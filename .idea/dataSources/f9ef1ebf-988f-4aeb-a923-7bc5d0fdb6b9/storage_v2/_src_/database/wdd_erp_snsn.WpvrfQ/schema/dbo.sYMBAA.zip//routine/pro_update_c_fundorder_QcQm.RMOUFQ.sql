CREATE PROC [dbo].[pro_update_c_fundorder_QcQm]
       @type INT ,
       @ciid INT = 0,
       @shid INT = 0 ,
       @to_cpid INT = 0 ,
       @id INT = 0
AS
       BEGIN
             --UPDATE c_fundorder
             --SET    fo_ordernum = cfu.num
             --FROM   c_fundorder AS cf ,
             --       ( SELECT    cf.fo_id ,
             --                   ROW_NUMBER() OVER ( ORDER BY cf.fo_dateint, cf.fo_orderid ) AS num
             --         FROM      c_fundorder AS cf
             --         WHERE     cf.fo_status = 2
             --                   AND cf.fo_type = @type
             --                   AND cf.fo_ciid = @ciid
             --                   AND cf.fo_shid = @shid
             --                   AND cf.fo_to_cpid = @to_cpid
             --       ) AS cfu
             --WHERE  cfu.fo_id = cf.fo_id

             DECLARE @fo_bs VARCHAR(50)= '';

             IF @type = 1
                SET @fo_bs = 'G';
             ELSE
                SET @fo_bs = 'X';

             ---EXEC pro_merge_c_fundorder @fo_bs = @fo_bs, @fo_ciid = @ciid, @fo_id = @id, @fo_shid = @shid, @fo_to_cpid = @to_cpid, @operate_type = '计算客户供应商固化数据';
			 
			 --计算对帐明细
             ---EXEC pro_merge_c_fundorder_reconciliation @fo_id = 0, @fo_ciid = @ciid, @fo_shid = @shid, @fo_to_cpid = @to_cpid, @fo_bs = @fo_bs;
       END
go

