


CREATE VIEW [dbo].[vi_j_purchaseStorageList_ognum_Group_Goods]
 AS
SELECT tb.*,
	   --执行数量
       (tb.ogl_num -tb.pll_num1)  AS ogl_num1,
       
       --未执行数量
       tb.pll_num1                AS pll_num_wzx,
       
       --采购数量
       tb.pll_num                 AS pll_num_dh,
       
       
       --已采购数量
       (tb.ogl_num -tb.pll_num1)  AS ycg_num,
       
       --已采购金额
       (tb.ogl_num -tb.pll_num1) * pll_stock_price AS ycg_money
FROM   (
           SELECT al.*,
				  --判断明细状态是否处于删除状态,处于删除状态就不返回数量
                  CASE al.pll_status
                       WHEN 0 THEN 0
                       ELSE al.pll_num
                  END                     AS pll_num1,
                  
                  ISNULL(red.ogl_num, 0)  AS ogl_num,
                  
                  red.og_id               AS og_id1,
                  red.ogl_add_time,
                  red.ogl_gi_id
           FROM   vi_j_purchaseStorageList_og_group_goods AS al
                  LEFT JOIN (
                           --合计订单数量
                           SELECT og_id,
                                  ogl_gi_id,
                                  SUM(ogl_num) AS ogl_num,
                                  ogl_add_time
                           FROM   vi_allocation_og_outed
                           GROUP BY
                                  og_id,
                                  ogl_gi_id,
                                  ogl_add_time
                       ) red
                       ON  
                       red.og_id = al.pl_source_id
                       and 
                       red.ogl_gi_id = al.pll_gi_id
                       AND al.pll_source_add_time 
                       = red.ogl_add_time
                       and al.pl_source=1
       ) AS tb


go

