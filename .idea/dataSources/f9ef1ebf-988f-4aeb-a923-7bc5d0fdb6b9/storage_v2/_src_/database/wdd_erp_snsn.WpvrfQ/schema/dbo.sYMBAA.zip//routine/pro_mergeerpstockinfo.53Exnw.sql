CREATE PROCEDURE [dbo].[pro_mergeerpstockinfo]
	@cp_id INT=0,
	@erpid int
AS
	SELECT @cp_id,@erpid



RETURN 0
go

