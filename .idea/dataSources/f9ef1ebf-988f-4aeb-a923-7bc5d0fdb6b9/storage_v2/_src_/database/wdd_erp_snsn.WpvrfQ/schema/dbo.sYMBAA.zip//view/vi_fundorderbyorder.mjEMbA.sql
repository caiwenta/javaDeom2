CREATE VIEW [dbo].[vi_fundorderbyorder]
	AS 
SELECT
	rowNum ,
	(fo_qc+ab.o_qc) AS qct,
	(fo_qm+ab.o_qc) AS qmt, 
	fb.fo_id,
	fo_cp_id,
	fo_ciid,
	fo_shid,
	fo_to_cpid,
	fo_status=2,
	fo_addtime,
	fo_remark,
	remark=fb.fo_custom_remark,
	fo_lastman,   
	(select cp_name from companyinfo where cp_id=fo_cp_id) set_cpname ,
	cicode=ab.o_code,
	objectname=ab.o_name,
	fo_no,
	fo_ofdate,
	fo_order_no,
	fo_realmoney,
	fo_givemoney,
	fo_admoney,
	fo_otheronmoney,
	fo_otheoutmoney,
	fo_thiyetmoney,
	fo_ensuremoney,
	fo_subscription,  
	fo_outmoney,
	fo_finished_money,
	fo_parts_money,
	fo_type,
	fo_erp_id
FROM c_fundorderbyorder AS fb 
INNER JOIN a_objectlist ab ON fb.fo_o_id=ab.o_id
go

