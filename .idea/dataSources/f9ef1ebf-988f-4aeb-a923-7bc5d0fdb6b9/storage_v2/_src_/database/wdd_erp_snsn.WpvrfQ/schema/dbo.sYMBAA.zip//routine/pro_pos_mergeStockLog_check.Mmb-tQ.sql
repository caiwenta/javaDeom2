CREATE  PROC [dbo].[pro_pos_mergeStockLog_check]
@tsl_sh_id INT, 
@negative_inventory INT = 0,
@old_sei_id INT = 0,  
@new_sei_id INT = 0
AS

IF ISNULL(@tsl_sh_id,0)=0
BEGIN
RAISERROR (
			'库存更新失败,sh_id空值',	
			16,	
			1,	
			N'number',	
			5 
		);
	RETURN;
END

IF @old_sei_id = @new_sei_id
BEGIN
    SET @old_sei_id = 0;
END

DECLARE @result_var VARCHAR(1000) = '';
DECLARE @bool_need_error INT = 0;


--比较开始盘点
IF (
       (
           SELECT COUNT(1) AS COUNT
           FROM   pos_takeStorageLog AS jt
                  INNER JOIN pos_stocklog AS js
                       ON  jt.tsl_st_id = js.sl_seiid
                           --and js.sl_addtime<dateadd(day,1,jt.tsl_date)
                       AND js.sl_order_date < DATEADD(DAY, 1, jt.tsl_date)
           WHERE  js.sl_shop_id = @tsl_sh_id
                  AND jt.tsl_status = 1 and  jt.tsl_st_id in(@old_sei_id,@new_sei_id)
                  AND js.sl_status != 0
                  AND jt.tsl_sh_id = @tsl_sh_id
       ) != (
           SELECT COUNT(1) AS COUNT
           FROM   pos_takeStorageLog AS jt
                  INNER JOIN vi_pos_stockList AS js
                       ON  jt.tsl_st_id = js.[sid]
                           --and js.addtime<dateadd(day,1,jt.tsl_date)
                       AND js.order_date < DATEADD(DAY, 1, jt.tsl_date)
           WHERE  jt.tsl_status = 1 and  jt.tsl_st_id in(@old_sei_id,@new_sei_id)
                  AND jt.tsl_sh_id = @tsl_sh_id
                  AND js.shid = @tsl_sh_id
       )
   )
BEGIN
    SET @result_var = '当前处于盘点准备状态,库存已被锁定!';
    SET @bool_need_error = 1;
END
	
--比较盘点完成
IF @bool_need_error = 0
BEGIN
    IF (
           (
               SELECT COUNT(1) AS COUNT
               FROM   pos_takeStorageLog AS jt
                      INNER JOIN pos_stocklog AS js
                           ON  jt.tsl_st_id = js.sl_seiid
                               --and js.sl_addtime<dateadd(day,1,jt.tsl_date)
                           AND js.sl_order_date < DATEADD(DAY, 1, jt.tsl_date)
               WHERE  js.sl_shop_id = @tsl_sh_id
                      AND jt.tsl_status = 2 and  jt.tsl_st_id in(@old_sei_id,@new_sei_id)
                      AND js.sl_status != 0
                      AND jt.tsl_sh_id = @tsl_sh_id
           ) != (
               SELECT COUNT(1) AS COUNT
               FROM   pos_takeStorageLog AS jt
                      INNER JOIN vi_pos_stockList AS js
                           ON  jt.tsl_st_id = js.[sid]
                               --and js.addtime<dateadd(day,1,jt.tsl_date)
                           AND js.order_date < DATEADD(DAY, 1, jt.tsl_date)
               WHERE  jt.tsl_status = 2 and  jt.tsl_st_id in(@old_sei_id,@new_sei_id)
                      AND jt.tsl_sh_id = @tsl_sh_id
                      AND js.shid = @tsl_sh_id
           )
       )
    BEGIN
        SET @result_var = '当前处于盘点完成状态,库存已被锁定!';
        SET @bool_need_error = 1;
    END
END

--是否负库存
IF @bool_need_error = 0
BEGIN
    IF EXISTS( SELECT fd.sei_id FROM   pos_storageInfo fd WITH (NOLOCK) WHERE  fd.sei_is_negative_inventory = 0 AND fd.sei_sh_id = @tsl_sh_id )
    BEGIN

	
        IF EXISTS(
               SELECT *
               FROM   (
                          SELECT sl.[sid],
                                 sl.gid,
                                 sl.skuid,
                                 sl.shid,
								 isnull(sl.pm,'') as pm,
                                 SUM(CASE WHEN sl.countType = 1 THEN sl.gnum ELSE -sl.gnum END) AS 
                                 gnum
                          FROM   vi_pos_stockList sl
                                 INNER JOIN pos_storageInfo fd WITH (NOLOCK)
                                      ON  sl.[sid] = fd.sei_id
                          WHERE  sl.shid = @tsl_sh_id and
						         sl.[sid] in(@old_sei_id,@new_sei_id)
                                 AND fd.sei_is_negative_inventory = 0
                                 AND fd.sei_sh_id = @tsl_sh_id
                          GROUP BY
                                 sl.[sid],
                                 sl.gid,
                                 sl.skuid,
                                 sl.shid,
								 isnull(sl.pm,'') 
                      ) AS fd
               WHERE  fd.gnum < 0
           )
        BEGIN
            SET @result_var = '不允许负库存!';
            SET @bool_need_error = 1;
        END
		

    END
END

----负库存提示
--IF @old_sei_id=0 AND @new_sei_id=0
--BEGIN
--	IF @bool_need_error=0 AND @negative_inventory=1
--	BEGIN
--	IF EXISTS(
--	select * from (
--	 select sl.[sid],
--       sl.gid,
--       sl.skuid,
--       sl.shid,
--       SUM(CASE WHEN sl.countType = 1 THEN sl.gnum ELSE -sl.gnum END) AS gnum 
--       from vi_pos_stockList sl
--       INNER JOIN 
--       pos_storageInfo fd WITH (NOLOCK) 
--       ON sl.[sid]=fd.sei_id 
--       WHERE 
--       sl.shid=@tsl_sh_id 
--       AND fd.sei_is_negative_inventory=1 
--       AND fd.sei_is_info=1
--       AND fd.sei_sh_id=@tsl_sh_id
--       GROUP BY
--       sl.[sid], 
--       sl.gid,
--       sl.skuid,
--       sl.shid
--	) AS fd WHERE fd.gnum<0)
--	BEGIN
-- 	SET @result_var = '会产生负库存,确定操作?';
--	SET @bool_need_error = 1;
--    END	
--	end
--end

IF @old_sei_id > 0
BEGIN
    IF @bool_need_error = 0
       AND @negative_inventory = 1
    BEGIN
        IF EXISTS(
               SELECT *
               FROM   (
                          SELECT sl.[sid],
                                 sl.gid,
                                 sl.skuid,
                                 sl.shid,
								 isnull(sl.pm,'') as pm,
                                 SUM(CASE WHEN sl.countType = 1 THEN sl.gnum ELSE -sl.gnum END) AS 
                                 gnum
                          FROM   vi_pos_stockList sl
                                 INNER JOIN pos_storageInfo fd WITH (NOLOCK)
                                      ON  sl.[sid] = fd.sei_id
                          WHERE  sl.[sid] = @old_sei_id
                                 AND sl.shid = @tsl_sh_id
                                 AND fd.sei_is_negative_inventory = 1
                                 AND fd.sei_is_info = 1
                                 AND fd.sei_sh_id = @tsl_sh_id
                          GROUP BY
                                 sl.[sid],
                                 sl.gid,
                                 sl.skuid,
                                 sl.shid,
								 isnull(sl.pm,'') 
                      ) AS fd
               WHERE  fd.gnum < 0
           )
        BEGIN
            SET @result_var = '会产生负库存,确定操作?';
            SET @bool_need_error = 1;
        END
    END
END

IF @new_sei_id > 0
BEGIN
    IF @bool_need_error = 0
       AND @negative_inventory = 1
    BEGIN
        IF EXISTS(
               SELECT *
               FROM   (
                          SELECT sl.[sid],
                                 sl.gid,
                                 sl.skuid,
                                 sl.shid,
								 isnull(sl.pm,'') as pm,
                                 SUM(CASE WHEN sl.countType = 1 THEN sl.gnum ELSE -sl.gnum END) AS 
                                 gnum
                          FROM   vi_pos_stockList sl
                                 INNER JOIN pos_storageInfo fd WITH (NOLOCK)
                                      ON  sl.[sid] = fd.sei_id
                          WHERE  sl.[sid] = @new_sei_id
                                 AND sl.shid = @tsl_sh_id
                                 AND fd.sei_is_negative_inventory = 1
                                 AND fd.sei_is_info = 1
                                 AND fd.sei_sh_id = @tsl_sh_id
                          GROUP BY
                                 sl.[sid],
                                 sl.gid,
                                 sl.skuid,
                                 sl.shid,
								 isnull(sl.pm,'') 
                      ) AS fd
               WHERE  fd.gnum < 0
           )
        BEGIN
            SET @result_var = '会产生负库存,确定操作?';
            SET @bool_need_error = 1;
        END
    END
END

IF @bool_need_error = 1
BEGIN
    RAISERROR (@result_var, 16, 1, N'number', 5);
END
go

