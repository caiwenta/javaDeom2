CREATE VIEW [dbo].[v_z_moStorage_good]
	AS 
SELECT   
	T.*,
	bg.*  
FROM 
(

SELECT '移出' mo_out_in,
       (CASE WHEN mo_in_st_id<>0 THEN mo_in_st_id ELSE mo_to_st_id END)mo_in_st_id, 
       (CASE WHEN mo_in_st_id<>0 THEN mo_in_st_id_txt ELSE mo_to_st_id_txt END)mo_in_st_id_txt, --移入仓库(旧) 
       mo_out_st_id, 
       mo_out_st_id_txt, --移出仓库
       mo_id, 
       mo_vo, 
       mo_date, 
       mo_no, 
       mo_order_man, 
       mo_cp_id, 
       mo_di_id, 
       mo_order_man_txt, 
       mo_add_man_txt, 
       mo_add_man, 
       mo_add_time, 
       mo_update_man_txt, 
       mo_update_man, 
       mo_update_time, 
       mo_audit_man_txt, 
       mo_audit_man, 
       mo_audit_time, 
       mo_remark, 
       mo_status, 
       mol_mo_id, 
       mol_gi_id, 
        -abs(mol_num )mol_num , 
       mol_stock_num, 
       mol_discount, 
        -abs(mol_retail_money) mol_retail_money,
       mol_retail_price,
       mol_stock_price, 
        -abs(mol_money) mol_money, 
       mol_boxbynum,--数量/箱
       -abs(case when isnull(mol_boxbynum,0)=0 then 0 else ceiling(mol_num/mol_boxbynum) end) as mol_box_num, --箱数
       mol_pm, 
       mol_add_time, 
       sumnum, 
       summoney 
FROM (
		SELECT mol_retail_price* mol_num AS mol_retail_money,*
		FROM j_moStorageListMergeSum el
		LEFT JOIN vi_j_moStorage eo ON  el.mol_mo_id = eo.mo_id AND eo.mo_status > 0
	)T  
WHERE mo_out_st_id > 0 and T.mol_type=0

UNION ALL

SELECT '移入' mo_out_in,
       mo_in_st_id, 
       mo_in_st_id_txt, --移入仓库(旧) 
       mo_out_st_id, 
       mo_out_st_id_txt, --移出仓库
       mo_id, 
       mo_vo, 
       mo_date, 
       mo_no, 
       mo_order_man, 
       mo_cp_id, 
       mo_di_id, 
       mo_order_man_txt, 
       mo_add_man_txt, 
       mo_add_man, 
       mo_add_time, 
       mo_update_man_txt, 
       mo_update_man, 
       mo_update_time, 
       mo_audit_man_txt, 
       mo_audit_man, 
       mo_audit_time, 
       mo_remark, 
       mo_status, 
       mol_mo_id, 
       mol_gi_id, 
       mol_num, 
       mol_stock_num, 
       mol_discount, 
       mol_retail_money,
       mol_retail_price,
       mol_stock_price, 
       mol_money, 
       mol_boxbynum,--数量/箱
      (case when isnull(mol_boxbynum,0)=0 then 0 else ceiling(mol_num/mol_boxbynum) end) as mol_box_num, --箱数
       mol_pm, 
       mol_add_time, 
       sumnum, 
       summoney 
FROM (
		SELECT mol_retail_price* mol_num AS mol_retail_money,*
		FROM j_moStorageListMergeSum el
		LEFT JOIN vi_j_moStorage eo ON el.mol_mo_id = eo.mo_id AND eo.mo_status > 0
	)T  
WHERE mo_in_st_id > 0 AND mo_source_type=0 and T.mol_type=1

UNION ALL

SELECT '移入' mo_out_in,
       mo_in_st_id, 
       mo_in_st_id_txt, --移入仓库(新)
      (SELECT mo_out_st_id FROM j_moStorage WHERE mo_id=T.mo_source_id),
      (SELECT (SELECT sei_name FROM b_storageinfo AS bs WITH (NOLOCK) WHERE sei_id = mo_out_st_id) FROM j_moStorage WHERE mo_id=T.mo_source_id), --移出仓库
       mo_id, 
       mo_vo, 
       mo_date, 
       mo_no, 
       mo_order_man, 
       mo_cp_id, 
       mo_di_id, 
       mo_order_man_txt, 
       mo_add_man_txt, 
       mo_add_man, 
       mo_add_time, 
       mo_update_man_txt, 
       mo_update_man, 
       mo_update_time, 
       mo_audit_man_txt, 
       mo_audit_man, 
       mo_audit_time, 
       mo_remark, 
       mo_status, 
       mol_mo_id, 
       mol_gi_id, 
       mol_num, 
       mol_stock_num, 
       mol_discount, 
       mol_retail_money,
       mol_retail_price,
       mol_stock_price, 
       mol_money, 
       mol_boxbynum,--数量/箱
      (case when isnull(mol_boxbynum,0)=0 then 0 else ceiling(mol_num/mol_boxbynum) end) as mol_box_num, --箱数
       mol_pm, 
       mol_add_time, 
       sumnum, 
       summoney 
FROM (
		SELECT mol_retail_price* mol_num AS mol_retail_money,*
		FROM j_moStorageListMergeSum el
		LEFT JOIN vi_j_moStorage_RU eo ON el.mol_mo_id = eo.mo_id AND eo.mo_status > 0
	)T  WHERE T.mo_source_type=2 and T.mol_type=2


)T
INNER JOIN b_goodsinfo bg ON bg.gi_id=T.mol_gi_id and bg.gi_status>0
go

