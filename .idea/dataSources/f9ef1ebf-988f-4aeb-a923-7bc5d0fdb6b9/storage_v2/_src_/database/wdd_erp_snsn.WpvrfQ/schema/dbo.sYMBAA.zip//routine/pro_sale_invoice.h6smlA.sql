CREATE PROCEDURE dbo.pro_sale_invoice
	@sa_id int,
	@sal_buyingteamid int,
	@sa_sh_id int,
	@si_company int,
	@sa_erp_id int
AS

DECLARE @i_id int=0;
DECLARE @orderNo varchar(50)='';
DECLARE @invoicecount int=0;

  if exists(select * from pos_sale_invoice where sa_id=@sa_id and sal_buyingteamid=@sal_buyingteamid)
  begin
		select 
		    @invoicecount=invoicecount,
			@i_id=i_id,
			@orderNo=orderNo
		from pos_sale_invoice 
		where sa_id=@sa_id and 
		sal_buyingteamid=@sal_buyingteamid

		update pos_sale_invoice set i_updatetime=getdate(),scanscount=scanscount+1;
	
   end
   else
   begin

		INSERT INTO pos_sale_invoice
			 (sa_id,sal_buyingteamid,sa_sh_id,si_company,i_addtime,scanscount,erp_id)
		VALUES
			 (@sa_id,@sal_buyingteamid,@sa_sh_id,@si_company,getdate(),1,@sa_erp_id)
		
		SET @i_id = SCOPE_IDENTITY();
		set @invoicecount=0;

		--订单号
		Declare @countstr Varchar(50)=convert(varchar(50),@i_id);
		If Len(@countstr)=1
		Begin
			Set @countstr='0000000'+@countstr;
		End
		Else If Len(@countstr)=2
		Begin
			Set @countstr='000000'+@countstr;
		End
		Else If Len(@countstr)=3
		Begin
			Set @countstr='00000'+@countstr;
		End
		Else If Len(@countstr)=4
		Begin
			Set @countstr='0000'+@countstr;
		End
		Else If Len(@countstr)=5
		Begin
			Set @countstr='000'+@countstr;
		End
		Else If Len(@countstr)=6
		Begin
			Set @countstr='00'+@countstr;
		End
		Else If Len(@countstr)=7
		Begin
			Set @countstr='0'+@countstr;
		End
		set @orderNo=@countstr;
		update pos_sale_invoice set orderNo=@orderNo where i_id=@i_id;

   end

select @i_id as i_id,@orderNo as orderNo,@invoicecount as invoicecount;
go

