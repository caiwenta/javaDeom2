CREATE VIEW [dbo].[vi_power_page] AS 
SELECT spi.*,
       sri.ri_id,
       bs.si_id
FROM   s_role_info AS sri
       INNER JOIN b_stafftinfo AS bs
            ON  sri.ri_id = bs.si_pid
       INNER JOIN s_power_page_info AS sppi
            ON  sri.ri_id = sppi.ppi_ri_id
       INNER JOIN vi_module_page_info AS spi
            ON  sppi.ppi_pi_id = spi.pi_id
WHERE  sri.ri_status = 1
       AND bs.si_status = 1
       AND spi.pi_status = 1
       AND sppi.ppi_is_enable = 1
go

