


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pro_pos_staffClassSet_op]
	@st_id INT OUTPUT,
	@st_st_id VARCHAR(50),
	@st_cl_id INT,
		@st_erp_id INT,
	@st_remark VARCHAR(50),
	@st_sh_id INT=0,
	@st_add_man INT,
	@st_add_time DATETIME,
	@st_update_man INT,
	@st_update_time DATETIME,
	 --操作类型(1:添加 2:修改 3:删除)
	@op_type INT = 0,
	@outResult INT OUTPUT
AS
BEGIN
	IF @op_type = 1
	BEGIN
	    INSERT INTO [pos_staffClassSet]
	      (
	        [st_st_id],
	        [st_cl_id],
	        [st_remark],
	        [st_add_man],
	        [st_add_time],
	        [st_update_man],
	        [st_update_time],
	        st_sh_id,st_erp_id
	      )
	    VALUES
	      (
	        @st_st_id,
	        @st_cl_id,
	        @st_remark,
	        @st_add_man,
	        @st_add_time,
	        @st_update_man,
	        @st_update_time,
	        @st_sh_id,@st_erp_id
	      )
	    SET @st_id = SCOPE_IDENTITY()
	END
	
	IF @op_type = 2
	   AND @st_id > 0
	BEGIN
	    UPDATE [pos_staffClassSet]
	    SET    [st_st_id] = @st_st_id,
	           [st_cl_id] = @st_cl_id,
	           [st_remark] = @st_remark,
	           st_sh_id= @st_sh_id,
	           [st_update_man] = @st_update_man,
	           [st_update_time] = @st_update_time
	    WHERE  st_id = @st_id
	     AND st_sh_id=@st_sh_id
	END
	
	IF @op_type = 3
	   AND @st_id > 0
	BEGIN
	   update pos_staffClassSet SET st_status=0
	    WHERE  st_id = @st_id
	     AND st_sh_id=@st_sh_id
	END
	
	IF @@error <> 0
	BEGIN
	    SET @outResult = 0;
	END
	ELSE
	BEGIN
	    SET @outResult = @st_id;
	END
	RETURN @outResult;
END
go

