CREATE PROCEDURE [dbo].[pro_mergeStockBatchCodeSum]
	@cp_id INT=0
AS


DECLARE @now DATETIME = GETDATE();
DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
BEGIN TRY

MERGE INTO b_stockinfobatch AS ta 
USING 
(

Select 
sl.[sid],
sl.gid,
sl.skuid,
sl.cp_id,
sl.boxbynum, 
Sum(Case when sl.countType=1 Then sl.gnum Else -sl.gnum End)As gnum,
Sum(Case when sl.countType=1 Then sl.box_num Else -sl.box_num End)As box_num,
MAX(sl.addtime) AS addtime,
pm
From vi_stockList_nolock sl WHERE sl.cp_id=@cp_id 
Group By 
sl.[sid],
sl.gid,
sl.skuid,
sl.cp_id,
sl.pm,
sl.boxbynum

) AS so ON 
ta.si_seiid = so.[sid]  
AND ta.si_giid = so.gid 
AND ta.si_skuid = so.skuid 
AND ta.si_cp_id=so.cp_id 
AND ta.si_pm=so.pm
and ta.sl_boxbynum=so.boxbynum
WHEN matched THEN 
UPDATE SET 
ta.sl_box_num=so.box_num,
ta.si_number = so.gnum,
ta.si_status=1,
ta.si_indate=case when  ta.si_number!=so.gnum then @now else ta.si_indate END
WHEN NOT matched THEN
INSERT 
  (
    si_seiid,
    si_giid,
    si_skuid,
    si_number,
    si_status,
    si_indate,
    si_cp_id,
	si_pm,
	sl_boxbynum,
	sl_box_num
  )
VALUES
  (
    so.[sid],
    so.gid,
    so.skuid,
    so.gnum,
    1,
    @now,
    so.cp_id,
	isnull(so.pm,''),
	so.boxbynum,
	so.box_num
  )
WHEN NOT matched BY source AND ta.si_status != 0 AND ta.si_cp_id=@cp_id THEN 
UPDATE 
SET    ta.si_number=0,
       ta.si_indate =CASE WHEN si_number!=0 THEN  @now ELSE si_indate END;




delete b_stockinfobatchMergeColorSum where si_cp_id=@cp_id
INSERT INTO b_stockinfobatchMergeColorSum
           (si_seiid
           ,si_status
           ,si_number
           ,si_indate
           ,si_giid
           ,si_cp_id
           ,si_pm
           ,sl_boxbynum
           ,sl_box_num
           ,sl_color_id)
SELECT 
		sl.si_seiid,
		1,
		Sum(si_number)As gnum,
		MAX(sl.si_indate) AS addtime,
		sl.si_giid,
		sl.si_cp_id,
		isnull(si_pm,'') AS si_pm,
		sl.sl_boxbynum, 
		(CASE WHEN ISNULL(sl.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(Sum(si_number)/sl.sl_boxbynum) END)ol_box_num,
		isnull(bg.colorid,0) AS sl_colorid
FROM b_stockinfobatch AS sl
LEFT JOIN b_goodsruleset AS bg ON sl.si_skuid=bg.gss_id
where sl.si_cp_id=@cp_id
GROUP BY 
sl.si_seiid,
sl.si_giid,
sl.si_cp_id,
sl.sl_boxbynum,
isnull(si_pm,''),
isnull(bg.colorid,0)



delete b_stockinfobatchMergeSum where si_cp_id=@cp_id
INSERT INTO b_stockinfobatchMergeSum
           (si_seiid
           ,si_status
           ,si_number
           ,si_indate
           ,si_giid
           ,si_cp_id
           ,si_pm
           ,sl_boxbynum
           ,sl_box_num
           )
SELECT 
		sl.si_seiid,
		1,
		Sum(si_number)As gnum,
		MAX(sl.si_indate) AS addtime,
		sl.si_giid,
		sl.si_cp_id,
		isnull(si_pm,'') AS si_pm,
		sl.sl_boxbynum, 
		(CASE WHEN ISNULL(sl.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(Sum(si_number)/sl.sl_boxbynum) END)ol_box_num
FROM b_stockinfobatchMergeColorSum AS sl
where sl.si_cp_id=@cp_id
GROUP BY 
sl.si_seiid,
sl.si_giid,
sl.si_cp_id,
sl.sl_boxbynum,
isnull(si_pm,'')




DELETE b_stockinfobatchMergeRuleSum where si_cp_id=@cp_id
INSERT INTO b_stockinfobatchMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
si_cp_id,
si_giid
)
SELECT 
	ems.si_id,
	vi.gnum,
	vi.sl_colorid AS colorid,
	vi.size AS gd_id,
	vi.si_cp_id AS si_cp_id,
	vi.si_giid
FROM (
	SELECT 
			sl.si_seiid,
			ISNULL(Sum(si_number),0)As gnum,
			MAX(sl.si_indate) AS addtime,
			sl.si_giid,
			sl.si_cp_id,
			isnull(si_pm,'') AS si_pm,
			sl.sl_boxbynum, 
			(CASE WHEN ISNULL(sl.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(Sum(si_number)/sl.sl_boxbynum) END)ol_box_num,
			isnull(bg.colorid,0) AS sl_colorid,
			ISNULL(bg.specid,0) AS size
		FROM b_stockinfobatch AS sl
		LEFT JOIN b_goodsruleset AS bg ON sl.si_skuid=bg.gss_id
		where sl.si_cp_id=@cp_id
		GROUP BY 
			sl.si_seiid,
			sl.si_giid,
			sl.si_cp_id,
			sl.sl_boxbynum,
			isnull(si_pm,''),
			isnull(bg.colorid,0),
			ISNULL(bg.specid,0)
) AS vi
INNER JOIN b_stockinfobatchMergeColorSum AS ems on 
vi.si_seiid=ems.si_seiid 
and vi.si_giid=ems.si_giid 
and vi.si_cp_id=ems.si_cp_id 
and vi.sl_colorid=ems.sl_color_id
and vi.si_pm=ems.si_pm
WHERE ems.si_cp_id=@cp_id






  
END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

