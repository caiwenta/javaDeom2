CREATE PROCEDURE [dbo].[pro_cardpaymentdetail_op]
	@me_id int = 0,
	@erpid int =0,
	@shipid int=0,
	@said int=0,
	@payment decimal(10,2)=0,
	@status int=0,
	@addtime datetime,
	@add_man int=0,
	@paytype int=0,
	@cp_vo VARCHAR(100),
	@remark VARCHAR(1000),
	@svc_id int=0,
	@receivepayment decimal(10,2)=0,--充值消费
	@givemoneypayment decimal(10,2)=0--赠送消费
AS

IF(SELECT me_balance FROM pos_memberInfo WHERE me_id=@me_id)>=@payment 
BEGIN 

    insert into 
	erp_cardpaymentdetail(me_id,erpid,shipid,said,sa_vo,balance,payment,status,addtime,add_man,
	paytype,cp_vo,remark,svc_id,receivepayment,givemoneypayment)
    values ( 
		@me_id,@erpid,@shipid,@said, 
		(SELECT sa_vo FROM pos_sale AS ps WHERE ps.sa_id=@said), 
		(select me_balance from pos_memberInfo as pm where pm.me_id=@me_id), 
		@payment,@status,@addtime,@add_man,@paytype, 
		(case when @svc_id>0 then (select svc_vo from erp_storedvaluecardcode WHERE svc_id=@svc_id) else @cp_vo end ), 
		@remark, 
		@svc_id,
		@receivepayment,
		@givemoneypayment
    );

    UPDATE pos_memberInfo SET 
	me_payment = me_payment+@payment,
	me_balance=me_balance-@payment,
	me_givemoney=me_givemoney-@givemoneypayment,
	me_rechargeamount=me_rechargeamount-@receivepayment
	WHERE me_id=@me_id;

END  
else
begin
		RAISERROR ( '余额不足', 16, 1, N'number', 5 );
end
go

