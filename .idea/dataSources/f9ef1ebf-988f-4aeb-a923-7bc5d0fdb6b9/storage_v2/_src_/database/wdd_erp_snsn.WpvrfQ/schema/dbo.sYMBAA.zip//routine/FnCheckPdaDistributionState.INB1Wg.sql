CREATE FUNCTION [dbo].[FnCheckPdaDistributionState]
(
	@sumnum int=0,
	@source_id int=0,
	@warehousingtype int=0
)
RETURNS INT
AS
BEGIN

	  --验证pds是否已派单
	  DECLARE @re INT=1;--0:未派单 1:已派单
    
	  --di_status等于1时
	   
	   IF EXISTS(
	         SELECT do_id FROM erp_distributionpdaing WHERE do_id in
			(SELECT do_id FROM erp_distributionorder WHERE warehousingtype=@warehousingtype and do_status<>0 AND do_source_id=@source_id)
			AND di_status=1
			)
	   BEGIN

			SET	@re=1;

	   END
	   ELSE
	   BEGIN
	   
		  --pda完成数等于总数的话完成的话
	      IF (select SUM(do_inspectionnum) from erp_distributionorder where do_source_id=@source_id and warehousingtype=@warehousingtype and do_status>0)
			<=@sumnum
		  BEGIN
				SET	@re=1;
		  END
		  ELSE
		  BEGIN
				 SET @re=0;
		  END

	   END
	
	 RETURN @re;
END
go

