CREATE VIEW [dbo].[vi_Join_AllocationList] AS 
SELECT
	all_al_id,
	all_gi_id,
	all_add_time,
	CONVERT (
		VARCHAR (100),
		MIN (all_source_add_time),
		25
	) AS all_source_add_time,
	SUM (al.all_pause_num) AS all_pause_num,
	SUM (all_num) AS all_num,
	MIN (all_id) AS all_id,
	MAX (all_sku_id) AS all_sku_id,
	SUM (all_money) AS all_money,
	SUM (all_retail_money) AS all_retail_money,
	MIN (all_gift) AS all_gift,
	MAX (all_status) AS all_status,
	CONVERT (
		DECIMAL (10, 2),
		AVG (all_retail_price)
	) AS all_retail_price,
	CONVERT (
		DECIMAL (10, 2),
		AVG (all_stock_price)
	) AS all_stock_price,
	CONVERT (
		DECIMAL (10, 2),
		AVG (all_discount)
	) AS all_discount,
	MAX (REPLACE(all_pm, '*', ',')) AS all_pm,
	MAX (all_box_num) AS all_box_num
FROM
	pos_allocation fd  WITH (NOLOCK) 
INNER JOIN dbo.pos_allocationList AS al   WITH (NOLOCK) ON fd.al_id = al.all_al_id
AND al.all_status > 0
GROUP BY
	all_al_id,
	all_gi_id,
	all_add_time
go

