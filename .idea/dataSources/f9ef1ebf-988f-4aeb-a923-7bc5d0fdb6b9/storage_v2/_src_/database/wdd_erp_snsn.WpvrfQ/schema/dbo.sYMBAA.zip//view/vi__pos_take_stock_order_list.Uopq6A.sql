
CREATE VIEW [dbo].[vi__pos_take_stock_order_list] AS 
select * from pos_takeStorage  as jt inner join pos_takeStorageList  as jtsl on jt.ts_id=jtsl.tsl_ts_id
where jtsl.tsl_status=1 and jt.ts_status>0
go

