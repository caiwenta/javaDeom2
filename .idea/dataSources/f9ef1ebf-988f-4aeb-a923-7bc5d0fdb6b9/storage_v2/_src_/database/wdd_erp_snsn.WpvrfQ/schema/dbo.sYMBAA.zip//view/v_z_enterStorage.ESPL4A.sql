CREATE VIEW [dbo].[v_z_enterStorage]
	AS 
select 
do_id,
eo_source_type,--来源类型
(case when (select COUNT(*) from j_outStorage where oo_source_type=2 and oo_source_id=M.eo_id AND oo_status<>0 and [oo_erp_id]=M.eo_erp_id)>0 then 1 else 0 end) oo_status, 
--上级状态1:已收货，0：未收货;oo_source_type2:分公司入库退货，3:pos入库退货

M.eo_totalboxnum,	 
M.eo_realmoney,el_totalintegral,M.eo_num,M.eo_id,M.eo_no,M.eo_entrydate,M.eo_manual,M.eo_type,M.eo_siid,M.eo_freight,
M.eo_source_id,M.eo_ciid,M.eo_cost,M.eo_takemanid,M.eo_cp_id,M.eo_di_id,
M.eo_auditdate,M.eo_status,M.eo_addtime,M.eo_addman,M.eo_updateman,M.eo_updatetime,M.eo_lastmanid,M.eo_to_cp_id,M.eo_remark,eo_fo_audit_ed,
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_takemanid) AS takeman, 
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_addman) AS eo_addman_txt, 
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_updateman) AS eo_update_man_txt,   
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_lastmanid) AS eo_lastman,M.eo_erp_id,M.eo_erp_id as erp_id, 
ISNULL(fo.si_name,(SELECT cp_name FROM companyinfo WHERE cp_is_zorf =1 AND cp_erp_id =M.eo_cp_id))as si_name, 
ISNULL(fo.si_code,(SELECT cp_code FROM companyinfo WHERE cp_is_zorf =1 AND cp_erp_id =M.eo_cp_id))as si_code,
fo.si_flid,pe.type_fid si_plid,fo.si_province,fo.si_city,fo.si_county,sei_name,


(
case when eo_source_type=1 then
     (SELECT pl_vo FROM j_purchaseStorage jp where M.eo_source_id=jp.pl_id  AND pl_status > 0)
     when eo_source_type=2 then
	 (SELECT oo_no FROM j_outStorage WHERE oo_id=M.eo_source_id AND oo_status<>0)
end
)
as pl_vo,

(
case when eo_source_type=1 then
    (SELECT pl_source FROM j_purchaseStorage jp where M.eo_source_id=jp.pl_id  AND pl_status > 0)
     when eo_source_type=2 then
	(SELECT oo_source_id FROM j_outStorage WHERE oo_id=M.eo_source_id AND oo_status<>0)
end
) as pl_source,
      

com.cp_name eo_to_cp_id_txt 

from (

SELECT do_id,M.eo_realmoney,el_totalintegral,M.eo_num,M.eo_id,M.eo_no,
M.eo_entrydate,M.eo_manual,M.eo_type,M.eo_siid,M.eo_freight,

M.eo_source_id,M.eo_source_type,
M.eo_totalboxnum,
M.eo_ciid,M.eo_cost,
M.eo_takemanid,M.eo_cp_id,M.eo_di_id,M.eo_auditdate,M.eo_status,M.eo_addtime,M.eo_addman,M.eo_updateman,
M.eo_updatetime,M.eo_lastmanid,M.eo_to_cp_id,M.eo_remark,eo_fo_audit_ed,M.eo_erp_id,
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_takemanid) AS takeman, 
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_addman) AS eo_addman_txt, 
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_updateman) AS eo_update_man_txt,  
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_lastmanid) AS eo_lastman 
FROM 
(

SELECT
do_id,M.eo_realmoney,el_totalintegral,M.eo_num,M.eo_id,M.eo_no,M.eo_entrydate,M.eo_manual,M.eo_type,M.eo_siid,M.eo_freight,

M.eo_source_id,eo_source_type,
M.eo_totalboxnum,
M.eo_ciid,M.eo_cost,M.eo_takemanid,M.eo_cp_id,M.eo_di_id,M.eo_auditdate,
M.eo_status,M.eo_addtime,M.eo_addman,M.eo_updateman,M.eo_updatetime,M.eo_lastmanid,
M.eo_to_cp_id,M.eo_remark,eo_fo_audit_ed,M.eo_erp_id,
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_takemanid) AS takeman,
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_addman) AS eo_addman_txt, 
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_updateman) AS eo_update_man_txt,  
(SELECT si_name FROM b_stafftinfo b WHERE b.si_id=M.eo_lastmanid) AS eo_lastman 
from  j_enterStorage M 
left join (
SELECT  el_eoid,SUM(el_totalintegral) AS el_totalintegral FROM j_enterStorageList GROUP BY el_eoid 
) li ON M.eo_id=li.el_eoid  
WHERE   eo_status>0 

) M 
)  as M  
left join b_supplierinfo fo on M.eo_ciid=fo.si_id 
left join b_storageinfo st on M.eo_siid=st.sei_id 
left join  b_stafftinfo man on M.eo_takemanid=man.si_id 
left join companyinfo com on M.eo_to_cp_id=com.cp_id 
left join  cors_type pe on pe.[type_id]= fo.si_flid and pe.type_status>0
go

