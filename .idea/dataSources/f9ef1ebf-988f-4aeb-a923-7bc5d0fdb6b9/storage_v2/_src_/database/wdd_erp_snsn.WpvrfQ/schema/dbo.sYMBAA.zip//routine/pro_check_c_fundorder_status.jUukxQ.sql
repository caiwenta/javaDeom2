
CREATE Proc [dbo].[pro_check_c_fundorder_status]
@fo_order_id INT=0,
@fo_source_id INT=0
AS
IF @fo_order_id!=0
BEGIN
	SELECT cf.fo_status FROM c_fundorder cf WHERE cf.fo_order_id=@fo_order_id
END
ELSE
BEGIN
	SELECT cf.fo_status FROM c_fundorder cf WHERE cf.fo_source_id=@fo_source_id
END
go

