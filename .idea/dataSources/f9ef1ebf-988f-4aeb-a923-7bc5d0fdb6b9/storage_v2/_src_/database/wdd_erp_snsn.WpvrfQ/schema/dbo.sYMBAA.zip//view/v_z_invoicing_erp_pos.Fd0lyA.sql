CREATE VIEW [dbo].[v_z_invoicing_erp_pos]
	AS 

SELECT  bg.gi_name,   
		bg.gi_code,   
		bg.gi_barcode,   
		bg.gi_type1,
		bg.gi_type2,
		bg.gi_type3,
	    bg.gi_type4,
		bg.gi_typename1,
		bg.gi_typename2,
		bg.gi_typename3,
	    bg.gi_typename4,
		(CASE WHEN T.ei_objecttype=1 THEN T.ei_objectid WHEN T.ei_objecttype=2 THEN T.ei_sei_id END)sei_sh_id,   
		(CASE WHEN T.ei_objecttype=1 THEN (SELECT sh_name FROM pos_shop WITH (NOLOCK) WHERE sh_id=T.ei_objectid) 
		      WHEN T.ei_objecttype=2 THEN (SELECT sei_name FROM b_storageinfo WHERE sei_id=T.ei_sei_id) END)sei_sh_name,
        T.ei_erp_id,
		T.ei_objectid ,
        T.ei_objecttype ,
        T.ei_sei_id ,
        T.ei_date ,
        T.ei_gi_id ,
        T.ei_costprice ,--成本价
		T.ei_stockprice,--进货价 

        T.ei_firstnum firstnum ,  --期初数量           
        T.ei_firstcprice firstnummoney ,  --期初成本
		T.ei_firstnum* T.ei_stockprice firstnum_stock, --期初进货金额
		
        (CASE WHEN T.ei_objecttype = 1 THEN T.ei_sh_dis_initnum
              WHEN T.ei_objecttype = 2 THEN T.ei_initnum
         END) initnum , --入库数量 
        (CASE WHEN T.ei_objecttype = 1 THEN T.ei_sh_dis_initcprice
              WHEN T.ei_objecttype = 2 THEN T.ei_initcprice
         END) initnummoney , --入库成本
        (CASE WHEN T.ei_objecttype = 1 THEN T.ei_sh_dis_initnum
              WHEN T.ei_objecttype = 2 THEN T.ei_initnum
         END) * T.ei_stockprice initnum_stock, --入库进货金额 
	   
        (CASE WHEN T.ei_objecttype = 1 THEN (T.ei_sh_dis_initback + T.ei_sh_dis_allotnum)
              WHEN T.ei_objecttype = 2 THEN T.ei_initback
         END) initback , --入库退货
        (CASE WHEN T.ei_objecttype = 1 THEN (T.ei_sh_dis_initbackcprice + T.ei_sh_dis_allotcprice)
              WHEN T.ei_objecttype = 2 THEN T.ei_initbackcprice
         END) initbackmoney , --入库退货成本
        (CASE WHEN T.ei_objecttype = 1 THEN (T.ei_sh_dis_initback + T.ei_sh_dis_allotnum)
              WHEN T.ei_objecttype = 2 THEN T.ei_initback
         END) * T.ei_stockprice initback_stock, --入库退货进货金额
		
        (T.ei_ci_outnum + T.ei_sh_dis_outnum) saleout ,--销售出库
        (T.ei_ci_outcprice + T.ei_sh_dis_outcprice) saleoutmoney ,--销售出库成本
        (T.ei_ci_outnum + T.ei_sh_dis_outnum) * T.ei_stockprice saleout_stock ,--销售出库进货金额
		
        (T.ei_ci_outback + T.ei_sh_dis_outback) saleback ,--销售退货
        (T.ei_ci_outbackcprice + T.ei_sh_dis_outbackcprice) salebackmoney ,--销售退货成本
        (T.ei_ci_outback + T.ei_sh_dis_outback) * T.ei_stockprice saleback_stock ,--销售退货进货金额
		
        (CASE WHEN T.ei_objecttype = 1 THEN T.ei_sh_sa_initnum
              WHEN T.ei_objecttype = 2 THEN T.ei_sh_sa_outback
         END) allotinit , --调拨入库
        (CASE WHEN T.ei_objecttype = 1 THEN T.ei_sh_sa_initcprice
              WHEN T.ei_objecttype = 2 THEN T.ei_sh_sa_outbackcprice
         END) allotinitmoney ,  --调拨入库成本
        (CASE WHEN T.ei_objecttype = 1 THEN T.ei_sh_sa_initnum
              WHEN T.ei_objecttype = 2 THEN T.ei_sh_sa_outback
         END) * T.ei_stockprice allotinit_stock , --调拨入库进货金额
	   
        (CASE WHEN T.ei_objecttype = 1 THEN (T.ei_sh_sa_initback + T.ei_sh_sa_allotnum)
              WHEN T.ei_objecttype = 2 THEN T.ei_sh_sa_outnum
         END) allotout , --调拨出库
        (CASE WHEN T.ei_objecttype = 1 THEN (T.ei_sh_sa_initbackcprice + T.ei_sh_sa_allotcprice)
              WHEN T.ei_objecttype = 2 THEN T.ei_sh_sa_outcprice
         END) allotoutmoney , --调拨出库成本
        (CASE WHEN T.ei_objecttype = 1 THEN (T.ei_sh_sa_initback + T.ei_sh_sa_allotnum)
              WHEN T.ei_objecttype = 2 THEN T.ei_sh_sa_outnum
         END) * T.ei_stockprice allotout_stock , --调拨出库进货金额
	    
		T.ei_lossnum lossnum ,  --盈亏数量
		T.ei_losscprice lossnummoney ,  --盈亏成本
		T.ei_lossnum * T.ei_stockprice lossnum_stock ,  --盈亏进货金额

        T.ei_sh_onlysale zeronum ,--零售数量
        T.ei_costprice * ei_sh_onlysale zeronummoney ,--零售成本
        T.ei_sh_onlysale * T.ei_stockprice zeronum_stock ,--零售进货金额
	    
        (CASE WHEN T.ei_objecttype = 1 THEN T.ei_sh_onlysalecprice
              WHEN T.ei_objecttype = 2 THEN (T.ei_ci_outmoney + T.ei_sh_dis_outmoney)
         END) zeromoney --零售成交金额

FROM erp_invoicing_nosku T WITH (NOLOCK)
INNER JOIN v_goodsinfo bg WITH (NOLOCK) ON bg.gi_id = T.ei_gi_id
                                      AND bg.gi_erp_id = T.ei_erp_id
WHERE ((ei_objecttype = 2  AND ei_objectid = (SELECT cp_id FROM companyinfo WHERE cp_is_zorf=1 AND cp_erp_id=T.ei_erp_id)) OR ei_objecttype = 1)
go

