CREATE PROC [dbo].[pro_pos_sale_temp_op]
    @sal_erp_id INT = 0 ,
    @sal_id INT = 0 , --主键   
    @sal_sa_id INT = 0 , --销售登记主键  
    @sal_gi_id INT = 0 , --商品主键  
    @sal_sku_id INT = 0 , --商品sku主键
    @sal_num INT = 0 , --数量  
    @sal_retail_price DECIMAL(9, 2) = 0 , --零售价  
    @sal_discount DECIMAL(9, 2) = 0 , --折率 
    @sal_list_man INT = 0 , --导购员主键 
    @sal_real_price DECIMAL(9, 2) = 0 , --实售价  
    @sal_money DECIMAL(9, 2) = 0 , --应收金额  
    @sal_deduct_money DECIMAL(9, 2) = 0 , --扣除金额  
    @sal_is_gift INT = 0 ,  --是否赠送
    @sal_is_change INT = 0 ,  --是否换货
    @sal_is_zhengjia INT = 0 ,  --是否正价
    @sal_is_tejia INT = 0 ,  --是否特价
    @sal_is_in INT = 0 ,  --是否积分兑换
    @sal_in_num INT = 0 ,  --积分
    @sal_is_return INT = 0 , --是否退货
    @sal_remark VARCHAR(50) = '' ,  --备注
    @sal_remark2 VARCHAR(50) = '' ,--备注2
    @sal_st_id INT = 0 ,
    @sal_add_time DATETIME = '2014-10-24' ,  --添加时间
    @sa_id INT = 0 ,  --主键
    @sa_sh_id INT = 0 ,  --店铺主键
    @sa_co_man INT = 0 ,  --收银人员主键
    @sa_date DATETIME = '2014-10-24' ,  --销售日期
    @sa_no VARCHAR(50) = '' ,  --单据号
    @sa_ac_id INT = 0 ,  --活动主键
    @sa_order_man INT = 0 ,  --制单人主键
    @sa_st_id INT = 0 ,  --仓库主键
    @sa_update_man INT = 0 ,  --修改人主键
    @sa_update_time DATETIME = '2014-10-24' ,  --修改时间
    @sa_add_man INT = 0 ,  --添加人主键
    @sa_add_time DATETIME = '2014-10-24' ,  --添加时间
    @sa_type INT = 0 ,  --单据类型(0,销售登记:1,销售退货登记)
    @sa_sa_type INT = 0 ,  --销售类型(0,会员:1,零售)
    @sa_me_id INT = 0 ,  --会员主键
    @sa_remark VARCHAR(50) = '' ,  --备注
    @sa_in_id INT = 0 ,  --积分消费规则主键
    @sa_in_num INT = 0 ,  --积分消费
    @sa_get_in_num INT = 0 ,  --获得积分
    @sa_deduct_money DECIMAL(9, 2) = 0 ,  --扣除金额
    @sa_sa_vo INT = 0 ,  --消费代金劵
    @sa_gift_vo INT = 0 ,  --赠送代金券
    @sa_in_money DECIMAL(9, 2) = 0 ,  --积分抵扣额
    @sa_card_money DECIMAL(9, 2) = 0 ,  --刷卡金额
    @sa_shop_money DECIMAL(9, 2) = 0 ,  --商城金额
    @sa_money DECIMAL(9, 2) = 0 ,  --应收金额
    @sa_real_money DECIMAL(9, 2) = 0 ,  --实收金额
    @sa_charge_money DECIMAL(9, 2) = 0 ,  --挂账金额
    @sa_surplus_money DECIMAL(9, 2) = 0 ,  --找零
    @sa_select INT = 0 ,  --收款方式
    @sa_audit_man INT = 0 ,  --审核人主键
    @sa_audit_time DATETIME = '2014-10-24' ,  --审核时间
    @sa_sale_money DECIMAL(9, 2) = 0 , --销售金额
    @sa_change_money DECIMAL(9, 2) = 0 , --退货金额
    @sa_gift_money DECIMAL(9, 2) = 0 , --赠送金额
    @sa_current_vo INT = 0 ,--现有积分
    @sa_is_charge INT = 0 , --是否挂账
    @sa_paytype VARCHAR(100) = '' , --支付方式
    @erp_id INT = 0 ,
    @op_type VARCHAR(100) = '添加修改单据,明细' , --操作类型
    @negative_inventory INT = 0 ,
    @result VARCHAR(100) = '' OUT, --结果
	@sa_salman VARCHAR(100)='',
	@sa_salmanname VARCHAR(1000)='',
	@sal_customprice VARCHAR(50)='',
	@sal_deduction DECIMAL(9, 2) = 0 --网络订单扣款
AS
    BEGIN
        IF ( @erp_id = 0 AND @sa_sh_id > 0 )
            BEGIN
                SELECT  @erp_id = sh_erp_id
                FROM    pos_shop ps
                WHERE   sh_id = @sa_sh_id
            END
	
        IF @sal_money = 0
            BEGIN
                SET @sal_money = @sal_num * @sal_retail_price;
            END

        IF ISNULL(@sal_gi_id, 0) = 0
            BEGIN
                IF ISNULL(@sal_sku_id, 0) != 0
                    BEGIN
                        SELECT  @sal_gi_id = bg.gi_id
                        FROM    b_goodsruleset bg WITH ( NOLOCK )
                        WHERE   bg.gss_id = @sal_sku_id
                    END
            END	
	
        IF ( DATEPART(YEAR, @sa_update_time) = 2014 )
            BEGIN
                SET @sa_update_time = GETDATE();
            END
			
        DECLARE @sei_is_negative INT= 0;
        
        SELECT  @sei_is_negative = sei_is_negative_inventory
        FROM    pos_storageInfo WITH ( NOLOCK )
        WHERE   sei_id = @sa_st_id
        
        IF @op_type = '会员打折'
            BEGIN
                IF @sa_me_id = ( SELECT ISNULL(fd.sa_me_id, 0)
                                 FROM   pos_sale_temp AS fd WITH ( NOLOCK )
                                 WHERE  fd.sa_id = @sa_id
                               )
                    BEGIN
                        SET @result = '1';
                        RETURN;
                    END
                ELSE
                    BEGIN
                        IF ( SELECT ISNULL(fd.sa_me_id, 0)
                             FROM   pos_sale_temp AS fd WITH ( NOLOCK )
                             WHERE  fd.sa_id = @sa_id
                           ) > 0
                            BEGIN
                                UPDATE  pos_saleList_temp
                                SET     sal_discount = ISNULL(sal_discount_old_mem, 1)
                                WHERE   sal_sa_id = @sa_id;
                            END
                    END
		
                DECLARE @gr_discount DECIMAL(10, 2)= 0;

                SELECT  @gr_discount = pg.gr_discount
                FROM    pos_grade AS pg WITH ( NOLOCK )
                WHERE   pg.gr_id = ( SELECT pmi.me_gr_id
                                     FROM   pos_memberInfo AS pmi WITH ( NOLOCK )
                                     WHERE  pmi.me_id = @sa_me_id
                                   )
				--会员卡级别为空   
                IF ( ( SELECT   CASE WHEN pmi.me_gr_id IS NULL THEN 0
                                     ELSE pmi.me_gr_id
                                END
                       FROM     pos_memberInfo AS pmi WITH ( NOLOCK )
                       WHERE    pmi.me_id = @sa_me_id
                     ) = 0 )
                    BEGIN
                        SET @gr_discount = 1
                    END
				--会员卡级别为空
                UPDATE  pos_saleList_temp
                SET     sal_discount_old_mem = sal_discount
                WHERE   sal_sa_id = @sa_id
	
                UPDATE  pos_saleList_temp
                SET     sal_discount = 1 * @gr_discount
                WHERE   sal_sa_id = @sa_id 
	
                UPDATE  pos_saleList_temp
                SET     sal_real_price = sal_retail_price * sal_discount ,
                        sal_money = ( sal_num * ( sal_retail_price * sal_discount ) ) - sal_deduct_money
                WHERE   sal_sa_id = @sa_id
	
                UPDATE  pos_sale_temp
                SET     sa_me_id = @sa_me_id ,
                        sa_current_vo = ( SELECT    me_cu_in_num
                                          FROM      pos_memberInfo AS pmi WITH ( NOLOCK )
                                          WHERE     pmi.me_id = @sa_me_id
                                        )
                WHERE   sa_id = @sa_id;
	
                SET @result = '1';
                RETURN;
            END

        IF @op_type = '删除会员'
            BEGIN
                UPDATE  pos_saleList_temp
                SET     sal_discount = ISNULL(sal_discount_old_mem, 1)
                WHERE   sal_sa_id = @sa_id;
	
                UPDATE  pos_saleList_temp
                SET     sal_real_price = sal_retail_price * sal_discount ,
                        sal_money = ( sal_num * ( sal_retail_price * sal_discount ) ) - sal_deduct_money
                WHERE   sal_sa_id = @sa_id
	
                SET @result = '1';
                RETURN;
            END

        IF @op_type = '挂单'
            BEGIN
                UPDATE  pos_sale_temp
                SET     sa_status = 2
                WHERE   sa_id = @sa_id;

                IF @@ROWCOUNT > 0
                    BEGIN
                        SET @result = '1';
                    END
                ELSE
                    BEGIN
                        SET @result = '0';
                    END
                RETURN;
            END
	
        IF @op_type = '数据签出'
            BEGIN
                EXEC pro_sale_merge @sa_id = @sa_id, @op_type = '数据签出'
                SET @result = '1';
                RETURN;
            END	
		
        DECLARE @isInsert INT = 0; --是否添加单据
        DECLARE @need_update INT = 0; --是否需要更新单据
        DECLARE @old_order_date DATETIME;  --旧的单据日期
        DECLARE @old_order_date_is_changed INT = 0; --单据日期是否更改
        DECLARE @myprevTxt VARCHAR(50) = 'XS'; --凭证号前缀
		--事务开始
        BEGIN TRAN
 
        IF @op_type = '是否销售过'
            BEGIN
                IF @sa_me_id > 0
                    BEGIN
 						--会员
                        IF EXISTS ( SELECT  *
                                    FROM    pos_sale_temp AS ps
                                            INNER JOIN pos_saleList_temp AS psl WITH ( NOLOCK ) ON ps.sa_id = psl.sal_sa_id
                                    WHERE   ps.sa_status > 0
                                            AND psl.sal_status > 0
                                            AND psl.sal_gi_id = @sal_gi_id
                                            AND ps.sa_me_id = @sa_me_id
                                            AND psl.sal_id != @sal_id )
                            BEGIN
 								--有销售过
                                SET @result = '1';
                            END
                        ELSE
                            BEGIN
 								--没有
                                SET @result = '0';
                            END
                    END
                ELSE
                    BEGIN
 						--零售
                        IF EXISTS ( SELECT  *
                                    FROM    pos_sale_temp AS ps
                                            INNER JOIN pos_saleList_temp AS psl WITH ( NOLOCK ) ON ps.sa_id = psl.sal_sa_id
                                    WHERE   ps.sa_status > 0
                                            AND psl.sal_status > 0
                                            AND psl.sal_gi_id = @sal_gi_id
                                            AND psl.sal_id != @sal_id )
                            BEGIN
 								--有销售过
                                SET @result = '1';
                            END
                        ELSE
                            BEGIN
 								--没有
                                SET @result = '0';
                            END
                    END
 	
                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN

                RETURN 1;
            END
 
        IF @op_type = '删除活动'
            BEGIN
 				--恢复应用活动之前的数据
                UPDATE  pos_sale_temp
                SET     sa_ac_id = 0
                WHERE   sa_id = @sa_id;
 	
                UPDATE  pos_saleList_temp
                SET     sal_discount = sal_discount_old ,
                        sal_real_price = sal_real_price_old ,
                        sal_deduct_money = sal_deduct_money_old ,
                        sal_old_record = 0
                WHERE   sal_sa_id = @sa_id
                        AND sal_old_record = 1;
 	
                DELETE  FROM pos_saleList_temp
                WHERE   sal_sa_id = @sa_id
                        AND sal_is_active_gift = 1;

                SET @result = 1;
            END
 
        IF @op_type = '活动扣除金额'
            BEGIN
                DECLARE @ac_money DECIMAL(10, 2)= 0; --活动赠送金额
                DECLARE @sa_money1 DECIMAL(10, 2)= 0; --销售总金额
                DECLARE @ac_discount_rate DECIMAL(10, 2)= 0; --折扣
                DECLARE @ac_sale_price DECIMAL(10, 2)= 0; --特价
                DECLARE @ac_gift_money DECIMAL(10, 2)= 0; --赠送代金券
                DECLARE @ac_is_discount INT= 0; --折上折
                DECLARE @ac_is_gift INT= 0; --递增赠送
                DECLARE @ac_xy INT= 0; --买x件打y折 
                DECLARE @ac_biger_equal DECIMAL(10, 2)= 0; --金额满多少
                DECLARE @ac_smaller_equal INT= 0; --数量满多少

                SELECT  @ac_money = ISNULL(pa.ac_immediately_money, 0) ,
                        @ac_discount_rate = ISNULL(pa.ac_discount_rate, 0) ,
                        @ac_sale_price = ISNULL(pa.ac_sale_price, 0) ,
                        @ac_is_discount = ISNULL(pa.ac_is_discount, 0) ,
                        @ac_is_gift = ISNULL(pa.ac_is_gift, 0) ,
                        @ac_xy = ISNULL(pa.ac_xy, 0) ,
                        @ac_gift_money = ISNULL(pa.ac_gift_money, 0) ,
                        @ac_smaller_equal = ISNULL(pa.ac_smaller_equal, 0) ,
                        @ac_biger_equal = ISNULL(pa.ac_biger_equal, 0)
                FROM    pos_active AS pa WITH ( NOLOCK )
                WHERE   pa.ac_id = @sa_ac_id
 				--促销商品数量
                DECLARE @ac_goods_count INT= 0;
                SELECT  @ac_goods_count = ISNULL(COUNT(1), 0)
                FROM    pos_activeGoods AS pag
                WHERE   pag.ac_ac_id = @sa_ac_id
                        AND pag.ac_status = 1;
 	
                IF @ac_goods_count != 0
                    BEGIN
 						--判断商品
                        IF NOT EXISTS ( SELECT  *
                                        FROM    pos_saleList_temp AS fd WITH ( NOLOCK )
                                                INNER JOIN ( SELECT DISTINCT
                                                                    pag.ac_gi_id
                                                             FROM   pos_activeGoods AS pag WITH ( NOLOCK )
                                                             WHERE  pag.ac_ac_id = @sa_ac_id
                                                                    AND pag.ac_status = 1
                                                           ) AS fd2 ON fd.sal_gi_id = fd2.ac_gi_id
                                        WHERE   fd.sal_sa_id = @sa_id
                                                AND fd.sal_status = 1 )
                            BEGIN
                                SET @result = '此商品没有参与活动';
                                IF @@TRANCOUNT > 0
                                    ROLLBACK TRAN;
                                RETURN;
                            END
 						--条件
				 		--指定商品的数量,金额
                        IF @ac_smaller_equal > 0
                            BEGIN
                                PRINT '金额'
                            END
                        ELSE
                            BEGIN
                                PRINT '数量'
                            END
 		
                        PRINT 1;
                    END
 				--设置活动id
                UPDATE  pos_sale_temp
                SET     sa_ac_id = @sa_ac_id
                WHERE   sa_id = @sa_id;
 				--记录旧的数据
                IF @ac_goods_count = 0
                    BEGIN
 						--对所有商品有效
                        UPDATE  pos_saleList_temp
                        SET     sal_discount_old = sal_discount ,
                                sal_deduct_money_old = sal_deduct_money ,
                                sal_real_price_old = sal_real_price ,
                                sal_old_record = 1
                        WHERE   sal_sa_id = @sa_id
                                AND ISNULL(sal_old_record, 0) = 0
                    END
                ELSE
                    BEGIN
 						--具体商品
 						--记录旧的数据
                        UPDATE  pos_saleList_temp
                        SET     sal_discount_old = sal_discount ,
                                sal_deduct_money_old = sal_deduct_money ,
                                sal_real_price_old = sal_real_price ,
                                sal_old_record = 1
                        WHERE   sal_sa_id = @sa_id
                                AND sal_gi_id IN ( SELECT DISTINCT
                                                            pag.ac_gi_id
                                                   FROM     pos_activeGoods AS pag WITH ( NOLOCK )
                                                   WHERE    pag.ac_ac_id = @sa_ac_id
                                                            AND pag.ac_status = 1 )
                                AND ISNULL(sal_old_record, 0) = 0
                    END
 	
                DECLARE @sal_num1 INT= 0; --扣除金额
		
                SELECT  @sa_money1 = fd.sa_money1 ,
                        @sal_num1 = fd.sal_num
                FROM    vi_pos_saleList_temp_sum AS fd
                WHERE   fd.sal_sa_id = @sa_id;

                IF @ac_is_gift = 1
                    BEGIN
                        DECLARE @bei_shu INT= 0; --递增赠送

                        IF @ac_biger_equal > 0
                            BEGIN
 								--金额
                                SET @bei_shu = FLOOR(@sa_money1 / @ac_biger_equal);
                            END
                        ELSE
                            BEGIN
 								--数量
                                SET @bei_shu = FLOOR(@sa_money1 / @ac_smaller_equal);
                            END

                        SET @ac_money = @ac_money * @bei_shu;
                    END
				--添加赠送商品
                IF EXISTS ( SELECT  pag.*
                            FROM    pos_active AS pa WITH ( NOLOCK )
                                    INNER JOIN pos_activeGift AS pag WITH ( NOLOCK ) ON pa.ac_id = pag.ac_ac_id
                            WHERE   pag.ac_status = 1
                                    AND pa.ac_id = @sa_ac_id )
                    AND NOT EXISTS ( SELECT *
                                     FROM   pos_saleList_temp AS psl WITH ( NOLOCK )
                                     WHERE  psl.sal_sa_id = @sa_id
                                            AND psl.sal_is_active_gift = 1 )
                    BEGIN
                        DECLARE @sint INT= 1;
 	
                        IF @bei_shu > 0
                            BEGIN
								--递增赠送,循环添加赠送商品
                                WHILE @sint <= @bei_shu
                                    BEGIN
                                        INSERT  INTO pos_saleList_temp
                                                ( sal_sa_id ,
                                                  sal_gi_id ,
                                                  sal_num ,
                                                  sal_retail_price ,
                                                  sal_discount ,
                                                  sal_real_price ,
                                                  sal_status ,
                                                  sal_is_active_gift ,
                                                  sal_is_gift
 	                                            )
                                                SELECT  @sa_id ,
                                                        pag.ac_gi_id ,
                                                        pag.ac_num ,
                                                        pag.ac_retail_price ,
                                                        pag.ac_discount_money ,
                                                        pag.ac_retail_price ,
                                                        1 ,
                                                        1 ,
                                                        1
                                                FROM    pos_activeGift AS pag WITH ( NOLOCK )
                                                WHERE   pag.ac_ac_id = @sa_ac_id
                                                        AND pag.ac_status = 1
                                        SET @sint = @sint + 1;
                                    END
                            END
                        ELSE
                            BEGIN
                                INSERT  INTO pos_saleList_temp
                                        ( sal_sa_id ,
                                          sal_gi_id ,
                                          sal_num ,
                                          sal_retail_price ,
                                          sal_discount ,
                                          sal_real_price ,
                                          sal_status ,
                                          sal_is_active_gift ,
                                          sal_is_gift
 	                                    )
                                        SELECT  @sa_id ,
                                                pag.ac_gi_id ,
                                                pag.ac_num ,
                                                pag.ac_retail_price ,
                                                pag.ac_discount_money ,
                                                pag.ac_retail_price ,
                                                1 ,
                                                1 ,
                                                1
                                        FROM    pos_activeGift AS pag WITH ( NOLOCK )
                                        WHERE   pag.ac_ac_id = @sa_ac_id
                                                AND pag.ac_status = 1
                            END
 	
                        DECLARE @t2out DATETIME= GETDATE(); --更新赠送商品的添加时间 	
                        DECLARE @ac_sal_id INT= 0;

                        DECLARE sopcor CURSOR
                        FOR
                            ( SELECT    psl.sal_id
                              FROM      pos_saleList_temp AS psl WITH ( NOLOCK )
                              WHERE     psl.sal_sa_id = @sa_id
                                        AND psl.sal_is_active_gift = 1
                            )
                        OPEN sopcor
                        FETCH NEXT FROM sopcor INTO @ac_sal_id
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                EXEC pro_get_rand_time @t1 = @t2out, @t2out = @t2out OUT
                                UPDATE  pos_saleList_temp
                                SET     sal_add_time = @t2out
                                WHERE   sal_id = @ac_sal_id;
		
                                FETCH NEXT FROM sopcor INTO @ac_sal_id
                            END
                        CLOSE sopcor
                        DEALLOCATE sopcor
                    END
	
                IF @ac_discount_rate > 0
                    BEGIN
                        IF @ac_goods_count = 0
                            BEGIN
								--折扣
                                UPDATE  pos_saleList_temp
                                SET     sal_discount = CASE WHEN @ac_is_discount = 1 THEN sal_discount * @ac_discount_rate
                                                            ELSE @ac_discount_rate
                                                       END
                                WHERE   sal_sa_id = @sa_id;
	
                                UPDATE  pos_saleList_temp
                                SET     sal_real_price = sal_retail_price * sal_discount
                                WHERE   sal_sa_id = @sa_id;
	
                                UPDATE  pos_saleList_temp
                                SET     sal_money = ( sal_real_price * pslt.sal_num ) - pslt.sal_deduct_money
                                FROM    pos_saleList_temp AS pslt WITH ( NOLOCK )
                                WHERE   pslt.sal_sa_id = @sa_id;
			 
                            END	
                        ELSE
                            BEGIN
								--折扣
                                UPDATE  pos_saleList_temp
                                SET     sal_discount = CASE WHEN @ac_is_discount = 1 THEN sal_discount * @ac_discount_rate
                                                            ELSE @ac_discount_rate
                                                       END
                                WHERE   sal_sa_id = @sa_id
                                        AND sal_gi_id IN ( SELECT DISTINCT
                                                                    pag.ac_gi_id
                                                           FROM     pos_activeGoods AS pag WITH ( NOLOCK )
                                                           WHERE    pag.ac_ac_id = @sa_ac_id
                                                                    AND pag.ac_status = 1 )
	
                                UPDATE  pos_saleList_temp
                                SET     sal_real_price = sal_retail_price * sal_discount
                                WHERE   sal_sa_id = @sa_id
                                        AND sal_gi_id IN ( SELECT DISTINCT
                                                                    pag.ac_gi_id
                                                           FROM     pos_activeGoods AS pag WITH ( NOLOCK )
                                                           WHERE    pag.ac_ac_id = @sa_ac_id
                                                                    AND pag.ac_status = 1 )
	
                                UPDATE  pos_saleList_temp
                                SET     sal_money = ( sal_real_price * pslt.sal_num ) - pslt.sal_deduct_money
                                FROM    pos_saleList_temp AS pslt
                                WHERE   pslt.sal_sa_id = @sa_id
                                        AND pslt.sal_gi_id IN ( SELECT DISTINCT
                                                                        pag.ac_gi_id
                                                                FROM    pos_activeGoods AS pag WITH ( NOLOCK )
                                                                WHERE   pag.ac_ac_id = @sa_ac_id
                                                                        AND pag.ac_status = 1 )
                            END
                    END
                ELSE
                    IF @ac_money > 0
                        BEGIN
							--立减金额
                            IF @ac_goods_count = 0
                                BEGIN
 									--销售金额/总销售金额*立减金额=扣除金额
                                    UPDATE  pos_saleList_temp
                                    SET     sal_deduct_money = ( sal_real_price * sal_num ) / @sa_money1 * @ac_money
                                    WHERE   sal_sa_id = @sa_id;
                                END	
                            ELSE
                                BEGIN
 									--销售金额/总销售金额*立减金额=扣除金额
                                    UPDATE  pos_saleList_temp
                                    SET     sal_deduct_money = ( sal_real_price * sal_num ) / @sa_money1 * @ac_money
                                    WHERE   sal_sa_id = @sa_id
                                            AND sal_gi_id IN ( SELECT DISTINCT
                                                                        pag.ac_gi_id
                                                               FROM     pos_activeGoods AS pag WITH ( NOLOCK )
                                                               WHERE    pag.ac_ac_id = @sa_ac_id
                                                                        AND pag.ac_status = 1 )
                                END
                        END
                    ELSE
                        IF @ac_sale_price > 0
                            BEGIN
                                IF @ac_goods_count = 0
                                    BEGIN
										--特价
                                        UPDATE  pos_saleList_temp
                                        SET     sal_real_price = @ac_sale_price
                                        WHERE   sal_sa_id = @sa_id;	
		
                                        UPDATE  pos_saleList_temp
                                        SET     sal_discount = ROUND(@ac_sale_price / sal_retail_price, 2)
                                        WHERE   sal_sa_id = @sa_id;	
			
                                    END
                                ELSE
                                    BEGIN
										--特价
                                        UPDATE  pos_saleList_temp
                                        SET     sal_real_price = @ac_sale_price
                                        WHERE   sal_sa_id = @sa_id
                                                AND sal_gi_id IN ( SELECT DISTINCT
                                                                            pag.ac_gi_id
                                                                   FROM     pos_activeGoods AS pag WITH ( NOLOCK )
                                                                   WHERE    pag.ac_ac_id = @sa_ac_id
                                                                            AND pag.ac_status = 1 )
		
                                        UPDATE  pos_saleList_temp
                                        SET     sal_discount = ROUND(@ac_sale_price / sal_retail_price, 2)
                                        WHERE   sal_sa_id = @sa_id
                                                AND sal_gi_id IN ( SELECT DISTINCT
                                                                            pag.ac_gi_id
                                                                   FROM     pos_activeGoods AS pag WITH ( NOLOCK )
                                                                   WHERE    pag.ac_ac_id = @sa_ac_id
                                                                            AND pag.ac_status = 1 )
                                    END
                            END
                        ELSE
                            IF @ac_gift_money > 0
                                BEGIN
									--赠送代金券
                                    PRINT '未做'
                                END

                IF @@ERROR <> 0
                    BEGIN
                        SET @result = '0';
                        IF @@TRANCOUNT > 0
                            ROLLBACK TRAN;
                    END
                ELSE
                    BEGIN
                        SET @result = '1';
                        IF @@TRANCOUNT > 0
                            COMMIT TRAN;
                    END

                RETURN;
            END
 
        IF @op_type = '退换货'
            BEGIN
                IF EXISTS ( SELECT  *
                            FROM    pos_sale AS ps WITH ( NOLOCK )
                            WHERE   ps.sa_vo = @sal_remark
                                    AND ps.sa_status > 0 )
                    BEGIN
                        DECLARE @first_id INT= 0;
 						--游标方式生成销售单
                        DECLARE sopcor CURSOR
                        FOR
                            ( SELECT    ps.sa_sh_id ,
                                        ps.sa_co_man ,
                                        ps.sa_date ,
                                        ps.sa_ac_id ,
                                        ps.sa_order_man ,
                                        ps.sa_st_id ,
                                        ps.sa_me_id ,
                                        ps.sa_remark ,
                                        ps.sa_in_id ,
                                        ps.sa_in_num ,
                                        ps.sa_get_in_num ,
                                        ps.sa_deduct_money ,
                                        ps.sa_sa_vo ,
                                        ps.sa_gift_vo ,
                                        ps.sa_in_money ,
                                        ps.sa_card_money ,
                                        ps.sa_shop_money ,
                                        ps.sa_money ,
                                        ps.sa_real_money ,
                                        ps.sa_charge_money ,
                                        ps.sa_surplus_money ,
                                        ps.sa_select ,
                                        ps.sa_sale_money ,
                                        ps.sa_change_money ,
                                        ps.sa_gift_money ,
                                        ps.sa_current_vo ,
                                        ps.sa_is_charge ,
                                        psl.sal_gi_id ,
                                        psl.sal_sku_id ,
                                        psl.sal_num ,
                                        psl.sal_retail_price ,
                                        psl.sal_discount ,
                                        psl.sal_list_man ,
                                        psl.sal_real_price ,
                                        psl.sal_money ,
                                        psl.sal_deduct_money ,
                                        psl.sal_is_gift ,
                                        psl.sal_is_change ,
                                        psl.sal_is_in ,
                                        psl.sal_in_num ,
                                        psl.sal_remark ,
                                        psl.sal_is_return ,
                                        psl.sal_add_time ,
                                        psl.sal_remark2 ,
                                        psl.sal_st_id ,
                                        ps.sa_paytype ,
                                        sal_is_zhengjia ,
                                        sal_is_tejia
                              FROM      pos_sale AS ps WITH ( NOLOCK )
                                        INNER JOIN pos_saleList AS psl WITH ( NOLOCK ) ON ps.sa_id = psl.sal_sa_id
                              WHERE     ps.sa_vo = @sal_remark
                                        AND psl.sal_status = 1
                            )
                        OPEN sopcor
                        DECLARE @now DATETIME;
                        DECLARE @prev_now DATETIME;
                        DECLARE @old_sal_add_time DATETIME= '2014-12-17';

                        SET @now = GETDATE();
                        FETCH NEXT FROM sopcor INTO @sa_sh_id, @sa_co_man, @sa_date, @sa_ac_id, @sa_order_man, @sa_st_id, @sa_me_id, @sa_remark, @sa_in_id,
                            @sa_in_num, @sa_get_in_num, @sa_deduct_money, @sa_sa_vo, @sa_gift_vo, @sa_in_money, @sa_card_money, @sa_shop_money, @sa_money,
                            @sa_real_money, @sa_charge_money, @sa_surplus_money, @sa_select, @sa_sale_money, @sa_change_money, @sa_gift_money, @sa_current_vo,
                            @sa_is_charge, @sal_gi_id, @sal_sku_id, @sal_num, @sal_retail_price, @sal_discount, @sal_list_man, @sal_real_price, @sal_money,
                            @sal_deduct_money, @sal_is_gift, @sal_is_change, @sal_is_in, @sal_in_num, @sal_remark, @sal_is_return, @sal_add_time, @sal_remark2,
                            @sal_st_id, @sa_paytype, @sal_is_zhengjia, @sal_is_tejia
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                IF @old_sal_add_time != @sal_add_time
                                    BEGIN
                                        SET @old_sal_add_time = @sal_add_time;
                                        SET @now = GETDATE();
                                        WHILE 1 = 1
                                            BEGIN
                                                IF @prev_now = @now
                                                    BEGIN
                                                        SET @now = GETDATE();
                                                    END
                                                ELSE
                                                    BEGIN
                                                        BREAK;
                                                    END
                                            END
                                    END
			
                                EXEC pro_pos_sale_temp_op
                                    @sal_sa_id = @first_id, @sal_gi_id = @sal_gi_id, @sal_sku_id = @sal_sku_id, @sal_num = @sal_num,
                                    @sal_retail_price = @sal_retail_price, @sal_discount = @sal_discount, @sal_list_man = @sal_list_man,
                                    @sal_real_price = @sal_real_price, @sal_money = @sal_money, @sal_deduct_money = @sal_deduct_money,
                                    @sal_is_gift = @sal_is_gift, @sal_is_change = @sal_is_change, @sal_is_in = @sal_is_in, @sal_in_num = @sal_in_num,
                                    @sal_is_return = @sal_is_return, @sal_is_zhengjia = @sal_is_zhengjia, @sal_is_tejia = @sal_is_tejia,
                                    @sal_remark = @sal_remark, @sal_remark2 = @sal_remark2, @sal_st_id = @sal_st_id, @sal_add_time = @now, @sa_id = @first_id,
                                    @sa_sh_id = @sa_sh_id, @sa_co_man = @sa_co_man,
                                    @sa_date = @sa_date, @sa_no = @sa_no, @sa_ac_id = @sa_ac_id, @sa_order_man = @sa_order_man, @sa_st_id = @sa_st_id,
                                    @sa_update_man = @sa_update_man, @sa_update_time = @sa_update_time, @sa_add_man = @sa_add_man, @sa_add_time = @sa_add_time,
                                    @sa_type = @sa_type, @sa_sa_type = @sa_sa_type, @sa_me_id = @sa_me_id, @sa_remark = @sa_remark, @sa_in_id = @sa_in_id,
                                    @sa_in_num = @sa_in_num, @sa_get_in_num = @sa_get_in_num, @sa_deduct_money = @sa_deduct_money, @sa_sa_vo = @sa_sa_vo,
                                    @sa_gift_vo = @sa_gift_vo, @sa_in_money = @sa_in_money, @sa_card_money = @sa_card_money, @sa_shop_money = @sa_shop_money,
                                    @sa_money = @sa_money, @sa_real_money = @sa_real_money, @sa_charge_money = @sa_charge_money,
                                    @sa_surplus_money = @sa_surplus_money, @sa_select = @sa_select, @sa_audit_man = @sa_audit_man,
                                    @sa_audit_time = @sa_audit_time, @sa_sale_money = @sa_sale_money, @sa_change_money = @sa_change_money,
                                    @sa_gift_money = @sa_gift_money, @sa_current_vo = @sa_current_vo, @sa_is_charge = @sa_is_charge, @sa_paytype = @sa_paytype,
                                    @op_type = '添加修改单据,明细', @result = @result OUT
				
                                SET @prev_now = @now;
				
                                IF @first_id = 0
                                    BEGIN
                                        SET @first_id = CONVERT(INT, @result);
                                    END
				
                                FETCH NEXT FROM sopcor INTO @sa_sh_id, @sa_co_man, @sa_date, @sa_ac_id, @sa_order_man, @sa_st_id, @sa_me_id, @sa_remark,
                                    @sa_in_id, @sa_in_num, @sa_get_in_num, @sa_deduct_money, @sa_sa_vo, @sa_gift_vo, @sa_in_money, @sa_card_money,
                                    @sa_shop_money, @sa_money, @sa_real_money, @sa_charge_money, @sa_surplus_money, @sa_select, @sa_sale_money, @sa_change_money,
                                    @sa_gift_money, @sa_current_vo, @sa_is_charge, @sal_gi_id, @sal_sku_id, @sal_num, @sal_retail_price, @sal_discount,
                                    @sal_list_man, @sal_real_price, @sal_money, @sal_deduct_money, @sal_is_gift, @sal_is_change, @sal_is_in, @sal_in_num,
                                    @sal_remark, @sal_is_return, @sal_add_time, @sal_remark2, @sal_st_id, @sa_paytype, @sal_is_zhengjia, @sal_is_tejia
                            END
                        CLOSE sopcor
                        DEALLOCATE sopcor
 		
                        IF @@ERROR <> 0
                            BEGIN
                                SET @result = '操作失败!';

                                IF @@TRANCOUNT > 0
                                    ROLLBACK TRAN;

                                RETURN 1;
                            END
                        ELSE
                            BEGIN
                                SET @result = CONVERT(VARCHAR(50), @first_id);

                                IF @@TRANCOUNT > 0
                                    COMMIT TRAN;

                                RETURN 1;
                            END
                    END
                ELSE
                    BEGIN
                        SET @result = '凭证号不存在!';

                        IF @@TRANCOUNT > 0
                            ROLLBACK TRAN;

                        RETURN 0;
                    END
            END
 
        IF @op_type = '是否结算'
            BEGIN
                DECLARE @max_sa_date DATETIME;
                DECLARE @sar_type_var VARCHAR(50)= '';

                SELECT TOP 1
                        @sar_type_var = ISNULL(psr.sar_type, '')
                FROM    pos_sale_record AS psr WITH ( NOLOCK )
                WHERE   CONVERT(VARCHAR(50), psr.sar_date, 23) = CONVERT(VARCHAR(50), @sa_date, 23)
                        AND psr.sar_sh_id = @sa_sh_id
                ORDER BY psr.sar_id DESC;
 	
                IF @sar_type_var = ''
                    OR @sar_type_var = '反结算'
                    BEGIN
 						--检查上一个日期是否结算
                        SELECT TOP 1
                                @sar_type_var = psr.sar_type
                        FROM    pos_sale_record AS psr WITH ( NOLOCK )
                        WHERE   CONVERT(VARCHAR(50), psr.sar_date, 23) = CONVERT(VARCHAR(50), DATEADD(day, -1, @sa_date), 23)
                                AND psr.sar_sh_id = @sa_sh_id
                        ORDER BY psr.sar_id DESC;

                        IF @sar_type_var = ''
                            OR @sar_type_var = '反结算'
                            BEGIN
                                SET @result = '该日期的前一天未结算利润，无法输入';
                            END
                        ELSE
                            BEGIN
                                SET @result = '1';
                            END
                    END
                ELSE
                    BEGIN
 						--当前已结算
                        SET @result = '该日期已结算利润，无法输入'
                    END

                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN;
                RETURN 1;
            END

        DECLARE @tdoc_xml VARCHAR(100)= '';

        IF @op_type = '结算'
            BEGIN
                UPDATE  pos_sale_temp
                SET     sa_is_calculated = 1
                WHERE   sa_date = @sa_date
                        AND sa_sh_id = @sa_sh_id;

                INSERT  INTO pos_sale_record
                        ( sar_type ,
                          sar_date ,
                          sar_add_time ,
                          sar_add_man ,
                          sar_sh_id
 	                    )
                VALUES  ( '结算' ,
                          @sa_date ,
                          GETDATE() ,
                          @sa_add_man ,
                          @sa_sh_id
 	                    )

                UPDATE  pos_sale
                SET     sa_status = 3
                WHERE   sa_date = @sa_date
                        AND sa_status != 0
						AND sa_sh_id = @sa_sh_id;

				--入队
                SELECT  @sal_erp_id = ps.sh_erp_id
                FROM    pos_shop ps
                WHERE   ps.sh_id = @sa_sh_id
                SET @tdoc_xml = '{"type":"Settlement", "sh_id":"' + CONVERT(VARCHAR(50), @sa_sh_id) + '","sa_date":"' + CONVERT(VARCHAR(100), @sa_date, 23)
                    + '"}';
                EXEC pro_apiqueue_op @tdoc_method = 'PosSettlement', @tdoc_xml = @tdoc_xml, @tdoc_erp_id = @sal_erp_id, @tdoc_state = 0;	
            END
 
        IF @op_type = '反结算'
            BEGIN
                UPDATE  pos_sale_temp
                SET     sa_is_calculated = 0
                WHERE   sa_date = @sa_date
                        AND sa_sh_id = @sa_sh_id;

                INSERT  INTO pos_sale_record
                        ( sar_type ,
                          sar_date ,
                          sar_add_time ,
                          sar_add_man ,
                          sar_sh_id
 	                    )
                VALUES  ( '反结算' ,
                          @sa_date ,
                          GETDATE() ,
                          @sa_add_man ,
                          @sa_sh_id
 	                    )

                UPDATE  pos_sale
                SET     sa_status = 1
                WHERE   sa_date = @sa_date
                        AND sa_status = 3
						AND sa_sh_id = @sa_sh_id;

				--入队
                SELECT  @sal_erp_id = ps.sh_erp_id
                FROM    pos_shop ps
                WHERE   ps.sh_id = @sa_sh_id
                SET @tdoc_xml = '{"type":"CounterSettlement", "sh_id":"' + CONVERT(VARCHAR(50), @sa_sh_id) + '","sa_date":"' + CONVERT(VARCHAR(100), @sa_date, 23)
                    + '"}';
                EXEC pro_apiqueue_op @tdoc_method = 'PosSettlement', @tdoc_xml = @tdoc_xml, @tdoc_erp_id = @sal_erp_id, @tdoc_state = 0;	
            END
 
        IF @op_type = '添加修改单据,明细'
            BEGIN
                IF @sal_is_return = 0
                    AND @sal_is_change = 0
                    BEGIN
                        SET @sal_num = ABS(@sal_num);
                        SET @sal_money = ABS(@sal_money);
                    END
	
                IF @sa_id = 0
                    BEGIN
						--添加单据
                        INSERT  INTO pos_sale_temp
                                ( sa_sh_id ,
                                  sa_co_man ,
                                  sa_date ,
                                  sa_no ,
                                  sa_vo ,
                                  sa_ac_id ,
                                  sa_order_man ,
                                  sa_st_id ,
                                  sa_update_man ,
                                  sa_update_time ,
                                  sa_add_man ,
                                  sa_add_time ,
                                  sa_status ,
                                  sa_type ,
                                  sa_sa_type ,
                                  sa_me_id ,
                                  sa_remark ,
                                  sa_in_id ,
                                  sa_in_num ,
                                  sa_get_in_num ,
                                  sa_deduct_money ,
                                  sa_sa_vo ,
                                  sa_gift_vo ,
                                  sa_in_money ,
                                  sa_card_money ,
                                  sa_shop_money ,
                                  sa_money ,
                                  sa_real_money ,
                                  sa_charge_money ,
                                  sa_surplus_money ,
                                  sa_select ,
                                  sa_sale_money ,
                                  sa_change_money ,
                                  sa_gift_money ,
                                  sa_current_vo ,
                                  sa_is_charge ,
                                  sa_is_calculated ,
                                  sa_paytype ,
                                  sa_erp_id,
								  sa_salman,
	                              sa_salmanname
                                )
                        VALUES  ( @sa_sh_id ,
                                  @sa_co_man ,
                                  @sa_date ,
                                  @sa_no ,
                                  NEWID() ,
                                  @sa_ac_id ,
                                  @sa_order_man ,
                                  @sa_st_id ,
                                  @sa_update_man ,
                                  @sa_update_time ,
                                  @sa_add_man ,
                                  @sa_add_time ,
                                  0 ,
                                  @sa_type ,
                                  @sa_sa_type ,
                                  @sa_me_id ,
                                  @sa_remark ,
                                  @sa_in_id ,
                                  @sa_in_num ,
                                  @sa_get_in_num ,
                                  @sa_deduct_money ,
                                  @sa_sa_vo ,
                                  @sa_gift_vo ,
                                  @sa_in_money ,
                                  @sa_card_money ,
                                  @sa_shop_money ,
                                  @sa_money ,
                                  @sa_real_money ,
                                  @sa_charge_money ,
                                  @sa_surplus_money ,
                                  @sa_select ,
                                  @sa_sale_money ,
                                  @sa_change_money ,
                                  @sa_gift_money ,
                                  @sa_current_vo ,
                                  @sa_is_charge ,
                                  0 ,
                                  @sa_paytype ,
                                  @erp_id,
								  @sa_salman,
	                              @sa_salmanname
                                );
                        SET @sa_id = SCOPE_IDENTITY();
 
                        SET @sal_sa_id = @sa_id;
                        SET @isInsert = 1;
                    END
                ELSE
                    BEGIN
                        SET @need_update = 1;
                    END

                IF EXISTS ( SELECT  *
                            FROM    pos_saleList_temp AS jt WITH ( NOLOCK )
                            WHERE   jt.sal_sa_id = @sa_id
                                    AND jt.sal_status = 1
                                    AND jt.sal_add_time = @sal_add_time
                                    AND jt.sal_gi_id != @sal_gi_id )
                    BEGIN
                        UPDATE  pos_saleList_temp
                        SET     sal_status = 0
                        WHERE   sal_sa_id = @sa_id
                                AND sal_add_time = @sal_add_time
                                AND sal_status = 1
                                AND sal_gi_id != @sal_gi_id;
                    END

                IF @sal_id = 0
                    BEGIN
                        INSERT  INTO pos_saleList_temp
                                ( sal_sa_id ,
                                  sal_gi_id ,
                                  sal_sku_id ,
                                  sal_num ,
                                  sal_retail_price ,
                                  sal_discount ,
                                  sal_list_man ,
                                  sal_real_price ,
                                  sal_money ,
                                  sal_deduct_money ,
                                  sal_is_gift ,
                                  sal_is_change ,
                                  sal_is_in ,
                                  sal_in_num ,
                                  sal_remark ,
                                  sal_status ,
                                  sal_add_time ,
                                  sal_is_return ,
                                  sal_remark2 ,
                                  sal_st_id ,
                                  sal_is_tejia ,
                                  sal_is_zhengjia ,
                                  sal_erp_id,
								  sal_paidmomey,
								  sal_customprice,
								  sal_deduction
                                )
                        VALUES  ( @sal_sa_id ,
                                  @sal_gi_id ,
                                  @sal_sku_id ,
                                  @sal_num ,
                                  @sal_retail_price ,
                                  @sal_discount ,
                                  @sal_list_man ,
                                  @sal_real_price ,
                                  @sal_money ,
                                  @sal_deduct_money ,
                                  @sal_is_gift ,
                                  @sal_is_change ,
                                  @sal_is_in ,
                                  @sal_in_num ,
                                  @sal_remark ,
                                  1 ,
                                  @sal_add_time ,
                                  @sal_is_return ,
                                  @sal_remark2 ,
                                  @sal_st_id ,
                                  @sal_is_tejia ,
                                  @sal_is_zhengjia ,
                                  @erp_id,
								  @sal_real_price*@sal_num,
								  @sal_customprice,
								  @sal_deduction
                                );
                        SET @sal_id = SCOPE_IDENTITY();
                    END
                ELSE
                    BEGIN
                        UPDATE  pos_saleList_temp
                        SET     --sal_sa_id=@sal_sa_id,
                                sal_gi_id = @sal_gi_id ,
                                sal_sku_id = @sal_sku_id ,
                                sal_num = @sal_num ,
                                sal_retail_price = @sal_retail_price ,
                                sal_discount = @sal_discount ,
                                sal_list_man = @sal_list_man ,
                                sal_real_price = @sal_real_price ,
                                sal_money = @sal_money ,
                                sal_deduct_money = @sal_deduct_money ,
                                sal_is_gift = @sal_is_gift ,
                                sal_is_change = @sal_is_change ,
                                sal_is_in = @sal_is_in ,
                                sal_in_num = @sal_in_num ,
                                sal_remark = @sal_remark ,
                                sal_is_return = @sal_is_return ,
                                sal_remark2 = @sal_remark2 ,
                                sal_st_id = @sal_st_id ,
                                sal_is_tejia = @sal_is_tejia ,
                                sal_is_zhengjia = @sal_is_zhengjia,
								sal_paidmomey=@sal_real_price*@sal_num,
								sal_customprice=@sal_customprice,
								sal_deduction=@sal_deduction
                        WHERE   sal_id = @sal_id;
                    END
            END

        IF @op_type = '审核单据'
            BEGIN
				--审核单据
                SELECT  @sa_st_id = sa_st_id
                FROM    pos_sale_temp WITH ( NOLOCK )
                WHERE   sa_id = @sa_id;--得到仓库id

                UPDATE  pos_sale_temp
                SET     sa_status = 2 ,
                        sa_audit_man = @sa_update_man ,
                        sa_audit_time = GETDATE()
                WHERE   sa_id = @sa_id;
            END

        IF @op_type = '取消审核单据'
            BEGIN
				--取消审核单据
                SELECT  @sa_st_id = sa_st_id
                FROM    pos_sale_temp WITH ( NOLOCK )
                WHERE   sa_id = @sa_id;--得到仓库id

                UPDATE  pos_sale_temp
                SET     sa_status = 1
                WHERE   sa_id = @sa_id;
            END
 
        IF @op_type = '删除单据'
            BEGIN
				--删除单据
                SELECT  @sa_st_id = sa_st_id
                FROM    pos_sale_temp WITH ( NOLOCK )
                WHERE   sa_id = @sa_id;--得到仓库id

                UPDATE  pos_sale_temp
                SET     sa_status = 0
                WHERE   sa_id = @sa_id;
            END
 
        IF @op_type = '删除明细'
            BEGIN
				--删除明细
                UPDATE  pos_saleList_temp
                SET     sal_status = 0
                WHERE   sal_id = @sal_id;
            END

        IF @op_type = '批量删除明细'
            BEGIN
                UPDATE  pos_saleList_temp
                SET     sal_status = 0
                WHERE   sal_sa_id = @sal_sa_id
                        AND sal_add_time = @sal_add_time
                        AND sal_gi_id = @sal_gi_id;
            END

        IF @op_type = '添加修改单据,明细'
            OR @need_update = 1
            OR @op_type = '修改单据'
            BEGIN
				--得到旧的单据日期
                SELECT  @old_order_date = jt.sa_date
                FROM    pos_sale_temp AS jt
                WHERE   jt.sa_id = @sa_id;

                IF @old_order_date != @sa_date
                    BEGIN
                        SET @old_order_date_is_changed = 1;
                    END
  
                UPDATE  pos_sale_temp
                SET     sa_sh_id = @sa_sh_id ,
                        sa_co_man = @sa_co_man ,
                        sa_date = @sa_date ,
                        sa_no = @sa_no ,
                        sa_ac_id = @sa_ac_id ,
                        sa_order_man = @sa_order_man ,
                        sa_st_id = @sa_st_id ,
                        sa_update_man = @sa_update_man ,
                        sa_update_time = @sa_update_time ,
                        sa_type = @sa_type ,
                        sa_sa_type = @sa_sa_type ,
                        sa_me_id = @sa_me_id ,
                        sa_remark = @sa_remark ,
                        sa_in_id = @sa_in_id ,
                        sa_in_num = @sa_in_num ,
                        sa_get_in_num = @sa_get_in_num ,
                        sa_deduct_money = @sa_deduct_money ,
                        sa_sa_vo = @sa_sa_vo ,
                        sa_gift_vo = @sa_gift_vo ,
                        sa_in_money = @sa_in_money ,
                        sa_card_money = @sa_card_money ,
                        sa_shop_money = @sa_shop_money ,
                        sa_money = @sa_money ,
                        sa_real_money = @sa_real_money ,
                        sa_charge_money = @sa_charge_money ,
                        sa_surplus_money = @sa_surplus_money ,
                        sa_select = @sa_select ,
                        sa_sale_money = @sa_sale_money ,
                        sa_change_money = @sa_change_money ,
                        sa_gift_money = @sa_gift_money ,
                        sa_current_vo = @sa_current_vo ,
                        sa_is_charge = @sa_is_charge ,
                        sa_paytype = @sa_paytype,
						sa_salman=@sa_salman,
	                    sa_salmanname= @sa_salmanname
                WHERE   sa_id = @sa_id;
  
                IF @op_type = '修改单据'
                    BEGIN
                        UPDATE  pos_sale_temp
                        SET     sa_status = 1
                        WHERE   sa_id = @sa_id;

                        DECLARE @old_sa_me_id INT= 0;	
                        IF EXISTS ( SELECT  *
                                    FROM    pos_sale AS ps WITH ( NOLOCK )
                                    WHERE   ps.sa_id = @sa_id )
                            BEGIN
                                IF ( SELECT ISNULL(ps.sa_me_id, 0)
                                     FROM   pos_sale AS ps WITH ( NOLOCK )
                                     WHERE  ps.sa_id = @sa_id
                                   ) > 0
                                    BEGIN
 		
                                        SELECT  @old_sa_me_id = ps.sa_me_id
                                        FROM    pos_sale AS ps
                                        WHERE   ps.sa_id = @sa_id
 		 
                                    END
                            END
  						--数据签入
                        EXEC pro_sale_merge @sa_id = @sa_id, @op_type = '数据签入'
  						--重算会员积分	
                        EXEC pro_recount_member @sa_id = @sa_id	
  		
                        IF @old_sa_me_id > 0
                            BEGIN
  								--重算会员积分	
                                EXEC pro_recount_member @sa_id = 0, @sa_me_id = @old_sa_me_id
                            END
                    END
            END

        IF @op_type = '销售数据签入'
            BEGIN
                DECLARE @me_id INT= 0;	

                IF EXISTS ( SELECT  *
                            FROM    pos_sale AS ps WITH ( NOLOCK )
                            WHERE   ps.sa_id = @sa_id )
                    BEGIN
                        IF ( SELECT ISNULL(ps.sa_me_id, 0)
                             FROM   pos_sale AS ps WITH ( NOLOCK )
                             WHERE  ps.sa_id = @sa_id
                           ) > 0
                            BEGIN
                                SELECT  @me_id = ps.sa_me_id
                                FROM    pos_sale AS ps
                                WHERE   ps.sa_id = @sa_id
                            END
                    END	
			 	--数据签入
                EXEC pro_sale_merge @sa_id = @sa_id, @op_type = '数据签入'
            END	

        IF @isInsert = 1
    --or @old_order_date_is_changed = 1
            BEGIN
		     --凭证号生成
				--更新凭证号 
                DECLARE @tableName VARCHAR(50) = 'pos_sale_temp'
                DECLARE @idField VARCHAR(50) = 'sa_id'
                DECLARE @idValue INT = @sa_id;
                DECLARE @dateField VARCHAR(50) = 'sa_date'
                DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @sa_date, 23)
                DECLARE @noField VARCHAR(50) = 'sa_vo'
                DECLARE @prevTxt VARCHAR(50) = @myprevTxt
                DECLARE @outno VARCHAR(100) = ''
                DECLARE @while INT = 0;

                WHILE @while = 0
                    BEGIN
				         --得到凭证号
                        EXECUTE [pro_gen_orderNo] @tableName, @idField, @idValue, @dateField, @dateValue, @noField, @prevTxt, @outno OUTPUT, @sa_sh_id
         
                        BEGIN TRY
							--更新
                            UPDATE  pos_sale_temp
                            SET     sa_vo = @outno ,
                                    pzone = dbo.Get_StrArrayStrOfIndex(@outno, '-', 1) ,
                                    pztwo = dbo.Get_StrArrayStrOfIndex(@outno, '-', 2) ,
                                    pzthree = dbo.Get_StrArrayStrOfIndex(@outno, '-', 3)
                            WHERE   sa_id = @sa_id;
				            --更新成功,赋值,结束循环
                            SET @while = 1;
                        END TRY
                        BEGIN CATCH
                            PRINT '';
							  ----发生错误,判断错误类型
							  --if charindex('重复键', error_message(), 0) = 0
							  --begin
							  --    --不是发生重复的错误
							  --    --赋值,结束循环
							  --    set @while = 1;
							  --end
                        END CATCH
                    END
            END

        IF @op_type = '销售数据签入'
            OR @op_type = '修改单据'
            BEGIN
                IF ISNULL(@sa_id, 0) = 0
                    BEGIN
                        RAISERROR ('库存更新错误,单据id为0',16,1,N'number',5);

                        SET @result = '0';

                        IF @@TRANCOUNT > 0
                            ROLLBACK TRAN;

                        RETURN 0;
                    END

                EXEC [dbo].[pro_pos_mergeStockLog_pos_sale] @tsl_sh_id = @sa_sh_id, @negative_inventory = @negative_inventory, @old_sei_id = 0,
                    @new_sei_id = @sa_st_id, @id = @sa_id  

                IF @@ERROR <> 0
                    BEGIN
                        SET @result = '0';

                        IF @@TRANCOUNT > 0
                            ROLLBACK TRAN;

                        RETURN 0;
                    END
            END

        IF @@ERROR <> 0
            BEGIN				
				--生成单据异常，回滚操作
               theRollback:

                SET @result = '0';

                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN;
            END
        ELSE
            BEGIN
                IF @isInsert = 1
                    SET @result = CONVERT(VARCHAR(50), @sa_id);
                ELSE
                    BEGIN
                        IF @op_type = '添加修改单据,明细'
                            SET @result = CONVERT(VARCHAR(50), @sal_id);
                        ELSE
                            SET @result = '1';
                    END

                IF @@TRANCOUNT > 0
                    COMMIT TRAN;
            END
  
    END
go

