CREATE  VIEW [dbo].[v_z_pos_plStorage_detail]
	AS 

select 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
plSlist.*
from 
(
	
select
isnull(grl.gss_no,'') as gss_no,--规格编码,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
plS.*

from
(
SELECT 
plStorag.*,
ps.sh_company,
ps.sh_id,
ps.sh_erp_id as erp_id,
ps.sh_name,
gi.gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
ui.ut_name,--单位
ui.ut_name as gi_unit,       --单位 
sg.sei_name as pl_st_id_txt   --仓库  
                                           
FROM
(
SELECT 
pps.pl_vo,--凭证号
pps.pl_no,--单据号
pps.pl_add_time, --单据添加时间
pps.pl_update_time, --单据修改时间
pps.pl_audit_time, --单据审核时间
CONVERT (VARCHAR(10), pps.pl_date, 120) AS pl_date,--盈亏日期

isnull(ppsl.ppl_retail_price,0) as ppl_retail_price, --零售价         
isnull(ppsl.ppl_stock_price,0) as ppl_stock_price,  --进货价        
isnull(ppsl.ppl_num,0) as ppl_num,    --数量
isnull(ppsl.ppl_stock_num,0) as ppl_stock_num,
isnull(ppsl.ppl_money,0) as ppl_money, --金额

ppsl.ppl_add_time, --商品添加时间                                                   --
pl_order_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_order_man ),--经手人
pl_add_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_add_man ) ,--单据添加人
pl_update_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_update_man ),--单据修改人
pl_audit_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_audit_man ),--单据审核人
pps.pl_audit_man,
pps.pl_add_man,
pps.pl_order_man,
pps.pl_update_man,
pps.pl_id,
pps.pl_st_id,
pps.pl_sh_id,
pps.pl_remark, --备注
pps.pl_status,--单据状态
ppsl.ppl_gi_id,
ppsl.ppl_sku_id
FROM pos_plStorage pps
INNER JOIN pos_plStorageList ppsl 
ON ppsl.ppl_pl_id=pps.pl_id 
AND ppsl.ppl_status=1 
AND pps.pl_status>0

UNION ALL

SELECT
psl.sl_order_no,--凭证号
'',--单据号
jt.tsl_add_time,--单据添加时间
psl.sl_updatetime,--单据修改时间
jt.tsl_update_time,--单据审核时间
CONVERT (VARCHAR(10),psl.sl_order_date, 120) AS sl_order_date, --盈亏日期

isnull(bg.gi_retailprice,0) as gi_retailprice,--零售价   
isnull((CASE WHEN sl_skuid=0 THEN gi_purchase ELSE gs_purchase END ),0) AS  gs_purchase,--进货价
isnull((Case when sl_counttype=1 Then sl_number Else -sl_number END),0) AS ppl_num,--数量
 0,                             
isnull((CASE WHEN sl_skuid=0 THEN(gi_purchase* (Case when sl_counttype=1 Then sl_number Else -sl_number End)) ELSE 
(gs_purchase* (Case when sl_counttype=1 Then sl_number Else -sl_number End))END ),0) as menoy, --金额

psl.sl_addtime,
pl_order_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = tsl_add_man ),--经手人
pl_add_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = tsl_add_man ) ,--单据添加人
pl_update_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = tsl_update_man ),--单据修改人
pl_audit_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = tsl_update_man ),--单据审核人
jt.tsl_update_man,
jt.tsl_add_man,
jt.tsl_update_man,
jt.tsl_update_man,
jt.tsl_id,
jt.tsl_st_id,
jt.tsl_sh_id,
jt.tsl_remark, --备注
jt.tsl_status,--单据状态
psl.sl_giid,
psl.sl_skuid
FROM pos_stocklog_pal AS psl
LEFT JOIN pos_takeStorageLog jt  ON psl.sl_elid=jt.tsl_id AND psl.sl_eoid=jt.tsl_id AND jt.tsl_status<>0
LEFT JOIN b_goodsinfo AS bg ON psl.sl_giid=bg.gi_id
LEFT JOIN b_goodsruleset AS bg2 ON bg2.gss_id=sl_skuid
WHERE (sl_type=7 OR sl_type=8 OR sl_type=9 OR sl_type=10) AND sl_number!=0

) AS plStorag
inner join b_goodsinfo gi on gi.gi_id=plStorag.ppl_gi_id and gi_status=1
inner join b_unit ui on ui.ut_id=gi.gi_unit 
inner join pos_storageInfo sg on sg.sei_id=plStorag.pl_st_id
inner join pos_shop ps on ps.sh_id=plStorag.pl_sh_id


) AS pls


left join b_goodsruleset  as grl on  grl.gss_id=pls.ppl_sku_id

) as plSlist
left join s_goodsruledetail rulenum on gd_id=plSlist.size


go

