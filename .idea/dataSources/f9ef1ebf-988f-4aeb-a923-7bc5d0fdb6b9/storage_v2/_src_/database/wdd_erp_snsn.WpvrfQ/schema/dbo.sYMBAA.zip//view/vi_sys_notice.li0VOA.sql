
CREATE VIEW [dbo].[vi_sys_notice] AS 
Select sn.*,bs.si_name As name
  From sys_notice sn 
  LEFT Join b_stafftinfo bs On sn.sn_userid=bs.si_id

go

