CREATE VIEW [dbo].[vi_pos_inStorage_audit_se] AS 
SELECT     isnull(p.inl_num_ed,0) AS inl_num_ed , p.inl_num, p.inl_money, jis.in_id, jis.in_vo, CONVERT(VARCHAR(10), jis.in_date, 120) AS in_date, jis.in_no, jis.in_st_id, jis.in_shop_id, jis.in_type, jis.in_supplier, jis.in_supplier_id, 
                      jis.in_man,
                          (SELECT    TOP 1 ord_no
                            FROM          dbo.pos_inStorage
                            WHERE      (
                            	
                            in_source_id= jis.in_id
                            )) AS ord_no, 
							
							(CASE WHEN in_type = 1 THEN
                          (SELECT     cp_simplename
                            FROM          dbo.companyinfo
                            WHERE       cp_erp_id =in_erp_id AND cp_is_zorf=1) ELSE
                          (SELECT     sh_name
                            FROM          dbo.pos_shop
                            WHERE      (sh_id = jis.in_supplier_id)) END) AS in_supplier_id_txt,
							              (CASE WHEN in_type = 1 THEN
                          (SELECT     cp_code
                            FROM          dbo.companyinfo
                            WHERE       cp_erp_id =in_erp_id AND cp_is_zorf=1) ELSE
                          (SELECT     sh_no
                            FROM          dbo.pos_shop
                            WHERE      (sh_id = jis.in_supplier_id)) END) AS in_supplier_code_txt,
							
							
							 (CASE WHEN in_pos_audit_man > 0 THEN 1 ELSE 0 END) AS in_status,
                          (SELECT     TOP (1) in_st_id_txt
                            FROM          dbo.vi_pos_inStorage AS bs
                            WHERE      (in_source_no = jis.in_vo) AND (in_status > 0) AND (jis.in_type = 2)) AS in_st_id_tb_txt,
                          (SELECT     sei_name
                            FROM          dbo.pos_storageInfo AS bs
                            WHERE      (sei_id = jis.in_st_id)) AS in_st_id_txt,
                          (SELECT     sh_name
                            FROM          dbo.pos_shop AS bs
                            WHERE      (sh_id = jis.in_shop_id)) AS in_sh_id_txt,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = jis.in_man)) AS in_man_txt,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = jis.in_add_man)) AS in_add_man, jis.in_add_time,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = jis.in_update_man)) AS in_update_man, jis.in_update_time,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = jis.in_audit_man)) AS in_audit_man, jis.in_audit_time, jis.in_remark,
                          (SELECT     TOP (1) in_st_id_txt
                            FROM          dbo.vi_pos_inStorage AS bs
                            WHERE      (in_source_no = jis.in_vo) AND (in_status > 0)) AS ins_txt,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = jis.in_pos_audit_man)) AS in_pos_audit_man_txt, jis.in_pos_audit_man, jis.in_pos_audit_time
FROM         dbo.vi_pos_inStorage_audit AS jis LEFT OUTER JOIN
                          (SELECT     inl_in_id, inl_type, SUM(inl_num) AS inl_num, SUM(inl_num_ed) AS inl_num_ed, SUM(inl_money) AS inl_money
                            FROM          dbo.vi_pos_inStorageList_audit_se AS jisl
                            GROUP BY inl_in_id, inl_type) AS p ON p.inl_in_id = jis.in_id AND p.inl_type = jis.in_type
go

