CREATE FUNCTION [dbo].[FnGoodsPrice]
(
    @gi_id int,
	@ci_id int,
	@sh_id int,
	@to_cp_id int,
	@type int
)
RETURNS @returntable TABLE
(
    gi_id int,
	supplyprice DECIMAL(9, 2),
	discount  DECIMAL(9, 2),

	gs_salesprice DECIMAL(9, 2),
	gs_purchase DECIMAL(9, 2),
	gs_marketprice DECIMAL(9, 2),
	gs_discount DECIMAL(9, 2)
)
AS
BEGIN
    --获取商品的供货价

    INSERT @returntable
	SELECT @gi_id,0.00,0.00,0.00,0.00,0.00,0.00;


    DECLARE @discount  DECIMAL(9, 2) = 1
	DECLARE @ghj DECIMAL(9, 2) = 0;
	DECLARE @ghj_type INT = 0
	DECLARE @lsj DECIMAL(9, 2) = 0;

	IF @ci_id > 0 AND @type > 0
BEGIN
    IF @type = 1
	BEGIN
		SELECT @ghj_type = ci_dhprice,@discount=ci_dhdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_dhprice > 0
	END	          
	ELSE 
	IF @type = 2
	BEGIN
		SELECT @ghj_type = ci_bhprice,@discount=ci_bhdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_bhprice > 0
	END	
	ELSE 
	IF @type = 3
	BEGIN
		SELECT @ghj_type = ci_phprice,@discount=ci_phdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_phprice > 0
	END	 
	ELSE 
	IF @type = 4
	BEGIN
		SELECT @ghj_type = ci_mdprice,@discount=ci_mddiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_mdprice > 0
	END
    
    SELECT @ghj = gd_price FROM  b_goods_discount WHERE  gd_gi_id = @gi_id AND gd_class = 2 AND gd_type = @ghj_type
           
    SELECT @lsj = gi_retailprice FROM b_goodsinfo WHERE   gi_id = @gi_id


    IF @ghj > 0.00
    BEGIN

    UPDATE @returntable SET supplyprice = @ghj
	UPDATE @returntable SET discount = @discount

	set @ghj=@ghj*@discount

    UPDATE @returntable SET gs_purchase = @ghj ,gs_salesprice = @ghj

    UPDATE @returntable SET gs_marketprice = @lsj
     
	UPDATE @returntable SET gs_discount =(CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END)

    END
    ELSE
    BEGIN

    UPDATE @returntable SET gs_purchase = gs_marketprice
    
    UPDATE @returntable SET gs_discount = ( CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END) WHERE gs_purchase>0

    END
END
ELSE 
IF @sh_id > 0 AND @type > 0
BEGIN
    --有选择店铺,并且有设置交易方式
     IF @type = 1
	BEGIN

		SELECT @ghj_type = sh_dhprice,@discount= sh_dhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_dhprice>0
	END         
	ELSE 
	IF @type = 2
	BEGIN

		SELECT @ghj_type = sh_bhprice,@discount= sh_bhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_bhprice>0
	END 
	ELSE 
	IF @type = 3
	BEGIN
	
		SELECT @ghj_type = sh_phprice,@discount= sh_phdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_phprice>0
		               
	END	           
	ELSE 
	IF @type = 4
	BEGIN
		
		SELECT @ghj_type = sh_mdprice,@discount= sh_mddiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_mdprice>0
	END	
    
    --得到价格
    SELECT @ghj = gd_price FROM b_goods_discount WHERE gd_gi_id = @gi_id AND gd_class = 2 AND gd_type = @ghj_type
       
    SELECT @lsj = gi_retailprice FROM b_goodsinfo WHERE gi_id = @gi_id

    IF @ghj > 0.00
    BEGIN

	UPDATE @returntable SET supplyprice = @ghj
	UPDATE @returntable SET discount = @discount

    set @ghj=@ghj*@discount
    --更细供货价
    UPDATE @returntable SET  gs_purchase = @ghj ,gs_salesprice = @ghj

    UPDATE @returntable SET gs_marketprice = @lsj
    --更新折扣价
    UPDATE @returntable SET gs_discount = ( CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END )

    END
    ELSE
    BEGIN

    UPDATE @returntable SET gs_purchase = gs_marketprice
    
    UPDATE @returntable SET gs_discount = ( CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END ) WHERE gs_purchase>0
    END
END
ELSE 
IF @to_cp_id > 0 AND @type > 0
BEGIN
    --有选择店铺,并且有设置交易方式
     IF @type = 1
	BEGIN
	
		SELECT @ghj_type = cp_dhprice,@discount=cp_dhdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_dhprice > 0
	END	          
	ELSE 
	IF @type = 2
	BEGIN
		
		SELECT @ghj_type = cp_bhprice,@discount=cp_bhdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_bhprice > 0
	END	
	ELSE 
	IF @type = 3
	BEGIN
		
		SELECT @ghj_type = cp_phprice,@discount=cp_phdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_phprice > 0
	END	 
	ELSE 
	IF @type = 4
	BEGIN
		
		SELECT @ghj_type = cp_mdprice,@discount=cp_mddiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_mdprice > 0
	END
   
    
    --得到价格
    SELECT @ghj = gd_price FROM  b_goods_discount WHERE  gd_gi_id = @gi_id AND gd_class = 2 AND gd_type = @ghj_type
       
    SELECT @lsj = gi_retailprice FROM   b_goodsinfo WHERE   gi_id = @gi_id

    IF @ghj > 0.00
    BEGIN

	UPDATE @returntable SET supplyprice = @ghj

	UPDATE @returntable SET discount = @discount

	set @ghj=@ghj*@discount
    --更细供货价
    UPDATE @returntable SET gs_purchase = @ghj ,gs_salesprice = @ghj

    UPDATE @returntable SET gs_marketprice = @lsj
    --更新折扣价
    UPDATE @returntable SET gs_discount = (CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END )
    END
    ELSE
    BEGIN

    UPDATE @returntable SET gs_purchase = gs_marketprice
    
    UPDATE @returntable SET gs_discount = ( CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END ) WHERE gs_purchase>0

    END
END
ELSE
BEGIN
	
    IF (@ci_id>0 OR @sh_id>0 OR @to_cp_id>0 ) AND @type=0
	BEGIN
		
	UPDATE @returntable SET gs_purchase = gs_marketprice 

    UPDATE @returntable SET gs_discount = ( CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END ) WHERE gs_purchase>0
		
	END
	
END



	
	RETURN
END
go

