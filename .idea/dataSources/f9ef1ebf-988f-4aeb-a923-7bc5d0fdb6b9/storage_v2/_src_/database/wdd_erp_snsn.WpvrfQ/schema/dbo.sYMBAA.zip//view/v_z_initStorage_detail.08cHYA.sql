


CREATE view [dbo].[v_z_initStorage_detail]
as

select 
'' as specname,--暂时为空 
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
rulenum.gd_code as sizecode,--尺码代号
jinitlist.*
from 
(

select 
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=isnull(grl.colorid,0))as colorcode,--颜色代号
isnull(grl.gss_no,'') as gss_no,--规格编码,
ISNULL(grl.colorid,0) as colorid,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
isnull(grl.gs_sampleno,gi_sampleno)gs_sampleno,--规格样品号
jinit.* 
from
(



SELECT
st.inl_id,
ge.in_cp_id,
ge.in_erp_id,
ge.in_erp_id as erp_id ,

ge.in_id,  
ge.in_vo,--凭证号
ge.in_no,--单据号
CONVERT(varchar(100), ge.in_date, 23) as in_date,--期初日期

sg.sei_id AS in_st_id,
sg.sei_name AS in_st_id_txt,--仓库
sg.sei_name,--仓库

gi.gi_id,
st.inl_gi_id,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_skuid,
gi.gi_sampleno,--样品号
isnull(st.inl_num,0) as num,--规格数量

ui.ut_name,--单位
ui.ut_name as gi_unit, --单位
st.inl_sku_id,--sku_id
isnull(st.inl_num,0) as inl_num,--数量
isnull(st.inl_retail_price,0) as inl_retail_price,--零售价
isnull(st.inl_discount,0) as inl_discount,--折率
isnull(st.inl_stock_price,0) as inl_stock_price,--进货价
isnull(st.inl_retail_price,0)*isnull(st.inl_num,0) as inl_retail_money,--零售金额
isnull(st.inl_money,0) as inl_money,--进货金额
st.inl_boxbynum,--数量/箱
(case when isnull(st.inl_boxbynum,0)=0 then 0 else ceiling(inl_num/inl_boxbynum) end) as inl_box_num, --箱数
st.inl_pm,
in_order_man_txt=( SELECT bs.si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE bs.si_id = in_order_man),--经手人
inl_add_time,   --单据商品添加时间
in_add_man_txt=( SELECT bs.si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE bs.si_id = in_add_man ), --添加人
in_add_time,    --单据添加时间
in_update_man_txt=( SELECT bs.si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE bs.si_id = in_update_man ), --单据修改人
in_update_time,    --单据修改时间
in_audit_man_txt=( SELECT bs.si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE bs.si_id = in_audit_man ),  --单据审核人
in_audit_time,     --单据审核时间
in_status,         --单据状态
in_remark  --备注

FROM   j_initStorage ge
inner join  j_initStorageList st ON ge.in_id = inl_in_id AND st.inl_status = 1 and ge.in_status>0
inner join b_goodsinfo gi on gi.gi_id=st.inl_gi_id and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 
left join b_storageinfo sg on sg.sei_id=ge.in_st_id

) as jinit
left join b_goodsruleset as grl on  grl.gss_id=jinit.inl_sku_id

) as jinitlist
left join s_goodsruledetail rulenum on gd_id=jinitlist.size
go

