



CREATE View [dbo].[vi_stockSum_nolock]
As
Select 
sl.[sid],
sl.gid,
sl.skuid,
sl.cp_id,
Sum(Case when sl.countType=1 Then sl.gnum Else -sl.gnum End)As gnum,
MAX(sl.addtime) AS addtime
From vi_stockList_nolock sl 
Group By 
sl.[sid],
sl.gid,
sl.skuid,
sl.cp_id


go

