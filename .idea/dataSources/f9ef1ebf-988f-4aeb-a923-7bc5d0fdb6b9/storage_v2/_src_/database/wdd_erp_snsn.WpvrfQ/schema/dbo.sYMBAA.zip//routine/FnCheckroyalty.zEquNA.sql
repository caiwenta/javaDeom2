CREATE FUNCTION [dbo].[FnCheckroyalty]
(
	@erp_id int,
	@status int,
	@deduction decimal(18,2),
	@otherdeduction decimal(18,2)
)
RETURNS INT
AS
BEGIN

	 DECLARE @re INT=1;
	
	 if @erp_id=51 and @status=1
	 begin
	   if @deduction >0
	   begin
	     SET @re = 0;
	   end

	   if @otherdeduction >0
	   begin
	     SET @re = 0;
	   end
	 end
	  
	 RETURN @re;
END
go

