CREATE PROC [dbo].[pro_update_occupy_num] @id INT = 0
AS
    BEGIN
        IF @id = 0
            RETURN;
      
        DECLARE @o_ord_sendtype VARCHAR(50)= '';
        DECLARE @ord_send_id INT= 0;
        DECLARE @erp_id INT= 0;

        SELECT  @o_ord_sendtype = nt.ord_sendtype ,
                @ord_send_id = nt.ord_send_erp_sid ,
                @erp_id = nt.ord_erp_id
        FROM    netorder_tbl nt WITH ( NOLOCK )
        WHERE   nt.ord_id = @id

        DECLARE @out_id INT= 0;
        EXEC pro_get_occupy_storage_id @type = @o_ord_sendtype, @id = @ord_send_id, @out_id = @out_id OUT
	
        IF @o_ord_sendtype = 'store'
            BEGIN
                SELECT  n.o_ord_send_erp_sid ,
                        n.o_gi_id ,
                        ISNULL(n.o_sku_id, 0) AS o_sku_id ,
                        SUM(n.o_nog_buynumber) AS num
                INTO    #p
                FROM    netorder_occupy_tbl n WITH ( NOLOCK )
                WHERE   n.o_ord_sendtype = 'store'
                        AND n.o_ord_send_erp_sid = @ord_send_id
                        AND n.o_status = 1
                GROUP BY n.o_ord_send_erp_sid ,
                        n.o_gi_id ,
                        n.o_sku_id

                INSERT  INTO pos_stockInfo
                        ( st_sh_id ,
                          st_st_id ,
                          st_gi_id ,
                          st_sku_id ,
                          st_num ,
                          add_time ,
                          st_occupy_num ,
                          st_erp_id
                        )
                        SELECT  @ord_send_id ,
                                @out_id ,
                                o_gi_id ,
                                o_sku_id ,
                                0 ,
                                GETDATE() ,
                                num ,
                                @erp_id
                        FROM    #p
                        WHERE   o_gi_id > 0
                                AND o_sku_id > 0
                                AND ( o_gi_id NOT IN ( SELECT DISTINCT
                                                                psi.st_gi_id
                                                       FROM     pos_stockInfo psi
                                                       WHERE    psi.st_sh_id = @ord_send_id
                                                                AND psi.st_st_id = @out_id )
                                      OR o_sku_id NOT IN ( SELECT DISTINCT
                                                                    psi.st_sku_id
                                                           FROM     pos_stockInfo psi
                                                           WHERE    psi.st_sh_id = @ord_send_id
                                                                    AND psi.st_st_id = @out_id )
                                    )

                INSERT  INTO pos_stockInfo
                        ( st_sh_id ,
                          st_st_id ,
                          st_gi_id ,
                          st_sku_id ,
                          st_num ,
                          add_time ,
                          st_occupy_num ,
                          st_erp_id
                        )
                        SELECT  @ord_send_id ,
                                @out_id ,
                                o_gi_id ,
                                o_sku_id ,
                                0 ,
                                GETDATE() ,
                                num ,
                                @erp_id
                        FROM    #p
                        WHERE   o_gi_id > 0
                                AND o_sku_id = 0
                                AND ( o_gi_id NOT IN ( SELECT DISTINCT
                                                                psi.st_gi_id
                                                       FROM     pos_stockInfo psi
                                                       WHERE    psi.st_sh_id = @ord_send_id
                                                                AND psi.st_st_id = @out_id ) )

                UPDATE  pos_stockInfo
                SET     st_occupy_num = 0
                WHERE   st_sh_id = @ord_send_id;

                UPDATE  pos_stockInfo
                SET     st_occupy_num = fd.num
                FROM    pos_stockInfo bs ,
                        ( SELECT    *
                          FROM      #p
                        ) AS fd
                WHERE   bs.st_sh_id = fd.o_ord_send_erp_sid
                        AND bs.st_st_id = @out_id
                        AND bs.st_gi_id = fd.o_gi_id
                        AND bs.st_sku_id = fd.o_sku_id
            END

        IF @o_ord_sendtype = 'node'
            BEGIN
                SELECT  n.o_ord_send_erp_sid ,
                        n.o_gi_id ,
                        ISNULL(n.o_sku_id, 0) AS o_sku_id ,
                        SUM(n.o_nog_buynumber) AS num
                INTO    #p1
                FROM    netorder_occupy_tbl n WITH ( NOLOCK )
                WHERE   n.o_ord_sendtype = 'node'
                        AND n.o_ord_send_erp_sid = @ord_send_id
                        AND n.o_status = 1
                GROUP BY n.o_ord_send_erp_sid ,
                        n.o_gi_id ,
                        n.o_sku_id

                INSERT  INTO b_stockinfo
                        ( si_seiid ,
                          si_status ,
                          si_number ,
                          si_indate ,
                          si_giid ,
                          si_skuid ,
                          si_cp_id ,
                          si_occupy_num ,
                          si_erp_id
                        )
                        SELECT  @out_id ,
                                1 ,
                                0 ,
                                GETDATE() ,
                                o_gi_id ,
                                o_sku_id ,
                                @ord_send_id ,
                                num ,
                                @erp_id
                        FROM    #p1
                        WHERE   o_gi_id > 0
                                AND o_sku_id > 0
                                AND ( o_gi_id NOT IN ( SELECT DISTINCT
                                                                fd.si_giid
                                                       FROM     b_stockinfo fd
                                                       WHERE    fd.si_cp_id = @ord_send_id
                                                                AND fd.si_seiid = @out_id )
                                      OR o_sku_id NOT IN ( SELECT DISTINCT
                                                                    fd.si_skuid
                                                           FROM     b_stockinfo fd
                                                           WHERE    fd.si_cp_id = @ord_send_id
                                                                    AND fd.si_seiid = @out_id )
                                    )

                INSERT  INTO b_stockinfo
                        ( si_seiid ,
                          si_status ,
                          si_number ,
                          si_indate ,
                          si_giid ,
                          si_skuid ,
                          si_cp_id ,
                          si_occupy_num ,
                          si_erp_id
                        )
                        SELECT  @out_id ,
                                1 ,
                                0 ,
                                GETDATE() ,
                                o_gi_id ,
                                o_sku_id ,
                                @ord_send_id ,
                                num ,
                                @erp_id
                        FROM    #p1
                        WHERE   o_gi_id > 0
                                AND o_sku_id = 0
                                AND ( o_gi_id NOT IN ( SELECT DISTINCT
                                                                fd.si_giid
                                                       FROM     b_stockinfo fd
                                                       WHERE    fd.si_cp_id = @ord_send_id
                                                                AND fd.si_seiid = @out_id ) )

                UPDATE  b_stockinfo
                SET     si_occupy_num = 0
                WHERE   si_cp_id = @ord_send_id;

                UPDATE  b_stockinfo
                SET     si_occupy_num = fd.num
                FROM    b_stockinfo bs ,
                        ( SELECT    *
                          FROM      #p1 fd WITH ( NOLOCK )
                        ) AS fd
                WHERE   fd.o_ord_send_erp_sid = bs.si_cp_id
                        AND bs.si_seiid = @out_id
                        AND bs.si_giid = fd.o_gi_id
                        AND bs.si_skuid = fd.o_sku_id
            END
    END
go

