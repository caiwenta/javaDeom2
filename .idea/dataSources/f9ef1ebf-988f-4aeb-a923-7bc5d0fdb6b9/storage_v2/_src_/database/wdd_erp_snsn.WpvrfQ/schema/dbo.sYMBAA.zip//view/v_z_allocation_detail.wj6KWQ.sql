CREATE view [dbo].[v_z_allocation_detail]
as

select 
--ISNULL(rulenum.tmp,'无') as spec2,
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_code as sizecode,--尺码代号
alclist.*,
(all_num-isnull(all_num_ed,0)) - ISNULL(all_pause_num, 0) AS all_num_do --未执行数量
from 
(

select 
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=isnull(grl.colorid,0))as colorcode,--颜色代号
isnull(grl.gss_no,'') as gss_no,--规格编码,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
isnull(grl.colorname,'无') as color,
ISNULL(grl.colorid,0)colorid,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
isnull(grl.gs_sampleno,gi_sampleno)gs_sampleno,--规格样品号
alc.* ,

(case when al_ci_id_txt<>'' then al_ci_id_txt
     when al_sh_id_txt<>'' then al_sh_id_txt
     when al_to_cp_id_txt<>'' then al_to_cp_id_txt
end
) as subname,
(case when al_ci_code_txt<>'' then al_ci_code_txt
     when al_sh_code_txt<>'' then al_sh_code_txt
     when al_to_cp_code_txt<>'' then al_to_cp_code_txt
end
) as subnamecode

from
(

SELECT
ge.al_review,
ge.al_id,
ge.al_cp_id,
st.all_id,
sg.sei_erp_id as erp_id,
ge.al_vo,--凭证号
ge.al_no,--单据号
CONVERT(varchar(100), ge.al_date, 23)al_date,--配货日期

sg.sei_name,--仓库
gi.gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_skus,
gi.gi_sampleno,--样品号
ISNULL(st.all_num,0) as num,--规格数量

isnull(ci.ci_name,'') as ci_name,--客户
isnull(ci.ci_code,'') as ci_code,--客户代号

ISNULL(ps.sh_name,'') as sh_name,--店铺
ISNULL(ps.sh_no,'') as sh_no,--店铺代号

ISNULL(cp.cp_name,'') as cp_name,--分公司
ISNULL(cp.cp_code,'') as cp_code,--分公司代号

ui.ut_name,--单位


ISNULL(st.all_retail_price,0) as all_retail_price,--零售价
ISNULL(st.all_retail_money,0) as all_retail_money,--零售金额
ISNULL(st.all_discount,0) as all_discount,--折率
ISNULL(st.all_stock_price,0) as all_stock_price,--供货价
ISNULL(st.all_money,0) as all_money,--金额
ISNULL(st.all_boxbynum,0) as all_boxbynum,--数量/箱
(case when isnull(all_boxbynum,0)=0 then 0 else ceiling(all_num/all_boxbynum) end) AS all_box_num, --箱数

ge.al_ci_id,
ci_name  as al_ci_id_txt,--客户
ci.ci_code as al_ci_code_txt,--客户代号
ge.al_sh_id,
sh_name as al_sh_id_txt,--店铺
sh_no as al_sh_code_txt,
ge.al_to_cp_id,
cp.cp_name as al_to_cp_id_txt,--公司
cp.cp_code as al_to_cp_code_txt,

ui.ut_name as gi_unit_name,--单位
al_type,--交易方式
all_al_id,
all_pm,--配码
all_gift,--是否赠送
all_add_time,--单据商品添加时间
al_trans,--运输方式
sg.sei_name as al_st_id_txt,--仓库
al_freight_no,--货运单号
al_fright,--垫付运费
al_source,--来源
al_source_id,--退货
al_add_man_txt,--添加人
al_add_time,--单据添加时间
al_update_man_txt,--修改人
al_update_time,--单据修改时间
al_audit_man_txt,--审核人
al_audit_time,
al_status,
al_remark,
             CASE al_source
             WHEN 2 THEN
             (SELECT re_vo FROM pos_reStorage AS bs  WITH (NOLOCK) WHERE re_id = al_source_id )
             WHEN 3 THEN
             (SELECT in_vo FROM pos_inStorage AS bs  WITH (NOLOCK) WHERE in_id = al_source_id )
             WHEN 5 THEN
             (SELECT og_vo FROM pos_ogStorage AS bs  WITH (NOLOCK) WHERE og_id = al_source_id)
			 WHEN 7 THEN
		( SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id where eio.io_id =al_source_id )
             END AS al_source_vo,--来源

            (CASE al_source
             WHEN 2 THEN
             (SELECT MAX(rel_id) FROM pos_reStorageList AS bs  WITH (NOLOCK) WHERE rel_id = all_source_id )
             WHEN 3 THEN
             (SELECT MAX(inl_id) FROM pos_inStorageList AS bs  WITH (NOLOCK) WHERE inl_id = all_source_id )
             WHEN 5 THEN
             (SELECT MAX(ogl_id) FROM pos_ogStorageList AS bs  WITH (NOLOCK) WHERE ogl_id = all_source_id)
			 WHEN 7 THEN
		    ( SELECT MAX(inl_in_id) FROM dbo.erp_instructionNoticeList AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.inl_in_id=eio.io_in_id where eio.io_id =all_source_id )
             END) AS all_source_id,--明细来源id
			 
            (CASE al_source
             WHEN 2 THEN
             (SELECT MAX(rel_add_time) FROM pos_reStorageList AS bs  WITH (NOLOCK) WHERE rel_id = all_source_id )
             WHEN 3 THEN
             (SELECT MAX(inl_add_time) FROM pos_inStorageList AS bs  WITH (NOLOCK) WHERE inl_id = all_source_id )
             WHEN 5 THEN
             (SELECT MAX(ogl_add_time) FROM pos_ogStorageList AS bs  WITH (NOLOCK) WHERE ogl_id = all_source_id)
			 WHEN 7 THEN
		    ( SELECT MAX(inl_add_time) FROM dbo.erp_instructionNoticeList AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.inl_in_id=eio.io_in_id where eio.io_id =all_source_id )
             END) AS all_source_add_time,--明细来源时间

st.all_sku_id,
st.all_gi_id,
ISNULL(st.all_num,0) as all_num,--数量
ISNULL((
SELECT sum(josl.ol_number) AS ol_number FROM j_outStorage AS jos WITH (NOLOCK) INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) 
ON jos.oo_id = josl.ol_eoid WHERE jos.oo_status<>0 AND  jos.oo_source_type=1 and josl.ol_source_id=st.all_id AND josl.ol_status<>0 AND josl.ol_status = 1	
), 0) AS all_num_ed, --执行数量
ISNULL(st.all_pause_num, 0) AS all_pause_num ,--终止数量
st.supplyprice,--出货价
st.discount,--出货价折扣
(case when st.supplyprice=0 then 0 else CONVERT(decimal(9,2), (st.all_stock_price/st.supplyprice)) end ) as realitydiscount--实际折扣                                         
FROM   pos_allocation ge
inner join  pos_allocationList st ON ge.al_id = st.all_al_id AND st.all_status = 1 and ge.al_status>0
inner join b_goodsinfo gi on gi.gi_id=st.all_gi_id and gi_status=1
inner join b_unit ui on ui.ut_id=gi.gi_unit 
inner join b_storageinfo sg on sg.sei_id=ge.al_st_id--仓库
left join b_clientinfo ci on ci.ci_id= ge.al_ci_id and ci.ci_status=1 --客户
left join pos_shop ps on ps.sh_id=ge.al_sh_id --店铺
left join companyinfo cp on cp.cp_id= ge.al_to_cp_id --分公司

) as alc
left join b_goodsruleset  as grl on  grl.gss_id=alc.all_sku_id

) as alclist
left join s_goodsruledetail rulenum on gd_id=alclist.size
go

