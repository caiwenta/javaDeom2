CREATE VIEW [dbo].[v_z_royaltyschemelog]
as
SELECT
erl.ss_name as sei_name,
(case when rc_royalty=1 then '按销售的金额提成' when rc_royalty=2 then '按毛利提成' when rc_royalty=3 then '按固定金额提成' end) rc_royaltyName,
(case when erl.commissiontype=5 or erl.commissiontype=7 then
''
else
cast(cast(erl.proportion as float) as varchar(10))+(case when rc_counttype=0 then '%' when rc_counttype=1 then '元/件' end) 
end)
rc_proportion_type,
erl.order_date AS oo_entrydate, 
erl.order_no as oo_no,
gi.gi_code,
gi.gi_barcode,
gi.gi_name,
erl.*,
(erl.otherdeduction+erl.deduction) as othermoney,
bs.si_name,
re.rc_royalty
FROM erp_royaltyschemelog AS erl
INNER JOIN erp_royaltyscheme AS re ON re.rc_id=erl.rc_id
inner join b_goodsinfo gi on gi.gi_id=erl.gi_id and gi_status=1
INNER JOIN b_stafftinfo AS bs on bs.si_id=erl.si_id
WHERE erl.[type]=1  and erl.status<>0 and  erl.sei_id<>0
go

