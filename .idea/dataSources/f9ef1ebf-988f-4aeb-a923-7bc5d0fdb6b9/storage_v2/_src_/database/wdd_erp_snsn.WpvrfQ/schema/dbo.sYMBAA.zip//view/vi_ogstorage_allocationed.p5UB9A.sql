CREATE VIEW [dbo].[vi_ogstorage_allocationed]
	AS 

--订单配货
SELECT 
       al_id,
       all_num,
       all_pm,
	   all_box_num,
	   all_source_id
FROM   pos_allocationList
	INNER JOIN pos_allocation ON  
	all_al_id = al_id  
	WHERE  al_status > 0
	AND all_status > 0 
	AND al_source = 5
go

