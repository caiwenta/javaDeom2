CREATE PROCEDURE [dbo].[proc_api_verifytoken]
    @outid INT OUTPUT ,		--返回状态
    @erpid INT = 0 OUTPUT ,     --erpid
    @cpid INT = 0 OUTPUT ,   --公司id
    @token VARCHAR(255) ,	--账号标识
    @method VARCHAR(255) ,	--相应接口
    @ip VARCHAR(50) ,		--当前IP
    @url VARCHAR(MAX)
AS
    BEGIN
		------------------------------------
		-- exec [proc_api_verifytoken] null,'DF4837CDD98A4C8E932DD46ABF9511C5','11','11','1111111'
		--用途：api接口验证
		--验证token是否有效[method暂时不做验证是否是允许的接口]
		------------------------------------
		
        SET NOCOUNT ON
        SET @outid = 0;
        
        SELECT  @outid = oc_id ,
                @erpid = oc_erp_id ,
                @cpid = ISNULL(( SELECT ci_cp_id
                                 FROM   b_clientinfo
                                 WHERE  ci_id = oc_client_id
                               ), 0)
        FROM    m_orderchannel
        WHERE   oc_Token = @token
                AND oc_status = 1
                AND oc_type = 2
		--SELECT @outid=tok_id FROM api_tokenset_tbl  WHERE tok_status=1 and tok_key=@token 
        IF ( @@ROWCOUNT > 0 )
            BEGIN
                UPDATE  api_tokenset_tbl
                SET     tok_access = tok_access + 1
                WHERE   tok_key = @token 
                
                IF ( @@ROWCOUNT > 0 )
                    BEGIN
                        INSERT  INTO [api_tokenlog_tbl]
                                ( tol_tok_key ,
                                  tol_ip ,
                                  tol_method ,
                                  tol_remark ,
                                  tol_status
                                )
                        VALUES  ( @token ,
                                  @ip ,
                                  @method ,
                                  @url ,
                                  1
                                )
                    END
            END
        ELSE
            BEGIN
			    SET @outid = 0;
				SET @erpid = 0;
				SET @cpid = 0;

                INSERT  INTO [api_tokenlog_tbl]
                        ( tol_tok_key ,
                          tol_ip ,
                          tol_method ,
                          tol_remark ,
                          tol_status ,
                          tol_xml
                        )
                VALUES  ( @token ,
                          @ip ,
                          @method ,
                          @url ,
                          -1 ,
                          '<xml><row>key不存在或未启用</row></xml>'
                        )
            END
            
        SET NOCOUNT OFF
    END
go

