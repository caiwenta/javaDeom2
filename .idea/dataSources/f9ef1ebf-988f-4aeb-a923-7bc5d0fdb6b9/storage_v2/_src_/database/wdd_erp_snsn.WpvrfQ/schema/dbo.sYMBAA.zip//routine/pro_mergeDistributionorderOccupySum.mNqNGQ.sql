CREATE PROCEDURE dbo.pro_mergeDistributionorderOccupySum
	@do_id int = 0,
	@type int=0,
	@si_id int=0
AS


DECLARE @warehousingtype int=0;
SELECT @warehousingtype=(case ed.warehousingtype 
when 0 then (SELECT  top 1 pl_pltype FROM j_purchaseStorage jps WHERE jps.pl_id=ed.do_source_id)
when 1 then 0
when 3 then (case (SELECT  top 1 al_source FROM pos_allocation pa WHERE pa.al_id=ed.do_source_id ) when 4 then 0 when 6 then 0 else 1 end)
WHEN 5 THEN 0
when 8 then 0
when 27 then (CASE (SELECT top 1 pa.mo_type FROM j_orderblank pa WHERE pa.mo_id=ed.do_source_id) WHEN 0 then 1 WHEN 1 THEN 4 ELSE 0 end)
when 36 then 5
else ed.warehousingtype end)
FROM erp_distributionorder ed WHERE ed.do_id=@do_id;


if @warehousingtype=1 or @warehousingtype=4
begin


BEGIN TRAN

--重新计算占用库存按pda传回的数量占用
if @si_id>0 and @type=1
begin

--先取消之当前pda所有占用的数量
update erp_distributionorderoccupy set o_status=0  FROM erp_distributionorderoccupy AS edc
INNER JOIN (
	SELECT 
		ed2.do_id,
		ed2.dol_gi_id,
		ed2.dol_sku_id
	FROM erp_distributionorder AS ed
	INNER JOIN erp_distributionorderlist AS ed2 ON ed.do_id=ed2.do_id AND ed.do_id=@do_id
	WHERE ed.do_id=@do_id AND ed2.si_id=@si_id
	GROUP BY ed2.do_id,ed2.dol_gi_id,ed2.dol_sku_id
) AS lt ON edc.do_id=lt.do_id AND edc.gi_id=lt.dol_gi_id AND edc.skuid=lt.dol_sku_id AND edc.do_id=@do_id


if @warehousingtype=1
begin
--重新计算占用库存
INSERT INTO dbo.erp_distributionorderoccupy
(do_id
,gi_id
,skuid
,occupynum
,sei_id
,location
,erp_id
,o_status)
SELECT
edl.do_id,
edl.dol_gi_id,
edl.dol_sku_id, 
edi.dp_inspectionnum,
(SELECT es.sei_id FROM erp_storagelocation AS es WHERE es.slt_id=edi.slt_id) AS sei_id,
edi.slt_id,
edl.erp_id,
1
FROM erp_distributionorderlist AS edl
INNER JOIN erp_distributionpicking AS edi 
ON edl.dol_id=edi.dol_id AND edl.dol_status>0 and edl.si_id=@si_id AND edl.do_id=@do_id

end


--移仓
if @warehousingtype=4
begin
 

INSERT INTO dbo.erp_distributionorderoccupy
(do_id
,gi_id
,skuid
,occupynum
,sei_id
,location
,erp_id
,o_status)
SELECT
edl.do_id,
edl.dol_gi_id,
edl.dol_sku_id, 
edi.dp_inspectionnum,
(SELECT es.sei_id FROM erp_storagelocation AS es WHERE es.slt_id=edi.slt_id) AS sei_id,
(select j.mo_locationid as slt_no  from j_orderblank j  where mo_type=1 and mo_id=edr.do_source_id) slt_out_id,
edl.erp_id,
1
FROM 
erp_distributionorder AS edr
INNER JOIN erp_distributionorderlist AS edl ON edr.do_id=edl.do_id AND edr.warehousingtype=27
INNER JOIN erp_distributionpicking AS edi 
ON edl.dol_id=edi.dol_id AND edl.dol_status>0 and edl.si_id=@si_id AND edl.do_id=@do_id


end



end
else
begin


--解除与占用
if @type=1
begin
	update erp_distributionorderoccupy set o_status=0 where do_id=@do_id
end
else
begin
	update erp_distributionorderoccupy set o_status=1 where do_id=@do_id
end

end



MERGE INTO b_stockinfolocation AS ta 
USING
(
	
SELECT 
t1.gi_id, t1.skuid, t1.sei_id, t1.location,erp_id,
SUM((CASE WHEN t1.o_status=1 THEN t1.occupynum ELSE 0 end)) AS occupynum
FROM erp_distributionorderoccupy AS t1
INNER JOIN(

	SELECT gi_id,skuid,sei_id,location FROM erp_distributionorderoccupy WHERE do_id=@do_id
    GROUP BY gi_id,skuid,sei_id,location
    
) AS t2 ON t1.gi_id=t2.gi_id AND t1.skuid=t2.skuid AND t1.location=t2.location
GROUP BY t1.gi_id, t1.skuid, t1.sei_id, t1.location,erp_id


) as so ON 
ta.si_giid=so.gi_id 
and ta.si_skuid=so.skuid 
AND ta.si_seiid=so.sei_id 
AND ta.si_location=so.location
and ta.si_erp_id=so.erp_id
WHEN MATCHED THEN  
UPDATE SET ta.si_occupy_num =so.occupynum
WHEN NOT matched THEN
INSERT 
           (si_seiid
           ,si_status
           ,si_number
           ,si_occupy_num
           ,si_indate
           ,si_giid
           ,si_skuid
           ,si_cp_id
           ,si_erp_id
           ,si_location)
VALUES
           (so.sei_id
           ,1
           ,0
           ,so.occupynum
           ,GETDATE()
           ,so.gi_id
           ,so.skuid
           ,(SELECT bs.sei_erp_id FROM b_storageinfo AS bs WHERE bs.sei_id=so.sei_id)
           ,so.erp_id
		   ,so.location
);
IF @@ERROR <> 0
BEGIN
    ROLLBACK TRAN
END
ELSE
BEGIN
    COMMIT TRAN
END

end
go

