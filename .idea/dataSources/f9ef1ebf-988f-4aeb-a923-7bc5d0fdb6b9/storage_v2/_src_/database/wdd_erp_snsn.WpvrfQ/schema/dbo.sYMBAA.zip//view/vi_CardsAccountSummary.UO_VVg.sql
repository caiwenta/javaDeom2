CREATE VIEW [dbo].[vi_CardsAccountSummary]
	AS 

SELECT T.*,
      (balance+receivemoney+givemoney-payment)balance_month--本月余额
FROM (
	SELECT erpid,
		   CONVERT(VARCHAR(7),addtime,23)year_month,-- 年-月
		   me_id,
		   (SELECT (CASE WHEN pmi.me_card<>'' THEN pmi.me_card ELSE pmi.me_phone END) 
			FROM pos_memberInfo pmi 
			WHERE pmi.me_id=cpd.me_id)me_card,--储值卡号
			                                  
		  ISNULL((
		    	SELECT TOP 1 (balance-payment+momey) FROM erp_cardpaymentdetail a 
		    	WHERE a.me_id=cpd.me_id 
		          AND CONVERT(VARCHAR(7),a.addtime,23)<CONVERT(VARCHAR(7),cpd.addtime,23)
		    	ORDER BY a.addtime desc
		          ),0)balance, --上月余额
		             
		   SUM(receivemoney)receivemoney, --本月充值金额
		   SUM(givemoney)givemoney, --赠送金额
		   SUM(payment)payment --消费金额
	FROM erp_cardpaymentdetail cpd
	GROUP BY erpid,me_id,CONVERT(VARCHAR(7),addtime,23)
)T
go

