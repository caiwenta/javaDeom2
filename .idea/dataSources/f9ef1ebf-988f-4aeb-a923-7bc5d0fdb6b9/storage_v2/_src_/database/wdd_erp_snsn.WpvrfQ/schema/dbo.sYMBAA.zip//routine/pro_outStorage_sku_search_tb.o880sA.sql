CREATE PROCEDURE [dbo].[pro_outStorage_sku_search_tb]
	@ol_eoid INT = 0,
	@ol_addtime DATETIME = '2004-10-17',
	@date VARCHAR(30) ='',
	@gi_id INT,
	 --客户
	@ci_id INT,
	 --店铺
	@sh_id INT,
	 --分公司
	@to_cp_id INT ,
	 --交易类型
	@type INT,
	@cpzorf_id INT = 0,
	@cp_id int=0,
	@gss_no VARCHAR(30) ='',
	@ol_pm  varchar(50)='' 
AS
	IF @gss_no !='' 
	BEGIN
		SELECT @gi_id = bg.gi_id FROM b_goodsruleset bg WHERE bg.gss_no = @gss_no
	END
	--供货价
	DECLARE @ghj       DECIMAL(9, 2) = 0;
	
		--原零售价
	DECLARE @s_lsj     DECIMAL(9, 2) = 0;
	
	--供货价类别
	DECLARE @ghj_type  INT = 0;
	--
	DECLARE @oi_no VARCHAR(MAX);
	--吊牌价
	--DECLARE @dpj DECIMAL(9,2) = 0 ;
	DECLARE @lsj       DECIMAL(9, 2) = 0;

	declare @returntable table(
			cspid int,
			gi_id int,
			sku_id int,
			retailprice DECIMAL(9, 2),--零售价
			discount DECIMAL(9, 2),
			importprices DECIMAL(9, 2)    --供货价
	)

		select (TT.ol_number-abs(isnull(var_num,0))) as optnum,TT.* INTO #p from (
		SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code,
		( SELECT SUM(var_num) FROM erp_inspectionofgoods WHERE orderid=ol_eoid AND warehousingtype=2 and iog_status=1 and gi_id=ol_siid AND sku_id=ol_skuid ) as var_num
		FROM   b_goodsruleset AS bg
		       LEFT JOIN (

SELECT 
max(ol_id) AS ol_id,
ol_eoid,ol_siid,ol_skuid,ol_erp_id,jisl.ol_gift,
isnull(jisl.ol_pm,'') AS ol_pm,
SUM(ol_number) AS ol_number,
sum(ol_box_num) as ol_box_num,
sum(ol_realmoney) AS ol_realmoney,
MIN(ol_discount) AS ol_discount,
MIN(ol_unit) AS ol_unit,
MIN(ol_costprice) AS ol_costprice,
MIN(supplyprice) as supplyprice,
MIN(discount) as discount

FROM  j_outStorageList AS jisl
WHERE jisl.ol_eoid = @ol_eoid
AND jisl.ol_status = 1
AND isnull(jisl.ol_pm,'')=@ol_pm
and jisl.ol_addtime=@ol_addtime
AND jisl.ol_siid = @gi_id
GROUP BY ol_eoid,ol_siid,ol_skuid,isnull(jisl.ol_pm,''),ol_erp_id,jisl.ol_gift,ol_addtime


		) AS p1
		            ON  bg.gi_id = p1.ol_siid
		            AND bg.gss_id = p1.ol_skuid LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
		WHERE  bg.gi_id = @gi_id
) as TT		

 
        

		SELECT @oi_no=oi_no FROM vi_j_outStorage WHERE oo_id = @ol_eoid
		--分公司时设置零售价为吊牌价
		IF @cpzorf_id != 0
		BEGIN
		if EXISTS(SELECT c.cp_goods_type FROM  companyinfo c WHERE  c.cp_id = @cpzorf_id and cp_goods_type!=0)
		BEGIN
		    SELECT @lsj = gd_price
		    FROM   b_goods_discount
		    WHERE  gd_gi_id = @gi_id
		           AND gd_type IN (SELECT c.cp_goods_type
		                           FROM   companyinfo c
		                           WHERE  c.cp_id = @cpzorf_id)
		           AND gd_class = 1
		    
		    UPDATE #p
		    SET    gs_marketprice = @lsj
		    
		    UPDATE #p
		    SET    gs_purchase = gs_marketprice * gs_discount
		  END  
		END
        

		IF  @date !=''
		BEGIN
		    INSERT @returntable
			SELECT 
			cspid,gi_id,sku_id,retailprice,discount,importprices
			FROM dbo.FnGoodsCustomPrice(@ci_id,@sh_id,@to_cp_id,@date,@gi_id,0,@cp_id)
		END

		if exists (select * from @returntable)  
		begin

		   update #p set
		        gs_marketprice=l.retailprice,
		        gs_salesprice= l.importprices,
				gs_purchase = l.importprices,
				gs_discount=l.discount
		   from #p as p 
		   inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id

		end
		else
		begin

		DECLARE @discount  DECIMAL(9, 2) = 1
		IF @oi_no IS NOT NULL
		BEGIN
			UPDATE #p
		        SET    ol_costprice = gs_salesprice
		        
		        UPDATE #p
		        SET    ol_discount = (
		                   CASE 
		                        WHEN gs_marketprice = 0.00 THEN 0.00
		                        ELSE gs_salesprice / gs_marketprice
		                   END
		               )
		END
		ELSE
		BEGIN

			INSERT @returntable
		    SELECT
				0,
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
			FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,@ci_id,@sh_id,@to_cp_id,@type)

		   update #p set
		        gs_salesprice= l.importprices,
				gs_purchase = l.importprices,
				gs_discount=l.discount
		   from #p as p 
		   inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id

		END

		end

		SELECT * FROM   #p
go

