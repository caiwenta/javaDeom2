CREATE PROC [dbo].[pro_outStorage_op]
    @ol_box_num INT = 0 ,
    @ol_pm VARCHAR(500) = '' ,
    @oo_id INT = 0 ,
    @oo_erp_id INT = 0 ,
    @ol_erp_id INT = 0 ,
    @oo_ciid INT = 0 , --客户id
    @oo_sh_id INT = 0 , --店铺主键
    @oo_siid INT = 0 , --仓库id
    @oo_takemanid INT = 0 , --经手人id
    @oo_remark VARCHAR(200) = '' , --备注
    @oo_ismatching INT = 0 , --自动匹配配货
    @oo_entrydate DATETIME = '2014-7-22' , --单据时间
    @oo_lastmanid INT = 0 , --审核人id
    @oo_itid INT = 0 , --部门id
    @oo_type INT = 0 , --类型(0,出库退货:1,出库)
    @oo_status INT = 0 , --状态(0,删除:1,可用:2,审核)
    @oo_manual VARCHAR(50) = '' , --手工单号
    @oo_cost DECIMAL(15, 2) = 0 , --费用
    @oo_freight DECIMAL(15, 2) = 0 , --运费
    @oo_express VARCHAR(100) = '' , --快递公司
    @oo_expressno VARCHAR(100) = '' , --货运单号
    @oo_source_type INT = 0 , --来源(1:配货,2:分公司入库退货，3:pos入库退货)
    @oo_source_id INT = 0 , --来源主键
    @oo_jytype INT = 0 , --交易类型
    @oo_addman INT = 0 , --添加人主键
    @oo_addtime DATETIME = '2014-10-29' , --添加时间
    @oo_updatemam INT = 0 , --修改人主键
    @oo_gift INT = 0 , --整单赠送
    @oo_cash INT = 0 , --现金交易
    @ol_id INT = 0 , --单据明细id
    @ol_siid INT = 0 , --商品id
    @ol_number INT = 0 , --数量
    @ol_discount DECIMAL(10, 2) = 0 , --折扣
    @ol_realmoney DECIMAL(10, 2) = 0 , --实际金额
    @ol_remark VARCHAR(500) = '' , --备注
    @ol_unit DECIMAL(10, 2) = 0 , --出货价
    @ol_costprice DECIMAL(10, 2) = 0 , --销售价
    @ol_addtime DATETIME = '2014-7-22' , --添加时间
    @ol_skuid INT = 0 , --规格id
    @ol_source_id INT = 0 , --来源明细主键
    @ol_gift INT = 0 , --是否赠送
    @oo_cp_id INT = 0 , --公司主键
    @oo_di_id INT = 0 , --部门主键
    @ol_source_add_time DATETIME = '2014-11-20' , --来源明细添加时间
    @is_saomiao INT = 0 , --是否为扫描
    @not_in_ids VARCHAR(MAX) = '' ,
    @savestr VARCHAR(MAX) = '' ,
    @order_id VARCHAR(MAX) = '' ,
    @good_id VARCHAR(MAX) = '' ,
	@pm VARCHAR(MAX) = '' ,
    @oo_to_cp_id INT = 0 ,
    @negative_inventory INT = 0 ,
    @op_type VARCHAR(50) = '' ,
    @result VARCHAR(8000) = '' OUT, --返回的结果(大于0的代表成功 0代表失败)
	@ol_pddate  VARCHAR(80) = null, --生产日期
	@ol_expirationdate VARCHAR(80) = null,--过期时间
	@ol_shelflife int=0,                   --保质期

	@orderguid VARCHAR(500)='', --唯一guid

	@do_id int=0,
    @IsPDA int=0,
	@warehousingtype int=0,

	@logistics VARCHAR(MAX) = '' ,--指令单物流公司
	@logistics_no VARCHAR(MAX) = '', --指令单物流单号
	@aspd int=0, --售后调价
	@isModifyEndNum int=0  --是否修改终止数量
AS
    BEGIN
	    DECLARE @tdoc_xml VARCHAR(max)= '';
		DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
		DECLARE @data VARCHAR(MAX) ='';--推送消息的数据

		--ERP出库单处理方法		
        DECLARE @ma_pl_id INT= 0;
        DECLARE @al_source INT= 0;
        DECLARE @return_no INT= 1;
	    DECLARE @fo_id INT = 0;

        IF @oo_type = 1
            SET @al_source = 0;
        ELSE
            SET @al_source = 4;
	
        IF @is_saomiao = 1
            BEGIN
                SELECT TOP 1
                        @ol_addtime = ol_addtime
                FROM    j_outStorageList WITH ( NOLOCK )
                WHERE   ol_eoid = @oo_id
                        AND ol_siid = @ol_siid;
            END
	   
        DECLARE @old_sei_id INT= 0;
        DECLARE @new_sei_id INT= @oo_siid;
        DECLARE @op_type_end VARCHAR(100)= ''; --终止标识
        IF @op_type = '添加修改单据,明细,终止操作'
            BEGIN
                SET @op_type = '添加修改单据,明细';
                SET @op_type_end = '添加修改单据,明细,终止操作';
            END
        DECLARE @sql NVARCHAR(MAX) = '';
        DECLARE @isInsert INT = 0; --是否添加单据
        DECLARE @need_update INT = 0; --是否需要更新单据
        DECLARE @old_order_date DATETIME; --旧的单据日期
        DECLARE @old_order_date_is_changed INT = 0; --单据日期是否更改
        DECLARE @myprevTxt VARCHAR(50) = 'CKTH'; --凭证号前缀
		declare @oo_io_id int=0;
        IF @oo_type = 1
            SET @myprevTxt = 'CK';


		--事务开始
        BEGIN TRAN

        IF @op_type = '添加修改单据,明细'
            BEGIN
                
		   IF @oo_id = 0 AND @op_type_end = ''
                    BEGIN
					    
						IF @oo_jytype=0
						BEGIN
							SET @oo_jytype=1;
						END
					  
                        IF @oo_cp_id = 0
                            BEGIN
								--员工信息,通过添加人得到公司主键,部门主键
                                SELECT  @oo_cp_id = si_company ,
                                        @oo_di_id = si_did
                                FROM    b_stafftinfo WITH ( NOLOCK )
                                WHERE   si_id = @oo_addman
                            END 

						--配货
                        IF @oo_source_type = 1
                            BEGIN
                                SELECT  @oo_sh_id = al_sh_id ,
										@oo_io_id=al_source_id,
                                        @oo_to_cp_id = al_to_cp_id
                                FROM    pos_allocation WITH ( NOLOCK )
                                WHERE   al_id = @oo_source_id
                            END 


							 if @oo_sh_id>0 and @oo_to_cp_id>0
							begin
								ROLLBACK TRANSACTION;
							end

                        
						--添加订单
                        INSERT  INTO j_outStorage
                                ( oo_sh_id ,
                                  oo_ciid ,
                                  oo_siid ,
                                  oo_no ,
                                  oo_takemanid ,
                                  oo_remark ,
                                  oo_entrydate ,
                                  oo_lastmanid ,
                                  oo_itid ,
                                  oo_type ,
                                  oo_status ,
                                  oo_addtime ,
                                  oo_manual ,
                                  oo_cost ,
                                  oo_freight ,
                                  oo_express ,
                                  oo_expressno ,
                                  oo_source_type ,
                                  oo_source_id ,
                                  oo_addman ,
                                  oo_updatemam ,
                                  oo_updatetime ,
                                  oo_cp_id ,
                                  oo_di_id ,
                                  oo_jytype ,
                                  oo_to_cp_id ,
                                  oo_cash ,
                                  oo_gift ,
                                  oo_ismatching ,
                                  oo_erp_id,
								  do_id,
								  oo_io_id,
								  oo_io_logistics,
								  oo_logistics_no
	                            )
                        VALUES  ( @oo_sh_id ,
                                  @oo_ciid ,
                                  @oo_siid ,
                                  NEWID() ,
                                  @oo_takemanid ,
                                  @oo_remark ,
                                  @oo_entrydate ,
                                  @oo_lastmanid ,
                                  @oo_itid ,
                                  @oo_type ,
                                  1 ,
                                  GETDATE() ,
                                  @oo_manual ,
                                  @oo_cost ,
                                  @oo_freight ,
                                  @oo_express ,
                                  @oo_expressno ,
                                  @oo_source_type ,
                                  @oo_source_id ,
                                  @oo_addman ,
                                  @oo_addman ,
                                  GETDATE() ,
                                  @oo_cp_id ,
                                  @oo_di_id ,
                                  @oo_jytype ,
                                  @oo_to_cp_id ,
                                  @oo_cash ,
                                  @oo_gift ,
                                  @oo_ismatching ,
                                  @oo_erp_id,
								  @do_id,
								  @oo_io_id,
								  @logistics,
								  @logistics_no
	                            );

                        SET @oo_id = SCOPE_IDENTITY();
                        SET @isInsert = 1;
                    END
                ELSE
                    SET @need_update = 1;
	    	
           DECLARE @savestr_item VARCHAR(MAX)= '';
           DECLARE @start_int INT= 1;
           DECLARE @end_int INT= 1;

           IF @savestr != ''
                    BEGIN
                        SELECT  @end_int = ( LEN(@savestr) - LEN(REPLACE(@savestr, '|', '')) )
                    END
                ELSE
                    BEGIN
                        IF @oo_source_type = 1
                            BEGIN
	    						--采购入库,采购退货
	    						--@savestr为空,整单执行,使其不符合条件
                                SET @start_int = @end_int + 1;
                            END
                    END
	    
           DECLARE @add_time_not_in VARCHAR(MAX)= '';
           SELECT  @add_time_not_in = NEWID();


				SELECT  0 all_id,
				        all_al_id,
                        all_gi_id ,
                        all_sku_id ,
                        all_num ,
                        all_add_time ,
                        all_retail_price ,
                        all_discount ,
                        all_stock_price ,
                        all_box_num ,
                        all_pm
                INTO    #temp_all
                FROM    pos_allocationList WITH ( NOLOCK )
                WHERE   1 = 2

		   if @orderguid=''
					begin
			    --动态赋值
					WHILE @start_int <= @end_int
                    BEGIN
                        IF @savestr != ''
                            BEGIN
                                SET @savestr_item = dbo.Get_StrArrayStrOfIndex(@savestr, '|', @start_int);

                                IF ( RTRIM(LTRIM(@savestr_item)) = '' )
                                    BEGIN
                                        BREAK;
                                    END
                                ELSE
                                    BEGIN
                                        IF @oo_source_type = 0
                                            BEGIN

                                                SET @ol_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
                                                SET @ol_siid = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
                                                SET @ol_skuid = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));
                                                SET @ol_number = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item,
                                                                                                        ',', 4));
                                                SET @ol_unit = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5));
                                                SET @ol_costprice = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6));
                                                SET @ol_discount = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7));
                                                SET @ol_box_num = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 8);
                                                SET @ol_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9);

                                            END
                                        ELSE
                                            IF @oo_source_type = 1 
                                                BEGIN

													--配货出库
                                                    SET @ol_id = 0;
                                                    SET @ol_source_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
                                                    SET @ol_number = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
                                                    SET @ol_source_add_time = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3);

                                                    IF ( dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4) = '' )
                                                        BEGIN
															--没规格
                                                            SELECT  @ol_siid = fd.all_gi_id ,
                                                                    @ol_skuid = fd.all_sku_id ,
                                                                    @ol_unit = fd.all_retail_price ,
                                                                    @ol_discount = fd.all_discount ,
                                                                    @ol_costprice = fd.all_stock_price,
																	@ol_pm=fd.all_pm
                                                            FROM    pos_allocationList fd WITH ( NOLOCK )
                                                            WHERE   fd.all_id = @ol_source_id;    
                                                        END	
                                                    ELSE
                                                        BEGIN

                                                            SET @ol_box_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
                                                            SET @ol_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5);
                                                            SET @ol_unit = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6));
                                                            SET @ol_costprice = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7));
                                                            SET @ol_discount = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 8));
                                                            SET @ol_siid = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9));--商品主键
                                                            SET @ol_skuid = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 10));--sku主键

                                                        END
                                                
													insert into #temp_all(all_id,
																		all_gi_id ,
																		all_sku_id ,
																		all_num ,
																		all_add_time ,
																		all_retail_price ,
																		all_discount ,
																		all_stock_price ,
																		all_box_num ,
																		all_pm)
													VALUES(@ol_source_id,@ol_siid,@ol_skuid,@ol_number,@ol_source_add_time,
														   @ol_unit,@ol_discount,@ol_costprice,@ol_box_num,@ol_pm);

												    SET @start_int=@start_int+1;

													CONTINUE;
												END
                                    END
                            END
	    
                        IF @ol_id = 0 AND @is_saomiao = 1
                            BEGIN
                                SELECT  @ol_id = ol_id ,
                                        @ol_number = @ol_number + ol_number
                                FROM    j_outStorageList WITH ( NOLOCK )
                                WHERE   ol_eoid = @oo_id
                                        AND ol_siid = @ol_siid
                                        AND ol_skuid = @ol_skuid
                                        AND ol_gift = @ol_gift

                                IF @ol_id IS NULL
                                    SET @ol_id = 0
                            END
	       
                        IF @oo_gift = 1
                            SET @ol_gift = 1
		
                        DECLARE @cha_el_number INT= 0;	

                        IF @ol_id = 0
                            BEGIN
                                IF @op_type_end = ''
                                    BEGIN
	    							
                                       
                                                INSERT  INTO j_outStorageList
                                                        ( ol_eoid ,
                                                          ol_siid ,
                                                          ol_number ,
                                                          ol_realmoney ,
                                                          ol_discount ,
                                                          ol_remark ,
                                                          ol_unit ,
                                                          ol_costprice ,
                                                          ol_addtime ,
                                                          ol_skuid ,
                                                          ol_source_id ,
                                                          ol_status ,
                                                          ol_source_add_time ,
                                                          ol_box_num ,
                                                          ol_pm ,
														  ol_pddate, --生产日期
														  ol_expirationdate,--过期时间
														  ol_shelflife,     --保质期
                                                          ol_gift ,
                                                          ol_erp_id,
                                                          ol_buyingteamid --买手小组

	                                                    )
                                                VALUES  ( @oo_id ,
                                                          @ol_siid ,
                                                          @ol_number ,
                                                          @ol_costprice * @ol_number ,
                                                          @ol_discount ,
                                                          @ol_remark ,
                                                          @ol_unit ,
                                                          @ol_costprice ,
                                                          @ol_addtime ,
                                                          @ol_skuid ,
                                                          @ol_source_id ,
                                                          1 ,
                                                          @ol_source_add_time ,
                                                          @ol_box_num ,
                                                          @ol_pm ,
														  @ol_pddate, --生产日期
														  @ol_expirationdate,--过期时间
														  @ol_shelflife,     --保质期
                                                          @ol_gift ,
                                                          @ol_erp_id,
                                                          (select gi_buyingteamid from b_goodsinfo where gi_id=@ol_siid) --买手小组
	                                                    );

                                                SET @ol_id = SCOPE_IDENTITY();
                                        
                                    END
                                ELSE
                                    BEGIN
                                        INSERT  INTO j_add_time_record
                                                ( a_add_time ,
                                                  a_guid
	    		                                )
                                        VALUES  ( @ol_source_add_time ,
                                                  @add_time_not_in
	    		                                )
	    		
                                        
	    		                        IF @isModifyEndNum=1 --修改终止数量
	    		                        BEGIN
	    		                        	UPDATE  pos_allocationList
											SET     all_pause_num = @ol_number,
											        all_pause_box_num=@ol_box_num
											WHERE   all_id = @ol_source_id;
	    		                        END
	    		                        ELSE 
	    		                        	BEGIN
	    		                        		UPDATE  pos_allocationList
												SET     all_pause_num = ISNULL(all_pause_num, 0) + @ol_number,
														all_pause_box_num=all_pause_box_num+@ol_box_num
												WHERE   all_id = @ol_source_id;
	    		                        	END
                                    END
                            END
                        ELSE
                            BEGIN
                              
                                --售后调价
								IF @aspd=1
								BEGIN
									UPDATE j_outStorageList
										SET ol_olddiscount=ol_discount,
											ol_oldcostprice=ol_costprice,
											ol_aspd=@oo_updatemam
									WHERE ol_id = @ol_id;
								END

								--明细更新
                                UPDATE  j_outStorageList
                                SET     ol_siid = @ol_siid ,
                                        ol_number = @ol_number ,
                                        ol_realmoney = @ol_costprice * @ol_number ,
                                        ol_discount = @ol_discount ,
                                        ol_remark = @ol_remark ,
                                        ol_unit = @ol_unit ,
                                        ol_costprice = @ol_costprice ,
                                        ol_skuid = @ol_skuid ,
                                        ol_box_num = @ol_box_num ,
                                        ol_pm = @ol_pm ,
										ol_pddate=@ol_pddate, --生产日期
										ol_expirationdate=@ol_expirationdate,--过期时间
										ol_shelflife=@ol_shelflife,     --保质期
                                        ol_gift = @ol_gift,
                                        ol_buyingteamid = (select gi_buyingteamid from b_goodsinfo where gi_id=@ol_siid)    --买手小组
                                WHERE   ol_id = @ol_id;



                            END
	    
	    
                        SET @start_int = @start_int + 1;
                    END
					end
				else
					begin

						  --匹配单
						if @oo_ismatching=1
			              begin

						  if @oo_source_type=1
						     begin

								DECLARE @pid AS dbo.UDTypeOrderId;
								declare @next int 
								set @next=1
								while @next<=dbo.Get_StrArrayLength(@order_id,',')
								begin
									insert @pid(id)VALUES(dbo.Get_StrArrayStrOfIndex(@order_id,',',@next))
									set @next=@next+1
								end
					
					
								INSERT INTO j_outStorageList
								(ol_eoid , ol_siid , ol_skuid ,ol_pm ,ol_gift,ol_erp_id ,
								 ol_number,ol_discount , ol_unit ,ol_costprice,
								 ol_realmoney,ol_status ,ol_box_num,
							     ol_addtime,
								 ol_source_add_time,
								 ol_source_id
								)	
								SELECT
								@oo_id,so.all_gi_id,so.all_sku_id,'',0,@oo_erp_id,
								so.qty,so.all_discount,so.all_retail_price,so.all_stock_price,
								all_stock_price*so.qty,1,0,
								GETDATE(),
								all_add_time,
								all_id
								FROM dbo.FnAllocationByFIFO(@pid,@orderguid,@oo_erp_id) as so;

								EXEC pro_update_unique_time_source @id = @oo_id,@type = '出库';

							end
						  end 
						  else
						  begin

						     if @oo_source_type=0
						     begin

								MERGE INTO j_outStorageList AS ta
						USING
						(
							SELECT  @oo_id as ol_eoid,gi_id, sku_id,pm,gift,erp_id,
							number,
							discount,--折扣
							importprices,--销售价
							stockprice,--供货价
							orderstatus,
							box_num,
						    slt_id
							FROM  erp_goodslisttemp 
							WHERE orderguid = @orderguid 

					  ) AS so on  ta.ol_siid=so.gi_id AND  ta.ol_skuid=so.sku_id and  ta.ol_eoid=so.ol_eoid and ta.ol_status=1
				      WHEN MATCHED THEN  UPDATE
                           SET  
						   ta.ol_number += so.number,
						   ta.ol_realmoney=((ta.ol_number+so.number)*so.stockprice)
					  WHEN NOT MATCHED THEN
							INSERT 
							(ol_eoid , ol_siid , ol_skuid ,ol_pm ,ol_gift,ol_erp_id ,
							ol_number , 
							ol_discount , --折扣
							ol_unit , --零售价
							ol_costprice, --供货价
							ol_realmoney,--出库金额
							ol_status ,
							ol_box_num,ol_addtime,ol_locationid 
							)
							VALUES
							( so.ol_eoid, so.gi_id, so.sku_id,so.pm,so.gift,so.erp_id,
							 so.number,
							 so.discount,--折扣
							 so.importprices,--销售价
							 so.stockprice,--供货价
							 so.number* so.stockprice,--入库金额
							 so.orderstatus,
							 so.box_num,
							(SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
							SELECT GETDATE() as nows,
                            (SELECT TOP 1 ol_addtime FROM j_outStorageList WHERE ol_siid=so.gi_id AND ol_eoid=so.ol_eoid and ol_gift=so.gift ) AS addtime) AS TT),
							so.slt_id
							);
								
						     end

                        end


						exec pro_setGoodsPurchasePrice @oo_id=@oo_id;
					end


           IF @isInsert = 1
              BEGIN
                 EXEC pro_update_unique_time @id = @oo_id, @type = '出库'
              END
           
	   if @oo_ismatching = 0
	   begin

       IF ((@oo_source_type = 1 AND @isInsert = 1 ) OR @op_type_end != '' )  and  @IsPDA=0 and @orderguid=''
	    BEGIN

		DECLARE @gids TABLE(gi_id int);
		DECLARE @orids TABLE(order_id int);
		DECLARE @pms TABLE(order_id varchar(5000));
		declare @tt int;
		if @good_id <>''
		begin
			set @tt=1;
			while @tt<=dbo.Get_StrArrayLength(@good_id,',')
			begin
			insert @gids(gi_id)VALUES(dbo.Get_StrArrayStrOfIndex(@good_id,',',@tt));
			set @tt=@tt+1;
			end
		end
		if @order_id <>''
		begin
			set @tt=1;
			while @tt<=dbo.Get_StrArrayLength(@order_id,',')
			begin
				insert @orids(order_id)VALUES(dbo.Get_StrArrayStrOfIndex(@order_id,',',@tt));
				set @tt=@tt+1;
			end
		end

		if @pm<>''
		begin
			set @tt=1;
			while @tt<=dbo.Get_StrArrayLength(@pm,',')
			begin
				insert @pms(order_id)VALUES(dbo.Get_StrArrayStrOfIndex(@pm,',',@tt));
				set @tt=@tt+1;
			end
		end
		else
		begin
		    insert @pms(order_id)VALUES('');
		end

		SELECT 
		       @oo_id all_al_id,
			   fd.all_gi_id,
			   fd.all_sku_id,
			   (CASE WHEN tp.all_gi_id IS NULL THEN
			   (fd.all_num -ISNULL(ed.ol_number, 0)-ISNULL(fd.all_pause_num, 0))
			    else
				tp.all_num end )
			    AS all_num,
			   (CASE WHEN tp.all_gi_id IS NULL THEN fd.all_discount else tp.all_discount end ) AS all_discount,
			   (CASE WHEN tp.all_gi_id IS NULL THEN fd.all_retail_price else tp.all_retail_price end ) AS all_retail_price,
			   (CASE WHEN tp.all_gi_id IS NULL THEN fd.all_stock_price else tp.all_stock_price end ) AS all_stock_price,
			   fd.all_status,
			   fd.all_id,
			   fd.all_add_time,
			   (CASE WHEN tp.all_gi_id IS NULL THEN
			   (fd.all_box_num-isnull(ed.ol_box_num,0)-fd.all_pause_box_num) 
			    else
			   tp.all_box_num end )
			   as all_box_num,
			   fd.all_pm, 
			   fd.all_erp_id,
			   fd.all_boxbynum
			   into #pslist
		   FROM   pos_allocationList fd
		   inner join @orids odi on fd.all_al_id=odi.order_id
		   inner join (SELECT DISTINCT gi_id FROM @gids) gis on gis.gi_id=fd.all_gi_id
		   inner join (SELECT DISTINCT order_id FROM @pms) pp on isnull(fd.all_pm,'')=isnull(pp.order_id,'')
		   left join #temp_all tp on fd.all_id=tp.all_id
		   LEFT  JOIN (
					SELECT
					fd.ol_source_id,
					SUM(fd.ol_number) AS ol_number,
					SUM(fd.ol_box_num) as ol_box_num
					FROM ( 
						SELECT 
							   josl.ol_siid,
							   josl.ol_number,
							   josl.ol_source_id,
							   josl.ol_source_add_time,
							   josl.ol_box_num
						FROM   j_outStorage                 AS jos
							   INNER JOIN j_outStorageList  AS josl
									ON  jos.oo_id = josl.ol_eoid
						WHERE  jos.oo_source_type = 1
							   AND josl.ol_status = 1
							   AND jos.oo_status > 0
					) AS fd GROUP BY fd.ol_source_id
			)
		ed ON  ed.ol_source_id = fd.all_id
		where fd.all_status>0 and (fd.all_num -ISNULL(ed.ol_number, 0)-ISNULL(fd.all_pause_num, 0)) > 0


       IF @op_type_end = ''
                BEGIN

                    INSERT  INTO j_outStorageList
                            (   ol_eoid ,
								ol_addtime,
                                ol_siid ,
                                ol_skuid ,
                                ol_number ,
                                ol_discount ,
                                ol_unit ,
                                ol_costprice ,
                                ol_status ,
                                ol_source_id ,
                                ol_source_add_time ,
                                ol_box_num ,
                                ol_pm ,
                                ol_erp_id,
								ol_boxbynum
			                )
                            SELECT 
							all_al_id,
							GETDATE(), 
							all_gi_id,
							all_sku_id,
							all_num,
							all_discount,
							all_retail_price,
							all_stock_price,
							1,
							all_id,
							all_add_time,
							all_box_num,
							all_pm,
							all_erp_id,
							all_boxbynum
							FROM #pslist
			
			
                    UPDATE  j_outStorageList
                    SET     ol_realmoney = ol_number * ol_costprice
                    WHERE   ol_eoid = @oo_id;
			
                    UPDATE  j_outStorage
                    SET     oo_status = 2 ,
                            oo_lastmanid = @oo_addman ,
                            oo_auditdate = GETDATE()
                    WHERE   oo_id = @oo_id;
	    	
                    EXEC pro_update_unique_time_source @type = '出库', @id = @oo_id;

                END
          ELSE
             BEGIN

			   IF @isModifyEndNum=1 --修改终止数量
				BEGIN 
                    UPDATE  pos_allocationList
                    SET     all_pause_num = ISNULL(fd2.all_num, 0),
							all_pause_box_num=ISNULL(fd2.all_box_num, 0)
                    FROM    pos_allocationList fd ,
                            #pslist fd2
                    WHERE   fd.all_id = fd2.all_id
                            --AND fd2.all_add_time NOT IN ( SELECT    fd3.a_add_time
                            --                                FROM      j_add_time_record fd3 WITH ( NOLOCK )
                            --                                WHERE     fd3.a_guid = @add_time_not_in )				
               END
				ELSE
				BEGIN
			 
				UPDATE  pos_allocationList
                    SET     all_pause_num = ISNULL(all_pause_num, 0) + ISNULL(fd2.all_num, 0),
							all_pause_box_num=all_pause_box_num+ISNULL(fd2.all_box_num, 0)
                    FROM    pos_allocationList fd ,
                            #pslist fd2
                    WHERE   fd.all_id = fd2.all_id
                            --AND fd2.all_add_time NOT IN ( SELECT    fd3.a_add_time
                            --                                FROM      j_add_time_record fd3 WITH ( NOLOCK )
                            --                                WHERE     fd3.a_guid = @add_time_not_in )
			    END

				declare @orderids UDTypeOrderId;
				insert into @orderids(Id) select order_id from @orids;
				exec pro_mergeSums @orderids=@orderids, @stockType=8;

			 END
                        

            IF ((@oo_source_type = 1 AND @isInsert = 0 ) OR @op_type_end = '添加修改单据,明细,终止操作' ) 
                BEGIN
                    EXEC pro_mergeAllocationOccupySum @id = @oo_id, @SID = @oo_siid, @cp_id = @oo_cp_id, @good_id = @good_id	--配货出库占用库存
                END
            ELSE
                BEGIN
                    EXEC pro_mergeAllocationOccupySum @id = @oo_id, @SID = @oo_siid, @cp_id = @oo_cp_id, @type = 1	--配货出库占用库存
                END

                    drop table #pslist
					drop table #temp_all

		END
		       
		    -------------(分公司入库退货单,店铺入库退货单)生成出库退货单------------
		   IF((@oo_source_type = 1 or @oo_source_type = 2 or @oo_source_type =3) AND @isInsert = 1 and @oo_source_id >0 and @orderguid<>'' and  @IsPDA=0 )
				begin
			    INSERT  INTO j_outStorageList
                       (ol_eoid , ol_siid , ol_skuid ,ol_pm ,ol_gift,ol_erp_id ,
					    ol_number , 
						ol_discount , --折扣
						ol_unit , --零售价
						ol_costprice, --供货价
						ol_realmoney,--出库金额
						ol_status ,
						ol_box_num,ol_addtime ,
						ol_locationid,
						ol_source_add_time,
						ol_source_id)
				SELECT  @oo_id, gi_id, sku_id,pm,gift,erp_id,
                        number,
						discount,--折扣
						retailprice,--零售价
                        stockprice,--进货价
						summoney,--入库金额
						orderstatus,
						box_num,
						GETDATE(),
						slt_id,
						source_addtime,
						source_id
				FROM  erp_goodslisttemp WHERE orderguid = @orderguid 
				
				EXEC pro_update_unique_time_source @type = '出库', @id = @oo_id;

				if(@oo_source_type = 1)
					begin
					EXEC pro_mergeAllocationOccupySum @id = @oo_id, @SID = @oo_siid, @cp_id = @oo_cp_id, @type = 1	--配货出库占用库存
					end
				end
		    -------------(分公司入库退货单,店铺入库退货单)生成出库退货单------------

			-------------PDA生成出库单------------
			if( (@oo_source_type = 1 or @oo_source_type = 2 or @oo_source_type =3) AND @IsPDA=1)
			begin
			   
			   if(@oo_source_type =1)
			   begin


			   	INSERT  INTO j_outStorageList
                       (ol_eoid , ol_siid , ol_skuid ,ol_pm ,ol_gift,ol_erp_id ,
					    ol_number , 
						ol_discount , --折扣
						ol_unit , --零售价
						ol_costprice, --供货价
						ol_realmoney,--出库金额
						ol_status ,
						ol_box_num,
						ol_source_id,
						ol_source_add_time,
						ol_addtime,
						ol_locationid,
						dol_id )
				SELECT  @oo_id,ed.dol_gi_id, ed.dol_sku_id, ed.dol_batchno ,0, ed.erp_id,
						pk.dp_inspectionnum,
	                    jek.all_discount,
						jek.all_retail_price,
						jek.all_stock_price,
						jek.all_stock_price*pk.dp_inspectionnum,
	                    1,
						0,
						jek.all_id,
						jek.all_add_time,
						getdate(),
						pk.slt_id,  --仓位
						ed.dol_id
						FROM erp_distributionorderlist as ed
						INNER JOIN erp_distributionpicking pk ON pk.dol_id=ed.dol_id
						INNER JOIN v_z_pos_allocationList jek  ON ed.dol_gi_id=jek.all_gi_id AND ed.dol_sku_id=jek.all_sku_id AND jek.all_al_id=@oo_source_id
						WHERE 
						do_id IN (SELECT do_id FROM erp_distributionorder where do_source_id=@oo_source_id and warehousingtype=@warehousingtype and erp_id=@oo_erp_id) 
						AND jek.all_status=1 and ed.erp_id=@oo_erp_id 	 


                --EXEC pro_mergeDistributionorderOccupySum @do_id=@do_id,@type=1

				exec pro_MergeDistributionorderManyOccupySum 1,@oo_source_id,@warehousingtype,@oo_erp_id

			   IF (( @oo_source_type = 1 AND @isInsert = 0 ) OR @op_type_end = '添加修改单据,明细,终止操作' ) 
                            BEGIN
                                EXEC pro_mergeAllocationOccupySum @id = @oo_id, @SID = @oo_siid, @cp_id = @oo_cp_id, @good_id = @good_id	--配货出库占用库存
                            END
                     ELSE
                            BEGIN
                                EXEC pro_mergeAllocationOccupySum @id = @oo_id, @SID = @oo_siid, @cp_id = @oo_cp_id, @type = 1	--配货出库占用库存
                            END

                    

			   end

			   if(@oo_source_type = 2)
			   begin
				INSERT  INTO j_outStorageList
                       (ol_eoid , ol_siid , ol_skuid ,ol_pm ,ol_gift,ol_erp_id ,
					    ol_number , 
						ol_discount , --折扣
						ol_unit , --零售价
						ol_costprice, --供货价
						ol_realmoney,--出库金额
						ol_status ,
						ol_box_num,
						ol_addtime,
						ol_locationid,
						dol_id )
				SELECT  @oo_id,ed. dol_gi_id, ed.dol_sku_id, ed.dol_batchno ,0, ed.erp_id,
						pk.dp_inspectionnum,
	                    jek.el_discount,
						jek.el_unit,
						jek.el_costprice,
						jek.el_costprice*pk.dp_inspectionnum,
	                    1,
						0,
						GETDATE(),
						pk.slt_id,  --仓位
						ed.dol_id
						FROM erp_distributionorderlist as ed
						INNER JOIN erp_distributionpicking pk ON pk.dol_id=ed.dol_id
						INNER JOIN j_enterStoragelist jek ON ed.dol_gi_id=jek.el_siid AND ed.dol_sku_id=jek.el_skuid AND jek.el_eoid=@oo_source_id	
						WHERE 
						do_id IN (SELECT do_id FROM erp_distributionorder where do_source_id=@oo_source_id and warehousingtype=@warehousingtype and erp_id=@oo_erp_id) 
						AND jek.el_status=1 and ed.erp_id=@oo_erp_id  


						--审核单据
				 UPDATE j_enterStorage
						SET eo_is_return_audit = 1,
						eo_lastmanid = @oo_lastmanid,
						eo_auditdate = GETDATE()
						WHERE  eo_id = @oo_source_id;

			   end

			   if(@oo_source_type =3)
			   begin

					INSERT  INTO j_outStorageList
                       (ol_eoid , ol_siid , ol_skuid ,ol_pm ,ol_gift,ol_erp_id ,
					    ol_number , 
						ol_discount , --折扣
						ol_unit , --零售价
						ol_costprice, --供货价
						ol_realmoney,--出库金额
						ol_status ,
						ol_box_num,
						ol_addtime,
						ol_locationid,
						dol_id 
						)
					SELECT  @oo_id,ed. dol_gi_id, ed.dol_sku_id, ed.dol_batchno ,0, ed.erp_id,
						pk.dp_inspectionnum,
	                    jek.inl_discount,
						jek.inl_retail_price,
						jek.inl_stock_price,
						jek.inl_stock_price*pk.dp_inspectionnum,
	                    1,
						0,
						GETDATE(),
						pk.slt_id,  --仓位
						ed.dol_id
						FROM erp_distributionorderlist as ed
						INNER JOIN erp_distributionpicking pk ON pk.dol_id=ed.dol_id
						INNER JOIN pos_inStorageList jek ON ed.dol_gi_id=jek.inl_gi_id AND ed.dol_sku_id=jek.inl_sku_id and jek.inl_in_id=@oo_source_id
						WHERE 
						do_id IN (SELECT do_id FROM erp_distributionorder where do_source_id=@oo_source_id and warehousingtype=@warehousingtype and erp_id=@oo_erp_id) 
						AND ed.erp_id=@oo_erp_id  and jek.inl_status=1


						UPDATE   pos_inStorage
               SET      in_is_audit = 1 ,
                        in_main_audit_man = @oo_takemanid ,
                        in_main_audit_time = GETDATE()
               WHERE    in_id = @oo_source_id
                        AND in_sh_id = @oo_sh_id;


			   end

			  
			   EXEC pro_update_unique_time_source @type = '出库', @id = @oo_id;

			end
			-------------PDA生成出库单------------

			end




			UPDATE j_outStorageList SET 
			       ol_buyingteamid=(select gi_buyingteamid from b_goodsinfo where gi_id=ol_siid),
				   supplyprice=(SELECT supplyprice FROM dbo.FnGoodsPrice(jol.ol_siid,jo.oo_ciid,jo.oo_sh_id,jo.oo_to_cp_id,@oo_jytype)),
				   discount=(SELECT discount FROM dbo.FnGoodsPrice(jol.ol_siid,jo.oo_ciid,jo.oo_sh_id,jo.oo_to_cp_id,@oo_jytype))
			FROM j_outStorageList AS jol 
			INNER JOIN j_outStorage jo ON jol.ol_eoid=jo.oo_id and jol.ol_status>0 
			WHERE jo.oo_id=@oo_id



			

		    IF @oo_source_type>0
			begin
				set @op_type = '审核单据'
			end




			----获取明细的最上级的订单id
			IF @oo_source_type = 1
			begin


			  UPDATE j_outStorageList
			  SET ol_topsource_id = isnull ((SELECT all_source_id 
			                         FROM pos_allocationlist 
			                         WHERE all_id = ol_source_id),0)
			  WHERE ol_eoid=@oo_id

			end

			exec dbo.pro_setPmNumberSum @orderid=@oo_id,@erp_id=@oo_erp_id ,@stockType=2;

        END

		if @op_type='修改单据'
		BEGIN
				UPDATE j_outStorageList SET 
			       ol_buyingteamid=(select gi_buyingteamid from b_goodsinfo where gi_id=ol_siid)
				WHERE ol_eoid =@oo_id
		END
	
        IF @op_type = '删除单据'
            BEGIN
			 
                SELECT  @old_sei_id = fd.oo_siid ,
                        @oo_source_type = oo_source_type
                FROM    j_outStorage fd WITH ( NOLOCK )
                WHERE   fd.oo_id = @oo_id;

				--删除单据
                UPDATE  j_outStorage
                SET     oo_status = 0
                WHERE   oo_id = @oo_id;
              
			    
				--还原配货出库占用库存
                IF @oo_source_type = 1
                    BEGIN

                        EXEC pro_mergeAllocationOccupySum @id = @oo_id, @SID = @old_sei_id, @cp_id = @oo_cp_id,@type = 1;
                        
					END
            END
	    
        IF @op_type = '批量删除明细'
            BEGIN
		
                SELECT  @old_sei_id = fd.oo_siid ,
                        @oo_source_type = oo_source_type
                FROM    j_outStorage fd WITH ( NOLOCK )
                WHERE   fd.oo_id = @oo_id;
	      
                IF @oo_source_id > 0
                    BEGIN
                        UPDATE  pos_allocationList
                        SET     all_status = 0
                        WHERE   all_al_id = @oo_source_id
                                AND all_add_time = @ol_addtime
                                AND all_gi_id = @ol_siid;


                    END
                ELSE
                    BEGIN
                        UPDATE  j_outStorageList
                        SET     ol_status = 0
                        WHERE   ol_eoid = @oo_id
                                AND ol_addtime = @ol_addtime
                                AND ol_siid = @ol_siid;
	        --判断是否为最后一条明细
                        IF ( ( SELECT   COUNT(1) AS COUNT
                               FROM     j_outStorageList AS je WITH ( NOLOCK )
                               WHERE    je.ol_eoid = @oo_id
                                        AND je.ol_status = 1
                             ) = 0 )
                            BEGIN
                                UPDATE  j_outStorage
                                SET     oo_status = 0
                                WHERE   oo_id = @oo_id;
	            --款项删除
                                UPDATE  c_fundorder
                                SET     fo_status = 0
                                WHERE   fo_orderid = ( SELECT   je.oo_no
                                                       FROM     j_outStorage je WITH ( NOLOCK )
                                                       WHERE    je.oo_id = @oo_id
                                                     )
                                        AND fo_cp_id = @oo_cp_id
                            END
           
		   
		    --还原配货出库占用库存
                        IF @oo_source_type = 1
                            BEGIN
                                EXEC pro_mergeAllocationOccupySum @id = @oo_id, @SID = @old_sei_id, @cp_id = @oo_cp_id,
                                    @good_id = @ol_siid	
                            END 

                    END
            END

        IF ((@op_type = '添加修改单据,明细' OR @need_update = 1 OR @op_type = '修改单据' ) AND @isInsert != 1 ) AND @op_type_end = ''
            BEGIN
		
		
	    --得到旧的单据日期
                SELECT  @old_order_date = jt.oo_entrydate
                FROM    j_outStorage AS jt WITH ( NOLOCK )
                WHERE   jt.oo_id = @oo_id;
                IF @old_order_date != @oo_entrydate
                    BEGIN
                        SET @old_order_date_is_changed = 1;
                    END
	    
                SELECT  @old_sei_id = fd.oo_siid
                FROM    j_outStorage fd WITH ( NOLOCK )
                WHERE   fd.oo_id = @oo_id;
	    
                UPDATE  j_outStorage
                SET     oo_to_cp_id=@oo_to_cp_id,
				        oo_sh_id = @oo_sh_id ,
                        oo_ciid = @oo_ciid ,
                        oo_siid = @oo_siid ,
                        oo_takemanid = @oo_takemanid ,
                        oo_remark = @oo_remark ,
                        oo_entrydate = @oo_entrydate ,
                        oo_lastmanid = @oo_lastmanid ,
                        oo_itid = @oo_itid ,
                        oo_updatemam = @oo_addman ,
                        oo_updatetime = GETDATE() ,
                        oo_manual = @oo_manual ,
                        oo_cost = @oo_cost ,
                        oo_freight = @oo_freight ,
                        oo_express = @oo_express ,
                        oo_expressno = @oo_expressno ,
                        oo_jytype = @oo_jytype ,
                        oo_cash = @oo_cash ,
                        oo_gift = @oo_gift ,
                        oo_ismatching = @oo_ismatching
                WHERE   oo_id = @oo_id;
	    
                IF @oo_gift = 1
                    BEGIN
                        UPDATE  j_outStorageList
                        SET     ol_gift = @oo_gift
                        WHERE   ol_eoid = @oo_id
                    END
	    
	    
                IF ( SELECT fd.oo_status
                     FROM   j_outStorage fd WITH ( NOLOCK )
                     WHERE  fd.oo_id = @oo_id
                   ) = 0
                    BEGIN
                        UPDATE  j_outStorage
                        SET     oo_status = 1
                        WHERE   oo_id = @oo_id;
	        --款项删除
                        UPDATE  c_fundorder
                        SET     fo_status = 1
                        WHERE   fo_orderid = ( SELECT   je.oo_no
                                               FROM     j_outStorage je WITH ( NOLOCK )
                                               WHERE    je.oo_id = @oo_id
                                             )
                                AND fo_cp_id = @oo_cp_id
                    END
            END
	
        SET @old_order_date_is_changed = 0;
        IF EXISTS ( SELECT  1 FROM    j_outStorage jos WITH ( NOLOCK ) WHERE   jos.oo_di_id > 0 AND jos.oo_id = @oo_id AND CHARINDEX('网络订单', jos.oo_remark) != 0 )
            BEGIN
                SET @old_order_date_is_changed = 1;
            END
	
        IF (@isInsert = 1 OR @old_order_date_is_changed = 1) AND @op_type_end = ''
            BEGIN
				--旧的单据号
                DECLARE @oldno VARCHAR(50) = '';
                SELECT  @oldno = je.oo_no
                FROM    j_outStorage je WITH ( NOLOCK )
                WHERE   je.oo_id = @oo_id;
	    
				--凭证号生成
				--更新凭证号 
                DECLARE @tableName VARCHAR(50) = 'j_outStorage'
                DECLARE @idField VARCHAR(50) = 'oo_id'
                DECLARE @idValue INT = @oo_id;
	    
                DECLARE @dateField VARCHAR(50) = 'oo_entrydate'
                DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @oo_entrydate, 23)
	    
                DECLARE @noField VARCHAR(50) = 'oo_no'
                DECLARE @prevTxt VARCHAR(50) = @myprevTxt
                DECLARE @outno VARCHAR(100) = ''
	    
	    
                DECLARE @while INT = 0;
                WHILE @while = 0
                    BEGIN
				--得到凭证号
                        EXECUTE [pro_gen_orderNo] @tableName, @idField, @idValue, @dateField, @dateValue, @noField,
                            @prevTxt, @outno OUTPUT, 0, @oo_cp_id
                        BEGIN TRY
	        	--更新
                            UPDATE  j_outStorage
                            SET     oo_no = @outno ,
                                    pzone = dbo.Get_StrArrayStrOfIndex(@outno, '-', 1) ,
                                    pztwo = dbo.Get_StrArrayStrOfIndex(@outno, '-', 2) ,
                                    pzthree = dbo.Get_StrArrayStrOfIndex(@outno, '-', 3)
                            WHERE   oo_id = @oo_id;
	        	
	        	--更新成功,赋值,结束循环
                            SET @while = 1;
                        END TRY
                        BEGIN CATCH
                            PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
                        END CATCH
                    END
                IF @isInsert != 1
                    BEGIN
				--更新了凭证号  --更新款项中的凭证号
                        IF EXISTS (SELECT  * FROM  c_fundorder cf WITH ( NOLOCK ) WHERE cf.fo_orderid = @oldno AND cf.fo_cp_id = @oo_cp_id )
                            BEGIN
                                UPDATE  c_fundorder
                                SET     fo_orderid = @outno
                                WHERE   fo_orderid = @oldno
                                        AND fo_cp_id = @oo_cp_id
                            END
                    END
            END

	    --网络订单
	   	if CHARINDEX('网络订单', @oo_remark) != 0
		begin
			set @op_type='审核单据'
		end

	
	   DECLARE @finished_money DECIMAL(15, 2) = 0; --成品金额
	   DECLARE @parts_money    DECIMAL(15, 2) = 0; --辅品金额

		--款项更新
        IF @op_type='审核单据'
        BEGIN
			    
                UPDATE  j_outStorage
                SET     oo_status = 2 ,
						
                        oo_lastmanid = @oo_lastmanid ,
                        oo_auditdate = GETDATE()
                WHERE   oo_id = @oo_id;

				DECLARE @mymoney DECIMAL(15, 2) = 0; --赠送金额
				DECLARE @giftedmoney DECIMAL(15, 2) = 0; --实收金额	
				DECLARE @thiyetmoney DECIMAL(15, 2) = 0;	
				DECLARE @orderNo VARCHAR(50); --单据号
				

				SELECT  @orderNo = je.oo_no,
                        @oo_ciid=je.oo_ciid,
						@oo_sh_id=je.oo_sh_id,
						@oo_gift=oo_gift,
						@oo_cash=oo_cash,
						@oo_to_cp_id=je.oo_to_cp_id,
						@oo_entrydate=je.oo_entrydate,
						@oo_freight=oo_freight,
						@oo_cost=oo_cost,
						@oo_cp_id=oo_cp_id,
						@oo_di_id=oo_di_id,
						@oo_erp_id=oo_erp_id,
						@oo_type=oo_type,
						@oo_remark=oo_remark
				FROM    j_outStorage je
				WHERE   je.oo_id = @oo_id;

				--成本价*数量
				SELECT  @mymoney = SUM(je.ol_realmoney)
				FROM    j_outStorageList je WITH ( NOLOCK )
				WHERE   je.ol_eoid = @oo_id
                AND je.ol_status = 1
                AND ISNULL(je.ol_gift, 0) = 0 

			    --成品金额
				SELECT  @finished_money = SUM(je.ol_realmoney)
				FROM    j_outStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.ol_siid = bg.gi_id
				WHERE   je.ol_eoid = @oo_id
                AND je.ol_status = 1
                AND ISNULL(je.ol_gift, 0) = 0 and bg. gi_ownership=0

				--辅品金额
				SELECT  @parts_money = SUM(je.ol_realmoney)
				FROM    j_outStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.ol_siid = bg.gi_id
				WHERE   je.ol_eoid = @oo_id
                AND je.ol_status = 1
                AND ISNULL(je.ol_gift, 0) = 0 and bg. gi_ownership=1


				--现金交易
				IF @oo_cash = 1 SET @thiyetmoney = @mymoney;

				SELECT  @giftedmoney = SUM(je.ol_realmoney) FROM j_outStorageList je WITH ( NOLOCK ) 
				WHERE   je.ol_eoid = @oo_id AND je.ol_status = 1 AND ISNULL(je.ol_gift, 0) != 0

				--整单赠送
				IF @oo_gift = 1
				BEGIN
					SELECT  @giftedmoney = SUM(je.ol_realmoney)
					FROM  j_outStorageList je WITH ( NOLOCK )
					WHERE   je.ol_eoid = @oo_id AND je.ol_status = 1
					SET @mymoney = 0
				END
		
				DECLARE @rkje DECIMAL(15, 2) = 0;
				DECLARE @rkthje DECIMAL(15, 2) = 0;
				DECLARE @myremark VARCHAR(50) = '';

				IF @oo_type = 0
				 BEGIN
					SET @thiyetmoney = -@thiyetmoney;
					SET @rkthje = @mymoney;
					SET @myremark = '出库退货应收';
				END
				ELSE
				BEGIN
					SET @rkje = @mymoney;
					SET @myremark = '出库应收';
				END
		
                DECLARE @RC INT = 0;
               
                DECLARE @fo_type TINYINT = 0;
                DECLARE @fo_ciid INT = @oo_ciid;
                DECLARE @fo_bs VARCHAR(20) = 'X';
                DECLARE @fo_orderid VARCHAR(50) = @orderNo;
                DECLARE @fo_takeman VARCHAR(50) = '';
                DECLARE @fo_ticketno VARCHAR(50) = '';
                DECLARE @fo_realmoney DECIMAL(15, 2) = @rkje;
                DECLARE @fo_thiyetmoney DECIMAL(15, 2) = @thiyetmoney;
                DECLARE @fo_ofdate DATETIME = @oo_entrydate;
                DECLARE @fo_remark VARCHAR(200) = @myremark;
                DECLARE @fo_lastman VARCHAR(50) = '';
                DECLARE @fo_status TINYINT = 1;
                DECLARE @fo_outmoney DECIMAL(15, 2) = @rkthje; --垫付运费
                DECLARE @fo_admoney DECIMAL(15, 2) = @oo_freight; --其他应收
                DECLARE @fo_otheronmoney DECIMAL(15, 2) = @oo_cost; --其他应付
                DECLARE @fo_otheoutmoney DECIMAL(15, 2) = 0;
                DECLARE @fo_givemoney DECIMAL(15, 2) = @giftedmoney;
                DECLARE @fo_ensuremoney DECIMAL(15, 2) = 0;
                DECLARE @fo_subscription DECIMAL(15, 2) = 0;
                DECLARE @fo_no VARCHAR(50) = '';
                DECLARE @fo_userorderno VARCHAR(50) = '';
                DECLARE @fo_shid INT = @oo_sh_id;
                DECLARE @fo_to_cpid INT = @oo_to_cp_id;
                DECLARE @outResult INT = 0;

				DECLARE @fo_finished_money DECIMAL(15, 2)= @finished_money;
				DECLARE @fo_parts_money DECIMAL(15, 2)= @parts_money;

				--更新帐款
                EXECUTE @RC = [pro_c_fundorder_op] @fo_id = @fo_id, @fo_type = @fo_type, @fo_ciid = @fo_ciid,
                    @fo_bs = @fo_bs, @fo_orderid = @fo_orderid, @fo_takeman = @fo_takeman, @fo_ticketno = @fo_ticketno,
                    @fo_realmoney = @fo_realmoney, @fo_thiyetmoney = @fo_thiyetmoney, @fo_ofdate = @fo_ofdate,
                    @fo_remark = @fo_remark, @fo_lastman = @fo_lastman, @fo_status = @fo_status,
                    @fo_outmoney = @fo_outmoney, @fo_admoney = @fo_admoney, @fo_otheronmoney = @fo_otheronmoney,
                    @fo_otheoutmoney = @fo_otheoutmoney, @fo_givemoney = @fo_givemoney,
                    @fo_ensuremoney = @fo_ensuremoney, @fo_subscription = @fo_subscription, @fo_no = @fo_no,
                    @fo_userorderno = @fo_userorderno, @outResult = @outResult OUTPUT, @fo_cp_id = @oo_cp_id,
                    @fo_di_id = @oo_di_id, @fo_shid = @fo_shid, @fo_to_cpid = @fo_to_cpid, @fo_erp_id = @oo_erp_id,
                    @fo_order_id = @oo_id,@fo_finished_money=@finished_money,
					@fo_parts_money=@parts_money,
					@fo_custom_remark=@oo_remark
                IF @RC = 0
                    BEGIN
                        RAISERROR ('款项更新失败!',16,1,N'number',5);
                        GOTO theRollback;
                    END

					--将需要推送的消息插入消息队列表里
				IF @oo_sh_id >0
				BEGIN
				set @data='{"WarehousingType":"2","source_id":"'+CONVERT(VARCHAR(50),@oo_id) +'","source_no":"'+CONVERT(VARCHAR(50),@orderNo)+'","date":"'+ CONVERT(VARCHAR(50),  CONVERT(varchar(100),@oo_entrydate, 20))+'"}';

				EXECUTE pro_erp_pushmessage_op @pm_name='待入库单',@ciid=@oo_ciid,@sh_id=@oo_sh_id,@cp_id=@oo_cp_id,@erp_id=@oo_erp_id,@pm_data=@data,@pm_target='Pos_PushOrder',@pm_type=1
				END
            END

		IF @op_type = '取消审核单据'
	    BEGIN
				

				

				SELECT 
			    @fo_id=cf.fo_id,
				@oo_cp_id=cf.fo_cp_id
				FROM c_fundorder cf 
				WHERE cf.fo_order_id=@oo_id and cf.fo_type=0



                UPDATE  j_outStorage
                SET     oo_status = 1
                WHERE   oo_id = @oo_id;


			  IF @fo_id>0
                 BEGIN


				    DECLARE @erp_id int=0;
				    select @erp_id=cp_erp_id from companyinfo where cp_id=@oo_cp_id
					if EXISTS(SELECT * FROM s_system_set AS sss WHERE sss.s_key='fundorderreconciliation' AND sss.s_erp_id=@erp_id AND sss.s_value=1)
	                   begin

							update c_fundorder set fo_status=1 where fo_id=@fo_id;
							--生成明细报表
							---exec pro_merge_c_fundorder_reconciliation @fo_id=@fo_id;
							SET @tdoc_xml = '{ "fo_id":"' + CONVERT(VARCHAR(50), @fo_id) + '"}';
							EXEC pro_apiqueue_op 
									@tdoc_method = 'fundorderreconciliation', 
									@tdoc_xml = @tdoc_xml, 
									@tdoc_erp_id =@erp_id, 
									@tdoc_cp_id=@oo_cp_id,
									@tdoc_state = 0;	

					   end
					   else
					   begin

					   --检查帐款状态
						IF EXISTS(SELECT * FROM c_fundorder cf WHERE cf.fo_order_id=@oo_id and cf.fo_status=2 and cf.fo_type=0)
							begin
								set @ERROR_MESSAGE='帐款已审核,禁止取消审核单据!';
								GOTO theRollback;
							end

					   end


					--款项删除
                        UPDATE  c_fundorder
                        SET     fo_status = 0
                        WHERE   fo_id = @fo_id
                        AND fo_cp_id = @oo_cp_id

						EXEC pro_merge_fundorder @fo_id=@fo_id;
                END

				
		END


		--单据信息统计
        UPDATE  j_outStorage
        SET     oo_realmoney = vj.ol_realmoney ,  --实际金额
                oo_num =  vj.ol_number, --总数量
				oo_totalboxnum=vj.ol_box_num
        FROM    j_outStorage je,
		        vi_j_outStorageList_sum vj
        WHERE  je.oo_id=vj.ol_eoid 
		       and  je.oo_id = @oo_id
			   
        UPDATE  j_outStorage
        SET     al_vo = ( SELECT    al_vo
                          FROM      dbo.pos_allocation AS bs WITH ( NOLOCK )
                          WHERE     ( al_id = jis.oo_source_id )
                        ) ,
                ci_name = ( SELECT  ci_name
                            FROM    dbo.b_clientinfo AS bs WITH ( NOLOCK )
                            WHERE   ( ci_id = jis.oo_ciid )
                          ) ,
                ci_province = ( SELECT  ci_province
                                FROM    dbo.b_clientinfo AS bs WITH ( NOLOCK )
                                WHERE   ( ci_id = jis.oo_ciid )
                              ) ,
                ci_city = ( SELECT  ci_city
                            FROM    dbo.b_clientinfo AS bs WITH ( NOLOCK )
                            WHERE   ( ci_id = jis.oo_ciid )
                          ) ,
                oo_sh_id_txt = ( SELECT sh_name
                                 FROM   dbo.pos_shop AS bs WITH ( NOLOCK )
                                 WHERE  ( sh_id = jis.oo_sh_id )
                               ) ,
                sh_province = ( SELECT  province
                                FROM    dbo.pos_shop AS bs WITH ( NOLOCK )
                                WHERE   ( sh_id = jis.oo_sh_id )
                              ) ,
                sh_city = ( SELECT  city
                            FROM    dbo.pos_shop AS bs WITH ( NOLOCK )
                            WHERE   ( sh_id = jis.oo_sh_id )
                          ) ,
                ci_code = ( SELECT  ci_code
                            FROM    dbo.b_clientinfo AS bs WITH ( NOLOCK )
                            WHERE   ( ci_id = jis.oo_ciid )
                          ) ,
                sei_name = ( SELECT sei_name
                             FROM   dbo.b_storageinfo AS bs WITH ( NOLOCK )
                             WHERE  ( sei_id = jis.oo_siid )
                           ) ,
                takeman = ( SELECT  si_name
                            FROM    dbo.b_stafftinfo AS bs WITH ( NOLOCK )
                            WHERE   ( si_id = jis.oo_takemanid )
                          ) ,
                oo_addman_txt = ( SELECT    si_name
                                  FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
                                  WHERE     ( si_id = jis.oo_addman )
                                ) ,
                oo_updatemam_txt = ( SELECT si_name
                                     FROM   dbo.b_stafftinfo AS bs WITH ( NOLOCK )
                                     WHERE  ( si_id = jis.oo_updatemam )
                                   ) ,
                oo_lastman = ( SELECT   si_name
                               FROM     dbo.b_stafftinfo AS bs WITH ( NOLOCK )
                               WHERE    ( si_id = jis.oo_lastmanid )
                             ) ,
                oo_to_cp_id_txt = ( SELECT  cp_name
                                    FROM    dbo.companyinfo AS bs WITH ( NOLOCK )
                                    WHERE   ( cp_id = jis.oo_to_cp_id )
                                  ) ,
                cp_province = ( SELECT  cp_province
                                FROM    dbo.companyinfo AS bs WITH ( NOLOCK )
                                WHERE   ( cp_id = jis.oo_to_cp_id )
                              ) ,
                cp_city = ( SELECT  cp_city
                            FROM    dbo.companyinfo AS bs WITH ( NOLOCK )
                            WHERE   ( cp_id = jis.oo_to_cp_id )
                          ) ,
                in_status = ( SELECT TOP 1
                                        in_status
                              FROM      pos_inStorage fd
                              WHERE     fd.in_source_id = jis.oo_id
                                        AND fd.in_source = 1
                                        AND fd.in_status > 0
                            )
        FROM    j_outStorage jis
        WHERE   jis.oo_id = @oo_id;

		SELECT  @old_sei_id = fd.oo_siid ,
               @oo_source_type = oo_source_type
        FROM   j_outStorage fd WITH ( NOLOCK )
        WHERE   fd.oo_id = @oo_id;

	    --更新配货的执行数量
		IF @oo_source_type = 1
           BEGIN

			UPDATE  pos_allocationList 
					 SET all_num_ed=ISNULL((
					 SELECT sum(josl.ol_number) AS ol_number 
					 FROM j_outStorage AS jos WITH (NOLOCK) INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) 
						ON jos.oo_id = josl.ol_eoid 
						WHERE jos.oo_status<>0 AND jos.oo_source_type=1 and josl.ol_source_id=st.all_id AND josl.ol_status<>0 AND josl.ol_status = 1	
					), 0)
					FROM 
					pos_allocationList st 
					INNER JOIN (
					SELECT ol_source_id AS source_id FROM j_outStorageList AS josl  WHERE josl.ol_eoid=@oo_id AND josl.ol_status=1
			 ) AS sc ON st.all_status=1 and st.all_id=sc.source_id

         end

		--售后不计算存库
		if @oo_id>0 and @aspd=0
		begin

			exec pro_mergebyErpStocklog @op_type=@op_type,@stockType=2,@orderid=@oo_id;
			IF @@ERROR <> 0
			BEGIN
                SET @return_no = 0;
                GOTO theRollback;
			END
			exec pro_instructionstate @orderid=@oo_id ,@type=1;

		END
		else
		begin

			DECLARE @oo_no VARCHAR(50) = '';
		    SELECT  @oo_no = oo_no
                      FROM    j_outStorage WITH ( NOLOCK )
             WHERE   oo_id = @oo_id;

		    --售后分润重橷计算
			SET @tdoc_xml = '{"said":"' + CONVERT(VARCHAR(50), @oo_id) + '","type":"1","cp_id":"' + CONVERT(VARCHAR(50), @oo_cp_id) + '"}';
			EXEC pro_apiqueue_op @tdoc_target='', @tdoc_action='', @tdoc_method = 'royaltyscheme', @tdoc_xml = @tdoc_xml, @tdoc_erp_id =@oo_erp_id, @tdoc_state = 0,
			@tdoc_no=@oo_no, @tdoc_cp_id=@oo_cp_id;
		end

		
		exec pro_mergesingleSums @orderid=@oo_id, @stockType=2;
		
		--售后调整
        if @aspd=1
		begin

		   select 
			 @oo_type=oo_type,
			 @oo_cp_id= oo_cp_id,
			 @oo_entrydate=oo_entrydate
		   from j_outStorage where oo_id=@oo_id

			--月报表
			IF EXISTS(SELECT TOP 1 m_month FROM j_month_report WHERE reporttype=0 AND company_id=@oo_cp_id AND  m_year=DATEPART(YEAR,@oo_entrydate) AND m_month=DATEPART(MONTH,@oo_entrydate))	
			BEGIN
				set @ERROR_MESSAGE='您所要操作的数据已生成月报表,数据已被锁定,禁止操作!'
				GOTO theRollback;
			END


			--日报表
			IF EXISTS(SELECT TOP 1 m_day FROM j_month_report WHERE reporttype=1 AND company_id=@oo_cp_id AND  m_year=DATEPART(YEAR,@oo_entrydate) AND m_month=DATEPART(MONTH,@oo_entrydate) AND m_day=DATEPART(day,@oo_entrydate))
			BEGIN
				set @ERROR_MESSAGE='您所要操作的数据已生成日报表,数据已被锁定,禁止操作!'
				GOTO theRollback;
			END

			SELECT  @ol_realmoney = SUM(je.ol_realmoney) 
			FROM  j_outStorageList je WITH ( NOLOCK ) 
			WHERE je.ol_status = 1 AND je.ol_eoid = @oo_id and ol_gift=0 
			GROUP BY je.ol_eoid;

			DECLARE @ol_givemoney DECIMAL(10, 2)=0.00;
			SELECT @ol_givemoney = SUM(je.ol_realmoney) FROM  j_outStorageList je WITH ( NOLOCK ) 
			WHERE je.ol_status = 1 AND je.ol_eoid = @oo_id and ol_gift=1 
			GROUP BY je.ol_eoid;
 
			--成品金额
			SELECT  @finished_money = SUM(je.ol_realmoney)
			FROM    j_outStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.ol_siid = bg.gi_id
			WHERE   je.ol_eoid = @oo_id
			AND je.ol_status = 1
			AND ISNULL(je.ol_gift, 0) = 0 and bg. gi_ownership=0

			--辅品金额
			SELECT  @parts_money = SUM(je.ol_realmoney)
			FROM    j_outStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.ol_siid = bg.gi_id
			WHERE   je.ol_eoid = @oo_id
			AND je.ol_status = 1
			AND ISNULL(je.ol_gift, 0) = 0 and bg. gi_ownership=1

			if @oo_type=0
			begin
				update c_fundorder 
				SET fo_outmoney =@ol_realmoney,
				 fo_finished_money=@finished_money,
				 fo_parts_money=@parts_money
				WHERE fo_order_id=@oo_id AND fo_type=0 ;
			end
			else
			begin
				update c_fundorder SET 
				fo_realmoney =@ol_realmoney, 
				fo_givemoney =@ol_givemoney,
				fo_finished_money=@finished_money,
			    fo_parts_money=@parts_money
				WHERE fo_order_id=@oo_id AND fo_type=0;
			end
			
		    SELECT 
				@fo_id=cf.fo_id
			FROM c_fundorder cf 
			WHERE cf.fo_order_id=@oo_id and cf.fo_type=0;

			EXEC pro_merge_fundorder @fo_id=@fo_id;
		end


        IF @@ERROR <> 0
            BEGIN
				--生成单据异常，回滚操作
                theRollback:
				
				SET @result = '0';

                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN;

                if @ERROR_MESSAGE<>''
				BEGIN
					RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);	 
                end

                RETURN @return_no;
            END
        ELSE
            BEGIN
                IF @isInsert = 1
                    SET @result = CONVERT(VARCHAR(50), @oo_id);
                ELSE
                    BEGIN
                        IF @op_type = '添加修改单据,明细' and @orderguid=''
                            AND @op_type_end = ''
                            SET @result = CONVERT(VARCHAR(50), @ol_id);
                        ELSE
                            SET @result = '1';
                    END

                IF @@TRANCOUNT > 0
                    COMMIT TRAN;
            END
    END
go

