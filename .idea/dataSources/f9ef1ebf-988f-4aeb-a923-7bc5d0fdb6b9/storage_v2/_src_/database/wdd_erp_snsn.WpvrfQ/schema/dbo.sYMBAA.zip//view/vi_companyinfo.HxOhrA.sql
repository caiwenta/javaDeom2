
CREATE VIEW [dbo].[vi_companyinfo]
AS
select cp_id,cp_name,cp_phone,cp_fax,cp_province,cp_city,cp_county,cp_address from dbo.companyinfo  --公司信息
UNION ALL
select  
ci_id as cp_id,ci_name as cp_name,ci_phone as cp_phone,ci_fax as cp_fax, ci_province as  cp_province,ci_city as cp_city,ci_county as  cp_county,ci_address as  cp_address
from dbo.b_clientinfo  
UNION ALL
select sh_id as cp_id,sh_name as cp_name,phone as cp_phone,fax as cp_fax,province as cp_province,city as cp_city,county as cp_county,[address] cp_address from dbo.pos_shop  --店铺信息


go

