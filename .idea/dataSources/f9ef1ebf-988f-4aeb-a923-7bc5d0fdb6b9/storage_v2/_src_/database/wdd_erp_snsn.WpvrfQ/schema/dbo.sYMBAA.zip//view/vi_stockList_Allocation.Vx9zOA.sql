

CREATE VIEW [dbo].[vi_stockList_Allocation]
AS
SELECT st.all_gi_id            AS ogl_gi_id,
       le.al_st_id,
       st.all_sku_id           AS ogl_sku_id,
       le.al_cp_id,
       SUM(st.all_num) - ISNULL(ou.ol_number, 0) AS all_num,
       SUM(st.all_num)         AS num,
       '' AS                      gi_name,
       '' AS                      gi_code,
       ou.ol_number,
       le.al_id,
       st.all_id
FROM   dbo.pos_allocationList  AS st
       LEFT OUTER JOIN dbo.pos_allocation AS le
            ON  st.all_al_id = le.al_id
       LEFT OUTER JOIN (
                SELECT
                       ol_siid,
                       ol_source_add_time,
                       ol_source_id,
                       SUM(ol_number) AS ol_number
                FROM   dbo.vi_allocation_outed
                GROUP BY
                       ol_siid,
                       ol_source_add_time,
                       ol_source_id
            )                  AS ou
            ON  ou.ol_source_id = st.all_id
WHERE  (st.all_status = 1)
       AND (le.al_status > 0)
GROUP BY
       le.al_source_id,
       st.all_gi_id,
       le.al_cp_id,
       le.al_st_id,
       st.all_source_add_time,
       st.all_source_id,
       ou.ol_number,
       st.all_sku_id,
       le.al_id,
       st.all_id
go

