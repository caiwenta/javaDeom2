CREATE VIEW [dbo].[v_z_instructionNoticeListgroupby]
	AS 
SELECT 
bg.gi_skus,
bg.gi_code,
bg.gi_barcode,
bg.gi_name,
bg.gi_unit_name,
list.* 
FROM (
	
SELECT 
la.inl_in_id,
la.inl_gi_id,
la.inl_gift,
la.inl_pm,
la.inl_erp_id,
SUM(inl_num) AS inl_num,
MAX(inl_sku_id) AS inl_sku_id,
SUM(inl_retail_money) AS inl_retail_money,
CONVERT(DECIMAL(10, 2), AVG(inl_retail_price)) AS inl_retail_price,
CONVERT(DECIMAL(10, 2), AVG(inl_stock_price)) AS inl_stock_price,
CONVERT(DECIMAL(10, 2), AVG(inl_discount)) AS inl_discount,
SUM(inl_money) AS inl_money,
MAX(inl_add_time) AS inl_add_time
FROM erp_instructionNoticeList la
WHERE la.inl_status=1
GROUP BY la.inl_in_id,la.inl_gi_id,la.inl_gift,la.inl_erp_id,inl_pm

) AS list
LEFT JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON list.inl_gi_id = bg.gi_id
go

