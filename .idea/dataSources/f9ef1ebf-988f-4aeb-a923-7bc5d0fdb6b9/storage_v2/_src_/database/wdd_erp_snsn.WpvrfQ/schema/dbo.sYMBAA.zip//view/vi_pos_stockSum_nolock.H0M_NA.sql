CREATE VIEW [dbo].[vi_pos_stockSum_nolock] AS 
SELECT shid,
       sid,
       gid,
       skuid,
       SUM(CASE WHEN sl.countType = 1 THEN sl.gnum ELSE - sl.gnum END) AS gnum
FROM   dbo.vi_pos_stockList_nolock AS sl
GROUP BY
       shid,
       sid,
       gid,
       skuid
go

