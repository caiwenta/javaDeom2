CREATE PROCEDURE [dbo].[pro_commoditysales]
	 @date DATETIME='2017-10-26',
	 @erp_id int=0
AS

DELETE [erp_commoditysales] where [date]=@date AND [gi_erp_id]=@erp_id 

INSERT INTO [dbo].[erp_commoditysales] 
           ([date]
           ,[gum_pos]
           ,[gum_pos_no_sku]
           ,[gum_j]
           ,[gum_j_no_sku]
           ,[sal_num_dealine]
           ,[sal_num_date]
           ,[gi_id]
           ,[gss_id]
           ,[gi_erp_id])
select 
@date AS date, 

(SELECT sum(CASE WHEN sl_countType=1 THEN sl_number ELSE-sl_number END) as gnum FROM (select psl.*,bgs.colorid,vbg.* from pos_stocklog AS psl  WITH (NOLOCK) left join v_goodsinfo Vbg on vbg.gi_id=psl.sl_giid and vbg.gi_status>0  left join b_goodsruleset bgs on psl.sl_giid=bgs.gi_id and psl.sl_skuid=bgs.gss_id) AS psl WHERE sl_status<>0 AND (convert(varchar(50),sl_order_date,23)=@date or sl_type=11) and psl.sl_giid=vbg.gi_id and psl.sl_skuid=bgs.gss_id)as gum_pos,

(SELECT sum(CASE WHEN sl_countType=1 THEN sl_number ELSE-sl_number END) as gnum FROM (select psl.*,bgs.colorid,vbg.* from pos_stocklog AS psl  WITH (NOLOCK) left join v_goodsinfo Vbg on vbg.gi_id=psl.sl_giid and vbg.gi_status>0  left join b_goodsruleset bgs on psl.sl_giid=bgs.gi_id and psl.sl_skuid=bgs.gss_id) AS psl WHERE sl_status<>0 AND (convert(varchar(50),sl_order_date,23)=@date or sl_type=11) and psl.sl_giid=vbg.gi_id and psl.sl_skuid is null)as gum_pos_no_sku,

(SELECT sum(Case when js.sl_counttype=1 Then js.sl_number Else -js.sl_number End) AS gnum FROM (select psl.*,bgs.colorid,vbg.* from j_stocklog AS psl  WITH (NOLOCK) left join v_goodsinfo Vbg on vbg.gi_id=psl.sl_giid and vbg.gi_status>0  left join b_goodsruleset bgs on psl.sl_giid=bgs.gi_id and psl.sl_skuid=bgs.gss_id) AS js WHERE sl_status>0 and (convert(varchar(50),sl_order_date,23)=@date or sl_type=3) and js.sl_giid=vbg.gi_id and js.colorid=bgs.colorid)as gum_j,

(SELECT sum(Case when js.sl_counttype=1 Then js.sl_number Else -js.sl_number End) AS gnum FROM (select psl.*,bgs.colorid,vbg.* from j_stocklog AS psl  WITH (NOLOCK) left join v_goodsinfo Vbg on vbg.gi_id=psl.sl_giid and vbg.gi_status>0  left join b_goodsruleset bgs on psl.sl_giid=bgs.gi_id and psl.sl_skuid=bgs.gss_id) AS js WHERE sl_status>0 and (convert(varchar(50),sl_order_date,23)=@date or sl_type=3) and js.sl_giid=vbg.gi_id and js.sl_skuid is null )as gum_j_no_sku,

(select sum(sal_num)sal_num from(select sal_num= ISNULL(CASE WHEN sal_is_return = 1 OR sal_is_change = 1 THEN -ABS(sal_num) WHEN sal_is_gift = 1 OR sal_is_in = 1 THEN 0 ELSE sal_num END,0)from (select * from pos_saleList psl left join b_goodsruleset bgs on psl.sal_sku_id=bgs.gss_id) psl left join pos_sale ps on psl.sal_sa_id=ps.sa_id where convert(varchar(50),sa_date,23) <= @date  and psl.sal_gi_id=vbg.gi_id and psl.sal_sku_id=isnull(bgs.gss_id,0) and sal_status>0 and sa_status>0)as t )as sal_num_dealine,


(select sum(sal_num)sal_num from(select sal_num= ISNULL(CASE WHEN sal_is_return = 1 OR sal_is_change = 1 THEN -ABS(sal_num) WHEN sal_is_gift = 1 OR sal_is_in = 1 THEN 0 ELSE sal_num END,0),sa_date from (select * from pos_saleList psl left join b_goodsruleset bgs on psl.sal_sku_id=bgs.gss_id) psl left join pos_sale ps on psl.sal_sa_id=ps.sa_id where convert(varchar(50),sa_date,23) = @date  and psl.sal_gi_id=vbg.gi_id and psl.sal_sku_id=isnull(bgs.gss_id,0) and sal_status>0 and sa_status>0)as t )as sal_num_date,


vbg.gi_id,
gss_id,
gi_erp_id
from v_goodsinfo vbg 
left join b_goodsruleset bgs on vbg.gi_id=bgs.gi_id and vbg.gi_status>0 and bgs.gs_status>0 
where gi_erp_id=@erp_id
go

