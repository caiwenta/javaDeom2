

CREATE PROCEDURE [dbo].[pro_pos_cost_op]
	@co_id INT,
	@co_sh_id INT,
	@co_vo VARCHAR(50),
	@co_no VARCHAR(50),
	@co_order_man INT,
	@co_status INT,
	@co_add_man INT,
	@co_add_time DATETIME,
	@co_update_man INT,
	@co_update_time DATETIME,
	@co_audit_man INT,
	@co_audit_time DATETIME,
	 
	 --明细
	@col_id INT,
	@col_co_id INT,
	@col_date DATETIME,
	@col_discount DECIMAL(10, 2),
	@col_divide DECIMAL(10, 2),
	@col_divide_money DECIMAL(10, 2),
	@col_withhold DECIMAL(10, 2),
	@col_mgn_money DECIMAL(10, 2),
	@col_co_money DECIMAL(10, 2),
	@col_salary DECIMAL(10, 2),
	@col_other_money DECIMAL(10, 2),
	@col_remark VARCHAR(50),
	@col_status INT,
	 --操作类型(1:添加单据,添加明细 2:修改明细  3.修改单据  4:删除单据,删除明细 5:删除明细 6.审核  7.取消审核 8.添加明细 9.添加单据
	@op_type INT = 0,
	@outResult INT OUTPUT
AS
BEGIN
	--前缀	
	DECLARE @myprevTxt VARCHAR(50) = '';
	SET @myprevTxt = 'FYDJ';
	--是否为添加操作
	DECLARE @isInsert INT = 0;
	--得到旧的款项时间
	DECLARE @olddate DATETIME;
	
	--添加单据
	IF @op_type = 1
	   OR @op_type = 9
	   AND @co_id = 0
	BEGIN
	    --是添加操作
	    SET @isInsert = 1;
	    --添加
	    INSERT INTO [pos_cost]
	      (
	        [co_sh_id],
	        [co_vo],
	        [co_no],
	        [co_order_man],
	        [co_status],
	        [co_add_man],
	        [co_add_time],
	        [co_update_man],
	        [co_update_time],
	        [co_audit_man],
	        [co_audit_time]
	      )
	    VALUES
	      (
	        @co_sh_id,
	        @co_vo,
	        @co_no,
	        @co_order_man,
	        @co_status,
	        @co_add_man,
	        @co_add_time,
	        @co_update_man,
	        @co_update_time,
	        @co_audit_man,
	        @co_audit_time
	      )
	    SET @co_id = SCOPE_IDENTITY()
	    IF @isInsert = 1
	    BEGIN
	        --更新凭证号	
	        DECLARE @tableName VARCHAR(50) = 'pos_cost'
	        DECLARE @idField VARCHAR(50) = 'co_id'
	        DECLARE @idValue INT = @co_id
	        DECLARE @dateField VARCHAR(50) = 'co_add_time'
	        DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @co_add_time, 23)
	        DECLARE @noField VARCHAR(50) = 'co_vo'
	        DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	        DECLARE @outno VARCHAR(100) = ''
	        DECLARE @while INT = 0;
	        WHILE @while = 0
	        BEGIN
	            --得到凭证号
	            EXECUTE [dbo].[pro_gen_orderNo]@tableName,@idField,@idValue,@dateField,
	            @dateValue,@noField,@prevTxt,@outno OUTPUT,@co_sh_id
	            BEGIN TRY
	            	--更新
	            	UPDATE pos_cost
	            	SET    co_vo = @outno
					,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)
	            	WHERE  co_id = @co_id
	            	AND co_sh_id=@co_sh_id
	            	--更新成功,赋值,结束循环
	            	SET @while = 1;
	            END TRY
	            BEGIN CATCH
				PRINT '';
	            	----发生错误,判断错误类型
	            	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	            	--BEGIN
	            	--    --不是发生重复的错误
	            	--    --赋值,结束循环
	            	--    SET @while = 1;
	            	--END
	            END CATCH
	        END
	    END
	END
	--修改单据
	IF @op_type = 3
	   AND @co_id > 0
	BEGIN
	    --更新
	    UPDATE [pos_cost]
	    SET    [co_sh_id]           = @co_sh_id,
	           [co_no]              = @co_no,
	           [co_order_man]       = @co_order_man,
	           [co_status]          = @co_status,
	           [co_update_man]      = @co_update_man,
	           [co_update_time]     = @co_update_time,
	           [co_audit_man]       = @co_audit_man,
	           [co_audit_time]      = @co_audit_time
	    WHERE  co_id                = @co_id
	    AND co_sh_id=@co_sh_id
	END
	--添加明细
	IF @op_type = 1
	   OR @op_type = 8
	   AND @co_id > 0
	BEGIN
	    INSERT INTO [pos_costList]
	      (
	        [col_co_id],
	        [col_date],
	        [col_discount],
	        [col_divide],
	        [col_divide_money],
	        [col_withhold],
	        [col_mgn_money],
	        [col_co_money],
	        [col_salary],
	        [col_other_money],
	        [col_remark],
	        [col_status]
	      )
	    VALUES
	      (
	        @co_id,
	        @col_date,
	        @col_discount,
	        @col_divide,
	        @col_divide_money,
	        @col_withhold,
	        @col_mgn_money,
	        @col_co_money,
	        @col_salary,
	        @col_other_money,
	        @col_remark,
	        @col_status
	      )
	    SET @col_id = SCOPE_IDENTITY()
	END
	--修改明细
	IF @op_type = 2
	   AND @co_id > 0
	BEGIN
	    UPDATE [pos_costList]
	    SET    [col_co_id]            = @co_id,
	           [col_date]             = @col_date,
	           [col_discount]         = @col_discount,
	           [col_divide]           = @col_divide,
	           [col_divide_money]     = @col_divide_money,
	           [col_withhold]         = @col_withhold,
	           [col_mgn_money]        = @col_mgn_money,
	           [col_co_money]         = @col_co_money,
	           [col_salary]           = @col_salary,
	           [col_other_money]      = @col_other_money,
	           [col_remark]           = @col_remark,
	           [col_status]           = @col_status
	    WHERE  col_id                 = @col_id
	  
	END
	--删除单据,删除明细
	IF @op_type = 4
	   AND @co_id > 0
	BEGIN
	    UPDATE [pos_costList]
	    SET    [col_status] = 0
	    WHERE  col_co_id = @co_id
	
	    IF @@ROWCOUNT > 0
	    BEGIN
	        UPDATE [pos_cost]
	        SET    [co_status]     = 0
	        WHERE  co_id           = @co_id
	            AND co_sh_id=@co_sh_id
	    END
	END
	--删除明细
	IF @op_type = 5
	   AND @col_id > 0
	BEGIN
	    UPDATE [pos_costList]
	    SET    [col_status]     = 0
	    WHERE  col_id           = @col_id
	    
	END
	--审核单据
	IF @op_type = 6
	   AND @co_id > 0
	BEGIN
	    UPDATE [pos_cost]
	    SET    [co_status]         = 2,
	           [co_audit_man]      = @co_audit_man,
	           [co_audit_time]     = @co_audit_time
	    WHERE  co_id               = @co_id
	        AND co_sh_id=@co_sh_id
	END
	--取消审核单据
	IF @op_type = 7
	   AND @co_id > 0
	BEGIN
	    UPDATE [pos_cost]
	    SET    [co_status]     = 1
	    WHERE  co_id           = @co_id
	        AND co_sh_id=@co_sh_id
	END
END
IF @@error <> 0
BEGIN
    SET @outResult = 0;
END
ELSE
BEGIN
    SET @outResult = @co_id;
END
RETURN @outResult;
go

