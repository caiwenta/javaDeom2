



CREATE PROC [dbo].[pro_pos_allocation_op]
@al_freight DECIMAL(15,2)=0,
@all_box_num INT = 0,
@all_pm VARCHAR(500) = '',
--主键  
@al_erp_id INT = 0,
@all_erp_id INT = 0,
@all_id INT = 0,  
--配货主键  
@all_al_id INT = 0,  
--商品主键  
@all_gi_id INT = 0,  
--商品sku主键  
@all_sku_id INT = 0,  
--数量  
@all_num INT = 0,  
--零售价  
@all_retail_price DECIMAL(9, 2) = 0,  
--零售金额  
@all_retail_money DECIMAL(9, 2) = 0,  
--折率  
@all_discount DECIMAL(9, 2) = 0,  
--供货价  
@all_stock_price DECIMAL(9, 2) = 0,  
--金额  
@all_money DECIMAL(9, 2) = 0,  
--是否赠送  
@all_gift INT = 0,  
--添加时间  
@all_add_time DATETIME = '2014-10-24', 
--来源明细主键
@all_source_id INT = 0, 
--主键  
@al_id INT = 0,  
--单据号  
@al_no VARCHAR(50) = '',  
--配货日期  
@al_date DATETIME = '2014-10-24',  
--交易方式(1,订货:2,补货:3,铺货:4,买断)  
@al_type INT = 0,  
--客户主键  
@al_ci_id INT = 0,  
--店铺主键  
@al_sh_id INT = 0,  
--运输方式  
@al_trans VARCHAR(50) = '',  
--自动匹配订单
@al_ismatching INT=0,
--仓库主键  
@al_st_id INT = 0,  
--货运单号  
@al_freight_no VARCHAR(50) = '',  
--垫付运费  
@al_fright DECIMAL(9, 2) = 0,  
--来源(1,订货:2,终端补货:3,终端退货 4:配货管理 5:订货 6:分公司)
@al_source INT = 0,  
--来源主键  
@al_source_id INT = 0, 

--来源凭证号 
@al_source_vo varchar(50) = '',  

--制单人主键  
@al_order_man INT = 0,  
--添加人主键  
@al_add_man INT = 0,  
--添加时间  
@al_add_time DATETIME = '2014-10-24',  
--修改人主键  
@al_update_man INT = 0,  
--修改时间  
@al_update_time DATETIME = '2014-10-24',  
--审核人主键  
@al_audit_man INT = 0,  
--审核时间  
@al_audit_time DATETIME = '2014-10-24',  
--来源添加时间 
@all_source_add_time DATETIME = '2014-10-24', 
--判断是否是补货审核的数据
@al_butype INT = 0,
--判断是否是订货审核的数据
@al_dhtype INT = 0,
--判断是否是订货审核的存储过程
@dhtype INT = 0,
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  
--结果  
@result VARCHAR(100) = '' OUT,
--公司主键
@al_cp_id INT = 0,
--部门主键
@al_di_id INT = 0,
--分公司主键
@al_to_cp_id INT = 0,
--保存字符串
@savestr VARCHAR(MAX) = '' ,
--前台排出的商品(单击清空明细按钮时会记录商品主键,添加时间)
@not_in_ids VARCHAR(MAX) = '',
@slt_id int=0,
@order_id  VARCHAR(MAX)='',
@good_id VARCHAR(MAX)='',
@ccupySum int=0,
@orderguid VARCHAR(500)='', --唯一guid
@IsPDA int=0,
@al_remark varchar(500)='', --备注
@isModifyEndNum int=0  --是否修改终止数量
AS
BEGIN

	--防止仓位为负数
      IF @slt_id<0
	  BEGIN
	   SET @slt_id=0;
	  END
	
	--终止标识
	DECLARE @op_type_end VARCHAR(100)='';
	IF @op_type='添加修改单据,明细,终止操作'
	BEGIN
		SET @op_type='添加修改单据,明细';
		SET @op_type_end='添加修改单据,明细,终止操作';
	END
	
	
	DECLARE @sql NVARCHAR(MAX) = '';
	--是否添加单据
	DECLARE @isInsert INT = 0;
	--是否恢复补货的添加时间
	DECLARE @isbh_add_time DATETIME;
	--是否恢复补货的添加时间
	DECLARE @isbh_source_add_time DATETIME;
	--是否需要更新单据
	DECLARE @need_update INT = 0;
	--旧的单据日期
	DECLARE @old_order_date DATETIME;
	--单据日期是否更改
	DECLARE @old_order_date_is_changed INT = 0;
	--凭证号前缀
	DECLARE @myprevTxt VARCHAR(50) = 'PH';
	BEGIN TRAN



	IF @op_type = '添加修改单据,明细'
	BEGIN
	    IF @al_id = 0 AND @op_type_end=''
	    BEGIN
	        IF @al_cp_id = 0
	        BEGIN
	            --员工信息表
	            --通过添加人得到公司主键,部门主键
	            SELECT @al_cp_id = fd.si_company,
	                   @al_di_id = fd.si_did
	            FROM   b_stafftinfo fd
	            WHERE  fd.si_id = @al_add_man
	        END
	        
	      
	        --添加单据
	        INSERT INTO pos_allocation
	          (
	            al_vo,
	            al_no,
	            al_date,
	            al_type,
	            al_ci_id,
	            al_sh_id,
	            al_trans,
	            al_st_id,
	            al_freight_no,
	            al_fright,
	            al_status,
	            al_source,
	            al_source_id,
	            al_order_man,
	            al_add_man,
	            al_add_time,
	            al_update_man,
	            al_update_time,
	            al_cp_id,
	            al_di_id,
	            al_to_cp_id,al_ismatching,al_erp_id ,al_freight,
				al_remark
	          )
	        VALUES
	          (
	            NEWID(),
	            @al_no,
	            @al_date,
	            @al_type,
	            @al_ci_id,
	            @al_sh_id,
	            @al_trans,
	            @al_st_id,
	            @al_freight_no,
	            @al_fright,
	            1,
	            @al_source,
	            @al_source_id,
	            @al_order_man,
	            @al_add_man,
	            @al_add_time,
	            @al_update_man,
	            @al_update_time,
	            @al_cp_id,
	            @al_di_id,
	            @al_to_cp_id,
	            @al_ismatching,@al_erp_id,@al_freight,
				@al_remark
	          );
	        SET @al_id = SCOPE_IDENTITY();
	        
	        --自增主键赋值
	        SET @all_al_id = @al_id;
	        --标识其为添加操作
	        SET @isInsert = 1;

	    END
	    ELSE
	    BEGIN
	        --标识其为更新操作
	        SET @need_update = 1;
	    END
	    
	    --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
	    DECLARE @savestr_item VARCHAR(MAX) = '';
	    --起始数值,每次循环后递增
	    DECLARE @start_int INT = 1;
	    --终止数值
	    DECLARE @end_int INT = 1;
	    DECLARE @temp INT = 0;
	    IF @savestr != '' 
	       --AND 1=2
	    BEGIN
	        --得到明细数量
	        --即要循环的次数
	        SELECT @end_int = (LEN(@savestr) -LEN(REPLACE(@savestr, '|', '')))
	    END
	    ELSE
	    BEGIN
	        IF @al_source = 5
	        BEGIN
	            --@savestr为空,整单执行,使其不符合条件
	            SET @start_int = @end_int + 1;
	        END
	    END
	    DECLARE @add_time_not_in VARCHAR(MAX)='';
	    SELECT @add_time_not_in=NEWID();
	
	IF @al_source=7
	   BEGIN
	      PRINT '开始生成配货明细单';

		    MERGE INTO pos_allocationList AS ta
			USING
			(


			select
			(case when newstockprice=0 then 
				(case when inl_stock_price=0 then 0 else CONVERT(decimal(9,2), (inl_stock_price/importprices)) end) 
			 else 
				CONVERT(decimal(9,2), (newstockprice/importprices)) end) as discount,
			
			 (case when newstockprice=0 then 
				 inl_stock_price
			 else 
			    newstockprice
			 end) as stockprice,

			 k.*
			from (
			SELECT 
				@al_id as all_al_id,
				inl_gi_id as gi_id, 
				inl_sku_id as sku_id,
				inl_pm as pm,
				inl_erp_id as erp_id,
				inl_num AS number,
				inl_stock_price,
				inl_retail_price as importprices,
				(SELECT gs_purchase FROM dbo.FnGoodsPrice(inl_gi_id,@al_ci_id,@al_sh_id,@al_to_cp_id,@al_type)) AS newstockprice,

				inl_status as orderstatus,
				inl_box_num as box_num
			FROM erp_instructionNoticeList
			WHERE inl_in_id=(SELECT io_in_id FROM erp_instructionObject WHERE io_id=@al_source_id) AND inl_status=1
			) as k
			
			)as so 
			on ta.all_gi_id=so.gi_id 
			AND ta.all_sku_id=so.sku_id 
			and ta.all_al_id=so.all_al_id 
			and ta.all_status=1
			WHEN MATCHED THEN  UPDATE
			SET ta.all_num += so.number, ta.all_money=((ta.all_num+so.number)*so.stockprice)
			WHEN NOT MATCHED THEN
			INSERT (all_al_id , 
				all_gi_id , 
				all_sku_id ,
				all_pm ,
				all_erp_id ,
				all_num , 
				all_discount , --折扣
				all_retail_price , --零售价
				all_retail_money,
				all_stock_price, --供货价
				all_money,--采购金额
				all_status ,
				all_box_num,
				all_add_time
				)
			VALUES
				( 
				 so.all_al_id, 
				 so.gi_id, 
				 so.sku_id,
				 so.pm,
				 so.erp_id,
				 so.number,
				 so.discount,--折扣
				 so.importprices,--销售价
				 so.number*so.importprices,--销售价金额
				 so.stockprice,--供货价
				 so.number*so.stockprice,--入库金额
				 so.orderstatus,
				 so.box_num,
				 (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
						SELECT GETDATE() as nows,
                 (SELECT TOP 1 all_add_time FROM pos_allocationList WHERE all_gi_id=so.gi_id AND all_al_id=so.all_al_id) AS addtime) AS TT)
				);
			EXEC pro_update_unique_time @id = @al_id, @type = '配货';

		END
		ELSE IF @orderguid=''
		BEGIN

			WHILE @start_int <= @end_int
	    BEGIN
	        --动态赋值
	        IF @savestr != ''
	        BEGIN
	            SET @savestr_item = dbo.Get_StrArrayStrOfIndex(@savestr, '|', @start_int);
	            IF (RTRIM(LTRIM(@savestr_item)) = '')
	            BEGIN
	                BREAK;
	            END
	            ELSE
	            BEGIN
	            	
	                IF (@al_source = 0 
	                OR 
	                (@al_source=5 AND @need_update=1)) AND @op_type_end=''
	                BEGIN
	                    set @temp=1;
	                    SET @all_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
	                    
	                    SET @all_gi_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
	                    
	                    SET @all_sku_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));
	                    
	                    SET @all_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
	                    
	                    SET @all_retail_price = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5)); 
	                    SET @all_stock_price = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6));
	                    
	                    SET @all_discount = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7));
	                    
	                    --SET @all_add_time=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',8);

	                    SET @all_box_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9));
	                    
	                    SET @all_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 10);
	                END
	                ELSE 
	                IF @al_source = 5
	                BEGIN
	                    
	                    SET @all_id = 0;
	                    SET @all_source_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
	                    SET @all_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
	                    SET @all_source_add_time = CONVERT(DATETIME ,dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));
	                    IF (dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4) = '')
	                    BEGIN
	                    set @temp=1;
	                        --没规格
	                        SELECT @all_gi_id = pal.ogl_gi_id,
	                               @all_sku_id = pal.ogl_sku_id,
	                               @all_retail_price = pal.ogl_retail_price,
	                               @all_discount = pal.ogl_discount,
	                               @all_stock_price = pal.ogl_stock_price
	                        FROM   pos_ogStorageList AS pal
	                        WHERE  pal.ogl_id = @all_source_id
	                    END
	                    ELSE
	                    BEGIN
	                        set @temp=1;
	                        SET @all_box_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
	                        SET @all_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5);
	                        SET @all_retail_price = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6) );
	                        
	                        SET @all_stock_price = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7) );
	                        
	                        SET @all_discount = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 8) );
	                        
	                        --商品主键
	                        SET @all_gi_id = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9) );
	                        --sku主键
	                        SET @all_sku_id = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 10) );
	                    END
	                END
	                
	                
	                if(@temp=0)
	                begin
	                      SET @all_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
	                    
	                    SET @all_gi_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
	                    
	                    SET @all_sku_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));
	                    
	                    SET @all_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
	                    
	                    SET @all_retail_price = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5));
	                    
	                    SET @all_stock_price = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6));
	                    
	                    SET @all_discount = CONVERT( DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7));
	                    
	                    --SET @all_add_time=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',8);

	                    SET @all_box_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9));
	                    
	                    SET @all_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 10);
	                
	                end
	                
	                
	            END
	        END

			IF @all_id = 0 and @all_sku_id=0
	        BEGIN
			 select 
				@all_id=all_id,@all_num=all_num+@all_num 
				FROM pos_allocationList jpsl WHERE all_al_id=@all_al_id 
				AND jpsl.all_gi_id= @all_gi_id  
				AND jpsl.all_sku_id= @all_sku_id 
				and jpsl.all_status=1
			end


			IF @all_id = 0
	        BEGIN
	        	IF @op_type_end=''
	    		BEGIN
	    	
	            INSERT INTO pos_allocationList
	              (
	                all_al_id,
	                all_gi_id,
	                all_sku_id,
	                all_num,
	                all_retail_price,
	                all_discount,
	                all_stock_price,
	                all_money,
	                all_gift,
	                all_status,
	                all_add_time,
	                all_source_id,
	                all_source_add_time,
	                all_box_num,
	                all_pm,all_erp_id
	              )
	            VALUES
	              (
	                @all_al_id,
	                @all_gi_id,
	                @all_sku_id,
	                @all_num,
	                @all_retail_price,
	                @all_discount,
	                @all_stock_price,
	                @all_stock_price * @all_num,
	                @all_gift,
	                1,
	                @all_add_time,
	                @all_source_id,
	                @all_source_add_time,
	                @all_box_num,
	                @all_pm,@all_erp_id
	              );
	            SET @all_id = SCOPE_IDENTITY();
	    		END
	    		ELSE
	    		BEGIN
	    			
	    		INSERT INTO j_add_time_record
	    		(
	    			a_add_time,
	    			a_guid
	    		)
	    		VALUES
	    		(
	    			@all_source_add_time,
	    			@add_time_not_in
	    		)
	    		IF @isModifyEndNum=1 --修改终止数量
				BEGIN 
				    UPDATE pos_ogStorageList
	    			SET ogl_pause_num = @all_num
	    			WHERE ogl_id=@all_source_id; 
				END
				ELSE
				BEGIN
	    			UPDATE pos_ogStorageList
	    			SET ogl_pause_num =ISNULL(ogl_pause_num,0)+ @all_num
	    			WHERE ogl_id=@all_source_id; 
				END
	    	END
	        END
	        ELSE
	        BEGIN
	            UPDATE pos_allocationList
	            SET    all_al_id = @all_al_id,
	                   all_gi_id = @all_gi_id,
	                   all_sku_id = @all_sku_id,
	                   all_num = @all_num,
	                   all_retail_price = @all_retail_price,
	                   all_retail_money = @all_retail_price * @all_num,
	                   all_discount = @all_discount,
	                   all_stock_price = @all_stock_price,
	                   all_money = @all_stock_price * @all_num,
	                   all_gift = @all_gift,
	                   all_box_num = @all_box_num,
	                   all_pm = @all_pm,
					   all_erp_id=@all_erp_id
	            WHERE  all_id = @all_id;
	        END
	        SET @start_int = @start_int + 1;
	    END
	    
		END
		ELSE
		BEGIN

			MERGE INTO pos_allocationList AS ta
     USING
     (
         SELECT  @al_id as all_al_id, 
                 gi_id, 
                 sku_id,
                 pm,
				 erp_id,
                 number,
                 discount,--折扣
                 (case when importprices>0 then importprices else retailprice end) as importprices,--销售价
                 stockprice,--供货价
                 orderstatus,
                 box_num,
				 source_id,
				 source_addtime
         FROM  erp_goodslisttemp WHERE orderguid = @orderguid
	)as so 
	on ta.all_gi_id=so.gi_id 
	AND ta.all_sku_id=so.sku_id 
	and ta.all_al_id=so.all_al_id 
	and ta.all_status=1
		WHEN MATCHED THEN  UPDATE
        SET  
		 ta.all_num += so.number,
		 ta.all_money=((ta.all_num+so.number)*so.stockprice)
		WHEN NOT MATCHED THEN
		INSERT (all_al_id , 
				all_gi_id , 
				all_sku_id ,
				all_pm ,
				all_erp_id ,
				all_num , 
				all_discount , --折扣
				all_retail_price , --零售价
				all_retail_money,
				all_stock_price, --供货价
				all_money,--采购金额
				all_status ,
				all_box_num,
				all_add_time
				)
		 VALUES
				( 
				 so.all_al_id, 
				 so.gi_id, 
				 so.sku_id,
				 so.pm,
				 so.erp_id,
				 so.number,
				 so.discount,--折扣
				 so.importprices,--销售价
				 so.number*so.importprices,--销售价金额
				 so.stockprice,--供货价
				 so.number*so.stockprice,--入库金额
				 so.orderstatus,
				 so.box_num,
				 (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
						SELECT GETDATE() as nows,
                 (SELECT TOP 1 all_add_time FROM pos_allocationList WHERE all_gi_id=so.gi_id AND all_al_id=so.all_al_id) AS addtime) AS TT)
				);
            
			exec pro_setGoodsPurchasePrice @oo_id=@al_id,@wt=1;

			EXEC pro_update_unique_time @id = @al_id, @type = '配货';

		END




		IF (@al_source = 5 AND @isInsert=1 ) OR @op_type_end!=''
	    BEGIN
	        SET @sql =REPLACE(  REPLACE( REPLACE(REPLACE(REPLACE(
	                        '
	                        SELECT * into ##p
FROM   (
           SELECT fd.ogl_gi_id,
                  fd.ogl_sku_id,
                  (ogl_num -ISNULL(all_num, 0)
                  -ISNULL(ogl_pause_num, 0)) AS ogl_num,
                  fd.ogl_discount,
                  fd.ogl_retail_price,
                  fd.ogl_stock_price,
                  fd.ogl_status,
                  fd.ogl_id,
                  fd.ogl_add_time,
                  fd.ogl_box_num,
                  fd.ogl_pm
           FROM   pos_ogStorageList fd
                  LEFT  JOIN (
						   SELECT SUM(all_num) AS all_num,
                                  all_source_id
                           FROM   pos_allocationList
                                  INNER JOIN pos_allocation
                                       ON  all_al_id = al_id
                                       WHERE  al_status > 0
                                  AND all_status > 0 and al_source={al_source}
                                  AND all_source_add_time > 0
                           GROUP BY
                                  all_source_id
                  )
                       ed
                       ON  ed.all_source_id = ogl_id
           WHERE  fd.ogl_og_id in({order_id})
            and fd.ogl_gi_id in({good_id})
                  AND ogl_status = 1
                  AND fd.ogl_add_time NOT IN ({0})
                  AND fd.ogl_add_time NOT IN (SELECT DISTINCT fd.all_source_add_time
                                              FROM   pos_allocationList fd
                                              WHERE  fd.all_al_id = @al_id)
                  AND (ogl_num -ISNULL(all_num, 0)-ISNULL(ogl_pause_num, 0)) > 0
) AS fd
	                        ', '{order_id}',@order_id ),'{0}',
	                    CASE 
	                         WHEN dbo.Get_StrArrayStrOfIndex(@not_in_ids, '|', 2)
	                              = '' THEN ''''''
	                         ELSE dbo.Get_StrArrayStrOfIndex(@not_in_ids, '|', 2)
	                    END
	                ),
	                '@al_id', CONVERT(VARCHAR(50), @al_id)),'{good_id}',@good_id),'{al_source}',@al_source);
	            
	            EXEC sp_executesql @sql
	            
	            IF @op_type_end=''
	            BEGIN

				INSERT INTO pos_allocationList
				(
					all_al_id,
					all_gi_id,
					all_sku_id,
					all_num,
					all_discount,
					all_retail_price,
					all_stock_price,
					all_status,
					all_source_id,
					all_source_add_time,
					all_box_num,
					all_pm
				)
				SELECT @al_id AS all_al_id,* FROM ##p
				DROP TABLE ##p
				
				
				UPDATE pos_allocationList
				SET all_money = all_stock_price*all_num
				WHERE all_al_id=@al_id;
				
				
				 SET @sql=REPLACE(REPLACE('UPDATE pos_ogStorage SET og_ph_audit=1,og_ph_audit_time=GETDATE(),og_ph_audit_man=@al_add_man WHERE og_id IN({order_id})','{order_id}',@order_id),'@al_add_man',CONVERT(VARCHAR(50),@al_add_man));
				exec sp_executesql @sql
	        
	        
	        
				
				
				UPDATE pos_allocation
				SET    al_status = 2,
					   al_audit_time = GETDATE(),
					   al_audit_man = @al_add_man
				WHERE  al_id = @al_id;
				
			--更新统一的添加时间
	    	DECLARE @sopcor_all_gi_id INT=0;
	    	DECLARE @sopcor_all_source_add_time DATETIME;	
	    		
	    	DECLARE @t2out DATETIME=GETDATE();
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.all_gi_id,fd.all_source_add_time
				FROM pos_allocationList fd WHERE fd.all_al_id=@al_id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @sopcor_all_gi_id,@sopcor_all_source_add_time
					WHILE @@FETCH_STATUS =0
					BEGIN
					EXEC pro_get_rand_time
	@t1 = @t2out,
	@t2out = @t2out OUT
					UPDATE pos_allocationList
					SET all_add_time = @t2out
					WHERE all_al_id=@al_id 
					AND all_gi_id=@sopcor_all_gi_id 
					AND all_source_add_time=@sopcor_all_source_add_time
					
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @sopcor_all_gi_id,@sopcor_all_source_add_time
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time
	            END
	            ELSE
	            BEGIN
	            	
	            	UPDATE pos_ogStorageList
	            	SET ogl_pause_num = ISNULL(ogl_pause_num,0)+ISNULL(fd2.ogl_num,0)
	            	FROM pos_ogStorageList fd,##p fd2 WHERE
	            	 fd.ogl_id=fd2.ogl_id AND fd2.ogl_add_time NOT IN (
					SELECT fd3.a_add_time
					  FROM j_add_time_record fd3 
					WHERE fd3.a_guid=@add_time_not_in	
					)
	            	
	            END
	    END
	   
		UPDATE pos_allocationList SET 
		
		supplyprice=(SELECT supplyprice FROM dbo.FnGoodsPrice(pal.all_gi_id,pa.al_ci_id,pa.al_sh_id,pa.al_to_cp_id,@al_type)),
		
		discount=(SELECT discount FROM dbo.FnGoodsPrice(pal.all_gi_id,pa.al_ci_id,pa.al_sh_id,pa.al_to_cp_id,@al_type))
		
		FROM pos_allocationList AS pal 
		INNER JOIN pos_allocation pa ON pal.all_status>0 and pal.all_al_id=pa.al_id

		WHERE pal.all_al_id=@al_id

	END



	IF @op_type = '进度终止'
	BEGIN
	    
	    UPDATE pos_allocation
	    SET al_status = 3
	    WHERE al_id = @al_id;
	END
	
	IF @op_type = '审核单据'
	BEGIN
	    --审核单据
	    UPDATE pos_allocation
	    SET    al_status = 2,
	           al_audit_man = @al_update_man,
	           al_audit_time = GETDATE()
	    WHERE  al_id = @al_id;
	END
	
	IF @op_type = '取消审核单据'
	BEGIN
	    --取消审核单据
	    UPDATE pos_allocation
	    SET    al_status = 1
	    WHERE  al_id = @al_id;
	END
	
	IF @op_type = '删除单据'
	BEGIN
	    --删除单据
	    UPDATE pos_allocation
	    SET    al_status = 0
	    WHERE  al_id = @al_id;
	END
	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE pos_allocationList
	    SET    all_status = 0
	    WHERE  all_id = @all_id;
	END
	
	DECLARE @nowal DATETIME = GETDATE();
	IF @op_type = '退货审核'
	BEGIN
	  
	   --审核单据
	    UPDATE pos_allocation
	    SET    al_is_return_audit = 1,
	           al_audit_man = @al_update_man,
	           al_audit_time = GETDATE()
	    WHERE  al_id = @al_id;


	  SELECT
		@al_sh_id=al_sh_id,
		@al_ci_id=al_ci_id,
		@al_to_cp_id=al_to_cp_id,
		@al_remark=al_remark
	  FROM pos_allocation AS pa where pa.al_id=@al_id

	  exec pro_goodsstock_op @al_id,'posallocation',@al_erp_id,@orderguid Out,@slt_id
	  IF @@error <> 0
	  BEGIN
	  IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION 
	  SET @result = '0';
	  RETURN 0;
	  END
	  if @orderguid<>''
		begin
				EXEC pro_outStorage_op
		         @op_type = '添加修改单据,明细',
				 @oo_erp_id=@al_erp_id,
				 @oo_cp_id=@al_cp_id,
				 @oo_remark=@al_remark,
				 @oo_jytype=1,
		         @oo_source_type =1 ,--来源(1:配货,2:分公司入库退货，3:pos入库退货)
			     @oo_source_id = @al_id,  --来源主键
				 @oo_type=0,--类型(0,出库退货:1,出库)
				 @oo_ciid=@al_ci_id,--客户id               
				 @oo_sh_id= @al_sh_id,   --店铺主键         
				 @oo_to_cp_id=@al_to_cp_id,--公司主键
				 @oo_siid=@al_st_id,--仓库id
				 @oo_entrydate=@al_date,
				 @oo_gift=0,
				 @oo_addman=@al_order_man,
				 @orderguid=@orderguid
				IF @@error <> 0
				BEGIN
				IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION 
				SET @result = '0';
				RETURN 0;
				END
		END
	END

	IF @op_type = '取消退货审核'
	BEGIN
	    --审核单据
	    UPDATE pos_allocation
	    SET    al_is_return_audit = 0,
	           al_audit_man =  0,
	           al_audit_time = null
	    WHERE  al_id = @al_id;

		
	  SELECT
		@al_sh_id=al_sh_id,
		@al_ci_id=al_ci_id,
		@al_to_cp_id=al_to_cp_id,
		@al_remark=al_remark
	  FROM pos_allocation AS pa where pa.al_id=@al_id

	     --获取出库信息
	DECLARE @oo_id int=0;
	SELECT  @oo_id = fd.oo_id 
            FROM    j_outStorage fd WITH ( NOLOCK )
            WHERE   fd.oo_source_id=@al_id and fd.oo_source_type=1 and fd.oo_status>0
   
	 if  @oo_id>0
		begin

		    EXEC pro_outStorage_op
		         @op_type = '取消审核单据',
				 @oo_erp_id=@al_id,
				 @oo_cp_id=@al_cp_id,
				 @oo_source_type =1, --来源(1:配货,2:分公司入库退货，3:pos入库退货)
				 @oo_id=@oo_id
			IF @@ERROR <> 0
				BEGIN
				 GOTO theRollback;
				END
			EXEC pro_outStorage_op
		         @op_type = '删除单据',
				 @oo_erp_id=@al_id,
				 @oo_cp_id=@al_cp_id,
				 @oo_source_type =1, --来源(1:配货,2:分公司入库退货，3:pos入库退货)
				 @oo_id=@oo_id
			IF @@ERROR <> 0
				BEGIN
				 GOTO theRollback;
				END
		end

	END

	--来源类型
	DECLARE @source INT = 0;
	--来源主键
	DECLARE @source_id INT = 0;
	
	DECLARE @sum INT = 0;
	
	IF @op_type = '批量删除明细'
	BEGIN
	    UPDATE pos_allocationList
	    SET    all_status = 0
	    WHERE  all_al_id = @all_al_id
	           AND all_add_time = @all_add_time
	           AND all_gi_id = @all_gi_id;
	    
	    --判断是否还存在记录
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   pos_allocationList AS jt
	           WHERE  jt.all_al_id = @all_al_id
	                  AND jt.all_status = 1
	       )
	    BEGIN
	        --已经没有明细了,把单据状态更改为删除状态	
	        UPDATE pos_allocation
	        SET    al_status = 0
	        WHERE  al_id = @all_al_id;
	        
	        
	        
	        
	        SELECT @source = jt.al_source,
	               @source_id = jt.al_source_id
	        FROM   pos_allocation AS jt
	        WHERE  jt.al_id = @all_al_id
	               AND jt.al_status = 0;
	        
	        --补货
	        IF @source = 2
	        BEGIN
	            UPDATE pos_reStorage
	            SET    re_is_audit = 0
	            WHERE  re_id = @source_id;
	        END
	        
	        --pos退货
	        IF @source = 3
	        BEGIN
	            UPDATE pos_inStorage
	            SET    in_is_audit = 0
	            WHERE  in_id = @source_id;
	        END
	    END
	END
	
	IF (@op_type = '添加修改单据,明细'
	   OR @need_update = 1
	   OR @op_type = '修改单据') AND @op_type_end=''
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.al_date
	    FROM   pos_allocation AS jt
	    WHERE  jt.al_id = @al_id;
	    IF @old_order_date != @al_date
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	    UPDATE pos_allocation
	    SET    al_no = @al_no,
	           al_date = @al_date,
	           al_type = @al_type,
	           al_ci_id = @al_ci_id,
	           al_sh_id = @al_sh_id,
			   al_to_cp_id=@al_to_cp_id,
	           al_trans = @al_trans,
	           al_ismatching=@al_ismatching,
	           al_st_id = @al_st_id,
	           al_freight_no = @al_freight_no,
	           al_fright = @al_fright,
	           al_order_man = @al_order_man,
	           al_update_man = @al_update_man,
	           al_update_time = @al_update_time
	           ,
	           al_source = @al_source,
			   al_remark=@al_remark
	           --,
	           --al_source_id = @al_source_id
	    WHERE  al_id = @al_id;
	    
	    IF(SELECT fd.al_status FROM pos_allocation  fd 
	       WHERE fd.al_id=@al_id)=0
	    BEGIN
	    	UPDATE pos_allocation
	        SET    al_status = 1
	        WHERE  al_id = @al_id;
	    END
	    
	    --补货审核状态
	    IF @al_butype = 1
	    BEGIN
	    	
	    	IF @al_source_id=0
	    	BEGIN
	    		SELECT @al_source_id=pa.al_source_id
	    		  FROM pos_allocation pa WHERE pa.al_id=@al_id;
	    	END
	        UPDATE pos_allocation
	        SET    al_status = 1,
	               al_audit_time = GETDATE(),
	               al_audit_man = @al_add_man
	        WHERE  al_id = @al_id AND al_status!=2
	         IF @@ROWCOUNT!=0
	        BEGIN
	        
	        UPDATE pos_reStorage
	        SET    re_is_audit = 1,
	               re_main_audit_time = GETDATE(),
	               re_main_audit_man = @al_add_man
	        WHERE  re_id = @al_source_id AND ISNULL(re_is_audit,0)=0
	        IF @@ROWCOUNT=0 AND (SELECT count(1) as count FROM pos_allocation pa WHERE pa.al_source=2 AND pa.al_source_id=@al_source_id AND pa.al_status>0)>1
	        BEGIN
	        	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	        	SET @result = '保存失败,补货单已经执行过!';
	        	RETURN;
	        END
	        
	        END
	    END

	END
	
	SET @old_order_date_is_changed=0; 
	IF (@isInsert = 1 OR @old_order_date_is_changed = 1) AND @op_type_end=''
	BEGIN
	    --凭证号生成
	    --更新凭证号 
	    DECLARE @tableName VARCHAR(50) = 'pos_allocation'
	    DECLARE @idField VARCHAR(50) = 'al_id'
	    DECLARE @idValue INT = @al_id;
	    
	    DECLARE @dateField VARCHAR(50) = 'al_date'
	    DECLARE @dateValue VARCHAR(50) =
	            CONVERT(VARCHAR(50), @al_date, 23)
	    
	    DECLARE @noField VARCHAR(50) = 'al_vo'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN
	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	        @idField,
	        @idValue,
	        @dateField,
	        @dateValue,
	        @noField,
	        @prevTxt,
	        @outno OUTPUT,0,@al_cp_id
	        
	        BEGIN TRY
	        	--更新
	        	UPDATE pos_allocation
	        	SET    al_vo = @outno
				
	        	,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)

	        	WHERE  al_id = @al_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
			PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
	        END CATCH
	    END
	END
	

	UPDATE pos_allocation SET 
	al_ci_id_txt = ( SELECT ci_name FROM dbo.b_clientinfo  as  bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ),
	al_ci_code_txt = ( SELECT ci_code FROM dbo.b_clientinfo  as  bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ),
	ci_province = ( SELECT ci_province FROM dbo.b_clientinfo  as  bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ),
	ci_city = ( SELECT ci_city FROM dbo.b_clientinfo  as  bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ),
	al_sh_id_txt = ( SELECT sh_name FROM dbo.pos_shop  as  bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ),
	sh_province = ( SELECT province FROM dbo.pos_shop  as  bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ),
	sh_city = ( SELECT city FROM dbo.pos_shop  as  bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ),
	al_to_cp_id_txt = ( SELECT cp_name FROM companyinfo  as  bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id ),
	al_st_id_txt = ( SELECT sei_name FROM dbo.b_storageinfo  as  bs  WITH (NOLOCK) WHERE sei_id = al.al_st_id ),
	cp_province = ( SELECT cp_province FROM companyinfo  as  bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id ),
	cp_city = ( SELECT cp_city FROM companyinfo  as  bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id ),
	al_order_man_txt = ( SELECT si_name FROM dbo.b_stafftinfo  as  bs  WITH (NOLOCK) WHERE si_id = al.al_order_man ),
	al_add_man_txt = ( SELECT si_name FROM dbo.b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_add_man ),
	al_update_man_txt = ( SELECT si_name FROM dbo.b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_update_man ),
	al_audit_man_txt = ( SELECT si_name FROM dbo.b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_audit_man ),
	OutNum = ( SELECT SUM (ol_number) FROM j_outStorage_allout  WITH (NOLOCK) WHERE oo_source_type = 1 AND oo_source_id = al.al_id ),--出库数量
	oo_status =  ( SELECT MAX (oo_status) FROM j_outStorage  WITH (NOLOCK) WHERE oo_source_type = 1 AND oo_source_id = al.al_id AND oo_status > 0 ),--出库状态
	PHNum = ( SELECT SUM (all_num) FROM pos_allocationList  WITH (NOLOCK) WHERE all_al_id = al.al_id AND all_status > 0 ),--配货数量
	all_pause_num = ( SELECT SUM (all_pause_num) FROM pos_allocationList  WITH (NOLOCK) WHERE all_al_id = al.al_id AND all_status > 0 ),--配货数量
	PHmoney =  (SELECT SUM (all_money) FROM pos_allocationList  WITH (NOLOCK) WHERE all_al_id = al.al_id AND all_status > 0 ),--配货金额
	ci_attribute_ids = (SELECT ci_attribute_ids FROM b_clientinfo  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ),
	ci_attribute_parentids = ( SELECT ci_attribute_parentids FROM b_clientinfo  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ),
	sh_attribute_ids = (SELECT sh_attribute_ids FROM dbo.pos_shop  as  bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ),
	sh_attribute_parentids = (SELECT sh_attribute_parentids FROM dbo.pos_shop  as  bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ) 
	FROM  pos_allocation al WHERE al.al_id=@al_id;


--更新占用库存 @op_type_end:终止数量   ge.al_source<>4 and ge.al_source<>3
IF ( @op_type <> '审核单据' or @op_type <> '取消审核单据' )
BEGIN

    
select 
@al_st_id=al_st_id,
@al_cp_id=al_cp_id,
@al_source=al_source
from pos_allocation 
where al_id = @al_id;


if @op_type = '批量删除明细'
begin
	set @al_id=@all_al_id;
end

if @al_st_id>0 and @al_source<>4 and @al_source<>3
begin
	EXEC pro_mergeAllocationOccupySum @id = @al_id,@SID=@al_st_id, @cp_id = @al_cp_id;
	EXEC pro_mergeOccupy_check @cp_id=@al_cp_id,@sei_id=@al_st_id;
    IF @@ERROR <> 0
	BEGIN
     GOTO theRollback;
	END
end

end



	


	IF @@ERROR <> 0
	BEGIN
	    theRollback:
	    SET @result = '0';
	    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	else
	BEGIN

	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @al_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细' AND @op_type_end='' and @orderguid=''
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @all_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END

		IF @@TRANCOUNT > 0 COMMIT TRAN;

	  END

END
go

