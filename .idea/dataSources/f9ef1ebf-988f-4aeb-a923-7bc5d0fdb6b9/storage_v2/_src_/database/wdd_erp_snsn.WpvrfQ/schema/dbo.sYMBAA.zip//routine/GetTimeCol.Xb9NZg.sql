CREATE FUNCTION [dbo].[GetTimeCol]
(
    @beginTime date,
    @endTime date
)
RETURNS @returntable TABLE
(
    CostTime date
)
AS
BEGIN
    while(@beginTime<=@endTime)
    begin
        insert into @returntable select @beginTime
        select @beginTime=dateadd(day,1,@beginTime)
    end;    
    RETURN
END
go

