CREATE VIEW [dbo].[v_z_pos_reStorage_detail]
	AS 
select 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
posinlist.*
from(
select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,

posin.* 
from
(

SELECT 
ps.sh_company,
ps.sh_erp_id  as erp_id,
ISNULL(ps.sh_name,'') as sh_name,--店铺
ISNULL(ps.sh_no,'') as sh_no, --店铺代号
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_skuid,
(SELECT al_vo FROM dbo.pos_allocation WITH (NOLOCK) WHERE al_source=2 and al_status<>0 and al_source_id = re_id) as ph_vo,--配货凭证号
re_id,
re_is_audit,
re_sh_id,
re_vo,
CONVERT(VARCHAR(10), re_date, 120) AS re_date,
re_no,
re_supplier_sh_id,
re_add_man,
re_update_man,
re_audit_man,
( SELECT sh_no FROM  dbo.pos_shop AS bs WITH (NOLOCK) WHERE  (sh_id = re.re_supplier_sh_id))  AS re_sh_no,
( SELECT sh_name FROM  dbo.pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = re.re_supplier_sh_id))  AS re_supplier_sh_id_txt,
( SELECT sh_name FROM  dbo.pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = re.re_sh_id) )  AS re_sh_id_txt,
( SELECT si_name FROM  dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE  (si_id = re.re_order_man))  AS re_order_man_txt,
re_order_man,
( SELECT si_name FROM  dbo.b_stafftinfo AS bs  WITH (NOLOCK) WHERE (si_id = re.re_add_man))  AS re_add_man_txt,
re_add_time,
( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = re.re_update_man))  AS re_update_man_txt,
re_update_time,
( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = re.re_main_audit_man))  AS re_main_audit_man_txt,
re_main_audit_time,
( SELECT si_name FROM  dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE  (si_id = re.re_audit_man)) AS re_audit_man_txt,
re_audit_time,
re_remark,
re_status,
(SELECT  cp_name FROM companyinfo AS cp WITH (NOLOCK) WHERE  cp.cp_id= re.re_tocompanyid  )  AS cp_name,
(SELECT  cp_code FROM companyinfo AS cp WITH (NOLOCK) WHERE  cp.cp_id= re.re_tocompanyid  )  AS cp_code,
(SELECT  cp_name FROM companyinfo AS cp WITH (NOLOCK) WHERE  cp.cp_id= re.re_cp_id  )  AS re_cp_name,
(SELECT  cp_code FROM companyinfo AS cp WITH (NOLOCK) WHERE  cp.cp_id= re.re_cp_id  )  AS re_cp_code,
re.re_tocompanyid,
re.re_cp_id
rel_re_id,
rel_gi_id,
rel_add_time,
rel_num,
rel_id,
rel_sku_id,
rel_money,
rel_retail_price,
rel_stock_price,
rel_is_gift,
rel_sample_no,
rel_discount,
ISNULL((
SELECT SUM(all_num) FROM pos_allocation pa WITH (NOLOCK)
INNER JOIN pos_allocationList pal WITH (NOLOCK) ON pa.al_id=pal.all_al_id AND pa.al_status<>0
AND pal.all_gi_id=rel_gi_id AND pal.all_sku_id=rel.rel_sku_id AND pa.al_source_id=rel_re_id and al_source IN (2)
),
0
) AS phnum,
rel_pm,
rel_box_num

FROM pos_reStorage AS re WITH (NOLOCK)
INNER JOIN pos_reStoragelist AS rel WITH (NOLOCK) ON re.re_id=rel.rel_re_id AND re.re_status>0 AND rel.rel_status>0
inner join b_goodsinfo gi WITH (NOLOCK) on gi.gi_id=rel.rel_gi_id and gi.gi_status>0
inner join b_unit ui on ui.ut_id=gi.gi_unit
inner join pos_shop ps on ps.sh_id=re.re_sh_id
) as posin
left join b_goodsruleset  as grl WITH (NOLOCK) on  grl.gss_id=posin.rel_sku_id

) as posinlist
left join s_goodsruledetail as rulenum WITH (NOLOCK)  on gd_id=posinlist.size
go

