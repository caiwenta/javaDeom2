CREATE TRIGGER [dbo].[merge_s_power_button_info]
ON [dbo].[s_buttoninfo]
AFTER INSERT
AS
merge into s_power_button_info as ta
  using vi_s_power_button_info as so
  on ta.pbi_bi_id=so.bi_id and ta.pbi_ri_id=so.ri_id
  when not matched then insert (pbi_bi_id,pbi_ri_id,pbi_is_enable)values(so.bi_id,so.ri_id,0);
go

