CREATE VIEW [dbo].[v_z_InitStorage_rule]
	AS 
SELECT rs.inl_in_id order_id, --主订单id
       rs.cs_id color_order_id, -- 颜色汇总表id
       rs.num sku_num, --数量
       rs.ruleid, --规格id
       gr.gd_row_number spec,--规格排序，占位号
       rs.colorid --颜色id
FROM j_initStorageListMergeRuleSum AS rs
LEFT JOIN s_goodsruledetail AS gr
ON rs.ruleid = gr.gd_id

go

