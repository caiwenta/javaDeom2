

CREATE PROC [dbo].[pro_j_moStorageList_skuid_search_tb]
@mol_box_num INT = 0,
@mol_pm VARCHAR(500) = '',
@gss_no VARCHAR(500) = '',
--主键  
@mo_id INT = 0,  
--移出仓库  
@mo_out_st_id INT = 0,  
--移入仓库  
@mo_in_st_id INT = 0,  
--移出数量  
@mo_num INT = 0,  
--单据号  
@mo_no VARCHAR(50) = '',  
--移仓日期  
@mo_date DATETIME = '2014-10-31',  
--添加人主键  
@mo_add_man INT = 0,  
--添加时间  
@mo_add_time DATETIME = '2014-10-31',  
--修改人主键  
@mo_update_man INT = 0,  
--修改时间  
@mo_update_time DATETIME = '2014-10-31',  
--审核人主键  
@mo_audit_man INT = 0,  
--审核时间  
@mo_audit_time DATETIME = '2014-10-31',  
--制单人主键  
@mo_order_man INT = 0,  
--备注  
@mo_remark VARCHAR(50) = '',  
--主键  
@mol_id INT = 0,  
--移仓主键  
@mol_mo_id INT = 0,  
--商品主键  
@mol_gi_id INT = 0,  
--商品sku主键  
@mol_sku_id INT = 0,  
--日期库存数量  
@mol_stock_num INT = 0,  
--移出数量  
@mol_num INT = 0,  
--备注  
@mol_remark VARCHAR(50) = '',  
--添加时间  
@mol_add_time DATETIME = '2014-10-31',  
--零售价
@mol_retail_price DECIMAL(18, 2) = 0,
--进货价
@mol_stock_price DECIMAL(18, 2) = 0,
--折扣
@mol_discount DECIMAL(18, 2) = 0,
--金额
@mol_money DECIMAL(18, 2) = 0,
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  
--结果  
@result VARCHAR(100) = '' OUT,
--产生了负库存是否提示
@negative_inventory INT = 0,
--公司主键
@mo_cp_id INT = 0,
--部门主键
@mo_di_id INT = 0,
--保存字符串
@savemor VARCHAR(MAX)=''
AS

  
begin

DECLARE @m_gi_id int = 0;
DECLARE @m_skuid int = 0;
DECLARE @m_gss_no VARCHAR(50) = '';
DECLARE @m_gi_add_time DATETIME;
DECLARE @m_gi_purchase DECIMAL(9, 2) = 0;
DECLARE @m_gi_retailprice DECIMAL(9, 2) = 0;

DECLARE @m_mol_new_num int = 0;
DECLARE @m_mol_old_num int = 0;

 
DECLARE @m_gs_weight DECIMAL(9, 2) = 0;  
DECLARE @m_mol_add_time DATETIME;  
DECLARE @m_mo_add_time datetime;  
DECLARE @m_mol_id int = 0;
DECLARE @m_gi_barcode VARCHAR(50) = 0;
DECLARE @mtemo VARCHAR(500) = '';
--============  

--修改时
if @mo_id>0 BEGIN
  set  @mol_mo_id=@mo_id 
end
set  @mol_id=0

--SELECT 'return='=@mo_mo_date
--return 

set  @m_mol_new_num=0;
set @savemor ='';

if EXISTS(SELECT * from b_goodsruleset where gss_no like   '%'+@gss_no+'%')--有规格
BEGIN 
declare cursor1 cursor for
SELECT   bg2.gi_id,  bg.gss_no,  bg.gss_id, bg2.gi_add_time, bg2.gi_retailprice, bg2.gi_purchase
FROM   b_goodsruleset  AS bg  
       LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id  
WHERE  bg2.gi_id=(SELECT top 1 gi_id from b_goodsruleset where gss_no =  @gss_no ) 


 --使用游标的对象(跟据需要填入select文)
 OPEN cursor1 --打开游标
 FETCH NEXT FROM cursor1 INTO  @m_gi_id,@m_gss_no,@m_skuid,@m_gi_add_time,@m_gi_retailprice,@m_gi_purchase--,@m_gs_weight--将游标向下移1行，获取的数据放入之前定义的变量@id,@name中

if @m_gi_id=0 BEGIN

  set @result='输入错误,当前商品有规格，请输入正确的规格编码！';
 SELECT 'id'=@result ;
return
end

WHILE @@fetch_status = 0 --判断是否成功获取数据
BEGIN
    --SELECT 'return='=@m_gss_no 
  --修改数量时得出原单据数量
--set @mol_new_num= @m_mol_new_num+3 
 
  if @mo_id>0 BEGIN
   IF EXISTS(SELECT * from j_moStorageList WHERE  mol_mo_id = @mo_id  and  mol_gi_id = @m_gi_id and mol_sku_id=@m_skuid  and mol_status>0)
   BEGIN
  SELECT top 1 @m_mol_id=mol_id,@m_mol_add_time=mol_add_time,@m_mol_old_num =mol_num from j_moStorageList WHERE  mol_mo_id = @mo_id and  mol_gi_id = @m_gi_id and mol_sku_id=@m_skuid  and mol_status>0
   set @mol_add_time=@m_mol_add_time
      SELECT top 1 @m_mo_add_time=mo_add_time from j_moStorage where mo_id=@mo_id and mo_status>0
   set @mo_add_time=@m_mo_add_time
     set @m_mol_id=@m_mol_id
   set @mol_id=@m_mol_id
   --set @mol_new_num=@m_mol_old_num --旧数量
   --if @mo_id>0 BEGIN
   --set @mol_new_num=999
  --end
  end
  end
 
  set @mol_sku_id=@m_skuid
  set @mol_stock_price=@m_gi_purchase
  set @mol_retail_price=@m_gi_retailprice
  set @mol_gi_id=@m_gi_id
  set @mtemo=@mtemo+cast(@m_skuid as varchar(10)) +'|'
    if @m_gss_no!=@gss_no BEGIN --使用旧数量
    set @savemor =@savemor +cast(@mol_id as varchar(10))+',' + cast(@mol_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+   cast(@m_mol_old_num as varchar(10))+','+ cast(@mol_retail_price as varchar(10)) +','+ cast(@mol_stock_price as varchar(10))+',0,0,|' 
  END
  else
  BEGIN--使用新数量 
   set @m_mol_new_num=@mol_num+@m_mol_old_num 
   set @savemor =@savemor +cast(@mol_id as varchar(10))+',' + cast(@mol_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+  cast(@m_mol_new_num as varchar(10))+','+ cast(@mol_retail_price as varchar(10)) +','+ cast(@mol_stock_price as varchar(10))+',0,0,|' 
  end
 
    --进行相应处理(跟据需要填入SQL文)

 FETCH NEXT

FROM
 cursor1 INTO  @m_gi_id,@m_gss_no,@m_skuid,@m_gi_add_time,@m_gi_retailprice,@m_gi_purchase--,@m_gs_weight --将游标向下移1行
END
CLOSE cursor1 --关闭游标
DEALLOCATE cursor1
end
ELSE
BEGIN
--无规格
if EXISTS(SELECT  * from b_goodsinfo bg2  WHERE  bg2.gi_barcode=@gss_no)
BEGIN
 SELECT  top 1 @m_gi_id= bg2.gi_id, @m_gi_barcode=bg2.gi_barcode, @m_gi_add_time=bg2.gi_add_time, @m_gi_retailprice=bg2.gi_retailprice, @m_gi_purchase=bg2.gi_purchase, @m_gi_retailprice=bg2.gi_retailprice  from b_goodsinfo bg2  WHERE  bg2.gi_barcode=@gss_no

     if @mo_id>0 BEGIN
   IF EXISTS(SELECT * from j_moStorageList WHERE  mol_mo_id = @mo_id  and  mol_gi_id = @m_gi_id   and mol_status>0)
   BEGIN
  SELECT top 1 @m_mol_id=mol_id,@m_mol_add_time=mol_add_time,@m_mol_old_num =mol_num from j_moStorageList WHERE  mol_mo_id = @mo_id and  mol_gi_id = @m_gi_id    and mol_status>0
   set @mol_add_time=@m_mol_add_time
      SELECT top 1 @m_mo_add_time=mo_add_time from j_moStorage where mo_id=@mo_id and mo_status>0
   set @mo_add_time=@m_mo_add_time
     set @m_mol_id=@m_mol_id
   set @mol_id=@m_mol_id
   --set @mol_new_num=@m_mol_old_num --旧数量
   --if @mo_id>0 BEGIN
   --set @mol_new_num=999
  --end
  end
  end
 
  set @mol_sku_id=@m_skuid
  set @mol_stock_price=@m_gi_purchase
  set @mol_retail_price=@m_gi_retailprice
  set @mol_gi_id=@m_gi_id
  set @mtemo=@mtemo+cast(@m_skuid as varchar(10)) +'|'
    if @m_gi_barcode!=@gss_no BEGIN --使用旧数量
    set @savemor =@savemor +cast(@mol_id as varchar(10))+',' + cast(@mol_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+ cast(@m_mol_old_num as varchar(10))+','+ cast(@mol_retail_price as varchar(10)) +','+ cast(@mol_stock_price as varchar(10))+',0,0,|' 
  END
  else
  BEGIN--使用新数量 
   set @m_mol_new_num=@mol_num+@m_mol_old_num 
   set @savemor =@savemor +cast(@mol_id as varchar(10))+',' + cast(@mol_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+',' + cast(@m_mol_new_num as varchar(10))+','+ cast(@mol_retail_price as varchar(10)) +','+ cast(@mol_stock_price as varchar(10))+',0,0,|' 
  end

END
ELSE
BEGIN
 set @result=0;
 SELECT 'id'=@result ;
return
end
end



--SELECT 'return='=@mtemo
--SELECT 'return='=@savemor
--return 
--==================



 


set @op_type='添加修改单据,明细'
EXECUTE [pro_j_moStorage_op]
@mol_box_num,
@mol_pm,
--主键  
@mo_id,  
--移出仓库  
@mo_out_st_id,  
--移入仓库  
@mo_in_st_id,  
--移出数量  
@mo_num,  
--单据号  
@mo_no,  
--移仓日期  
@mo_date,  
--添加人主键  
@mo_add_man,  
--添加时间  
@mo_add_time,  
--修改人主键  
@mo_update_man,  
--修改时间  
@mo_update_time,  
--审核人主键  
@mo_audit_man,  
--审核时间  
@mo_audit_time,  
--制单人主键  
@mo_order_man,  
--备注  
@mo_remark,  
--主键  
@mol_id,  
--移仓主键  
@mol_mo_id,  
--商品主键  
@mol_gi_id,  
--商品sku主键  
@mol_sku_id,  
--日期库存数量  
@mol_stock_num,  
--移出数量  
@mol_num,  
--备注  
@mol_remark,  
--添加时间  
@mol_add_time,  
--零售价
@mol_retail_price,
--进货价
@mol_stock_price,
--折扣
@mol_discount,
--金额
@mol_money,
--操作类型  
@op_type,  
--结果  
@result  OUTPUT,
--产生了负库存是否提示
@negative_inventory,
--公司主键
@mo_cp_id,
--部门主键
@mo_di_id,
--保存字符串
@savemor 

SELECT 'id'=@result 
--==================
--SELECT   bg2.gi_id, bg.gss_no, bg2.gi_add_time
--FROM   b_goodsruleset  AS bg  
--       LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
--WHERE  bg.gi_id = @gi_id   AND bg.gss_no = @gss_no
 
end


go

