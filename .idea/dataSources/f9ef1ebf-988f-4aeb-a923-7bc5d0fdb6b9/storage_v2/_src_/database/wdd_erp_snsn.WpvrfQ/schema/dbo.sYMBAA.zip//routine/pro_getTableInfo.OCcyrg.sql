CREATE Proc [dbo].[pro_getTableInfo]
@table Varchar(50)
As
Begin
 Select * From 
(
Select * From  dbo.Get_table_field_Info(@table)
)As f1
Left Join
(
   SELECT syscolumns.name As idField  FROM syscolumns,sysobjects,sysindexes,sysindexkeys WHERE syscolumns.id = object_id(@table) AND sysobjects.xtype = 'PK' AND sysobjects.parent_obj = syscolumns.id AND sysindexes.id = syscolumns.id AND sysobjects.name = sysindexes.name AND sysindexkeys.id = syscolumns.id AND sysindexkeys.indid = sysindexes.indid AND syscolumns.colid = sysindexkeys.colid
   )As s1
   On f1.fieldName=s1.idfield
 
 End
go

