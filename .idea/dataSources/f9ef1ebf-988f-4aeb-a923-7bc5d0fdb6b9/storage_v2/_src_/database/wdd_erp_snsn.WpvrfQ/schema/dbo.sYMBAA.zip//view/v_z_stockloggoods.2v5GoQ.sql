CREATE VIEW [dbo].[v_z_stockloggoods]
	AS 
SELECT
fd2.ord_no AS m_no,
ck.*,
convert(varchar(50),order_date,23) AS addtime
FROM 
(
SELECT 
sl_eoid AS eoid,
sl_pm AS pm,
fd2.oo_di_id, 
sl_order_no AS orderno,
bs.sei_name,
bg.gi_name,
bg.gi_code,
bg.gi_barcode,
bg.gi_types,
bg.gi_type1,
bg.gi_type2,
bg.gi_type3,
bg.gi_type4,
(select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi_type1)gi_typename1,
(select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi_type2)gi_typename2,
(select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi_type3)gi_typename3,
(select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi_type4)gi_typename4,
js.gi_skus,
js.erp_id,
si_number AS gnum,
sl_remark AS myremark,
sl_order_date AS order_date,
sl_addtime AS order_add_time,
sl_seiid AS sei_id,
sl_giid AS gi_id ,
sl_type ,
sl_cp_id AS cp_id,
(CASE sl_type WHEN 1 THEN
(SELECT si_name FROM b_supplierinfo bs WHERE bs.si_status<>0 AND bs.si_id=sl_ciid)
WHEN 2 THEN
(	
SELECT 	 
(CASE WHEN oo_sh_id_txt<>'' THEN oo_sh_id_txt	
WHEN ci_name<>'' THEN ci_name
WHEN oo_to_cp_id_txt<>'' THEN oo_to_cp_id_txt
ELSE '其它'
END) AS sup FROM vi_j_outStorage WHERE oo_id=sl_eoid
)
ELSE '其它'
END
)AS sup,
(select
(case when type=1 then '加盟专卖店'
when type=3 then '直营专卖店'
else '' end)
from pos_shop
where sh_id=(SELECT 
(CASE WHEN oo_sh_id<>0 THEN oo_sh_id
ELSE '' END) AS shop
FROM vi_j_outStorage WHERE oo_id=sl_eoid ))shop_type
FROM (
Select 
js.sl_order_no,js.sl_giid ,js.sl_seiid , js.sl_cp_id,js.sl_type ,js.sl_remark,sl_ciid,sl_eoid,sl_pm,
MAX(js.sl_order_date) AS sl_order_date,MAX(js.sl_addtime) AS sl_addtime ,max(js.sl_erp_id) AS erp_id, 
MAX(CASE WHEN sl_skuid=0 THEN '' ELSE '1' END ) AS gi_skus,
Sum(Case when js.sl_counttype=1 Then js.sl_number Else -js.sl_number End) As si_number
From j_stocklog js 
WHERE js.sl_status<>0 
GROUP BY js.sl_order_no,js.sl_seiid,js.sl_giid,js.sl_cp_id,js.sl_type ,js.sl_remark,sl_ciid,sl_eoid,sl_pm
) AS js
INNER JOIN dbo.b_storageinfo AS bs ON  js.sl_seiid = bs.sei_id 
LEFT JOIN dbo.b_goodsinfo AS bg  ON  js.sl_giid = bg.gi_id  and bg.gi_status=1
LEFT JOIN j_outStorage AS fd2 ON js.sl_type = 2 AND js.sl_cp_id = fd2.oo_cp_id AND js.sl_eoid = fd2.oo_id
) ck
LEFT OUTER JOIN
netorder_tbl AS fd2 ON ck.oo_di_id = fd2.ord_id
go

