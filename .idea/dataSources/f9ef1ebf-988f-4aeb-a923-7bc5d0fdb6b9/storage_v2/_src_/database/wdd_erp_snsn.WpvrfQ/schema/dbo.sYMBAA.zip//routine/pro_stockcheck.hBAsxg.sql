CREATE PROCEDURE [dbo].[pro_stockcheck]
	@cp_id INT=0,
	@new_sei_id int=0,
	@old_sei_id int=0,
	@date DATETIME
AS
DECLARE @result_var VARCHAR(1000) = '';
DECLARE @bool_need_error INT = 0;

BEGIN
IF EXISTS(select * from vi_j_takeStorage_record as fd where fd.tsl_st_id in(@new_sei_id,@old_sei_id) and fd.tsl_date>=@date)
BEGIN
	SET @bool_need_error=1;
	SET @result_var = '有进行盘点，库存已被锁定！请检查！';
	GOTO theEnd;
END

--月报表
IF EXISTS(SELECT TOP 1 m_month FROM j_month_report WHERE reporttype=0 AND company_id=@cp_id AND  m_year=DATEPART(YEAR,@date) AND m_month=DATEPART(MONTH,@date))	
BEGIN
	SET @bool_need_error=1;
	SET @result_var = '您所要操作的数据已生成月报表,数据已被锁定,禁止操作!';
	GOTO theEnd;
END


--日报表
IF EXISTS(SELECT TOP 1 m_day FROM j_month_report WHERE reporttype=1 AND company_id=@cp_id AND  m_year=DATEPART(YEAR,@date) AND m_month=DATEPART(MONTH,@date) AND m_day=DATEPART(day,@date))
BEGIN
	SET @bool_need_error=1;
	SET @result_var = '您所要操作的数据已生成日报表,数据已被锁定,禁止操作!';
	GOTO theEnd;
END


theEnd:
	IF @bool_need_error = 1
		RAISERROR (@result_var,16,1,N'number',5);
end
go

