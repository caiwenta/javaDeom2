CREATE PROC [dbo].[pro_mergeStockLog_j_outStorage]
    @cp_id INT = 0 ,
    @negative_inventory INT = 0 ,--产生了负库存是否提示
    @old_sei_id INT = 0 ,
    @new_sei_id INT = 0 ,
    @id INT = 0
AS
    BEGIN
		--此过程作用：公司出库计算库存
		--检测库存
        BEGIN TRY
            EXEC pro_mergeStockLog_check @cp_id = @cp_id, @negative_inventory = @negative_inventory, @old_sei_id = @old_sei_id, @new_sei_id = @new_sei_id
        END TRY 
        BEGIN CATCH    
            DECLARE @ERROR_MESSAGE VARCHAR(MAX)= ERROR_MESSAGE();
            --有异常
            RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
            
            RETURN;
        END CATCH;
        --事务开始
        BEGIN TRAN
            
        DECLARE @now DATETIME = GETDATE();

		update j_stocklog set sl_status = 0 where sl_cp_id = @cp_id and sl_eoid = @id and sl_type = 2


		INSERT j_stocklog( sl_eoid,
                              sl_elid ,
                              sl_seiid ,
                              sl_ciid ,
                              sl_giid ,
                              sl_skuid ,
                              sl_type ,
                              sl_counttype ,
                              sl_number ,
                              sl_addtime ,
                              sl_updatetime ,
                              sl_remark ,
                              sl_status ,
                              sl_order_no ,
                              sl_order_date ,
                              sl_order_add_time ,
                              sl_cp_id ,
                              sl_erp_id,
							  sl_pm,
							  sl_location,
							  sl_boxbynum,
							  sl_box_num
                            )
                     select   so.eoid ,
                              so.elid ,
                              so.[sid] ,
                              so.cid ,
                              so.gid ,
                              so.skuid ,
                              so.mytype ,
                              so.countType ,
                              so.gnum ,
                              so.addtime ,
                              @now ,
                              so.myremark ,
                              1 ,
                              so.orderno ,
                              so.order_date ,
                              so.order_add_time ,
                              so.cp_id ,
                              so.erp_id,
							  isnull(so.pm,''),
							  so.lid,
							  so.boxbynum,
							  isnull(so.box_num,0)
				  from (
				  SELECT    je.oo_siid AS SID ,
                            je.oo_ciid AS cid ,
							jl.ol_locationid as lid,
                            jl.ol_siid AS gid ,
                            jl.ol_skuid AS skuid ,
                            jl.ol_number AS gnum ,
						    isnull(jl.ol_pm,'')             As pm ,
							jl.ol_boxbynum as boxbynum,
							jl.ol_box_num as  box_num,
                            countType = CASE WHEN je.oo_type = 0 THEN 1
                                             ELSE 0
                                        END ,
                            myremark = CASE WHEN je.oo_type = 0 THEN '出库退货'
                                            ELSE '出库'
                                       END ,
                            addtime = jl.ol_addtime ,
                            orderno = je.oo_no ,
                            eoid = je.oo_id ,
                            elid = jl.ol_id ,
                            mytype = 2 ,
                            order_add_time = je.oo_addtime ,
                            order_date = je.oo_entrydate ,
                            je.oo_cp_id AS cp_id ,
                            je.oo_erp_id AS erp_id
                  FROM      j_outStorage je
                            INNER JOIN j_outStorageList jl ON je.oo_id = jl.ol_eoid
                  WHERE     je.oo_id = @id
                            AND je.oo_status =2
                            AND jl.ol_status = 1
                            AND jl.ol_siid > 0
                            AND je.oo_siid > 0
					 ) as so

		--计算汇总库存
        EXEC pro_mergeStockSum_new @cp_id = @cp_id, @id = @id, @type = 2

	   --计算汇总仓位库存
		EXEC pro_mergeStocklocationSum_new @cp_id=@cp_id,@id=@id,@type=2

	    
	--计算汇总批次库存
	exec pro_mergeStockBatchSum @id=@id,@stockType=2;

	 --固话库存变动明细
	EXEC pro_mergeStockLogSum @cp_id=@cp_id,@orderid=@id,@stockType=2


	delete j_stocklog where  sl_status = 0 and sl_cp_id = @cp_id and sl_eoid = @id and sl_type = 2


	DECLARE @tdoc_xml VARCHAR(max)= '';
	declare @erpid int=0;
	declare @oo_no varchar(255)='';
	select @oo_no=oo_no from j_outStorage where oo_id=@id;
	select @erpid=cp_erp_id from companyinfo where cp_id=@cp_id;
		
	SET @tdoc_xml = '{"said":"' + CONVERT(VARCHAR(50), @id) + '","type":"1","cp_id":"' + CONVERT(VARCHAR(50), @cp_id) + '"}';
	EXEC pro_apiqueue_op @tdoc_target='', @tdoc_action='', @tdoc_method = 'royaltyscheme', @tdoc_xml = @tdoc_xml, @tdoc_erp_id =@erpid, @tdoc_state = 0,
	 @tdoc_no=@oo_no, @tdoc_cp_id=@cp_id;



    IF @@ERROR <> 0
        BEGIN
           IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
        END
        ELSE
        BEGIN
           IF @@TRANCOUNT > 0 COMMIT TRAN
        END
    END
go

