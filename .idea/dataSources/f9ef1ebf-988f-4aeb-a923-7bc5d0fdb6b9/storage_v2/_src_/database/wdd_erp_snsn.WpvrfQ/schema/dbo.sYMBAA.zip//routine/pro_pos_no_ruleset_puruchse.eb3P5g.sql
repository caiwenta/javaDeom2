CREATE PROCEDURE [dbo].[pro_pos_no_ruleset_puruchse]
    @gi_id INT ,
    @sh_id INT , --店铺
    @gss_no VARCHAR(30) = '',
	@type int=1
AS
    BEGIN
		--进货价
        DECLARE @ghj DECIMAL(9, 2) = 0;
		declare @discount DECIMAL(9, 2) = 0;
        DECLARE @ghj_type INT = 0; --价格类型
        DECLARE @erp_id INT = 0;

		select 
		@erp_id=sh_erp_id 
		from pos_shop where sh_id=@sh_id;


		--IF @type = 1
		--	BEGIN
		--       --店铺信息
		--       SELECT @erp_id = sh_erp_id ,@ghj_type = sh_dhprice,@discount=sh_dhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_dhprice>0;
		--    END         
		--ELSE 
		--IF @type = 2
		--BEGIN
		--      SELECT @erp_id = sh_erp_id ,@ghj_type = sh_bhprice,@discount=sh_bhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_bhprice>0;
		--END 

		

		declare @returntable table(
			gi_id int,
			sku_id int,
			retailprice DECIMAL(9, 2),--零售价
			discount DECIMAL(9, 2),
			importprices DECIMAL(9, 2)    --供货价
		)
		INSERT @returntable
		SELECT
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
		FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,0,@sh_id,0,@type)





		--有商品编号按商品编号    
        IF @gss_no <> ''
            BEGIN
                SELECT  @gi_id = gi_id
                FROM    b_goodsinfo
                WHERE   gi_code = @gss_no
                        AND gi_erp_id = @erp_id
        END
        SELECT  *
        INTO    #p
        FROM    b_goodsinfo AS bg
        WHERE   bg.gi_id = @gi_id;



		  update #p set
		        gi_importprices= l.importprices,
				gi_purchase = l.importprices,
				gi_purchase_discount=l.discount
		  from #p as p 
		  inner join @returntable as l on p.gi_id=l.gi_id







		----计算价格		
  --      UPDATE #p SET 
		--gi_purchase = gi_retailprice ,
		--gi_purchase_discount = 1 
		--WHERE ISNULL(gi_purchase, 0) = 0
		        
  --      UPDATE #p SET 
		--gi_purchase_discount = gi_purchase / gi_retailprice 
		--WHERE  ISNULL(gi_purchase, 0) != 0 AND ISNULL(gi_purchase_discount, 0) = 0
    

  --      IF @sh_id > 0
  --          BEGIN
		--		--有设置价格类型按价格类型计算，没有则默认
  --              IF @ghj_type > 0
  --                  BEGIN
		--				--得到价格
  --                      SELECT  @ghj = gd_price
  --                      FROM    b_goods_discount
  --                      WHERE   gd_gi_id = @gi_id
  --                              AND gd_class = 2
  --                              AND gd_type = @ghj_type
		        
  --                      IF @ghj > 0.00
  --                          BEGIN

		--						--更细供货价
  --                              UPDATE  #p SET gi_purchase = @ghj*@discount
		            
		--						--更新折扣价
  --                              UPDATE  #p SET gi_purchase_discount = ( CASE WHEN gi_retailprice = 0.00 THEN 0.00 ELSE gi_purchase / gi_retailprice END )
  --                          END
		--					else
		--					begin
		--						UPDATE  #p SET gi_purchase = gi_importprices

		--						UPDATE  #p SET gi_purchase_discount = ( CASE WHEN gi_retailprice = 0.00 THEN 0.00 ELSE gi_purchase / gi_retailprice END)
		--					end
  --                  END
  --              ELSE
  --                  BEGIN

  --                      UPDATE  #p SET gi_purchase = gi_importprices

  --                      UPDATE  #p SET gi_purchase_discount = ( CASE WHEN gi_retailprice = 0.00 THEN 0.00 ELSE gi_purchase / gi_retailprice END)

  --                  END
  --          END
		

		--吊牌价设置
		DECLARE @lsj       DECIMAL(9, 2) = 0;--零售价
		DECLARE @dpj_type  INT = 0;--吊牌价类型

		SELECT @dpj_type = ps.sh_goods_type
		FROM   pos_shop ps
		WHERE  ps.sh_id = @sh_id

		IF @dpj_type != 0
		BEGIN
			SELECT @lsj = gd_price
			FROM   b_goods_discount
			WHERE  gd_type = @dpj_type
	           AND gd_class = 1 AND gd_gi_id = @gi_id
			--零售价
			UPDATE #p SET  gi_retailprice = @lsj
		END


		--更新折扣价
		UPDATE #p
		SET    gi_purchase_discount = (
	               CASE 
	                    WHEN gi_retailprice = 0.00 THEN 0.00
	                    ELSE gi_purchase / gi_retailprice
	               END
		)



        SELECT * FROM    #p
    END
go

