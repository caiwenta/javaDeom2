CREATE PROCEDURE [dbo].[pro_payment_op]
 @said INT=0,
 @svc_id INT=0,
 @action VARCHAR(50)='confirm',
 @erp_id INT=0,
 @svc_vo VARCHAR(100)='',
 @cxorderno varchar(200)=''

AS
	
DECLARE @status INT=0;



IF	@action='callback'
BEGIN
	
	SELECT 
	@status=es.svc_status,
	@svc_id=es.svc_id
	FROM erp_storedvaluecardcode AS es WHERE svc_vo=@svc_vo AND erp_id=@erp_id 
	
	
	IF @status=1
	BEGIN
		UPDATE erp_storedvaluecardcode SET 
		svc_status =2,
		svc_confirm=2,
		svc_confirmdatetime=GETDATE(),
		svc_si_id=0,
		cxorderno=@cxorderno
		WHERE svc_id=@svc_id;
	END
	ELSE IF @status=2 --注意订单已经手工确定了
	BEGIN
		
		UPDATE erp_storedvaluecardcode SET 
		svc_status=3, 
		svc_updatetime=GETDATE(),
		me_balance=(case when erp_storedvaluecardcode.me_id<>0 then (select me_balance from pos_memberInfo as pm where pm.me_id=erp_storedvaluecardcode.me_id) else 0 end),
		cxorderno=@cxorderno 
		WHERE svc_id=@svc_id;
		
	END
	
	
END


IF	@action='confirm'
BEGIN
	
	SELECT 
	@status=es.svc_status
	FROM erp_storedvaluecardcode AS es WHERE  svc_id=	@svc_id
	
	
	IF @status=1 --手工确定了
	BEGIN
		
		UPDATE erp_storedvaluecardcode 
		SET svc_status =2,
			sa_id=@said,
			svc_confirm=1,
			svc_confirmdatetime=GETDATE() 
		WHERE svc_id=@svc_id
		
	END
	ELSE IF @status=2
	BEGIN
	
		UPDATE erp_storedvaluecardcode 
		SET svc_status=3,
		sa_id=@said,
		svc_updatetime=GETDATE(),
		me_balance=(case when erp_storedvaluecardcode.me_id<>0 then (select me_balance from pos_memberInfo as pm where pm.me_id=erp_storedvaluecardcode.me_id) else 0 end) 
		WHERE svc_id=@svc_id;
	
	END
	
END
go

