CREATE PROCEDURE [dbo].[pro_storedvaluecardcode_op]
    @me_id INT = 0,
	@erpid INT = 0,
	@shipid INT = 0,
	@said INT = 0,
	@payment  DECIMAL(9, 2) = 0,  
	@status int=0,
	@addtime DATETIME = '2014-10-24',
	@add_man int=0,
	@paytype int=0,
	@svc_id INT = 0,
	@cp_vo VARCHAR(100) = '',  
	@remark VARCHAR(100) = ''
AS

--修改状态为3
if @svc_id>0
begin

   select @cp_vo=svc_vo from erp_storedvaluecardcode WHERE svc_id=@svc_id AND svc_status=2

   UPDATE erp_storedvaluecardcode 
   SET svc_status=3,
   sa_id=@said,
   svc_updatetime=GETDATE()
   WHERE svc_id=@svc_id

   if @me_id>0
   begin
     UPDATE erp_storedvaluecardcode 
	        SET me_balance=(select me_balance from pos_memberInfo as pm where pm.me_id=@me_id)
     WHERE svc_id=@svc_id
   end

end


if @cp_vo=''
   begin
     set @cp_vo='SK' +(Select REPLACE(CONVERT(varchar(100), GETDATE(), 112)+CONVERT(varchar(100), GETDATE(), 8),':','')+CONVERT(varchar(50),@me_id)+CONVERT(varchar(50),@svc_id));
  end



IF(SELECT me_balance FROM pos_memberInfo WHERE me_id=@me_id)>=@payment 
BEGIN 


insert into erp_cardpaymentdetail
(
me_id,
erpid,
shipid,
said,
sa_vo,
balance,
payment,
status,
addtime,
add_man,
paytype,
cp_vo,
remark
)
values 
(@me_id,@erpid,@shipid,@said,
(SELECT sa_vo FROM pos_sale AS ps WHERE ps.sa_id=@said),
(select me_balance from pos_memberInfo as pm where pm.me_id=@me_id),
@payment,
@status,
@addtime,
@add_man,
@paytype,
@cp_vo,
@remark
); 


UPDATE pos_memberInfo SET me_payment = me_payment+@payment,me_balance=me_balance-@payment WHERE me_id=@me_id;

END
go

