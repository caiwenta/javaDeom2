CREATE FUNCTION [dbo].[FNCKapiqueue]
(
	@tdoc_method varchar(255),
	@tdoc_xml varchar(MAX)
)
RETURNS INT
AS
BEGIN
	 DECLARE @re INT=1;
	 if @tdoc_method='fundorderreconciliation'
		begin
			if @tdoc_xml='' or @tdoc_xml is null
			begin
				set @re=0;
			end
		end
	if @tdoc_method='mergefundorder'
	begin
		if @tdoc_xml='' or @tdoc_xml is null
		begin
			set @re=0;
		end
	end
	 RETURN @re;
END
go

