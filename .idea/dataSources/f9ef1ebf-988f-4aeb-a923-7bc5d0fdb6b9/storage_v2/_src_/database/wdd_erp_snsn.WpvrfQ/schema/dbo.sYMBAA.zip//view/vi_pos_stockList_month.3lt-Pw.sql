




CREATE VIEW [dbo].[vi_pos_stockList_month] AS 

Select je.in_st_id As sid,
      je.in_sh_id as shid,
      cid=0
      ,je2.inl_gi_id As gid
      ,je2.inl_sku_id As skuid
      ,je2.inl_num As gnum
      ,je2.inl_money as allmoney
      --类型(0:入库1:退货)
      --入库加库存
      --入库退货减库存
      ,countType = Case when je.in_type=0 Then 1 Else 0 End
	  ,myremark=CASE WHEN je.in_type=0 THEN '入库' ELSE '入库退货' end
      ,addtime=je2.inl_add_time
      ,orderno=je.in_vo
      ,eoid=je.in_id
      ,elid=je2.inl_id
      ,mytype=1
      ,order_add_time=je.in_add_time
      ,order_date=je.in_date
From   pos_inStorage je
       Inner Join pos_inStorageList je2
            On  je.in_id = je2.inl_in_id
Where je.in_status>0 and je2.inl_status=1
and je2.inl_num!=0
AND je2.inl_gi_id>0
AND je.in_st_id>0
Union ALL

--期初
select 
jt.in_st_id As [sid],
jt.in_sh_id as shid,
cid=0,
ji.inl_gi_id As gid,
ji.inl_sku_id As skuid,
ji.inl_num As gnum,
ji.inl_money as allmoney,
countType=1,
myremark='期初',
ji.inl_add_time as addtime,
jt.in_vo as  orderno,
jt.in_id as eoid,
ji.inl_id as elid,
mytype=3
,order_add_time=jt.in_add_time
,order_date=jt.in_date
 from pos_initStorage as jt inner join pos_initStorageList as ji on jt.in_id=ji.inl_in_id
where jt.in_status>0 and ji.inl_status=1
and ji.inl_num!=0
AND ji.inl_gi_id>0
AND jt.in_st_id>0

union all
--移仓
select 
jms.mo_out_st_id as sid,
jms.mo_sh_id AS shid,cid=0,
jmsl.mol_gi_id as gid,
jmsl.mol_sku_id as skuid,
jmsl.mol_num as gnum,
jmsl.mol_num *bg.gi_purchase  as allmoney,
countType=0,
myremark='移出仓库',
addtime=jmsl.mol_add_time,
orderno=mo_vo,
eoid=mo_id,
elid=mol_id,
mytype=4
,order_add_time=jms.mo_add_time
,order_date=jms.mo_date
from pos_moStorage as jms 
inner join pos_moStorageList as jmsl
on jms.mo_id=jmsl.mol_mo_id
Inner JOIN b_goodsinfo AS bg ON jmsl.mol_gi_id =bg.gi_id
where jms.mo_status>0 and jmsl.mol_status=1
and jmsl.mol_num>0
AND jmsl.mol_gi_id>0
AND jms.mo_out_st_id>0
union all
select 
jms.mo_in_st_id as sid,
jms.mo_sh_id AS shid,
cid=0,
jmsl.mol_gi_id as gid,
jmsl.mol_sku_id as skuid,
jmsl.mol_num as gnum,
jmsl.mol_num *bg.gi_purchase  as allmoney,
countType=1,
myremark='移入仓库',
addtime=jmsl.mol_add_time,
orderno=mo_vo,
eoid=mo_id,
elid=mol_id,
mytype=5,
order_add_time=jms.mo_add_time,
order_date=jms.mo_date
from pos_moStorage as jms inner join pos_moStorageList as jmsl
on jms.mo_id=jmsl.mol_mo_id
Inner JOIN b_goodsinfo AS bg ON jmsl.mol_gi_id =bg.gi_id
where jms.mo_status>0 and jmsl.mol_status=1
and jmsl.mol_num!=0
AND jmsl.mol_gi_id>0
AND jms.mo_in_st_id>0
union all
 --盈亏明细
select 
	  jps.pl_st_id As sid
      , jps.pl_sh_id AS shid,cid=0
      ,jpsl.ppl_gi_id As gid
      ,jpsl.ppl_sku_id As skuid
      ,abs(jpsl.ppl_num) As gnum
      ,abs(jpsl.ppl_num)*bg.gi_purchase as allmoney
      ,countType =(Case when jpsl.ppl_num>=0 Then 1 Else 0 End)
      ,myremark='盈亏'
      ,addtime=jpsl.ppl_add_time
      ,orderno=jps.pl_vo
      ,eoid=jps.pl_id
      ,elid=jpsl.ppl_id
      ,mytype=6
      ,order_add_time=jps.pl_add_time
	  ,order_date=jps.pl_date
 from pos_plStorage as jps inner join pos_plStorageList as jpsl
 on jps.pl_id=jpsl.ppl_pl_id
 Inner JOIN b_goodsinfo AS bg ON jpsl.ppl_gi_id=bg.gi_id
 where jps.pl_status=2 and jpsl.ppl_status=1
 and jpsl.ppl_num!=0 
 AND jpsl.ppl_gi_id>0
 AND jps.pl_st_id>0 
union all
 --调拨
select 
	  jps.al_st_id As sid
      , jps.al_sh_id AS shid,cid=0
      ,jpsl.all_gi_id As gid
      ,jpsl.all_sku_id As skuid
      ,abs(jpsl.all_num) As gnum
      , (abs(jpsl.all_num)*jpsl.all_retail_price) as allmoney
      --,countType =(Case when jpsl.all_num>=0 Then 1 Else 0 End)
      ,countType=0
      ,myremark='调拨'
      ,addtime=jpsl.all_add_time
      ,orderno=jps.al_vo
      ,eoid=jps.al_id
      ,elid=jpsl.all_id
      ,mytype=6
      ,order_add_time=jps.al_add_time
	  ,order_date=jps.al_date
 from pos_alStorage as jps inner join pos_alStorageList as jpsl
 on jps.al_id=jpsl.all_al_id
 where jps.al_status>0 and jpsl.all_status=1
 and jpsl.all_num!=0 
union all
 --销售前台
select 
	  jps.sa_st_id As sid
      , jps.sa_sh_id AS shid,cid=0
      ,jpsl.sal_gi_id As gid
      ,jpsl.sal_sku_id As skuid
      ,abs(jpsl.sal_num) As gnum
      ,jpsl.sal_money as allmoney
      ,countType = (CASE WHEN jpsl.sal_is_return=1 OR jpsl.sal_is_change=1 THEN 1 WHEN jpsl.sal_num >= 0 THEN 0 ELSE 1 END)
      ,myremark='销售前台'
      ,addtime=jpsl.sal_add_time
      ,orderno=jps.sa_vo
      ,eoid=jps.sa_id
      ,elid=jpsl.sal_id
      ,mytype=6
      ,order_add_time=jps.sa_add_time
	  ,order_date=jps.sa_date
 from pos_sale as jps inner join pos_saleList as jpsl
 on jps.sa_id=jpsl.sal_sa_id
 where jps.sa_status>0 and jpsl.sal_status=1
 and jpsl.sal_num!=0 
union all
--盘点,整仓盘点库存抵消
select 
js.sl_seiid as sid,
js.sl_shid as shid,
cid=0,
js.sl_giid as gid,
js.sl_skuid as skuid,
js.sl_number ,
0 as allmoney,
js.sl_counttype,
js.sl_remark,
js.sl_addtime,
js.sl_order_no,
js.sl_eoid,
js.sl_elid,
mytype=7--前台可以此为条件,不显示
,order_add_time=js.sl_order_add_time
,order_date=js.sl_order_date
from pos_stocklog_pal as js 
where js.sl_status=2 and js.sl_number!=0 
union all
--整仓盘点,盘点明细
select 
vt.sl_seiid ,
vt.sl_shid,
cid=0,
vt.sl_giid,
vt.sl_skuid,
vt.sl_number ,
0 as allmoney,
vt.sl_counttype,
vt.sl_remark,
vt.sl_addtime,
vt.sl_order_no,
vt.sl_eoid,
vt.sl_elid,
vt.sl_type,
vt.sl_order_add_time,
vt.sl_order_date
from pos_stocklog_pal as vt
where vt.sl_status=1  and vt.sl_number!=0
go

