
CREATE Proc [dbo].[pro_pos_customPrice_op]
--主键  
@cp_id int=0,  
@cp_erp_id int=0,  
--单据号  
@cp_no varchar(50)='',  
--单据日期  
@cp_date datetime='2014-11-20',  
--添加人主键  
@cp_add_man int=0,  
--添加时间  
@cp_add_time datetime='2014-11-20',  
--修改人主键  
@cp_update_man int=0,  
--修改时间  
@cp_update_time datetime='2014-11-20',  
--审核人主键  
@cp_audit_man int=0,  
--审核时间  
@cp_audit_time datetime='2014-11-20',  
--制单人主键  
@cp_order_man int=0,  
--备注  
@cp_remark varchar(50)='',  
--主键  
@cpl_id int=0,  
--调价单主键  
@cpl_cp_id int=0,  
--商品主键  
@cpl_gi_id int=0,  
--店铺主键  
@cpl_sh_id int=0,  
--起始日期  
@cpl_start datetime='2014-11-20',  
--终止日期  
@cpl_end datetime='2014-11-20',  
--零售价  
@cpl_retail_price decimal(18,2)=0,  
--折率  
@cpl_discount decimal(18,2)=0,  
--供货价  
@cpl_stock_price decimal(18,2)=0,  
--更新类型(1,零售价:2,折率:3,供货价)  
@cpl_update_type int=0,  
--备注  
@cpl_remark varchar(200)='',  
--添加时间  
@cpl_add_time datetime='2014-11-20',  
--操作类型  
@op_type varchar(100)='添加修改单据,明细',  
--结果  
@result varchar(100)='' out
as
BEGIN
 --是否添加单据
 declare @isInsert int = 0;
 --是否需要更新单据
 declare @need_update int = 0;
 --旧的单据日期
 declare @old_order_date datetime;
 --单据日期是否更改
 declare @old_order_date_is_changed int = 0;
 --凭证号前缀
 declare @myprevTxt varchar(50) = 'TJ';
 begin tran
 
 
 
 
 
if @op_type='添加修改单据,明细'
begin
	
	--清除之前的内容
	if @cp_id!=0 and (select Count(1) As count from pos_customPriceList where cpl_cp_id=@cp_id)>0
	begin
		--得到添加时间
		declare @add_time datetime;
		select top 1 @add_time=pcpl.cpl_add_time
		from pos_customPriceList as pcpl where pcpl.cpl_cp_id=@cp_id ;
		if @add_time!=@cpl_add_time
		BEGIN
			delete from pos_customPriceList where cpl_cp_id=@cp_id;
		END
	END
	
 if @cp_id=0
 begin
  
 --添加单据
 insert into pos_customPrice(cp_vo,cp_no,cp_date,cp_add_man,cp_add_time,cp_update_man,cp_update_time,cp_order_man,cp_status,cp_remark,cp_erp_id)values(newid(),@cp_no,@cp_date,@cp_add_man,@cp_add_time,@cp_update_man,@cp_update_time,@cp_order_man,1,@cp_remark,@cp_erp_id);set  @cp_id=SCOPE_IDENTITY();
 
 set @cpl_cp_id=@cp_id;
 set @isInsert = 1;
 end
  else
     begin
         set @need_update = 1;
     end
  
     if @cpl_id=0
     BEGIN
      insert into pos_customPriceList(cpl_cp_id,cpl_gi_id,cpl_sh_id,cpl_start,cpl_end,cpl_retail_price,cpl_discount,cpl_stock_price,cpl_update_type,cpl_remark,cpl_add_time)values(@cpl_cp_id,@cpl_gi_id,@cpl_sh_id,@cpl_start,@cpl_end,@cpl_retail_price,@cpl_discount,@cpl_stock_price,@cpl_update_type,@cpl_remark,@cpl_add_time);set  @cpl_id=SCOPE_IDENTITY();
     end
     else
     BEGIN
   update pos_customPriceList set cpl_cp_id=@cpl_cp_id,cpl_gi_id=@cpl_gi_id,cpl_sh_id=@cpl_sh_id,cpl_start=@cpl_start,cpl_end=@cpl_end,cpl_retail_price=@cpl_retail_price,cpl_discount=@cpl_discount,cpl_stock_price=@cpl_stock_price,cpl_update_type=@cpl_update_type,cpl_remark=@cpl_remark where cpl_id=@cpl_id;
     END
end
if @op_type = '审核单据'
 begin
     --审核单据
     update pos_customPrice
     set    cp_status = 2,
            cp_audit_man     =@cp_update_man,
            cp_audit_time       = getdate()
     where  cp_id               = @cp_id;
    
 end
if @op_type = '取消审核单据'
 begin
     --取消审核单据
     update pos_customPrice
     set    cp_status     = 1
     where  cp_id         = @cp_id;
    
 end
 
 if @op_type = '删除单据'
 begin
     --删除单据
     update pos_customPrice
     set    cp_status     = 0
     where  cp_id         = @cp_id;
     
 end
 
 



 if @op_type = '添加修改单据,明细' or @need_update = 1 or @op_type='修改单据'
 begin
    --得到旧的单据日期
     select @old_order_date = jt.cp_date
     from pos_customPrice  as jt
     where  jt.cp_id = @cp_id;
     if @old_order_date != @cp_date
     begin
         set @old_order_date_is_changed = 1;
     end
  
  update pos_customPrice set cp_no=@cp_no,cp_date=@cp_date,cp_update_man=@cp_update_man,cp_update_time=@cp_update_time,cp_order_man=@cp_order_man,cp_remark=@cp_remark where cp_id=@cp_id;
  
  
  end


if @isInsert = 1
    or @old_order_date_is_changed = 1
 begin
     --凭证号生成
     --更新凭证号 
     declare @tableName varchar(50) = 'pos_customPrice'
     declare @idField varchar(50) = 'cp_id'
     declare @idValue int = @cp_id;
    
     declare @dateField varchar(50) = 'cp_date'
     declare @dateValue varchar(50) = convert(varchar(50),@cp_date, 23)
 
     declare @noField varchar(50) = 'cp_vo'
     declare @prevTxt varchar(50) = @myprevTxt
     declare @outno varchar(100) = ''
     declare @while int = 0;
     while @while = 0
     begin
         --得到凭证号
         execute [pro_gen_orderNo]@tableName,
              @idField,
              @idValue,
              @dateField,
              @dateValue,
              @noField,
              @prevTxt,
              @outno output
         
         begin try
          --更新
          update pos_customPrice
          set cp_vo = @outno
		  ,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)

          where cp_id           = @cp_id;
          
          --更新成功,赋值,结束循环
          set @while = 1;
         end try
         begin catch
		 PRINT '';
          ----发生错误,判断错误类型
          --if charindex('重复键', error_message(), 0) = 0
          --begin
          --    --不是发生重复的错误
          --    --赋值,结束循环
          --    set @while = 1;
          --end
         end catch
     end
 end


if @@ERROR <> 0
 begin
     set @result = '0';
     IF @@TRANCOUNT > 0 rollback tran;
 end
 else
 begin
     if @isInsert = 1
     begin
         set @result = convert(varchar(50),@cp_id);
     end
     else
     begin
         if @op_type = '添加修改单据,明细'
         begin
             set @result = convert(varchar(50),@cpl_id);
         end
         else
         begin
             set @result = '1';
         end
     end
     IF @@TRANCOUNT > 0 commit tran;
 end
  
end
go

