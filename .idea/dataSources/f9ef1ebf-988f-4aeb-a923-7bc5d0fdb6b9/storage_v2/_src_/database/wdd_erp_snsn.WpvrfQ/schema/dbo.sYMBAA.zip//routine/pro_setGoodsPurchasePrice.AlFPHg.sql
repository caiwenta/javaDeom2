CREATE PROCEDURE [dbo].[pro_setGoodsPurchasePrice]
(
    @oo_id int,
	@wt int=0 --0:出库 1:配货 2:订单 3:pos入库 4:pos补货 5:pos调拨 6:POS移仓 7:POS期初 8:盘点
)

AS
BEGIN
DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
BEGIN TRY
   
	DECLARE @IsCustomPrice int=0;--是否自定义调价（注意pos不使用自定义调价）
	DECLARE @ci_id int;
	DECLARE @sh_id int;
	DECLARE @to_cp_id int;
	DECLARE @type int;
	DECLARE @date DATETIME;
    DECLARE @cp_id INT;
	DECLARE @returntable TABLE
	(
		cspid int,
		gi_id int,
		gi_skuid int,
		supplyprice DECIMAL(9, 2),
		discount  DECIMAL(9, 2),
		gs_marketprice DECIMAL(9, 2),--零售价
		gs_discount DECIMAL(9, 2),
		gs_purchase DECIMAL(9, 2)    --供货价
	)

	---商品调价
	DECLARE @temp TABLE ( gi_id INT ) 
	
	IF @wt=0
	BEGIN
	    set @IsCustomPrice=1;
		SELECT 
			@type=oo_jytype,
			@ci_id=oo_ciid,
			@sh_id=oo_sh_id,
			@to_cp_id=oo_to_cp_id,
			@date=oo_entrydate,
			@cp_id=oo_cp_id
		FROM j_outStorage AS jos WHERE jos.oo_id=@oo_id;


	INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.ol_siid,josl.ol_skuid  
		FROM j_outStorageList AS josl
		WHERE josl.ol_eoid=@oo_id and josl.ol_status>0
		GROUP BY josl.ol_siid,josl.ol_skuid 
	) AS os ON tt.gi_id=os.ol_siid AND tt.sku_id=os.ol_skuid

	INSERT INTO @temp(gi_id)
	SELECT distinct ol_siid FROM j_outStorageList where ol_eoid=@oo_id and ol_status>0;

	END
	ELSE IF @wt=1
	BEGIN
		set @IsCustomPrice=1;
	   SELECT 
			@type=al_type,
			@ci_id=al_ci_id,
			@sh_id=al_sh_id,
			@to_cp_id=al_to_cp_id,
			@date=al_date,
			@cp_id=al_cp_id
	   FROM pos_allocation WHERE al_id=@oo_id;

	   INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.all_gi_id,josl.all_sku_id  
		FROM pos_allocationList AS josl
		WHERE josl.all_al_id=@oo_id and josl.all_status>0
		GROUP BY josl.all_gi_id,josl.all_sku_id 

	) AS os ON tt.gi_id=os.all_gi_id AND tt.sku_id=os.all_sku_id

	   INSERT INTO @temp(gi_id)
	   SELECT distinct all_gi_id FROM pos_allocationList where all_al_id=@oo_id and all_status>0;

	END
	ELSE IF @wt=2
	BEGIN
		set @IsCustomPrice=1;
		SELECT 
		@type=og_type,
		@ci_id=og_ci_id,
		@sh_id=og_sh_id,
		@to_cp_id=og_to_cp_id,
		@date=og_date,
		@cp_id=og_cp_id
	FROM pos_ogStorage WHERE og_id=@oo_id;

		INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.ogl_gi_id,josl.ogl_sku_id  
		FROM pos_ogStorageList AS josl
		WHERE josl.ogl_og_id=@oo_id and josl.ogl_status>0
		GROUP BY josl.ogl_gi_id,josl.ogl_sku_id 

	) AS os ON tt.gi_id=os.ogl_gi_id AND tt.sku_id=os.ogl_sku_id
	
	INSERT INTO @temp(gi_id)
	SELECT distinct ogl_gi_id FROM pos_ogStorageList where ogl_og_id=@oo_id and ogl_status>0;


	END

	ELSE IF @wt=3
	BEGIN

	set @IsCustomPrice=0;
	set @type=1;
	select @sh_id=in_sh_id 
	from pos_inStorage where in_id = @oo_id;

	INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.inl_gi_id,josl.inl_sku_id  
			FROM pos_inStorageList AS josl
			WHERE josl.inl_in_id=@oo_id and josl.inl_status>0
		GROUP BY josl.inl_gi_id,josl.inl_sku_id 

	) AS os ON tt.gi_id=os.inl_gi_id AND tt.sku_id=os.inl_sku_id

	INSERT INTO @temp(gi_id)
	SELECT distinct inl_gi_id FROM pos_inStorageList where inl_in_id=@oo_id and inl_status>0;


	END
	ELSE IF @wt=4
	begin

	set @IsCustomPrice=0;
	set @type=2;
	select @sh_id=re.re_sh_id
	from pos_reStorage re where re.re_id= @oo_id;

	INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.rel_gi_id,josl.rel_sku_id  
			FROM pos_reStorageList AS josl
			WHERE josl.rel_re_id=@oo_id and josl.rel_status>0
		GROUP BY josl.rel_gi_id,josl.rel_sku_id 

	) AS os ON tt.gi_id=os.rel_gi_id AND tt.sku_id=os.rel_sku_id


	INSERT INTO @temp(gi_id)
	SELECT distinct rel_gi_id FROM pos_reStorageList where rel_re_id=@oo_id and rel_status>0;

	end
	ELSE IF @wt=5
	begin

	set @IsCustomPrice=0;
	set @type=1;
	select @sh_id=re.al_sh_id from pos_alStorage re where re.al_id= @oo_id;

	INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.all_gi_id,josl.all_sku_id  
			FROM pos_alStorageList AS josl
			WHERE josl.all_al_id=@oo_id and josl.all_status>0
		GROUP BY josl.all_gi_id,josl.all_sku_id 

	) AS os ON tt.gi_id=os.all_gi_id AND tt.sku_id=os.all_sku_id

	INSERT INTO @temp(gi_id)
	SELECT distinct all_gi_id FROM pos_alStorageList where all_al_id=@oo_id and all_status>0;


	end
	ELSE IF @wt=6
	begin

	set @IsCustomPrice=0;
	set @type=1;
	select @sh_id=re.mo_sh_id from pos_moStorage re where re.mo_id= @oo_id;

	INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.mol_gi_id,josl.mol_sku_id  
			FROM pos_moStorageList AS josl
			WHERE josl.mol_mo_id=@oo_id and josl.mol_status>0
		GROUP BY josl.mol_gi_id,josl.mol_sku_id 

	) AS os ON tt.gi_id=os.mol_gi_id AND tt.sku_id=os.mol_sku_id

	INSERT INTO @temp(gi_id)
	SELECT distinct mol_gi_id FROM pos_moStorageList where mol_mo_id=@oo_id and mol_status>0;


	end
	else if @wt=7
	begin

		set @IsCustomPrice=0;
		set @type=1;

		select @sh_id=re.in_sh_id from pos_initStorage re where re.in_id= @oo_id;

	INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.inl_gi_id,josl.inl_sku_id  
			FROM pos_initStorageList AS josl
			WHERE josl.inl_in_id=@oo_id and josl.inl_status>0
		GROUP BY josl.inl_gi_id,josl.inl_sku_id 

	) AS os ON tt.gi_id=os.inl_gi_id AND tt.sku_id=os.inl_sku_id

	INSERT INTO @temp(gi_id)
	SELECT distinct inl_gi_id FROM pos_initStorageList where inl_in_id=@oo_id and inl_status>0;

	end
	else if @wt=8
	begin

    set @IsCustomPrice=0;
	set @type=1;

	select @sh_id=re.ts_sh_id from pos_takeStorage re where re.ts_id= @oo_id;

	INSERT @returntable(gi_id,gi_skuid,supplyprice,discount,gs_marketprice,gs_discount,gs_purchase)
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 
	) AS TT
	INNER JOIN
	(
		SELECT josl.tsl_gi_id,josl.tsl_sku_id  
			FROM pos_takeStorageList AS josl
			WHERE josl.tsl_ts_id=@oo_id and josl.tsl_status>0
		GROUP BY josl.tsl_gi_id,josl.tsl_sku_id 

	) AS os ON tt.gi_id=os.tsl_gi_id AND tt.sku_id=os.tsl_sku_id

	INSERT INTO @temp(gi_id)
	SELECT distinct tsl_gi_id FROM pos_takeStorageList where tsl_ts_id=@oo_id and tsl_status>0;



	end








--设置供商价 FnGoodsERPPurchasePrice
DECLARE @ghj_type INT = 0;
DECLARE @discount  DECIMAL(9, 2) = 1;
IF @ci_id > 0 AND @type > 0
BEGIN

    IF @type = 1
	BEGIN

		SELECT @ghj_type = ci_dhprice,@discount=ci_dhdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_dhprice > 0;

	END	          
	ELSE 
	IF @type = 2
	BEGIN

		SELECT @ghj_type = ci_bhprice,@discount=ci_bhdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_bhprice > 0;

	END	
	ELSE 
	IF @type = 3
	BEGIN

		SELECT @ghj_type = ci_phprice,@discount=ci_phdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_phprice > 0;

	END	 
	ELSE 
	IF @type = 4
	BEGIN

		SELECT @ghj_type = ci_mdprice,@discount=ci_mddiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_mdprice > 0;

	END
    
	
END
ELSE 
IF @sh_id > 0 AND @type > 0
BEGIN
    --有选择店铺,并且有设置交易方式
     IF @type = 1
	BEGIN

		SELECT @ghj_type = sh_dhprice,@discount= sh_dhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_dhprice>0;

	END         
	ELSE 
	IF @type = 2
	BEGIN

		SELECT @ghj_type = sh_bhprice,@discount= sh_bhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_bhprice>0;

	END 
	ELSE 
	IF @type = 3
	BEGIN
	
		SELECT @ghj_type = sh_phprice,@discount= sh_phdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_phprice>0;
		               
	END	           
	ELSE 
	IF @type = 4
	BEGIN

		SELECT @ghj_type = sh_mdprice,@discount= sh_mddiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_mdprice>0;

	END	
    

END
ELSE 
IF @to_cp_id > 0 AND @type > 0
BEGIN

    --有选择店铺,并且有设置交易方式
     IF @type = 1
	BEGIN
	
		SELECT @ghj_type = cp_dhprice,@discount=cp_dhdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_dhprice > 0;

	END	          
	ELSE 
	IF @type = 2
	BEGIN
		
		SELECT @ghj_type = cp_bhprice,@discount=cp_bhdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_bhprice > 0;

	END	
	ELSE 
	IF @type = 3
	BEGIN
		
		SELECT @ghj_type = cp_phprice,@discount=cp_phdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_phprice > 0;

	END	 
	ELSE 
	IF @type = 4
	BEGIN
		
		SELECT @ghj_type = cp_mdprice,@discount=cp_mddiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_mdprice > 0;

	END
   
END
if @ghj_type>0
BEGIN
       
		UPDATE @returntable set supplyprice=(SELECT isnull(gd_price,0) FROM b_goods_discount WHERE  gd_gi_id = gi_id AND gd_class = 2 AND gd_type = @ghj_type);

		UPDATE @returntable set discount=@discount;

		UPDATE @returntable set gs_purchase=(case when supplyprice<>0.00 then supplyprice*discount else gs_purchase end);

		UPDATE @returntable SET gs_discount =(case when supplyprice<>0.00 then (CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END) else gs_discount end);
END



IF @wt=0
BEGIN

UPDATE j_outStorageList SET 
	supplyprice=gp.supplyprice,
	discount=gp.discount,
	ol_unit=gp.gs_marketprice,
	ol_costprice=gp.gs_purchase,
	ol_discount=gp.gs_discount
FROM j_outStorage AS jos
	INNER JOIN j_outStorageList AS josl ON jos.oo_id=josl.ol_eoid and josl.ol_status>0
	INNER JOIN @returntable AS gp ON josl.ol_siid=gp.gi_id AND josl.ol_skuid=gp.gi_skuid
WHERE jos.oo_id=@oo_id;

UPDATE j_outStorageList SET ol_realmoney = ol_number*ol_costprice WHERE ol_eoid=@oo_id;

END
ELSE IF @wt=1
BEGIN

UPDATE pos_allocationList SET 
	supplyprice=gp.supplyprice,
	discount=gp.discount,
	all_retail_price=gp.gs_marketprice,
	all_stock_price=gp.gs_purchase,
	all_discount=gp.gs_discount
FROM pos_allocation AS jos
	INNER JOIN pos_allocationList AS josl ON jos.al_id=josl.all_al_id and josl.all_status>0
	INNER JOIN @returntable AS gp ON josl.all_gi_id=gp.gi_id AND josl.all_sku_id=gp.gi_skuid
WHERE jos.al_id=@oo_id;

UPDATE pos_allocationList SET all_money = all_num*all_stock_price WHERE all_al_id=@oo_id;

END
ELSE IF @wt=2
BEGIN

UPDATE pos_ogStorageList SET 
	ogl_retail_price=gp.gs_marketprice,
	ogl_stock_price=gp.gs_purchase,
	ogl_discount=gp.gs_discount
FROM pos_ogStorage AS jos
	INNER JOIN pos_ogStorageList AS josl ON jos.og_id=josl.ogl_og_id and josl.ogl_status>0
	INNER JOIN @returntable AS gp ON josl.ogl_gi_id=gp.gi_id AND josl.ogl_sku_id=gp.gi_skuid
WHERE jos.og_id=@oo_id;

UPDATE pos_ogStorageList SET ogl_money = ogl_num*ogl_stock_price WHERE ogl_og_id=@oo_id;

END
ELSE IF @wt=3
BEGIN


UPDATE pos_inStorageList SET 
	inl_retail_price=gp.gs_marketprice,
	inl_stock_price=gp.gs_purchase,
	inl_discount=gp.gs_discount
FROM pos_inStorage AS jos
	INNER JOIN pos_inStorageList AS josl ON jos.in_id=josl.inl_in_id and josl.inl_status>0
	INNER JOIN @returntable AS gp ON josl.inl_gi_id=gp.gi_id AND josl.inl_sku_id=gp.gi_skuid
WHERE jos.in_id=@oo_id;

UPDATE pos_inStorageList SET inl_money = inl_num*inl_stock_price WHERE inl_in_id=@oo_id;


END
ELSE IF @wt=4
BEGIN


UPDATE pos_reStorageList SET 
	rel_retail_price=gp.gs_marketprice,
	rel_stock_price=gp.gs_purchase,
	rel_discount=gp.gs_discount
FROM pos_reStorage AS jos
	INNER JOIN pos_reStorageList AS josl ON jos.re_id=josl.rel_re_id and josl.rel_status>0
	INNER JOIN @returntable AS gp ON josl.rel_gi_id=gp.gi_id AND josl.rel_sku_id=gp.gi_skuid
WHERE jos.re_id=@oo_id;

UPDATE pos_reStorageList SET rel_money = rel_num*rel_stock_price WHERE rel_re_id=@oo_id;


END
ELSE IF @wt=5
BEGIN


UPDATE pos_alStorageList SET 
	all_retail_price=gp.gs_marketprice,
	all_stock_price=gp.gs_purchase,
	all_discount=gp.gs_discount
FROM pos_alStorage AS jos
	INNER JOIN pos_alStorageList AS josl ON jos.al_id=josl.all_al_id and josl.all_status>0
	INNER JOIN @returntable AS gp ON josl.all_gi_id=gp.gi_id AND josl.all_sku_id=gp.gi_skuid
WHERE jos.al_id=@oo_id;

UPDATE pos_alStorageList SET all_money = all_num*all_stock_price WHERE all_al_id=@oo_id;


END
ELSE IF @wt=6
BEGIN


UPDATE pos_moStorageList SET 
	mol_retail_price=gp.gs_marketprice,
	mol_stock_price=gp.gs_purchase,
	mol_discount=gp.gs_discount
FROM pos_moStorage AS jos
	INNER JOIN pos_moStorageList AS josl ON jos.mo_id=josl.mol_mo_id and josl.mol_status>0
	INNER JOIN @returntable AS gp ON josl.mol_gi_id=gp.gi_id AND josl.mol_sku_id=gp.gi_skuid
WHERE jos.mo_id=@oo_id;

UPDATE pos_moStorageList SET mol_money = mol_num*mol_stock_price WHERE mol_mo_id=@oo_id;


END 
ELSE IF @wt=7
begin

UPDATE pos_initStorageList SET 
	inl_retail_price=gp.gs_marketprice,
	inl_stock_price=gp.gs_purchase,
	inl_discount=gp.gs_discount
FROM pos_initStorage AS jos
	INNER JOIN pos_initStorageList AS josl ON jos.in_id=josl.inl_in_id and josl.inl_status>0
	INNER JOIN @returntable AS gp ON josl.inl_gi_id=gp.gi_id AND josl.inl_sku_id=gp.gi_skuid
WHERE jos.in_id=@oo_id;

UPDATE pos_initStorageList SET inl_money = inl_num*inl_stock_price WHERE inl_in_id=@oo_id;

end
else if @wt=8
begin

UPDATE pos_takeStorageList SET 
	tsl_retail_price=gp.gs_marketprice,
	tsl_stock_price=gp.gs_purchase,
	tsl_discount=gp.gs_discount
FROM pos_takeStorage AS jos
	INNER JOIN pos_takeStorageList AS josl ON jos.ts_id=josl.tsl_ts_id and josl.tsl_status>0
	INNER JOIN @returntable AS gp ON josl.tsl_gi_id=gp.gi_id AND josl.tsl_sku_id=gp.gi_skuid
WHERE jos.ts_id=@oo_id;

UPDATE pos_takeStorageList SET 
tsl_new_money= tsl_new_num*tsl_stock_price,
tsl_old_money = tsl_old_num*tsl_stock_price,
tsl_log_money = (tsl_new_num - tsl_old_num)*tsl_stock_price
WHERE tsl_ts_id=@oo_id;



end



--总部调价
if @IsCustomPrice=1
begin

--清除数据
delete @returntable
DECLARE @gi_id AS INT;
WHILE EXISTS(SELECT gi_id FROM @temp)
BEGIN
    SELECT top 1 @gi_id= gi_id FROM @temp;

	INSERT @returntable
	(cspid,gi_id,gi_skuid,gs_marketprice,gs_discount,gs_purchase)
	SELECT 
	cspid,gi_id, sku_id,retailprice,discount,importprices
	FROM 
	dbo.FnGoodsCustomPrice(@ci_id,@sh_id,@to_cp_id,@date,@gi_id,0,@cp_id);

    DELETE FROM @temp WHERE gi_id=@gi_id;
END

if exists (select * from @returntable)  
begin

IF @wt=0
BEGIN

UPDATE j_outStorageList SET 
    ol_cspid=gp.cspid,
	ol_unit=gp.gs_marketprice,
	ol_costprice=gp.gs_purchase,
	ol_discount=gp.gs_discount
FROM j_outStorage AS jos
	INNER JOIN j_outStorageList AS josl ON jos.oo_id=josl.ol_eoid and josl.ol_status>0
	INNER JOIN @returntable AS gp ON josl.ol_siid=gp.gi_id AND josl.ol_skuid=gp.gi_skuid
WHERE jos.oo_id=@oo_id;

UPDATE j_outStorageList SET ol_realmoney = ol_number*ol_costprice WHERE ol_eoid=@oo_id;

END
ELSE IF @wt=1
BEGIN

UPDATE pos_allocationList SET 
	all_cspid=gp.cspid,
	all_retail_price=gp.gs_marketprice,
	all_stock_price=gp.gs_purchase,
	all_discount=gp.gs_discount
FROM pos_allocation AS jos
	INNER JOIN pos_allocationList AS josl ON jos.al_id=josl.all_al_id and josl.all_status>0
	INNER JOIN @returntable AS gp ON josl.all_gi_id=gp.gi_id AND josl.all_sku_id=gp.gi_skuid
WHERE jos.al_id=@oo_id;

UPDATE pos_allocationList SET all_money = all_num*all_stock_price WHERE all_al_id=@oo_id;

END
ELSE IF @wt=2
BEGIN

	UPDATE pos_ogStorageList SET 
		ogl_cspid=gp.cspid,
		ogl_retail_price=gp.gs_marketprice,
		ogl_stock_price=gp.gs_purchase,
		ogl_discount=gp.gs_discount
	FROM pos_ogStorage AS jos
	INNER JOIN pos_ogStorageList AS josl ON jos.og_id=josl.ogl_og_id and josl.ogl_status>0
	INNER JOIN @returntable AS gp ON josl.ogl_gi_id=gp.gi_id AND josl.ogl_sku_id=gp.gi_skuid
	WHERE jos.og_id=@oo_id;

	UPDATE pos_ogStorageList SET ogl_money = ogl_num*ogl_stock_price WHERE ogl_og_id=@oo_id;

END

end
	
end



END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH


if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);

END
go

