
CREATE view [dbo].[dbo.vi_j_Pos_customPrice_shop]
AS



--测试


















select * from pos_shop where sh_id in (select cpl_sh_id from pos_customPriceList)
go

