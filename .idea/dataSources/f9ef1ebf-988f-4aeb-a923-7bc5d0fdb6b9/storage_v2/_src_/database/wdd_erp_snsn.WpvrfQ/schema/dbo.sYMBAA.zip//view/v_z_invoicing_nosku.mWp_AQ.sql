CREATE VIEW [dbo].[v_z_invoicing_nosku]
	AS 
 SELECT
  
 bg.gi_name,   
 bg.gi_code,   
 bg.gi_barcode,   
 bg.gi_buyingteamid,
 bg.gi_type1,
 bg.gi_type2,
 bg.gi_type3,
 bg.gi_type4,
 (select si_name from b_stafftinfo where si_id=bg.gi_buyingteamid)gi_buyingteam, 
 (case when T.ei_objecttype=1 then T.ei_objectid when T.ei_objecttype=2 then T.ei_objectid end)cp_sh_id,   
 (case when T.ei_objecttype=1 then (select sh_name from pos_shop WITH (NOLOCK) WHERE sh_id=T.ei_objectid) when T.ei_objecttype=2 then (select cp_name from companyinfo WHERE cp_id=T.ei_objectid) end)cp_sh_name,
 T.ei_date,
 T.ei_objectid ,   
 T.ei_objecttype ,   
 T.ei_gi_id ,   
 T.ei_costprice, 
 T.ei_stockprice,--进货价 

 T.ei_firstnum,
 T.ei_firstcprice,  
 T.ei_firstnum* T.ei_stockprice ei_first_stock, --期初进货金额

 (T.ei_initnum-T.ei_initback) initnum ,  
 (T.ei_initmoney-T.ei_initbackmoney) initmoney , 
 (T.ei_initnum-T.ei_initback)* T.ei_stockprice init_stock ,  --入库进货金额

 (T.ei_ci_outnum - T.ei_ci_outback) wholesale ,  
 (T.ei_ci_outmoney - T.ei_ci_outbackmoney) wholesalemoney ,  
 (T.ei_ci_outnum - T.ei_ci_outback)* T.ei_stockprice wholesale_stock ,  --批发进货金额

 (T.ei_sh_onlysale) zeronum , 
 (T.ei_sh_onlysalecprice) zeromoney ,    
 (T.ei_sh_onlysale)* T.ei_stockprice zero_stock ,  --零售进货金额

 (T.ei_ci_outnum - T.ei_ci_outback + T.ei_sh_onlysale) salenum ,   
 (T.ei_ci_outmoney - T.ei_ci_outbackmoney + T.ei_sh_onlysalecprice) salemoney ,  
 (T.ei_ci_outnum - T.ei_ci_outback + T.ei_sh_onlysale)* T.ei_stockprice sale_stock ,   --总销售进货金额
  
 (CASE WHEN T.ei_objecttype = 1 THEN (T.ei_sh_sa_initnum + T.ei_sh_dis_initnum) WHEN T.ei_objecttype = 2 THEN (T.ei_sh_sa_outback + T.ei_sh_dis_outback) END) allotinit ,   
 (CASE WHEN T.ei_objecttype = 1 THEN (T.ei_sh_sa_initback + T.ei_sh_dis_initback + T.ei_sh_sa_allotnum + T.ei_sh_dis_allotnum) WHEN T.ei_objecttype = 2 THEN (T.ei_sh_sa_outnum + T.ei_sh_dis_outnum) END) allotout ,   

 (T.ei_lossnum) lossnum ,  
 (T.ei_losscprice) lossmoney ,  
 (T.ei_lossnum)* T.ei_stockprice loss_stock ,  --盈亏进货金额

 T.ei_erp_id

 FROM erp_invoicing_nosku AS T  
 left join b_goodsinfo bg WITH(NOLOCK) ON T.ei_gi_id = bg.gi_id AND bg.gi_status>0
 where ((SELECT cp_is_zorf FROM companyinfo WHERE T.ei_objecttype = 2 AND cp_id=T.ei_objectid)<>1 OR T.ei_objecttype = 1)
go

