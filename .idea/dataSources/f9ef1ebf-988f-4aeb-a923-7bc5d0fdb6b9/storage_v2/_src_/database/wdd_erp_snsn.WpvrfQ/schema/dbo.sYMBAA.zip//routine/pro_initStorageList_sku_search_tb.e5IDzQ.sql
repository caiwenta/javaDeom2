CREATE PROC [dbo].[pro_initStorageList_sku_search_tb]
@inl_in_id INT = 0,
@inl_add_time DATETIME = '2004-10-17',
@gi_id INT,
@cp_id INT = 0,
@inl_pm varchar(50)=''

AS
DECLARE @lsj DECIMAL(9, 2) = 0;
SELECT bg.*,
       p1.*,
       bg2.gi_name,
       bg2.gi_code INTO #p
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT *
                FROM   j_initStorageList AS jisl
                WHERE  jisl.inl_in_id = @inl_in_id
                       AND jisl.inl_add_time = @inl_add_time
                       AND jisl.inl_status = 1
					   AND jisl.inl_pm=@inl_pm
                       AND jisl.inl_gi_id = @gi_id
            ) AS p1
            ON  bg.gi_id = p1.inl_gi_id
            AND bg.gss_id = p1.inl_sku_id
       LEFT JOIN b_goodsinfo bg2
            ON  bg.gi_id = bg2.gi_id
WHERE  bg.gi_id = @gi_id;
IF @cp_id != 0
BEGIN
if EXISTS(SELECT c.cp_goods_type FROM  companyinfo c WHERE  c.cp_id = @cp_id and cp_goods_type!=0)
		BEGIN
    SELECT @lsj = gd_price
    FROM   b_goods_discount
    WHERE  gd_gi_id = @gi_id
           AND gd_type IN (SELECT c.cp_goods_type
                           FROM   companyinfo c
                           WHERE  c.cp_id = @cp_id)
           AND gd_class = 1
    
    UPDATE #p
    SET    gs_marketprice = @lsj
    
    UPDATE #p
    SET    gs_purchase = gs_marketprice * gs_discount
	END
END

SELECT *
FROM   #p
go

