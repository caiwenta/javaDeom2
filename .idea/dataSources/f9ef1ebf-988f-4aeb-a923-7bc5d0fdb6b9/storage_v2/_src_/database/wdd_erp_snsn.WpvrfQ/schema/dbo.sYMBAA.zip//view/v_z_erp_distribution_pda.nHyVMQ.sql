CREATE VIEW [dbo].[v_z_erp_distribution_pda]
	AS 
select 
(CASE WHEN TT.eo_num>0 THEN '已入库' else '未入库' end) as eostatus,
(CASE WHEN TT.eo_num>0 THEN inspectionnum else null end) as outinnum,
TT.* 
from (
SELECT
vz.do_id,dpda.si_id,
vz.do_source_id,vz.warehousingtype,
do_vo,dpda.applyqty,dpda.inspectionnum,dpda.di_status,
(SELECT si_name FROM b_stafftinfo bs WHERE bs.si_id=dpda.si_id) as pda_man,
(case di_status when 1 then null when 2 then di_addtime end) as finishtime,

(
CASE warehousingtype
WHEN 0 THEN (SELECT SUM(eo_num) FROM j_enterStorage jes WHERE jes.eo_source_id=vz.do_source_id  AND jes.eo_siid=vz.sei_id AND jes.eo_status<>0 AND jes.eo_source_type=1) 
WHEN 1 THEN (SELECT SUM(jos.oo_num) FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=2)--分公司入库退货
WHEN 2 THEN (SELECT SUM(jos.oo_num) FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 3 THEN (SELECT SUM(jos.oo_num) FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id  AND jos.oo_status<>0 and jos.oo_source_type=1)--配货
WHEN 5 THEN (SELECT sum(jms.mo_num) FROM j_moStorage AS jms WHERE jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
WHEN 8 THEN (SELECT SUM(jos.oo_num) FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=3)--pos入库退货
WHEN 27 THEN (SELECT SUM(jms.mo_num) FROM j_moStorage AS jms WHERE jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
WHEN 36 THEN (SELECT SUM(sal_num) FROM pos_saleList WHERE sal_sa_id=(SELECT TOP 1 ord_sa_id FROM netorder_tbl WHERE ord_id=vz.do_source_id))--网络订单生成销售单
end
) eo_num,

 (
 CASE warehousingtype
 WHEN 0 THEN (SELECT TOP 1 jes.eo_no FROM j_enterStorage jes WHERE jes.eo_source_id=vz.do_source_id AND jes.eo_source_type=1  AND jes.eo_siid=vz.sei_id  AND jes.eo_status<>0 )
 WHEN 1 THEN (SELECT TOP 1 jos.oo_no FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=2)--分公司入库退货
 WHEN 2 THEN (SELECT TOP 1 jos.oo_no FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
 WHEN 3 THEN (SELECT TOP 1 jos.oo_no FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id  AND jos.oo_status<>0 and jos.oo_source_type=1)--配货
 WHEN 5 THEN (SELECT TOP 1 jms.mo_vo  FROM j_moStorage AS jms WHERE jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
 WHEN 8 THEN (SELECT TOP 1 jos.oo_no FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=3)--pos入库退货
 WHEN 27 THEN (SELECT TOP 1 jms.mo_vo  FROM j_moStorage AS jms WHERE jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
 WHEN 36 THEN (SELECT top 1 sa_vo FROM pos_sale WHERE sa_id=(SELECT TOP 1 ord_sa_id FROM netorder_tbl WHERE ord_id=vz.do_source_id))--网络订单生成销售单
 end
 ) eo_no,

  (
 CASE warehousingtype
 WHEN 0 THEN (SELECT TOP 1 jes.eo_id FROM j_enterStorage jes WHERE jes.eo_source_id=vz.do_source_id AND jes.eo_source_type=1  AND jes.eo_siid=vz.sei_id  AND jes.eo_status<>0 )
 WHEN 1 THEN (SELECT TOP 1 jos.oo_id FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=2)--分公司入库退货
 WHEN 2 THEN (SELECT TOP 1 jos.oo_id FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
 WHEN 3 THEN (SELECT TOP 1 jos.oo_id FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=1)--配货
 WHEN 5 THEN (SELECT TOP 1 jms.mo_id  FROM j_moStorage AS jms WHERE jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
 WHEN 8 THEN (SELECT TOP 1 jos.oo_id FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=3)--pos入库退货
 WHEN 27 THEN (SELECT TOP 1 jms.mo_id  FROM j_moStorage AS jms WHERE jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
 WHEN 36 THEN (SELECT top 1 sa_id FROM pos_sale WHERE sa_id=(SELECT TOP 1 ord_sa_id FROM netorder_tbl WHERE ord_id=vz.do_source_id))--网络订单生成销售单
 end
 ) eo_id,

CONVERT(VARCHAR(10), (
CASE warehousingtype
WHEN 0 THEN (SELECT TOP 1 CONVERT(varchar(100), jes.eo_entrydate, 23) FROM j_enterStorage jes WHERE jes.eo_source_id=vz.do_source_id AND jes.eo_source_type=1  AND jes.eo_siid=vz.sei_id and jes.eo_status<>0) 
WHEN 1 THEN (SELECT TOP 1 jos.oo_entrydate FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=2)--分公司入库退货
WHEN 2 THEN (SELECT TOP 1 jos.oo_entrydate FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 3 THEN (SELECT TOP 1 jos.oo_entrydate FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=1)--配货
WHEN 5 THEN (SELECT TOP 1 jms.mo_date  FROM j_moStorage AS jms WHERE  jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
WHEN 8 THEN (SELECT TOP 1 jos.oo_entrydate FROM j_outStorage jos WHERE  jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 and jos.oo_source_type=3)--pos入库退货
WHEN 27 THEN (SELECT TOP 1 jms.mo_date  FROM j_moStorage AS jms WHERE  jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
WHEN 36 THEN (SELECT top 1 sa_date FROM pos_sale WHERE sa_id=(SELECT TOP 1 ord_sa_id FROM netorder_tbl WHERE ord_id=vz.do_source_id))--网络订单生成销售单
end
), 120) eo_entrydate,



vz.sei_id,
vz.do_status,
vz.do_addtime,
vz.cp_id,
vz.sh_id,
vz.do_applyqty,
vz.do_inspectionnum,
vz.erp_id


FROM erp_distributionorder AS vz
INNER JOIN erp_distributionpdaing AS dpda ON vz.do_id=dpda.do_id
WHERE vz.do_status>0
) as TT
go

