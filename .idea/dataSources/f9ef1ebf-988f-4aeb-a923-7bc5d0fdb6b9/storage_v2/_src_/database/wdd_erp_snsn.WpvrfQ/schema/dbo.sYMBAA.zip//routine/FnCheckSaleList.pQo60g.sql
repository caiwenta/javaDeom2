CREATE FUNCTION [dbo].[FnCheckSaleList]
(
	@sal_gi_id int,
	@sal_sku_id int,
	@sal_status int
)
RETURNS INT
AS
BEGIN
   --用途：验证销售单数据完整性
   DECLARE @re INT=1;

   if @sal_status>0
   begin
     
	 if @sal_gi_id=0
	 begin
	    SET @re = 0;
	 end

   end

   RETURN @re;
END
go

