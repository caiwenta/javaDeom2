CREATE PROCEDURE [dbo].[pro_apiqueue_op]
@tdoc_method varchar(255),
@tdoc_xml varchar(MAX)='',
@tdoc_hash bigint=0,
@tdoc_apitoken varchar(255)='',
@tdoc_cp_id int=0,
@tdoc_shid int=0,
@tdoc_erp_id int=0,
@tdoc_state int=0,
@tdoc_target varchar(50)='',
@tdoc_action varchar(50)='',
@tdoc_priority int=0,
@tdoc_no varchar(255)='' --异常单号

AS

IF NOT EXISTS(SELECT 1 FROM  api_queue WHERE tdoc_xml=@tdoc_xml and  tdoc_cp_id=@tdoc_cp_id and tdoc_erp_id=@tdoc_erp_id and tdoc_target=@tdoc_target and  tdoc_action=@tdoc_action AND tdoc_state=0)
BEGIN
insert into api_queue(tdoc_method,tdoc_xml,tdoc_hash,tdoc_apitoken,tdoc_erp_id,tdoc_cp_id,tdoc_state,tdoc_addtime,tdoc_target,tdoc_action,tdoc_shid,tdoc_no,tdoc_priority)
values (@tdoc_method,@tdoc_xml,@tdoc_hash,@tdoc_apitoken,@tdoc_erp_id,@tdoc_cp_id,@tdoc_state,GETDATE(),@tdoc_target,@tdoc_action,@tdoc_shid,@tdoc_no,@tdoc_priority)
END
go

