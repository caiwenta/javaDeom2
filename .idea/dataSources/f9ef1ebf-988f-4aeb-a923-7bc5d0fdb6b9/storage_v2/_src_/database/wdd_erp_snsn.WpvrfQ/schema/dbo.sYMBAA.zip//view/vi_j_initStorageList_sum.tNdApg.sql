CREATE VIEW [dbo].[vi_j_initStorageList_sum]
	AS 
SELECT 
jmsl.inl_in_id,
(SELECT SUM(isnull(inl_box_num,0)) FROM (
Select (case when fd.inl_boxbynum=0 then 0 else ceiling(sum(fd.inl_num)/fd.inl_boxbynum) end) as inl_box_num
From j_initStorageList fd where fd.inl_status=1 AND fd.inl_in_id=jmsl.inl_in_id
GROUP BY fd.inl_gi_id,isnull(fd.inl_pm,''),fd.inl_boxbynum
) AS BB
) AS inl_boxnum,
SUM(inl_num) AS inl_num,
SUM(inl_money) AS inl_money
FROM j_initStorageList AS jmsl WHERE jmsl.inl_status=1 
GROUP BY jmsl.inl_in_id
go

