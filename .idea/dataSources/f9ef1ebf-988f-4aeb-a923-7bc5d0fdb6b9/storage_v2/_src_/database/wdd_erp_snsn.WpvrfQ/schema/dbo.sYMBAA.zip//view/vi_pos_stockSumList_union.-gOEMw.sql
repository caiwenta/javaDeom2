CREATE VIEW [dbo].[vi_pos_stockSumList_union] AS 
SELECT
	ss.st_sh_id as shid,
	ss.st_gi_id as gid,
	ss.st_sku_id as skuid,
	ss.st_st_id as sid,
	ss.st_num as gnum,
	bs.sei_name,
	bs.sei_is_tb,--是否同步
	bg2.gs_name,
	bg2.gss_no,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.gi_unit,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_add_man,
	bg.gi_add_time,
	bg.gi_update_man,
	bg.gi_update_time,
	bg.gi_cp_id,
	bg.gi_di_id,
	bg.gi_attribute_ids,
	bg.gi_is_tb,
	bg.gi_attribute_parentids,
	bg.gi_purchase_discount,
	bu.ut_name,
	
	ss.st_occupy_num,
	enable_stock_num=ss.st_num-ISNULL(ss.st_occupy_num,0),
		(
SELECT TOP 1 sa_date FROM 
pos_sale INNER JOIN pos_saleList 
ON pos_sale.sa_id = pos_saleList.sal_sa_id 
WHERE dbo.pos_sale.sa_status <> 0
 and  sal_gi_id=ss.st_gi_id and sal_sku_id=ss.st_sku_id AND sa_st_id=bs.sei_id
ORDER BY sal_add_time DESC
	) AS last_sa_date
	
--最后的供应商
FROM
	pos_stockInfo AS ss WITH (NOLOCK) 
	
LEFT OUTER JOIN dbo.pos_storageInfo AS bs WITH (NOLOCK) ON ss.st_st_id = bs.sei_id
INNER JOIN dbo.b_goodsinfo AS bg WITH (NOLOCK) ON ss.st_gi_id = bg.gi_id
LEFT OUTER JOIN dbo.b_goodsruleset AS bg2 WITH (NOLOCK) ON ss.st_sku_id = bg2.gss_id
LEFT OUTER JOIN dbo.b_unit AS bu WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
go

