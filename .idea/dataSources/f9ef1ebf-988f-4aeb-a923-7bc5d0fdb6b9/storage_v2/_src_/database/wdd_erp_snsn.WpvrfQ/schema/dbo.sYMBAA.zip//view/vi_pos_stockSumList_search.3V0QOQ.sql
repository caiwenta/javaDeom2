



CREATE VIEW [dbo].[vi_pos_stockSumList_search]
AS
SELECT shid,
shid as sh_id,
       gid,
       skuid,
       SID,
       gnum,
       sei_name,
       gs_name,
       gss_no,
       gi_id,
       gi_shortname,
       gi_name,
       gi_type,
       gi_code,
       gi_grade,
       gi_norm,
       gi_status,
       gi_remark,
       gi_entrydate,
       gi_unit,
       si_img,
       gi_skus,
       gi_alarmstock,
       gi_barcode,
       gi_brands,
       gi_category,
       gi_costprice,
       gi_downstork,
       gi_importprices,
       gi_number,
       gi_retailprice,
       gi_seiid,
       gi_seiname,
       gi_typeone,
       gi_types,
       gi_typesid,
       gi_upstock,
       gi_virtual,
       gi_weight,
       gi_simplecode,
       gi_brandsid,
       isnull(gi_skuid,'') as gi_skuid,
       gi_purchase,
       gi_class,
       gi_class_id,
       gi_addtime,
       gi_updatetime,
       gi_oc_id,
       gi_tid,
       gi_taobao_id,
       gi_add_man,
       gi_add_time,
       gi_update_man,
       gi_update_time,
       ut_name,
       (
           SELECT sh_name
           FROM   pos_shop
           WHERE  (sh_id = vi_pos_stockSumList_copy.shid)
       ) AS sh_name,
       (
		   SELECT sh_company
		   FROM pos_shop 
		   WHERE  (sh_id =vi_pos_stockSumList_copy.shid)
       ) AS sh_company,
       vertical_column_id,
       vertical_column_name
FROM   vi_pos_stockSumList_copy
go

