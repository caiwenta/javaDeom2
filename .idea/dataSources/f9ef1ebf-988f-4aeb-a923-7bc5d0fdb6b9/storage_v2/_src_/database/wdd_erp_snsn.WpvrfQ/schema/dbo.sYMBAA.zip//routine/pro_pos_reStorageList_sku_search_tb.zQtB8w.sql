
CREATE PROC [dbo].[pro_pos_reStorageList_sku_search_tb]
@rel_re_id INT = 0,
@rel_add_time DATETIME = '2004-10-17',
@gi_id INT,
@sh_id INT,
@cp_id int
AS

BEGIN

	SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p
	FROM   b_goodsruleset AS bg
	       LEFT JOIN (
	               SELECT (ISNULL(rel_num,0)-ISNULL(phnum,0))un_phnum,*
	                FROM 
	                (
						SELECT ISNULL((SELECT SUM(all_num) FROM pos_allocation pa
	                				   INNER JOIN pos_allocationList pal ON pa.al_id=pal.all_al_id AND pa.al_status<>0 AND pal.all_status>0
	                				   AND pal.all_gi_id=rel_gi_id AND pal.all_sku_id=rel_sku_id AND pa.al_source_id=rel_re_id and al_source IN (2)
	                			),0) AS phnum,*
						FROM   pos_reStorageList AS jisl
						WHERE  jisl.rel_re_id = @rel_re_id
							   --AND jisl.rel_add_time = @rel_add_time
							   AND jisl.rel_status = 1
							   AND jisl.rel_gi_id = @gi_id
	                 )T
	            ) AS p1 
	            ON  bg.gi_id = p1.rel_gi_id
	            AND bg.gss_id = p1.rel_sku_id
	            LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
	WHERE  bg.gi_id = @gi_id;
	




	--DECLARE @ghj       DECIMAL(9, 2) = 0;
	--DECLARE @lsj       DECIMAL(9, 2) = 0;
	--DECLARE @ghj_type  INT = 0;
	--DECLARE @dpj_type  INT = 0;
	--declare @discount DECIMAL(9, 2) = 1;

	declare @type int=2;--交易方式订货
	declare @returntable table(
			gi_id int,
			sku_id int,
			retailprice DECIMAL(9, 2),--零售价
			discount DECIMAL(9, 2),
			importprices DECIMAL(9, 2)    --供货价
	);

	if @sh_id>0
	begin
		INSERT @returntable
		SELECT
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
		FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,0,@sh_id,0,@type);
	end

	if @cp_id>0
	begin
		INSERT @returntable
		SELECT
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
		FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,0,0,@cp_id,@type);
	end

	
    update #p set
		        gs_salesprice= l.importprices,
				gs_purchase = l.importprices,
				gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id


	--IF @dpj_type != 0
	--BEGIN
	--    SELECT @lsj = gd_price
	--    FROM   b_goods_discount
	--    WHERE  gd_type = @dpj_type
	--           AND gd_class = 1 AND gd_gi_id = @gi_id
	----零售价
	--UPDATE #p SET    gs_marketprice = @lsj
	--END

	--IF @dpj_type = 0 OR @lsj = 0 
	--BEGIN
	--    SELECT @lsj = bg.gi_importprices
	--    FROM   b_goodsinfo bg
	--    WHERE  bg.gi_id = @gi_id
	--END

	
	--SELECT @ghj = gd_price
	--FROM   b_goods_discount
	--WHERE  gd_gi_id = @gi_id
	--       AND gd_class = 2
	--       AND gd_type = @ghj_type
	
	--IF @ghj > 0.00
	--BEGIN
	--    --更细供货价
	--    UPDATE #p SET    gs_purchase = @ghj *@discount
	--END
	--ELSE
	--BEGIN
	--    UPDATE #p SET    gs_purchase = @lsj
	--END

	
	--吊牌价设置
	DECLARE @lsj       DECIMAL(9, 2) = 0;--零售价
	DECLARE @dpj_type  INT = 0;--吊牌价类型

	SELECT @dpj_type = ps.sh_goods_type
	FROM   pos_shop ps
	WHERE  ps.sh_id = @sh_id

	IF @dpj_type != 0
	BEGIN
	    SELECT @lsj = gd_price
	    FROM   b_goods_discount
	    WHERE  gd_type = @dpj_type
	           AND gd_class = 1 AND gd_gi_id = @gi_id
		--零售价
		UPDATE #p SET  gs_marketprice = @lsj
	END

	 UPDATE #p
	    SET    gs_discount = (
	               CASE 
	                    WHEN gs_marketprice = 0.00 THEN 0.00
	                    ELSE gs_purchase / gs_marketprice
	               END
	    )


	SELECT * FROM   #p
END
go

