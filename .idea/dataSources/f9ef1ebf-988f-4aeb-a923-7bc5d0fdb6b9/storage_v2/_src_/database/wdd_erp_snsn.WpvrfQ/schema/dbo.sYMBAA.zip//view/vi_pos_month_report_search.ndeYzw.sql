CREATE VIEW [dbo].[vi_pos_month_report_search]
	AS 
	
	
	SELECT gid,[sid],order_date,myremark,sei_erp_id AS erp_id ,shid,gi_name,gi_code,gi_unit_name AS ut_name,sei_name,
LEFT(CONVERT(CHAR(19), order_date, 120) 
,7) AS date,
 0 as retail_enmoneyhj, 0 as retail_ooth_moneyhj,0 as retail_end_money ,0 as end_money,
 
 (case when myremark='入库' then gnum else 0 end) +(case when myremark='入库退货' then gnum else 0 end) AS enhj ,
  (case when myremark='入库' then allmoney else 0 end) +(case when myremark='入库退货' then allmoney else 0 end) AS enmoneyhj ,
 isnull(-(case when myremark='销售前台' and  gnum <0  then gnum else 0 end)-(case when myremark='销售前台' and  gnum >0 then gnum else 0 end),0)  AS ooth_numhj,
isnull(-(case when  myremark='销售前台' and  gnum >0 then allmoney else 0 end)-(case when myremark='销售前台' and  gnum <0 then allmoney else 0 end),0) AS ooth_moneyhj,
 0 AS end_num,
    (case when myremark='期初' then gnum else 0 end) as start_num,
        (case when myremark='期初' then gnum else 0 end) * gi_costprice AS retail_start_money,
         (case when myremark='期初' then allmoney else 0 end) as start_money,   
 (case when myremark='入库' then gnum else 0 end) as en_num,
     (case when myremark='入库' then gnum else 0 end) * gi_costprice AS retail_en_money,
	  (case when myremark='入库' then allmoney else 0 end) as en_money,
		(case when myremark='入库退货' then gnum else 0 end) as enth_num,
			(case when myremark='入库退货' then gnum else 0 end)  * gi_costprice AS retail_enth_money,
		(case when myremark='入库退货' then allmoney else 0 end) as enth_money,
		(case when myremark='销售前台' and  gnum <0 then gnum else 0 end) as oo_num,
		(case when myremark='销售前台' and  gnum <0 then gnum else 0 end) * gi_costprice as retail_oo_money,
		(case when myremark='销售前台' and  gnum <0 then allmoney else 0 end) as oo_money,
	    (case when myremark='销售前台' and  gnum >0 then gnum else 0 end) as ooth_num,
	     (case when myremark='销售前台' and  gnum >0 then gnum else 0 end) * gi_costprice as retail_ooth_money,
		(case when myremark='销售前台' and  gnum >0 then allmoney else 0 end) as ooth_money,
		(case when myremark='整仓盘点盈亏调整' then gnum else 0 end) as ts_num,
				(case when myremark='整仓盘点盈亏调整' then gnum else 0 end)  * gi_costprice AS retail_ts_money,
	    (case when myremark='整仓盘点盈亏调整' then allmoney else 0 end) as ts_money,
		(case when myremark='移出仓库' then gnum else 0 end) as mo_num,
			(case when myremark='移出仓库' then gnum else 0 end)  * gi_costprice AS retail_mo_money,
		(case when myremark='移出仓库' then allmoney else 0 end) as mo_money,
		(case when myremark='移入仓库' then gnum else 0 end) as mi_num,
		(case when myremark='移入仓库' then gnum else 0 end) * gi_costprice AS retail_mi_money,
		(case when myremark='移入仓库' then allmoney else 0 end) as mi_money,
		(case when myremark='盈亏'then gnum else 0 end) as yk_num,
		(case when myremark='盈亏'then gnum else 0 end) * gi_costprice AS retail_yk_money,
		(case when myremark='盈亏'then allmoney else 0 end) as yk_money
		
	

 FROM vi_pos_stockList_createmonthly
go

