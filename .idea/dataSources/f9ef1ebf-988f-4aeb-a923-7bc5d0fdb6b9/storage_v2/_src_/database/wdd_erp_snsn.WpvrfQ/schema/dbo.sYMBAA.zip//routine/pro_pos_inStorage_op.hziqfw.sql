CREATE PROC [dbo].[pro_pos_inStorage_op]
       @inl_box_num INT = 0 ,
       @inl_pm VARCHAR(500) = '' ,
       @in_id INT = 0 , --主键  
       @in_sh_id INT = 0 ,  --店铺主键   
       @inl_erp_id INT = 0 ,
       @in_erp_id INT = 0 ,
       @in_no VARCHAR(50) = '' ,  --单据号
       @in_date DATETIME = '2014-10-24' ,  --入库日期 
       @in_st_id INT = 0 ,  --仓库主键
       @in_source INT = 0 ,  --来源(1,总部:2,店铺) 
       @in_supplier_sh_id INT = 0 ,  --供方店铺主键  
       @in_order_man INT = 0 ,  --制单人主键 
       @in_update_man INT = 0 ,  --修改人主键
       @in_update_time DATETIME = '2014-10-24' ,  --修改时间
       @in_add_man INT = 0 ,  --添加人主键
       @in_add_time DATETIME = '2014-10-24' ,  --添加时间  
       @in_audit_man INT = 0 ,  --审核人主键
       @in_audit_time DATETIME = '2014-10-24' ,  --审核时间 
       @in_type INT = 0 ,  --类型(0,入库:1,入库退货)  
       @in_remark VARCHAR(50) = '' ,  --备注
       @in_actual_num INT = 0 , --实到数量
       @in_source_id INT = 0 , --来源主键
       @inl_id INT = 0 ,  --主键
       @inl_in_id INT = 0 ,  --产品入库登记主键 
       @inl_gi_id INT = 0 ,  --商品主键
       @inl_sku_id INT = 0 ,  --商品sku主键 
       @inl_num INT = 0 ,  --数量
       @inl_retail_price DECIMAL(9,2) = 0 ,  --零售价
       @inl_discount DECIMAL(9,2) = 0 ,  --折率
       @inl_stock_price DECIMAL(9,2) = 0 ,  --进货价
       @inl_money DECIMAL(9,2) = 0 ,  --金额 
       @inl_sample_no VARCHAR(50) = '' ,  --样品号
       @inl_gift INT = 0 ,  --是否获赠 
       @inl_remark VARCHAR(50) = '' ,  --备注
       @inl_add_time DATETIME = '2014-10-24' ,  --添加时间 
       @inl_source_id INT = 0 , --来源明细主键
       @inl_source_add_time DATETIME = '2014-11-20' , --来源明细添加时间
       @op_type VARCHAR(100) = '添加修改单据,明细' ,  --操作类型
       @negative_inventory INT = 0 ,
       @result VARCHAR(100) = '' OUT , --结果 
       @savestr VARCHAR(MAX) = '' , --保存字符串
       @isInsert INT = 0 , --是否添加单据
       @orderguid VARCHAR(500) = '', --唯一guid,
	   @slt_id int=0 --仓位
AS
BEGIN
     
	  --防止仓位为负数
      IF @slt_id<0
	  BEGIN
	   SET @slt_id=0;
	  END

      DECLARE @inl_update_time DATETIME= GETDATE();    	
      DECLARE @sql NVARCHAR(MAX) = '';
      DECLARE @sei_is_negative INT= 0;		
      DECLARE @old_sei_id INT= 0;
      DECLARE @new_sei_id INT= 0;
      
      SET @new_sei_id = @in_st_id;

      DECLARE @need_update INT = 0; --是否需要更新单据
      DECLARE @old_order_date DATETIME; --旧的单据日期
      DECLARE @old_order_date_is_changed INT = 0; --单据日期是否更改
      DECLARE @myprevTxt VARCHAR(50) = 'RK'; --凭证号前缀
	  declare @in_io_id int=0;
	      
      IF @in_type = 1
         SET @myprevTxt = 'RKTH';
	
      BEGIN TRAN
      SELECT    @sei_is_negative = sei_is_negative_inventory
      FROM      pos_storageInfo WITH (NOLOCK)
      WHERE     sei_id = @in_st_id 
      
	  
	  IF @in_source =2
	     BEGIN
			  select @in_io_id=al_source_id from 
			  pos_alStorage where al_id=@in_source_id and al_cp_do=2
	     END 
		   
	  IF @in_source =1
	     BEGIN
			  select @in_io_id=oo_io_id from j_outStorage where oo_id=@in_source_id 
	     END   


      IF @op_type = '添加修改单据,明细'
         BEGIN

               IF @in_id = 0
                  BEGIN
						--添加单据
                        INSERT  INTO pos_inStorage
                                (in_sh_id ,
                                 in_vo ,
                                 in_no ,
                                 in_date ,
                                 in_st_id ,
                                 in_source ,
                                 in_supplier_sh_id ,
                                 in_order_man ,
                                 in_update_man ,
                                 in_update_time ,
                                 in_add_man ,
                                 in_add_time ,
                                 in_status ,
                                 in_type ,
                                 in_remark ,
                                 in_actual_num ,
                                 in_source_id ,
                                 in_erp_id,in_io_id)
                        VALUES  (@in_sh_id ,
                                 NEWID() ,
                                 @in_no ,
                                 @in_date ,
                                 @in_st_id ,
                                 @in_source ,
                                 @in_supplier_sh_id ,
                                 @in_order_man ,
                                 @in_update_man ,
                                 @in_update_time ,
                                 @in_add_man ,
                                 @in_add_time ,
                                 1 ,
                                 @in_type ,
                                 @in_remark ,
                                 @in_actual_num ,
                                 @in_source_id ,
                                 @in_erp_id,@in_io_id);
                        SET @in_id = SCOPE_IDENTITY();
	        
                        SET @inl_in_id = @in_id;
                        SET @isInsert = 1;
                  END
               ELSE
                  SET @need_update = 1;
	    
               IF EXISTS ( SELECT   1
                           FROM     pos_inStorageList AS jt
                           WHERE    jt.inl_in_id = @in_id
                                    AND jt.inl_status = 1
                                    AND jt.inl_add_time = @inl_add_time
                                    AND jt.inl_gi_id != @inl_gi_id )
                  BEGIN
                        UPDATE  pos_inStorageList
                        SET     inl_status = 0
                        WHERE   inl_in_id = @in_id
                                AND inl_add_time = @inl_add_time
                                AND inl_status = 1
                                AND inl_gi_id != @inl_gi_id
	                  
	               
                        SET @inl_id = 0;
                  END
	    
               DECLARE @savestr_item VARCHAR(MAX) = ''; --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
               DECLARE @start_int INT = 1; --起始数值,每次循环后递增
               DECLARE @end_int INT = 1; --终止数值

               IF @orderguid = ''
                  BEGIN
                        IF @savestr != ''
                           BEGIN
						--得到明细数量
						--即要循环的次数
                                 SELECT @end_int = (LEN(@savestr) - LEN(REPLACE(@savestr,'|','')))
                           END
                        ELSE
                           BEGIN
                                 IF @in_source > 0
                                    BEGIN
								 --@savestr为空,整单执行,使其不符合条件
                                          SET @start_int = @end_int + 1;
                                    END
                           END
                        WHILE @start_int <= @end_int
                              BEGIN
						   --动态赋值
                                    IF @savestr != ''
                                       BEGIN
                                             SET @savestr_item = dbo.Get_StrArrayStrOfIndex(@savestr,'|',@start_int);

                                             IF (RTRIM(LTRIM(@savestr_item)) = '')
                                                BEGIN
                                                      BREAK;
                                                END
                                             ELSE
                                                BEGIN
                                                      IF @in_source = 0
                                                         BEGIN
                                                               SET @inl_id = CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));
                                                               SET @inl_gi_id = CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));
                                                               SET @inl_sku_id = CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3));
                                                               SET @inl_num = CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));	                    
                                                               SET @inl_retail_price = CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5));
                                                               SET @inl_stock_price = CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',6));
                                                               SET @inl_discount = CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',7));

                                                               SET @inl_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item,',',8);
                                                         END
                                                      ELSE
                                                         IF @in_source > 0
                                                            BEGIN
                                                                  SET @inl_id = 0;
                                                                  SET @inl_source_id = CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));
                                                                  SET @inl_num = CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));
                                                                  SET @inl_source_add_time = dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3);
                                                     
                                                                  IF (dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4) = '')
                                                                     BEGIN
																  --补货
                                                                           IF @in_source = 1
                                                                              BEGIN
	                    												   --没规格
                                                                                    SELECT  @inl_gi_id = posl.ol_siid ,
                                                                                            @inl_sku_id = posl.ol_skuid ,
                                                                                            @inl_pm = posl.ol_pm ,
                                                                                            @inl_retail_price = posl.ol_unit ,
                                                                                            @inl_discount = posl.ol_discount ,
                                                                                            @inl_stock_price = posl.ol_costprice
                                                                                    FROM    j_outStorageList AS posl
                                                                                    WHERE   posl.ol_id = @inl_source_id 
                                                                              END
	                        
                                                                           IF @in_source = 2
                                                                              BEGIN
                                                                                    SELECT  @inl_gi_id = posl.all_gi_id ,
                                                                                            @inl_sku_id = posl.all_sku_id ,
                                                                                            @inl_pm = posl.all_pm ,
                                                                                            @inl_retail_price = posl.all_retail_price ,
                                                                                            @inl_discount = posl.all_discount ,
                                                                                            @inl_stock_price = posl.all_stock_price
                                                                                    FROM    pos_allocationList AS posl
                                                                                    WHERE   posl.all_id = @inl_source_id
                                                                              END
                                                                     END
                                                                  ELSE
                                                                     BEGIN
                                                                           SET @inl_num = CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));
                                                                           SET @inl_sku_id = CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5));
                                                                           SET @inl_retail_price = CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,
                                                                                                                                                ',',6));
                                                                           SET @inl_stock_price = CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,
                                                                                                                                                ',',7));
                                                                           SET @inl_discount = CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,
                                                                                                                                                ',',8));
                                                                           SET @inl_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item,',',9);
                                                                     END
                                                            END
                                                END
                                       END  

                                    IF @inl_id = 0
                                       BEGIN
                                             SET @inl_money = @inl_num * @inl_stock_price;

                                             INSERT INTO pos_inStorageList
                                                    (inl_in_id ,
                                                     inl_gi_id ,
                                                     inl_sku_id ,
                                                     inl_num ,
                                                     inl_retail_price ,
                                                     inl_discount ,
                                                     inl_stock_price ,
                                                     inl_money ,
                                                     inl_sample_no ,
                                                     inl_gift ,
                                                     inl_remark ,
                                                     inl_status ,
                                                     inl_add_time ,
                                                     inl_source_id ,
                                                     inl_source_add_time ,
                                                     inl_box_num ,
                                                     inl_pm ,
                                                     inl_erp_id)
                                             VALUES (@in_id ,
                                                     @inl_gi_id ,
                                                     @inl_sku_id ,
                                                     @inl_num ,
                                                     @inl_retail_price ,
                                                     @inl_discount ,
                                                     @inl_stock_price ,
                                                     @inl_money ,
                                                     @inl_sample_no ,
                                                     @inl_gift ,
                                                     @inl_remark ,
                                                     1 ,
                                                     @inl_add_time ,
                                                     @inl_source_id ,
                                                     @inl_source_add_time ,
                                                     @inl_box_num ,
                                                     @inl_pm ,
                                                     @inl_erp_id);
                                             SET @inl_id = SCOPE_IDENTITY();
                                       END
                                    ELSE
                                       BEGIN
                                             SET @inl_money = @inl_num * @inl_stock_price;

                                             UPDATE pos_inStorageList
                                             SET    inl_in_id = @inl_in_id ,
                                                    inl_gi_id = @inl_gi_id ,
                                                    inl_sku_id = @inl_sku_id ,
                                                    inl_num = @inl_num ,
                                                    inl_retail_price = @inl_retail_price ,
                                                    inl_discount = @inl_discount ,
                                                    inl_stock_price = @inl_stock_price ,
                                                    inl_money = @inl_money ,
                                                    inl_sample_no = @inl_sample_no ,
                                                    inl_gift = @inl_gift ,
                                                    inl_remark = @inl_remark ,
                                                    inl_box_num = @inl_box_num ,
                                                    inl_pm = @inl_pm ,
                                                    inl_erp_id = @inl_erp_id
                                             WHERE  inl_id = @inl_id;
                                       END
	        
                                    SET @start_int = @start_int + 1;
                              END
                        IF @in_source > 0
                           AND @isInsert = 1
                           BEGIN

                                 IF @in_source = 1 --公司出库
                                    BEGIN
                                          SET @sql = REPLACE(REPLACE('SELECT * INTO ##p FROM (
																SELECT 
																	   fd.ol_siid,
																	   fd.ol_skuid,
																	   (fd.ol_number -ISNULL(inl_num, 0)) AS ol_number,
																	   fd.ol_discount,
																	   fd.ol_unit,
																	   fd.ol_costprice,
																	   fd.ol_realmoney,
																	   fd.ol_status,
																	   fd.ol_id,
																	   fd.ol_addtime,
																	   fd.ol_box_num,
																	   fd.ol_pm,fd.ol_erp_id
																FROM j_outStorageList fd
																LEFT  JOIN (
																	SELECT inl_source_id,
																			SUM(inl_num)  AS inl_num
																	FROM   (
																			SELECT josl.inl_source_id,
																					josl.inl_gi_id,
																					CASE jos.in_type
																						WHEN 1 THEN -josl.inl_num
																						WHEN 0 THEN josl.inl_num
																					END AS inl_num,
																					josl.inl_source_add_time
																			FROM   pos_inStorage AS jos
																					INNER JOIN pos_inStorageList AS josl
																						ON  jos.in_id = josl.inl_in_id
																			WHERE  jos.in_source = 1
																					AND jos.in_source_id = @in_source_id
																					AND josl.inl_status = 1
																					AND jos.in_status > 0
																)	fd
																GROUP BY inl_source_id     
															)	ed ON  ed.inl_source_id = ol_id
															WHERE  ol_eoid = @in_source_id
																	AND ol_status = 1
																	AND fd.ol_addtime NOT IN (
																		SELECT DISTINCT fd.inl_source_add_time
																		FROM pos_inStorageList fd WHERE fd.inl_in_id = @in_id)
																	AND (ol_number -ISNULL(inl_num, 0)) > 0) AS fd','@in_source_id',
                                                                     CONVERT(VARCHAR(50),@in_source_id)),'@in_id',CONVERT(VARCHAR(50),@in_id));
                                          SET @in_supplier_sh_id = (SELECT  si_id
                                                                    FROM    pos_supplierinfo AS bs
                                                                    WHERE   bs.si_sh_id = @in_sh_id
                                                                            AND bs.si_companyid = (SELECT   oo_cp_id
                                                                                                   FROM     j_outStorage
                                                                                                   WHERE    oo_id = @in_source_id
                                                                                                  )
                                                                   );
                                    END
                 
                                 IF @in_source = 2 --调拨
                                    BEGIN
                                          SET @sql = REPLACE(REPLACE('SELECT * INTO ##p FROM (
																SELECT 
																	   fd.all_gi_id,
																	   fd.all_sku_id,
																	   (fd.all_num -ISNULL(inl_num, 0)) AS all_num,
																	   fd.all_discount,
																	   fd.all_retail_price,
																	   fd.all_stock_price,
																	   fd.all_money,
																	   fd.all_status,
																	   fd.all_id,
																	   fd.all_add_time,
																	   fd.all_box_num,
																	   fd.all_pm,fd.all_erp_id
																FROM pos_alStorageList fd
																LEFT  JOIN (
																	SELECT inl_source_id,
																			SUM(inl_num)  AS inl_num
																	FROM   (
																			SELECT josl.inl_source_id,
																					josl.inl_gi_id,
																					CASE jos.in_type
																						WHEN 1 THEN -josl.inl_num
																						WHEN 0 THEN josl.inl_num
																					END AS inl_num,
																					josl.inl_source_add_time
																			FROM   pos_inStorage AS jos
																					INNER JOIN pos_inStorageList AS josl
																						ON  jos.in_id = josl.inl_in_id
																			WHERE  jos.in_source = 2
																					AND jos.in_source_id = @in_source_id
																					AND josl.inl_status = 1
																					AND jos.in_status > 0
																			)   fd
																GROUP BY inl_source_id     
												            )	ed	ON  ed.inl_source_id = all_id
															WHERE  all_al_id = @in_source_id
																   AND all_status = 1
																   AND fd.all_add_time not in(
																		SELECT DISTINCT fd.inl_source_add_time
																		FROM pos_inStorageList fd WHERE fd.inl_in_id = @in_id)
																   AND (all_num -ISNULL(inl_num, 0)) > 0) AS fd','@in_source_id',
                                                                     CONVERT(VARCHAR(50),@in_source_id)),'@in_id',CONVERT(VARCHAR(50),@in_id));
                                    END
	        
                                 EXEC sp_executesql @sql;

                                 INSERT INTO pos_inStorageList
                                        (inl_in_id ,
                                         inl_gi_id ,
                                         inl_sku_id ,
                                         inl_num ,
                                         inl_discount ,
                                         inl_retail_price ,
                                         inl_stock_price ,
                                         inl_money ,
                                         inl_status ,
                                         inl_source_id ,
                                         inl_source_add_time ,
                                         inl_box_num ,
                                         inl_pm ,
                                         inl_erp_id)
                                        SELECT  @in_id AS inl_in_id ,
                                                *
                                        FROM    ##p
	        
                                 DROP TABLE ##p
	        
                                 UPDATE pos_inStorageList
                                 SET    inl_money = inl_retail_price * inl_num
                                 WHERE  inl_in_id = @in_id;
	        
                                 UPDATE pos_inStorage
                                 SET    in_status = 2 ,
                                        in_update_man = @in_add_man ,
                                        in_audit_time = GETDATE()
                                 WHERE  in_id = @in_id
                                        AND in_sh_id = @in_sh_id;

								EXEC pro_update_unique_time @id=@in_id, @type='pos入库'


                           END
                  END
               ELSE
                  BEGIN

				    MERGE INTO pos_inStorageList AS ta
						USING
						(
						       SELECT   @in_id as inl_in_id,
                                        gi_id ,
                                        sku_id ,
                                        pm ,
                                        gift ,
                                        erp_id ,
                                        number ,
                                        discount ,--折扣
                                        retailprice ,--销售价
                                        purchase ,--进货价
                                        number * purchase as [money],--进货金额
                                        orderstatus ,
                                        box_num 
                                FROM    erp_goodslisttemp
                                WHERE   orderguid = @orderguid 
						) AS so on  ta.inl_gi_id=so.gi_id AND ta.inl_sku_id=so.sku_id and  ta.inl_in_id=so.inl_in_id and ta.inl_status=1
						  WHEN MATCHED THEN  UPDATE
                           SET  
						   ta.inl_num += so.number,
						   ta.inl_money=((ta.inl_num+so.number)*so.purchase)
						    WHEN NOT MATCHED THEN
                              INSERT
                                (inl_in_id ,
                                 inl_gi_id ,
                                 inl_sku_id ,
                                 inl_pm ,
                                 inl_gift ,
                                 inl_erp_id ,
                                 inl_num ,
                                 inl_discount , --折扣
                                 inl_retail_price , --零售价
                                 inl_stock_price , --供货价
                                 inl_money ,--进货金额
                                 inl_status ,
                                 inl_box_num ,
                                 inl_add_time)
								 VALUES
							   (
                                   so.inl_in_id ,
                                   so.gi_id ,
                                   so.sku_id ,
                                   so.pm ,
                                   so.gift ,
                                   so.erp_id ,
                                   so.number ,
                                   so.discount ,--折扣
                                   so.retailprice ,--销售价
                                   so.purchase ,--进货价
                                   so.[money] ,--进货金额
                                   so.orderstatus ,
                                   so.box_num ,
                                       (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
							           SELECT GETDATE() as nows,
                                      (SELECT TOP 1 inl_add_time FROM pos_inStorageList WHERE inl_gi_id=so.gi_id AND inl_in_id=so.inl_in_id) AS addtime) AS TT)
									  );

					EXEC pro_update_unique_time @id=@in_id, @type='pos入库';

					exec pro_setGoodsPurchasePrice @oo_id=@in_id,@wt=3;

                 END   


         END
	
      IF @op_type = '审核单据'
         BEGIN
			   --审核单据
               SELECT   @in_st_id = in_st_id
               FROM     pos_inStorage WITH (NOLOCK)
               WHERE    in_id = @in_id; --得到仓库id

               SELECT   @in_type = in_type
               FROM     pos_inStorage
               WHERE    in_id = @in_id

               UPDATE   pos_inStorage
               SET      in_status = 2 ,
                        in_audit_man = @in_update_man ,
                        in_audit_time = GETDATE()
               WHERE    in_id = @in_id
                        AND in_sh_id = @in_sh_id;

              EXEC pro_update_unique_time @id=@in_id, @type='pos入库';
         END
	
      IF @op_type = '取消审核单据'
         BEGIN
			   --取消审核单据
               SELECT   @in_st_id = in_st_id
               FROM     pos_inStorage WITH (NOLOCK)
               WHERE    in_id = @in_id; --得到仓库id

               UPDATE   pos_inStorage
               SET      in_status = 1
               WHERE    in_id = @in_id;
	    
               UPDATE   pos_inStorage
               SET      in_is_audit = 0
               WHERE    in_id = @in_id
                        AND in_type = 1
                        AND in_sh_id = @in_sh_id;
         END
	
      IF @op_type = '删除单据'
         BEGIN	
               EXEC pro_recovery_pos_ppdate_order
                @in_id;
	
               SELECT   @old_sei_id = in_st_id ,
                        @in_st_id = in_st_id
               FROM     pos_inStorage
               WHERE    in_id = @in_id; --得到仓库id
			   --删除单据
               UPDATE   pos_inStorage
               SET      in_status = 0
               WHERE    in_id = @in_id;

               UPDATE   pos_funds
               SET      fu_status = 0
               WHERE    fu_source_type = 1
                        AND fu_source_id = @in_id;
         END
	
      IF @op_type = '删除入库审核单据'
         BEGIN
	    --删除单据
	    
			   --注意@in_id为in_source_id，防止@in_id不对
			  set @in_source_id= @in_id;

	          select @in_id=in_id from pos_inStorage WHERE  in_source_id = @in_source_id
                        AND in_source = @in_source AND in_sh_id = @in_sh_id;

			  SELECT   @new_sei_id = in_st_id
               FROM     pos_inStorage
               WHERE    in_source_id = @in_source_id
                        AND in_status > 0
                        AND in_source = @in_source
                        AND in_sh_id = @in_sh_id;

               UPDATE   pos_inStorage
               SET      in_status = 0
               WHERE    in_source_id = @in_source_id
                        AND in_status > 0
                        AND in_source = @in_source
                        AND in_sh_id = @in_sh_id;
	            

         END
	
      IF @op_type = '删除明细'
         BEGIN
	    --删除明细
               UPDATE   pos_inStorageList
               SET      inl_status = 0
               WHERE    inl_id = @inl_id;
         END
	
      IF @op_type = '批量删除明细'
         BEGIN
               EXEC pro_recovery_pos_ppdate
                @gi_id = @inl_gi_id ,
                @order_id = @in_id ,
                @type = 'pos'
	    	
               SELECT   @old_sei_id = fd.in_st_id
               FROM     pos_inStorage fd
               WHERE    fd.in_id = @in_id
                        AND in_sh_id = @in_sh_id;
		
               UPDATE   pos_inStorageList
               SET      inl_status = 0
               WHERE    inl_in_id = @inl_in_id
                        AND inl_add_time = @inl_add_time
                        AND inl_gi_id = @inl_gi_id;
               IF NOT EXISTS ( SELECT   1
                               FROM     pos_inStorageList AS jt
                               WHERE    jt.inl_in_id = @inl_in_id
                                        AND jt.inl_status = 1 )
                  BEGIN
                        UPDATE  pos_inStorage
                        SET     in_status = 0
                        WHERE   in_id = @inl_in_id;
                        UPDATE  pos_funds
                        SET     fu_status = 0
                        WHERE   fu_source_type = 1
                                AND fu_source_id = @in_id;
                  END
         END
	
      IF (@op_type = '添加修改单据,明细' OR @need_update = 1 OR @op_type = '修改单据') AND @isInsert != 1
         BEGIN
               IF ((SELECT  jt.in_status
                    FROM    pos_inStorage AS jt WITH (NOLOCK)
                    WHERE   jt.in_id = @in_id
                   ) != 2)
                  BEGIN
	    --得到旧的单据日期
                        SELECT  @old_order_date = jt.in_date
                        FROM    pos_inStorage AS jt WITH (NOLOCK)
                        WHERE   jt.in_id = @in_id;

                        IF @old_order_date != @in_date
                           BEGIN
                                 SET @old_order_date_is_changed = 1;
                           END
	    
                        SELECT  @old_sei_id = fd.in_st_id
                        FROM    pos_inStorage fd WITH (NOLOCK)
                        WHERE   fd.in_id = @in_id
                                AND in_sh_id = @in_sh_id;
	    
                        UPDATE  pos_inStorage
                        SET     in_sh_id = @in_sh_id ,
                                in_no = @in_no ,
                                in_date = @in_date ,
                                in_st_id = @in_st_id ,
                                in_source = @in_source ,
                                in_supplier_sh_id = @in_supplier_sh_id ,
                                in_order_man = @in_order_man ,
                                in_update_man = @in_update_man ,
                                in_update_time = @in_update_time ,
                                in_type = @in_type ,
                                in_remark = @in_remark ,
                                in_actual_num = @in_actual_num
                        WHERE   in_id = @in_id
                                AND in_sh_id = @in_sh_id;
	    
                        IF (SELECT  fd.in_status
                            FROM    pos_inStorage fd WITH (NOLOCK)
                            WHERE   fd.in_id = @in_id
                                    AND in_sh_id = @in_sh_id
                           ) = 0
                           BEGIN
                                 UPDATE pos_inStorage
                                 SET    in_status = 1
                                 WHERE  in_id = @in_id;
	        
                                 UPDATE pos_funds
                                 SET    fu_status = 1
                                 WHERE  fu_source_type = 1
                                        AND fu_source_id = @in_id;
                           END
                  END
         END
	
      IF @isInsert = 1
	   --OR @old_order_date_is_changed = 1
         BEGIN
	    --凭证号生成
	    --更新凭证号 
               DECLARE @tableName VARCHAR(50) = 'pos_inStorage'
               DECLARE @idField VARCHAR(50) = 'in_id'
               DECLARE @idValue INT = @in_id;
	    
               DECLARE @dateField VARCHAR(50) = 'in_date'
               DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50),@in_date,23)
	    
               DECLARE @noField VARCHAR(50) = 'in_vo'
               DECLARE @prevTxt VARCHAR(50) = @myprevTxt
               DECLARE @outno VARCHAR(100) = ''
	    
               DECLARE @while INT = 0;
               WHILE @while = 0
                     BEGIN
	        --得到凭证号
                           EXECUTE [pro_gen_orderNo]
                            @tableName ,
                            @idField ,
                            @idValue ,
                            @dateField ,
                            @dateValue ,
                            @noField ,
                            @prevTxt ,
                            @outno OUTPUT ,
                            @in_sh_id
	        
                           BEGIN TRY
	        	--更新
                                 UPDATE pos_inStorage
                                 SET    in_vo = @outno ,
                                        pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1) ,
                                        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2) ,
                                        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)
                                 WHERE  in_id = @in_id
                                        AND in_sh_id = @in_sh_id;
	        	
	        	--更新成功,赋值,结束循环
                                 SET @while = 1;
                           END TRY
                           BEGIN CATCH
                                 PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
                           END CATCH
                     END
               IF @isInsert != 1
                  BEGIN
	        --更新了凭证号
                        UPDATE  pos_funds
                        SET     fu_source_vo = @outno
                        WHERE   fu_source_type = 1
                                AND fu_source_id = @in_id;
                  END
         END
	--款项备注
      DECLARE @in_fu_remark VARCHAR(50) = '入库';
	--入库金额
      DECLARE @in_in_money DECIMAL(10,2) = 0;
	--退货金额
      DECLARE @in_out_money DECIMAL(10,2) = 0;
	--得到单据的合计金额
      SELECT    @inl_money = fd.[money]
      FROM      (SELECT fd.inl_in_id ,
                        SUM(fd.inl_num * fd.inl_stock_price) AS MONEY
                 FROM   pos_inStorageList AS fd WITH (NOLOCK)
                 WHERE  fd.inl_status = 1
                 GROUP BY fd.inl_in_id
                ) AS fd
      WHERE     fd.inl_in_id = @in_id;
	
      IF @in_type = 1
         BEGIN
               SET @in_fu_remark = '入库退货';
               SET @in_out_money = @inl_money;
         END
      ELSE
         BEGIN
               SET @in_in_money = @inl_money;
         END
	
	--凭证号
      DECLARE @in_fu_vo VARCHAR(50) = '';
      SELECT    @in_fu_vo = pis.in_vo
      FROM      pos_inStorage AS pis
      WHERE     pis.in_id = @in_id
                AND in_sh_id = @in_sh_id;
	
      IF @op_type = '添加修改单据,明细' OR @op_type = '批量删除明细'
         BEGIN
	    --生成账款
               EXEC pro_pos_funds_op
	         --@fu_id = null,
                @fu_sh_id = @in_sh_id ,
                @fu_date = @in_date ,
                @fu_ci_id = @in_supplier_sh_id ,
                @fu_type = 1 ,
                @fu_order_man = @in_order_man ,
                @fu_add_man = @in_add_man ,
                @fu_add_time = @in_add_time ,
                @fu_update_man = @in_update_man ,
                @fu_update_time = @in_update_time ,
				--@fu_audit_man = null,
				--@fu_audit_time = null,
                @fu_remark = @in_fu_remark ,
                @fu_source_type = 1 ,
                @fu_source_id = @in_id ,
                @fu_source_vo = @in_fu_vo ,
                @ful_id = 0 ,
                @ful_fu_id = 0 ,
                @ful_ensure_money = 0 ,
                @ful_handsel_money = 0 ,
                @ful_freight = 0 ,
                @ful_other_out_money = 0 ,
                @ful_other_in_money = 0 ,
                @ful_money = 0 ,
                @ful_vo = '' ,
                @ful_remark = '' ,
                @ful_in_money = @in_in_money ,
                @ful_out_money = @in_out_money ,
                @op_type = '添加修改单据,明细' ,
                @result = @result OUT
	    
               IF @result = '0'
                  BEGIN
						--账款操作失败
                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END
         END
	
      DECLARE @si_company INT= 0;
      DECLARE @nowal DATETIME = GETDATE();
      IF @op_type = '退货审核'
         BEGIN   
		 
               SELECT   @in_erp_id = in_erp_id ,
                        @si_company =(SELECT si_companyid FROM pos_supplierinfo bs WHERE bs.si_id = in_supplier_sh_id),
						@in_remark=in_remark,
                        @in_sh_id = in_sh_id
               FROM     pos_inStorage
               WHERE    in_id = @in_id;


               UPDATE   pos_inStorage
               SET      in_is_audit = 1 ,
                        in_main_audit_man = @in_add_man ,
                        in_main_audit_time = GETDATE()
               WHERE    in_id = @in_id
                        AND in_sh_id = @in_sh_id;


               IF @si_company > 0
                  BEGIN
						--生成商品明细临时表
                        EXEC pro_goodsstock_op @in_id , 'posenter' , @in_erp_id , @orderguid OUT, @slt_id
                        IF @@error <> 0
                           BEGIN
                                 IF @@TRANCOUNT > 0
                                    ROLLBACK TRANSACTION 
									SET @result = '0';
                                 RETURN 0;
                           END

                        IF @orderguid <> ''
                           BEGIN
                                 EXEC pro_outStorage_op
                                    @op_type = '添加修改单据,明细' ,
                                    @oo_erp_id = @in_erp_id ,
                                    @oo_cp_id = @si_company ,
									@oo_remark=@in_remark,
                                    @oo_jytype = 1 ,
                                    @oo_source_type = 3 , --来源(1:配货,2:分公司入库退货，3:pos入库退货)
                                    @oo_source_id = @in_id ,  --来源主键
                                    @oo_type = 0 ,--类型(0,出库退货:1,出库)
                                    @oo_ciid = 0 ,--客户id               
                                    @oo_sh_id = @in_sh_id ,   --店铺主键         
                                    @oo_to_cp_id = 0 ,--公司主键
                                    @oo_siid = @in_st_id ,--仓库id
                                    @oo_entrydate = @in_date ,
                                    @oo_gift = 0 ,
                                    @oo_addman = @in_add_man ,
                                    @orderguid = @orderguid
                                 IF @@error <> 0
                                    BEGIN
                                          IF @@TRANCOUNT > 0
                                             ROLLBACK TRANSACTION 
                                          SET @result = '0';
                                          RETURN 0;
                                    END
                           END
                  END;


         END

      IF @op_type = '取消退货审核'
         BEGIN
               UPDATE   pos_inStorage
               SET      in_is_audit = 0 ,
                        in_main_audit_man = 0 ,
                        in_main_audit_time = NULL
               WHERE    in_id = @in_id
                        AND in_sh_id = @in_sh_id;

               SELECT   @in_erp_id = in_erp_id ,
                        @si_company = (SELECT si_companyid FROM pos_supplierinfo bs WHERE bs.si_id = in_supplier_sh_id ),
                        @in_sh_id = @in_sh_id
               FROM     pos_inStorage
               WHERE    in_id = @in_id;


			   --获取出库信息
               DECLARE @oo_id INT= 0;
               SELECT   @oo_id = fd.oo_id
               FROM     j_outStorage fd WITH (NOLOCK)
               WHERE    fd.oo_source_id = @in_id
                        AND fd.oo_source_type = 3
                        AND oo_sh_id = @in_sh_id
                        AND fd.oo_status > 0

				--检查帐款状态
				IF EXISTS(SELECT * FROM c_fundorder cf WHERE cf.fo_order_id=@oo_id and cf.fo_status=2 and cf.fo_type=0)
				begin
					RAISERROR ('帐款已审核,禁止取消审核单据',16,1,N'number',5);
					GOTO theRollback;
				end

               IF @si_company > 0
                  AND @oo_id > 0
                  BEGIN

				        EXEC pro_outStorage_op
                            @op_type = '取消审核单据' ,
                            @oo_erp_id = @in_erp_id ,
                            @oo_cp_id = @si_company ,
                            @oo_source_type = 3 , --来源(1:配货,2:分公司入库退货，3:pos入库退货)
                            @oo_id = @oo_id
							IF @@ERROR <> 0
							BEGIN
								GOTO theRollback;
							END


                        EXEC pro_outStorage_op
                            @op_type = '删除单据' ,
                            @oo_erp_id = @in_erp_id ,
                            @oo_cp_id = @si_company ,
                            @oo_source_type = 3 , --来源(1:配货,2:分公司入库退货，3:pos入库退货)
                            @oo_id = @oo_id
							IF @@ERROR <> 0
							BEGIN
								GOTO theRollback;
							END
                  END
         END

	  
      IF @op_type = '入库审核'
         AND 1 = 2
         BEGIN
               DECLARE @fristflag INT = 0;
               BEGIN
                     DECLARE @pa_inl_id INT = 0;
                     DECLARE @pa_inl_gi_id INT = 0;
                     DECLARE @pa_inl_sku_id INT = 0;
                     DECLARE @pa_inl_num INT = 0;
                     DECLARE @pa_inl_retail_price DECIMAL(9,2) = 0;
                     DECLARE @pa_inl_inl_discount DECIMAL(9,2) = 0;
                     DECLARE @pa_inl_stock_pricee DECIMAL(9,2) = 0;
                     DECLARE @pa_inl_money DECIMAL(9,2) = 0;
                     DECLARE @pa_inl_remark VARCHAR(50) = '';
                     DECLARE @pa_inl_status INT = 1;
                     DECLARE @pa_inl_add_time DATETIME;
                     DECLARE @now DATETIME = GETDATE();
                     DECLARE @old_add_time DATETIME = '2001-01-01';
	    	
                     SELECT inl_id ,
                            inl_gi_id ,
                            inl_sku_id ,
                            inl_num ,
                            inl_retail_price ,
                            inl_discount ,
                            inl_stock_price ,
                            inl_money ,
                            inl_remark ,
                            inl_add_time
                     INTO   #temp
                     FROM   vi_pos_inStorageList_audit
                     WHERE  inl_in_id = @in_source_id
                            AND inl_type = @in_source
	    	
	    	--价格设置
                     IF EXISTS ( SELECT ps.sh_goods_type
                                 FROM   pos_shop AS ps
                                 WHERE  ps.sh_id = @in_sh_id
                                        AND sh_goods_type > 0 )
                        BEGIN
                              SELECT    *
                              INTO      #sh_goods_type
                              FROM      b_goods_discount AS fd
                              WHERE     fd.gd_class = 1
                                        AND fd.gd_type = (SELECT    ps.sh_goods_type
                                                          FROM      pos_shop AS ps
                                                          WHERE     ps.sh_id = @in_sh_id
                                                                    AND sh_goods_type > 0
                                                         )
                                        AND fd.gd_gi_id IN (SELECT DISTINCT
                                                                    inl_gi_id
                                                            FROM    #temp)
	    	    
	    	    
	    	    
                              UPDATE    #temp
                              SET       inl_retail_price = fd2.gd_price ,
                                        inl_discount = fd2.gd_discount
                              FROM      #temp AS fd ,
                                        #sh_goods_type AS fd2
                              WHERE     fd.inl_gi_id = fd2.gd_gi_id
	    	    
                              UPDATE    #temp
                              SET       inl_stock_price = inl_retail_price * inl_discount;
                              UPDATE    #temp
                              SET       inl_money = inl_num * inl_stock_price;
                        END
	    	
                     DECLARE delsopcor CURSOR
                     FOR
                     (SELECT    *
                      FROM      #temp
                     )
	    	
                     OPEN delsopcor
                     FETCH NEXT FROM delsopcor INTO @pa_inl_id,@pa_inl_gi_id,@pa_inl_sku_id,@pa_inl_num,@pa_inl_retail_price,@pa_inl_inl_discount,
                           @pa_inl_stock_pricee,@pa_inl_money,@pa_inl_remark,@pa_inl_add_time
                     WHILE @@FETCH_STATUS = 0
                           BEGIN
                                 IF (@old_add_time != @pa_inl_add_time)
                                    BEGIN
                                          SET @now = GETDATE();
                                          SET @old_add_time = @pa_inl_add_time;
                                    END
	    	    
                                 EXEC pro_pos_inStorage_op
                                    @in_id = @fristflag ,
                                    @in_update_man = @in_add_man ,
                                    @in_update_time = @now ,
                                    @in_type = @in_type ,
                                    @in_source = @in_source ,
                                    @in_source_id = @in_source_id ,
                                    @inl_gi_id = @pa_inl_gi_id ,
                                    @inl_sku_id = @pa_inl_sku_id ,
                                    @inl_num = @pa_inl_num ,
                                    @in_sh_id = @in_sh_id ,
                                    @inl_in_id = @fristflag ,
                                    @inl_retail_price = @pa_inl_retail_price ,
                                    @inl_discount = @pa_inl_inl_discount ,
                                    @inl_stock_price = @pa_inl_stock_pricee ,
                                    @inl_money = @pa_inl_money ,
                                    @inl_source_id = @pa_inl_id ,
                                    @inl_add_time = @now ,
                                    @in_date = @in_date ,
                                    @in_st_id = @in_st_id ,
                                    @in_order_man = @in_order_man ,
                                    @in_add_man = @in_add_man ,
                                    @in_add_time = @now ,
                                    @op_type = '添加修改单据,明细' ,
                                    @result = @result OUT 
	    	    
                                 IF @result = '0'
                                    BEGIN
	    	        --操作失败
                                          CLOSE delsopcor
                                          DEALLOCATE delsopcor

                                          IF @@TRANCOUNT > 0
                                             ROLLBACK TRAN;
                                          RETURN 1;
                                    END
                                 ELSE
                                    BEGIN
                                          IF @fristflag = '0'
                                             BEGIN
                                                   SET @fristflag = @result;
                                             END
                                    END
                                 FETCH NEXT FROM delsopcor INTO @pa_inl_id,@pa_inl_gi_id,@pa_inl_sku_id,@pa_inl_num,@pa_inl_retail_price,@pa_inl_inl_discount,
                                       @pa_inl_stock_pricee,@pa_inl_money,@pa_inl_remark,@pa_inl_add_time
                           END
                     CLOSE delsopcor
                     DEALLOCATE delsopcor
                     SET @result = 1;
                     UPDATE pos_inStorage
                     SET    in_status = 2 ,
                            in_audit_man = @in_add_man ,
                            in_audit_time = GETDATE()
                     WHERE  in_id = @fristflag;
	    	--完成事务
                     IF @@TRANCOUNT > 0
                        COMMIT TRANSACTION
                     RETURN 1;
               END
         END
	
      IF @op_type != '审核单据' AND @op_type != '取消审核单据'
         BEGIN
               IF ISNULL(@in_id,0) = 0
                  BEGIN
                        RAISERROR ( '库存更新错误,单据id为0', 16, 1, N'number', 5 );
                        SET @result = '0';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 0;
                  END

               --IF @op_type = '删除入库审核单据'
               --   BEGIN
                        --EXEC [dbo].[pro_pos_mergeStockLog]
                        --    @tsl_sh_id = @in_sh_id ,
                        --    @negative_inventory = @negative_inventory ,
                        --    @old_sei_id = @old_sei_id ,
                        --    @new_sei_id = @new_sei_id

			    
                  --END
               --ELSE
               --   BEGIN
                        EXEC [dbo].[pro_pos_mergeStockLog_pos_inStorage]
                            @tsl_sh_id = @in_sh_id ,
                            @negative_inventory = @negative_inventory ,
                            @old_sei_id = @old_sei_id ,
                            @new_sei_id = @new_sei_id ,
                            @id = @in_id 
                  --END


               IF @@ERROR <> 0
                  BEGIN
                        SET @result = '0';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 0;
                  END
               ELSE
                  BEGIN
		
                        IF ISNULL(@in_source,0) != 2
                           BEGIN
		
                                 UPDATE pos_inStorageList
                                 SET    inl_pddate = fd2.si_pddate
                                 FROM   pos_inStorageList fd ,
                                        (SELECT fd.inl_gi_id ,
                                                MAX(bs.si_pddate) AS si_pddate
                                         FROM   (SELECT DISTINCT
                                                        pisl.inl_gi_id
                                                 FROM   pos_inStorageList pisl WITH (NOLOCK)
                                                 WHERE  pisl.inl_in_id = @in_id
                                                ) AS fd
                                         INNER JOIN b_stockinfo bs WITH (NOLOCK) ON fd.inl_gi_id = bs.si_giid
                                         GROUP BY fd.inl_gi_id
                                        ) fd2
                                 WHERE  fd.inl_gi_id = fd2.inl_gi_id
                                        AND fd.inl_in_id = @in_id;


                                 EXEC pro_update_b_stockinfo_si_pddate
                                    @order_id = @in_id ,
                                    @order_type = 'pos入库'
				
                           END
                  END
         END
	
	
      UPDATE    pos_inStorageList
      SET       inl_source_add_time = NULL
      FROM      pos_inStorageList AS pinl ,
                (SELECT pinl.inl_id
                 FROM   pos_inStorage AS pin WITH (NOLOCK)
                 INNER JOIN pos_inStorageList AS pinl WITH (NOLOCK) ON pin.in_id = pinl.inl_in_id
                                                                   AND pin.in_source = 0
                                                                   AND pinl.inl_source_add_time IS NOT NULL
                 WHERE  pin.in_id = @in_id
                ) AS ypinl
      WHERE     pinl.inl_id = ypinl.inl_id
	
      UPDATE    pos_inStorageList
      SET       inl_source_add_time = ypinl.inl_source_add_time
      FROM      pos_inStorageList AS pinl ,
                (SELECT pinl.inl_in_id ,
                        pinl.inl_gi_id ,
                        pinl.inl_add_time ,
                        MAX(CASE WHEN pinl.inl_source_id > 0
                                      AND pinl.inl_source_add_time IS NOT NULL THEN pinl.inl_source_add_time
                                 ELSE NULL
                            END) AS inl_source_add_time
                 FROM   pos_inStorage AS pin WITH (NOLOCK)
                 INNER JOIN pos_inStorageList AS pinl WITH (NOLOCK) ON pin.in_id = pinl.inl_in_id
                                                                       AND pin.in_source > 0
                 WHERE  pin.in_id = @in_id
                 GROUP BY pinl.inl_in_id ,
                        pinl.inl_gi_id ,
                        pinl.inl_add_time
                ) AS ypinl
      WHERE     pinl.inl_in_id = ypinl.inl_in_id
                AND pinl.inl_gi_id = ypinl.inl_gi_id
                AND pinl.inl_add_time = ypinl.inl_add_time   
	
      exec pro_instructionstate @orderid=@in_id ,@type=4;

	  --更成本价
      IF @op_type = '添加修改单据,明细'
         BEGIN
               DECLARE @tdoc_xml VARCHAR(MAX)= '';

               SET @tdoc_xml = '{ "update":"' + CONVERT(VARCHAR(100),@inl_update_time,121) + '","cp_id":"0","sh_id":"' + CONVERT(VARCHAR(50),@in_sh_id)
                   + '", "orderid":"' + CONVERT(VARCHAR(50),@in_id) + '" }';

               EXEC pro_apiqueue_op
                @tdoc_method = 'updatecostprice' ,
                @tdoc_xml = @tdoc_xml ,
                @tdoc_erp_id = @in_erp_id ,
                @tdoc_cp_id = 0 ,
                @tdoc_state = 0;
         END

      IF @@ERROR <> 0
         BEGIN
               SET @result = '0';
			   theRollback:
               IF @@TRANCOUNT > 0
                  ROLLBACK TRAN;

               RETURN 1;
         END
      ELSE
         BEGIN
               IF @isInsert = 1
                  BEGIN
                        SET @result = CONVERT(VARCHAR(50),@in_id);
                  END
               ELSE
                  BEGIN
                        IF @op_type = '添加修改单据,明细'
                           AND @orderguid = ''
                           BEGIN
                                 SET @result = CONVERT(VARCHAR(50),@inl_id);
                           END
                        ELSE
                           BEGIN
                                 SET @result = '1';
                           END
                  END

               IF @@TRANCOUNT > 0
                  COMMIT TRAN;
         END
END
go

