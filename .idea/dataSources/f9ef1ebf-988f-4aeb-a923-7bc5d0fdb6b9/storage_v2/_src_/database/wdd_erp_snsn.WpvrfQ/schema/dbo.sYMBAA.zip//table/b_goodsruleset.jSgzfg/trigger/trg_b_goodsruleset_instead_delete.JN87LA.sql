CREATE TRIGGER [dbo].[trg_b_goodsruleset_instead_delete] ON [dbo].[b_goodsruleset]
    INSTEAD OF DELETE
AS
BEGIN
    DECLARE @gss_id INT= 0;
    
    DECLARE sopcor CURSOR
    FOR
    ( SELECT    gss_id
      FROM      DELETED
    )
    
    OPEN sopcor
    FETCH NEXT FROM sopcor INTO @gss_id
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT  INTO log_c
                    ( li_content
                    )
                    EXEC pro_check_delete @op_type = '商品规格', @id = @gss_id
                    
            DECLARE @content VARCHAR(50)= '';
            
            SELECT  @content = lc.li_content
            FROM    log_c lc
            WHERE   lc.li_id = SCOPE_IDENTITY()
            
            IF ( @content ) = '1'
                BEGIN
                    INSERT  INTO log_c
                            ( li_content, li_time )
                    VALUES  ( '删除商品规格', GETDATE() )
                    PRINT '删除商品规格'
					--可以删除
                    DELETE  FROM b_goodsruleset
                    WHERE   gss_id = @gss_id
                END
            ELSE
                BEGIN
                    INSERT  INTO log_c
                            ( li_content, li_time )
                    VALUES  ( '删除商品规格失败', GETDATE() )
                    
                    PRINT @content
                END

            FETCH NEXT FROM sopcor INTO @gss_id
        END
    CLOSE sopcor
    DEALLOCATE sopcor
END
go

