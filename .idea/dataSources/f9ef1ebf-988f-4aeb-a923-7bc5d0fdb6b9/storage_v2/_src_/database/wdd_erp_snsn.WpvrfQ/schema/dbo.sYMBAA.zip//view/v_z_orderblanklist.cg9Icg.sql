CREATE VIEW [dbo].[v_z_orderblanklist]
	AS 
SELECT 
       mol_mo_id,
       mol_gi_id,
	   mol_sku_id                      AS mol_sku_id,
	   MAX(mol_id)					   as mol_id,
       SUM(mol_num)                    AS mol_num,
       SUM(mol_stock_num)              AS mol_stock_num,
       CONVERT(DECIMAL(10, 2), AVG(mol_discount)) AS mol_discount,
       CONVERT(DECIMAL(10, 2), AVG(mol_retail_price)) AS mol_retail_price,
       CONVERT(DECIMAL(10, 2), AVG(mol_stock_price)) AS mol_stock_price,
       SUM(mol_money)                  AS mol_money,
       MAX(REPLACE(isnull(mol_pm,''), '*', ','))  AS mol_pm,
       MAX(mol_box_num)                AS mol_box_num,
	   MAX(mol_add_time)               as mol_add_time
FROM   dbo.j_orderblanklist AS jt
WHERE  (mol_status = 1)
GROUP BY
       mol_mo_id,
       mol_gi_id,
	   mol_sku_id
go

