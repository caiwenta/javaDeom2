

CREATE PROCEDURE [dbo].[pro_enterStorage_sku_search_tb]
	@el_eoid INT = 0,
	@el_addtime DATETIME = '2004-10-17',
	@gi_id INT,
	@ci_id int,
	@cp_id INT = 0,
	@input int=0, --为1时不使用负数，用于入库退库
	@el_pm  varchar(50)='' 
AS
	DECLARE @ghj       DECIMAL(9, 2) = 0;
	DECLARE @lsj       DECIMAL(9, 2) = 0;
	DECLARE @ghj_type  INT = 0;
	declare @discount DECIMAL(9, 2) = 1;
	DECLARE @dpj_type  INT = 0;
BEGIN
    
	if @input=0
	begin	
	--入库规格明细查询	
	SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p1
	FROM   b_goodsruleset  AS bg
	       LEFT JOIN (

SELECT 
max(el_id) AS el_id,el_eoid,el_siid,el_skuid,SUM(el_number) AS el_number,SUM(el_realmoney) AS el_realmoney,el_discount,
el_remark,el_unit,el_costprice,el_addtime,el_status,el_source_id,
el_source_add_time ,el_cp_id,el_di_id,el_box_num,el_pm,el_gift,SUM(el_integral) AS el_integral,SUM(el_totalintegral) AS el_totalintegral
FROM
(

SELECT 
el_id,el_eoid,el_siid,el_skuid,
(CASE WHEN eo_type=1 THEN  -el_number ELSE el_number END) AS el_number,
(CASE WHEN eo_type=1 THEN  -el_realmoney ELSE el_realmoney END) AS el_realmoney,
el_discount,
el_remark,el_unit,el_costprice,el_addtime,el_status,el_source_id ,
el_source_add_time ,el_cp_id,el_di_id,el_box_num,el_pm,el_gift,
(CASE WHEN eo_type=1 THEN  -el_integral ELSE el_integral END) AS el_integral,
(CASE WHEN eo_type=1 THEN  -el_totalintegral ELSE el_totalintegral END) AS el_totalintegral

FROM   j_enterStorageList AS jisl
INNER JOIN
j_enterStorage jes 
ON jes.eo_id=jisl.el_eoid AND jes.eo_status<>0
WHERE  jisl.el_eoid = @el_eoid
AND jisl.el_addtime = @el_addtime
AND jisl.el_status = 1
AND jisl.el_siid=@gi_id

) AS TT
GROUP BY el_eoid,el_siid,el_skuid,el_discount,
el_remark,el_unit,el_costprice,el_addtime,el_status,el_source_id,el_source_add_time ,el_cp_id,el_di_id,el_box_num,el_pm,el_gift


	            )          AS p1
	            ON  bg.gi_id = p1.el_siid
	            AND bg.gss_id = p1.el_skuid LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
	WHERE  bg.gi_id = @gi_id;
	
	
		--分公司时设置零售价为吊牌价
     IF @cp_id != 0
	BEGIN
	     

		if EXISTS(SELECT 1 FROM b_supplierinfo bs WHERE si_id=@ci_id and si_company>0)
		 begin

		SELECT @ghj_type = ps.cp_bhprice, @discount=cp_bhdiscount FROM companyinfo ps WHERE  ps.cp_id = @cp_id
		   
		SELECT @dpj_type=c.cp_goods_type FROM   companyinfo c WHERE  c.cp_id = @cp_id
			
			IF @dpj_type != 0
	       BEGIN
			
			   SELECT @lsj = gd_price FROM b_goods_discount WHERE  gd_gi_id = @gi_id AND gd_type = @dpj_type AND gd_class = 1
			  --零售价
			   UPDATE #p1 SET    gs_marketprice = @lsj
			END


			IF @dpj_type = 0 OR @lsj = 0 
			BEGIN
				SELECT @lsj = bg.gi_importprices FROM   b_goodsinfo bg WHERE  bg.gi_id = @gi_id
			END

		SELECT @ghj = gd_price FROM   b_goods_discount WHERE  gd_gi_id = @gi_id AND gd_class = 2 AND gd_type = @ghj_type


			IF @ghj > 0.00
				BEGIN
				UPDATE #p1 SET    gs_purchase = @ghj *@discount  --更细供货价
				END
			ELSE
				BEGIN
				 UPDATE #p1 SET    gs_purchase = @lsj
				END


	    UPDATE #p1 SET gs_discount = ( CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END )

		end


END





	SELECT * FROM #p1
	
	
	end
	else
	
	
	
	begin


	--入库规格明细查询	
	 select (TT.el_number-abs(isnull(var_num,0))) as optnum,TT.* INTO #p2 from (
	SELECT 
	bg.*,
	p1.*,
	bg2.gi_name,
	bg2.gi_code, 
	( SELECT SUM(var_num) FROM erp_inspectionofgoods WHERE orderid=el_eoid AND warehousingtype=1 and iog_status=1 and gi_id=el_siid AND sku_id=el_skuid ) as var_num
	
FROM   b_goodsruleset  AS bg
	       LEFT JOIN (


SELECT 
max(el_id) AS el_id,el_eoid,el_siid,el_skuid,SUM(el_number) AS el_number,SUM(el_realmoney) AS el_realmoney,el_discount,
el_remark,el_unit,el_costprice,el_addtime,el_status,el_source_id,
el_source_add_time ,el_cp_id,el_di_id,el_box_num,el_pm,el_gift,SUM(el_integral) AS el_integral,SUM(el_totalintegral) AS el_totalintegral
FROM
(

SELECT 
el_id,el_eoid,el_siid,el_skuid,
el_number,
el_realmoney,
el_discount,
el_remark,el_unit,el_costprice,el_addtime,el_status,el_source_id ,
el_source_add_time ,el_cp_id,el_di_id,el_box_num,el_pm,el_gift,
el_integral,
el_totalintegral
FROM   j_enterStorageList AS jisl
INNER JOIN
j_enterStorage jes 
ON jes.eo_id=jisl.el_eoid AND jes.eo_status<>0
WHERE  jisl.el_eoid = @el_eoid
AND jisl.el_addtime = @el_addtime
AND jisl.el_status = 1
AND jisl.el_siid=@gi_id   
And jisl.el_pm=@el_pm

) AS TTT
GROUP BY el_eoid,el_siid,el_skuid,el_discount,
el_remark,el_unit,el_costprice,el_addtime,el_status,el_source_id,el_source_add_time ,el_cp_id,el_di_id,el_box_num,el_pm,el_gift


) AS p1
ON  bg.gi_id = p1.el_siid
AND bg.gss_id = p1.el_skuid 
LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
	WHERE  bg.gi_id = @gi_id
	) as TT

	--分公司时设置零售价为吊牌价
		--分公司时设置零售价为吊牌价



    IF @cp_id != 0
	BEGIN

		if EXISTS(SELECT 1 FROM b_supplierinfo bs WHERE si_id=@ci_id and si_company>0)
		 begin


	    SELECT @ghj_type = ps.cp_bhprice, @discount=cp_bhdiscount FROM companyinfo ps WHERE  ps.cp_id = @cp_id
		   
		SELECT @dpj_type=c.cp_goods_type FROM   companyinfo c WHERE  c.cp_id = @cp_id
		
		IF @dpj_type != 0
	    BEGIN
			SELECT @lsj = gd_price FROM b_goods_discount WHERE  gd_gi_id = @gi_id AND gd_type = @dpj_type AND gd_class = 1
	    
			UPDATE #p2 SET    gs_marketprice = @lsj
		END

		IF @dpj_type = 0 OR @lsj = 0 
		BEGIN
	     SELECT @lsj = bg.gi_importprices FROM   b_goodsinfo bg WHERE  bg.gi_id = @gi_id
		END

		SELECT @ghj = gd_price FROM   b_goods_discount WHERE  gd_gi_id = @gi_id AND gd_class = 2 AND gd_type = @ghj_type

			IF @ghj > 0.00
				BEGIN
				UPDATE #p2 SET    gs_purchase = @ghj *@discount  --更细供货价
				END
			ELSE
				BEGIN
				 UPDATE #p2 SET    gs_purchase = @lsj
				END

	    UPDATE #p2 SET gs_discount = ( CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END )

       end


	END

	SELECT * FROM #p2
	end

	
END
go

