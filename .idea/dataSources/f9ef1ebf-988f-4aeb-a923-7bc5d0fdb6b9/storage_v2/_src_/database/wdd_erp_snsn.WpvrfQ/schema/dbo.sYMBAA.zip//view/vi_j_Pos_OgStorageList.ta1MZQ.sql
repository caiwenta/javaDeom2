CREATE VIEW [dbo].[vi_j_Pos_OgStorageList] AS 
SELECT
	ogl_og_id,
	ogl_gi_id,
	ogl_add_time,
	ogl_boxbynum,
	SUM (ol_num) AS ol_num,--发货数量
	SUM (jt.ogl_pause_num) AS ogl_pause_num,
	SUM (jt.ogl_pause_num_pll) AS ogl_pause_num_pll,
	SUM (ogl_num) AS ogl_num,
	MIN (ogl_id) AS ogl_id,
	MAX (ogl_sku_id) AS ogl_sku_id,
	SUM (ogl_money) AS ogl_money,
	SUM (ogl_retail_money) AS ogl_retail_money,
	CONVERT (
		DECIMAL (10, 2),
		AVG (ogl_retail_price)
	) AS ogl_retail_price,
	CONVERT (
		DECIMAL (10, 2),
		AVG (ogl_stock_price)
	) AS ogl_stock_price,
	CONVERT (
		DECIMAL (10, 2),
		AVG (ogl_discount)
	) AS ogl_discount,
    isnull(ogl_pm,'') AS ogl_pm,
	MAX (ogl_box_num) AS ogl_box_num
FROM
	(select *,ISNULL((SELECT SUM (ol_number) FROM j_outStorageList  WITH (NOLOCK)
WHERE ol_status=1 and   ol_topsource_id = ogl_id),0) AS ol_num--发货数量
	 from dbo.pos_ogStorageList WITH (NOLOCK) ) AS jt
WHERE
	(ogl_status = 1)
GROUP BY
	ogl_og_id,
	ogl_gi_id,
	ogl_add_time,
	ogl_boxbynum,
	isnull(ogl_pm,'')
go

