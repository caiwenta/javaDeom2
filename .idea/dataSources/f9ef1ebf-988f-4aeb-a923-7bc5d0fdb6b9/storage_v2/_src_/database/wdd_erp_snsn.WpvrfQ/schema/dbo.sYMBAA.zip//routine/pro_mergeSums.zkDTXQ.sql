CREATE PROCEDURE [dbo].[pro_mergeSums]
	@orderids UDTypeOrderId READONLY,
	@stockType int=0
AS
--批量汇总数据生成表
DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';

BEGIN TRY

--入库
IF @stockType=1
BEGIN

DELETE j_enterStorageListMergeColorSum WHERE el_eoid in (select Id from @orderids)

INSERT INTO j_enterStorageListMergeColorSum
(
	el_eoid,
	el_siid,
	el_color_id,
	el_pm,
	el_boxbynum,
	
	el_number,
	el_box_num,
	
	el_realmoney,
	el_discount,
	el_unit,
	el_costprice,
	
	el_status,
	el_gift,
	el_addtime,
	el_source_id,
	el_di_id,
	el_cp_id,
	el_erp_id
)
SELECT el_eoid,
	   el_siid,
	   el_color_id,
	   el_pm,
	   el_boxbynum,
		
	   el_number,
	   (CASE WHEN ISNULL(el_boxbynum,0)=0 THEN 0 ELSE CEILING(el_number/el_boxbynum) END)el_box_num,
	   
	   el_realmoney,
	   el_discount,
	   el_unit,
	   el_costprice,
	   
	   1,
	   el_gift,
	   isnull(el_addtime,getdate()),
	   el_source_id,
	   el_di_id,
	   eo_cp_id,
	   el_erp_id
FROM (
	SELECT el_eoid,
		   el_siid,
		   col el_color_id,
		   isnull(el_pm,'') as el_pm,
		   el_boxbynum,
			
		   ISNULL(SUM(el_number),0)el_number,
			
		   SUM(el_realmoney)el_realmoney,
		   MAX(el_discount)el_discount,
		   CONVERT(DECIMAL(10, 2), AVG(el_unit))el_unit,
		   CONVERT(DECIMAL(10, 2), AVG(el_costprice))el_costprice,
		   isnull(el_gift,0) as el_gift,
		   el_addtime as el_addtime,
		   source_id as el_source_id,
		   el_di_id,
		   eo_cp_id,
		   el_erp_id
	FROM v_z_enterStorage_detail
	WHERE el_eoid in (select Id from @orderids)
	GROUP BY el_eoid,
	         el_siid,
	         col,
			 source_id,
	         isnull(el_pm,''),
	         el_boxbynum,
	         isnull(el_gift,0),
	         el_di_id,
		     eo_cp_id,
		     el_erp_id,
			 el_addtime
	)ogl

DELETE j_enterStorageListMergeSum WHERE el_eoid in (select Id from @orderids)

INSERT INTO j_enterStorageListMergeSum
(
	el_eoid,
	el_siid,
	el_pm,
	el_boxbynum,
	
	el_number,
	el_box_num,
	
	el_realmoney,
	el_discount,
	el_unit,
	el_costprice,
	
	el_status,
	el_gift,
	el_addtime,
	el_source_id,
	el_di_id,
	el_cp_id,
	el_erp_id
)
SELECT el_eoid,
	   el_siid,
	   el_pm,
	   el_boxbynum,
		
	   SUM(el_number)el_number,
	   SUM(el_box_num)el_box_num,
		
	   SUM(el_realmoney)el_realmoney,
	   MAX(el_discount)el_discount,
	   CONVERT(DECIMAL(10, 2), AVG(el_unit))el_unit,
	   CONVERT(DECIMAL(10, 2), AVG(el_costprice))el_costprice,
	   
	   1,
	   el_gift,
	   el_addtime el_addtime,
	   MAX(el_source_id)el_source_id,
	   el_di_id,
	   el_cp_id,
	   el_erp_id
FROM j_enterStorageListMergeColorSum
WHERE el_eoid in (select Id from @orderids)
GROUP BY el_eoid,
         el_siid,
         el_pm,
         el_boxbynum,
         el_gift,
         el_di_id,
         el_cp_id,
         el_erp_id,
		 el_addtime


DELETE j_enterStorageListMergeRuleSum where el_eoid in (select Id from @orderids)
INSERT INTO j_enterStorageListMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
el_eoid
)
SELECT 
	ems.elmcs_id,
	num,
	col AS colorid,
	SIZE AS gd_id,
	vi.el_eoid AS el_eoid
FROM (
	SELECT 
	el_siid,
	vi.el_eoid,
	isnull(vi.el_pm,'') AS el_pm,
	col,
	size,
	el_addtime,
	sum(el_number) AS num
	FROM v_z_enterStorage_detail AS vi
	WHERE vi.el_eoid in (select Id from @orderids)
	GROUP BY vi.el_siid,vi.el_eoid,isnull(vi.el_pm,''),col,SIZE,el_addtime
) AS vi
INNER JOIN j_enterStorageListMergeColorSum 
AS ems on ems.el_eoid=vi.el_eoid AND  ems.el_siid=vi.el_siid and ems.el_color_id=vi.col 
and vi.el_addtime=ems.el_addtime
AND isnull(vi.el_pm,'')=isnull(ems.el_pm,'')
WHERE ems.el_eoid in (select Id from @orderids) and vi.num<>0


END

--出库
IF @stockType=2
BEGIN
print N'开始生成出库';

DELETE j_outStorageListMergeColorSum WHERE ol_eoid in (select Id from @orderids)
INSERT INTO j_outStorageListMergeColorSum
(
	ol_eoid,
	ol_siid,
	ol_number,
	ol_box_num,
	ol_boxbynum,
	ol_realmoney,
	ol_discount,
	ol_unit,
	ol_costprice,
	ol_addtime,
	ol_gift,
	ol_source_id,
	ol_status,
	ol_cp_id,
	ol_erp_id,
	ol_pm,
	ol_color_id,
	supplyprice,
	discount,
	ol_buyingteamid
)
SELECT 
	oo_id,
	ol_siid,
	ol_number,
	(CASE WHEN ISNULL(ol_boxbynum,0)=0 THEN 0 ELSE CEILING(ol_number/ol_boxbynum) END)ol_box_num,
	ol_boxbynum,
	ol_realmoney,
	ol_discount,
	ol_unit,
	ol_costprice,
	isnull(ol_addtime,getdate()),
	ol_gift,
	ol_source_id,
	1 as ol_status,
	oo_cp_id,
	oo_erp_id,
	ol_pm,
	colorid,
	supplyprice,
	discount,
	ol_buyingteamid
from (
	SELECT oo_id,
		ol_siid,
		colorid,
		isnull(ol_pm,'') as ol_pm,
		ol_boxbynum,
		ISNULL(SUM(ol_number),0)ol_number,
		SUM(ol_realmoney)ol_realmoney,
		MAX(ol_discount)ol_discount,
		CONVERT(DECIMAL(10, 2), AVG(ol_unit))ol_unit,
		CONVERT(DECIMAL(10, 2), AVG(ol_costprice))ol_costprice,
		isnull(ol_gift,0) as ol_gift,
		ol_addtime,
		max(supplyprice) as supplyprice,
		max(discount) as discount,
		max(ol_buyingteamid) as ol_buyingteamid,
		source_id as ol_source_id,
		oo_cp_id,
		oo_erp_id
	FROM v_z_outStorage_detail
	WHERE  ol_number<>0 and oo_id in (select Id from @orderids)
	GROUP BY oo_id,
		ol_siid,
		colorid,
		isnull(ol_pm,''),
		ol_boxbynum,
		isnull(ol_gift,0),
		oo_cp_id,
		oo_erp_id,
		source_id,
		ol_addtime
) as bt

DELETE j_outStorageListMergeSum WHERE ol_eoid in (select Id from @orderids)
INSERT INTO j_outStorageListMergeSum
(
	ol_eoid,
	ol_siid,
	ol_number,
	ol_box_num,
	ol_boxbynum,
	ol_realmoney,
	ol_discount,
	ol_unit,
	ol_costprice,
	ol_addtime,
	ol_gift,
	ol_source_id,
	ol_status,
	ol_cp_id,
	ol_erp_id,
	ol_pm,
	supplyprice,
	discount,
	ol_buyingteamid
)
select 
	ol_eoid,
	ol_siid,
	ol_number,
	(CASE WHEN ISNULL(ol_boxbynum,0)=0 THEN 0 ELSE CEILING(ol_number/ol_boxbynum) END) ol_box_num,
	ol_boxbynum,
	ol_realmoney,
	ol_discount,
	ol_unit,
	ol_costprice,
	ol_addtime,
	ol_gift,
	ol_source_id,
	1,
	ol_cp_id,
	ol_erp_id,
	ol_pm,
	supplyprice,
	discount,
	ol_buyingteamid
from (
	select 
		ol_eoid,
		ol_siid,
		sum(ol_number) as ol_number,
		ol_boxbynum,
		SUM(ol_realmoney) as ol_realmoney,
		max(ol_discount) as ol_discount,
		avg(ol_unit) as ol_unit,
		avg(ol_costprice) as ol_costprice,
		ol_addtime,
		ol_gift,
		ol_source_id,
		ol_cp_id,
		ol_erp_id,
		ol_pm,
		avg(supplyprice) as supplyprice,
		avg(discount) as discount,
		max(ol_buyingteamid) as ol_buyingteamid
	from 
		j_outStorageListMergeColorSum
		WHERE ol_eoid in (select Id from @orderids)
	group by ol_eoid,
			 ol_siid,
			 ol_boxbynum,
			 ol_gift,
			 ol_source_id,
			 ol_pm,
			 ol_cp_id,
			 ol_erp_id,
			 ol_addtime
) bt

DELETE z_outStorage_detail where oo_id in (select Id from @orderids)
INSERT INTO dbo.z_outStorage_detail
           (specname
           ,spec2
           ,specno
           ,gd_row_number
           ,gss_no
           ,color
           ,spec
           ,colorid
           ,color_id
           ,size
           ,specid
           ,gs_sampleno
           ,ol_id
           ,oo_id
           ,oo_cp_id
           ,oo_cp_code
           ,oo_cp_name
           ,erp_id
           ,oo_no
           ,ol_gift
           ,gift
           ,oo_manual
           ,oo_entrydate
           ,oo_status
           ,oostatus
           ,sei_name
           ,sei_id
           ,gi_id
           ,ol_siid
           ,ol_pm
           ,gi_attribute_parentids
           ,gi_attribute_ids
           ,gi_typesid
           ,gi_types
           ,gi_type1
           ,gi_type2
           ,gi_type3
           ,gi_type4
           ,gi_skuid
           ,gi_brands
           ,gi_brandsid
           ,gi_sampleno
           ,gi_code
           ,gi_name
           ,gi_barcode
           ,gi_purchase
           ,gi_purchase_money
           ,gi_buyingteam
           ,gi_supplier
           ,si_royaltytype
           ,num
           ,oo_object
           ,oo_ciid
           ,ci_name
           ,ci_code
           ,ci_type
           ,oo_sh_id
           ,sh_name
           ,oo_sh_id_txt
           ,sh_no
           ,sh_type
           ,pstype
           ,sh_clientname
           ,sh_attribute_ids
           ,sh_attribute_parentids
           ,oo_to_cp_id
           ,cp_name
           ,cp_code
           ,oo_to_cp_id_txt
           ,ut_name
           ,ol_number
           ,gi_costprice
           ,gi_costprice_money
           ,ol_unit
           ,ol_discount
           ,ol_costprice
           ,ol_realmoney
           ,ol_unit_money
           ,ol_boxbynum
           ,ol_box_num
           ,oo_realmoney
           ,oo_num
           ,oo_returnrealmoney
           ,oo_returnnum
           ,realmoney
           ,oo_source_type
           ,ol_skuid
           ,al_vo
           ,source_id
           ,gi_unit
           ,ol_addtime
           ,takeman
           ,oo_jytype
           ,oojytype
           ,oo_freight
           ,oo_cost
           ,ootype
           ,oo_type
           ,oo_month
           ,oo_addman_txt
           ,oo_addtime
           ,oo_updatemam_txt
           ,oo_updatetime
           ,oo_lastman
           ,oo_auditdate
           ,oo_remark
           ,oi_no
           ,oo_erp_id
           ,supplyprice
           ,discount
           ,ol_buyingteamid
           ,realitydiscount
           ,oo_io_logistics
           ,oo_logistics_no
           ,instru_vo
           ,sh_ci_name
           ,sh_ci_code
           ,rulecode
           ,sizecode
           ,colorcode)
 SELECT specname
      ,spec2
      ,specno
      ,gd_row_number
      ,gss_no
      ,color
      ,spec
      ,colorid
      ,color_id
      ,size
      ,specid
      ,gs_sampleno
      ,ol_id
      ,oo_id
      ,oo_cp_id
      ,oo_cp_code
      ,oo_cp_name
      ,erp_id
      ,oo_no
      ,ol_gift
      ,gift
      ,oo_manual
      ,oo_entrydate
      ,oo_status
      ,oostatus
      ,sei_name
      ,sei_id
      ,gi_id
      ,ol_siid
      ,ol_pm
      ,gi_attribute_parentids
      ,gi_attribute_ids
      ,gi_typesid
      ,gi_types
      ,gi_type1
      ,gi_type2
      ,gi_type3
      ,gi_type4
      ,gi_skuid
      ,gi_brands
      ,gi_brandsid
      ,gi_sampleno
      ,gi_code
      ,gi_name
      ,gi_barcode
      ,gi_purchase
      ,gi_purchase_money
      ,gi_buyingteam
      ,gi_supplier
      ,si_royaltytype
      ,num
      ,oo_object
      ,oo_ciid
      ,ci_name
      ,ci_code
      ,ci_type
      ,oo_sh_id
      ,sh_name
      ,oo_sh_id_txt
      ,sh_no
      ,sh_type
      ,pstype
      ,sh_clientname
      ,sh_attribute_ids
      ,sh_attribute_parentids
      ,oo_to_cp_id
      ,cp_name
      ,cp_code
      ,oo_to_cp_id_txt
      ,ut_name
      ,ol_number
      ,gi_costprice
      ,gi_costprice_money
      ,ol_unit
      ,ol_discount
      ,ol_costprice
      ,ol_realmoney
      ,ol_unit_money
      ,ol_boxbynum
      ,ol_box_num
      ,oo_realmoney
      ,oo_num
      ,oo_returnrealmoney
      ,oo_returnnum
      ,realmoney
      ,oo_source_type
      ,ol_skuid
      ,al_vo
      ,source_id
      ,gi_unit
      ,ol_addtime
      ,takeman
      ,oo_jytype
      ,oojytype
      ,oo_freight
      ,oo_cost
      ,ootype
      ,oo_type
      ,oo_month
      ,oo_addman_txt
      ,oo_addtime
      ,oo_updatemam_txt
      ,oo_updatetime
      ,oo_lastman
      ,oo_auditdate
      ,oo_remark
      ,oi_no
      ,oo_erp_id
      ,supplyprice
      ,discount
      ,ol_buyingteamid
      ,realitydiscount
      ,oo_io_logistics
      ,oo_logistics_no
      ,instru_vo
      ,sh_ci_name
      ,sh_ci_code
      ,rulecode
      ,sizecode
      ,colorcode
  FROM dbo.v_z_outStorage_detail
  where oo_id in (select Id from @orderids)




END

--期初
IF @stockType=3
BEGIN
print N'开始生成期初';
DELETE j_initStorageListMergeColorSum WHERE inl_in_id in (select Id from @orderids)
INSERT INTO j_initStorageListMergeColorSum
           (inl_in_id
           ,inl_gi_id
           ,inl_num
           ,inl_retail_price
           ,inl_stock_price
           ,inl_money
           ,inl_status
           ,inl_add_time
           ,inl_discount
           ,inl_cp_id
           ,inl_box_num
           ,inl_pm
           ,inl_erp_id
           ,inl_boxbynum
           ,inl_color_id)
SELECT 
	in_id,
	inl_gi_id,
	inl_num,
	inl_retail_price,
	inl_stock_price,
	inl_money,
	1,
	inl_add_time,
	inl_discount,
	in_cp_id,
	(CASE WHEN ISNULL(inl_boxbynum,0)=0 THEN 0 ELSE CEILING(inl_num/inl_boxbynum) END)inl_box_num,
	inl_pm,
	in_erp_id,
	inl_boxbynum,
	colorid
FROM (
	SELECT 
	 in_id
	,inl_gi_id
	,sum(inl_num) AS inl_num
	,MAX(inl_retail_price) AS inl_retail_price
	,MAX(inl_stock_price) AS inl_stock_price
	,SUM(inl_money) AS inl_money
	,inl_add_time
	,MAX(inl_discount) AS inl_discount
	,in_cp_id
	,isnull(inl_pm,'') AS inl_pm
	,in_erp_id
	,inl_boxbynum
	,colorid
	FROM v_z_initStorage_detail
	WHERE in_id in (select Id from @orderids)
	GROUP BY in_id
	,inl_gi_id
	,in_cp_id
	,isnull(inl_pm,'')
	,in_erp_id
	,inl_boxbynum
	,colorid
    ,inl_add_time
) AS bt

DELETE j_initStorageListMergeSum WHERE inl_in_id in (select Id from @orderids)
INSERT INTO j_initStorageListMergeSum
           (inl_in_id
           ,inl_gi_id
           ,inl_num
           ,inl_retail_price
           ,inl_stock_price
           ,inl_money
           ,inl_status
           ,inl_add_time
           ,inl_discount
           ,inl_cp_id
           ,inl_box_num
           ,inl_pm
           ,inl_erp_id
           ,inl_boxbynum)
select 
	inl_in_id,
	inl_gi_id,
	inl_num,
	inl_retail_price,
	inl_stock_price,
	inl_money,
	1,
	inl_add_time,
	inl_discount,
	inl_cp_id,
	(CASE WHEN ISNULL(inl_boxbynum,0)=0 THEN 0 ELSE CEILING(inl_num/inl_boxbynum) END) inl_box_num,
	inl_pm,
	inl_erp_id,
	inl_boxbynum
from (
	select 
		inl_in_id,
		inl_gi_id,
		sum(inl_num) as inl_num,
		inl_boxbynum,
		SUM(inl_money) as inl_money,
		max(inl_discount) as inl_discount,
		avg(inl_retail_price) as inl_retail_price,
		avg(inl_stock_price) as inl_stock_price,
		inl_add_time as inl_add_time,
		inl_cp_id,
		inl_erp_id,
		inl_pm
	from 
		j_initStorageListMergeColorSum
	WHERE inl_in_id in (select Id from @orderids)
	group by inl_in_id,
			 inl_gi_id,
			 inl_boxbynum,
			 inl_cp_id,
			 inl_erp_id,
			 inl_pm,
			 inl_add_time
)as bt

DELETE j_initStorageListMergeRuleSum where inl_in_id in (select Id from @orderids)
INSERT INTO j_initStorageListMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
inl_in_id
)
SELECT 
	ems.inlmcs_id,
	num,
	colorid,
	SIZE,
	vi.in_id
FROM (
	SELECT 
	inl_gi_id,
	vi.in_id,
	isnull(vi.inl_pm,'') AS inl_pm,
	colorid,
	size,
	sum(num) AS num,
	inl_add_time
	FROM v_z_initStorage_detail AS vi
	WHERE vi.in_id  in (select Id from @orderids)
	GROUP BY inl_gi_id,vi.in_id,isnull(vi.inl_pm,''),colorid,SIZE,inl_add_time
) AS vi
INNER JOIN j_initStorageListMergeColorSum AS ems on 
ems.inl_in_id=vi.in_id AND ems.inl_gi_id=vi.inl_gi_id and ems.inl_color_id=vi.colorid 
AND isnull(vi.inl_pm,'')=ems.inl_pm
and vi.inl_add_time=ems.inl_add_time
WHERE vi.num<>0 AND ems.inl_in_id  in (select Id from @orderids)

END

--移仓
IF @stockType=4
BEGIN
print N'开始生成移仓';
DELETE j_moStorageListMergeColorSum WHERE mol_mo_id in (select Id from @orderids)
--移出
INSERT INTO j_moStorageListMergeColorSum
           (mol_mo_id
           ,mol_gi_id
           ,mol_stock_num
           ,mol_num
           ,mol_status
           ,mol_add_time
           ,mol_retail_price
           ,mol_discount
           ,mol_stock_price
           ,mol_money
           ,mol_cp_id
           ,mol_box_num
           ,mol_pm
           ,mol_erp_id
           ,mol_source_id
           ,mol_boxbynum
           ,mol_color_id
		   ,mol_type
		   )
SELECT 
	mo_id,
	mol_gi_id,
	0,
	-abs(mol_num),
	1,
	isnull(mol_add_time,getdate()),
	mol_retail_price,
	mol_discount,
	mol_stock_price,
	-abs(mol_money) as mol_money,
	mo_cp_id,
    -abs((CASE WHEN ISNULL(mol_boxbynum,0)=0 THEN 0 ELSE CEILING(mol_num/mol_boxbynum) END)) mol_box_num,
	mol_pm,
	erp_id,
    mo_source_id,
	mol_boxbynum,
	colorid,
	0 as mol_type
from (
	SELECT mo_id,
		mol_gi_id,
		colorid,
		isnull(mol_pm,'') as mol_pm,
		mol_boxbynum,
		ISNULL(SUM(mol_num),0)mol_num,
		SUM(mol_money)mol_money,
		MAX(mol_discount)mol_discount,
		CONVERT(DECIMAL(10, 2), AVG(mol_retail_price))mol_retail_price,
		CONVERT(DECIMAL(10, 2), AVG(mol_stock_price))mol_stock_price,
		mol_add_time,
		isnull(mo_source_id,0) as mo_source_id,
		mo_cp_id,
		erp_id
	FROM v_z_moStorage_detail 
	where mo_out_st_id > 0 and mo_id in (select Id from @orderids)
	GROUP BY mo_id,
		mol_gi_id,
		colorid,
		isnull(mol_pm,''),
		mol_boxbynum,
		mo_cp_id,
		erp_id,
		isnull(mo_source_id,0),
		mol_add_time
) as bt
WHERE bt.mol_num<>0 

--移入
INSERT INTO j_moStorageListMergeColorSum
           (mol_mo_id
           ,mol_gi_id
           ,mol_stock_num
           ,mol_num
           ,mol_status
           ,mol_add_time
           ,mol_retail_price
           ,mol_discount
           ,mol_stock_price
           ,mol_money
           ,mol_cp_id
           ,mol_box_num
           ,mol_pm
           ,mol_erp_id
           ,mol_source_id
           ,mol_boxbynum
           ,mol_color_id
		   ,mol_type
		   )
SELECT 
	mo_id,
	mol_gi_id,
	0,
	abs(mol_num),
	1,
	isnull(mol_add_time,getdate()),
	mol_retail_price,
	mol_discount,
	mol_stock_price,
	mol_money,
	mo_cp_id,
   (CASE WHEN ISNULL(mol_boxbynum,0)=0 THEN 0 ELSE CEILING(mol_num/mol_boxbynum) END)mol_box_num,
	mol_pm,
	erp_id,
    mo_source_id,
	mol_boxbynum,
	colorid,
	1 as mol_type
from (
	SELECT mo_id,
		mol_gi_id,
		colorid,
		isnull(mol_pm,'') as mol_pm,
		mol_boxbynum,
		ISNULL(SUM(mol_num),0)mol_num,
		SUM(mol_money)mol_money,
		MAX(mol_discount)mol_discount,
		CONVERT(DECIMAL(10, 2), AVG(mol_retail_price))mol_retail_price,
		CONVERT(DECIMAL(10, 2), AVG(mol_stock_price))mol_stock_price,
		mol_add_time,
		isnull(mo_source_id,0) as mo_source_id,
		mo_cp_id,
		erp_id
	FROM v_z_moStorage_detail 
	where mo_in_st_id > 0 AND mo_source_type=0 and mo_id in (select Id from @orderids)
	GROUP BY mo_id,
		mol_gi_id,
		colorid,
		isnull(mol_pm,''),
		mol_boxbynum,
		mo_cp_id,
		erp_id,
		isnull(mo_source_id,0),
		mol_add_time
) as bt
WHERE bt.mol_num<>0 

--新移入
INSERT INTO j_moStorageListMergeColorSum
           (mol_mo_id
           ,mol_gi_id
           ,mol_stock_num
           ,mol_num
           ,mol_status
           ,mol_add_time
           ,mol_retail_price
           ,mol_discount
           ,mol_stock_price
           ,mol_money
           ,mol_cp_id
           ,mol_box_num
           ,mol_pm
           ,mol_erp_id
           ,mol_source_id
           ,mol_boxbynum
           ,mol_color_id
		   ,mol_type
		   )
SELECT 
	mo_id,
	mol_gi_id,
	0,
	abs(mol_num),
	1,
	isnull(mol_add_time,getdate()),
	mol_retail_price,
	mol_discount,
	mol_stock_price,
	mol_money,
	mo_cp_id,
   (CASE WHEN ISNULL(mol_boxbynum,0)=0 THEN 0 ELSE CEILING(mol_num/mol_boxbynum) END)mol_box_num,
	mol_pm,
	erp_id,
    mo_source_id,
	mol_boxbynum,
	colorid,
	2 as mol_type
from (
	SELECT mo_id,
		mol_gi_id,
		colorid,
		isnull(mol_pm,'') as mol_pm,
		mol_boxbynum,
		ISNULL(SUM(mol_num),0)mol_num,
		SUM(mol_money)mol_money,
		MAX(mol_discount)mol_discount,
		CONVERT(DECIMAL(10, 2), AVG(mol_retail_price))mol_retail_price,
		CONVERT(DECIMAL(10, 2), AVG(mol_stock_price))mol_stock_price,
		mol_add_time,
		isnull(mo_source_id,0) as mo_source_id,
		mo_cp_id,
		erp_id
	FROM v_z_moStorage_detail 
	where mo_source_type=2 and mo_id in (select Id from @orderids)
	GROUP BY mo_id,
		mol_gi_id,
		colorid,
		isnull(mol_pm,''),
		mol_boxbynum,
		mo_cp_id,
		erp_id,
		isnull(mo_source_id,0),
		mol_add_time
) as bt
WHERE bt.mol_num<>0 

DELETE j_moStorageListMergeSum WHERE mol_mo_id in (select Id from @orderids)
INSERT INTO j_moStorageListMergeSum
           (mol_mo_id
           ,mol_gi_id
           ,mol_stock_num
           ,mol_num
           ,mol_status
           ,mol_add_time
           ,mol_retail_price
           ,mol_discount
           ,mol_stock_price
           ,mol_money
           ,mol_cp_id
           ,mol_box_num
           ,mol_pm
           ,mol_erp_id
           ,mol_source_id
           ,mol_boxbynum
		   ,mol_type)
select 
	mol_mo_id,
	mol_gi_id,
	0,
	mol_num,
	1,
	mol_add_time,
	mol_retail_price,
	mol_discount,
	mol_stock_price,
	mol_money,
	mol_cp_id,
   (CASE WHEN ISNULL(mol_boxbynum,0)=0 THEN 0 ELSE CEILING(mol_num/mol_boxbynum) END)mol_box_num,
	mol_pm,
	mol_erp_id,
    mol_source_id,
	mol_boxbynum,
	mol_type
from (
	select 
		mol_mo_id,
		mol_gi_id,
		sum(mol_num) as mol_num,
		mol_boxbynum,
		SUM(mol_money) as mol_money,
		max(mol_discount) as mol_discount,
		avg(mol_retail_price) as mol_retail_price,
		avg(mol_stock_price) as mol_stock_price,
		mol_add_time,
		mol_source_id,
		mol_cp_id,
		mol_erp_id,
		mol_pm,
		mol_type
	from 
		j_moStorageListMergeColorSum
		WHERE mol_mo_id in (select Id from @orderids)
	group by mol_mo_id,
			 mol_gi_id,
			 mol_boxbynum,
			 mol_source_id,
			 mol_pm,
			 mol_cp_id,
			 mol_erp_id,
			 mol_type,
			 mol_add_time
) bt


DELETE j_moStorageListMergeRuleSum where mol_mo_id in (select Id from @orderids)
INSERT INTO j_moStorageListMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
mol_mo_id
)
SELECT 
	ems.molmcs_id,
	num,
	colorid,
	SIZE,
	vi.mo_id
FROM (

	SELECT 
	0 mol_type,
	mol_gi_id,
	vi.mo_id,
	isnull(vi.mol_pm,'') AS mol_pm,
	colorid,
	size,
	-abs(sum(num)) AS num,
	mol_add_time
	FROM v_z_moStorage_detail AS vi
	WHERE  mo_out_st_id > 0 and vi.mo_id  in (select Id from @orderids)
	GROUP BY mol_gi_id,vi.mo_id,isnull(vi.mol_pm,''),colorid,SIZE,mol_add_time

	UNION ALL

	SELECT 
	1 mol_type,
	mol_gi_id,
	vi.mo_id,
	isnull(vi.mol_pm,'') AS mol_pm,
	colorid,
	size,
	abs(sum(num)) AS num,
	mol_add_time
	FROM v_z_moStorage_detail AS vi
	WHERE  mo_in_st_id > 0  AND mo_source_type=0 and vi.mo_id  in (select Id from @orderids)
	GROUP BY mol_gi_id,vi.mo_id,isnull(vi.mol_pm,''),colorid,SIZE,mol_add_time

	UNION ALL

	SELECT 
	2 mol_type,
	mol_gi_id,
	vi.mo_id,
	isnull(vi.mol_pm,'') AS mol_pm,
	colorid,
	size,
	abs(sum(num)) AS num,
	mol_add_time
	FROM v_z_moStorage_detail AS vi
	WHERE  mo_source_type=2 and vi.mo_id  in (select Id from @orderids)
	GROUP BY mol_gi_id,vi.mo_id,isnull(vi.mol_pm,''),colorid,SIZE,mol_add_time

) AS vi
INNER JOIN j_moStorageListMergeColorSum AS ems on 
ems.mol_mo_id=vi.mo_id AND ems.mol_gi_id=vi.mol_gi_id and 
ems.mol_color_id=vi.colorid AND isnull(vi.mol_pm,'')=ems.mol_pm
and vi.mol_type=ems.mol_type
and vi.mol_add_time=ems.mol_add_time
WHERE vi.num<>0 
AND ems.mol_mo_id  in (select Id from @orderids)

end







--订货
IF @stockType=7
BEGIN
print N'开始生成订货';

DELETE pos_ogStorageListMergeColorSum WHERE ogl_og_id in (select Id from @orderids)

INSERT INTO pos_ogStorageListMergeColorSum
(
	ogl_og_id,
	ogl_gi_id,
	ogl_color_id,
	ogl_pm,
	ogl_boxbynum,
	
	ogl_num,
	ogl_pause_num,
	ogl_pause_num_pll,
	ogl_num_ed,
	ogl_num_ed_pll,
	ogl_num_ed_ol,
	
	ogl_box_num,
	ogl_pause_box_num,
	ogl_pause_box_num_pll,
	ogl_box_num_ed,
	ogl_box_num_ed_pll,
	ogl_box_num_ed_ol,
	
	ogl_retail_price,
	ogl_stock_price,
	ogl_money,
	ogl_retail_money,
	ogl_discount,
	ogl_status,
	ogl_add_time,
	ogl_erp_id,
	ogl_cspid
)
SELECT ogl_og_id,
	   ogl_gi_id,
	   ogl_color_id,
	   ogl_pm,
	   ogl_boxbynum,
		
	   ogl_num,
	   ogl_pause_num,
	   ogl_pause_num_pll,
	   ogl_num_ed,
	   ogl_num_ed_pll,
	   ogl_num_ed_ol,
		
	   (CASE WHEN ISNULL(ogl_boxbynum,0)=0 THEN 0 ELSE CEILING(ogl_num/ogl_boxbynum) END)ogl_box_num,
	   (CASE WHEN ISNULL(ogl_boxbynum,0)=0 THEN 0 ELSE CEILING(ogl_pause_num/ogl_boxbynum) END)ogl_pause_box_num,
	   (CASE WHEN ISNULL(ogl_boxbynum,0)=0 THEN 0 ELSE CEILING(ogl_pause_num_pll/ogl_boxbynum) END)ogl_pause_box_num_pll,
	   (CASE WHEN ISNULL(ogl_boxbynum,0)=0 THEN 0 ELSE CEILING(ogl_num_ed/ogl_boxbynum) END)ogl_box_num_ed,
	   (CASE WHEN ISNULL(ogl_boxbynum,0)=0 THEN 0 ELSE CEILING(ogl_num_ed_pll/ogl_boxbynum) END)ogl_box_num_ed_pll,
	   (CASE WHEN ISNULL(ogl_boxbynum,0)=0 THEN 0 ELSE CEILING(ogl_num_ed_ol/ogl_boxbynum) END)ogl_box_num_ed_ol,
		
	   ogl_retail_price,
	   ogl_stock_price,
	   ogl_money,
	   ogl_retail_money,
	   ogl_discount,
	   1,
	   ogl_add_time,
	   ogl_erp_id,
	   ogl_cspid 
FROM (
	SELECT ogl_og_id,
		   ogl_gi_id,
		   colorid ogl_color_id,
		   isnull(ogl_pm,'') ogl_pm,
		   ogl_boxbynum,
			
		   ISNULL(SUM(ogl_num),0)ogl_num,
		   ISNULL(SUM(ogl_pause_num),0)ogl_pause_num,
		   ISNULL(SUM(ogl_pause_num_pll),0)ogl_pause_num_pll,
		   ISNULL(SUM(ogl_num_ed),0)ogl_num_ed,
		   ISNULL(SUM(ogl_num_ed_pll),0)ogl_num_ed_pll,
		   ISNULL(SUM(ogl_num_ed_ol),0)ogl_num_ed_ol,
			
		   CONVERT(DECIMAL(10, 2), AVG(ogl_retail_price))ogl_retail_price,
		   CONVERT(DECIMAL(10, 2), AVG(ogl_stock_price))ogl_stock_price,
		   SUM(ogl_money)ogl_money,
		   SUM(ogl_retail_money)ogl_retail_money,
		   MAX(ogl_discount)ogl_discount,
		   isnull(ogl_add_time,getdate()) as ogl_add_time,
		   ogl_erp_id,
		   ogl_cspid
	FROM v_z_pos_ogStorage_detail
	WHERE og_id in (select Id from @orderids)
	GROUP BY ogl_og_id,
		     ogl_gi_id,
		     colorid,
			 isnull(ogl_add_time,getdate()),
		     isnull(ogl_pm,''),
		     ogl_boxbynum,
		     ogl_erp_id,
		     ogl_cspid
	)ogl

DELETE pos_ogStorageListMergeSum WHERE ogl_og_id in (select Id from @orderids)

INSERT INTO pos_ogStorageListMergeSum
(
	ogl_og_id,
	ogl_gi_id,
	ogl_pm,
	ogl_boxbynum,
	
	ogl_num,
	ogl_pause_num,
	ogl_pause_num_pll,
	ogl_num_ed,
	ogl_num_ed_pll,
	ogl_num_ed_ol,
	
	ogl_box_num,
	ogl_pause_box_num,
	ogl_pause_box_num_pll,
	ogl_box_num_ed,
	ogl_box_num_ed_pll,
	ogl_box_num_ed_ol,
	
	ogl_retail_price,
	ogl_stock_price,
	ogl_money,
	ogl_retail_money,
	ogl_discount,
	ogl_status,
	ogl_add_time,
	ogl_erp_id,
	ogl_cspid
)
SELECT ogl_og_id,
	   ogl_gi_id,
	   ogl_pm,
	   ogl_boxbynum,
		
	   SUM(ogl_num)ogl_num,
	   SUM(ogl_pause_num)ogl_pause_num,
	   SUM(ogl_pause_num_pll)ogl_pause_num_pll,
	   SUM(ogl_num_ed)ogl_num_ed,
	   SUM(ogl_num_ed_pll)ogl_num_ed_pll,
	   SUM(ogl_num_ed_ol)ogl_num_ed_ol,
		 
	   SUM(ogl_box_num)ogl_box_num,
	   SUM(ogl_pause_box_num)ogl_pause_box_num,
	   SUM(ogl_pause_box_num_pll)ogl_pause_box_num_pll,
	   SUM(ogl_box_num_ed)ogl_box_num_ed,
	   SUM(ogl_box_num_ed_pll)ogl_box_num_ed_pll,
	   SUM(ogl_box_num_ed_ol)ogl_box_num_ed_ol,
		
	   CONVERT(DECIMAL(10, 2), AVG(ogl_retail_price))ogl_retail_price,
	   CONVERT(DECIMAL(10, 2), AVG(ogl_stock_price))ogl_stock_price,
	   SUM(ogl_money)ogl_money,
	   SUM(ogl_retail_money)ogl_retail_money,
	   MAX(ogl_discount)ogl_discount,
	   1,
	   ogl_add_time,
	   ogl_erp_id,
	   ogl_cspid
FROM pos_ogStorageListMergeColorSum
WHERE ogl_og_id in (select Id from @orderids)
GROUP BY ogl_og_id,
	     ogl_gi_id,
	     ogl_pm,
		 ogl_add_time,
	     ogl_boxbynum,
	     ogl_erp_id,
	     ogl_cspid

DELETE pos_ogStorageListMergeRuleSum WHERE ogl_og_id in (select Id from @orderids)
INSERT INTO pos_ogStorageListMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
ogl_og_id,
pause_num,
pause_num_pll,
num_ed,
num_ed_pll,
num_ed_ol
)
SELECT 
ems.oglmcs_id,
vi.ogl_num,
vi.colorid,
vi.ruleid,
vi.ogl_og_id,
vi.ogl_pause_num,
vi.ogl_pause_num_pll,
vi.ogl_num_ed,
vi.ogl_num_ed_pll,
vi.ogl_num_ed_ol
FROM (
SELECT  ogl_og_id,
		ogl_gi_id,
		colorid,
		SIZE AS ruleid,
		isnull(ogl_pm,'') ogl_pm,
		ISNULL(SUM(ogl_num),0)ogl_num,
		ISNULL(SUM(ogl_pause_num),0)ogl_pause_num,
		ISNULL(SUM(ogl_pause_num_pll),0)ogl_pause_num_pll,
		ISNULL(SUM(ogl_num_ed),0)ogl_num_ed,
		ISNULL(SUM(ogl_num_ed_pll),0)ogl_num_ed_pll,
		ISNULL(SUM(ogl_num_ed_ol),0)ogl_num_ed_ol,ogl_add_time
FROM v_z_pos_ogStorage_detail
WHERE ogl_og_id in (select Id from @orderids)
GROUP BY ogl_og_id,
		 ogl_gi_id,
		 colorid,
		 SIZE,
		 isnull(ogl_pm,''),ogl_add_time
) AS vi
INNER JOIN pos_ogStorageListMergeColorSum AS ems 
on vi.ogl_og_id=ems.ogl_og_id AND vi.ogl_gi_id=ems.ogl_gi_id AND vi.ogl_pm=ems.ogl_pm 
and vi.colorid=ems.ogl_color_id and ems.ogl_add_time=vi.ogl_add_time
WHERE vi.ogl_num<>0 
AND ems.ogl_og_id  in (select Id from @orderids)


END

--配货
IF @stockType=8
BEGIN
print N'开始生成配货';
DELETE pos_allocationListMergeColorSum where all_al_id in (select Id from @orderids)

INSERT INTO pos_allocationListMergeColorSum
(
	all_al_id,
	all_gi_id,
	all_color_id,
	all_pm,
	all_boxbynum,
	
	all_num,
	all_pause_num,
	all_num_ed,
	
	all_box_num,
	all_pause_box_num,
	all_box_num_ed,
	
	all_retail_price,
	all_stock_price,
	all_money,
	all_retail_money,
	all_discount,
	supplyprice,
	discount,
	all_gift,
	all_status,
	all_add_time,
	all_source_id,
	all_source_add_time,
	all_erp_id,
	all_cspid
)
SELECT al_id,
	   all_gi_id,
	   all_color_id,
       all_pm,
	   all_boxbynum,
	
	   all_num,
	   all_pause_num,
	   all_num_ed,
	
	   (CASE WHEN ISNULL(all_boxbynum,0)=0 THEN 0 ELSE CEILING(all_num/all_boxbynum) END)all_box_num,
	   (CASE WHEN ISNULL(all_boxbynum,0)=0 THEN 0 ELSE CEILING(all_pause_num/all_boxbynum) END)all_pause_box_num,
	   (CASE WHEN ISNULL(all_boxbynum,0)=0 THEN 0 ELSE CEILING(all_num_ed/all_boxbynum) END)all_box_num_ed,
	
	   all_retail_price,
	   all_stock_price,
	   all_money,
	   all_retail_money,
	   all_discount,
	   supplyprice,
	   discount,
	   all_gift,
	   1,
	   isnull(all_add_time,getdate()),
	   all_source_id,
	   all_source_add_time,
	   erp_id,
	   al_cp_id
FROM (
	SELECT al_id,
		   all_gi_id,
		   colorid all_color_id,
		   isnull(all_pm,'') as all_pm,
		   all_boxbynum,
			
		   ISNULL(SUM(all_num),0)all_num,
		   ISNULL(SUM(all_pause_num),0)all_pause_num,
		   ISNULL(SUM(all_num_ed),0)all_num_ed,
			
		   CONVERT(DECIMAL(10, 2), AVG(all_retail_price))all_retail_price,
		   CONVERT(DECIMAL(10, 2), AVG(all_stock_price))all_stock_price,
		   SUM(all_money)all_money,
		   SUM(all_retail_money)all_retail_money,
		   MAX(all_discount)all_discount,
		   CONVERT(DECIMAL(10, 2), AVG(supplyprice))supplyprice,
		   MAX(discount)discount,
		   isnull(all_gift,0) as all_gift,
		   all_add_time,
		   MAX(all_source_id)all_source_id,
		   MAX(all_source_add_time)all_source_add_time,
		   erp_id,
		   al_cp_id
	FROM v_z_allocation_detail
	WHERE al_id in (select Id from @orderids)
	GROUP BY al_id,
		     all_gi_id,
		     colorid,
			 all_add_time,
		     isnull(all_pm,''),
		     all_boxbynum, 
		     isnull(all_gift,0), 
		     erp_id,
		     al_cp_id
	)al

DELETE pos_allocationListMergeSum where all_al_id in (select Id from @orderids)

INSERT INTO pos_allocationListMergeSum
(
	all_al_id,
	all_gi_id,
	all_pm,
	all_boxbynum,
	
	all_num,
	all_pause_num,
	all_num_ed,
	
	all_box_num,
	all_pause_box_num,
	all_box_num_ed,
	
	all_retail_price,
	all_stock_price,
	all_money,
	all_retail_money,
	all_discount,
	supplyprice,
	discount,
	all_gift,
	all_status,
	all_add_time,
	all_source_id,
	all_source_add_time,
	all_erp_id,
	all_cspid
)
SELECT all_al_id,
	   all_gi_id,
	   all_pm,
	   all_boxbynum,
		
	   SUM(all_num)all_num,
	   SUM(all_pause_num)all_pause_num,
	   SUM(all_num_ed)all_num_ed,
		 
	   SUM(all_box_num)all_box_num,
	   SUM(all_pause_box_num)all_pause_box_num,
	   SUM(all_box_num_ed)all_box_num_ed,
		
	   CONVERT(DECIMAL(10, 2), AVG(all_retail_price))all_retail_price,
	   CONVERT(DECIMAL(10, 2), AVG(all_stock_price))all_stock_price,
	   SUM(all_money)all_money,
	   SUM(all_retail_money)all_retail_money,
	   MAX(all_discount)all_discount,
	   CONVERT(DECIMAL(10, 2), AVG(supplyprice))supplyprice,
	   MAX(discount)discount,
	   isnull(all_gift,0) as all_gift,
	   1,
	   all_add_time,
	   MAX(all_source_id)all_source_id,
	   MAX(all_source_add_time)all_source_add_time,
	   all_erp_id,
	   all_cspid
FROM pos_allocationListMergeColorSum
WHERE all_al_id in (select Id from @orderids)
GROUP BY all_al_id,
	     all_gi_id,
	     all_pm,
	     all_boxbynum,
		 all_add_time,
	     isnull(all_gift,0),
	     all_erp_id,
	     all_cspid


DELETE pos_allocationListMergeRuleSum WHERE all_al_id in (select Id from @orderids)
INSERT INTO pos_allocationListMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
all_al_id,
pause_num,
num_ed
)
SELECT 
ems.allmcs_id,
vi.all_num,
vi.colorid,
vi.[SIZE],
vi.al_id,
vi.all_pause_num,
vi.all_num_ed
FROM (
SELECT al_id,
	   all_gi_id,
	   all_pm,
	   colorid,
	   SIZE,
	   SUM(all_num)all_num,
	   SUM(all_pause_num)all_pause_num,
	   SUM(all_num_ed)all_num_ed,
	   isnull(all_gift,0) AS all_gift,all_add_time
FROM v_z_allocation_detail
WHERE al_id in (select Id from @orderids)
GROUP BY al_id,
	     all_gi_id,
	     all_pm,
	     colorid,
	     SIZE,
	     isnull(all_gift,0),all_add_time
) AS vi
INNER JOIN pos_allocationListMergeColorSum AS ems 
on vi.al_id=ems.all_al_id AND vi.all_gi_id=ems.all_gi_id AND vi.all_pm=ems.all_pm AND vi.all_gift=ems.all_gift and vi.colorid=ems.all_color_id
and vi.all_add_time=ems.all_add_time
where vi.all_num<> 0 and ems.all_al_id in (select Id from @orderids)

END

--采购
IF @stockType=9
BEGIN

print N'开始生成采购';
DELETE j_purchasestoragelistmergecolorsum where pll_pl_id in (select Id from @orderids)

INSERT INTO j_purchasestoragelistmergecolorsum
(pll_pl_id
,pll_gi_id

,pll_num
,pll_pause_num
,pll_num_ed

,pll_box_num
,pll_pause_box_num
,pll_box_num_ed

,pll_retail_price
,pll_discount
,pll_stock_price
,pll_money
,pll_status
,pll_add_time
,pll_source_id
,pll_pm
,pll_boxbynum

,pll_color_id
,pll_erp_id
,pll_cp_id
)
SELECT 
pll_pl_id,
pll_gi_id,

pll_num,
pll_pause_num,
pll_num_ed,

(case when isnull(pll_boxbynum,0)=0 then 0 else ceiling(pll_num/pll_boxbynum) end) as pll_box_num,
(case when isnull(pll_boxbynum,0)=0 then 0 else ceiling(pll_pause_num/pll_boxbynum) end) as pll_pause_box_num,
(case when isnull(pll_boxbynum,0)=0 then 0 else ceiling(pll_num_ed/pll_boxbynum) end) as pll_box_num_ed,

pll_retail_price,
pll_discount,
pll_stock_price,
pll_money,
1,
 isnull(pll_add_time,getdate()),
pll_source_id,
pll_pm,
pll_boxbynum,

pll_color_id,
pll_erp_id,
pl_cp_id
FROM (
	SELECT 
		pll_pl_id,
		pll_gi_id,
		SUM(pll_num) AS pll_num,
		CONVERT(DECIMAL(10, 2), AVG(pll_retail_price)) AS pll_retail_price,
		MAX(pll_discount) AS pll_discount, 
		CONVERT(DECIMAL(10, 2), AVG(pll_stock_price)) AS pll_stock_price,
		SUM(pll_money) AS pll_money,
		pll_add_time,
		isnull(og_id,0) AS pll_source_id, 
		pl_cp_id,
		isnull(colorid,0) AS pll_color_id,
		SUM(pll_num_ed) AS pll_num_ed,
		SUM(pll_pause_num) AS pll_pause_num,
		isnull(pll_pm,'') as pll_pm,
		pll_boxbynum,
		erp_id AS pll_erp_id
	FROM v_z_purchaseStorage_detail WHERE pl_id in (select Id from @orderids)
	GROUP BY 
	pl_cp_id,pll_pl_id,pll_gi_id,isnull(colorid,0),pll_boxbynum,
	isnull(pll_pm,''),erp_id,og_id,pll_add_time

) AS pl

DELETE j_purchasestoragelistmergesum WHERE pll_pl_id in (select Id from @orderids)

INSERT INTO j_purchasestoragelistmergesum
(pll_pl_id
,pll_gi_id

,pll_num
,pll_num_ed
,pll_pause_num

,pll_box_num
,pll_pause_box_num
,pll_box_num_ed

,pll_retail_price
,pll_discount
,pll_stock_price
,pll_money
,pll_status
,pll_add_time
,pll_source_id
,pll_pm
,pll_boxbynum

,pll_cp_id
,pll_erp_id
)
SELECT 
pll_pl_id,
pll_gi_id,
SUM(pll_num) AS pll_num,
SUM(pll_num_ed) AS pll_num_ed,
SUM(pll_pause_num) AS pll_pause_num,

SUM(pll_box_num) AS pll_box_num,
SUM(pll_pause_box_num) AS pll_pause_box_num,
SUM(pll_box_num_ed) AS pll_box_num_ed,

CONVERT(DECIMAL(10, 2), AVG(pll_retail_price)) AS pll_retail_price,
MAX(pll_discount) AS pll_discount, 
CONVERT(DECIMAL(10, 2), AVG(pll_stock_price)) AS pll_stock_price,
SUM(pll_money) AS pll_money,
1,
pll_add_time,
pll_source_id, 
pll_pm,
pll_boxbynum,

pll_cp_id,
pll_erp_id
FROM j_purchasestoragelistmergecolorsum WHERE  pll_pl_id in (select Id from @orderids)
GROUP BY 
pll_pl_id,pll_gi_id,pll_cp_id,pll_boxbynum,pll_pm,pll_erp_id,pll_source_id,pll_add_time

DELETE j_purchasestoragelistmergerulesum WHERE pll_pl_id in (select Id from @orderids)
INSERT INTO j_purchasestoragelistmergerulesum
(
cs_id,
num,
colorid,
ruleid,
pll_pl_id,
pause_num,
num_ed
)
SELECT 
ems.pcs_id,
vi.pll_num,
vi.pll_color_id,
vi.SIZE,
vi.pll_pl_id,
vi.pll_pause_num,
vi.pll_num_ed
FROM (
	SELECT 
		pll_pl_id,
		pll_gi_id,
		isnull(pll_pm,'') as pll_pm,
		isnull(colorid,0) AS pll_color_id,
		SIZE,
		SUM(pll_num) AS pll_num,
		SUM(pll_num_ed) AS pll_num_ed,
		SUM(pll_pause_num) AS pll_pause_num,pll_add_time
	FROM v_z_purchaseStorage_detail 
	WHERE pll_pl_id in (select Id from @orderids)
	GROUP BY 
	pll_pl_id,
	pll_gi_id,
	isnull(colorid,0),
	SIZE,
	isnull(pll_pm,''),pll_add_time
) AS vi
INNER JOIN j_purchasestoragelistmergecolorsum AS ems 
on vi.pll_pl_id=ems.pll_pl_id AND vi.pll_gi_id=ems.pll_gi_id AND vi.pll_pm=ems.pll_pm and vi.pll_color_id=ems.pll_color_id
and vi.pll_add_time=ems.pll_add_time
where vi.pll_num<>0 and ems.pll_pl_id in (select Id from @orderids)

END 

--盘点
if @stockType=10
begin

print  N'开始生成盘点';
delete j_takeStorageListMergeColorSum where tsl_ts_id in (select Id from @orderids)
INSERT INTO j_takeStorageListMergeColorSum
           (tsl_ts_id
           ,tsl_gi_id

           ,tsl_old_num
           ,tsl_new_num
           ,tsl_log_num

           ,tsl_old_weight
           ,tsl_new_weight
           ,tsl_log_weight

           ,tsl_old_money
           ,tsl_log_money
           ,tsl_new_money

           ,tsl_retail_price
           ,tsl_add_time
           ,tsl_stock_price

           ,tsl_discount
           ,tsl_cp_id

		   ,tsl_old_box_num
           ,tsl_box_num
           ,tsl_log_box_num

           ,tsl_pm
           ,tsl_erp_id
           ,tsl_boxbynum
           ,tsl_color_id)
SELECT 
		tsl_ts_id,
		tsl_gi_id,

		tsl_old_num,
		tsl_new_num,
		tsl_log_num,

		tsl_old_weight,
		tsl_new_weight,
		tsl_log_weight,

		tsl_old_money,
		tsl_log_money,
		tsl_new_money,

		tsl_retail_price,
		tsl_add_time,
		tsl_stock_price,

		tsl_discount,
		ts_cp_id,

		(CASE WHEN ISNULL(tsl_boxbynum,0)=0 THEN 0 ELSE CEILING(tsl_old_num/tsl_boxbynum) END) tsl_old_box_num,
		(CASE WHEN ISNULL(tsl_boxbynum,0)=0 THEN 0 ELSE CEILING(tsl_new_num/tsl_boxbynum) END) tsl_box_num,
		(CASE WHEN ISNULL(tsl_boxbynum,0)=0 THEN 0 ELSE CEILING(tsl_log_num/tsl_boxbynum) END) tsl_log_box_num,

		tsl_pm,
		erp_id,
		tsl_boxbynum,
		colorid
FROM (
	SELECT 
		tsl_ts_id,
		tsl_gi_id,
	
		sum(tsl_old_num) as tsl_old_num,
		sum(tsl_new_num) as tsl_new_num,
		sum(tsl_log_num) as tsl_log_num,
    
		0 AS tsl_old_weight,
		0 AS tsl_new_weight,
		0 AS tsl_log_weight,
    
		sum(tsl_old_money) as tsl_old_money,
		sum(tsl_log_money) as tsl_log_money,
		sum(tsl_new_money) as tsl_new_money,
    
		MAX(tsl_retail_price) AS tsl_retail_price,
		tsl_add_time,
		MAX(tsl_stock_price) as tsl_stock_price,
		MAX(tsl_discount) AS tsl_discount,
		ts_cp_id,
		isnull(tsl_pm,'') as tsl_pm,
		erp_id,
		tsl_boxbynum,
		colorid
	FROM v_z_takeStorage_detail
    WHERE tsl_ts_id in (select Id from @orderids)
	GROUP BY 
		tsl_ts_id,
		tsl_gi_id,
		isnull(tsl_pm,''),
		ts_cp_id,
		erp_id,
		tsl_boxbynum,
		tsl_add_time,
		colorid
) AS bt

delete j_takeStorageListMergeSum where tsl_ts_id in (select Id from @orderids)
INSERT INTO j_takeStorageListMergeSum
           (tsl_ts_id
           ,tsl_gi_id

           ,tsl_old_num
           ,tsl_new_num
           ,tsl_log_num

           ,tsl_old_weight
           ,tsl_new_weight
           ,tsl_log_weight

           ,tsl_old_money
           ,tsl_log_money
           ,tsl_new_money

           ,tsl_retail_price
           ,tsl_add_time
           ,tsl_stock_price

           ,tsl_discount
           ,tsl_cp_id

		   ,tsl_old_box_num
           ,tsl_box_num
           ,tsl_log_box_num

           ,tsl_pm
           ,tsl_erp_id
           ,tsl_boxbynum
		   )
SELECT 
		tsl_ts_id,
		tsl_gi_id,

		tsl_old_num,
		tsl_new_num,
		tsl_log_num,

		tsl_old_weight,
		tsl_new_weight,
		tsl_log_weight,

		tsl_old_money,
		tsl_log_money,
		tsl_new_money,

		tsl_retail_price,
		tsl_add_time,
		tsl_stock_price,

		tsl_discount,
		tsl_cp_id,

		(CASE WHEN ISNULL(tsl_boxbynum,0)=0 THEN 0 ELSE CEILING(tsl_old_num/tsl_boxbynum) END) tsl_old_box_num,
		(CASE WHEN ISNULL(tsl_boxbynum,0)=0 THEN 0 ELSE CEILING(tsl_new_num/tsl_boxbynum) END) tsl_box_num,
		(CASE WHEN ISNULL(tsl_boxbynum,0)=0 THEN 0 ELSE CEILING(tsl_log_num/tsl_boxbynum) END) tsl_log_box_num,

		tsl_pm,
		tsl_erp_id,
		tsl_boxbynum
FROM (
SELECT 
		tsl_ts_id,
		tsl_gi_id,
	
		sum(tsl_old_num) as tsl_old_num,
		sum(tsl_new_num) as tsl_new_num,
		sum(tsl_log_num) as tsl_log_num,
    
		0 AS tsl_old_weight,
		0 AS tsl_new_weight,
		0 AS tsl_log_weight,
    
		sum(tsl_old_money) as tsl_old_money,
		sum(tsl_log_money) as tsl_log_money,
		sum(tsl_new_money) as tsl_new_money,
    
		MAX(tsl_retail_price) AS tsl_retail_price,
		tsl_add_time,
		MAX(tsl_stock_price) as tsl_stock_price,
		MAX(tsl_discount) AS tsl_discount,
		tsl_cp_id,
		tsl_pm,
		tsl_erp_id,
		tsl_boxbynum
FROM j_takeStorageListMergeColorSum
where tsl_ts_id in (select Id from @orderids)
GROUP BY 
		tsl_ts_id,
		tsl_gi_id,
		tsl_pm,
		tsl_cp_id,
		tsl_erp_id,
		tsl_boxbynum,
		tsl_add_time
) AS bt

delete j_takeStorageListMergeRuleSum where tsl_ts_id in (select Id from @orderids)
INSERT INTO j_takeStorageListMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
tsl_ts_id,
old_num,
log_num
)
SELECT 
    ems.tsl_id,
	vi.tsl_new_num,
	vi.colorid,
	vi.ruleid,
	vi.tsl_ts_id,
	vi.tsl_old_num,
	vi.tsl_log_num
FROM (
	SELECT 
		tsl_ts_id,
		tsl_gi_id,
		sum(tsl_old_num) as tsl_old_num,
		sum(tsl_new_num) as tsl_new_num,
		sum(tsl_log_num) as tsl_log_num,
		tsl_add_time,
		isnull(tsl_pm,'') as tsl_pm,
		colorid,
		SIZE AS ruleid
	FROM v_z_takeStorage_detail
	where tsl_ts_id in (select Id from @orderids)
	GROUP BY 
		tsl_ts_id,
		tsl_gi_id,
		isnull(tsl_pm,''),
		tsl_add_time,
		colorid,
		SIZE
) AS vi
INNER JOIN j_takeStorageListMergeColorSum AS ems
ON vi.tsl_ts_id=ems.tsl_ts_id AND vi.tsl_gi_id=ems.tsl_gi_id
AND vi.tsl_pm=ems.tsl_pm AND vi.colorid=ems.tsl_color_id
and vi.tsl_add_time=ems.tsl_add_time
where ems.tsl_ts_id in (select Id from @orderids)
end


--盈亏
IF @stockType=6
BEGIN
print N'开始生成盈亏';
DELETE j_plStorageListMergeColorSum WHERE ppl_type=0 and ppl_pl_id in (select Id from @orderids)
INSERT INTO j_plStorageListMergeColorSum
           (ppl_pl_id
           ,ppl_gi_id
           ,ppl_stock_num
           ,ppl_num
           ,ppl_status
           ,ppl_add_time
           ,ppl_retail_price
           ,ppl_discount
           ,ppl_stock_price
           ,ppl_money
           ,ppl_cp_id
           ,ppl_box_num
           ,ppl_pm
           ,ppl_erp_id
           ,ppl_boxbynum
           ,ppl_color_id,
		    ppl_type)
SELECT 
	 pl_id
    ,ppl_gi_id
    ,ppl_stock_num
    ,ppl_num
    ,1
    ,ppl_add_time
    ,ppl_retail_price
    ,ppl_discount
    ,ppl_stock_price
    ,ppl_money
    ,pl_cp_id
    ,(CASE WHEN ISNULL(ppl_boxbynum,0)=0 THEN 0 ELSE CEILING(ppl_num/ppl_boxbynum) END)ppl_box_num
    ,ppl_pm
    ,erp_id
    ,ppl_boxbynum
    ,colorid
	,0
FROM (
	SELECT 
		 pl_id
		,ppl_gi_id
		,sum(ppl_stock_num) AS ppl_stock_num
		,sum(abs(ppl_num)) AS ppl_num
		,ppl_add_time
		,max(ppl_retail_price) AS ppl_retail_price
		,max(ppl_discount) AS ppl_discount
		,max(ppl_stock_price) AS ppl_stock_price
		,sum(ppl_money) AS ppl_money
		,pl_cp_id
		,isnull(ppl_pm,'') AS ppl_pm
		,erp_id
		,ppl_boxbynum
		,colorid
	FROM v_z_plStorage_detail WHERE pltype=0 and pl_id in (select Id from @orderids)
	GROUP BY  
		 pl_id
		,ppl_gi_id
		,pl_cp_id
		,isnull(ppl_pm,'')
		,erp_id
		,ppl_boxbynum
		,colorid
		,ppl_add_time
) AS bt

DELETE j_plStorageListMergeSum WHERE ppl_type=0 and  ppl_pl_id in (select Id from @orderids)
INSERT INTO j_plStorageListMergeSum
           (ppl_pl_id
           ,ppl_gi_id
           ,ppl_stock_num
           ,ppl_num
           ,ppl_status
           ,ppl_add_time
           ,ppl_retail_price
           ,ppl_discount
           ,ppl_stock_price
           ,ppl_money
           ,ppl_cp_id
           ,ppl_box_num
           ,ppl_pm
           ,ppl_erp_id
           ,ppl_boxbynum
		   ,ppl_type)
SELECT 
	 ppl_pl_id
	,ppl_gi_id
	,ppl_stock_num
	,ppl_num
	,1
	,ppl_add_time
	,ppl_retail_price
	,ppl_discount
	,ppl_stock_price
	,ppl_money
	,ppl_cp_id
	,(CASE WHEN ISNULL(ppl_boxbynum,0)=0 THEN 0 ELSE CEILING(ppl_num/ppl_boxbynum) END)ppl_box_num
	,ppl_pm
	,ppl_erp_id
	,ppl_boxbynum
	,0
FROM (
	SELECT 
		 ppl_pl_id
		,ppl_gi_id
		,sum(ppl_stock_num) AS ppl_stock_num 
		,sum(ppl_num) AS ppl_num
		,ppl_add_time
		,max(ppl_retail_price) AS ppl_retail_price
		,max(ppl_discount) AS ppl_discount
		,max(ppl_stock_price) AS ppl_stock_price
		,sum(ppl_money) AS ppl_money
		,ppl_cp_id
		,ppl_pm
		,ppl_erp_id
		,ppl_boxbynum
	FROM j_plStorageListMergeColorSum
	where ppl_pl_id  in (select Id from @orderids) and ppl_type=0
	GROUP BY  
		 ppl_pl_id
		,ppl_gi_id
		,ppl_cp_id
		,ppl_pm
		,ppl_erp_id
		,ppl_boxbynum
		,ppl_add_time
) AS bt

delete j_plStorageListMergeRuleSum WHERE ppl_type=0 and ppl_pl_id in (select Id from @orderids)
INSERT INTO j_plStorageListMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
ppl_pl_id,
ppl_type
)
SELECT 
ems.ppl_id,
vi.ppl_num,
colorid,
ruleid,
pl_id,
0
FROM (
	SELECT 
	 pl_id
	,ppl_gi_id
	,sum(ppl_num) AS ppl_num
	,colorid
	,[size] AS ruleid
	,ppl_add_time
	,isnull(ppl_pm,'') AS ppl_pm
	,pltype
	FROM v_z_plStorage_detail 
	WHERE pltype=0 and pl_id in (select Id from @orderids)
	GROUP BY  
	pl_id
	,ppl_gi_id
	,isnull(ppl_pm,'')
	,colorid
	,[size]
	,ppl_add_time
	,pltype
) AS vi
INNER JOIN j_plStorageListMergeColorSum AS ems  ON 
ems.ppl_type=0 
and vi.pl_id=ems.ppl_pl_id 
AND vi.ppl_gi_id=ems.ppl_gi_id AND vi.colorid=ems.ppl_color_id AND vi.ppl_pm=ems.ppl_pm
and vi.ppl_add_time=ems.ppl_add_time
and vi.pltype=ems.ppl_type
where ems.ppl_pl_id in (select Id from @orderids)

END

--盘点盈亏
if @stockType=11
begin

print  N'开始生成盈亏';

delete j_plStorageListMergeColorSum where ppl_type=1 and ppl_pl_id in (select Id from @orderids)
INSERT INTO j_plStorageListMergeColorSum
           (ppl_pl_id
           ,ppl_gi_id
           ,ppl_stock_num
           ,ppl_num
           ,ppl_status
           ,ppl_add_time

           ,ppl_retail_price
           ,ppl_discount
           ,ppl_stock_price
           ,ppl_money

           ,ppl_cp_id
           ,ppl_box_num
           ,ppl_pm
           ,ppl_erp_id
           ,ppl_boxbynum
           ,ppl_color_id,
		    ppl_type,
			sl_order_no)
SELECT 
	bt.sl_eoid,
	bt.sl_giid,
	(SUM(bt.sl_takenum)-(CASE WHEN sl_counttype = 1 THEN SUM(bt.sl_number) ELSE -SUM(bt.sl_number) END)) stock_num, 
	isnull((Case when sl_counttype=1 Then SUM(bt.sl_number) Else -SUM(bt.sl_number) END),0)  as sl_number,
	1 as [status],
	MAX(sl_addtime) AS sl_addtime,

	max(bt.gi_retailprice)  as retail_price,
	0 as discount,
	max(bt.gs_purchase) as stock_price,
	max(bt.gs_purchase)*isnull((Case when sl_counttype=1 Then SUM(bt.sl_number) Else -SUM(bt.sl_number) END),0) as [money],

	bt.sl_cp_id,
	(CASE WHEN ISNULL(bt.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(SUM(bt.sl_number)/bt.sl_boxbynum) END) as all_box_num,
	isnull(bt.sl_pm,'') AS sl_pm,
	bt.sl_erp_id,
	bt.sl_boxbynum,
	bt.colorid,
	1,
	bt.sl_order_no
FROM (
	SELECT 
		ISNULL(grl.colorid,0) as colorid
		,isnull((CASE WHEN pal.sl_skuid=0 THEN gi_retailprice ELSE gs_marketprice END ),0) as gi_retailprice--零售价   
		,isnull((CASE WHEN pal.sl_skuid=0 THEN gi_purchase ELSE gs_purchase END ),0) AS  gs_purchase
		,sl_eoid
		,sl_elid
		,sl_seiid
		,sl_ciid
		,sl_giid
		,sl_type
		,sl_counttype
		,sl_number
		,sl_addtime
		,sl_updatetime
		,sl_remark
		,sl_status
		,sl_deltime
		,sl_order_no
		,sl_order_date
		,sl_order_add_time
		,sl_cp_id
		,sl_erp_id
		,sl_pm
		,sl_takenum
		,sl_boxbynum
	FROM j_stocklog_pal AS pal 
	LEFT JOIN b_goodsinfo AS bg ON pal.sl_giid=bg.gi_id
	left join b_goodsruleset as grl on grl.gss_id=pal.sl_skuid AND grl.gs_status>0
	WHERE pal.sl_eoid in (select Id from @orderids) AND pal.sl_status>0
) AS bt
GROUP BY bt.colorid,bt.sl_eoid,bt.sl_elid,bt.sl_seiid,bt.sl_ciid,bt.sl_giid,bt.sl_type,bt.sl_counttype,
sl_remark,bt.sl_status,bt.sl_order_no,bt.sl_cp_id,bt.sl_erp_id,isnull(bt.sl_pm,''),bt.sl_boxbynum

DELETE j_plStorageListMergeSum WHERE ppl_type=1 and  ppl_pl_id in (select Id from @orderids)
INSERT INTO j_plStorageListMergeSum
           (ppl_pl_id
           ,ppl_gi_id
           ,ppl_stock_num
           ,ppl_num
           ,ppl_status
           ,ppl_add_time
           ,ppl_retail_price
           ,ppl_discount
           ,ppl_stock_price
           ,ppl_money
           ,ppl_cp_id
           ,ppl_box_num
           ,ppl_pm
           ,ppl_erp_id
           ,ppl_boxbynum
		   ,ppl_type,sl_order_no)
SELECT 
	 ppl_pl_id
	,ppl_gi_id
	,ppl_stock_num
	,ppl_num
	,1
	,ppl_add_time
	,ppl_retail_price
	,ppl_discount
	,ppl_stock_price
	,ppl_money
	,ppl_cp_id
	,(CASE WHEN ISNULL(ppl_boxbynum,0)=0 THEN 0 ELSE CEILING(ppl_num/ppl_boxbynum) END)ppl_box_num
	,ppl_pm
	,ppl_erp_id
	,ppl_boxbynum
	,1,sl_order_no
FROM (
	SELECT 
		 ppl_pl_id
		,ppl_gi_id
		,sum(ppl_stock_num) AS ppl_stock_num 
		,sum(ppl_num) AS ppl_num
		,ppl_add_time
		,max(ppl_retail_price) AS ppl_retail_price
		,max(ppl_discount) AS ppl_discount
		,max(ppl_stock_price) AS ppl_stock_price
		,sum(ppl_money) AS ppl_money
		,ppl_cp_id
		,ppl_pm
		,ppl_erp_id
		,ppl_boxbynum,sl_order_no
	FROM j_plStorageListMergeColorSum
	where ppl_pl_id  in (select Id from @orderids) and ppl_type=1
	GROUP BY  
		 ppl_pl_id
		,ppl_gi_id
		,ppl_cp_id
		,ppl_pm
		,ppl_erp_id
		,ppl_boxbynum
		,ppl_add_time,sl_order_no
) AS bt

delete j_plStorageListMergeRuleSum WHERE ppl_type=1 and ppl_pl_id in (select Id from @orderids)
INSERT INTO j_plStorageListMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
ppl_pl_id,
ppl_type,
stock_num
)
SELECT 
ems.ppl_id,
vi.sl_number,
vi.colorid,
vi.ruleid,
vi.sl_eoid,
vi.ppl_type,
vi.stock_num
FROM (
	SELECT 
		bt.sl_eoid,
		bt.sl_giid,
		SUM(bt.sl_number) as sl_number,
		SUM(bt.ppl_stock_num) as stock_num,
		bt.sl_cp_id,
		bt.sl_erp_id,
		isnull(bt.sl_pm,'') AS sl_pm,
		SUM(bt.sl_takenum) AS sl_takenum,
		bt.sl_boxbynum,
		(CASE WHEN ISNULL(bt.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(SUM(bt.sl_number)/bt.sl_boxbynum) END)all_box_num,
		bt.colorid,
		bt.ruleid,
		1 as ppl_type
	FROM (
		SELECT 
			 ISNULL(grl.colorid,0) as colorid
			,ISNULL(grl.specid,0) AS ruleid
			,sl_eoid
			,sl_elid
			,sl_seiid
			,sl_ciid
			,sl_giid
			,sl_type
			,sl_counttype
			,isnull((Case when sl_counttype=1 Then sl_number Else -sl_number END),0) AS sl_number
			,(sl_takenum-(CASE WHEN sl_counttype = 1 THEN sl_number ELSE -sl_number END)) as ppl_stock_num  --日期库存数量=实盘数-盈亏数
			,sl_addtime
			,sl_updatetime
			,sl_remark
			,sl_status
			,sl_deltime
			,sl_order_no
			,sl_order_date
			,sl_order_add_time
			,sl_cp_id
			,sl_erp_id
			,sl_pm
			,sl_takenum
			,sl_boxbynum
		FROM j_stocklog_pal AS pal 
		left join b_goodsruleset as grl on grl.gss_id=pal.sl_skuid AND grl.gs_status>0
		WHERE pal.sl_eoid in (select Id from @orderids) AND pal.sl_status>0
		) AS bt
		GROUP BY bt.colorid,bt.ruleid,bt.sl_eoid,bt.sl_elid,bt.sl_seiid,bt.sl_ciid,bt.sl_giid,bt.sl_type,bt.sl_counttype,
		sl_remark,bt.sl_status,bt.sl_order_no,bt.sl_cp_id,bt.sl_erp_id,isnull(bt.sl_pm,''),bt.sl_boxbynum
) AS vi
INNER JOIN j_plStorageListMergeColorSum AS ems  ON  ems.ppl_type=1 and vi.ppl_type =ems.ppl_type
and vi.sl_eoid=ems.ppl_pl_id AND vi.sl_giid=ems.ppl_gi_id AND vi.colorid=ems.ppl_color_id AND vi.sl_pm=ems.ppl_pm
where ems.ppl_pl_id in (select Id from @orderids) 



--盘点盈亏
delete j_stocklog_palMergeColorSum where  sl_eoid in (select Id from @orderids)

INSERT INTO j_stocklog_palMergeColorSum
           (sl_eoid
           ,sl_elid
           ,sl_seiid
           ,sl_ciid
           ,sl_giid
           ,sl_type
           ,sl_counttype

           ,sl_number
           ,sl_addtime
           ,sl_updatetime
           ,sl_remark
           ,sl_status
           ,sl_order_no

           ,sl_order_date
           ,sl_order_add_time
           ,sl_cp_id
           ,sl_erp_id
           ,sl_pm
           ,sl_takenum
           ,sl_boxbynum
           ,sl_box_num
           ,sl_color_id)
SELECT 
	bt.sl_eoid,
	bt.sl_elid,
	bt.sl_seiid,
	bt.sl_ciid,
	bt.sl_giid,
	bt.sl_type,
	bt.sl_counttype,

	sum(bt.sl_number) as sl_number,
	max(sl_addtime) as sl_addtime,
	max(sl_updatetime) as sl_updatetime,
    sl_remark,
	bt.sl_status,
	bt.sl_order_no,

	max(sl_order_date) as sl_order_date,
	max(sl_order_add_time) as sl_order_add_time,
	bt.sl_cp_id,
	bt.sl_erp_id,
	isnull(bt.sl_pm,''),

	sum(bt.sl_takenum) as sl_takenum,
	bt.sl_boxbynum,
	(CASE WHEN ISNULL(bt.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(SUM(bt.sl_number)/bt.sl_boxbynum) END) as all_box_num,
	bt.colorid
FROM (
	SELECT 
		ISNULL(grl.colorid,0) as colorid
		,sl_eoid
		,sl_elid
		,sl_seiid
		,sl_ciid
		,sl_giid
		,sl_type
		,sl_counttype
		,sl_number
		,sl_addtime
		,sl_updatetime
		,sl_remark
		,sl_status
		,sl_deltime
		,sl_order_no
		,sl_order_date
		,sl_order_add_time
		,sl_cp_id
		,sl_erp_id
		,sl_pm
		,sl_takenum
		,sl_boxbynum
	FROM j_stocklog_pal AS pal 
	left join b_goodsruleset as grl on grl.gss_id=pal.sl_skuid AND grl.gs_status>0
	WHERE pal.sl_eoid in (select Id from @orderids) AND pal.sl_status>0
) AS bt
GROUP BY bt.colorid,bt.sl_eoid,bt.sl_elid,bt.sl_seiid,bt.sl_ciid,bt.sl_giid,bt.sl_type,bt.sl_counttype,
sl_remark,bt.sl_status,bt.sl_order_no,bt.sl_cp_id,bt.sl_erp_id,isnull(bt.sl_pm,''),bt.sl_boxbynum


delete j_stocklog_palMergeSum where  sl_eoid in (select Id from @orderids)
INSERT INTO j_stocklog_palMergeSum
           (sl_eoid
           ,sl_elid
           ,sl_seiid
           ,sl_ciid
           ,sl_giid
           ,sl_type
           ,sl_counttype
           ,sl_number
           ,sl_addtime
           ,sl_updatetime
           ,sl_remark
           ,sl_status
           ,sl_order_no
           ,sl_order_date
           ,sl_order_add_time
           ,sl_cp_id
           ,sl_erp_id
           ,sl_pm
           ,sl_takenum
           ,sl_boxbynum
           ,sl_box_num)
SELECT 
	bt.sl_eoid,
	bt.sl_elid,
	bt.sl_seiid,
	bt.sl_ciid,
	bt.sl_giid,
	bt.sl_type,
	bt.sl_counttype,

	sum(bt.sl_number) as sl_number,
	max(sl_addtime) as sl_addtime,
	max(sl_updatetime) as sl_updatetime,
    sl_remark,
	bt.sl_status,
	bt.sl_order_no,

	max(sl_order_date) as sl_order_date,
	max(sl_order_add_time) as sl_order_add_time,
	bt.sl_cp_id,
	bt.sl_erp_id,
	isnull(bt.sl_pm,''),

	sum(bt.sl_takenum) as sl_takenum,
	bt.sl_boxbynum,
	(CASE WHEN ISNULL(bt.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(SUM(bt.sl_number)/bt.sl_boxbynum) END) as all_box_num
FROM j_stocklog_palMergeColorSum AS bt
where sl_eoid in (select Id from @orderids)
GROUP BY bt.sl_eoid,bt.sl_elid,bt.sl_seiid,bt.sl_ciid,bt.sl_giid,bt.sl_type,bt.sl_counttype,
sl_remark,bt.sl_status,bt.sl_order_no,bt.sl_cp_id,bt.sl_erp_id,isnull(bt.sl_pm,''),bt.sl_boxbynum


end


--pos销售
if @stockType=12
begin

delete z_pos_sale_detail where sa_id in (select Id from @orderids);
INSERT INTO z_pos_sale_detail
			(specname
			,spec2
			,specno
			,gd_row_number
			,gss_no
			,gs_name
			,colorgroupname
			,color
			,specngroupname
			,spec
			,colorid
			,size
			,specid
			,gs_sampleno
			,sal_retail_money
			,gi_costprice
			,gi_costprice_money
			,sal_id
			,sal_customprice
			,sa_ac_names
			,sh_company
			,erp_id
			,gi_id
			,gi_skuid
			,gi_brandsid
			,gb_name
			,sal_gi_id
			,gi_attribute_parentids
			,gi_attribute_ids
			,gi_typesid
			,gi_types
			,gi_type1
			,gi_type2
			,gi_type3
			,gi_type4
			,gi_sampleno
			,gc_name1
			,gc_name2
			,gc_name3
			,gc_name4
			,vl_no
			,sa_id
			,sa_salman
			,sa_salmanname
			,sa_vo
			,sa_no
			,sa_month
			,sa_date
			,sei_name
			,sh_id
			,sa_sh_id
			,sa_sh_id_txt
			,sh_name
			,sh_no
			,gi_code
			,gi_name
			,gi_barcode
			,st_id
			,st_st_id
			,num
			,sa_paytype
			,sa_me_id
			,me_name
			,me_card
			,vip
			,sa_co_man_txt
			,sal_list_man_txt
			,sa_get_in_num
			,sa_current_vo
			,gi_unit
			,ut_name
			,sal_retail_price
			,sal_discount
			,sal_real_price
			,sal_num
			,sal_deduct_money
			,sal_money
			,saltype
			,sal_is_gift
			,sal_paidmomey
			,salpaidmomey
			,returnsalpaidmomey
			,salnum
			,returnsalnum
			,sa_add_man
			,sal_paiddiscount
			,sal_is_change
			,sal_is_return
			,sal_is_in
			,sal_remark
			,sal_remark2
			,sa_status
			,sa_st_id_txt
			,sa_st_id
			,sa_order_man_txt
			,sa_add_man_txt
			,sa_add_time
			,sa_update_man_txt
			,sa_update_time
			,sa_audit_man_txt
			,sa_audit_time
			,sal_add_time
			,sal_sku_id
			,oi_no
			,sal_buyingteamid
			,gi_buyingteam
			,gi_supplierid
			,gi_supplier
			,gi_purchase
			,gi_purchase_money
			,gi_costprice_z
			,sa_remark
			,rulecode
			,sizecode
			,colorcode)
SELECT specname
		,spec2
		,specno
		,gd_row_number
		,gss_no
		,gs_name
		,colorgroupname
		,color
		,specngroupname
		,spec
		,colorid
		,size
		,specid
		,gs_sampleno
		,sal_retail_money
		,gi_costprice
		,gi_costprice_money
		,sal_id
		,sal_customprice
		,sa_ac_names
		,sh_company
		,erp_id
		,gi_id
		,gi_skuid
		,gi_brandsid
		,gb_name
		,sal_gi_id
		,gi_attribute_parentids
		,gi_attribute_ids
		,gi_typesid
		,gi_types
		,gi_type1
		,gi_type2
		,gi_type3
		,gi_type4
		,gi_sampleno
		,gc_name1
		,gc_name2
		,gc_name3
		,gc_name4
		,vl_no
		,sa_id
		,sa_salman
		,sa_salmanname
		,sa_vo
		,sa_no
		,sa_month
		,sa_date
		,sei_name
		,sh_id
		,sa_sh_id
		,sa_sh_id_txt
		,sh_name
		,sh_no
		,gi_code
		,gi_name
		,gi_barcode
		,st_id
		,st_st_id
		,num
		,sa_paytype
		,sa_me_id
		,me_name
		,me_card
		,vip
		,sa_co_man_txt
		,sal_list_man_txt
		,sa_get_in_num
		,sa_current_vo
		,gi_unit
		,ut_name
		,sal_retail_price
		,sal_discount
		,sal_real_price
		,sal_num
		,sal_deduct_money
		,sal_money
		,saltype
		,sal_is_gift
		,sal_paidmomey
		,salpaidmomey
		,returnsalpaidmomey
		,salnum
		,returnsalnum
		,sa_add_man
		,sal_paiddiscount
		,sal_is_change
		,sal_is_return
		,sal_is_in
		,sal_remark
		,sal_remark2
		,sa_status
		,sa_st_id_txt
		,sa_st_id
		,sa_order_man_txt
		,sa_add_man_txt
		,sa_add_time
		,sa_update_man_txt
		,sa_update_time
		,sa_audit_man_txt
		,sa_audit_time
		,sal_add_time
		,sal_sku_id
		,oi_no
		,sal_buyingteamid
		,gi_buyingteam
		,gi_supplierid
		,gi_supplier
		,gi_purchase
		,gi_purchase_money
		,gi_costprice_z
		,sa_remark
		,rulecode
		,sizecode
		,colorcode
	FROM v_z_pos_sale_detail where sa_id in (select Id from @orderids) and sa_status>0;
update pos_sale set sa_curing=1,sa_curingdate=getdate() where sa_id in (select Id from @orderids);

end



END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

