CREATE VIEW [dbo].[v_z_distributionordergroupby]
	AS

select 
(SELECT top 1 eo_id FROM v_z_erp_distribution_pda as pda WHERE pda.do_source_id=TT.do_source_id and pda.warehousingtype=tt.stocktype ) as eo_id,
(SELECT top 1 eo_no FROM v_z_erp_distribution_pda as pda WHERE pda.do_source_id=TT.do_source_id and pda.warehousingtype=tt.stocktype ) as eo_no,
(SELECT top 1 eo_entrydate FROM v_z_erp_distribution_pda as pda WHERE pda.do_source_id=TT.do_source_id and pda.warehousingtype=tt.stocktype ) as eo_entrydate,
TT.* 

from ( 

select 
(select (SELECT slt_no  FROM dbo.erp_storagelocation where slt_id=j.mo_locationid) as slt_no from j_orderblank j where mo_type=1 and mo_id=vz.do_source_id) as slt_no_out,
(SELECT pl_ci_id FROM j_purchaseStorage jps  WHERE jps.pl_status<>0 AND jps.pl_id=do_source_id ) AS ci_id,

(select sum(outinnum) from v_z_erp_distribution_pda as pda where pda.do_source_id=vz.do_source_id and  pda.warehousingtype=vz.stocktype )as outinnum,

vz.*,
vz.do_applyqty AS dol_applyqty,


vz.do_inspectionnum AS inspectionnum,


(vz.do_num-do_inspectionnum) AS differencenum
from
(

select
	edi.warehousingtype as stocktype,
	--0:入库　1:出库　3:盘点 4：移动移仓 5:POS出库
	(
case edi.warehousingtype
when 0 then (SELECT  top 1 pl_pltype FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
when 1 then 0
when 3 then (
case (SELECT  top 1 al_source FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
		when 4 then 0
		when 6 then 0
		else 1 
		end)
WHEN 5 THEN 0
when 8 then 0
when 27 then (
CASE (SELECT top 1 pa.mo_type FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id) WHEN 0 then 1 WHEN 1 THEN 4 ELSE 0 end
)
when 36 then 5
else
	edi.warehousingtype
end
) as warehousingtype,

(
   case edi.warehousingtype
   when 27 then (SELECT top 1 pa.mo_locationid FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id)
   else 0 end
) as locationid,


(case edi.warehousingtype 
when 0 then
			(case (SELECT  top 1 pl_pltype FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
			      when 0 then  '入库单'  else  '供应商退货'  end
			)
when 1 then '分公司退货'
when 3 then(case (SELECT  top 1 al_source FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
		    when 3 then '店铺退货单' 
		    when 4 then '客户退货单'
		    when 6 then '分公司退货'
            else '出库单' end
)
WHEN 5 THEN '移仓入库单'
when 8 then '店铺退货单'
when 27 THEN  CASE (SELECT top 1 pa.mo_type FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id) WHEN 0 then '移仓出库单' WHEN 1 THEN  '移仓单' ELSE '移仓出库单' end  
when 36 then '网络订单'--网络订单
else '盘点'
end
) as typename,

(
case edi.warehousingtype 
when 0 then (SELECT top 1 pl_vo FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id and jps.pl_status>0)
when 1 then (SELECT top 1 jps.eo_no FROM j_enterStorage jps WHERE jps.eo_id=edi.do_source_id and jps.eo_status>0)
when 3 then (SELECT top 1 al_vo FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id AND pa.al_status>0)
WHEN 5 then (SELECT top 1 mo_vo FROM j_moStorage AS jms  WHERE jms.mo_source_type=1 AND jms.mo_id=edi.do_source_id and jms.mo_status>0 )
when 8 then (SELECT top 1 pa.in_vo FROM pos_inStorage pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT top 1 pa.mo_vo FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id )
when 36 then (SELECT top 1 ord_no FROM netorder_tbl WHERE ord_id=edi.do_source_id)--网络订单
end
) as do_no,

(
case edi.warehousingtype 
when 0 then (SELECT top 1 pl_remark FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id and jps.pl_status>0)
when 1 then (SELECT top 1 jps.eo_remark FROM j_enterStorage jps WHERE jps.eo_id=edi.do_source_id and jps.eo_status>0)
when 3 then (SELECT top 1 al_remark FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id AND pa.al_status>0)
WHEN 5 then (SELECT top 1 mo_remark FROM j_moStorage AS jms  WHERE jms.mo_source_type=1 AND jms.mo_id=edi.do_source_id and jms.mo_status>0 )
when 8 then (SELECT top 1 pa.in_remark FROM pos_inStorage pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT top 1 pa.mo_remark FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id )
when 36 then ''--网络订单
end
) as remark,--备注

(
case edi.warehousingtype 
when 0 then (SELECT top 1 pl_num FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id and jps.pl_status>0)
when 1 then (SELECT top 1 jps.eo_num FROM j_enterStorage jps WHERE jps.eo_id=edi.do_source_id and jps.eo_status>0)
when 3 then (SELECT SUM(pal.all_num) FROM pos_allocation pa INNER JOIN pos_allocationList AS pal ON pa.al_id=pal.all_al_id AND pal.all_status>0 WHERE pa.al_id=edi.do_source_id AND pa.al_status>0)
WHEN 5 then (SELECT top 1 mo_num FROM j_moStorage AS jms  WHERE jms.mo_source_type=1 AND jms.mo_id=edi.do_source_id and jms.mo_status>0 )
when 8 then (SELECT SUM(pisl.inl_num) FROM pos_inStorage pa INNER JOIN pos_inStorageList AS pisl ON pa.in_id=pisl.inl_in_id AND pisl.inl_status>0
WHERE pa.in_id=edi.do_source_id AND pa.in_status>0 )
when 27 then (SELECT top 1 pa.mo_num FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id )
when 36 then (SELECT top 1 ord_number FROM netorder_tbl WHERE ord_id=edi.do_source_id)--网络订单
end
) as do_num,

(
case edi.warehousingtype 
when 0 then (SELECT top 1 pl_date FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
when 1 then (SELECT top 1 jps.eo_entrydate FROM j_enterStorage jps WHERE jps.eo_id=edi.do_source_id)
when 3 then (SELECT top 1 al_date FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
WHEN 5 then (SELECT top 1 mo_date FROM j_moStorage AS jms  WHERE jms.mo_source_type=1 AND jms.mo_id=edi.do_source_id )
when 8 then (SELECT top 1 pa.in_date FROM pos_inStorage pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT top 1 pa.mo_date FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id )
when 36 then (SELECT top 1 ord_paydate FROM netorder_tbl WHERE ord_id=edi.do_source_id)--网络订单
end
)  AS do_date,
(case edi.warehousingtype when 36 then (SELECT sei_name FROM pos_storageinfo WHERE sei_id=edi.sei_id) else bsi.sei_name end)sei_name,
(case edi.warehousingtype when 36 then (SELECT sei_code FROM pos_storageinfo WHERE sei_id=edi.sei_id) else bsi.sei_code end)sei_code,

--对象名称（单位）
(case edi.warehousingtype 
when 0 then (SELECT top 1 pl_ci_id_txt FROM v_z_purchaseStorage_detail jps WHERE jps.pl_id=edi.do_source_id)
when 1 THEN (SELECT top 1 (SELECT cp_name FROM companyinfo c WHERE c.cp_id=jps.eo_cp_id) FROM v_z_enterStorage jps WHERE jps.eo_id=edi.do_source_id)
when 3 then (SELECT top 1 subname FROM v_z_allocation_detail pa WHERE pa.al_id=edi.do_source_id)
WHEN 5 then (SELECT top 1 mo_out_st_id_txt FROM v_z_moStorage_detail AS jms  WHERE  jms.mo_id=edi.do_source_id )
when 8 then (SELECT top 1 pa.sh_name FROM v_z_pos_inStorage_detail pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT sei_name FROM b_storageinfo WHERE sei_id=(SELECT top 1 pa.mo_in_st_id FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id))
when 36 then (SELECT top 1 ord_b_linkman FROM netorder_tbl WHERE ord_id=edi.do_source_id)--网络订单
end
) as subname,

edi.sei_id,
edi.do_source_id,
edi.do_status,
edi.do_addtime,
edi.cp_id,
edi.sh_id,
edi.do_applyqty,
edi.do_inspectionnum,
edi.erp_id,
(SELECT si_name FROM b_stafftinfo bs WHERE bs.si_id=do_man) as do_man


FROM (
SELECT 
warehousingtype,
do_source_id,
sei_id,
min(do_man) as do_man,
erp_id,cp_id,sh_id,do_status,
MAX(do_addtime) AS do_addtime,
MAX(do_updatetime) AS do_updatetime,
SUM(do_inspectionnum) AS do_inspectionnum,
SUM(do_applyqty) AS do_applyqty
FROM erp_distributionorder
WHERE do_status=1 
GROUP BY warehousingtype,do_source_id,sei_id,erp_id,do_status,cp_id,sh_id
) AS edi
left join b_storageinfo as bsi on bsi.sei_id=edi.sei_id
where edi.do_status>0

) as vz

) as TT
go

