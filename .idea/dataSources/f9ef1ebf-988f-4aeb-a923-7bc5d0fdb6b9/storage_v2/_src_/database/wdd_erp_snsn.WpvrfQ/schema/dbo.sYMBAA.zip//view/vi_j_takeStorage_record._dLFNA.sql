
CREATE VIEW [dbo].[vi_j_takeStorage_record] AS 
select 
fd.tsl_st_id,fd.tsl_erp_id,tsl_cp_id,
max(fd.tsl_date) as tsl_date from j_takeStorageLog as fd
where fd.tsl_status>0 
group by fd.tsl_st_id,fd.tsl_erp_id,tsl_cp_id
go

