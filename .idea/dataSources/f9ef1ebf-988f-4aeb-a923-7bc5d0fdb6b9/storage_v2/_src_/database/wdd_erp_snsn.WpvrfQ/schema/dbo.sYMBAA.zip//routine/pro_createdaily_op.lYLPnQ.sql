CREATE PROCEDURE [dbo].[pro_createdaily_op]

@year int=0,
@month int=0,
@day int=0,
@erp_id int=0,
@company_id int=0,
@add_man int=0,
--操作类型(1:添加 2:删除)
@op_type varchar(100)='',
@outResult varchar(100)='' Output
AS
BEGIN

declare @bool_first int=0;
declare @date_str varchar(50)=CONVERT(varchar(50),@year)+'-'+CONVERT(varchar(50),@month)+'-'+CONVERT(varchar(50),@day);




if @op_type='添加'
begin
    if(( @day>datepart(day,GETDATE()) and @month>datepart(month,GETDATE()) and  @year=datepart(year,GETDATE())) or @year>datepart(year,GETDATE()))
    begin
          set @outResult='选择的日份还没到，不能生成日报！'
		  select INFO=@outResult;
		  return;
    end
    --判断这个月是否生成
	if exists(select * from j_month_report as  fd where fd.reporttype=1 and fd.m_year=@year
	and fd.m_month=@month AND fd.erp_id=@erp_id and fd.company_id=@company_id and fd.m_day=@day )
	begin
		--生成
		--结束，返回提示信息
		set @outResult='日报已生成！'
		select INFO=@outResult;
		return;
	end

	DECLARE @isgt INT=0;
	declare @prev_year int=datepart(year,DATEADD(day,-1,convert(datetime,@date_str)));
	declare @prev_month int=datepart(month,DATEADD(day,-1,convert(datetime,@date_str)));
	declare @prev_day int=datepart(day,DATEADD(day,-1,convert(datetime,@date_str)));

create table #p3 --创建临时表#Tmp
(
    datee   varchar(50)  null, 
    SID     int          null,   
    gid     int          null,
	end_num int          null,
	end_money decimal(38,2) null
);



--判断上前天是否生成
 if exists(select * from j_month_report as  fd where fd.reporttype=1 and fd.m_year=@prev_year and fd.m_month=@prev_month and fd.company_id=@company_id and fd.m_day=@prev_day)
BEGIN

insert #p3

SELECT @date_str,SID,gid,end_num,end_money  FROM (

SELECT SID,gid,SUM(end_num) AS end_num,SUM(end_money) AS end_money FROM (

--前月的报表的期未数据	
select SID,gid,end_num,(fd.end_num*fd.price) AS end_money  from j_month_report as  fd where fd.reporttype=1 and fd.m_year=@prev_year
and fd.m_month=@prev_month and  fd.m_day=@prev_day and fd.company_id=@company_id and fd.erp_id=@erp_id

UNION ALL

SELECT SID,gid,0,0 FROM vi_stockList_createmonthly where 
DATEPART(YEAR,order_date)=@year and 
DATEPART(MONTH,order_date)=@month and
DATEPART(day,order_date)=@day and sei_cp_id=@company_id and sei_erp_id=@erp_id and myremark<>'期初'

) as TT GROUP BY gid, SID

) AS month_report

end
else
BEGIN


SET @isgt=1;

insert #p3

SELECT @date_str,SID,gid,end_num,(end_num*(
case isnull((SELECT s_value FROM s_system_set AS sss WHERE sss.s_key='wmamwma' AND s_erp_id=@erp_id),0)
     when 0 then bg.gi_costprice   --成本价
	 when 1 then bg.gi_importprices --销售价
	 when 2 then bg.gi_purchase    --进货价
     else bg.gi_costprice
end
))  end_money  FROM (


--截止上个月的数据
SELECT  SID, gid, SUM(gnum) AS end_num FROM(

SELECT SID, gid ,gnum  FROM vi_stockList_createmonthly WHERE  order_date<@date_str and sei_erp_id=@erp_id and sei_cp_id=@company_id 
AND mytype!=3

UNION ALL

SELECT SID, gid ,gnum FROM vi_stockList_createmonthly vsl WHERE vsl.mytype=3 and sei_erp_id=@erp_id and sei_cp_id=@company_id 

UNION ALL

--今天销售过新商品期初
SELECT SID, gid,0 FROM vi_stockList_createmonthly where 
DATEPART(YEAR,order_date)=@year and DATEPART(MONTH,order_date)=@month 
and DATEPART(day,order_date)=@day 
and sei_cp_id=@company_id and sei_erp_id=@erp_id and myremark<>'期初'

) AS createmonthly GROUP BY gid, SID

) AS month_report
INNER JOIN b_goodsinfo bg ON bg.gi_id=gid

end

		--统计当月数据
		select 
		fd.gid,
		fd.sid,
		isnull(SUM(case when fd.myremark='入库' then fd.gnum else 0 end),0) as en_num,
		isnull(SUM(case when fd.myremark='入库' then fd.allmoney else 0 end),0) as en_money,
		isnull(SUM(case when fd.myremark='入库退货' then fd.gnum else 0 end),0) as enth_num,
		isnull(SUM(case when fd.myremark='入库退货' then fd.allmoney else 0 end),0) as enth_money,
		isnull(SUM(case when fd.myremark='出库' then fd.gnum else 0 end),0) as oo_num,
	    isnull(SUM(case when fd.myremark='出库' then fd.allmoney else 0 end),0) as oo_money,
		isnull(SUM(case when fd.myremark='出库退货' then fd.gnum else 0 end),0) as ooth_num,
		isnull(SUM(case when fd.myremark='出库退货' then fd.allmoney else 0 end),0) as ooth_money,
		isnull(SUM(case when fd.myremark LIKE '%盘点盈亏调整' then fd.gnum else 0 end),0) as ts_num,
	    isnull(SUM(case when fd.myremark LIKE '%盘点盈亏调整' then fd.allmoney else 0 end),0) as ts_money,
		isnull(SUM(case when fd.myremark='移出仓库' then fd.gnum else 0 end),0) as mo_num,
		isnull(SUM(case when fd.myremark='移出仓库' then fd.allmoney else 0 end),0) as mo_money,
		isnull(SUM(case when fd.myremark='移入仓库' then fd.gnum else 0 end),0) as mi_num,
		isnull(SUM(case when fd.myremark='移入仓库' then fd.allmoney else 0 end),0) as mi_money,
		isnull(SUM(case when fd.myremark='盈亏' then fd.gnum else 0 end),0) as yk_num,--盈亏
		isnull(SUM(case when fd.myremark='盈亏' then fd.allmoney else 0 end),0) as yk_money--盈亏
		into #p4
		from vi_stockList_createmonthly as fd where 
		fd.gid>0 and fd.sid>0 AND fd.sei_cp_id=@company_id and sei_erp_id=@erp_id 
		and DATEPART(YEAR,fd.order_date)=@year 
		and DATEPART(MONTH,fd.order_date)=@month
		and DATEPART(day,fd.order_date)=@day
		group by fd.gid, fd.sid

		alter table #p4 add price decimal(18,2);
		alter table #p4 add end_money decimal(18,2);
		alter table #p4 add end_num int;
		alter table #p4 add m_year int;
		alter table #p4 add m_month int;
		alter table #p4 add m_day int;



		select
		#p3.gid,
		#p3.sid, 
		#p3.end_money as start_money,
		#p3.end_num as start_num,
		#p4.m_year,
		#p4.m_month,
		#p4.m_day,
		isnull(#p4.en_num,0)as en_num,
		isnull(#p4.en_money,0) as en_money,
		isnull(#p4.enth_num,0) as enth_num,
		isnull(#p4.enth_money,0) as enth_money,
		isnull(#p4.oo_num,0) as oo_num,
	    isnull(#p4.oo_money,0) as oo_money,
		isnull(#p4.ooth_num,0) as ooth_num,
		isnull(#p4.ooth_money,0) as ooth_money,
		isnull(#p4.ts_num,0) as ts_num,
	    isnull(#p4.ts_money,0) as ts_money,
		isnull(#p4.mo_num,0) as mo_num,
		isnull(#p4.mo_money,0) as mo_money,
		isnull(#p4.mi_num,0) as mi_num,
		isnull(#p4.mi_money,0) as mi_money,
		isnull(#p4.yk_num,0) as yk_num,
		isnull(#p4.yk_money,0) as yk_money,
		isnull(#p4.price,0) as price,
		isnull(#p4.end_money,0) as end_money,
		isnull(#p4.end_num,0) as end_num
		into #p1
		from #p3 
		left join #p4 on #p3.gid=#p4.gid and #p3.sid=#p4.sid

		
		
		--按公式算出单价
	-- IF @isgt=0
	--  BEGIN
	--  	update #p1 set start_money=#p2.end_money,start_num=#p2.end_num from #p1,#p2
	--	where #p1.gid=#p2.gid and #p1.sid=#p2.sid
	--  END
	--ELSE
	--BEGIN
	--update #p1 set start_money=#p3.end_money,start_num=#p3.end_num from #p1,#p3
	--	where #p1.gid=#p3.gid and #p1.sid=#p3.sid
	--END
		
    --移动加权平均法
    update #p1 set price=abs(fd.price1) from #p1 ,
	(

	select ((#p1.start_money+#p1.en_money+#p1.enth_money)/case when (#p1.start_num+#p1.en_num+#p1.enth_num)=0 then 1 else (#p1.start_num+#p1.en_num+#p1.enth_num) end)as price1,gid,sid  from  #p1
	
	)as fd where #p1.gid=fd.gid and #p1.sid=fd.sid


	update #p1 set start_money=0,start_num=0 where start_money is null and start_num is null
		

	--更新期末数了，金额
	update #p1 
	set 
	end_money=(start_money+enth_money+en_money+ooth_money+oo_money+yk_money+ ts_money+mo_money+mi_money),
	end_num=(start_num+en_num + enth_num+oo_num + ooth_num+ yk_num+ts_num+mo_num+mi_num)


	update #p1 set m_year=@year,m_month=@month,m_day=@day
		
insert into j_month_report(
 m_year, m_month,m_day,gid, [sid] ,en_num, en_money, enth_num, enth_money, oo_num, oo_money, ooth_num,ooth_money, ts_num,ts_money, mo_num, mo_money,mi_num,mi_money, yk_num, yk_money, price, start_money, start_num, end_money, end_num,erp_id,company_id,reporttype,add_man,add_time
) 
select 
m_year, m_month,@day, gid, sid, en_num, en_money, enth_num, enth_money, oo_num, oo_money, ooth_num, ooth_money, ts_num, ts_money, mo_num, mo_money, mi_num, mi_money, yk_num, yk_money, price,
start_money, start_num, end_money, end_num, @erp_id, @company_id,1,@add_man,GETDATE()
from #p1
		

		if @outResult!=''
		begin
				select INFO=@outResult;
		end
		else
		begin
				IF EXISTS(SELECT * FROM #p1)
				BEGIN
					select * from #p1
				END
				ELSE
				BEGIN
					select INFO='所选月份没有数据!';
				END
		end
end
else if @op_type='删除'
begin
    declare @next_year int=datepart(year,DATEADD(day,1,convert(datetime,@date_str)));
	declare @next_month int=datepart(month,DATEADD(day,1,convert(datetime,@date_str)));
	declare @next_day int=datepart(day,DATEADD(day,1,convert(datetime,@date_str)));
	if exists(select * from j_month_report where reporttype=1 and m_month=@next_month and m_year=@next_year and m_day=@next_day AND company_id=@company_id)
		begin
			--存在昨天的报表，不能删除
			set @outResult='昨天的日报已生成，无法删除！'
			select INFO=@outResult;
			return;	
	   end
    else
    begin
        delete j_month_report where reporttype=1 and m_month=@month and m_year=@year and m_day=@day AND company_id=@company_id
        set @outResult='删除成功！'
			select INFO=@outResult;
			return;	
    end
end


END
go

