CREATE VIEW [dbo].[vi_purchase_entered]
	AS 

--采购入库
SELECT 
       jes.eo_id,
       jesl.el_source_id,
       jesl.el_pm,
	(
        CASE jes.eo_type
            WHEN 1 THEN -jesl.el_box_num
            WHEN 0 THEN jesl.el_box_num
            ELSE 0
        END
    )el_box_num,
    (
        CASE jes.eo_type
            WHEN 1 THEN -jesl.el_number
            WHEN 0 THEN jesl.el_number
            ELSE 0
        END
    )en_number
FROM   j_enterStorage AS jes
    INNER JOIN j_enterStorageList 
    AS jesl
        ON  
        jes.eo_id = jesl.el_eoid
WHERE  jes.eo_status > 0
    AND jesl.el_status = 1
    AND jes.eo_source_type = 1
go

