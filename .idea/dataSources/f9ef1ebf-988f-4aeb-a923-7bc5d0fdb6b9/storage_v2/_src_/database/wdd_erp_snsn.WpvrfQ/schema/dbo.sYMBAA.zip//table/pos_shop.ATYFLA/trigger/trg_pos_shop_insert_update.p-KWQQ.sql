CREATE TRIGGER [dbo].[trg_pos_shop_insert_update] ON dbo.pos_shop
       FOR INSERT,UPDATE
AS
BEGIN
      DECLARE @IsInsert INT= 0; --插入
      DECLARE @IsUpdate INT= 0; --更新
      DECLARE @IsDelete INT= 0; --删除
 
      IF EXISTS ( SELECT    1
                  FROM      inserted )
         AND NOT EXISTS ( SELECT    1
                          FROM      deleted )
         SET @IsInsert = 1
      ELSE
         IF EXISTS ( SELECT 1
                     FROM   inserted )
            AND EXISTS ( SELECT 1
                         FROM   deleted )
            SET @IsUpdate = 1
         ELSE
            IF NOT EXISTS ( SELECT  1
                            FROM    inserted )
               AND EXISTS ( SELECT  1
                            FROM    deleted )
               SET @IsDelete = 1

      DECLARE @sh_id INT= 0;
      DECLARE @sh_company INT= 0;
      DECLARE @qcje DECIMAL(15,2)= 0;
      DECLARE @oldqcje DECIMAL(15,2)= 0;

      SELECT    @sh_id = sh_id ,
                @qcje = sh_qcje ,
                @sh_company = sh_company
      FROM      INSERTED;

      SELECT    @oldqcje = sh_qcje
      FROM      DELETED;

      DECLARE @cp_name VARCHAR(100)= '';
      DECLARE @cp_code VARCHAR(50)= '';

      SELECT    @cp_name = cp_name ,
                @cp_code = cp_code
      FROM      companyinfo
      WHERE     cp_id = @sh_company;

             --IF NOT EXISTS ( SELECT *
             --                FROM   pos_supplierinfo
             --                WHERE  si_sh_id = @sh_id
             --                       AND si_code = @cp_code )
             --   BEGIN
             --         INSERT    INTO pos_supplierinfo
             --                   ( si_name ,
             --                     si_code ,
             --                     si_status ,
             --                     si_isdel ,
             --                     si_sh_id
             --                   )
             --                   SELECT  @cp_name AS si_name ,
             --                           @cp_code AS si_code ,
             --                           1 AS si_status ,
             --                           1 AS si_isdel ,
             --                           @sh_id AS si_sh_id
             --   END
			  --计算期初金额
      IF @oldqcje <> @qcje or @oldqcje=0
         EXEC pro_update_c_fundorder_QcQm @type = 0 ,  @shid = @sh_id ,  @id = NULL
END
go

