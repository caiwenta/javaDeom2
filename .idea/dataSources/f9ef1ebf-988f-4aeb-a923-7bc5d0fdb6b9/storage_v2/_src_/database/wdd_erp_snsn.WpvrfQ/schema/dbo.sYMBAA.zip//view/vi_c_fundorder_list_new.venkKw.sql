CREATE VIEW [dbo].[vi_c_fundorder_list_new]
AS
       SELECT   cf.qm_integral ,
                cf.qm ,
                cf.qm_user_integral ,
                cf.Count ,
                cf.qc ,
                cf.qc_integral ,
                cf.fo_id ,
                cf.fo_erp_id ,
                cf.fo_type ,
                cf.fo_ciid ,
                cf.fo_bs ,
                cf.fo_orderid ,
                cf.fo_takeman ,
                cf.fo_ticketno ,
                cf.fo_realmoney ,
                cf.fo_thiyetmoney ,
                cf.fo_ofdate ,
                cf.fo_remark ,
                cf.fo_lastman ,
                cf.fo_status ,
                cf.fo_outmoney ,
                cf.fo_admoney ,
                cf.fo_otheronmoney ,
                cf.fo_otheoutmoney ,
                cf.fo_givemoney ,
                cf.fo_ensuremoney ,
                cf.fo_subscription ,
                cf.fo_no ,
                cf.fo_addtime ,
                cf.fo_updatetime ,
                cf.fo_rowNum ,
                cf.ciname ,
                cf.qcje ,
                cf.fo_userorderno ,
                cf.cicode ,
                cf.fo_cp_id ,
                cf.shname ,
                cf.cpname ,
                cf.fo_realmoney_integral ,
                cf.fo_thiyetmoney_integral ,
                cf.fo_outmoney_integral ,
                cf.fo_otheronmoney_integral ,
                cf.fo_otheoutmoney_integral ,
                cf.fo_givemoney_integral ,
                cf.fun_status ,
                cf.integral_status ,
                cf.fo_shid ,
                cf.fo_to_cpid,
				(SELECT si_name FROM dbo.b_stafftinfo AS bs  WITH (NOLOCK) WHERE (si_id = jes.eo_addman)) AS eo_addman_txt --入库制单人
                 ,oo_addman_txt,  --出库制单人
				 fo_custom_remark, --自定义备注
				 jis.oo_remark,--出库备注
				 jes.eo_remark,--入库备注
				 fo_addman,--应收应付制单人
				 fo_addman_id --应收应付制单人id
				 ,(case when fo_outmoney >0 then -fo_finished_money else fo_finished_money end)fo_finished_money
				 ,(case when fo_outmoney >0 then -fo_parts_money else fo_parts_money end)fo_parts_money
				 ,fo_queue_status
       FROM     c_fundorder cf
	   LEFT JOIN j_outStorage AS jis WITH ( NOLOCK ) ON jis.oo_id =cf.fo_order_id and jis.oo_status>0
       LEFT JOIN j_enterStorage AS jes WITH ( NOLOCK ) ON jes.eo_id =cf.fo_order_id and jes.eo_status>0
       WHERE    cf.fo_status = 2
go

