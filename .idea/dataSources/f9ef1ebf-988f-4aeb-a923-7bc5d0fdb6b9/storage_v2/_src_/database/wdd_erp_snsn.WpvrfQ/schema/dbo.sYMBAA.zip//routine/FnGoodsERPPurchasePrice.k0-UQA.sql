CREATE FUNCTION [dbo].[FnGoodsERPPurchasePrice]
(
	@gi_id int=0,
	@gi_skuid INT,
	@ci_id INT,--0:客户
	@sh_id INT, --店铺
	@to_cp_id INT, --公司
	@type int
)

--获取商品的供货价
RETURNS @returntable TABLE
(
    gi_id int,
	gi_skuid int,
	supplyprice DECIMAL(9, 2),
	discount  DECIMAL(9, 2),
	gs_marketprice DECIMAL(9, 2),--零售价
	gs_discount DECIMAL(9, 2),
	gs_purchase DECIMAL(9, 2)    --供货价
)
AS
BEGIN
   --pro_setGoodsPurchasePrice
	INSERT @returntable
	SELECT
	gi_id,
	sku_id,
	0.00 AS supplyprice,
	0.00 AS discount,
	retailprice,
	gs_discount=cast((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE importprices / retailprice END) as decimal(18,2)),
	importprices
	FROM (
		SELECT
		bg.gi_id as gi_id, 
		isnull(bs.gss_id,0) sku_id, 
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE bs.gs_marketprice END) AS retailprice,
		(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE bs.gs_salesprice END) AS importprices
		FROM  b_goodsinfo AS  bg
		LEFT JOIN b_goodsruleset AS bs ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		AND bs.gss_id=(CASE WHEN @gi_skuid > 0 THEN  @gi_skuid  ELSE bs.gss_id END)
		WHERE  gi_status<>0 and isnull(gi_disable,0)=0 and bg.gi_id=@gi_id
		
	) AS TT


DECLARE @ghj_type INT = 0;
DECLARE @discount  DECIMAL(9, 2) = 1;

IF @ci_id > 0 AND @type > 0
BEGIN

    IF @type = 1
	BEGIN

		SELECT @ghj_type = ci_dhprice,@discount=ci_dhdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_dhprice > 0;

	END	          
	ELSE 
	IF @type = 2
	BEGIN

		SELECT @ghj_type = ci_bhprice,@discount=ci_bhdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_bhprice > 0;

	END	
	ELSE 
	IF @type = 3
	BEGIN

		SELECT @ghj_type = ci_phprice,@discount=ci_phdiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_phprice > 0;

	END	 
	ELSE 
	IF @type = 4
	BEGIN

		SELECT @ghj_type = ci_mdprice,@discount=ci_mddiscount FROM b_clientinfo WHERE ci_id = @ci_id AND ci_mdprice > 0;

	END
    
	
END
ELSE 
IF @sh_id > 0 AND @type > 0
BEGIN
    --有选择店铺,并且有设置交易方式
     IF @type = 1
	BEGIN

		SELECT @ghj_type = sh_dhprice,@discount= sh_dhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_dhprice>0;

	END         
	ELSE 
	IF @type = 2
	BEGIN

		SELECT @ghj_type = sh_bhprice,@discount= sh_bhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_bhprice>0;

	END 
	ELSE 
	IF @type = 3
	BEGIN
	
		SELECT @ghj_type = sh_phprice,@discount= sh_phdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_phprice>0;
		               
	END	           
	ELSE 
	IF @type = 4
	BEGIN

		SELECT @ghj_type = sh_mdprice,@discount= sh_mddiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_mdprice>0;

	END	
    

END
ELSE 
IF @to_cp_id > 0 AND @type > 0
BEGIN

    --有选择店铺,并且有设置交易方式
     IF @type = 1
	BEGIN
	
		SELECT @ghj_type = cp_dhprice,@discount=cp_dhdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_dhprice > 0;

	END	          
	ELSE 
	IF @type = 2
	BEGIN
		
		SELECT @ghj_type = cp_bhprice,@discount=cp_bhdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_bhprice > 0;

	END	
	ELSE 
	IF @type = 3
	BEGIN
		
		SELECT @ghj_type = cp_phprice,@discount=cp_phdiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_phprice > 0;

	END	 
	ELSE 
	IF @type = 4
	BEGIN
		
		SELECT @ghj_type = cp_mdprice,@discount=cp_mddiscount FROM  companyinfo WHERE  cp_id = @to_cp_id AND cp_mdprice > 0;

	END
   
END


if @ghj_type>0
BEGIN

		--供货价
		DECLARE @ghj DECIMAL(9, 2) = 0;

		(SELECT @ghj=isnull(gd_price,0) FROM b_goods_discount WHERE gd_gi_id = @gi_id AND gd_class = 2 AND gd_type = @ghj_type);

		IF @ghj>0.00
		BEGIN

			UPDATE @returntable set supplyprice=@ghj

			UPDATE @returntable set discount=@discount;

			UPDATE @returntable set gs_purchase=(case when supplyprice<>0.00 then supplyprice*discount else gs_purchase end);

			UPDATE @returntable SET gs_discount =(CASE WHEN gs_marketprice = 0.00 THEN 0.00 ELSE gs_purchase / gs_marketprice END);
		
		END
END

	
	RETURN
END
go

