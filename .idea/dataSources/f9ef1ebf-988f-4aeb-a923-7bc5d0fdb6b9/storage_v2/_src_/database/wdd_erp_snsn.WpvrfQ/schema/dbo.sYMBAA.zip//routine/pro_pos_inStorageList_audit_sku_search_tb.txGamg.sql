CREATE PROC [dbo].[pro_pos_inStorageList_audit_sku_search_tb]
@inl_in_id INT = 0,
@inl_add_time DATETIME = '2004-10-17',
@gi_id INT,
@sh_id INT = 0
AS
BEGIN
 SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p
 FROM   b_goodsruleset AS bg 
        LEFT JOIN (
                 SELECT *
                 FROM   vi_pos_inStorageList_audit AS jisl
                 WHERE  jisl.inl_in_id = @inl_in_id
                        AND jisl.inl_add_time = @inl_add_time
                        AND jisl.inl_gi_id = @gi_id
             ) AS p1
             ON  bg.gi_id = p1.inl_gi_id
             AND bg.gss_id = p1.inl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
 WHERE  bg.gi_id = @gi_id;
 
 SELECT *
 FROM   #p
END
go

