CREATE VIEW [dbo].[vi_payoutlist] AS 
SELECT 
pt.*, 
add_man=CASE WHEN pt.add_man_id=0 THEN '网络订单' 
ELSE
(SELECT si_name FROM b_stafftinfo WHERE si_id=pt.add_man_id)
END

FROM(

---销售金额-消费代金券-刷卡金额-商城金额-积分抵扣额-退货金额

SELECT 
0 AS po_id,
-1 AS p_type, 
'销售' as p_typetxt,
'凭证号：'+ps.sa_vo as p_remark,
fd.sal_num AS num,
ps.sa_cashmoney-ps.sa_surplus_money AS  p_money,
ps.sa_date AS order_time,
ps.sa_add_time AS add_time,
satype=2,
ps.sa_sh_id AS sh_id,
ps.sa_add_man AS add_man_id
FROM
(
SELECT
ps.sal_sa_id, 
sum(
	case when ps.sal_is_change=1 or ps.sal_is_return=1then 
		-abs(ps.sal_num) 
	else
		ps.sal_num 
	end
)as sal_num,
sum(
	case when ps.sal_is_gift=0 and ps.sal_is_change=0 and ps.sal_is_in=0 and ps.sal_is_return=0 then 
		(ps.sal_num*ps.sal_real_price)-ps.sal_deduct_money
	else 
		0 
	end
	)as sal_money,
sum(
	case when ps.sal_is_return=1 or ps.sal_is_change=1 then 
		(ps.sal_real_price*abs(ps.sal_num))-sal_deduct_money 
	ELSE
		 0 
	end)as sal_change_money 
from pos_saleList as ps where ps.sal_status=1 
group by ps.sal_sa_id
) fd
INNER JOIN pos_sale ps ON fd.sal_sa_id=ps.sa_id AND ps.sa_status<>0 AND (not EXISTS(SELECT * FROM pos_sale_net psn WHERE psn.sa_net_sa_id=ps.sa_id))


UNION ALL
--网络订单
SELECT 
0 AS po_id,
-1 AS p_type, 
'销售' as p_typetxt,
'凭证号：'+ps.sa_vo as p_remark,
fd.sal_num AS num,
(fd.sal_money-ps.sa_in_money-ps.sa_sa_vo-fd.sal_change_money-ps.sa_card_money) AS  p_money,
ps.sa_date AS order_time,
ps.sa_add_time AS add_time,
satype=2,
ps.sa_sh_id AS sh_id,
ps.sa_add_man AS add_man_id
FROM
(
SELECT
ps.sal_sa_id, 
sum(
	case when ps.sal_is_change=1 or ps.sal_is_return=1then 
		-abs(ps.sal_num) 
	else
		ps.sal_num 
	end
)as sal_num,
sum(
	case when ps.sal_is_gift=0 and ps.sal_is_change=0 and ps.sal_is_in=0 and ps.sal_is_return=0 then 
		(ps.sal_num*ps.sal_real_price)-ps.sal_deduct_money
	else 
		0 
	end
	)as sal_money,
sum(
	case when ps.sal_is_return=1 or ps.sal_is_change=1 then 
		(ps.sal_real_price*abs(ps.sal_num))-sal_deduct_money 
	ELSE
		 0 
	end)as sal_change_money 
from pos_saleList as ps where ps.sal_status=1 
group by ps.sal_sa_id
) fd
INNER JOIN pos_sale ps ON fd.sal_sa_id=ps.sa_id AND ps.sa_status<>0 AND (EXISTS(SELECT * FROM pos_sale_net psn WHERE psn.sa_net_sa_id=ps.sa_id)) AND ps.sa_paytype='现金支付'



UNION ALL

SELECT
pp.po_id AS po_id,
p_type,
p_typetxt=
CASE WHEN p_type=0 THEN '现金支出'
WHEN  p_type=1 THEN '现金收入'
WHEN  p_type=2 THEN '老板提现'
ELSE '其它' end,
(CASE WHEN p_remark='' THEN (SELECT gs_name FROM dbo.s_goodstype WHERE gs_id=p_class AND gs_typeid=6) ELSE p_remark END)
AS p_remark,
NULL AS num,
CASE WHEN pp.p_counttype=1 THEN  pp.p_money ELSE - pp.p_money END AS p_money,
pp.p_add_time AS order_time,
pp.p_sort_time AS add_time,
satype=1,
pp.p_sh_id AS sh_id,
pp.p_add_man AS add_man_id
FROM pos_payout AS pp  WITH (NOLOCK)  WHERE pp.p_status<>0


) AS pt
go

