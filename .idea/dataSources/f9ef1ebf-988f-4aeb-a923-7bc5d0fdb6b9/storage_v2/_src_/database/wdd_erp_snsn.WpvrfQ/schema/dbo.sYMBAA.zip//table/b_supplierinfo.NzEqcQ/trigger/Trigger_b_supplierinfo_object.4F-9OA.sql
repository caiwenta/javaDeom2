CREATE TRIGGER [dbo].[Trigger_b_supplierinfo_object] ON [dbo].[b_supplierinfo]
    FOR DELETE, INSERT, UPDATE
    AS
BEGIN

    DECLARE @maxID int,  
			@inserted INT,
            @deleted INT, 
			@ChangeType NVARCHAR(20);
	SELECT  @inserted = COUNT(1) FROM Inserted;
    SELECT  @deleted = COUNT(1) FROM Deleted;

	--判断对表Table1的操作类型
	IF @inserted > 0 AND @deleted = 0
	BEGIN 
		SET @ChangeType = 'INSERT';
	END;
	ELSE IF @inserted > 0  AND @deleted > 0
	BEGIN 
		SET @ChangeType = 'UPDATE';
	END;
	ELSE IF @inserted = 0AND @deleted > 0
	BEGIN 
		SET @ChangeType = 'DELETE';
	END;

	IF @ChangeType = 'DELETE'
	BEGIN
		SELECT @maxID = si_id FROM Deleted;
	end
	else
	begin
	    SELECT  @maxID = si_id FROM Inserted;   
	end
	exec pro_objectlist_op @id=@maxID,@type=2;
 END
go

