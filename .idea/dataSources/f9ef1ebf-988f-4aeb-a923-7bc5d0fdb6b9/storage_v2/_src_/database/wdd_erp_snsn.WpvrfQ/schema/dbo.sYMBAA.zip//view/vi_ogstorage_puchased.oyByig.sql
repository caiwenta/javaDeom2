CREATE VIEW [dbo].[vi_ogstorage_puchased]
	AS 

--订单采购
SELECT 
    pl_id,
	pll_num,
	pll_pm,
	pll_box_num,
	pll_source_id
FROM  j_purchaseStorageList
	INNER JOIN j_purchaseStorage
		ON  pll_pl_id = pl_id
WHERE  pl_status > 0 AND pll_status > 0 
       AND pl_source = 1
go

