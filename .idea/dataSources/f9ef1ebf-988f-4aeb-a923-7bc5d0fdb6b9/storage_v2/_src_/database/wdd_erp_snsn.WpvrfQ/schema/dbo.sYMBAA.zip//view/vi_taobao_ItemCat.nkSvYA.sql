CREATE VIEW [dbo].[vi_taobao_ItemCat] AS 
select * from taobao_ItemCat as tic where tic.sys_oc_id is not null
go

