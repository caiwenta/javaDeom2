
CREATE TRIGGER [dbo].[Trigger_erp_distributionpdaing_after_delete_update_insert]
    ON [dbo].[erp_distributionpdaing]
    after DELETE, INSERT, UPDATE
    AS
    BEGIN
        UPDATE    erp_distributionpdaing
      SET       di_lastdate =GETDATE()
      FROM      erp_distributionpdaing es ,
                (SELECT di_id 
                 FROM   DELETED
                ) del
      WHERE     es.di_id = del.di_id;
    END
go

