Create View [dbo].[vi_b_goodsinfo]
As
Select rcount=(
	Select Count(1) From b_goodsruleset bg2 Where bg2.gi_id=bg.gi_id
),* From b_goodsinfo bg
go

