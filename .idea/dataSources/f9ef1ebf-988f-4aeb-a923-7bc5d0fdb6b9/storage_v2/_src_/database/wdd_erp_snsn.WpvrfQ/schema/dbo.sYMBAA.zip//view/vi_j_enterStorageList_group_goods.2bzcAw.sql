CREATE VIEW [dbo].[vi_j_enterStorageList_group_goods] AS 
SELECT
	jt.el_eoid,
	jt.el_siid,
	jt.el_number,
	jt.el_id,
	jt.el_realmoney,
	jt.el_unit,
	jt.el_costprice,
	jt.el_discount,
	jt.el_skuid,
	jt.el_pddate,
	jt.el_pdgddate,
	jt.el_expirationdate,
	jt.el_shelflife,
	jt.el_integral,
	jt.el_totalintegral,
	CONVERT (
		VARCHAR (100),
		jt.el_addtime,
		25
	) AS el_addtime,
	jt.el_pm,
	jt.el_box_num,
	jt.el_gift,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_cratebox,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_shelflife,
	bg.gi_category,
	bg.gi_costprice,
	
	(bg.gi_costprice*jt.el_number)gi_costprice_money,--成本金额
	
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_factoryprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bg.gi_type1,
	bg.gi_type2,
	bg.gi_type3,
	bg.gi_type4,
	(select top 1 gc_name from s_goodsclass where gc_id=bg.gi_type1) AS gi_typename1,
	(select top 1 gc_name from s_goodsclass where gc_id=bg.gi_type2) AS gi_typename2,
	(select top 1 gc_name from s_goodsclass where gc_id=bg.gi_type3) AS gi_typename3,
	(select top 1 gc_name from s_goodsclass where gc_id=bg.gi_type4) AS gi_typename4,
	bu.ut_name AS gi_unit,
	bu.ut_id AS gi_unit_id,
	(
		SELECT
			fd.pl_vo
		FROM
			j_purchaseStorage fd WITH (NOLOCK) 
		WHERE
			fd.pl_id = (
				SELECT
					MAX (fd.pll_pl_id)
				FROM
					j_purchaseStorageList fd WITH (NOLOCK) 
				WHERE
					fd.pll_add_time = jt.el_source_add_time
			)
	) AS pl_vo
FROM
	dbo.vi_j_enterStorageList AS jt
INNER JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON jt.el_siid = bg.gi_id  and gi_status=1
INNER JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
go

