CREATE VIEW [dbo].[vi_AfterSaleAdjustment]
	AS 
	

SELECT T.*,
       (ol_number*asal_old_costprice)old_realmoney, --原出库金额
       (ol_number*asal_new_costprice)new_realmoney  --现出库金额
FROM (
	SELECT easa.asa_id,         --主表id
		   easal.asal_asa_id,   --主表id
		   easal.asal_id,       --明细id
		   easa.asa_no,    --调价凭证号
		   CONVERT(varchar(100), easa.asa_date, 23)asa_date,  --调价日期
		   easa.asa_erp_id,
		   easa.asa_cp_id, 
		   easa.asa_addman,--添加人id
		   (SELECT si_name FROM b_stafftinfo AS bs WHERE bs.si_id=easa.asa_addman)asa_addman_txt, --添加人
		   easa.asa_addtime, --添加时间
	                         
		   easa.asa_oo_id, --被调价的出库单id
		   jos.oo_id, --出库单id
		   jos.oo_no, --出库凭证号
		   jos.oo_entrydate, --出库日期
		   jos.oo_ciid,    --客户
		   jos.oo_sh_id,   --店铺 
		   jos.oo_to_cp_id,--分公司
		   (CASE WHEN jos.oo_ciid>0 THEN (SELECT ci_code FROM b_clientinfo AS bc WHERE bc.ci_id=jos.oo_ciid)
				 WHEN jos.oo_sh_id>0 THEN (SELECT ps.sh_no FROM pos_shop AS ps WHERE ps.sh_id=jos.oo_sh_id)
				 WHEN jos.oo_to_cp_id>0 THEN (SELECT cp_code FROM companyinfo AS c WHERE c.cp_id=jos.oo_to_cp_id) END)objectCode,--对象代号     
		   (CASE WHEN jos.oo_ciid>0 THEN (SELECT ci_name FROM b_clientinfo AS bc WHERE bc.ci_id=jos.oo_ciid)
				 WHEN jos.oo_sh_id>0 THEN (SELECT sh_name FROM pos_shop AS ps WHERE ps.sh_id=jos.oo_sh_id)
				 WHEN jos.oo_to_cp_id>0 THEN (SELECT cp_name FROM companyinfo AS c WHERE c.cp_id=jos.oo_to_cp_id) END)objectName,--对象名称         
	                            
		   easal.asal_gi_id,--商品id 
		   bg.gi_id, 
		   bg.gi_name, 
		   bg.gi_code, 
		   bg.gi_barcode,
		   bg.gi_unit gi_unit_id, --单位id
		   (SELECT ut_name FROM b_unit AS bu WHERE bu.ut_id=bg.gi_unit)gi_unit,--单位
		   bg.gi_retailprice,--零售价
	        
		   (SELECT MAX(ol_unit) 
			FROM j_outStorageList AS josl 
			WHERE josl.ol_eoid=easa.asa_oo_id AND josl.ol_siid=easal.asal_gi_id)ol_unit,--出货单的零售价
		   (SELECT SUM(ol_number) 
			FROM j_outStorageList AS josl 
			WHERE josl.ol_eoid=easa.asa_oo_id AND josl.ol_siid=easal.asal_gi_id)ol_number,--数量 
		   easal.asal_old_discount, --原折扣
		   easal.asal_old_costprice,--原供货价 
		   easal.asal_new_discount, --现折扣
		   easal.asal_new_costprice --现供货价
	                                
	FROM erp_afterSaleAdjustment AS easa 
	LEFT JOIN erp_afterSaleAdjustmentList AS easal ON easa.asa_id=easal.asal_asa_id
	INNER JOIN b_goodsinfo AS bg ON easal.asal_gi_id=bg.gi_id
	INNER JOIN j_outStorage AS jos ON easa.asa_oo_id=jos.oo_id
)T
go

