
CREATE Proc [dbo].[pro_merge_taobao_orders]
@oc_id int,
@timestamp datetime,
@result int out
as
begin tran


update taobao_Trade
set [status] = case 
--没有创建支付宝交易
when [status]='TRADE_NO_CREATE_PAY' then 0
--等待买家付款
when [status]='WAIT_BUYER_PAY' then 0
--卖家部分发货
when [status]='SELLER_CONSIGNED_PART' then 4
--等待卖家发货,即:买家已付款
when [status]='WAIT_SELLER_SEND_GOODS' then 2
--等待买家确认收货,即:卖家已发货
when [status]='WAIT_BUYER_CONFIRM_GOODS' then 4
--买家已签收,货到付款专用
when [status]='TRADE_BUYER_SIGNED' then 6
--交易成功
when [status]='TRADE_FINISHED' then 8
--付款以后用户退款成功，交易自动关闭
when [status]='TRADE_CLOSED' then 5
--付款以前，卖家或买家主动关闭交易
when [status]='TRADE_CLOSED_BY_TAOBAO' then 10
--国际信用卡支付付款确认中
when [status]='PAY_PENDING' then 0
--0元购合约中
when [status]='WAIT_PRE_AUTH_CONFIRM' then 0
end where sys_oc_id=@oc_id and sys_timestamp=@timestamp;


update taobao_Order
set refund_status = case 
--买家已经申请退款，等待卖家同意
when refund_status='WAIT_SELLER_AGREE' then 1
--卖家已经同意退款，等待买家退货
when refund_status='WAIT_BUYER_RETURN_GOODS' then 2
--买家已经退货，等待卖家确认收货
when refund_status='WAIT_SELLER_CONFIRM_GOODS' then 3
--卖家拒绝退款
when refund_status='SELLER_REFUSE_BUYER' then 4
--退款关闭
when refund_status='CLOSED' then 5
--退款成功
when refund_status='SUCCESS' then 6 end,
[status]= case 
--没有创建支付宝交易
when [status]='TRADE_NO_CREATE_PAY' then 0
--等待买家付款
when [status]='WAIT_BUYER_PAY' then 0
--卖家部分发货
when [status]='SELLER_CONSIGNED_PART' then 4
--等待卖家发货,即:买家已付款
when [status]='WAIT_SELLER_SEND_GOODS' then 2
--等待买家确认收货,即:卖家已发货
when [status]='WAIT_BUYER_CONFIRM_GOODS' then 4
--买家已签收,货到付款专用
when [status]='TRADE_BUYER_SIGNED' then 6
--交易成功
when [status]='TRADE_FINISHED' then 8
--付款以后用户退款成功，交易自动关闭
when [status]='TRADE_CLOSED' then 5
--付款以前，卖家或买家主动关闭交易
when [status]='TRADE_CLOSED_BY_TAOBAO' then 10
--国际信用卡支付付款确认中
when [status]='PAY_PENDING' then 0
--0元购合约中
when [status]='WAIT_PRE_AUTH_CONFIRM' then 0
end
where sys_oc_id=@oc_id and sys_timestamp=@timestamp;



declare @now datetime=getdate();
--订单
merge into m_orderinfo as ta
using (select * from taobao_Trade as so where so.sys_timestamp=@timestamp and so.sys_oc_id=@oc_id) as so 
on ta.oi_tid=so.tid and ta.oi_oc_id=@oc_id
when matched then update set 
ta.oi_updatetime=@now,
ta.oi_taobao_id=so.taobao_id,
-------------------匹配
ta.oi_no=so.tid,
ta.oi_realmoney=so.payment,
ta.oi_totalmoney=so.total_fee,
ta.oi_couponmoney=so.discount_fee,
ta.oi_number=so.num,
ta.oi_status=so.[status],
ta.oi_mname=so.buyer_nick,
ta.oi_orderdate=so.created,
ta.oi_paydate=so.pay_time,
ta.oi_outdate=so.consign_time,
ta.oi_receipt=so.receiver_district,
ta.sa_linkman=so.receiver_name,
ta.sa_province=so.receiver_state,
ta.sa_city=so.receiver_city,
ta.sa_county=so.receiver_district,
ta.sa_address=so.receiver_address,
ta.sa_zipcode=so.receiver_zip,
ta.sa_tel=so.receiver_phone,
ta.sa_phone=so.receiver_mobile

when not matched then insert(
oi_oc_id,
oi_addtime,
oi_taobao_id,
oi_tid,
-------------------匹配
oi_no,
oi_totalmoney,
oi_couponmoney,
oi_number,
oi_status,
oi_mname,
oi_orderdate,
oi_paydate,
oi_outdate,
oi_receipt,
sa_linkman,
sa_province,
sa_city,
sa_county,
sa_address,
sa_zipcode,
sa_tel,
sa_phone
)values(
@oc_id,
@now,	
so.taobao_id,
so.tid,
-------------------匹配
so.tid,
so.total_fee,
so.discount_fee,
so.num,
so.status,
so.buyer_nick,
so.created,
so.pay_time,
so.consign_time,
so.receiver_district,
so.receiver_name,
so.receiver_state,
so.receiver_city,
so.receiver_district,
so.receiver_address,
so.receiver_zip,
so.receiver_phone,
so.receiver_mobile
);

/*******************************************
 * 商品id,规格id,条形码更新为本地的
 * 
 * 
 *******************************************/
 
 


select * from taobao_Item as ti

select ti.num_iid,
Count(1) As count
  from taobao_Item as ti inner join taobao_Sku as ts on ti.num_iid=ts.num_iid 
group by ti.num_iid

select * from taobao_Item as ti where ti.sys_oc_id=10
select * from taobao_Sku as ts where ts.sys_oc_id=10



--订单商品
merge into m_ordergoods as ta
using (select * from taobao_Order as so where so.sys_oc_id=@oc_id and so.sys_timestamp=@timestamp) as so 
on ta.og_oc_id=@oc_id and ta.og_tid=so.oid
when matched then update set
ta.og_updatetime=@now, 
-------------------匹配
ta.og_serialid=so.oid,
ta.og_goodsid=so.num_iid,
ta.og_title=so.title,
ta.og_picurl=so.pic_path,
ta.og_buynum=so.num,
ta.og_actualprice=so.price,
ta.gs_id=so.sku_id
when not matched then insert(
og_addtime,
og_tid,
-------------------匹配
og_serialid,
og_goodsid,
og_title,
og_picurl,
og_buynum,
og_actualprice,
gs_id
)values(
@now,
so.oid,
-------------------匹配
so.oid,
so.num_iid,
so.title,
so.pic_path,
so.num,
so.price,
so.sku_id
);
if @@ERROR<>0
BEGIN
	set @result=0;

	IF @@TRANCOUNT > 0 rollback tran;
end
else
BEGIN
 set @result=1;
 IF @@TRANCOUNT > 0 commit tran;
END
go

