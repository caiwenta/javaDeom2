CREATE function [dbo].[fn_get_attribute_hu_str]( @gi_id INT,@a_cp_id INT)
returns varchar(MAX)
as
begin

DECLARE @result VARCHAR(MAX)='';

--SELECT @result+=ba.a_name+',' FROM b_attribute_set bas 
--INNER JOIN b_attribute ba ON bas.a_a_id=ba.a_id AND a_pid=(SELECT a_id FROM b_attribute WHERE  a_name='货位' and a_status=1  and a_cp_id=@a_cp_id)
--WHERE bas.a_gi_id=@gi_id AND bas.a_type=1 
SELECT @result=[location] FROM [b_goodslocation] WHERE [gi_id]=@gi_id AND cp_id= @a_cp_id

return @result;
end
go

