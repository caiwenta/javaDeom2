CREATE TRIGGER [dbo].[m_order_goods_og_servtype_update_after]
ON [dbo].[m_order_goods]
AFTER UPDATE
AS
BEGIN
	DECLARE @og_servtype INT=0;
	DECLARE @gs_ys INT=0;
	DECLARE @oi_id INT=0;
	
	SELECT @og_servtype=og_servtype,@gs_ys=gs_ys,@oi_id=oi_id FROM INSERTED;

	IF @og_servtype=2 AND @gs_ys=2 AND NOT EXISTS(SELECT * FROM j_outStorage fd WHERE fd.oo_status>0 AND fd.oo_di_id=@oi_id AND fd.oo_type=0)
	BEGIN
		--生成出库退货单
		
		DECLARE @og_oc_id INT=0;
		DECLARE @oi_cp_id INT=0;
		
		DECLARE @og_id INT=0;
		
		DECLARE @oi_orderdate VARCHAR(50)='';
		
		SET @oi_orderdate=CONVERT(VARCHAR(50),GETDATE(),23);
		
		SELECT @oi_id=oi_id,@og_id=og_id FROM INSERTED
		
		SELECT @oi_cp_id=oi_cp_id,@og_oc_id=fd.oi_oc_id
		  FROM m_order_info fd WHERE fd.oi_id=@oi_id;
		
		--客户主键
		DECLARE @oc_client_id INT=0;
		--仓库主键
		DECLARE @oc_stock_id INT=0;
		
		SELECT @oc_client_id=fd.oc_client_id,@oc_stock_id=fd.oc_stock_id
		FROM m_orderchannel fd WHERE fd.oc_id=@og_oc_id;

		IF((SELECT fd.cp_is_zorf FROM companyinfo fd WHERE fd.cp_id=@oi_cp_id)!=1) OR 1=1
		BEGIN                                                                    	  --不是总部
		  DECLARE @sei_id INT=0;
		  SELECT TOP 1 @sei_id=fd.sei_id
		  FROM b_storageinfo fd WHERE fd.sei_cp_id=@oi_cp_id
		  AND  fd.sei_is_net=1 AND fd.sei_status=1                                   IF ISNULL(@sei_id,0)=0
		  BEGIN
		  	  --没有设置网络订单仓库,随机一个
		  	  SELECT TOP 1 @sei_id=fd.sei_id
		  	  FROM b_storageinfo fd WHERE fd.sei_cp_id=@oi_cp_id
			  AND fd.sei_status=1  
		  END 
		  SET @oc_stock_id=@sei_id;                         	
		END
		
		
		
		DECLARE @oo_addman INT=0;
		--得到添加人
		SELECT 
		TOP 1 @oo_addman=fd.si_id 
		FROM b_stafftinfo fd WHERE fd.si_cp_id=@oi_cp_id
		AND fd.si_isdel=1
		BEGIN tran
		--添加单据
		DECLARE @oo_id INT=0;
		INSERT INTO j_outStorage
		(
			oo_ciid,
			oo_siid,
			oo_no,
			oo_manual,
			oo_entrydate,
			oo_itid,
			oo_type,
			oo_status,
			oo_takemanid,
			oo_cost,
			oo_freight,
			oo_express,
			oo_expressno,
			oo_remark,
			oo_source_type,
			oo_source_id,
			oo_addman,
			oo_addtime,
			oo_lastmanid,
			oo_auditdate,
			oo_updatemam,
			oo_updatetime,
			oo_num,
			oo_realmoney,
			oo_totalmoney,
			oo_sh_id,
			oo_cp_id,
			oo_di_id,
			oo_jytype,
			oo_to_cp_id
		)
		VALUES
		(
			@oc_client_id,
			@oc_stock_id,
			NEWID(),
			'',
			--@oi_orderdate,
			'2004-01-02',
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			0,
			'网络订单',
			0,
			0,
			--发货人
			@oo_addman,
			GETDATE(),
			NULL,
			NULL,
			NULL,
			NULL,
			0,
			0,
			0,
			0,
			@oi_cp_id,
			@oi_id,
			0,
			0
		)
		SET @oo_id=SCOPE_IDENTITY();
		--添加明细
		INSERT INTO j_outStorageList
		(
			-- ol_id -- this column value is auto-generated
			ol_eoid,
			ol_siid,
			ol_skuid,
			ol_number,
			
			ol_realmoney,
			ol_discount,
			ol_remark,
			ol_unit,
			ol_costprice,
			ol_addtime,
			--ol_source_id,
			ol_status
			--ol_source_add_time,
			--ol_cp_id,
			--ol_di_id,
			--ol_box_num,
			--ol_pm
		)
		SELECT 
		@oo_id AS ol_eoid,
		fd2.gi_id,
		sku_id=CASE WHEN fd3.gss_id IS NOT NULL THEN fd3.gss_id ELSE 0 END,
		fd.og_buynum,
		(fd.og_buynum * fd2.gi_importprices) AS ol_realmoney,
		(fd2.gi_importprices/fd2.gi_retailprice) AS gi_purchase_discount,
		--fd2.gi_purchase_discount,
		'' AS ol_remark,
		fd2.gi_retailprice,
		fd2.gi_importprices,
		--fd2.gi_purchase,
		fd4.oi_addtime,
		1 AS ol_status
		FROM m_order_goods fd 
		INNER JOIN b_goodsinfo fd2
		ON fd.og_goodsno=fd2.gi_code
		INNER JOIN m_order_info fd4 ON fd.og_serialid=fd4.oi_no
		LEFT JOIN b_goodsruleset fd3 ON fd.gs_skucode=fd3.gss_no
		WHERE fd4.oi_id=@oi_id AND fd.og_id=@og_id
		
		DECLARE @result VARCHAR(500)='';
		--调用存储过程生成出库单
		EXEC pro_outStorage_op
			@ol_box_num = 0,
			@ol_pm = '',
			@oo_id = @oo_id,
			@oo_ciid = @oc_client_id,
			@oo_sh_id = 0,
			@oo_siid = @oc_stock_id,
			@oo_takemanid = 0,
			@oo_remark = '网络订单',
			@oo_entrydate = @oi_orderdate,
			@oo_lastmanid = 0,
			@oo_itid = 0,
			@oo_type = 0,
			@oo_status = 1,
			@oo_manual = '',
			--@oo_cost = null,
			--@oo_freight = null,
			--@oo_express = null,
			--@oo_expressno = null,
			--@oo_source_type = null,
			--@oo_source_id = null,
			@oo_jytype = 0,
			--@oo_addman = @oo_addman,
			--@oo_addtime = null,
			@oo_updatemam = @oo_addman,
			@ol_id = NULL,
			@ol_siid = null,
			@ol_number = null,
			@ol_discount = null,
			@ol_realmoney = null,
			@ol_remark = null,
			@ol_unit = null,
			@ol_costprice = null,
			@ol_addtime = null,
			@ol_skuid = null,
			@ol_source_id = null,
			@oo_cp_id = null,
			@oo_di_id = null,
			@ol_source_add_time = null,
			@not_in_ids = null,
			@savestr = null,
			@oo_to_cp_id = null,
			@negative_inventory = null,
			@op_type = '修改单据',
			@result = @result OUT
		DECLARE @ROLLBACK_ed INT=0;
		IF @result='0'
		BEGIN
			SET @ROLLBACK_ed=1;

			IF @@TRANCOUNT > 0 ROLLBACK TRAN;
		END	
		ELSE
		BEGIN
			IF @@TRANCOUNT > 0 COMMIT TRAN;
		END
		--EXEC pro_mergeStockSum
		--	@cp_id = @oi_cp_id	
		EXEC pro_mergeStockLog
			@cp_id = @oi_cp_id,
			@negative_inventory = 0,
			@old_sei_id = 0,
			@new_sei_id = 0
		IF @@error <> 0
		BEGIN
			set @ROLLBACK_ed=1 ;

			IF @@TRANCOUNT > 0 ROLLBACK TRAN;
		END	
			
		IF @ROLLBACK_ed=1
		BEGIN
			INSERT INTO log_c
			(
				-- li_id -- this column value is auto-generated
				li_myid,
				li_key,
				li_time
			)
			VALUES
			(
				@oi_id,
				'出库退货单生成失败',
				GETDATE()
			)
		END
		

	END
END
go

