CREATE VIEW [dbo].[v_z_instruction_detail]
	AS 

SELECT 
(CASE WHEN in_status=1 THEN '待审核' WHEN in_status=2 THEN '审核' END) in_status_txt,--状态

(CASE WHEN io_status=0 THEN '正常' WHEN io_status=1 THEN '延迟' END)io_status_txt,--指令状态

(CASE WHEN io_upstatus=0 THEN '未发货' WHEN io_upstatus=1 THEN '已发货' END)io_upstatus_txt,--上级状态 0-未发货  1-已发货

(CASE WHEN io_sendertype=0 THEN (SELECT sei_name FROM b_storageinfo WHERE sei_id=io_sender)
WHEN io_sendertype=1 THEN (SELECT sh_name FROM pos_shop WHERE sh_id=io_sender) END)io_sender_txt,--发货方
io_send_vo,--发货凭证号
io_senderdate,--发货限时时间

io_sys_senderdate,--限时完成完成时间

io_upstatus,--上级状态 0-未发货  1-已发货

(CASE WHEN in_level=1 THEN (CASE WHEN io_receivertype=0 THEN (SELECT cp_name FROM companyinfo WHERE cp_id=io_receiver)
WHEN io_receivertype=1 THEN (SELECT sh_name FROM pos_shop WHERE sh_id=io_receiver) END)
WHEN in_level=2 THEN (CASE WHEN io_level=1 THEN (SELECT sei_name FROM b_storageinfo WHERE sei_id=io_receiver)
WHEN io_level=2 THEN (CASE WHEN io_receivertype=0 THEN (SELECT cp_name FROM companyinfo WHERE cp_id=io_receiver)
WHEN io_receivertype=1 THEN (SELECT sh_name FROM pos_shop WHERE sh_id=io_receiver) END)END)END)io_receiver_txt,--收货方名称
io_receice_vo --收货凭证号,                                                                                            
io_sys_receicedate,--入库时间
io_downstatus, --下级状态  0-未发货 1-已发货
(CASE WHEN io_downstatus=0 THEN '未收货' WHEN io_downstatus=1 THEN '已收货' END)io_downstatus_txt,--下级状态
(CASE WHEN ino.io_level=1 THEN '一级' WHEN ino.io_level=2 THEN '二级' END)in_level_txt,--级别
(CASE WHEN in_type=0 THEN '配货单' WHEN in_type=1 THEN '调拨单' END)in_type_txt,--单据类型
ein.in_id,
ein.in_erp_id,
ein.in_date ,--单据时间
ein.in_vo, --指令凭证号
bg.gi_name,--商品名称
bg.gi_code,--商品编号
bg.gi_barcode,
bg2.colorname,--颜色
bg2.specname,--尺码
bg2.gss_no,--规格条码
einl.inl_retail_price,
einl.inl_discount,
einl.inl_num,
einl.inl_stock_price,
einl.inl_gi_id,
einl.inl_erp_id,
ino.io_logistics,--物流公司
ino.io_logistics_no,--物流单号
'' lastsaledate--最近销售时间
FROM erp_instructionObject ino
LEFT JOIN erp_instructionNotice AS ein ON ino.io_in_id=ein.in_id
INNER JOIN erp_instructionNoticelist AS einl ON ein.in_id=einl.inl_in_id AND einl.inl_status=1 AND ein.in_status>0
INNER JOIN b_goodsinfo AS bg ON einl.inl_gi_id=bg.gi_id and bg.gi_status>0
LEFT JOIN b_goodsruleset AS bg2 ON bg2.gss_id=einl.inl_sku_id
go

