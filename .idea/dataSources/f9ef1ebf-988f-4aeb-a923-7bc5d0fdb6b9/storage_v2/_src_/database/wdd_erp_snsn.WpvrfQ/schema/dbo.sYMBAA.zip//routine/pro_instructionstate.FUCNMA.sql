CREATE PROCEDURE [dbo].[pro_instructionstate]
	@orderid INT=0,
	@type INT=0
AS
	DECLARE @state INT=0;
	DECLARE @io_id INT=0;
	DECLARE @io_senderdate datetime ;--限时完成时间
	DECLARE @oo_date datetime ;--出库时间
	DECLARE @al_date datetime ;--调拨时间

	DECLARE @io_logistics varchar(MAX)='';
	DECLARE @io_logistics_no varchar(MAX)='';
--出库发货
IF @type=1 AND EXISTS(select oo_io_id from j_outStorage where oo_id=@orderid and oo_io_id>0)
BEGIN
	  select 
	  @state=oo_status,
	  @io_id=oo_io_id,
	  @io_logistics=oo_io_logistics,
	  @io_logistics_no=oo_logistics_no,
	  @oo_date=oo_addtime
	  from j_outStorage 
	  where oo_id=@orderid and oo_io_id>0
	
	  select 
	  @io_senderdate=io_senderdate
	  from erp_instructionObject AS iob
	  INNER JOIN j_outStorage AS ou  ON ou.oo_io_id=iob.io_id
	  WHERE oo_id=@orderid AND iob.io_id=@io_id

	IF @state=0
		BEGIN
			UPDATE erp_instructionObject
				SET io_upstatus=0,io_status=0,
				io_sys_senderdate=NULL,io_logistics='',io_logistics_no='',
				io_send_vo=''
				WHERE io_id=@io_id
		END
	ELSE	
	BEGIN
			UPDATE erp_instructionObject
				SET io_upstatus=1,
				io_sys_senderdate=ou.oo_addtime,
				io_send_vo=ou.oo_no,
				io_logistics=@io_logistics,
				io_logistics_no=@io_logistics_no
				FROM erp_instructionObject AS  iob
				INNER JOIN j_outStorage AS ou  ON ou.oo_io_id=iob.io_id
				WHERE oo_id=@orderid AND iob.io_id=@io_id

				if(@io_senderdate !='')
				BEGIN
					if(DATEDIFF (MINUTE,@io_senderdate,@oo_date)<=0) --更新指令单状态,时间比较精确到分钟
						BEGIN
							UPDATE erp_instructionObject
								SET io_status=2
								FROM erp_instructionObject AS  iob
								INNER JOIN j_outStorage AS ou  ON ou.oo_io_id=iob.io_id
								WHERE oo_id=@orderid AND iob.io_id=@io_id
						END
					ELSE	
					BEGIN
							UPDATE erp_instructionObject
								SET io_status=1
								FROM erp_instructionObject AS  iob
								INNER JOIN j_outStorage AS ou  ON ou.oo_io_id=iob.io_id
								WHERE oo_id=@orderid AND iob.io_id=@io_id

					END
				END
	END
	

END

--入库收货
IF @type=2 AND EXISTS(select eo_io_id from j_enterStorage where eo_id=@orderid and eo_io_id>0)
BEGIN
	select 
	@state=eo_status,
	@io_id=eo_io_id
	from j_enterStorage 
	where eo_id=@orderid and eo_io_id>0
	
	IF @state=0
		BEGIN
			UPDATE erp_instructionObject
				SET io_downstatus=0,
				io_sys_receicedate=NULL,
				io_receice_vo=''
				WHERE io_id=@io_id
		END
	ELSE	
	BEGIN
			 UPDATE erp_instructionObject
			    SET io_downstatus=1,
					io_sys_receicedate=ou.eo_addtime,
					io_receice_vo=ou.eo_no
				FROM erp_instructionObject AS iob
				INNER JOIN j_enterStorage AS ou ON ou.eo_io_id=iob.io_id
				WHERE eo_id=@orderid AND iob.io_id=@io_id
	END

END
	

--调拨发货
IF @type=3 AND EXISTS(select al_source_id from pos_alStorage where al_id=@orderid and al_cp_do=2)
BEGIN

	SELECT
	@state=al_status, 
	@io_id=al_source_id,
	@al_date=al_add_time
	from pos_alStorage 
	where al_id=@orderid and al_cp_do=2
	
	
	select 
	@io_senderdate=io_senderdate
	from erp_instructionObject AS iob
	INNER JOIN pos_alStorage AS ou  ON ou.al_source_id=iob.io_id
	WHERE al_id=@orderid AND iob.io_id=@io_id

	IF @state=2
		BEGIN
			 UPDATE erp_instructionObject
				SET io_upstatus=1,
				io_sys_senderdate=ou.al_add_time,
				io_send_vo=ou.al_vo
				FROM erp_instructionObject AS iob
				INNER JOIN pos_alStorage AS ou ON ou.al_source_id=iob.io_id AND ou.al_cp_do=2
				WHERE al_id=@orderid AND iob.io_id=@io_id
				
				
				if(@io_senderdate !='')
				BEGIN
					if(DATEDIFF (MINUTE,@io_senderdate,@al_date)<=0) --更新指令单状态,时间比较精确到分钟
						BEGIN
							UPDATE erp_instructionObject
								SET io_status=2
								FROM erp_instructionObject AS  iob
								INNER JOIN pos_alStorage AS ou  ON ou.al_source_id=iob.io_id
								WHERE al_id=@orderid AND iob.io_id=@io_id
						END
					ELSE	
					BEGIN
							UPDATE erp_instructionObject
								SET io_status=1
								FROM erp_instructionObject AS  iob
								INNER JOIN pos_alStorage AS ou  ON ou.al_source_id=iob.io_id
								WHERE al_id=@orderid AND iob.io_id=@io_id

					END
				END
		
		END
	ELSE	
	BEGIN	update erp_instructionObject 
						set io_upstatus=0,
							io_sys_senderdate=null,
							io_send_vo=''
			WHERE io_id = @io_id
			
	END

END


--pos收货
IF @type=4 AND EXISTS(select in_id from pos_inStorage where in_id=@orderid and in_io_id>0)
BEGIN



	SELECT
		@state=in_status, 
		@io_id=in_io_id
	from pos_inStorage 
	where in_id=@orderid and  in_io_id>0
	
	
	IF @state=0
		BEGIN
			update erp_instructionObject 
						set io_downstatus=0,
							io_sys_receicedate=NULL,
							io_receice_vo=''
			WHERE io_id =@io_id
		END
	ELSE	
	BEGIN
					
			UPDATE erp_instructionObject
					SET io_downstatus=1,
						io_sys_receicedate=ou.in_add_time,
						io_receice_vo=ou.in_vo
					FROM erp_instructionObject AS iob
			INNER JOIN pos_inStorage AS ou ON ou.in_io_id=iob.io_id 
			WHERE in_id=@orderid AND iob.io_id=@io_id
	END
END
go

