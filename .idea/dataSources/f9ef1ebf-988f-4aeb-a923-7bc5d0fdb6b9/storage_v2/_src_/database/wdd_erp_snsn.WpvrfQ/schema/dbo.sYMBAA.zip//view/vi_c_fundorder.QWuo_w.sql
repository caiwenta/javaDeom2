


CREATE VIEW [dbo].[vi_c_fundorder] AS 
SELECT 
cf.fo_id,
cf.fo_type,
cf.fo_ciid,
cf.fo_bs,
cf.fo_orderid,
cf.fo_takeman,
cf.fo_ticketno,
cf.fo_realmoney,
cf.fo_thiyetmoney,
cf.fo_ofdate,
cf.fo_remark,
cf.fo_lastman,
cf.fo_status,
cf.fo_outmoney,
cf.fo_admoney,
cf.fo_otheronmoney,
cf.fo_otheoutmoney,
cf.fo_givemoney,
cf.fo_ensuremoney,
cf.fo_subscription,
cf.fo_no,
cf.fo_addtime,
cf.fo_updatetime,
cf.fo_rowNum,
cf.fo_userorderno,
cf.fo_qc,
cf.fo_qm,
cf.fo_dateint,
cf.fo_orderint,
cf.fo_ordernum,
cf.fo_cp_id,
cf.fo_di_id,
cf.fo_shid,
cf.fo_to_cpid,
cf.fo_erp_id,
cf.fo_qc_integral,
cf.fo_realmoney_integral,
cf.fo_thiyetmoney_integral,
cf.fo_outmoney_integral,
cf.fo_otheronmoney_integral,
cf.fo_otheoutmoney_integral,
cf.fo_givemoney_integral,
cf.fo_qm_integral,
cf.fo_rowNum_integral,
cf.fo_dateint_integral,
cf.fo_orderint_integral,
cf.fo_ordernum_integral,
cf.fo_order_id,
cf.pzone,
cf.pztwo,
cf.pzthree,
       ciname = CASE 
                     WHEN bcinfo.ci_bs IS NULL THEN 
                          ISNULL(bsinfo.si_name, '')
                     ELSE ISNULL(bcinfo.ci_name, '')
                END,
       shname = psinfo.sh_name,
       cpname = cpinfo.cp_name,
       qcje = CASE 
                   WHEN (bcinfo.ci_bs IS NULL AND psinfo.sh_bs IS NULL AND cpinfo.cp_bs IS NULL) THEN  bsinfo.si_qcje
                   WHEN (bcinfo.ci_bs IS NULL AND bsinfo.si_bs IS NULL AND cpinfo.cp_bs IS NULL) THEN  psinfo.sh_qcje
                   WHEN (bcinfo.ci_bs IS NULL AND psinfo.sh_bs IS NULL AND bsinfo.si_bs IS NULL) THEN  cpinfo.cp_qcje
                   ELSE bcinfo.ci_qcje
              END,
       qc_integral=ISNULL(bsinfo.si_initial_integral,0),
       cicode = CASE 
                     WHEN (bcinfo.ci_bs IS NULL AND psinfo.sh_bs IS NULL AND cpinfo.cp_bs IS NULL) THEN bsinfo.si_code
                     WHEN (bcinfo.ci_bs IS NULL AND bsinfo.si_bs IS NULL AND cpinfo.cp_bs IS NULL) THEN ''--psinfo.sh_no
                     WHEN (bcinfo.ci_bs IS NULL AND psinfo.sh_bs IS NULL AND bsinfo.si_bs IS NULL) THEN ''--cpinfo.cp_code
                     ELSE bcinfo.ci_code
                END
                
                ,
                
                CASE WHEN cf.fo_realmoney_integral=0
                AND cf.fo_thiyetmoney_integral=0
                AND cf.fo_outmoney_integral=0
                AND cf.fo_otheronmoney_integral=0
                AND cf.fo_otheoutmoney_integral=0
                AND cf.fo_givemoney_integral=0
                THEN 1 ELSE 0 
                END AS integral_status,
                CASE WHEN cf.fo_realmoney=0
                AND cf.fo_thiyetmoney=0
                AND cf.fo_outmoney=0
                AND cf.fo_otheronmoney=0
                AND cf.fo_otheoutmoney=0
                AND cf.fo_givemoney=0
                THEN 1 ELSE 0 
                END AS fun_status

FROM   c_fundorder cf WITH (NOLOCK) 
       LEFT JOIN (
                SELECT ci_bs = 'X',
                       bc.ci_id,
                       bc.ci_name,
                       ISNULL(bc.ci_qcje, 0) AS ci_qcje,
                       bc.ci_code
                FROM   b_clientinfo bc WITH (NOLOCK) 
            ) AS bcinfo
            ON  cf.fo_ciid = bcinfo.ci_id
            AND cf.fo_bs = bcinfo.ci_bs
       LEFT JOIN (
                SELECT sh_bs = 'X',
                       ps.sh_id,
                       ps.sh_name,
                       0 AS sh_qcje,
                       ps.sh_no
                FROM   pos_shop ps WITH (NOLOCK) 
                WHERE  ps.[status] != 0
            ) AS psinfo
            ON  cf.fo_shid = psinfo.sh_id
            AND cf.fo_bs = psinfo.sh_bs
       LEFT JOIN (
                     SELECT cp_bs = 'X',
                            cp.cp_id,
                            cp.cp_name,
                            0 AS cp_qcje,
                            cp.cp_code
                     FROM   companyinfo cp WITH (NOLOCK) 
                 ) AS cpinfo 
                 ON cf.fo_to_cpid = cpinfo.cp_id 
                 AND cf.fo_bs = cpinfo.cp_bs
       LEFT JOIN (
                SELECT si_bs = 'G',
                       bs.si_id,
                       bs.si_name,
                       ISNULL(bs.si_qcje, 0) AS si_qcje,
					   ISNULL(bs.si_initial_integral,0) AS si_initial_integral,
                       bs.si_code
                FROM   b_supplierinfo bs WITH (NOLOCK) 
            ) AS bsinfo
            ON  cf.fo_ciid = bsinfo.si_id
            AND cf.fo_bs = bsinfo.si_bs
WHERE  cf.fo_status =2
go

