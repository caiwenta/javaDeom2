CREATE VIEW [dbo].[vi_j_month_report] AS 

select 

(end_num*price) as end_money,--期末金额
(en_money-enth_money) AS enmoneyhj,--入库额合计
(TT.oo_money-TT.ooth_money) AS ooth_moneyhj,--出库额合计
TT.* 

from
(
SELECT rp.[gid]
      ,rp.[sid]
      ,rp.[en_num]
      ,rp.[en_money]
      ,-rp.[enth_num] AS [enth_num]
      ,-rp.[enth_money] as[enth_money]
      ,-rp.[oo_num] AS [oo_num]
      ,rp.[ooth_num] as[ooth_num] 
      ,rp.[ts_num]
      ,rp.[mi_num]
      ,(rp.[mo_num]+rp.[mi_num]) AS mo_num
      ,(rp.[yk_num]+ rp.[ts_num]) AS yk_num
      ,rp.[price]
      ,rp.[start_money]
      ,rp.[start_num]

,(rp.[start_num]+rp.en_num + rp.enth_num+rp.oo_num +rp.ooth_num+ rp.[yk_num]+ rp.[ts_num]+rp.[mo_num]+rp.[mi_num]) AS  [end_num]
      ,rp.[m_year]
      ,rp.[m_month]
	  ,rp.m_day
      ,rp.[erp_id]
      ,rp.[company_id],

       b.gi_code,
       b.gi_skus,
	   b.gi_barcode,
       b.gi_costprice,
       b.gi_retailprice,
       b.gi_name,
       b.gi_attribute_ids,
       b.gi_attribute_parentids,
	   b.gi_types,
       b.gi_typesid,
       s.sei_name,
       un.ut_name,


	   abs(oo_num*price) AS oo_money,--出库金额
	   (ooth_num *price) as  ooth_money,--出退金额
	   ((rp.[yk_num]+ rp.[ts_num]) * price)     AS yk_money,--盈亏金额
	    (rp.ts_num * rp.price)     AS ts_money,--盘点盈亏金额
	   ((rp.[mo_num]+rp.[mi_num]) *  price)     AS mo_money,--移仓金额
       (rp.mi_num * rp.price)     AS mi_money,--移仓移入金额


       (rp.en_num + rp.enth_num)  AS enhj,--入库数合计
     
       (-rp.oo_num- rp.ooth_num)  AS ooth_numhj,--出库数合计




	     (rp.start_num * rp.price)  AS s_money,
       --(-rp.[ooth_money]-rp.[oo_money]) AS ooth_moneyhj,
       (start_num*b.gi_costprice) AS retail_start_money,
       (en_num*b.gi_costprice) AS retail_en_money,
       ((en_num+rp.enth_num)*b.gi_costprice) AS retail_enmoneyhj,
        (-rp.enth_num*b.gi_costprice) as retail_enth_money,
	   (-rp.[oo_num]*b.gi_costprice) AS retail_oo_money, 
	   (rp.[ooth_num]*b.gi_costprice) AS retail_ooth_money,
	   ((rp.oo_num + rp.ooth_num)*b.gi_costprice) AS retail_ooth_moneyhj,
	   ((rp.[yk_num]+ rp.[ts_num]) * b.gi_costprice)     AS retail_yk_money,
	   ((rp.[mo_num]+rp.[mi_num]) *  b.gi_costprice)     AS retail_mo_money,
((rp.[start_num]+rp.en_num + rp.enth_num+rp.oo_num + rp.ooth_num+ rp.[yk_num]+ rp.[ts_num]+rp.[mo_num]+rp.[mi_num] ) * b.gi_costprice)AS retail_end_money,    
   ( 
 CASE WHEN 	rp.reporttype=0 then
 CAST(rp.m_year AS VARCHAR(100)) + '-' + CAST(rp.m_month AS VARCHAR(100)) 
 ELSE
 CAST(rp.m_year AS VARCHAR(100)) + '-' + CAST(rp.m_month AS VARCHAR(100))+'-' +CAST(rp.m_day AS VARCHAR(100))
 END
 ) AS DATE,
       rp.[order_date] AS order_date,
       rp.reporttype
FROM   j_month_report AS rp
       INNER JOIN b_goodsinfo      AS b
            ON  b.gi_id = rp.gid
       INNER JOIN b_storageinfo s
            ON  s.sei_id = rp.sid
       INNER JOIN b_unit un
            ON  un.ut_id = b.gi_unit

) as TT
go

