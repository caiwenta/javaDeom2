CREATE PROCEDURE [dbo].[pro_netordergoods_tbl_get_storage_id]
       @ord_type VARCHAR(50) ,  --‘refund’为退货，‘send’为发货
       @send_type VARCHAR(50) , --‘node’为节点，‘store’为门店
       @cp_id INT = 0	--节点ID或门店ID
AS
       BEGIN
			------------------------------------
			--用途：获取网络订单设置的仓库
			------------------------------------
             DECLARE @stock_id INT= 0  --仓库ID
			 --退货到节点
             IF @send_type = 'node'
                BEGIN
                      IF @ord_type = 'refund'
                         BEGIN
					  --设置了退换货仓库
                               SELECT TOP 1
                                        @stock_id = sei_id
                               FROM     b_storageinfo WITH ( NOLOCK )
                               WHERE    sei_cp_id = @cp_id
                                        AND sei_is_net_refund = 1
                                        AND sei_status = 1
                         END	                                        
					  --没有设置退换货仓库取网络订单仓库
                      IF ISNULL(@stock_id, 0) = 0
                         BEGIN
                               SELECT TOP 1
                                        @stock_id = sei_id
                               FROM     b_storageinfo WITH ( NOLOCK )
                               WHERE    sei_cp_id = @cp_id
                                        AND sei_is_net = 1
                                        AND sei_status = 1
                         END
					  --没有设置网络订单仓库,随机一个
                      IF ISNULL(@stock_id, 0) = 0
                         BEGIN
                               SELECT TOP 1
                                        @stock_id = sei_id
                               FROM     b_storageinfo WITH ( NOLOCK )
                               WHERE    sei_cp_id = @cp_id
                                        AND sei_status = 1
                         END

                END
			 --退货到门店
             IF @send_type = 'store'
                BEGIN
                      IF @ord_type = 'refund'
                         BEGIN 
					  --设置了退换货仓库
                               SELECT TOP 1
                                        @stock_id = sei_id
                               FROM     pos_storageInfo WITH ( NOLOCK )
                               WHERE    sei_sh_id = @cp_id
                                        AND sei_status = 1
                                        AND sei_is_net_refund = 1
                         END
					  --没设置退换货仓库，使用网络订单仓库
                      IF ISNULL(@stock_id, 0) = 0
                         BEGIN
                               SELECT TOP 1
                                        @stock_id = sei_id
                               FROM     pos_storageInfo WITH ( NOLOCK )
                               WHERE    sei_sh_id = @cp_id
                                        AND sei_status = 1
                                        AND sei_is_net = 1
                         END
					   --没设置退换货仓库和网络订单仓库，随机一个
                      IF ISNULL(@stock_id, 0) = 0
                         BEGIN
                               SELECT TOP 1
                                        @stock_id = sei_id
                               FROM     pos_storageInfo WITH ( NOLOCK )
                               WHERE    sei_sh_id = @cp_id
                                        AND sei_status = 1
                         END
                END

             RETURN @stock_id
       END
go

