

CREATE VIEW [dbo].[vi_pos_stockSumList] AS 
SELECT
	ss.shid,
	ss.gid,
	ss.skuid,
	ss.sid,
	ss.gnum,
	bs.sei_name,
	bs.sei_is_tb,--是否同步
	bg2.gs_name,
	bg2.gss_no,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.gi_unit,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_add_man,
	bg.gi_add_time,
	bg.gi_update_man,
	bg.gi_update_time,
	bg.gi_cp_id,
	bg.gi_di_id,
	bg.gi_attribute_ids,
	bg.gi_is_tb,
	bg.gi_attribute_parentids,
	bg.gi_purchase_discount,
	bu.ut_name,
	
	psi.st_occupy_num,
	enable_stock_num=ss.gnum-ISNULL(psi.st_occupy_num,0)
--最后的供应商
FROM
	dbo.vi_pos_stockSum AS ss
	INNER JOIN pos_stockInfo psi  WITH (NOLOCK) 
	ON ss.shid=psi.st_sh_id
	AND ss.[sid]=psi.st_st_id
	AND ss.gid=psi.st_gi_id
	AND ss.skuid=psi.st_sku_id
	
LEFT OUTER JOIN dbo.pos_storageInfo AS bs ON ss.sid = bs.sei_id
INNER JOIN dbo.b_goodsinfo AS bg ON ss.gid = bg.gi_id
LEFT OUTER JOIN dbo.b_goodsruleset AS bg2 ON ss.skuid = bg2.gss_id
LEFT OUTER JOIN dbo.b_unit AS bu ON bg.gi_unit = bu.ut_id

go

