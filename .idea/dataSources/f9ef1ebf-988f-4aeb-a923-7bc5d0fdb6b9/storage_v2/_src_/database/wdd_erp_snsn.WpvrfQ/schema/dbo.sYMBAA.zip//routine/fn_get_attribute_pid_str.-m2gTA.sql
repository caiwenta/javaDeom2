
CREATE function [dbo].[fn_get_attribute_pid_str]( @gi_id INT,@a_cp_id INT)
returns varchar(MAX)
as
begin

DECLARE @result VARCHAR(MAX)=',';

SELECT
@result+=CONVERT(VARCHAR(10),tt.pid)+','
FROM
(
SELECT 
ablist.pid,ablist.a_gi_id
FROM
(
SELECT 
(SELECT a_pid FROM b_attribute AS ba WHERE ba.a_id=bs.a_a_id) AS pid,bs.a_gi_id
FROM [b_attribute_set] AS bs INNER JOIN b_attribute bas ON bs.a_a_id=bas.a_id 
WHERE  bs.a_type=1 and bs.a_cp_id=@a_cp_id
) ablist WHERE ablist.a_gi_id=@gi_id 
GROUP BY pid,a_gi_id
) tt



return @result;
end
go

