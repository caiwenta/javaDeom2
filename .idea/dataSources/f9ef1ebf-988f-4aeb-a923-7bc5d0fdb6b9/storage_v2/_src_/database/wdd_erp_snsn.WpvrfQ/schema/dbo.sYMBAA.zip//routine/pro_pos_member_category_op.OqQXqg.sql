


CREATE PROCEDURE [dbo].[pro_pos_member_category_op]
	@category_id INT ,
	@category_name VARCHAR(50),
	@category_cors INT,
	@addtime DATETIME,
	@remark VARCHAR(250),
	@category_fid INT,
	@category_status INT,
	 --操作类型(1:添加 2:修改 3:删除)
	@op_type INT = 0,
	@outResult INT OUTPUT,
	@category_sh_id INT = 0,
	@category_erp_id INT = 0
AS
BEGIN
	IF @op_type = 1
	BEGIN
	    INSERT INTO [pos_member_category]
	      (
	        [category_name],
	        [category_cors],
	        [addtime],
	        [remark],
	        [category_fid],
	        [category_status],
	        [category_sh_id],
	        category_erp_id
	      )
	    VALUES
	      (
	        @category_name,
	        @category_cors,
	        @addtime,
	        @remark,
	        @category_fid,
	        @category_status,
	        @category_sh_id,@category_erp_id
	      )
	    SET @category_id = SCOPE_IDENTITY()
	END
	
	IF @op_type = 2
	   AND @category_id > 0
	BEGIN
	    UPDATE [pos_member_category]
	    SET    [category_name]       = @category_name,
	           [category_cors]       = @category_cors,
	           [addtime]         = @addtime,
	           [remark]          = @remark,
	           [category_fid]        = @category_fid,
	           [category_status]     = @category_status
	    WHERE  [category_id]         = @category_id
	    --AND category_sh_id=@category_sh_id
	END
	
	IF @op_type = 3
	   AND @category_id > 0
	BEGIN
	    UPDATE [pos_member_category]
	    SET    [category_status]     = @category_status
	    WHERE  [category_id]         = @category_id
	     --AND category_sh_id=@category_sh_id
	END
	
	IF @@error <> 0
	BEGIN
	    SET @outResult = 0;
	END
	ELSE
	BEGIN
	    SET @outResult = @category_id;
	END
	RETURN @outResult;
END
go

