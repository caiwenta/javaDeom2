CREATE VIEW [dbo].[vi_j_moStorageList_sum]
	AS 
SELECT 
jmsl.mol_mo_id,
(SELECT SUM(isnull(mol_box_num,0)) FROM (
Select (case when fd.mol_boxbynum=0 then 0 else ceiling(sum(fd.mol_num)/fd.mol_boxbynum) end) as mol_box_num
From j_moStorageList fd where fd.mol_status=1 AND fd.mol_mo_id=jmsl.mol_mo_id
GROUP BY fd.mol_gi_id,isnull(fd.mol_pm,''),fd.mol_boxbynum
) AS BB
) AS mol_boxnum,
SUM(mol_num) AS mol_num,
SUM(mol_money) AS mol_money
FROM j_moStorageList AS jmsl WHERE jmsl.mol_status=1 
GROUP BY jmsl.mol_mo_id
go

