






CREATE view [dbo].[v_z_moStorage_detail]
as

select 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
molist.*,
(case when molist.mol_sku_id>0 then gss_no else gi_barcode end) as barcode

from 
(

select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
mo.* 
from
(

SELECT
st.mol_id,
ge.mo_id,
ge.mo_cp_id,
ge.mo_erp_id as erp_id,

ge.mo_vo,--凭证号
ge.mo_no,--单据号
ge.mo_date,--移仓日期
ug.sei_name as mo_out_st_id_txt,--移出仓库
ig.sei_name as mo_in_st_id_txt,--移入仓库

ug.sei_name as outseiname,--移出仓库
ig.sei_name as inseiname,--移入仓库

st.mol_gi_id,
gi.gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码


isnull(st.mol_num,0) as num,--移出数量

ui.ut_name,--单位
ui.ut_name as gi_unit,

isnull(st.mol_stock_num,0) as mol_stock_num,--日期库存数量
isnull(st.mol_num,0) as mol_num,--移出数量

isnull(st.mol_retail_price,0) as mol_retail_price,--零售价
isnull(st.mol_discount,0) as mol_discount,--折率
isnull(st.mol_stock_price,0) as mol_stock_price,--进货价
isnull(st.mol_money,0) as mol_money,--金额
isnull(st.mol_box_num,0) as mol_box_num,--箱数
st.mol_pm,--配码

mol_add_time,--单据添加时间
mo_order_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = mo_order_man) ),--经手人
mo_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = mo_add_man) ),--单据添加人
mo_add_time,--单据添加时间
mo_update_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = mo_update_man) ),--单据修改人
mo_update_time,--单据修改时间
mo_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = mo_audit_man) ),--单据审核人
mo_audit_time,--单据审核时间
mo_remark,--备注
mo_status,--状态
(SELECT sei_name FROM b_storageinfo WHERE sei_id=ge.mo_to_st_id) AS mo_to_st_id_txt,
ge.mo_to_st_id,
ge.mo_out_st_id,
ge.mo_in_st_id,
st.mol_sku_id,
ge.mo_source_type,

(case ge.mo_source_type when 1 then (SELECT TOP 1 mo_in_st_id FROM j_moStorage AS je WHERE je.mo_source_id=ge.mo_id AND je.mo_status<>0) else 0 end) AS mo_source_in_st_id,
(case ge.mo_source_type when 1 then (SELECT TOP 1 mo_id FROM j_moStorage AS je WHERE je.mo_source_id=ge.mo_id AND je.mo_status<>0) else 0 end) AS mo_source_id,
(case ge.mo_source_type when 1 then (SELECT TOP 1 mo_vo FROM j_moStorage AS je WHERE je.mo_source_id=ge.mo_id AND je.mo_status<>0)  else '' end) AS mo_source_vo


FROM   j_moStorage ge
inner join  j_moStorageList st ON ge.mo_id = mol_mo_id AND st.mol_status = 1 and ge.mo_status>0
left join b_goodsinfo gi on gi.gi_id=st.mol_gi_id and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 
LEFT join b_storageinfo ug on ug.sei_id=ge.mo_out_st_id
LEFT join b_storageinfo ig on ig.sei_id=ge.mo_in_st_id

) as mo
left join b_goodsruleset  as grl on  grl.gss_id=mo.mol_sku_id

) as molist
left join s_goodsruledetail rulenum on gd_id= molist.size
go

