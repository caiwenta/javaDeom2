CREATE TRIGGER [dbo].[m_pos_order_goods_og_servtype_update_after] ON [dbo].[m_pos_order_goods] 
AFTER update
--INSERT,DELETE,
AS
BEGIN
	DECLARE @og_servtype INT=0;
	DECLARE @gs_ys INT=0;
	SELECT @og_servtype=og_servtype,@gs_ys=gs_ys FROM INSERTED;
	
	IF @og_servtype=2 AND @gs_ys=2 AND 1=2
	BEGIN
		
		DECLARE @oi_id INT=0;
		DECLARE @og_oc_id INT=0;
		DECLARE @oi_sh_id INT=0;
		
		DECLARE @og_id INT=0;
		
		DECLARE @oi_orderdate VARCHAR(50)='';
		
		SET @oi_orderdate=CONVERT(VARCHAR(50),GETDATE(),23);
		
		SELECT @oi_id=oi_id,@og_id=og_id FROM INSERTED
		
		SELECT @oi_sh_id=oi_sh_id,@og_oc_id=fd.oi_oc_id
		  FROM m_pos_order_info fd WHERE fd.oi_id=@oi_id;
		
		--客户主键
		DECLARE @oc_client_id INT=0;
		--仓库主键
		DECLARE @oc_stock_id INT=0;
		
		SELECT @oc_client_id=fd.oc_client_id,@oc_stock_id=fd.oc_stock_id
		FROM m_orderchannel fd WHERE fd.oc_id=@og_oc_id;
		
		DECLARE @oo_addman INT=0;
		--得到添加人
		SELECT 
		TOP 1 @oo_addman=fd.si_id 
		FROM b_stafftinfo fd WHERE fd.si_cp_id=@oi_sh_id
		AND fd.si_isdel=1
		
		
	    SELECT top 1 @oc_stock_id=fd.sei_id
		FROM pos_storageInfo fd WHERE fd.sei_sh_id=@oi_sh_id
		AND fd.sei_status=1 

		DECLARE @result VARCHAR(500)='';
		
		DECLARE @gi_id INT=0;
		DECLARE @sku_id INT=0;
		DECLARE @og_buynum INT=0;
		DECLARE @gi_purchase_discount DECIMAL(10,2)=0;
		DECLARE @gi_retailprice DECIMAL(10,2)=0;
		DECLARE @gi_purchase DECIMAL(10,2)=0;
		DECLARE @oi_addtime DATETIME;
	
		DECLARE @sa_id INT=0;
		DECLARE @sa_add_time DATETIME;
		SET @sa_add_time=GETDATE();
		--游标
		DECLARE sopcor CURSOR FOR(
			
			SELECT 
			fd2.gi_id,
			sku_id=CASE WHEN fd3.gss_id IS NOT NULL 
			THEN fd3.gss_id ELSE 0 END,
			fd.og_buynum,
			fd2.gi_purchase_discount,
			fd2.gi_retailprice,
			fd2.gi_purchase,
			fd4.oi_addtime
			FROM m_order_goods fd 
			INNER JOIN b_goodsinfo fd2
			ON fd.og_goodsno=fd2.gi_code
			INNER JOIN m_pos_order_info fd4 ON fd.og_serialid=fd4.oi_no
			LEFT JOIN b_goodsruleset fd3 ON fd.gs_skucode=fd3.gss_no
			WHERE fd4.oi_id=@oi_id AND fd.og_id=@og_id
			
		)
		OPEN sopcor
		FETCH NEXT FROM sopcor INTO @gi_id,@sku_id,@og_buynum,@gi_purchase_discount,@gi_retailprice,@gi_purchase,@oi_addtime
			WHILE @@FETCH_STATUS =0
			begin
				
				
				EXEC pro_pos_sale_temp_op
				@sal_id = 0,
				@sal_sa_id = @sa_id,
				@sal_gi_id = @gi_id,
				@sal_sku_id = @sku_id,
				@sal_num = @og_buynum,
				@sal_retail_price = @gi_retailprice,
				@sal_discount = @gi_purchase_discount,
				@sal_list_man = @oo_addman,
				@sal_real_price = @gi_purchase,
				--@sal_money = (@gi_purchase*@og_buynum),
				--@sal_deduct_money = 0,
				--@sal_is_gift = null,
				--@sal_is_change = null,
				--@sal_is_in = null,
				--@sal_in_num = null,
				@sal_is_return = 1,
				--@sal_remark = null,
				--@sal_remark2 = null,
				@sal_add_time = @oi_addtime,
				@sa_id = @sa_id,
				@sa_sh_id = @oi_sh_id,
				@sa_co_man = @oo_addman,
				@sa_date = @oi_orderdate,
				--@sa_no = NULL,
				--@sa_ac_id = null,
				--@sa_order_man = null,
				@sa_st_id = @oc_stock_id,
				--@sa_update_man = null,
				--@sa_update_time = null,
				@sa_add_man = @oo_addman,
				@sa_add_time = @sa_add_time,
				@sa_type = 1,
				@sa_sa_type = 1,
				--@sa_me_id = null,
				@sa_remark = '网络订单',
				--@sa_in_id = null,
				--@sa_in_num = null,
				--@sa_get_in_num = null,
				--@sa_deduct_money = null,
				--@sa_sa_vo = null,
				--@sa_gift_vo = null,
				--@sa_in_money = null,
				--@sa_card_money = null,
				--@sa_shop_money = null,
				--@sa_money = null,
				--@sa_real_money = null,
				--@sa_charge_money = null,
				--@sa_surplus_money = null,
				--@sa_select = null,
				--@sa_audit_man = null,
				--@sa_audit_time = null,
				--@sa_sale_money = null,
				--@sa_change_money = null,
				--@sa_gift_money = null,
				--@sa_current_vo = null,
				--@sa_is_charge = null,
				@op_type = '添加修改单据,明细',
				@result = @result OUT
				
				IF @sa_id=0
				BEGIN
					SET @sa_id=CONVERT(INT,@result);
				END
			
			FETCH NEXT FROM sopcor INTO @gi_id,@sku_id,@og_buynum,@gi_purchase_discount,@gi_retailprice,@gi_purchase,@oi_addtime
			End
		CLOSE sopcor
		DEALLOCATE sopcor
		
		
		EXEC pro_pos_sale_temp_op
		--@sal_id = 0,
		--@sal_sa_id = null,
		--@sal_gi_id = null,
		--@sal_sku_id = null,
		--@sal_num = null,
		--@sal_retail_price = null,
		--@sal_discount = null,
		--@sal_list_man = null,
		--@sal_real_price = null,
		--@sal_money = null,
		--@sal_deduct_money = null,
		--@sal_is_gift = null,
		--@sal_is_change = null,
		--@sal_is_in = null,
		--@sal_in_num = null,
		--@sal_is_return = null,
		--@sal_remark = null,
		--@sal_remark2 = null,
		--@sal_add_time = null,
		@sa_id = @sa_id,
		@sa_sh_id = @oi_sh_id,
		@sa_co_man = @oo_addman,
		@sa_date = @oi_orderdate,
		--@sa_no = null,
		--@sa_ac_id = null,
		--@sa_order_man = null,
		@sa_st_id = @oc_stock_id,
		--@sa_update_man = null,
		--@sa_update_time = null,
		--@sa_add_man = null,
		--@sa_add_time = null,
		@sa_type = 1,
		@sa_sa_type = 1,
		--@sa_me_id = null,
		@sa_remark = '网络订单',
		--@sa_in_id = null,
		--@sa_in_num = null,
		--@sa_get_in_num = null,
		--@sa_deduct_money = null,
		--@sa_sa_vo = null,
		--@sa_gift_vo = null,
		--@sa_in_money = null,
		--@sa_card_money = null,
		--@sa_shop_money = null,
		--@sa_money = null,
		--@sa_real_money = null,
		--@sa_charge_money = null,
		--@sa_surplus_money = null,
		--@sa_select = null,
		--@sa_audit_man = null,
		--@sa_audit_time = null,
		--@sa_sale_money = null,
		--@sa_change_money = null,
		--@sa_gift_money = null,
		--@sa_current_vo = null,
		--@sa_is_charge = null,
		@op_type = '修改单据',
		@result = @result
		
		
	END
END
go

