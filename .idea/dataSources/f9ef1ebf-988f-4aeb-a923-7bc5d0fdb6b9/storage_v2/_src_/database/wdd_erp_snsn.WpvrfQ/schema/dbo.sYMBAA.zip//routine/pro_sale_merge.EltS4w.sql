


CREATE Proc  [dbo].[pro_sale_merge]
@sa_id int,
@op_type varchar(50)=''
as

if @op_type='数据签出'
BEGIN

begin tran

merge into pos_sale_temp as ta 
using (select * from pos_sale as so where so.sa_id=@sa_id) as so 
on ta.sa_id=so.sa_id and ta.sa_id=@sa_id
when not matched then insert(
 sa_sh_id, sa_co_man, sa_date, sa_no, sa_vo, sa_ac_id, sa_order_man, sa_st_id, sa_update_man, sa_update_time, sa_add_man, sa_add_time, sa_audit_man, sa_audit_time, sa_status, sa_type, sa_sa_type, sa_me_id, sa_remark, sa_in_id, sa_in_num, sa_get_in_num, sa_deduct_money, sa_sa_vo, sa_gift_vo, sa_in_money, sa_card_money, sa_shop_money, sa_money, sa_real_money, sa_charge_money, sa_surplus_money, sa_select, sa_sale_money, sa_change_money, sa_gift_money, sa_current_vo, sa_is_charge, sa_is_calculated,sa_erp_id,sa_salman,sa_salmanname,
  sa_receivedmomey,sa_paidmomey,sa_cashmoney,sa_bankmomey,sa_weixinmoney,sa_alipaymoney,sa_storedmoney,sa_ac_ids,sa_ac_names
)values(
  so.sa_sh_id, so.sa_co_man, so.sa_date, so.sa_no, so.sa_vo, so.sa_ac_id, so.sa_order_man, so.sa_st_id, so.sa_update_man, so.sa_update_time, so.sa_add_man, so.sa_add_time, so.sa_audit_man, so.sa_audit_time, so.sa_status, so.sa_type, so.sa_type, so.sa_me_id, so.sa_remark, so.sa_in_id, so.sa_in_num, so.sa_get_in_num, so.sa_deduct_money, so.sa_sa_vo, so.sa_gift_vo, so.sa_in_money, so.sa_card_money, so.sa_shop_money, so.sa_money, so.sa_real_money, so.sa_charge_money, so.sa_surplus_money, so.sa_select, so.sa_sale_money, so.sa_change_money, so.sa_gift_money, so.sa_current_vo, so.sa_is_charge, so.sa_is_calculated,so.sa_erp_id,so.sa_salman,so.sa_salmanname
   ,so.sa_receivedmomey,so.sa_paidmomey,so.sa_cashmoney,so.sa_bankmomey,so.sa_weixinmoney,so.sa_alipaymoney,so.sa_storedmoney,so.sa_ac_ids,so.sa_ac_names
)
when matched then update set ta.sa_sh_id=so.sa_sh_id,ta.sa_co_man=so.sa_co_man,ta.sa_date=so.sa_date,ta.sa_no=so.sa_no,ta.sa_vo=so.sa_vo,ta.sa_ac_id=so.sa_ac_id,ta.sa_order_man=so.sa_order_man,ta.sa_st_id=so.sa_st_id,ta.sa_update_man=so.sa_update_man,ta.sa_update_time=so.sa_update_time,ta.sa_add_man=so.sa_add_man,ta.sa_add_time=so.sa_add_time,ta.sa_audit_man=so.sa_audit_man,ta.sa_audit_time=so.sa_audit_time,ta.sa_status=so.sa_status,ta.sa_type=so.sa_type,ta.sa_sa_type=so.sa_sa_type,ta.sa_me_id=so.sa_me_id,ta.sa_remark=so.sa_remark,ta.sa_in_id=so.sa_in_id,ta.sa_in_num=so.sa_in_num,ta.sa_get_in_num=so.sa_get_in_num,ta.sa_deduct_money=so.sa_deduct_money,ta.sa_sa_vo=so.sa_sa_vo,ta.sa_gift_vo=so.sa_gift_vo,ta.sa_in_money=so.sa_in_money,ta.sa_card_money=so.sa_card_money,ta.sa_shop_money=so.sa_shop_money,ta.sa_money=so.sa_money,ta.sa_real_money=so.sa_real_money,ta.sa_charge_money=so.sa_charge_money,ta.sa_surplus_money=so.sa_surplus_money,ta.sa_select=so.sa_select,ta.sa_sale_money=so.sa_sale_money,ta.sa_change_money=so.sa_change_money,ta.sa_gift_money=so.sa_gift_money,ta.sa_current_vo=so.sa_current_vo,ta.sa_is_charge=so.sa_is_charge,ta.sa_is_calculated=so.sa_is_calculated,ta.sa_erp_id=so.sa_erp_id,
  ta.sa_salman=so.sa_salman,ta.sa_salmanname=so.sa_salmanname,
  ta.sa_receivedmomey=so.sa_receivedmomey,
  ta.sa_paidmomey=so.sa_paidmomey,
  ta.sa_cashmoney=so.sa_cashmoney,
  ta.sa_bankmomey=so.sa_bankmomey,
  ta.sa_weixinmoney=so.sa_weixinmoney,
  ta.sa_alipaymoney=so.sa_alipaymoney,
  ta.sa_storedmoney=so.sa_storedmoney,
  ta.sa_ac_ids=so.sa_ac_ids,
  ta.sa_ac_names=ta.sa_ac_names
when not matched by source and ta.sa_id=@sa_id then delete; 
if @@ERROR<>0
BEGIN
	IF @@TRANCOUNT > 0 rollback tran;
	return;
END




merge into pos_saleList_temp as ta 
using (select * from  pos_saleList as ps where ps.sal_sa_id=@sa_id )as so 
on ta.sal_id=so.sal_id and ta.sal_sa_id=@sa_id
when not matched then insert(
sal_sa_id, sal_gi_id, sal_sku_id, sal_num, sal_retail_price, sal_discount, sal_list_man, sal_real_price, sal_money, sal_deduct_money, sal_is_gift, sal_is_change, sal_is_tejia,sal_is_zhengjia,sal_is_in, sal_in_num, sal_remark, sal_status, sal_add_time, sal_is_return, sal_discount_old, sal_deduct_money_old, sal_real_price_old, sal_old_record, sal_is_active_gift,sal_remark2,sal_st_id,sal_erp_id,sal_customprice,
sal_buyingteamid,sal_deduction,sal_acid,sal_returnedid,sal_in_money
)values(
  so.sal_sa_id, so.sal_gi_id, so.sal_sku_id, so.sal_num, so.sal_retail_price, so.sal_discount, so.sal_list_man, so.sal_real_price, so.sal_money, so.sal_deduct_money, so.sal_is_gift, so.sal_is_change,so.sal_is_tejia,so.sal_is_zhengjia, so.sal_is_in, so.sal_in_num, so.sal_remark, so.sal_status, so.sal_add_time, so.sal_is_return, so.sal_discount_old, so.sal_deduct_money_old, so.sal_real_price_old, so.sal_old_record, so.sal_is_active_gift,so.sal_remark2,so.sal_st_id,so.sal_erp_id,so.sal_customprice,
  so.sal_buyingteamid,so.sal_deduction,so.sal_acid,so.sal_returnedid,so.sal_in_money
)
when matched then update set ta.sal_sa_id=so.sal_sa_id,ta.sal_gi_id=so.sal_gi_id,ta.sal_sku_id=so.sal_sku_id,ta.sal_num=so.sal_num,ta.sal_retail_price=so.sal_retail_price,ta.sal_discount=so.sal_discount,ta.sal_list_man=so.sal_list_man,ta.sal_real_price=so.sal_real_price,ta.sal_money=so.sal_money,ta.sal_deduct_money=so.sal_deduct_money,ta.sal_is_gift=so.sal_is_gift,ta.sal_is_change=so.sal_is_change,ta.sal_is_zhengjia=so.sal_is_zhengjia,ta.sal_is_tejia=so.sal_is_tejia,ta.sal_is_in=so.sal_is_in,ta.sal_in_num=so.sal_in_num,ta.sal_remark=so.sal_remark,ta.sal_status=so.sal_status,ta.sal_add_time=so.sal_add_time,ta.sal_is_return=so.sal_is_return,ta.sal_discount_old=so.sal_discount_old,ta.sal_deduct_money_old=so.sal_deduct_money_old,ta.sal_real_price_old=so.sal_real_price_old,ta.sal_old_record=so.sal_old_record,ta.sal_is_active_gift=so.sal_is_active_gift,ta.sal_remark2=so.sal_remark2,ta.sal_st_id=so.sal_st_id,ta.sal_erp_id=so.sal_erp_id,ta.sal_customprice=so.sal_customprice,
ta.sal_buyingteamid=so.sal_buyingteamid,ta.sal_deduction=so.sal_deduction,ta.sal_acid=so.sal_acid,ta.sal_returnedid=so.sal_returnedid,ta.sal_in_money=so.sal_in_money
when not matched by source and ta.sal_sa_id=@sa_id then delete; 
if @@ERROR<>0
BEGIN
	IF @@TRANCOUNT > 0 rollback tran;
	return;
end
else
BEGIN
	

--UPDATE pos_sale
--SET sa_paytype = fd2.ord_payway
--FROM pos_sale fd,(
--SELECT psn.sa_net_sa_id,nt.ord_payway FROM pos_sale_net psn
--INNER JOIN netorder_tbl nt ON psn.sa_net_ord_id=nt.ord_id
--) AS fd2 WHERE fd.sa_id=fd2.sa_net_sa_id


--UPDATE pos_sale_temp
--SET sa_paytype = fd2.ord_payway
--FROM pos_sale_temp fd,(
--SELECT psn.sa_net_sa_id,nt.ord_payway FROM pos_sale_net psn
--INNER JOIN netorder_tbl nt ON psn.sa_net_ord_id=nt.ord_id
--) AS fd2 WHERE fd.sa_id=fd2.sa_net_sa_id

	IF @@TRANCOUNT > 0 commit tran;
	return;
END

return;	
end

if @op_type='数据签入'
BEGIN
begin tran


delete pos_sale where sa_id=@sa_id
INSERT INTO pos_sale
(
 sa_id, sa_sh_id, sa_co_man, sa_date, sa_no, sa_vo, sa_ac_id, sa_order_man, sa_st_id, sa_update_man, sa_update_time, sa_add_man, sa_add_time, sa_audit_man, sa_audit_time, sa_status, sa_type, sa_sa_type, sa_me_id, sa_remark, sa_in_id, sa_in_num, sa_get_in_num, sa_deduct_money, sa_sa_vo, sa_gift_vo, sa_in_money, sa_card_money, sa_shop_money, sa_money, sa_real_money, sa_charge_money, sa_surplus_money, sa_select, sa_sale_money, sa_change_money, sa_gift_money, sa_current_vo, sa_is_charge, sa_is_calculated,sa_paytype,pzone,pztwo,pzthree,sa_erp_id,sa_salman,sa_salmanname,
   sa_receivedmomey,
   sa_paidmomey,
   sa_cashmoney,
   sa_bankmomey,
   sa_weixinmoney,
   sa_alipaymoney,
   sa_storedmoney,sa_ac_ids,sa_ac_names
)
select 
    so.sa_id, so.sa_sh_id, so.sa_co_man, so.sa_date, so.sa_no, so.sa_vo, so.sa_ac_id, so.sa_order_man, so.sa_st_id, so.sa_update_man, so.sa_update_time, so.sa_add_man, so.sa_add_time, so.sa_audit_man, so.sa_audit_time, so.sa_status, so.sa_type, so.sa_type, so.sa_me_id, so.sa_remark, so.sa_in_id, so.sa_in_num, so.sa_get_in_num, so.sa_deduct_money, so.sa_sa_vo, so.sa_gift_vo, so.sa_in_money, so.sa_card_money, so.sa_shop_money, so.sa_money, so.sa_real_money, so.sa_charge_money, so.sa_surplus_money, so.sa_select, so.sa_sale_money, so.sa_change_money, so.sa_gift_money, so.sa_current_vo, so.sa_is_charge, so.sa_is_calculated,so.sa_paytype,so.pzone,so.pztwo,so.pzthree,so.sa_erp_id,so.sa_salman,so.sa_salmanname,
   so.sa_receivedmomey,
   so.sa_paidmomey,
   so.sa_cashmoney,
   so.sa_bankmomey,
   so.sa_weixinmoney,
   so.sa_alipaymoney,
   so.sa_storedmoney,so.sa_ac_ids,so.sa_ac_names
from pos_sale_temp as so
where so.sa_id=@sa_id

--merge into pos_sale as ta 
--using (select * from pos_sale_temp as so where so.sa_id=@sa_id) as so 
--on ta.sa_id=so.sa_id and ta.sa_id=@sa_id
--when not matched then 

--insert(
-- sa_id, sa_sh_id, sa_co_man, sa_date, sa_no, sa_vo, sa_ac_id, sa_order_man, sa_st_id, sa_update_man, sa_update_time, sa_add_man, sa_add_time, sa_audit_man, sa_audit_time, sa_status, sa_type, sa_sa_type, sa_me_id, sa_remark, sa_in_id, sa_in_num, sa_get_in_num, sa_deduct_money, sa_sa_vo, sa_gift_vo, sa_in_money, sa_card_money, sa_shop_money, sa_money, sa_real_money, sa_charge_money, sa_surplus_money, sa_select, sa_sale_money, sa_change_money, sa_gift_money, sa_current_vo, sa_is_charge, sa_is_calculated,sa_paytype,pzone,pztwo,pzthree,sa_erp_id,sa_salman,sa_salmanname,
--   sa_receivedmomey,
--   sa_paidmomey,
--   sa_cashmoney,
--   sa_bankmomey,
--   sa_weixinmoney,
--   sa_alipaymoney,
--   sa_storedmoney,sa_ac_ids,sa_ac_names
-- )values(
--  so.sa_id, so.sa_sh_id, so.sa_co_man, so.sa_date, so.sa_no, so.sa_vo, so.sa_ac_id, so.sa_order_man, so.sa_st_id, so.sa_update_man, so.sa_update_time, so.sa_add_man, so.sa_add_time, so.sa_audit_man, so.sa_audit_time, so.sa_status, so.sa_type, so.sa_type, so.sa_me_id, so.sa_remark, so.sa_in_id, so.sa_in_num, so.sa_get_in_num, so.sa_deduct_money, so.sa_sa_vo, so.sa_gift_vo, so.sa_in_money, so.sa_card_money, so.sa_shop_money, so.sa_money, so.sa_real_money, so.sa_charge_money, so.sa_surplus_money, so.sa_select, so.sa_sale_money, so.sa_change_money, so.sa_gift_money, so.sa_current_vo, so.sa_is_charge, so.sa_is_calculated,so.sa_paytype,so.pzone,so.pztwo,so.pzthree,so.sa_erp_id,so.sa_salman,so.sa_salmanname,
--   so.sa_receivedmomey,
--   so.sa_paidmomey,
--   so.sa_cashmoney,
--   so.sa_bankmomey,
--   so.sa_weixinmoney,
--   so.sa_alipaymoney,
--   so.sa_storedmoney,so.sa_ac_ids,so.sa_ac_names
--)
--when matched then update set ta.sa_sh_id=so.sa_sh_id,ta.sa_co_man=so.sa_co_man,ta.sa_date=so.sa_date,ta.sa_no=so.sa_no,ta.sa_vo=so.sa_vo,ta.sa_ac_id=so.sa_ac_id,ta.sa_order_man=so.sa_order_man,ta.sa_st_id=so.sa_st_id,ta.sa_update_man=so.sa_update_man,ta.sa_update_time=so.sa_update_time,ta.sa_add_man=so.sa_add_man,ta.sa_add_time=so.sa_add_time,ta.sa_audit_man=so.sa_audit_man,ta.sa_audit_time=so.sa_audit_time,ta.sa_status=so.sa_status,ta.sa_type=so.sa_type,ta.sa_sa_type=so.sa_sa_type,ta.sa_me_id=so.sa_me_id,ta.sa_remark=so.sa_remark,ta.sa_in_id=so.sa_in_id,ta.sa_in_num=so.sa_in_num,ta.sa_get_in_num=so.sa_get_in_num,ta.sa_deduct_money=so.sa_deduct_money,ta.sa_sa_vo=so.sa_sa_vo,ta.sa_gift_vo=so.sa_gift_vo,ta.sa_in_money=so.sa_in_money,ta.sa_card_money=so.sa_card_money,ta.sa_shop_money=so.sa_shop_money,ta.sa_money=so.sa_money,ta.sa_real_money=so.sa_real_money,ta.sa_charge_money=so.sa_charge_money,ta.sa_surplus_money=so.sa_surplus_money,ta.sa_select=so.sa_select,ta.sa_sale_money=so.sa_sale_money,ta.sa_change_money=so.sa_change_money,ta.sa_gift_money=so.sa_gift_money,ta.sa_current_vo=so.sa_current_vo,ta.sa_is_charge=so.sa_is_charge,ta.sa_is_calculated=so.sa_is_calculated,ta.sa_paytype=so.sa_paytype,
--ta.sa_erp_id=so.sa_erp_id,ta.pzone=so.pzone,ta.pztwo=so.pztwo,ta.pzthree=so.pzthree,ta.sa_salman=so.sa_salman,ta.sa_salmanname=so.sa_salmanname
--,
--ta.sa_receivedmomey=so.sa_receivedmomey,
--ta.sa_paidmomey=so.sa_paidmomey,
--ta.sa_cashmoney=so.sa_cashmoney,
--ta.sa_bankmomey=so.sa_bankmomey,
--ta.sa_weixinmoney=so.sa_weixinmoney,
--ta.sa_alipaymoney=so.sa_alipaymoney,
--ta.sa_storedmoney=so.sa_storedmoney,
--ta.sa_ac_ids=so.sa_ac_ids,
--ta.sa_ac_names=ta.sa_ac_names
--when not matched by source and ta.sa_id=@sa_id then delete; 

if @@ERROR<>0
BEGIN
	IF @@TRANCOUNT > 0 rollback tran;
	return;
end

	
delete pos_saleList where sal_sa_id=@sa_id
INSERT INTO pos_saleList(
sal_id, sal_sa_id, sal_gi_id, sal_sku_id, sal_num, sal_retail_price, sal_discount, sal_list_man, sal_real_price, sal_money, sal_deduct_money, sal_is_gift, sal_is_change, sal_is_tejia,sal_is_zhengjia,sal_is_in, sal_in_num, sal_remark, sal_status, sal_add_time, sal_is_return, sal_discount_old, sal_deduct_money_old, sal_real_price_old, sal_old_record, sal_is_active_gift,sal_remark2,sal_st_id,sal_erp_id,sal_customprice,sal_paiddiscount,sal_paidmomey,
sal_buyingteamid,sal_deduction,sal_acid,sal_returnedid,sal_in_money,sal_pkindex
)
select 
so.sal_id, so.sal_sa_id, so.sal_gi_id, so.sal_sku_id, so.sal_num, so.sal_retail_price, so.sal_discount, so.sal_list_man, so.sal_real_price, so.sal_money, so.sal_deduct_money, so.sal_is_gift, so.sal_is_change,so.sal_is_tejia,so.sal_is_zhengjia, so.sal_is_in, so.sal_in_num, so.sal_remark, so.sal_status, so.sal_add_time, so.sal_is_return, so.sal_discount_old, so.sal_deduct_money_old, so.sal_real_price_old, so.sal_old_record, so.sal_is_active_gift,so.sal_remark2,so.sal_st_id,so.sal_erp_id,so.sal_customprice,so.sal_paiddiscount,so.sal_paidmomey,
so.sal_buyingteamid,so.sal_deduction,so.sal_acid,so.sal_returnedid,so.sal_in_money,so.sal_pkindex
from pos_saleList_temp as so
where so.sal_sa_id=@sa_id 

--merge into pos_saleList as ta 
--using (select * from  pos_saleList_temp as ps where ps.sal_sa_id=@sa_id )as so 
--on ta.sal_id=so.sal_id and ta.sal_sa_id=@sa_id
--when not matched then insert(
--sal_id, sal_sa_id, sal_gi_id, sal_sku_id, sal_num, sal_retail_price, sal_discount, sal_list_man, sal_real_price, sal_money, sal_deduct_money, sal_is_gift, sal_is_change, sal_is_tejia,sal_is_zhengjia,sal_is_in, sal_in_num, sal_remark, sal_status, sal_add_time, sal_is_return, sal_discount_old, sal_deduct_money_old, sal_real_price_old, sal_old_record, sal_is_active_gift,sal_remark2,sal_st_id,sal_erp_id,sal_customprice,sal_paiddiscount,sal_paidmomey,
--sal_buyingteamid,sal_deduction,sal_acid,sal_returnedid,sal_in_money,sal_pkindex
--)values(
--so.sal_id, so.sal_sa_id, so.sal_gi_id, so.sal_sku_id, so.sal_num, so.sal_retail_price, so.sal_discount, so.sal_list_man, so.sal_real_price, so.sal_money, so.sal_deduct_money, so.sal_is_gift, so.sal_is_change,so.sal_is_tejia,so.sal_is_zhengjia, so.sal_is_in, so.sal_in_num, so.sal_remark, so.sal_status, so.sal_add_time, so.sal_is_return, so.sal_discount_old, so.sal_deduct_money_old, so.sal_real_price_old, so.sal_old_record, so.sal_is_active_gift,so.sal_remark2,so.sal_st_id,so.sal_erp_id,so.sal_customprice,so.sal_paiddiscount,so.sal_paidmomey,
--so.sal_buyingteamid,so.sal_deduction,so.sal_acid,so.sal_returnedid,so.sal_in_money,so.sal_pkindex
--)
--when matched then update set ta.sal_sa_id=so.sal_sa_id,ta.sal_gi_id=so.sal_gi_id,ta.sal_sku_id=so.sal_sku_id,ta.sal_num=so.sal_num,ta.sal_retail_price=so.sal_retail_price,ta.sal_discount=so.sal_discount,ta.sal_list_man=so.sal_list_man,ta.sal_real_price=so.sal_real_price,ta.sal_money=so.sal_money,ta.sal_deduct_money=so.sal_deduct_money,ta.sal_is_gift=so.sal_is_gift,ta.sal_is_change=so.sal_is_change,ta.sal_is_zhengjia=so.sal_is_zhengjia,ta.sal_is_tejia=so.sal_is_tejia,ta.sal_is_in=so.sal_is_in,ta.sal_in_num=so.sal_in_num,ta.sal_remark=so.sal_remark,ta.sal_status=so.sal_status,ta.sal_add_time=so.sal_add_time,ta.sal_is_return=so.sal_is_return,ta.sal_discount_old=so.sal_discount_old,ta.sal_deduct_money_old=so.sal_deduct_money_old,ta.sal_real_price_old=so.sal_real_price_old,ta.sal_old_record=so.sal_old_record,ta.sal_is_active_gift=so.sal_is_active_gift,ta.sal_remark2=so.sal_remark2,ta.sal_st_id=so.sal_st_id,ta.sal_erp_id=so.sal_erp_id,ta.sal_customprice=so.sal_customprice,
--  ta.sal_paiddiscount=so.sal_paiddiscount,
--  ta.sal_paidmomey=so.sal_paidmomey,
--  ta.sal_buyingteamid=so.sal_buyingteamid,
--  ta.sal_deduction=so.sal_deduction,
--  ta.sal_acid=so.sal_acid,
--  ta.sal_returnedid=so.sal_returnedid,
--  ta.sal_in_money=so.sal_in_money,
--  ta.sal_pkindex=so.sal_pkindex
--when not matched by source and ta.sal_sa_id=@sa_id then delete; 


--2018-6-4  写入固化表 BJW

delete z_pos_sale_detail where sa_id =@sa_id
INSERT INTO z_pos_sale_detail
			(specname
			,spec2
			,specno
			,gd_row_number
			,gss_no
			,gs_name
			,colorgroupname
			,color
			,specngroupname
			,spec
			,colorid
			,size
			,specid
			,gs_sampleno
			,sal_retail_money
			,gi_costprice
			,gi_costprice_money
			,sal_id
			,sal_customprice
			,sa_ac_names
			,sh_company
			,erp_id
			,gi_id
			,gi_skuid
			,gi_brandsid
			,gb_name
			,sal_gi_id
			,gi_attribute_parentids
			,gi_attribute_ids
			,gi_typesid
			,gi_types
			,gi_type1
			,gi_type2
			,gi_type3
			,gi_type4
			,gi_sampleno
			,gc_name1
			,gc_name2
			,gc_name3
			,gc_name4
			,vl_no
			,sa_id
			,sa_salman
			,sa_salmanname
			,sa_vo
			,sa_no
			,sa_month
			,sa_date
			,sei_name
			,sh_id
			,sa_sh_id
			,sa_sh_id_txt
			,sh_name
			,sh_no
			,gi_code
			,gi_name
			,gi_barcode
			,st_id
			,st_st_id
			,num
			,sa_paytype
			,sa_me_id
			,me_name
			,me_card
			,vip
			,sa_co_man_txt
			,sal_list_man_txt
			,sa_get_in_num
			,sa_current_vo
			,gi_unit
			,ut_name
			,sal_retail_price
			,sal_discount
			,sal_real_price
			,sal_num
			,sal_deduct_money
			,sal_money
			,saltype
			,sal_is_gift
			,sal_paidmomey
			,salpaidmomey
			,returnsalpaidmomey
			,salnum
			,returnsalnum
			,sa_add_man
			,sal_paiddiscount
			,sal_is_change
			,sal_is_return
			,sal_is_in
			,sal_remark
			,sal_remark2
			,sa_status
			,sa_st_id_txt
			,sa_st_id
			,sa_order_man_txt
			,sa_add_man_txt
			,sa_add_time
			,sa_update_man_txt
			,sa_update_time
			,sa_audit_man_txt
			,sa_audit_time
			,sal_add_time
			,sal_sku_id
			,oi_no
			,sal_buyingteamid
			,gi_buyingteam
			,gi_supplierid
			,gi_supplier
			,gi_purchase
			,gi_purchase_money
			,gi_costprice_z
			,sa_remark
			,rulecode
			,sizecode
			,colorcode)
SELECT specname
		,spec2
		,specno
		,gd_row_number
		,gss_no
		,gs_name
		,colorgroupname
		,color
		,specngroupname
		,spec
		,colorid
		,size
		,specid
		,gs_sampleno
		,sal_retail_money
		,gi_costprice
		,gi_costprice_money
		,sal_id
		,sal_customprice
		,sa_ac_names
		,sh_company
		,erp_id
		,gi_id
		,gi_skuid
		,gi_brandsid
		,gb_name
		,sal_gi_id
		,gi_attribute_parentids
		,gi_attribute_ids
		,gi_typesid
		,gi_types
		,gi_type1
		,gi_type2
		,gi_type3
		,gi_type4
		,gi_sampleno
		,gc_name1
		,gc_name2
		,gc_name3
		,gc_name4
		,vl_no
		,sa_id
		,sa_salman
		,sa_salmanname
		,sa_vo
		,sa_no
		,sa_month
		,sa_date
		,sei_name
		,sh_id
		,sa_sh_id
		,sa_sh_id_txt
		,sh_name
		,sh_no
		,gi_code
		,gi_name
		,gi_barcode
		,st_id
		,st_st_id
		,num
		,sa_paytype
		,sa_me_id
		,me_name
		,me_card
		,vip
		,sa_co_man_txt
		,sal_list_man_txt
		,sa_get_in_num
		,sa_current_vo
		,gi_unit
		,ut_name
		,sal_retail_price
		,sal_discount
		,sal_real_price
		,sal_num
		,sal_deduct_money
		,sal_money
		,saltype
		,sal_is_gift
		,sal_paidmomey
		,salpaidmomey
		,returnsalpaidmomey
		,salnum
		,returnsalnum
		,sa_add_man
		,sal_paiddiscount
		,sal_is_change
		,sal_is_return
		,sal_is_in
		,sal_remark
		,sal_remark2
		,sa_status
		,sa_st_id_txt
		,sa_st_id
		,sa_order_man_txt
		,sa_add_man_txt
		,sa_add_time
		,sa_update_man_txt
		,sa_update_time
		,sa_audit_man_txt
		,sa_audit_time
		,sal_add_time
		,sal_sku_id
		,oi_no
		,sal_buyingteamid
		,gi_buyingteam
		,gi_supplierid
		,gi_supplier
		,gi_purchase
		,gi_purchase_money
		,gi_costprice_z
		,sa_remark
		,rulecode
		,sizecode
		,colorcode
	FROM v_z_pos_sale_detail where sa_id=@sa_id and sa_status>0;
update pos_sale set sa_curing=1,sa_curingdate=getdate() where sa_id =@sa_id



if @@ERROR<>0
BEGIN
	IF @@TRANCOUNT > 0 rollback tran;
	return;
end
else
begin
	
	exec pro_recount_member
	@sa_id = @sa_id
	
	

declare @erpid int=0;
declare @cpid int=0;
declare @sa_vo varchar(255)='';--销售单号
select @erpid=sh_erp_id from pos_shop where sh_id=(SELECT [sa_sh_id] FROM pos_sale where [sa_id] =@sa_id)
select @sa_vo=sa_vo FROM pos_sale where [sa_id] =@sa_id;


DECLARE @tdoc_xml VARCHAR(max)= '';	
SET @tdoc_xml = '{ "said":"' + CONVERT(VARCHAR(50), @sa_id) + '","type":"2" }';
EXEC pro_apiqueue_op 
			@tdoc_target='',
			@tdoc_action='',
			@tdoc_method = 'royaltyscheme', 
			@tdoc_xml = @tdoc_xml, 
			@tdoc_erp_id =@erpid, 
			@tdoc_no=  @sa_vo ,
			@tdoc_state = 0;

			
SELECT top 1 @cpid=cp_id from companyinfo WHERE cp_erp_id=@erpid AND cp_is_zorf=1
EXEC pro_apiqueue_op 
			@tdoc_method = 'uploadmemberintegral', 
			@tdoc_xml = '', 
			@tdoc_erp_id =@erpid, 
			@tdoc_state = 0,
			@tdoc_cp_id=@cpid


	
	UPDATE pos_sale SET sa_real_money = fd2.ord_totalmoney
	FROM pos_sale fd,(
	SELECT ps.sa_id,nt.ord_totalmoney 
	FROM pos_sale_net psn WITH (NOLOCK) 
	INNER JOIN pos_sale ps  WITH (NOLOCK) 
	ON psn.sa_net_sa_id=ps.sa_id
	INNER JOIN netorder_tbl nt WITH (NOLOCK) 
	 ON psn.sa_net_ord_id=nt.ord_id
	WHERE psn.sa_net_sa_id=@sa_id
	) AS fd2 WHERE fd.sa_id=fd2.sa_id
	
	
	declare @sa_date datetime;
	declare @sa_sh_id int=0;
	DECLARE @vo VARCHAR(50)='';
	select @vo=sa_vo,@sa_date=pst.sa_date,@sa_sh_id=pst.sa_sh_id
	  from pos_sale_temp as pst
	where pst.sa_id=@sa_id;
	IF CHARINDEX('xs',@vo)=0
	BEGIN
		

	declare @myprevTxt varchar(50)='XS';

     declare @tableName varchar(50) = 'pos_sale'
     declare @idField varchar(50) = 'sa_id'
     declare @idValue int = @sa_id;
    
     declare @dateField varchar(50) = 'sa_date'
     declare @dateValue varchar(50) = convert(varchar(50),@sa_date, 23)
 
     declare @noField varchar(50) = 'sa_vo'
     declare @prevTxt varchar(50) = @myprevTxt
     declare @outno varchar(100) = ''
     declare @while int = 0;
     while @while = 0
     begin
         --得到凭证号
         execute [pro_gen_orderNo]@tableName,
              @idField,
              @idValue,
              @dateField,
              @dateValue,
              @noField,
              @prevTxt,
              @outno output,@sa_sh_id
         
         begin try
          --更新
          update pos_sale
          set sa_vo = @outno
		  	,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)

          where sa_id           = @sa_id;
          
          --更新成功,赋值,结束循环
          set @while = 1;
         end try
         begin catch
		 PRINT '';
          ----发生错误,判断错误类型
          --if charindex('重复键', error_message(), 0) = 0
          --begin
          --    --不是发生重复的错误
          --    --赋值,结束循环
          --    set @while = 1;
          --end
         end catch
     end
	
	eND
	
	
	IF EXISTS(
SELECT * FROM s_system_set s WHERE s.s_key='销售前台单据自动审核' and s_value=1)
BEGIN
	
	
	update pos_sale
		 set    sa_status = 2,
				sa_audit_man     =(SELECT ps.sa_add_man FROM pos_sale ps WHERE ps.sa_id=@sa_id),
				sa_audit_time       = getdate()
		 where  sa_id               = @sa_id;
	
	
END
	
	
	

--UPDATE pos_sale
--SET sa_paytype = fd2.ord_payway
--FROM pos_sale fd,(
--SELECT psn.sa_net_sa_id,nt.ord_payway FROM pos_sale_net psn
--INNER JOIN netorder_tbl nt ON psn.sa_net_ord_id=nt.ord_id
--) AS fd2 WHERE fd.sa_id=fd2.sa_net_sa_id


--UPDATE pos_sale_temp
--SET sa_paytype = fd2.ord_payway
--FROM pos_sale_temp fd,(
--SELECT psn.sa_net_sa_id,nt.ord_payway FROM pos_sale_net psn
--INNER JOIN netorder_tbl nt ON psn.sa_net_ord_id=nt.ord_id
--) AS fd2 WHERE fd.sa_id=fd2.sa_net_sa_id
	IF @@TRANCOUNT > 0 commit tran;
	return;
END

	return;
END
go

