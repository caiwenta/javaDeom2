CREATE FUNCTION [dbo].[FnPurchaseByFIFO]
(
	@pid UDTypeOrderId READONLY,
	@orderguid VARCHAR(5000),
	@erp_id int
)
RETURNS @pl TABLE (
	  pll_id INT,
      pll_pl_id INT,
      pll_gi_id INT,
      pll_sku_id INT,
      pll_add_time DATETIME,
      pll_num INT,
	  qty int,
	  pll_retail_price decimal(10,2),
	  pll_discount decimal(10,2),
	  pll_stock_price decimal(10,2)
)
AS
BEGIN

---控制允许超百分比
declare @maxinput float=0;
SELECT @maxinput=(case when s_value=1 then
case when s_othervalue<>'' then CAST(s_othervalue AS float) else 0 end
else 0
end)
FROM s_system_set AS sss 
WHERE sss.s_erp_id=@erp_id AND sss.s_key='AllowOverPurchasePer'

if @maxinput>0
	set @maxinput=@maxinput/100;


--获取要入库商品数量
DECLARE @in TABLE (
	gi_id INT, 
	sku_id INT,
	num INT,
	retailprice decimal(10,2),
	discount decimal(10,2),
	realprice decimal(10,2)
)
INSERT INTO @in	
SELECT 
gi_id,
sku_id,
SUM(number),
max(retailprice),
max(discount),
max(purchase) FROM erp_goodslisttemp AS eg 
WHERE eg.orderguid=@orderguid 
GROUP BY gi_id,sku_id



--要分配的采购
INSERT INTO @pl
SELECT 
pll_id,
pll_pl_id,
pll_gi_id,
pll_sku_id,
pll_add_time,
(
floor(isnull(pll_num,0)*@maxinput+ isnull(pll_num,0))
-isnull((SELECT sum(el_number) FROM j_enterStorageList jesl 
INNER JOIN j_enterStorage AS jes ON jes.eo_id = jesl.el_eoid WHERE jes.eo_source_type=1 and jes.eo_status > 0 and jesl.el_source_id=st.pll_id AND jesl.el_status<>0 ),0) 
-isnull(st.pll_pause_num,0)
) AS pll_num,
0,
pll_retail_price,
pll_discount,
pll_stock_price
FROM j_purchaseStorageList AS st 
INNER JOIN @pid p ON st.pll_pl_id=p.id
WHERE  st.pll_status>0

--先进先出
update @pl set qty=(
CASE WHEN 
   (select i.num-isnull(sum(pt.pll_num),0) FROM @pl pt WHERE pt.pll_id<=ps.pll_id AND pt.pll_gi_id=ps.pll_gi_id AND pt.pll_sku_id=ps.pll_sku_id )>=0 THEN ps.pll_num
ELSE( 
CASE WHEN 
   (SELECT i.num-isnull(sum(pt.pll_num),0) FROM @pl pt WHERE pt.pll_id<ps.pll_id AND pt.pll_gi_id=ps.pll_gi_id AND pt.pll_sku_id=ps.pll_sku_id )<0
 then 0
 ELSE
   (SELECT i.num-isnull(sum(pt.pll_num),0) FROM @pl pt WHERE pt.pll_id<ps.pll_id AND pt.pll_gi_id=ps.pll_gi_id AND pt.pll_sku_id=ps.pll_sku_id )
 END)
END
)
FROM @pl AS ps
INNER JOIN @in AS i ON ps.pll_gi_id=i.gi_id AND ps.pll_sku_id=i.sku_id

--删除没分配到的采购
delete @pl where qty=0;


	RETURN
END
go

