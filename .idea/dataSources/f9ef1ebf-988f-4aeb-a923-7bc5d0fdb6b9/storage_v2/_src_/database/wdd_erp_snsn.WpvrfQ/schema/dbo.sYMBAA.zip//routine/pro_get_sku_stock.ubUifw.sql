CREATE PROC [dbo].[pro_get_sku_stock]
       @sei_id INT = 0 ,
       @date DATETIME = '2004-12-13' ,
       @gi_id INT = 0 ,
       @sh_id INT = 0 ,
       @customPricename VARCHAR(50) = '' OUT ,
       @cp_memberdiscount INT OUT ,
       @cp_membermoney INT OUT ,--0:零售价 1:销售价
       @cp_update_type INT OUT,
	   @gr_id int=0,
	   @gi_skuid int=0
AS
BEGIN

      DECLARE @skus VARCHAR(50)= '';
      DECLARE @is_custom INT= 0;
      DECLARE @isruleprice INT= 0;--是否同步规格价格
      DECLARE @cplid INT= 0;--调价id

      SELECT    @skus = bg.gi_skus ,
                @cp_memberdiscount = gi_memberdiscount
      FROM      b_goodsinfo AS bg WITH (NOLOCK)
      WHERE     bg.gi_id = @gi_id;

	  --获取调价商品
      SELECT    @cplid = cpl_id ,
                @isruleprice = isruleprice ,
                @customPricename = cp_name ,
                @cp_memberdiscount = (CASE WHEN cp_memberdiscount = 0 THEN (SELECT  gi_memberdiscount
                                                                            FROM    b_goodsinfo AS bg
                                                                            WHERE   bg.gi_id = @gi_id
                                                                           )
                                           ELSE cp_memberdiscount
                                      END) ,
                @cp_membermoney = cp_membermoney ,
                @cp_update_type = cp_update_type
      FROM      
	  (
				SELECT TOP 1
                        cppl.cpl_id ,
                        cppl.isruleprice ,
                        pcp.cp_name ,
                        cp_memberdiscount ,
                        cp_membermoney ,
                        cp_update_type
                 FROM   pos_customPriceList AS cppl WITH (NOLOCK)
                 INNER JOIN pos_customPrice AS pcp WITH (NOLOCK) ON pcp.cp_id = cppl.cpl_cp_id AND pcp.cp_status = 2
                 INNER JOIN pos_customPriceShop AS pcps WITH (NOLOCK) ON pcps.s_cp_id = cppl.cpl_cp_id
                 WHERE  pcps.s_shid = @sh_id
                        AND cppl.cpl_gi_id = @gi_id
                        AND pcp.cp_start <= @date
                        AND pcp.cp_end >= @date
						AND (pcp.gr_id=@gr_id or pcp.gr_id=0 or pcp.gr_id=(case when @gr_id>0 then -2 else -1 end))--0:所有客户  -2:会员客户  -1:零售客户
                 ORDER BY pcp.cp_add_time DESC
       ) TT
     
	  IF @cplid > 0
         BEGIN
               SET @is_custom = 1;
         END
      ELSE
         BEGIN 
               SET @is_custom = 0;
         END




    DECLARE @sh_goods_type INT = 0;
    DECLARE @gd_price DECIMAL(10, 2) = 0;

	DECLARE @update_type INT = 1;
    DECLARE @price DECIMAL(10, 2) = 0;

 --没有规格商品  
IF @skus = ''
begin

   SELECT
   ISNULL(js.enable_stock_num,0) as enable_stock_num ,
   ISNULL(js.sub_enable_stock_num,0) AS sub_enable_stock_num ,
   ISNULL(js.stock_num,0) AS stock_num ,
   have_custom_price = 0 ,
   update_type = 1,
   gi_discount=1.00,
   bg.*,
   gi_retailprice as gi_oldretailprice,
   1.00 as gi_olddiscount,
   gi_importprices as gi_oldimportprices
   INTO  #noskugoods
   FROM b_goodsinfo AS bg WITH (NOLOCK)
   LEFT JOIN (
   SELECT js.st_gi_id,
       SUM(js.st_num)  AS stock_num,
       SUM(js.st_num - ISNULL(js.st_occupy_num, 0)) AS enable_stock_num,	--pos总的可用库存
       (SELECT SUM(si_number -(ISNULL(si_occupy_num, 0) + ISNULL(si_allocationoccupy_num, 0)+ ISNULL(si_orderblankoccupy_num, 0))) AS enable_stock
        FROM b_stockinfo bs WITH (NOLOCK) WHERE  bs.si_status <> 0
             AND bs.si_giid = js.st_gi_id AND bs.si_skuid = 0
       ) AS sub_enable_stock_num --总部总的可用库存
	FROM pos_stockInfo AS js WITH (NOLOCK)
	WHERE js.st_st_id = @sei_id AND js.st_gi_id = @gi_id AND js.st_sku_id =0
	GROUP BY js.st_gi_id
   ) AS js ON bg.gi_id = js.st_gi_id
   WHERE  bg.gi_id = @gi_id

   ---获取商品的吊牌价
   SELECT TOP 1 @sh_goods_type = sh_goods_type FROM pos_shop WITH (NOLOCK) WHERE  sh_id = @sh_id
   IF @sh_goods_type > 0
    BEGIN

        SELECT TOP 1
               @gd_price = gd_price
        FROM   b_goods_discount WITH (NOLOCK)
        WHERE  gd_gi_id = @gi_id AND gd_type= @sh_goods_type AND gd_class= 1
        
        UPDATE #noskugoods
        SET    gi_retailprice        = @gd_price,
               gi_oldretailprice     = @gd_price;
    END

	--商品调价
   IF @is_custom = 1
	begin
			--设置介格
            SELECT pcpl.cpl_gi_id,
                   pcp.cp_update_type  AS cpl_update_type,
                   cpl_retail_price,
                   cpl_discount,
                   cpl_stock_price
            INTO   #noskuP
            FROM   pos_customPrice     AS pcp WITH (NOLOCK)
                   INNER JOIN pos_customPriceList AS pcpl WITH (NOLOCK)
                        ON  pcp.cp_id = pcpl.cpl_cp_id
            WHERE  pcpl.cpl_id = @cplid
                   AND pcp.cp_status = 2
                   AND pcpl.cpl_gi_id = @gi_id
                   AND pcp.cp_start <= @date
                   AND pcp.cp_end >= @date
            ORDER BY
                   pcp.cp_add_time DESC,
                   pcp.cp_update_time DESC  

			SELECT TOP 1
                   @update_type = #noskuP.cpl_update_type
            FROM   #noskuP

		    UPDATE #noskugoods SET  update_type = @update_type; 

			IF @update_type = 1
            BEGIN
                SELECT TOP 1
                       @price = #noskuP.cpl_retail_price
                FROM   #noskuP
                
                UPDATE #noskugoods
                SET    gi_retailprice        = @price,
                       have_custom_price     = 1;
            END
            ELSE
            IF @update_type = 2
            BEGIN

                SELECT TOP 1
                       @price = #noskuP.cpl_discount
                FROM   #noskuP
                
                UPDATE #noskugoods
                SET    gi_discount           = @price,
                       have_custom_price     = 1;
            END
            ELSE
            IF @update_type = 3
            BEGIN
                SELECT TOP 1
                       @price = #noskuP.cpl_stock_price
                FROM   #noskuP
                
                UPDATE #noskugoods
                SET    gi_importprices           = @price,
                       have_custom_price     = 1;
            END
	end

   SELECT * FROM  #noskugoods 
end

 --有规格商品  
IF @skus != ''
BEGIN
      
	--商品存库 #goods
    SELECT   ISNULL(js.enable_stock_num,0) as enable_stock_num ,
                        ISNULL(js.sub_enable_stock_num,0) AS sub_enable_stock_num ,
                        bg.* ,
						bg.gs_salesprice as gs_oldsalesprice,
						bg.gs_marketprice as gs_oldmarketprice,
						bg.gs_discount as gs_olddiscount,
                        ISNULL(js.stock_num,0) AS stock_num ,
                        have_custom_price = 0 ,
                        update_type = 1
               INTO     #goods
               FROM     b_goodsruleset AS bg WITH (NOLOCK)
               LEFT JOIN (SELECT    js.st_gi_id ,
                                    js.st_sku_id ,
                                    sum(js.st_num) AS stock_num ,
									SUM(js.st_num - ISNULL(js.st_occupy_num,0)) AS enable_stock_num,--pos总的可用库存
									(SELECT SUM(si_number - (ISNULL(si_occupy_num,0)+ISNULL(si_allocationoccupy_num,0)+ISNULL(si_orderblankoccupy_num,0))) 
									AS enable_stock
									FROM  b_stockinfo bs WITH (NOLOCK) WHERE  bs.si_status <> 0 AND bs.si_giid =js.st_gi_id AND si_skuid = js.st_sku_id
                                    ) AS sub_enable_stock_num --总部总的可用库存
                          FROM      pos_stockInfo AS js WITH (NOLOCK)
                          WHERE     js.st_st_id = @sei_id
                                    AND js.st_gi_id = @gi_id
									AND js.st_sku_id=(CASE WHEN @gi_skuid > 0 THEN  @gi_skuid  ELSE js.st_sku_id END)
                          GROUP BY  js.st_gi_id,js.st_sku_id
                         ) AS js ON bg.gi_id = js.st_gi_id AND bg.gss_id = js.st_sku_id
    WHERE    bg.gi_id = @gi_id and bg.gss_id=(CASE WHEN @gi_skuid > 0 THEN  @gi_skuid  ELSE bg.gss_id END)


    ---获取商品的吊牌价
    SELECT TOP 1 @sh_goods_type = sh_goods_type FROM pos_shop WITH (NOLOCK) WHERE  sh_id = @sh_id
    IF @sh_goods_type > 0
    BEGIN

        SELECT TOP 1
               @gd_price = gd_price
        FROM   b_goods_discount WITH (NOLOCK)
        WHERE  gd_gi_id         = @gi_id
               AND gd_type      = @sh_goods_type
               AND gd_class     = 1
        
        UPDATE #goods
        SET    gs_marketprice        = @gd_price,
               gs_oldmarketprice     = @gd_price;
    END
    
	--商品调价
    IF @is_custom = 1
    BEGIN
        --按规格商品
        IF (@isruleprice = 0)
        BEGIN
            SELECT pcpl.cpl_gi_id,
                   pcpl.cpl_skuid,
                   pcp.cp_update_type  AS cpl_update_type,
                   cpl_retail_price,
                   cpl_discount,
                   cpl_stock_price
            INTO                          #pk
            FROM   pos_customPrice     AS pcp WITH (NOLOCK)
                   INNER JOIN pos_customPriceSkuList AS pcpl WITH (NOLOCK)
                        ON  pcp.cp_id = pcpl.cpl_cp_id
            WHERE  pcpl.cpl_cpl_id = @cplid
                   AND pcp.cp_status = 2
                   AND pcpl.cpl_gi_id = @gi_id
                   AND pcp.cp_start <= @date
                   AND pcp.cp_end >= @date
            ORDER BY
                   pcp.cp_add_time DESC,
                   pcp.cp_update_time DESC   
            
            SELECT (CASE WHEN cpl_update_type = 1 THEN cpl_retail_price ELSE gs_marketprice END )  AS gs_marketprice,
                   (CASE WHEN cpl_update_type = 2 THEN cpl_discount ELSE gs_discount END )  AS gs_discount,
                   (CASE WHEN cpl_update_type = 3 THEN cpl_stock_price ELSE gs_salesprice END )  AS gs_purchase,
                   (CASE WHEN cpl_update_type IS NULL THEN 0 ELSE 1 END) AS have_custom_price,
                   (CASE WHEN cpl_update_type IS NULL THEN 0 ELSE cpl_update_type END )  AS update_type,
                   enable_stock_num,
                   sub_enable_stock_num,
                   stock_num,
                   gss_id,
                   gi_id,
                   gss_no,
                   gs_id,
                   gs_name,
                   gs_stock,
                   gs_salesprice,
                   gs_costprice,
                   gs_weight,
                   gs_upstock,
                   gs_downstork,
                   gs_alarmstock,
                   gs_columnid,
                   gs_is_custom,
                   gs_oldsalesprice,
                   gs_oldmarketprice,
                   gs_olddiscount,
                   gss_cp_id,
                   gss_di_id,
                   gs_status,
                   dzd_gssid,
                   gs_integral,
                   gss_erp_id
            FROM   #goods
                   LEFT JOIN #pk
                        ON  #pk.cpl_skuid = #goods.gss_id
        END
        ELSE
        BEGIN
            --同步规格调价 按商品
            SELECT pcpl.cpl_gi_id,
                   pcp.cp_update_type  AS cpl_update_type,
                   cpl_retail_price,
                   cpl_discount,
                   cpl_stock_price
            INTO                          #p
            FROM   pos_customPrice     AS pcp WITH (NOLOCK)
                   INNER JOIN pos_customPriceList AS pcpl WITH (NOLOCK)
                        ON  pcp.cp_id = pcpl.cpl_cp_id
            WHERE  pcpl.cpl_id = @cplid
                   AND pcp.cp_status = 2
                   AND pcpl.cpl_gi_id = @gi_id
                   AND pcp.cp_start <= @date
                   AND pcp.cp_end >= @date
            ORDER BY
                   pcp.cp_add_time DESC,
                   pcp.cp_update_time DESC  
            
            SELECT TOP 1
                   @update_type = #p.cpl_update_type
            FROM   #p
            
            UPDATE #goods SET    update_type = @update_type; 
            
            IF @update_type = 1
            BEGIN
                SELECT TOP 1
                       @price = #p.cpl_retail_price
                FROM   #p
                
                UPDATE #goods
                SET    gs_marketprice        = @price,
                       have_custom_price     = 1;
            END
            ELSE
            IF @update_type = 2
            BEGIN
                SELECT TOP 1
                       @price = #p.cpl_discount
                FROM   #p
                
                UPDATE #goods
                SET    gs_discount           = @price,
                       have_custom_price     = 1;
            END
            ELSE
            IF @update_type = 3
            BEGIN
                SELECT TOP 1
                       @price = #p.cpl_stock_price
                FROM   #p
                
                UPDATE #goods
                SET    gs_purchase           = @price,
                       have_custom_price     = 1;
            END

            SELECT * FROM   #goods
        END
    END
    ELSE
    BEGIN
        SELECT * FROM   #goods
    END
END

 
END
go

