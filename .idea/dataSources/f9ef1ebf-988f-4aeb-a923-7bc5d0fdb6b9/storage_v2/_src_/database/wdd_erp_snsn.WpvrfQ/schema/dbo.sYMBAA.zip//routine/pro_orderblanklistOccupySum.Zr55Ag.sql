CREATE PROCEDURE [dbo].[pro_orderblanklistOccupySum]
	@mo_id int = 0,@type int=0
AS
BEGIN
	 TRAN
if @type>0
begin
UPDATE j_orderblank
SET   mo_status = 3
WHERE mo_id = @mo_id;
end


MERGE INTO b_stockinfo AS ta 
USING
(



SELECT
ob.mo_cp_id ,
obl.mol_gi_id as gi_id,
obl.mol_sku_id as skuid,
ob.mo_out_st_id as sei_id,
SUM((CASE WHEN ob.mo_status=2 and obl.mol_status=1 THEN mol_num ELSE 0 end))  AS occupynum --ob.mo_status=1 or
FROM j_orderblank AS ob
INNER JOIN j_orderblanklist AS obl ON ob.mo_id=obl.mol_mo_id  AND ob.mo_type=0
INNER JOIN(

SELECT 
obl.mol_gi_id,obl.mol_sku_id,mo_out_st_id
FROM j_orderblank AS ob
INNER JOIN j_orderblanklist AS obl ON ob.mo_id=obl.mol_mo_id  AND ob.mo_type=0
WHERE ob.mo_id=@mo_id
GROUP BY obl.mol_gi_id,obl.mol_sku_id,mo_out_st_id
) AS t2 ON ob.mo_out_st_id=t2.mo_out_st_id and obl.mol_gi_id=t2.mol_gi_id AND obl.mol_sku_id=t2.mol_sku_id
GROUP BY obl.mol_gi_id,obl.mol_sku_id,ob.mo_out_st_id,ob.mo_cp_id


) as so ON ta.si_giid=so.gi_id and ta.si_skuid=so.skuid AND ta.si_seiid=so.sei_id 
WHEN MATCHED THEN  
UPDATE SET ta.si_orderblankoccupy_num =so.occupynum
WHEN NOT matched THEN
INSERT ( si_seiid, si_giid, si_skuid, si_number, si_orderblankoccupy_num, si_status, si_indate, si_cp_id )
VALUES ( so.sei_id, so.gi_id, so.skuid, 0, so.occupynum, 1, GETDATE(), so.mo_cp_id );


IF @@ERROR <> 0
BEGIN
    ROLLBACK TRAN
END
ELSE
BEGIN
    COMMIT TRAN
END
go

