


CREATE VIEW [dbo].[vi_stockList_createmonthly] AS 

SELECT *
FROM   (
           SELECT fd.[sid],
                  fd.cid,
                  fd.gid,
                  fd.orderno,
                  fd.order_date,
                  fd.order_add_time,
                  CONVERT(VARCHAR(100), fd.addtime, 25) AS addtime,
                  fd.myremark,
				  fd.mytype,
                  SUM(CASE WHEN countType = 1 THEN gnum ELSE -gnum END) 
                  AS gnum,
                  SUM(CASE WHEN countType = 1 THEN allmoney 
                  ELSE -allmoney END) AS 
                  allmoney
           FROM   vi_stockList_monthly AS fd
           GROUP BY
                  fd.[sid],
                  fd.cid,
                  fd.gid,
                  fd.orderno,
                  fd.order_date,
                  fd.order_add_time,
                  fd.myremark,
				  fd.mytype,
                  fd.addtime
       )                        AS fd
       INNER JOIN b_goodsinfo bg
            ON  fd.gid = bg.gi_id
       INNER JOIN b_storageinfo  AS bs
            ON  fd.[sid] = bs.sei_id
go

