CREATE function [dbo].[getgoodsprice](@no varchar(50),@i int)
returns decimal(10,2)
as
begin
	declare @gs_salesprice decimal(10,2),@gs_marketprice decimal(10,2),@gs_costprice decimal(10,2),@gs_weight decimal(10,2),@rest decimal(10,2)
	select top 1 @gs_salesprice=gs_salesprice,@gs_marketprice=gs_marketprice,@gs_costprice=gs_costprice,@gs_weight=gs_weight from b_goodsruleset where gss_no=@no
	if @i=0 begin
		set @rest=@gs_salesprice
	end else if(@i=1) begin
		set @rest=@gs_marketprice
	end else if(@i=2) begin
		set @rest=@gs_costprice
	end else if(@i=3) begin
		set @rest=@gs_weight
	end
	return @rest
end
go

