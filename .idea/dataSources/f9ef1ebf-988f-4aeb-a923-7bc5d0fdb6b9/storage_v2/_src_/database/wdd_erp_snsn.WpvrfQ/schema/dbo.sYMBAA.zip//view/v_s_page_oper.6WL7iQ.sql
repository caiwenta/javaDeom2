CREATE VIEW dbo.v_s_page_oper
AS
SELECT     dbo.s_page_oper.*, dbo.s_pageInfo.pi_name, dbo.s_oper_info.oi_name
FROM         dbo.s_page_oper INNER JOIN
                      dbo.s_pageInfo ON dbo.s_page_oper.po_pi_id = dbo.s_pageInfo.pi_id INNER JOIN
                      dbo.s_oper_info ON dbo.s_page_oper.po_oi_id = dbo.s_oper_info.oi_id
go

