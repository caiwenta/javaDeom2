CREATE VIEW [dbo].[vi_s_power_page_info] AS 
select sri.ri_id,spi.pi_id
    from s_role_info as sri left join s_pageInfo as spi on 1=1 where spi.pi_status=1
go

