CREATE FUNCTION [dbo].[FnNumCol]
(
	@beginNum int,
    @endNum int
)
RETURNS @returntable TABLE
(
    num int,
	moon varchar(10)
)
AS
BEGIN
	 while(@beginNum<=@endNum)
    begin
        insert into @returntable select @beginNum,CONVERT(varchar(10), @beginNum)+'月'
		set @beginNum=@beginNum+1
    end;    
    RETURN
END
go

