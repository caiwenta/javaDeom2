
CREATE Proc [dbo].[pro_del_merge]
@oc_id int,
@timestamp datetime
as

DELETE FROM s_goodsbrand_merge WHERE gb_id NOT IN (
SELECT MIN(gb_id) AS gb_id FROM s_goodsbrand_merge WHERE gb_oc_id=@oc_id AND gb_timestamp=@timestamp
GROUP BY gb_type_id
) AND gb_oc_id=@oc_id AND gb_timestamp=@timestamp;


DELETE FROM s_goodsclass_merge WHERE gc_id NOT IN (
SELECT MIN(gc_id) AS gc_id FROM s_goodsclass_merge WHERE gc_oc_id=@oc_id AND gc_timestamp=@timestamp
GROUP BY gc_type_id
) AND gc_oc_id=@oc_id AND gc_timestamp=@timestamp;


DELETE FROM s_goodsrule_merge WHERE gs_id NOT IN (
SELECT MIN(gs_id) AS gs_id FROM s_goodsrule_merge WHERE gs_oc_id=@oc_id AND gs_timestamp=@timestamp
GROUP BY gs_class_id
) AND gs_oc_id=@oc_id AND gs_timestamp=@timestamp;

DELETE FROM s_goodsruledetail_merge WHERE gd_id NOT IN (
SELECT MIN(gd_id) AS gd_id FROM s_goodsruledetail_merge WHERE gd_oc_id=@oc_id AND gd_timestamp=@timestamp
GROUP BY gd_type_id
) AND gd_oc_id=@oc_id AND gd_timestamp=@timestamp;

DELETE FROM b_goodsinfo_merge WHERE gi_id NOT IN (
SELECT MIN(gi_id) AS gi_id FROM b_goodsinfo_merge WHERE gi_oc_id=@oc_id AND gi_timestamp=@timestamp
GROUP BY gi_class_id
) AND gi_oc_id=@oc_id AND gi_timestamp=@timestamp;


DELETE FROM b_goodsruleset_merge WHERE gss_id NOT IN (
SELECT MIN(gss_id) AS gss_id FROM b_goodsruleset_merge WHERE gs_oc_id=@oc_id AND gs_timestamp=@timestamp
GROUP BY gs_type_id
) AND gs_oc_id=@oc_id AND gs_timestamp=@timestamp;
go

