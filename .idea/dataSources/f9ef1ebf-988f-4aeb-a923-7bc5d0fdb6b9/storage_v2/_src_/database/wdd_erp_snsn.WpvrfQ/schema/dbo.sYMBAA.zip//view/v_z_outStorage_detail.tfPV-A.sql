CREATE  VIEW [dbo].[v_z_outStorage_detail]
AS
SELECT  '' AS specname ,--暂时为空 
        (CASE WHEN rulenum.gd_row_number IS NULL THEN '' ELSE 'spec' + CONVERT(VARCHAR,rulenum.gd_row_number) END) AS spec2 ,
		(CASE WHEN rulenum.gd_row_number IS NULL THEN '' ELSE 'spec' + CONVERT(VARCHAR,rulenum.gd_row_number) END) AS specno ,
        rulenum.gd_row_number ,
        poutlist.* ,
        (poutlist.sh_name + poutlist.ci_name+poutlist.cp_name) AS sh_ci_name ,--店铺&客户
        (poutlist.sh_no + poutlist.ci_code+poutlist.cp_code) AS sh_ci_code, --店铺&客户代号
		rulenum.gd_code as rulecode,
		rulenum.gd_code as sizecode,
		colorrule.gd_code as colorcode
FROM    (
		SELECT ISNULL(grl.gss_no,'') AS gss_no ,--规格编码,
				ISNULL(grl.colorname,'') AS color , --grl.rulename1
                ISNULL(grl.specname,'') AS spec ,---grl.rulename1
				ISNULL(grl.colorid,0) as colorid,
                ISNULL(grl.specid,0) AS size ,  --rule1
                ISNULL(grl.specngroupid,0) AS specid ,--group1
                pout.*
         FROM   (
						SELECT 
						st.ol_id,
						ge.oo_id ,
                        ge.oo_cp_id ,
						(SELECT cp_code FROM [companyinfo] WHERE cp_id=ge.oo_cp_id) as oo_cp_code,
						(SELECT cp_name FROM [companyinfo] WHERE cp_id=ge.oo_cp_id) as oo_cp_name,
                        sg.sei_erp_id AS erp_id ,
                        ge.oo_no ,--凭证号
                        ISNULL(st.ol_gift,0) AS ol_gift ,--赠送
                        (CASE WHEN ISNULL(st.ol_gift,0) = 0 THEN '否' ELSE '是' END) AS gift ,--赠送
                        ge.oo_manual ,--单据号
                        CONVERT(VARCHAR(100),ge.oo_entrydate,23) AS oo_entrydate ,--出货日期
                        ge.oo_status ,--单据状态
						( CASE WHEN ge.oo_status = 1 THEN '未审核' WHEN ge.oo_status = 2 THEN '已审核' END ) as oostatus,
                        sg.sei_name ,--仓库
                        sg.sei_id ,
                        gi.gi_id ,
                        st.ol_siid ,
                        st.ol_pm ,--配码
                        gi.gi_attribute_parentids ,
                        gi.gi_attribute_ids ,
                        gi.gi_typesid ,
                        gi.gi_types ,
						gi.gi_type1,
						gi.gi_type2,
						gi.gi_type3,
						gi.gi_type4,
                        gi.gi_skuid ,
                        gi.gi_brands ,
                        gi.gi_brandsid ,
                        gi.gi_code ,--商品编号
                        gi.gi_name ,--商品名称
                        gi.gi_barcode ,--商品条形码
                        gi.gi_purchase,--商品表的进货价
                        ISNULL(((CASE WHEN ge.oo_type = 0 THEN -st.ol_number ELSE st.ol_number END) * gi_purchase),0) AS gi_purchase_money ,--进货金额
                        (select si_name from b_stafftinfo where si_id=ol_buyingteamid) as gi_buyingteam,--买手小组
                        (select si_name from b_supplierinfo where si_id=gi.gi_supplierid) as gi_supplier,--供应商
                        (select (CASE WHEN si_royaltytype=1 THEN '现金供应商' 
                                      WHEN si_royaltytype=2 THEN '代销供应商' end) from b_supplierinfo where si_id=gi.gi_supplierid) as si_royaltytype,--分润类型
                        ISNULL(st.ol_number,0) AS num ,--规格数量
                        
                        (case when oo_ciid<>0 then 1 when oo_sh_id <>0 then 2 when oo_to_cp_id<>0 then 3 end)oo_object,--出库对象，1-客户  2-店铺  3-分公司
                        
                        ge.oo_ciid ,
                        ISNULL(ci.ci_name,'') AS ci_name ,--客户
                        ISNULL(ci.ci_code,'') AS ci_code ,--客户代号
						(select type_name from cors_type where type_id= ci.ci_flid) as ci_type,--客户分类
                        ge.oo_sh_id ,
                        ISNULL(ps.sh_name,'') AS sh_name ,--店铺
                        ISNULL(ps.sh_name,'') AS oo_sh_id_txt ,
                        ISNULL(ps.sh_no,'') AS sh_no ,--店铺代号
                        ISNULL(ps.type,'') AS sh_type ,--店铺类型
						(
						CASE WHEN  ps.type = 1 THEN '加盟专卖店'
						     WHEN  ps.type = 2 THEN '联营专卖店'
							 WHEN  ps.type = 3 THEN '直营专卖店'
							 WHEN  ps.type = 4 THEN '托管专卖店'
							 WHEN  ps.type = 5 THEN '代理商'
							 WHEN  ps.type = 6 THEN '直营分公司'
						     WHEN  ps.type = 7 THEN '联营分公司'
							 WHEN  ps.type = 8 THEN '总公司'
							 WHEN  ps.type = 9 THEN '特价专卖店'
							 end
						) pstype,
                        ps.sh_clientname ,
                        ps.sh_attribute_ids ,
                        ps.sh_attribute_parentids ,
                        ge.oo_to_cp_id ,
                        ISNULL(cp.cp_name,'') AS cp_name ,--分公司
                        ISNULL(cp.cp_code,'') AS cp_code ,--分公司代号
                        ISNULL(cp.cp_code,'') AS oo_to_cp_id_txt ,--分公司代号
                        ui.ut_name ,--单位
                        ISNULL((CASE WHEN ge.oo_type = 0 THEN -st.ol_number ELSE st.ol_number END),0) AS ol_number ,--数量
			

                        ISNULL(gi.gi_costprice,0) AS gi_costprice ,--成本价
						ISNULL(((CASE WHEN ge.oo_type = 0 THEN -st.ol_number ELSE st.ol_number END) * gi.gi_costprice),0) AS gi_costprice_money ,--成本金额


                        ISNULL(st.ol_unit,0) AS ol_unit ,--零售价
                        ISNULL(st.ol_discount,0) AS ol_discount ,--折率
                        ISNULL(st.ol_costprice,0) AS ol_costprice ,--供货价

                        ISNULL((CASE WHEN ge.oo_type = 0 THEN -st.ol_realmoney ELSE st.ol_realmoney END),0) AS ol_realmoney ,--出库金额
                        ISNULL(((CASE WHEN ge.oo_type = 0 THEN -st.ol_number ELSE st.ol_number END) * st.ol_unit),0) AS ol_unit_money ,--零售金额
                        ISNULL(st.ol_box_num,0) AS ol_box_num , --箱数


						ISNULL((CASE WHEN ge.oo_type = 0 THEN 0 ELSE st.ol_realmoney END),0) AS oo_realmoney ,--出库金额
						ISNULL((CASE WHEN ge.oo_type = 0 THEN 0 ELSE st.ol_number END),0) AS oo_num ,--出库数量 
                                           
						ISNULL((CASE WHEN ge.oo_type = 0 THEN -st.ol_realmoney ELSE 0 END),0) AS oo_returnrealmoney ,--退货金额
						ISNULL((CASE WHEN ge.oo_type = 0 THEN -st.ol_number  ELSE 0 END),0) AS oo_returnnum, --退货数量                                                                

						ISNULL((CASE WHEN ge.oo_type = 0 THEN -st.ol_realmoney ELSE st.ol_realmoney END),0) AS realmoney ,--合计金额
					



                        st.ol_skuid ,
                        (case oo_source_type when 1 then (SELECT  al_vo FROM  pos_allocation AS bs WITH ( NOLOCK ) WHERE   al_id = oo_source_id )
											  when 2 then (SELECT eo_no FROM  j_enterStorage AS bs WITH ( NOLOCK ) WHERE  eo_id = oo_source_id )
											  when 3 then (SELECT  in_vo FROM   pos_inStorage AS bs WITH ( NOLOCK ) WHERE  in_id = oo_source_id )
						 else '' end ) AS al_vo ,
                        ui.ut_name AS gi_unit ,--单位
                        ol_addtime , --单据商品添加时间
                        takeman ,    --经手人
                        oo_jytype ,--交易类型
						(CASE WHEN oo_jytype = 1 THEN '订货' WHEN oo_jytype = 2 THEN '补货' WHEN oo_jytype = 3 THEN '铺货' WHEN oo_jytype = 4 THEN '买断' end ) oojytype,
                        oo_freight ,--垫付运费
                        oo_cost ,--其他应收
                        (CASE WHEN oo_type = 0 THEN '退货' WHEN oo_type = 1 THEN '出库' END) ootype ,  --单据类型
                        oo_type ,
						(CONVERT(VARCHAR(10),YEAR(oo_entrydate))+'年'+CONVERT(VARCHAR(10),MONTH(oo_entrydate))+'月') AS oo_month , --月份
                        oo_addman_txt ,--单据添加人
                        oo_addtime ,   --单据添加时间
                        oo_updatemam_txt , --单据修改人
                        oo_updatetime ,  --单据修改时间
                        oo_lastman ,   --单据审核人
                        oo_auditdate , --单据审核时间
                        oo_remark , --备注
                        fd.ord_no AS oi_no ,  --网络订单号
                        oo_erp_id,
						st.supplyprice,--出货价
					    st.discount,--出货价折扣
	                   (case when st.supplyprice=0 then 0 else CONVERT(decimal(9,2), (st.ol_costprice/st.supplyprice)) end ) as realitydiscount,--实际折扣
					   
	                   ge.oo_io_logistics,   --指令单物流公司
	                   ge.oo_logistics_no,   --指令单物流单号
					   ( SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id where eio.io_id=oo_io_id)instru_vo --指令单凭证号

                 FROM   j_outStorage ge WITH (NOLOCK)
                 INNER JOIN j_outStorageList st WITH (NOLOCK) ON ge.oo_id = ol_eoid AND st.ol_status = 1
                 LEFT JOIN b_goodsinfo gi WITH (NOLOCK) ON gi.gi_id = st.ol_siid AND gi_status = 1
                 LEFT JOIN b_unit ui WITH (NOLOCK) ON ui.ut_id = gi.gi_unit
                 LEFT JOIN b_storageinfo sg WITH (NOLOCK) ON ge.oo_siid = sg.sei_id
                 LEFT JOIN b_clientinfo ci WITH (NOLOCK) ON ci.ci_id = ge.oo_ciid AND ci.ci_status = 1
                 LEFT JOIN pos_shop ps WITH (NOLOCK) ON ps.sh_id = ge.oo_sh_id
                 LEFT JOIN companyinfo cp WITH (NOLOCK) ON cp.cp_id = ge.oo_to_cp_id
                 LEFT JOIN netorder_tbl fd WITH (NOLOCK) ON ge.oo_di_id = fd.ord_id
				 WHERE ge.oo_status > 0 
				 ) AS pout
                 LEFT JOIN b_goodsruleset AS grl ON grl.gss_id = pout.ol_skuid ) AS poutlist
			     LEFT JOIN s_goodsruledetail rulenum WITH (NOLOCK) ON rulenum.gd_id = poutlist.size
				 LEFT JOIN s_goodsruledetail colorrule WITH (NOLOCK) ON colorrule.gd_id = poutlist.colorid
go

