CREATE VIEW [dbo].[vi_JoinFK_Allocation_Search] AS 
SELECT
	el.*, eo.*
FROM
	vi_JoinFK_Allocation_Group_Goods el
INNER JOIN vi_JoinFK_Allocation eo ON el.all_al_id = eo.al_id
AND eo.al_status > 0
go

