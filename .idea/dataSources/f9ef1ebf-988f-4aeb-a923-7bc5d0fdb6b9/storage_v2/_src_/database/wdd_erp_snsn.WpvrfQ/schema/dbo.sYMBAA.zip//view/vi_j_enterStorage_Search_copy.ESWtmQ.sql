CREATE VIEW [dbo].[vi_j_enterStorage_Search_copy] AS 
SELECT el.el_eoid,
       el.el_siid,
       el.el_number,
       el.el_id,
       el.el_realmoney,
       el.el_unit,
       el.el_costprice,
       el.el_discount,
       el.el_skuid,
       el.el_addtime,
       el.el_pm,
       el.el_box_num,
       el.el_gift,
       el.gi_id,
       el.gi_shortname,
       el.gi_name,
       el.gi_type,
       el.gi_code,
       el.gi_grade,
       el.gi_norm,
       el.gi_status,
       el.gi_remark,
       el.gi_entrydate,
       el.si_img,
       el.gi_skus,
       el.gi_alarmstock,
       el.gi_barcode,
       el.gi_brands,
       el.gi_category,
       el.gi_costprice,
       el.gi_downstork,
       el.gi_importprices,
       el.gi_number,
       el.gi_retailprice,
       el.gi_seiid,
       el.gi_seiname,
       el.gi_typeone,
       el.gi_types,
       el.gi_typesid,
       el.gi_upstock,
       el.gi_virtual,
       el.gi_weight,
       el.gi_simplecode,
       el.gi_brandsid,
       el.gi_skuid,
       el.gi_purchase,
       el.gi_addtime,
       el.gi_updatetime,
       el.gi_class,
       el.gi_class_id,
       el.gi_oc_id,
       el.gi_tid,
       el.gi_taobao_id,
       el.gi_attribute_ids,
       el.gi_attribute_parentids,
       el.gi_unit,
       el.gi_unit_id,
       el.vertical_column_id,
       el.vertical_column_name,
       el.el_integral,
	   el.el_totalintegral,
	   el.el_pddate,
       eo.eo_realmoney,
       eo.eo_num,
       eo.eo_id,
       eo.eo_no,
       eo.eo_entrydate,
       eo.eo_manual,
       eo.eo_type,
       eo.eo_siid,
       eo.eo_freight,
       eo.eo_ciid,
       eo.eo_cost,
       eo.eo_takemanid,
       eo.eo_cp_id,
       eo.eo_di_id,
       eo.si_name,
       eo.si_code,
       eo.si_flid,
       eo.si_plid,
       eo.si_province,
       eo.si_city,
       eo.si_county,
       eo.sei_name,
       eo.takeman,
       eo.eo_addman_txt,
       eo.eo_addtime,
       eo.eo_addman,
       eo.eo_update_man_txt,
       eo.eo_updatetime,
       eo.eo_updateman,
       eo.eo_lastman,
       eo.eo_lastmanid,
       eo.eo_auditdate,
       eo.eo_remark,
       eo.eo_status,
       eo.pl_vo,
       eo.pl_source,
       eo.eo_to_cp_id,
       eo.eo_to_cp_id_txt
FROM   (
           --dbo.vi_j_enterStorageList_group_goods 
           
           
           SELECT jt.el_eoid,
                  jt.el_siid,
                  jt.el_number,
                  jt.el_id,
                  jt.el_realmoney,
                  jt.el_unit,
                  jt.el_costprice,
                  jt.el_discount,
                  jt.el_skuid,
                  CONVERT(VARCHAR(100), jt.el_addtime, 25) AS el_addtime,
                  jt.el_pm,
                  jt.el_box_num,
                  jt.el_gift,
                  jt.vertical_column_id,
                  jt.vertical_column_name,
				  jt.el_integral,
	              jt.el_totalintegral,
				  jt.el_pddate,
                  bg.gi_id,
                  bg.gi_shortname,
                  bg.gi_name,
                  bg.gi_type,
                  bg.gi_code,
                  bg.gi_grade,
                  bg.gi_norm,
                  bg.gi_status,
                  bg.gi_remark,
                  bg.gi_entrydate,
                  bg.si_img,
                  bg.gi_skus,
                  bg.gi_alarmstock,
                  bg.gi_barcode,
                  bg.gi_brands,
                  bg.gi_category,
                  bg.gi_costprice,
                  bg.gi_downstork,
                  bg.gi_importprices,
                  bg.gi_number,
                  bg.gi_retailprice,
                  bg.gi_seiid,
                  bg.gi_seiname,
                  bg.gi_typeone,
                  bg.gi_types,
                  bg.gi_typesid,
                  bg.gi_upstock,
                  bg.gi_virtual,
                  bg.gi_weight,
                  bg.gi_simplecode,
                  bg.gi_brandsid,
                  bg.gi_skuid,
                  bg.gi_purchase,
                  bg.gi_addtime,
                  bg.gi_updatetime,
                  bg.gi_class,
                  bg.gi_class_id,
                  bg.gi_oc_id,
                  bg.gi_tid,
                  bg.gi_taobao_id,
                  bg.gi_attribute_ids,
                  bg.gi_attribute_parentids,
                  bu.ut_name             AS gi_unit,
                  bu.ut_id               AS gi_unit_id,
                  (
                      SELECT fd.pl_vo
                      FROM   j_purchaseStorage fd
                      WHERE  fd.pl_id = (
                                 SELECT MAX(fd.pll_pl_id)
                                 FROM   j_purchaseStorageList fd
                                 WHERE  fd.pll_add_time = jt.el_source_add_time
                             )
                  )                      AS pl_vo
           FROM   (
                      --dbo.vi_j_enterStorageList 
                      

					
SELECT jt.el_eoid,
       jt.el_siid,
       jt.el_addtime,
       SUM(el_number)                    AS el_number,
       MIN(el_id)                        AS el_id,
       MAX(el_skuid)                     AS el_skuid,
       SUM(el_realmoney)                 AS el_realmoney,
       CONVERT(DECIMAL(10, 2), AVG(el_unit)) AS el_unit,
       CONVERT(DECIMAL(10, 2), AVG(el_costprice)) AS el_costprice,
       CONVERT(DECIMAL(10, 2), AVG(el_discount)) AS el_discount,
       MAX(REPLACE(jt.el_pm, '*', ','))  AS el_pm,
       MAX(fd.el_box_num)                AS el_box_num,
       jt.el_gift,
       MAX(jt.el_source_add_time)        AS el_source_add_time,
       jt.vertical_column_id,
       jt.vertical_column_name,
	   max(jt.el_pdgddate) AS el_pdgddate,
       max(jt.el_pddate) AS el_pddate,
	   sum(jt.el_integral) as el_integral,
	   sum(jt.el_totalintegral) as el_totalintegral
FROM   (
           SELECT jt.*
                  --垂直列,颜色列
                  ,
                  vertical_column_id = CASE 
                                            WHEN ISNULL(
                                                     dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1),
                                                     0
                                                 ) = 0 THEN --没规格
                                                 0
                                            ELSE CASE 
                                                      WHEN bg.gs_is_custom > 0 THEN CASE 
                                                                                         WHEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1)
                                                                                              )
                                                                                              = 
                                                                                              bg.gs_is_custom THEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 2), '-', 2)
                                                                                              )
                                                                                         ELSE 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 2)
                                                                                              )
                                                                                    END
                                                      ELSE CONVERT(
                                                               INT,
                                                               dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 2)
                                                           )
                                                 END
                                       END,
                  vertical_column_name = CASE 
                                              WHEN ISNULL(
                                                       dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1),
                                                       0
                                                   ) = 0 THEN --没规格
                                                   ''
                                              ELSE CASE 
                                                        WHEN bg.gs_is_custom > 0 THEN CASE 
                                                                                           WHEN 
                                                                                                CONVERT(
                                                                                                    INT,
                                                                                                    dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1)
                                                                                                )
                                                                                                = 
                                                                                                bg.gs_is_custom THEN 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 2), ':', 2)
                                                                                           ELSE 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 1), ':', 2)
                                                                                      END
                                                        ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 1), ':', 2)
                                                   END
                                         END
           FROM   dbo.j_enterStorageList AS jt
                  LEFT JOIN b_goodsruleset bg
                       ON  jt.el_skuid = bg.gss_id
           WHERE  (el_status = 1)
           
                  --AND el_eoid = 804
       )                                 AS jt
       INNER JOIN (
                SELECT fd.el_eoid,
                       fd.el_siid,
                       fd.el_addtime,
                       SUM(fd.el_box_num) AS el_box_num
                FROM   (
                           SELECT fd.el_eoid,
                                  fd.el_siid,
                                  fd.el_addtime,
                                  fd.el_box_num,
                                  fd.el_costprice,
                                  fd.el_unit,
                                  fd.el_discount,
                                  fd.el_gift,
                                  --MAX(fd.el_id) AS el_id
                                  fd.el_id
                           FROM   j_enterStorageList AS fd
                           GROUP BY
                                  fd.el_eoid,
                                  fd.el_siid,
                                  fd.el_addtime,
                                  fd.el_box_num,
                                  fd.el_costprice,
                                  fd.el_unit,
                                  fd.el_discount,
                                  fd.el_gift,
                                  fd.el_id
                       ) AS fd
                GROUP BY
                       fd.el_eoid,
                       fd.el_siid,
                       fd.el_addtime,
                       fd.el_gift
            )                            AS fd
            ON  jt.el_eoid = fd.el_eoid
            AND jt.el_siid = fd.el_siid
            AND jt.el_addtime = fd.el_addtime
GROUP BY
       jt.el_eoid,
       jt.el_siid,
       jt.el_addtime,
       jt.el_gift,
       jt.vertical_column_id,
       jt.vertical_column_name
                             
                             
                  )                      AS jt
                  INNER JOIN dbo.b_goodsinfo AS bg
                       ON  jt.el_siid = bg.gi_id  and bg.gi_status=1
                  INNER JOIN dbo.b_unit  AS bu
                       ON  bg.gi_unit = bu.ut_id
       )                                 AS el
       INNER JOIN dbo.vi_j_enterStorage  AS eo
            ON  el.el_eoid = eo.eo_id
            AND eo.eo_status > 0
--WHERE eo.eo_id=804
go

