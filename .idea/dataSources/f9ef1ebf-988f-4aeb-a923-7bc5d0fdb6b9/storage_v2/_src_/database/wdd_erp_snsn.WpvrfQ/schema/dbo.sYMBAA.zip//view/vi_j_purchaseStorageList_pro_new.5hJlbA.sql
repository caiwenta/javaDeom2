CREATE VIEW [dbo].[vi_j_purchaseStorageList_pro_new] AS 
SELECT pll_pl_id,
       pll_gi_id,
       pll_sku_id,
       --pll_source_add_time,
       min(pll_add_time) AS pll_add_time,
       SUM(pll_pause_num)              AS pll_pause_num,
       SUM(pll_num)                    AS pll_num,
       MIN(pll_id)                     AS pll_id,
       CONVERT(DECIMAL(10, 2), AVG(pll_stock_price)) AS pll_stock_price,
       MAX(pll_discount)               AS pll_discount,
       SUM(pll_money)                  AS pll_money,
       CONVERT(DECIMAL(10, 2), AVG(pll_retail_price)) AS pll_retail_price,
       MAX(pll_status)                 AS pll_status,
       MAX(REPLACE(pll_pm, '*', ','))  AS pll_pm,
       MAX(pll_box_num)                AS pll_box_num,
	   SUM(pll_integral) AS  pll_integral,
       SUM(pll_totalintegral)  AS  pll_totalintegral
FROM   dbo.j_purchaseStorageList AS jt 
where jt.pll_status=1
GROUP BY
       pll_pl_id,
       pll_gi_id,
       pll_sku_id
go

