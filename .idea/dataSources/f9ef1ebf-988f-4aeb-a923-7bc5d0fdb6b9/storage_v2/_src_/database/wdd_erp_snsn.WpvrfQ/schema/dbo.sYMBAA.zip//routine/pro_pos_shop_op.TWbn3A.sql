CREATE PROCEDURE [dbo].[pro_pos_shop_op]
    @sh_id INT ,
    @sh_no VARCHAR(50) ,
    @sh_name VARCHAR(50) ,
    @sh_pi_id INT ,
    @add_man INT ,
    @add_time DATETIME ,
    @update_man INT ,
    @update_time DATETIME ,
    @audit_man INT ,
    @audit_time DATETIME ,
    @status INT ,
    @area VARCHAR(50) ,
    @province VARCHAR(50) ,
    @city VARCHAR(50) ,
    @county VARCHAR(50) ,
    @address VARCHAR(100) ,
    @phone VARCHAR(50) ,
    @fax VARCHAR(50) ,
    @type INT ,
    @sh_class INT ,
    @sh_company INT ,
    @sh_goods_type INT ,
    @remark VARCHAR(50) ,
    @sh_erp_id INT = 0 ,
    @sh_dhprice INT = 0 ,
    @sh_bhprice INT = 0 ,
    @sh_phprice INT = 0 ,
    @sh_mdprice INT = 0 ,
    @sh_tjprice INT = 0 ,
    @sh_province INT = 0 ,
    @sh_city INT = 0 ,
    @sh_district INT = 0 ,
    @sh_town INT = 0 ,
    @town VARCHAR(50) = '' ,
    @sh_cp_id INT = 0 ,
    @sh_di_id INT = 0 ,
    @sh_attribute_ids VARCHAR(250) ,
    @sh_attribute_parentids VARCHAR(250) ,
    @sh_is_tb INT = 0 ,
    @sh_ischange_instorage INT = 0 ,
    @sh_fixed INT = 0 ,
    @sh_qcje DECIMAL(15, 2) = 0 ,
	@sh_client int=0,
	@sh_commission int=1,
	@sh_member int=0,
	@sh_isshoppingguide int=0,
    @op_type INT = 0 ,--操作类型(1:添加 2:修改 3:删除 4:审核或取消审核)
    @outResult INT OUTPUT,
	@sh_dhdiscount DECIMAL(15, 2) = 1 ,
	@sh_bhdiscount DECIMAL(15, 2) = 1 ,
	@sh_phdiscount DECIMAL(15, 2) = 1 ,
	@sh_mddiscount DECIMAL(15, 2) = 1 ,
	@sh_tjdiscount DECIMAL(15, 2) = 1 ,

	@sh_brokedealers INT = 0  ,
    @sh_residualcommission INT = 0  ,
    @sh_breakeven DECIMAL(15, 2) = 0 ,
    @sh_opendate VARCHAR(50) = '',
    @sh_closedate VARCHAR(50) = '' ,
    @sh_shoparea DECIMAL(15, 2) = 0,

	@sh_disupplier INT = 0  , 
	@sh_isgoods INT = 0 ,
	@sh_p_type int=0 ,
	@sh_is_lease int=0,
	@sh_is_confirm int=0,
	@sh_confirm_days int=0,
	@sh_issharing int=0
AS
    BEGIN
		--新增
        IF @op_type = 1
            BEGIN
                INSERT  INTO [pos_shop]
                        ( [sh_no] ,
                          [sh_name] ,
                          [sh_pi_id] ,
                          [add_man] ,
                          [add_time] ,
                          [update_man] ,
                          [update_time] ,
                          [audit_man] ,
                          [audit_time] ,
                          [status] ,
                          [area] ,
                          [province] ,
                          [city] ,
                          [county] ,
                          [address] ,
                          [phone] ,
                          [fax] ,
                          [type] ,
                          [sh_class] ,
                          [sh_company] ,
                          [remark] ,
                          sh_goods_type ,
                          sh_dhprice ,
                          sh_bhprice ,
                          sh_phprice ,
                          sh_mdprice ,
                          sh_tjprice ,
                          sh_cp_id ,
                          sh_di_id ,
                          sh_attribute_ids ,
                          sh_attribute_parentids ,
                          sh_is_tb ,
                          sh_province ,
                          sh_city ,
                          sh_district ,
                          sh_town ,
                          town ,
                          sh_ischange_instorage ,
                          sh_erp_id ,
                          sh_fixed ,
                          sh_qcje,
						  sh_client,
						  sh_clientname,
						  sh_commission,
						  sh_member,
						  sh_isshoppingguide,
						  
						  sh_brokedealers,
						  sh_residualcommission,
						  sh_breakeven,
						  sh_opendate,
						  sh_closedate,
						  sh_shoparea,

						  sh_dhdiscount,sh_bhdiscount,sh_phdiscount,sh_mddiscount,sh_tjdiscount,
						  sh_disupplier,
						  sh_isgoods,
						  sh_p_type,
						  sh_is_lease,
						  sh_is_confirm,
						  sh_confirm_days,
						  sh_issharing
	                    )
                VALUES  ( @sh_no ,
                          @sh_name ,
                          @sh_pi_id ,
                          @add_man ,
                          @add_time ,
                          @update_man ,
                          @update_time ,
                          @audit_man ,
                          @audit_time ,
                          @status ,
                          @area ,
                          @province ,
                          @city ,
                          @county ,
                          @address ,
                          @phone ,
                          @fax ,
                          @type ,
                          @sh_class ,
                          @sh_company ,
                          @remark ,
                          @sh_goods_type ,
                          @sh_dhprice ,
                          @sh_bhprice ,
                          @sh_phprice ,
                          @sh_mdprice ,
                          @sh_tjprice ,
                          @sh_cp_id ,
                          @sh_di_id ,
                          @sh_attribute_ids ,
                          @sh_attribute_parentids ,
                          @sh_is_tb ,
                          @sh_province ,
                          @sh_city ,
                          @sh_district ,
                          @sh_town ,
                          @town ,
                          @sh_ischange_instorage ,
                          @sh_erp_id ,
                          @sh_fixed ,
                          @sh_qcje,
						  @sh_client,
						  (SELECT ci_name FROM b_clientinfo WHERE ci_id=@sh_client),
						  @sh_commission,
						  @sh_member,
						  @sh_isshoppingguide,
						  
						  @sh_brokedealers,
						  @sh_residualcommission,
						  @sh_breakeven,
						  @sh_opendate,
						  @sh_closedate,
						  @sh_shoparea,

						  @sh_dhdiscount,@sh_bhdiscount,@sh_phdiscount,@sh_mddiscount,@sh_tjdiscount,
						  @sh_disupplier,
						  @sh_isgoods,
						  @sh_p_type,
						  @sh_is_lease,
						  @sh_is_confirm,
						  @sh_confirm_days,
						  @sh_issharing
	                    )
                SET @sh_id = SCOPE_IDENTITY()
            END
		--更新
        IF @op_type = 2
            AND @sh_id > 0
            AND @sh_erp_id > 0
            BEGIN
                UPDATE  [pos_shop]
                SET     [sh_no] = @sh_no ,
                        [sh_name] = @sh_name ,
                        [sh_pi_id] = @sh_pi_id ,
                        [update_man] = @update_man ,
                        [update_time] = @update_time ,
                        [audit_man] = @audit_man ,
                        [audit_time] = @audit_time ,
                        [status] = @status ,
                        [area] = @area ,
                        [province] = @province ,
                        [city] = @city ,
                        [county] = @county ,
                        [address] = @address ,
                        [phone] = @phone ,
                        [fax] = @fax ,
                        [type] = @type ,
                        [sh_class] = @sh_class ,
                        [sh_company] = @sh_company ,
                        [remark] = @remark ,
                        sh_goods_type = @sh_goods_type ,
                        sh_dhprice = @sh_dhprice ,
                        sh_bhprice = @sh_bhprice ,
                        sh_phprice = @sh_phprice ,
                        sh_mdprice = @sh_mdprice ,
                        sh_tjprice = @sh_tjprice ,
                        sh_attribute_ids = @sh_attribute_ids ,
                        sh_attribute_parentids = @sh_attribute_parentids ,
                        sh_is_tb = @sh_is_tb ,
                        sh_province = @sh_province ,
                        sh_city = @sh_city ,
                        sh_district = @sh_district ,
                        sh_town = @sh_town ,
                        town = @town ,
                        sh_ischange_instorage = @sh_ischange_instorage ,
                        sh_fixed = @sh_fixed ,
                        sh_qcje = @sh_qcje,
						sh_client=@sh_client,
						sh_clientname=(SELECT ci_name FROM b_clientinfo WHERE ci_id=@sh_client),
						sh_commission=@sh_commission,
						sh_member=@sh_member,
						sh_isshoppingguide=@sh_isshoppingguide,
						
            			sh_brokedealers=@sh_brokedealers,
            			sh_residualcommission=@sh_residualcommission,
            			sh_breakeven=@sh_breakeven,
           		    	sh_opendate=@sh_opendate,
           			    sh_closedate=@sh_closedate,
            			sh_shoparea=@sh_shoparea,

						sh_dhdiscount=@sh_dhdiscount,
						sh_bhdiscount=@sh_bhdiscount,
						sh_phdiscount=@sh_phdiscount,
						sh_mddiscount=@sh_mddiscount,
						sh_tjdiscount=@sh_tjdiscount,
						
						sh_disupplier=@sh_disupplier,
						sh_isgoods=@sh_isgoods,
						sh_p_type=@sh_p_type,
						sh_is_lease=@sh_is_lease,
						sh_is_confirm=@sh_is_confirm,
						sh_confirm_days=@sh_confirm_days,
						sh_issharing=@sh_issharing
                WHERE   sh_id = @sh_id
                        AND sh_erp_id = @sh_erp_id
            END
		--状态
        IF @op_type = 3
            AND @sh_id > 0
            AND @sh_erp_id > 0
            BEGIN
                UPDATE  [pos_shop]
                SET     [update_man] = @update_man ,
                        [update_time] = @update_time ,
                        [status] = @status
                WHERE   sh_id = @sh_id
                        AND sh_erp_id = @sh_erp_id
            END
		--审核
        IF @op_type = 4
            AND @sh_id > 0
            AND @sh_erp_id > 0
            BEGIN
                UPDATE  [pos_shop]
                SET     [audit_man] = @audit_man ,
                        [audit_time] = @audit_time ,
                        [status] = @status
                WHERE   sh_id = @sh_id
                        AND sh_erp_id = @sh_erp_id
            END
    
        IF @@error <> 0
            SET @outResult = 0;
        ELSE
            SET @outResult = @sh_id;

        RETURN @outResult;
    END
go

