CREATE FUNCTION [dbo].[FnPosGoodsPrice]
(
	@gi_id INT=0,
	@sh_id INT=0
)
RETURNS @p TABLE
(
	gi_id int,
	gs_discount DECIMAL(9, 2),
	gs_purchase DECIMAL(9, 2),
	gs_marketprice DECIMAL(9, 2)
)
AS
BEGIN
	INSERT @p
	SELECT @gi_id,0.00,0.00,0.00
	
		
DECLARE @ghj       DECIMAL(9, 2) = 0;
DECLARE @lsj       DECIMAL(9, 2) = 0;
DECLARE @ghj_type  INT = 0;
DECLARE @dpj_type  INT = 0;

declare @discount DECIMAL(9, 2) = 1;

SELECT 
	@ghj_type = ps.sh_dhprice, 
	@discount=sh_dhdiscount
FROM pos_shop ps
WHERE ps.sh_id = @sh_id


	SELECT @dpj_type = ps.sh_goods_type
	FROM   pos_shop ps
	WHERE  ps.sh_id = @sh_id
	
	IF @dpj_type != 0
	BEGIN
	    SELECT @lsj = gd_price
	    FROM   b_goods_discount
	    WHERE  gd_type = @dpj_type
	           AND gd_class = 1 AND gd_gi_id = @gi_id
	END
	IF @dpj_type = 0 OR @lsj = 0 
	BEGIN
	    SELECT @lsj = bg.gi_retailprice
	    FROM   b_goodsinfo bg
	    WHERE  bg.gi_id = @gi_id
	END
	
	SELECT @ghj = gd_price
	FROM   b_goods_discount
	WHERE  gd_gi_id = @gi_id
	       AND gd_class = 2
	       AND gd_type = @ghj_type
	
	--零售价
	UPDATE @p
	SET    gs_marketprice = @lsj
	
	
	IF @ghj > 0.00
	BEGIN
	    --更细供货价
	    UPDATE @p
	    SET    gs_purchase = @ghj* @discount
	    
	    --更新折扣价
	    UPDATE @p
	    SET    gs_discount = (
	               CASE 
	                    WHEN gs_marketprice = 0.00 THEN 0.00
	                    ELSE gs_purchase / gs_marketprice
	               END
	           )
	END
	ELSE
	BEGIN
	    UPDATE @p
	    SET    gs_purchase = @lsj
	    
	    UPDATE @p
	    SET    gs_discount = 1
	END

	RETURN
END
go

