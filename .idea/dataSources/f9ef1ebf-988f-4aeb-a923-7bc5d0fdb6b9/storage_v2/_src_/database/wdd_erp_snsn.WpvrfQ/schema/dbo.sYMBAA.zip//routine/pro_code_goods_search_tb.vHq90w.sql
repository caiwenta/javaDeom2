
CREATE  proc [dbo].[pro_code_goods_search_tb]                   --定义存储过程
@code varchar(500)                             --用户输入的参数2  

as



select  top 15 *  FROM b_goodsinfo  where gi_id=(select gi_id from dbo.b_goodsruleset where gss_no=@code)

go

