CREATE VIEW [dbo].[vi_j_purchaseStorage_and_detail] AS 
SELECT jt.pl_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.j_purchaseStorage            AS jt
       INNER JOIN dbo.j_purchaseStorageList AS jt1
            ON  jt.pl_id = jt1.pll_pl_id
       INNER JOIN dbo.b_goodsinfo  AS bg
            ON  jt1.pll_gi_id = bg.gi_id
WHERE  (jt.pl_status <> 0)
       AND (jt1.pll_status = 1)
go

