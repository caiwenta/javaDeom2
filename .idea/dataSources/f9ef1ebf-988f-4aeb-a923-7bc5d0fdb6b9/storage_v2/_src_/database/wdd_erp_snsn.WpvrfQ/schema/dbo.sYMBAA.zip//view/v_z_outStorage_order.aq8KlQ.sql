CREATE VIEW [dbo].[v_z_outStorage_order]
	AS 

SELECT
CONVERT(VARCHAR(100),ge.oo_entrydate,23) AS oo_entrydate ,--出货日期
cp.cp_code as oo_cp_code,--发货地编号
cp.cp_name as oo_cp_name,--发货地名称
ge.oo_id,
ge.oo_cp_id,
ge.oo_no ,--凭证号
ge.oo_manual ,--单据号
ge.oo_status,--单据状态
(CASE WHEN ge.oo_status = 1 THEN '未审核' WHEN ge.oo_status = 2 THEN '已审核' END) as oostatus,

(CASE WHEN isnull(ge.oo_ciid,0)>0 THEN ISNULL(ci.ci_name,'')
WHEN isnull(ge.oo_sh_id,0)>0 THEN ISNULL(ps.sh_name,'')
WHEN isnull(ge.oo_to_cp_id ,0)>0 THEN ISNULL(tocp.cp_name,'')  END) AS ci_name,
     
(CASE WHEN isnull(ge.oo_ciid,0)>0 THEN ISNULL(ci.ci_code,'')
WHEN isnull(ge.oo_sh_id,0)>0 THEN ISNULL(ps.sh_no,'')
WHEN isnull(ge.oo_to_cp_id ,0)>0 THEN ISNULL(tocp.cp_code,'')  END) AS ci_code,
     
isnull(ge.oo_ciid,0)  AS oo_ciid,
ISNULL(ci.ci_name,'') AS oo_ci_name ,--客户
ISNULL(ci.ci_code,'') AS oo_ci_code ,--客户代号

isnull(ge.oo_sh_id,0) AS oo_sh_id,
ISNULL(ps.sh_name,'') AS oo_sh_name ,--店铺
ISNULL(ps.sh_no,'')   AS oo_sh_code ,--店铺代号

isnull(ge.oo_to_cp_id ,0) AS oo_to_cp_id,
ISNULL(tocp.cp_name,'') AS oo_to_cp_name ,--分公司
ISNULL(tocp.cp_code,'') AS oo_to_cp_code ,--分公司代号


ISNULL((CASE WHEN ge.oo_type = 0 THEN 0 ELSE ge.oo_realmoney END),0) AS oo_realmoney ,--出库金额
ISNULL((CASE WHEN ge.oo_type = 0 THEN 0 ELSE ge.oo_num END),0) AS oo_num ,--出库数量 
                                           
ISNULL((CASE WHEN ge.oo_type = 0 THEN -ge.oo_realmoney ELSE 0 END),0) AS oo_returnrealmoney ,--退货金额
ISNULL((CASE WHEN ge.oo_type = 0 THEN -ge.oo_num  ELSE 0 END),0) AS oo_returnnum, --退货数量                                                                

ISNULL((CASE WHEN ge.oo_type = 0 THEN -ge.oo_realmoney ELSE ge.oo_realmoney END),0) AS realmoney ,--合计金额
ISNULL((CASE WHEN ge.oo_type = 0 THEN -ge.oo_num ELSE ge.oo_num END),0) AS num, --合计数量 


ge.oo_jytype ,--交易类型
(CASE WHEN ge.oo_jytype = 1 THEN '订货'
	WHEN ge.oo_jytype = 2 THEN '补货'
	WHEN ge.oo_jytype = 3 THEN '铺货'
	WHEN ge.oo_jytype = 4 THEN '买断'
	end
) oojytype,
ge.oo_freight ,--垫付运费
ge.oo_cost ,--其他应收
(CASE WHEN ge.oo_type = 0 THEN '退货'
    WHEN ge.oo_type = 1 THEN '出库'
END) ootype ,  --单据类型
ge.oo_type ,
--CONVERT(varchar(7), oo_entrydate, 120 )as oo_month,--月份
(CONVERT(VARCHAR(10),YEAR(ge.oo_entrydate))+'年'+CONVERT(VARCHAR(10),MONTH(ge.oo_entrydate))+'月') AS oo_month , --月份
ge.oo_addman_txt ,--单据添加人
ge.oo_addtime ,   --单据添加时间
ge.oo_updatemam_txt , --单据修改人
ge.oo_updatetime ,  --单据修改时间
ge.oo_lastman ,   --单据审核人
ge.oo_auditdate , --单据审核时间
ge.oo_remark , --备注
ge.oo_erp_id,
ge.oo_erp_id as erp_id
                                                       
FROM  j_outStorage ge WITH (NOLOCK)
LEFT JOIN companyinfo cp on cp.cp_id=ge.oo_cp_id
LEFT JOIN companyinfo tocp on tocp.cp_id=ge.oo_to_cp_id 
LEFT JOIN b_clientinfo ci WITH (NOLOCK) ON ci.ci_id = ge.oo_ciid AND ci.ci_status = 1
LEFT JOIN pos_shop ps WITH (NOLOCK) ON ps.sh_id = ge.oo_sh_id
WHERE ge.oo_status > 0
go

