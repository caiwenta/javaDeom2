CREATE VIEW [dbo].[v_z_initStorage_color]
	AS 



select 
'' AS specname, 
T.inlmcs_id color_order_id,
ISNULL((SELECT sg.gd_name FROM s_goodsruledetail AS sg WHERE sg.gd_id=T.inl_color_id),'无') AS color,
T.in_id order_id, 
T.inl_color_id colorid,  

ISNULL((select TOP 1 bgr.gs_sampleno from b_goodsruleset bgr where bgr.gi_id=T.inl_gi_id and bgr.colorid=T.inl_color_id and bgr.gs_status>0),T.gi_sampleno) AS gs_sampleno,--规格样品号


T.* 
from
(



SELECT
st.inlmcs_id,
st.inl_color_id,
ge.in_cp_id,
ge.in_erp_id,
ge.in_erp_id as erp_id ,

ge.in_id,  
ge.in_vo,--凭证号
ge.in_no,--单据号
CONVERT(varchar(100), ge.in_date, 23) as in_date,--期初日期

sg.sei_id AS in_st_id,
sg.sei_name AS in_st_id_txt,--仓库
sg.sei_name,--仓库

gi.gi_id,
st.inl_gi_id,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_skuid,
gi.gi_sampleno,--样品号
isnull(st.inl_num,0) as num,--规格数量

ui.ut_name,--单位
ui.ut_name as gi_unit, --单位
isnull(st.inl_num,0) as inl_num,--数量
isnull(st.inl_retail_price,0) as inl_retail_price,--零售价
isnull(st.inl_discount,0) as inl_discount,--折率
isnull(st.inl_stock_price,0) as inl_stock_price,--进货价
isnull(st.inl_retail_price,0)*isnull(st.inl_num,0) as inl_retail_money,--零售金额
isnull(st.inl_money,0) as inl_money,--进货金额
st.inl_boxbynum,--数量/箱
(case when isnull(st.inl_boxbynum,0)=0 then 0 else ceiling(inl_num/inl_boxbynum) end) as inl_box_num, --箱数
st.inl_pm,
in_order_man_txt=( SELECT bs.si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE bs.si_id = in_order_man),--经手人
inl_add_time,   --单据商品添加时间
in_add_man_txt=( SELECT bs.si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE bs.si_id = in_add_man ), --添加人
in_add_time,    --单据添加时间
in_update_man_txt=( SELECT bs.si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE bs.si_id = in_update_man ), --单据修改人
in_update_time,    --单据修改时间
in_audit_man_txt=( SELECT bs.si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE bs.si_id = in_audit_man ),  --单据审核人
in_audit_time,     --单据审核时间
in_status,         --单据状态
in_remark  --备注

FROM   j_initStorage ge
inner join  j_initStorageListMergeColorSum st ON ge.in_id = inl_in_id AND st.inl_status = 1 and ge.in_status>0
left join b_goodsinfo gi on gi.gi_id=st.inl_gi_id and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 
left join b_storageinfo sg on sg.sei_id=ge.in_st_id


) as T
go

