CREATE Proc [dbo].[pro_kill_deadlock]
as
DECLARE @sid INT=0;
DECLARE @sql NVARCHAR(50)='';
DECLARE sopcor CURSOR FOR(
 SELECT request_session_id FROM sys.dm_tran_locks   fd WITH (NOLOCK)   WHERE  resource_type='OBJECT' AND  fd.resource_database_id=DB_ID()
  )
OPEN sopcor
FETCH NEXT FROM sopcor INTO @sid
  WHILE @@FETCH_STATUS =0
  begin
  SET @sql='kill '+CONVERT(VARCHAR(50),@sid);
  exec sp_executesql @sql 
  FETCH NEXT FROM sopcor INTO @sid
  End
CLOSE sopcor
DEALLOCATE sopcor
go

