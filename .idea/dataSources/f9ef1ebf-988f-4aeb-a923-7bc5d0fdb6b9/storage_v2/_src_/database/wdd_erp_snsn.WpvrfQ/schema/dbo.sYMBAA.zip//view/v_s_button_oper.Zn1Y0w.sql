CREATE VIEW dbo.v_s_button_oper
AS
SELECT     dbo.v_s_page_oper.po_id, dbo.v_s_page_oper.po_oi_id, dbo.v_s_page_oper.po_pi_id, dbo.v_s_page_oper.po_remark, dbo.v_s_page_oper.pi_name, 
                      dbo.v_s_page_oper.oi_name, dbo.s_button_oper.bo_id, dbo.s_button_oper.bo_bi_id, dbo.s_button_oper.bo_po_id
FROM         dbo.v_s_page_oper INNER JOIN
                      dbo.s_button_oper ON dbo.s_button_oper.bo_po_id = dbo.v_s_page_oper.po_id
go

