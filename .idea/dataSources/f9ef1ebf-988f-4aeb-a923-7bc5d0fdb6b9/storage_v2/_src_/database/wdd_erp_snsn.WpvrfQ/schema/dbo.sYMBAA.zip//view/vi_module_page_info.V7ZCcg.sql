
CREATE VIEW [dbo].[vi_module_page_info] AS 
select vmi.pi_id as m_pi_id,vmi.pi_name as m_pi_name,vmi.pi_icon as m_pi_icon,vmi.pi_jscode as m_pi_jscode,vmi.pi_sort as m_pi_sort,vmi.pi_type as m_pi_type,vmi.pi_status as m_pi_status,
vpi.pi_id,vpi.pi_name,vpi.pi_url,vpi.pi_icon,vpi.pi_jscode,vpi.pi_sort,vpi.pi_parentid,vpi.pi_type,vpi.pi_status,vmi.pi_remark
 from vi_moduleInfo as vmi left join vi_pageInfo as vpi on vmi.pi_id=vpi.pi_parentid 
--order by vmi.pi_sort,vpi.pi_sort
go

