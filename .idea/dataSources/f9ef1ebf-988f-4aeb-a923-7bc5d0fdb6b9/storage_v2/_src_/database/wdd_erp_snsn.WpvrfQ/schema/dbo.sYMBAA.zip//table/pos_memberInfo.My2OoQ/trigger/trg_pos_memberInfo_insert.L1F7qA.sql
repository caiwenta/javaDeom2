CREATE TRIGGER [dbo].[trg_pos_memberInfo_insert] ON [dbo].[pos_memberInfo]
       AFTER INSERT
AS
BEGIN
      IF ((SELECT   COUNT(1)
           FROM     INSERTED it
           INNER JOIN pos_memberinfo me ON me.me_status = it.me_status
                                           AND me.dzd_miid = it.dzd_miid
                                           AND me.me_erp_id = it.me_erp_id
           WHERE    ISNULL(it.dzd_miid,0) > 0
          ) > 1)
         BEGIN
               RAISERROR('系统提示：同步会员重复，不能新增！', 16, 11);
               ROLLBACK TRAN;
         END;
         
      ELSE 
      	BEGIN
      		DECLARE @erp_id INT
      		DECLARE @me_id INT
      		DECLARE @default_count VARCHAR(10)
      		DECLARE @discount decimal(10,2)
      		
      		SELECT @erp_id=me_erp_id FROM INSERTED
      		SELECT @me_id=me_id FROM INSERTED
      		SELECT @discount=birthday_discount FROM INSERTED
      		SELECT @default_count=s_othervalue FROM s_system_set WHERE s_erp_id=@erp_id AND s_key='discountonbirthday' 
      		--当新增会员时，没有设置生日折扣且系统有设置默认折扣时，更新为默认折扣
      		IF(@discount=0 AND @default_count!='')
      		BEGIN
      			UPDATE pos_memberinfo
      			SET birthday_discount=@default_count
      			WHERE me_id=@me_id AND me_erp_id=@erp_id
      		END
      	END
END
go

