CREATE FUNCTION [dbo].[FnErpStocklocationlog]
(
	@date DATETIME,
	@sei_id int,
	@gi_id int,
	@gi_sku_id int,
	@locationid int=0
)
RETURNS INT
AS
BEGIN
	declare @stock_num int=0;

	SELECT @stock_num =ISNULL(SUM( CASE WHEN js.sl_counttype = 1 THEN js.sl_number ELSE -js.sl_number END ),0)
	FROM   j_stocklog AS js
	WHERE  js.sl_seiid = @sei_id
             AND (( CONVERT(VARCHAR(50), js.sl_order_date, 23) <= @date )OR js.sl_type = 3)
             AND js.sl_status != 0
             AND js.sl_giid = @gi_id
			 and js.sl_skuid=@gi_sku_id
			 AND isnull(js.sl_location,0)=@locationid
	GROUP BY
             js.sl_giid,js.sl_skuid,
			 isnull(js.sl_pm,''),
			 isnull(js.sl_location,0)

	RETURN @stock_num;
END
go

