

CREATE PROCEDURE [dbo].[pro_pos_createmonthly_op]
@shid int=0,
@year int=0,
@month int=0,
@add_man int=0,
--操作类型(1:添加 2:删除)
@op_type varchar(100)='',
@outResult varchar(100)='' Output
AS
BEGIN


declare @bool_first int=0;
declare @date_str varchar(50)=CONVERT(varchar(50),@year)+'-'+CONVERT(varchar(50),@month)+'-01';
if @op_type='添加'
begin
    if((@month>datepart(month,GETDATE()) and @year=datepart(year,GETDATE())) or @year>datepart(year,GETDATE()))
    begin
          set @outResult='选择的月份还没到，不能生成月报！'
		  select INFO=@outResult;
		  return;
    end
   
   	if exists(select * from pos_month_report as  fd where fd.reporttype=0 and  fd.m_year=@year and fd.m_month=@month and fd.shid=@shid)
			begin
				--生成
				--结束，返回提示信息
				set @outResult='这个月的月报已生成！'
				select INFO=@outResult;
				return;
			end
   
   --是否有生成过月报
   if exists(SELECT TOP 1 m_month  FROM pos_month_report WHERE reporttype=0 AND shid=@shid )
   begin	
   		if not exists(select * from pos_month_report as  fd where fd.reporttype=0 and  fd.m_year=(CASE WHEN @month=1 THEN DATEPART(YEAR,DATEADD(YEAR, -1, @date_str)) ELSE @year END) and fd.m_month=DATEPART(MONTH,DATEADD(MONTH, -1, @date_str)) and fd.shid=@shid)
				begin
					--生成
					--结束，返回提示信息
					set @outResult='请按顺序生成月报表！'
					select INFO=@outResult;
					return;
				end
   end
	
declare @prev_year int=datepart(year,DATEADD(month,-1,convert(datetime,@date_str)));
declare @prev_month int=datepart(month,DATEADD(month,-1,convert(datetime,@date_str)));

--创建临时表#Tmp
create table #p3 
(
    datee   varchar(50)  null, 
	shid    int          null,
    SID     int          null,   
    gid     int          null,
	end_num int          null,
	end_money decimal(38,2) null
);


--判断上一个月是否生成
if exists(select * from pos_month_report as  fd where fd.reporttype=0 and  fd.m_year=@prev_year and fd.m_month=@prev_month and fd.shid=@shid)
begin

insert #p3
SELECT @date_str,shid,SID,gid,end_num,end_money  FROM (
SELECT shid,SID,gid,SUM(end_num) AS end_num,SUM(end_money) AS end_money FROM (
--上个月的报表的期未数据	
select shid,SID,gid,end_num,end_money  from pos_month_report as  fd where fd.reporttype=0 and  fd.m_year=@prev_year
and fd.m_month=@prev_month and fd.shid=@shid 

UNION ALL

SELECT shid,SID,gid,0,0 FROM vi_pos_stockList_createmonthly where 
DATEPART(YEAR,order_date)=@year and DATEPART(MONTH,order_date)=@month and shid=@shid  and myremark<>'期初'

) as TT GROUP BY shid,gid, SID
) AS month_report

end
else
begin

insert #p3
SELECT @date_str,shid,SID,gid,end_num,end_money  FROM (
--截止上个月的数据
SELECT shid, SID, gid, SUM(gnum) AS end_num, SUM(allmoney) AS end_money FROM(

SELECT shid,SID, gid ,gnum , allmoney FROM vi_pos_stockList_createmonthly WHERE  order_date<@date_str and shid=@shid
AND mytype!=3

UNION ALL

SELECT shid,SID,gid,gnum,allmoney FROM vi_pos_stockList_createmonthly vsl WHERE vsl.mytype=3 and shid=@shid

UNION ALL
SELECT shid,SID,gid,0,0 FROM vi_pos_stockList_createmonthly where 
DATEPART(YEAR,order_date)=@year and DATEPART(MONTH,order_date)=@month and shid=@shid and myremark<>'期初'

) AS createmonthly GROUP BY shid,gid, SID

) AS month_report

end

		--统计当月数据
		select 
		fd.gid,
		fd.sid,
		fd.shid,
		--统计入库数量
		SUM(case when fd.myremark='入库' then fd.gnum else 0 end) as en_num,
		SUM(case when fd.myremark='入库' then fd.allmoney else 0 end) as en_money,
		SUM(case when fd.myremark='入库退货'  or fd.myremark='调拨' then fd.gnum else 0 end) as enth_num,
		SUM(case when fd.myremark='入库退货'  or fd.myremark='调拨' then fd.allmoney else 0 end) as enth_money,
		SUM(case when fd.myremark='销售前台' and  fd.gnum <0 then fd.gnum else 0 end) as oo_num,
		SUM(case when fd.myremark='销售前台' and  fd.gnum <0 then fd.allmoney else 0 end) as oo_money,
	    SUM(case when fd.myremark='销售前台' and  fd.gnum >0 then fd.gnum else 0 end) as ooth_num,
		SUM(case when fd.myremark='销售前台' and  fd.gnum >0 then fd.allmoney else 0 end) as ooth_money,
		SUM(case when fd.myremark='整仓盘点盈亏调整' then fd.gnum else 0 end) as ts_num,
		SUM(case when fd.myremark='整仓盘点盈亏调整' then fd.allmoney else 0 end) as ts_money,
		SUM(case when fd.myremark='移出仓库' then fd.gnum else 0 end) as mo_num,
		SUM(case when fd.myremark='移出仓库' then fd.allmoney else 0 end) as mo_money,
		SUM(case when fd.myremark='移入仓库' then fd.gnum else 0 end) as mi_num,
		SUM(case when fd.myremark='移入仓库' then fd.allmoney else 0 end) as mi_money,
		SUM(case when fd.myremark='盈亏' then fd.gnum else 0 end) as yk_num,
		SUM(case when fd.myremark='盈亏' then fd.allmoney else 0 end) as yk_money
		into #p4
		from vi_pos_stockList_createmonthly as fd where fd.gid>0 and fd.sid>0
		and DATEPART(YEAR,fd.order_date)=@year and DATEPART(MONTH,fd.order_date)=@month and fd.shid=@shid
		group by 
		fd.gid,
		fd.sid,
		fd.shid
		alter table #p4 add price decimal(18,2);
		--alter table #p4 add start_money decimal(18,2);
		--alter table #p4 add start_num int;
		alter table #p4 add end_money decimal(18,2);
		alter table #p4 add end_num int;
		alter table #p4 add m_year int;
		alter table #p4 add m_month int;
		


		select
		#p3.gid,
		#p3.sid,
		#p3.shid, 
		#p3.end_money as start_money,
		#p3.end_num as start_num,
		#p4.m_year,
		#p4.m_month,
		isnull(#p4.en_num,0)as en_num,
		isnull(#p4.en_money,0) as en_money,
		isnull(#p4.enth_num,0) as enth_num,
		isnull(#p4.enth_money,0) as enth_money,
		isnull(#p4.oo_num,0) as oo_num,
	    isnull(#p4.oo_money,0) as oo_money,
		isnull(#p4.ooth_num,0) as ooth_num,
		isnull(#p4.ooth_money,0) as ooth_money,
		isnull(#p4.ts_num,0) as ts_num,
	    isnull(#p4.ts_money,0) as ts_money,
		isnull(#p4.mo_num,0) as mo_num,
		isnull(#p4.mo_money,0) as mo_money,
		isnull(#p4.mi_num,0) as mi_num,
		isnull(#p4.mi_money,0) as mi_money,
		isnull(#p4.yk_num,0) as yk_num,
		isnull(#p4.yk_money,0) as yk_money,
		isnull(#p4.price,0) as price,
		isnull(#p4.end_money,0) as end_money,
		isnull(#p4.end_num,0) as end_num
		into #p1
		from #p3 
		left join #p4 on #p3.gid=#p4.gid and #p3.sid=#p4.sid





		
		--if @bool_first=0
		--begin
		----按公式算出单价
		--update #p1 set start_money=#p2.end_money,start_num=#p2.end_num from #p1,#p2
		--where #p1.gid=#p2.gid and #p1.sid=#p2.sid and #p1.shid=#p2.shid
		
		--end
		--else
		--begin
		
		
		----期初库存数量，金额
		----使用产品档案的进货价
		
		--update #p1 set start_money=fd.start_money,start_num=fd.start_num 
		--from #p1,
		--(
		--select 	
		--fd.gid,
		--fd.sid,	
		--fd.shid,
		--SUM(fd.gnum) as  start_num,
		--SUM(fd.allmoney) as start_money 
		--from vi_pos_stockList_createmonthly as fd where fd.myremark='期初'
		--group by 
		--fd.gid,
		--fd.sid,
		--fd.shid
		--) as fd where #p1.sid=fd.sid and #p1.gid=fd.gid and #p1.shid=fd.shid
		
		--update #p1 set price=fd.gi_purchase from #p1 ,b_goodsinfo as fd where #p1.gid=fd.gi_id
		
		
		--end
		


		update #p1 set price=ISNULL(fd.price1,0)
		
		from #p1 ,
		(select
		 (
		 (#p1.start_money+#p1.en_money+#p1.enth_money)/case when 
		 (#p1.start_num+#p1.en_num+#p1.enth_num)=0 then 1 else (#p1.start_num+#p1.en_num+#p1.enth_num) end)as price1,gid,sid,shid  from  #p1)as fd
		
		 where #p1.gid=fd.gid and #p1.sid=fd.sid and #p1.shid=fd.shid

		
		update #p1 set start_money=0,start_num=0
		where start_money is null and start_num is null
		
		--更新期末数了，金额
		update #p1 set end_money=ISNULL((start_money+en_money +enth_money+oo_money +ooth_money+mo_money+mi_money+ts_money+yk_money),0),
		               end_num=ISNULL((start_num+en_num +enth_num+oo_num +ooth_num +mo_num+mi_num  +ts_num+yk_num),0)
		
		
		update #p1 set m_year=@year,m_month=@month
		
		--if @bool_first=1
		--begin
		--if OBJECT_ID('pos_month_report') is not null
		--begin
		--	insert into pos_month_report(
		--		gid, sid, shid, en_num, en_money, enth_num, enth_money,oo_num, oo_money,ooth_num, ooth_money,
		--		 ts_num, ts_money,mo_num,mo_money, mi_num, mi_money,yk_num, yk_money,price, start_money, start_num, end_money, end_num, m_year, m_month
			
		--	) select * from #p1
		--end
		--else 
		--begin
		--    select * into pos_month_report from #p1
		--end
		--end
		--else
		--begin
		--insert into pos_month_report(
		--		gid, sid, shid, en_num, en_money, enth_num, enth_money,oo_num, oo_money,ooth_num, ooth_money, ts_num, ts_money,mo_num,mo_money, mi_num, mi_money,yk_num, yk_money,price, start_money, start_num, end_money, end_num, m_year, m_month
			
		--	) select * from #p1
		--end

insert into pos_month_report(
 m_year, m_month,gid, [sid] ,en_num, en_money, enth_num, enth_money, oo_num, oo_money, ooth_num,ooth_money, ts_num,ts_money, mo_num, mo_money,mi_num,mi_money, yk_num, yk_money, price, start_money, start_num, end_money, end_num,shid,reporttype,add_man,add_time
) 
select 
m_year, m_month, gid, sid, en_num, en_money, enth_num, enth_money, oo_num, oo_money, ooth_num, ooth_money, ts_num, ts_money, mo_num, mo_money, mi_num, mi_money, yk_num, yk_money, price,
start_money, start_num, end_money, end_num,@shid,0,@add_man,GETDATE()
from #p1

if @outResult!=''
		begin
				select INFO=@outResult;
		end
		else
		begin
				IF EXISTS(SELECT * FROM #p1)
				BEGIN
					select * from #p1
				END
				ELSE
				BEGIN
					select INFO='所选月份没有数据!';
				END
		end

		
		
end
else if @op_type='删除'
begin
    declare @next_year int=datepart(year,DATEADD(month,1,convert(datetime,@date_str)));
	declare @next_month int=datepart(month,DATEADD(month,1,convert(datetime,@date_str)));
	if exists(select * from pos_month_report where m_month=@next_month and m_year=@next_year and shid=@shid)
		begin
			--存在下个月的报表，不能删除
			set @outResult='下个月的月报已生成，无法删除！'
			select INFO=@outResult;
			return;	
	   end
    else
    begin
        delete pos_month_report where m_month=@month and m_year=@year and shid=@shid
        set @outResult='删除成功！'
			select INFO=@outResult;
			return;	
    end
end


END
go

