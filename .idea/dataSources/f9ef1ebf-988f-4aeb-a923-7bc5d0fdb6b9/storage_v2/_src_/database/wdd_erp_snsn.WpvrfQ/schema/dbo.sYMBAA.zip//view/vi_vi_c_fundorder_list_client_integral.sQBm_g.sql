CREATE VIEW [dbo].[vi_vi_c_fundorder_list_client_integral] AS 
SELECT 
qm,
Count,
qc,
fo_id,
fo_erp_id,
fo_type,
fo_ciid,
fo_bs,
fo_orderid,
(SELECT si_name FROM b_stafftinfo WHERE si_id= fo_takeman) as takeman,
fo_ticketno,
fo_realmoney,
fo_thiyetmoney,
CONVERT(varchar(100), fo_ofdate, 23) AS fo_ofdate,
fo_remark,
fo_lastman,
fo_status,
fo_outmoney,
fo_admoney,
fo_otheronmoney,
fo_otheoutmoney,
fo_givemoney,
fo_ensuremoney,
fo_subscription,
fo_no,
fo_addtime,
fo_updatetime,
fo_rowNum,
ciname,
qcje,
fo_userorderno,
cicode,
fo_cp_id,
qc_integral, fo_realmoney_integral, fo_thiyetmoney_integral, fo_outmoney_integral, fo_otheronmoney_integral, fo_otheoutmoney_integral, fo_givemoney_integral, qm_integral,
shname,
cpname,
fo_order_id=CASE WHEN 
ISNULL(fo_ciid,0)=0 THEN CASE WHEN ISNULL(fo_shid,0)=0 THEN fo_to_cpid ELSE fo_shid
                         
                         END
                         ELSE fo_ciid
END
FROM   vi_c_fundorder_list WHERE integral_status=0
--WHERE qm_user_integral!=0
UNION ALL
SELECT *,NULL AS shname,NULL AS cpname,fo_order_id=fo_ciid
FROM   vi_client_qcqm_integral AS fd
go

