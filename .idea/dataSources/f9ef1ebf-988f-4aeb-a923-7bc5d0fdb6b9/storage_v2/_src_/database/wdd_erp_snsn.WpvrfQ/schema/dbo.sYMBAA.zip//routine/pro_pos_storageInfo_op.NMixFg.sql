
CREATE PROCEDURE [dbo].[pro_pos_storageInfo_op]
       @sei_id INT ,
       @sei_erp_id INT ,
       @sei_sh_id INT ,
       @sei_name VARCHAR(50) ,
       @sei_code VARCHAR(50) ,
       @sei_siid INT ,
       @sei_phone VARCHAR(20) ,
       @sei_address VARCHAR(200) ,
       @sei_remark VARCHAR(500) ,
       @sei_is_default INT ,
       @sei_status INT ,
       @sei_add_man INT ,
       @sei_add_time DATETIME ,
       @sei_update_man INT ,
       @sei_update_time DATETIME ,
       @sei_is_negative_inventory INT ,
       @sei_is_info INT ,
       @sei_is_tb INT ,
       @sei_is_net INT ,
       @sei_is_net_refund INT=0 ,
	   --操作类型(1:添加 2:修改 3:删除)
       @op_type INT = 0 ,
       @outResult INT OUTPUT
AS
       BEGIN
             IF @op_type = 1
                BEGIN
                      INSERT    INTO [pos_storageInfo]
                                ( [sei_sh_id] ,
                                  [sei_name] ,
                                  [sei_code] ,
                                  [sei_siid] ,
                                  [sei_phone] ,
                                  [sei_address] ,
                                  [sei_remark] ,
                                  [sei_is_default] ,
                                  [sei_status] ,
                                  [sei_add_man] ,
                                  [sei_add_time] ,
                                  [sei_update_man] ,
                                  [sei_update_time] ,
                                  [sei_is_negative_inventory] ,
                                  [sei_is_info] ,
                                  [sei_is_tb] ,
                                  [sei_is_net] ,
                                  [sei_is_net_refund] ,
                                  sei_erp_id
	                            )
                      VALUES    ( @sei_sh_id ,
                                  @sei_name ,
                                  @sei_code ,
                                  @sei_siid ,
                                  @sei_phone ,
                                  @sei_address ,
                                  @sei_remark ,
                                  @sei_is_default ,
                                  @sei_status ,
                                  @sei_add_man ,
                                  @sei_add_time ,
                                  @sei_update_man ,
                                  @sei_update_time ,
                                  @sei_is_negative_inventory ,
                                  @sei_is_info ,
                                  @sei_is_tb ,
                                  @sei_is_net ,
								  @sei_is_net_refund ,
                                  @sei_erp_id
	                            )
                      SET @sei_id = SCOPE_IDENTITY()
                END
	
             IF @op_type = 2
                AND @sei_id > 0
                BEGIN
                      UPDATE    [pos_storageInfo]
                      SET       [sei_sh_id] = @sei_sh_id ,
                                [sei_name] = @sei_name ,
                                [sei_code] = @sei_code ,
                                [sei_siid] = @sei_siid ,
                                [sei_phone] = @sei_phone ,
                                [sei_address] = @sei_address ,
                                [sei_remark] = @sei_remark ,
                                [sei_is_default] = @sei_is_default ,
                                [sei_status] = @sei_status ,
                                [sei_update_man] = @sei_update_man ,
                                [sei_update_time] = @sei_update_time ,
                                [sei_is_negative_inventory] = @sei_is_negative_inventory ,
                                [sei_is_info] = @sei_is_info ,
                                [sei_is_tb] = @sei_is_tb ,
                                [sei_is_net] = @sei_is_net ,
                                [sei_is_net_refund] = @sei_is_net_refund
                      WHERE     sei_id = @sei_id
                                AND sei_sh_id = @sei_sh_id
                END
	
             IF @op_type = 3
                AND @sei_id > 0
                BEGIN
                      UPDATE    [pos_storageInfo]
                      SET       [sei_status] = @sei_status ,
                                [sei_update_man] = @sei_update_man ,
                                [sei_update_time] = @sei_update_time
                      WHERE     sei_id = @sei_id
                                AND sei_sh_id = @sei_sh_id
                END
	
             IF ( @sei_is_net = 1 )
                BEGIN
                      UPDATE    [pos_storageInfo]
                      SET       sei_is_net = 0
                      WHERE     sei_is_net = 1
                                AND sei_sh_id = @sei_sh_id
                                AND sei_id <> @sei_id
                END
	
             IF @@error <> 0
                SET @outResult = 0;
             ELSE
                SET @outResult = @sei_id;

             RETURN @outResult;
       END
go

