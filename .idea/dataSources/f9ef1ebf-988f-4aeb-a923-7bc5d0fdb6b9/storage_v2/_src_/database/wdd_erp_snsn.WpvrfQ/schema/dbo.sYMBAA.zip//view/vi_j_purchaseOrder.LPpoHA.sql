CREATE VIEW [dbo].[vi_j_purchaseOrder]
	AS 
	
--用于采购入库单
SELECT T.pl_id,
       T.pll_pl_id,
       T.pl_vo, --凭证号 
       T.pl_no, --单据号
       CONVERT(varchar(100), T.pl_date, 23)pl_date, --日期 
       T.pl_pltype, --退货
       T.pll_gi_id, 
       T.pll_gi_id gi_id, 
      (SELECT gi_code FROM b_goodsinfo WHERE gi_id=pll_gi_id)gi_code,--商品编号
      (SELECT gi_barcode FROM b_goodsinfo WHERE gi_id=pll_gi_id)gi_barcode,--商品条形码
      (SELECT gi_name FROM b_goodsinfo WHERE gi_id=pll_gi_id)gi_name,--商品名称
      (SELECT gi_skus FROM b_goodsinfo WHERE gi_id=pll_gi_id)gi_skus,--商品规格
      (SELECT ut_name FROM b_unit WHERE ut_id=(SELECT gi_unit
                                             FROM b_goodsinfo 
                                             WHERE gi_id=pll_gi_id))gi_unit,--单位
       (SELECT gi_factoryprice FROM b_goodsinfo WHERE gi_id=pll_gi_id)gi_factoryprice,--出厂价
       MAX(T.pll_retail_price)pll_retail_price, --零售价
       SUM(pll_num *pll_retail_price) AS pll_retail_money,--零售金额
       MAX(T.pll_discount)pll_discount,   --进货折扣
       MAX(T.pll_stock_price)pll_stock_price,  --进货价
       MAX(T.pll_pm)pll_pm,  --配码
       SUM(T.pll_num)pll_num, --数量
       SUM(T.pll_num_ed)pll_num_ed, --已执行数量
       SUM((pll_num-ISNULL(pll_pause_num1,0)-ISNULL(pll_num_ed,0)))rk_el_number_do, --未执行数量
       SUM(T.rkth_el_number)rkth_el_number,
       SUM((pll_num-ISNULL(pll_pause_num1,0)- ISNULL(rkth_el_number,0)))rkth_el_number_do,
       SUM(T.pll_pause_num1)pll_pause_num1, --终止数量
       SUM(T.pll_money)pll_money, --金额
       SUM(T.pll_totalintegral)pll_totalintegral, --采购积分
       T.pl_type, --采购方式
       CONVERT(varchar(100), T.pll_add_time, 21)pll_add_time,  --商品添加时间
       T.pl_ci_id, --供应商id
      (SELECT si_code FROM b_supplierinfo WHERE si_id=pl_ci_id)si_code,--供应商代号
      (SELECT si_name FROM b_supplierinfo WHERE si_id=pl_ci_id)pl_ci_id_txt, --供应商名称
       T.pl_order_man,
      (SELECT si_name FROM b_stafftinfo WHERE si_id=pl_order_man)pl_order_man_txt,--经手人
       T.pl_add_man, 
       T.pl_add_time, 
      (SELECT si_name FROM b_stafftinfo WHERE si_id=pl_add_man)pl_add_man_txt,--添加人
       T.pl_update_man, 
       T.pl_update_time,
      (SELECT si_name FROM b_stafftinfo WHERE si_id=pl_update_man)pl_update_man_txt,--修改人
       T.pl_audit_man, 
       T.pl_audit_time, 
      (SELECT si_name FROM b_stafftinfo WHERE si_id=pl_audit_man)pl_audit_man_txt,--审核人
       T.pl_remark, --备注
       T.pl_status, --单据状态
       T.pl_source, --来源类型
       T.pl_source_id,  --来源单据id
       T.pl_cp_id,  
       T.pl_erp_id
FROM (

	SELECT *,
		   ISNULL(
			(
				SELECT
					abs(sum(fd2.el_number)) AS el_number
				FROM j_enterStorage AS fd WITH (NOLOCK)
				INNER JOIN j_enterStorageList AS fd2  WITH (NOLOCK) ON fd.eo_id = fd2.el_eoid
				AND fd.eo_source_type = 1
				AND fd2.el_status = 1
				AND fd.eo_status <> 0
				AND fd2.el_source_id IN (
									SELECT jpsl.pll_id
									FROM j_purchaseStorageList jpsl
									WHERE jpsl.pll_pl_id = pll_pl_id
										)
				AND fd2.el_source_add_time = pll_add_time
				AND fd2.el_siid=pll_gi_id
				AND fd2.el_skuid=pll_sku_id
			),
			0
		) AS pll_num_ed, --已执行数量
		ISNULL(
		(
			SELECT
				SUM (fd2.el_number) AS el_number
			FROM
				dbo.j_enterStorage AS fd  WITH (NOLOCK)
			INNER JOIN dbo.j_enterStorageList AS fd2   WITH (NOLOCK) ON fd.eo_id = fd2.el_eoid
			AND fd.eo_source_type = 1
			AND fd.eo_source_id = pll_pl_id
			AND fd2.el_status = 1
			AND fd.eo_status <> 0
			AND fd.eo_type = 1
			AND fd2.el_source_id IN (
				SELECT
					jpsl.pll_id
				FROM
					j_purchaseStorageList jpsl WITH (NOLOCK) 
				WHERE
					jpsl.pll_pl_id = pll_pl_id
			)
			AND fd2.el_source_add_time = pll_add_time
		),
		0
	) AS rkth_el_number,
		ISNULL(pll_pause_num,0)pll_pause_num1 --终止数量
	FROM j_purchaseStorage 
	LEFT JOIN j_purchaseStorageList
	ON pl_id=pll_pl_id
	WHERE pl_status>0 AND pll_status=1

)T

GROUP BY T.pl_id,
         T.pll_pl_id,
         T.pl_vo, --凭证号 
         T.pl_no, --单据号
	     T.pl_date, --日期 
	     T.pl_pltype, --退货
	     T.pll_gi_id, 
	     T.pl_type, --采购方式
	     T.pll_add_time,  --商品添加时间
	     T.pl_ci_id, --供应商id
	     T.pl_order_man, 
	     T.pl_add_man, 
	     T.pl_add_time,  
	     T.pl_update_man, 
	     T.pl_update_time, 
	     T.pl_audit_man, 
	     T.pl_audit_time, 
	     T.pl_remark, --备注
	     T.pl_status, --单据状态
	     T.pl_source, --来源类型
	     T.pl_source_id,  --来源单据id
	     T.pl_cp_id,  
	     T.pl_erp_id
go

