CREATE  Proc [dbo].[pro_purchaseStorage_excel]
@id INT=0
AS
SELECT [pll_gi_id],[日期],[供应商代码],[供应商名称],[商品编码],[商品名称],[单位],[颜色编码],[颜色名称],[尺码],[尺码数量],[零售价],[条形码]
INTO #p
 FROM (
SELECT *,
'颜色编码'=case when fd.gs_columnid=fd.second_id then (SELECT TOP 1 fd2.gd_code
FROM s_goodsruledetail fd2 WHERE fd2.gs_id=fd.first_id AND fd2.gd_name=fd.first_txt) ELSE (SELECT TOP 1 fd2.gd_code
FROM s_goodsruledetail fd2 WHERE fd2.gs_id=fd.second_id AND fd2.gd_name=fd.second_txt) END,
'颜色名称'=case when fd.gs_columnid=fd.second_id then fd.first_txt ELSE fd.second_txt END,
'尺码'= case when fd.gs_columnid=fd.second_id then fd.second_txt ELSE fd.first_txt END FROM (
SELECT 
fd2.pll_gi_id,
replace(convert(varchar(50),fd.pl_date,23),'-','') AS '日期',
fd3.si_code AS'供应商代码',
fd3.si_name AS'供应商名称',
fd4.gi_code AS'商品编码',
fd4.gi_name AS'商品名称',
fd5.ut_name AS'单位',
'尺码数量'=fd2.pll_num,
fd6.gs_name,fd4.gi_retailprice AS '零售价',
'条形码'=case when fd6.gss_no is null 
then fd4.gi_barcode else fd6.gss_no END,
fd6.gs_id,
fd6.gs_columnid,
dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(fd6.gs_name,'|',1),':',2) AS first_txt,
dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(fd6.gs_name,'|',2),':',2) AS second_txt,
dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(fd6.gs_id,'/',1),'-',1) AS first_id,
dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(fd6.gs_id,'/',2),'-',1) AS second_id
FROM j_purchaseStorage fd
INNER JOIN j_purchaseStorageList fd2
ON fd.pl_id=fd2.pll_pl_id
AND fd2.pll_status=1
INNER JOIN b_supplierinfo fd3 ON fd.pl_ci_id=fd3.si_id
INNER JOIN b_goodsinfo fd4 ON fd2.pll_gi_id=fd4.gi_id
INNER JOIN b_unit fd5 ON fd4.gi_unit=fd5.ut_id
LEFT JOIN b_goodsruleset fd6 ON fd2.pll_gi_id=fd6.gi_id
AND fd2.pll_sku_id=fd6.gss_id
WHERE fd.pl_id=@id
) AS fd
) AS fd

DECLARE @sql NVARCHAR(MAX)='';
DECLARE @name VARCHAR(50)='';

DECLARE sopcor CURSOR FOR
--规格大类
SELECT fd.a_name FROM (
SELECT  fd.a_name,MAX(fd.a_id) AS a_id  FROM b_attribute fd WHERE fd.a_type=1
AND fd.a_pid=0 AND fd.a_status=1
GROUP BY fd.a_name
) AS fd ORDER BY fd.a_id
OPEN sopcor
FETCH NEXT FROM sopcor INTO @name
  WHILE @@FETCH_STATUS =0
  begin
   SET @sql=REPLACE('ALTER TABLE #p ADD [{0}] VARCHAR(MAX);','{0}',@name);
   exec sp_executesql @sql
  FETCH NEXT FROM sopcor INTO @name
  End
CLOSE sopcor
DEALLOCATE sopcor

DECLARE @update_column VARCHAR(50)='';
DECLARE @row_value VARCHAR(100)='';
DECLARE @gi_id INT=0;


SELECT fd3.a_name  AS p_name, fd2.a_name,fd.a_gi_id INTO #p2 FROM b_attribute_set fd INNER JOIN b_attribute fd2 ON fd.a_a_id=fd2.a_id
INNER JOIN b_attribute fd3 ON fd2.a_pid=fd3.a_id
WHERE fd.a_type=1 AND fd.a_gi_id IN (
SELECT DISTINCT jp.pll_gi_id
FROM j_purchaseStorageList jp WHERE jp.pll_pl_id=@id
AND jp.pll_status=1 )ORDER BY fd3.a_id 


DECLARE sopcor_1 CURSOR FOR
SELECT * FROM #p2
OPEN sopcor_1
FETCH NEXT FROM sopcor_1 INTO @update_column,@row_value,@gi_id
  WHILE @@FETCH_STATUS =0
  begin
   SET @sql=REPLACE(REPLACE(REPLACE('UPDATE #p SET [{0}]=''{1}'' WHERE pll_gi_id={2}','{0}',@update_column),'{1}',@row_value),'{2}',@gi_id);
   PRINT @sql
   exec sp_executesql @sql
  FETCH NEXT FROM sopcor_1 INTO @update_column,@row_value,@gi_id
  End
CLOSE sopcor_1
DEALLOCATE sopcor_1


ALTER TABLE #p DROP COLUMN pll_gi_id  


SELECT * FROM #p

go

