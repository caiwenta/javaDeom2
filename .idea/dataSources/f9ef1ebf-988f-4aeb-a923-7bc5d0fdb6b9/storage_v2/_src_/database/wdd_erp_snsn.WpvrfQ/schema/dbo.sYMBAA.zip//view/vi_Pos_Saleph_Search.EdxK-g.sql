CREATE VIEW [dbo].[vi_Pos_Saleph_Search] AS 
SELECT
	sa.sa_sh_id,
	bg.gi_code,
	bg.gi_skus,
	sal.sal_gi_id,
	sal.sal_sa_id,
	sal.sal_add_time,
	bg.gi_name,
	bg.gi_barcode,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bg.gi_brandsid,
	(
		SELECT
			gb_name
		FROM
			s_goodsbrand WITH (NOLOCK)
		WHERE
			gb_id = bg.gi_brandsid
		AND gb_status > 0
	) AS gb_name,
	sal.sal_num,
	sal.sal_money,
	sa.sa_co_man,
	sa.sa_me_id,
	(
	    SELECT 
		    st_st_id
	    FROM    
	        dbo.pos_staffClassSet WITH (NOLOCK)
       WHERE
	       (st_id = sa.sa_co_man)
    ) AS sa_co_man_txt,
	sal.sal_sku_id,
	gs_id,
	gs_name,
	(
		SELECT
			sh_name
		FROM
			pos_shop WITH (NOLOCK)
		WHERE
			sh_id = sa.sa_sh_id
	) AS sa_sh_id_txt,
	(
		SELECT
			sh_company
		FROM
			pos_shop WITH (NOLOCK)
		WHERE
			sh_id = sa.sa_sh_id
	) AS sh_company,
	ISNULL(
		(
			SELECT
				me_name
			FROM
				pos_memberInfo WITH (NOLOCK)
			WHERE
				me_id = sa_me_id
		),
		'零售'
	) AS sa_me_id_txt,
	ISNULL(
		(
			SELECT
				me_card
			FROM
				pos_memberInfo WITH (NOLOCK)
			WHERE
				me_id = sa_me_id
		),
		'零售'
	) AS sa_me_id_codetxt,
	sa.sa_date,
	sa.sa_erp_id,
	sal.sal_is_gift,
	sa.sa_salman,
    sa.sa_salmanname
FROM
	pos_saleList sal WITH (NOLOCK)
INNER JOIN pos_sale sa  WITH (NOLOCK) ON sal.sal_sa_id = sa.sa_id
INNER JOIN b_goodsinfo bg  WITH (NOLOCK) ON sal.sal_gi_id = bg.gi_id
INNER JOIN b_goodsruleset  WITH (NOLOCK) ON sal.sal_sku_id = gss_id
WHERE
	sal.sal_status > 0
AND sa.sa_status > 0
go

