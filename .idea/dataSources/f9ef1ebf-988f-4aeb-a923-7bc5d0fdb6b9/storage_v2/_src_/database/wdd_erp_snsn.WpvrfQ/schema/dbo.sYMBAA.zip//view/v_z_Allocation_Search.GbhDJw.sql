 CREATE VIEW v_z_Allocation_Search
 as
 SELECT      
             al.al_review,
             al.al_vo,
             al.al_no,
             CONVERT (VARCHAR(10), al_date, 120) AS al_date,
             al.al_type,
             al.al_trans,
             al.al_freight_no,
             al.al_fright,
             al.al_source,
             al.al_add_time,
             al.al_update_time,
             al.al_audit_time,
             al.al_status,
             al.al_id,
             al.al_source_id,
             al.al_cp_id,
             al.al_di_id,

             (SELECT ci_name FROM b_clientinfo AS bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id) AS al_ci_id_txt,
             al_ci_id,
             (SELECT ci_code FROM b_clientinfo AS bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ) AS al_ci_code_txt,
             (SELECT ci_province FROM b_clientinfo AS bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ) AS ci_province,
             (SELECT ci_city FROM b_clientinfo AS bs  WITH (NOLOCK)  WHERE ci_id = al.al_ci_id) AS ci_city,
             (SELECT	sh_name	FROM pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ) AS al_sh_id_txt,
             al_sh_id,
             (SELECT province FROM dbo.pos_shop AS bs  WITH (NOLOCK)  WHERE sh_id = al.al_sh_id) AS sh_province,
             (SELECT city FROM pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id) AS sh_city,
             (SELECT cp_name FROM companyinfo AS bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id) AS al_to_cp_id_txt,
             al.al_to_cp_id,
             (SELECT sei_name FROM b_storageinfo AS bs  WITH (NOLOCK) WHERE sei_id = al.al_st_id) AS al_st_id_txt,
             (SELECT cp_province FROM companyinfo AS bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id) AS cp_province,
             (SELECT cp_city FROM companyinfo AS bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id) AS cp_city,
             al_st_id,
             (SELECT si_name FROM b_stafftinfo AS bs  WITH (NOLOCK) WHERE si_id = al.al_order_man) AS al_order_man_txt,
             al_order_man,
             (SELECT si_name FROM b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_add_man) AS al_add_man_txt,
             al_add_man,
             (SELECT si_name FROM b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_update_man) AS al_update_man_txt,
             al_update_man,
             (SELECT si_name FROM b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_audit_man ) AS al_audit_man_txt,
             al_audit_man,
   
             CASE al.al_source
             WHEN 1 THEN
             (
             SELECT og_no FROM pos_ogStorage AS bs  WITH (NOLOCK) WHERE og_id = al.al_source_id
             )
             WHEN 2 THEN
             (
             SELECT re_no FROM pos_reStorage AS bs  WITH (NOLOCK) WHERE re_id = al.al_source_id
             )
             WHEN 3 THEN
             (
             SELECT in_no FROM pos_inStorage AS bs  WITH (NOLOCK) WHERE in_id = al.al_source_id
             )
             WHEN 5 THEN
             (
             SELECT og_no FROM pos_ogStorage AS bs  WITH (NOLOCK) WHERE og_id = al.al_source_id
             )
             END AS al_source_id_txt,
             CASE al_source
             WHEN 2 THEN
             (
             SELECT re_vo FROM pos_reStorage AS bs  WITH (NOLOCK) WHERE re_id = al.al_source_id
             )
             WHEN 3 THEN
             (
             SELECT in_vo FROM pos_inStorage AS bs  WITH (NOLOCK) WHERE in_id = al.al_source_id
             )
             WHEN 5 THEN
             (
             SELECT og_vo FROM pos_ogStorage AS bs  WITH (NOLOCK) WHERE og_id = al.al_source_id
             )
             END AS al_source_vo,
             (SELECT ci_attribute_ids FROM b_clientinfo  WITH (NOLOCK) WHERE ci_id = al.al_ci_id) AS ci_attribute_ids,
             (SELECT ci_attribute_parentids FROM b_clientinfo  WITH (NOLOCK) WHERE ci_id = al.al_ci_id) AS ci_attribute_parentids,
             (SELECT sh_attribute_ids FROM pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id) AS sh_attribute_ids,
             (SELECT sh_attribute_parentids FROM pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id) AS sh_attribute_parentids,
             alm.all_al_id,
             alm.all_gi_id,
             alm.all_num,
             alm.all_id,
             alm.all_money,
             alm.all_retail_price,
             alm.all_stock_price,
             alm.all_discount,
             alm.all_sku_id,
             alm.all_gift,
             alm.all_status,
             alm.all_box_num,
             alm.all_pm,
             ISNULL(fd.ol_number, 0) AS all_num_ed,
             (alm.all_num - ISNULL(fd.ol_number, 0)) - ISNULL(alm.all_pause_num, 0) AS all_num_ding,
             (alm.all_num - ISNULL(fd.ol_number, 0)) - ISNULL(alm.all_pause_num, 0) AS all_num_do,
             (alm.all_num - ISNULL(fd.ol_number, 0)) - ISNULL(alm.all_pause_num, 0) AS all_num_end,
             alm.all_pause_num AS all_pause_num1,
             CONVERT (VARCHAR (100),alm.all_add_time,25) AS all_add_time,
             CONVERT (VARCHAR (100),alm.all_source_add_time,25) AS all_source_add_time,


             (SELECT fd.og_vo FROM pos_ogStorage fd WITH (NOLOCK) WHERE
             fd.og_id = (SELECT MAX (fd.ogl_og_id) FROM pos_ogStorageList fd WITH (NOLOCK)  WHERE
             fd.ogl_add_time = alm.all_source_add_time
             )) AS og_vo,


             bg.gi_id,
             bg.gi_shortname,
             bg.gi_name,
             bg.gi_type,
             bg.gi_code,
             bg.gi_grade,
             bg.gi_norm,
             bg.gi_status,
             bg.gi_remark,
             bg.gi_entrydate,
             bg.si_img,
             bg.gi_skus,
             bg.gi_alarmstock,
             bg.gi_barcode,
             bg.gi_brands,
             bg.gi_category,
             bg.gi_costprice,
             bg.gi_downstork,
             bg.gi_importprices,
             bg.gi_number,
             bg.gi_retailprice,
             bg.gi_seiid,
             bg.gi_seiname,
             bg.gi_typeone,
             bg.gi_types,
             bg.gi_typesid,
             bg.gi_upstock,
             bg.gi_virtual,
             bg.gi_weight,
             bg.gi_simplecode,
             bg.gi_brandsid,
             bg.gi_skuid,
             bg.gi_purchase,
             bg.gi_addtime,
             bg.gi_updatetime,
             bg.gi_class,
             bg.gi_class_id,
             bg.gi_oc_id,
             bg.gi_tid,
             bg.gi_taobao_id,
             bg.gi_attribute_ids,
             bg.gi_attribute_parentids,

             bu.ut_id AS gi_unit,
             bu.ut_id AS gi_unit_id,
             bu.ut_name AS gi_unit_name
             from
             (
             SELECT
             all_al_id,
             all_gi_id,
             all_add_time,
             CONVERT (VARCHAR (100),MIN (all_source_add_time),25) AS all_source_add_time,
             SUM (al.all_pause_num) AS all_pause_num,
             SUM (all_num) AS all_num,
             MIN (all_id) AS all_id,
             MAX (all_sku_id) AS all_sku_id,
             SUM (all_money) AS all_money,
             SUM (all_retail_money) AS all_retail_money,
             MIN (all_gift) AS all_gift,
             MAX (all_status) AS all_status,
             CONVERT (DECIMAL (10, 2),AVG (all_retail_price)) AS all_retail_price,
             CONVERT (DECIMAL (10, 2),AVG (all_stock_price)) AS all_stock_price,
             CONVERT (DECIMAL (10, 2),AVG (all_discount)) AS all_discount,
             MAX (REPLACE(all_pm, '*', ',')) AS all_pm,
             MAX (all_box_num) AS all_box_num
             FROM pos_allocationList AS al   
             where al.all_status > 0 
             GROUP BY
             all_al_id,
             all_gi_id,
             all_add_time
             ) 
             AS alm 
             INNER JOIN pos_allocation AS al   WITH (NOLOCK) ON alm.all_al_id = al.al_id AND  al.al_status > 0
             INNER JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON alm.all_gi_id = bg.gi_id
             INNER JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
             LEFT JOIN  
             (

             SELECT 
             oo_source_id,
             ol_siid,
             ol_source_add_time,
             SUM (ol_number) AS ol_number
             FROM   j_outStorage          AS jos WITH (NOLOCK) 
             INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) 
             ON  jos.oo_id = josl.ol_eoid
             WHERE  jos.oo_source_type = 1 
             AND jos.oo_source_id > 0
             AND josl.ol_status = 1
             AND jos.oo_status > 0
             GROUP BY
             oo_source_id,
             ol_siid,
             ol_source_add_time      
             ) AS fd 
             ON alm.all_add_time = fd.ol_source_add_time and alm.all_gi_id=fd.ol_siid
 go

