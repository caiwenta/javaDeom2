




CREATE VIEW [dbo].[vi_j_takeStorageLog] AS 
SELECT jt.tsl_id,
       CONVERT(varchar(100),jt.tsl_date,23)tsl_date ,
       jt.tsl_status,
       jt.tsl_type,
       jt.tsl_add_time,
       jt.tsl_cp_id,
       jt.tsl_di_id,
       jt.tsl_update_time,
       jt.tsl_remark,
       jt.tsl_st_id tsl_st_id_id,
       bs.si_name               AS tsl_add_man,
       bs2.si_name              AS tsl_update_man,
       bs3.sei_name             AS tsl_st_id,
	   (select isnull(max(do_id),0) from j_takeStorage where ts_tsl_id=jt.tsl_id)do_id,
	   (case when (SELECT COUNT(*) FROM erp_distributionpdaing WHERE do_id in(SELECT do_id FROM erp_distributionorder WHERE warehousingtype=17 and do_status<>0 AND do_source_id=jt.tsl_id) )>0 then '已派单' else '未派单' end)plstatus
	  
FROM   j_takeStorageLog         AS jt
       LEFT JOIN b_stafftinfo   AS bs
            ON  jt.tsl_add_man = bs.si_id
       LEFT JOIN b_stafftinfo   AS bs2
            ON  jt.tsl_update_man = bs2.si_id
       INNER JOIN b_storageinfo  AS bs3
            ON  jt.tsl_st_id = bs3.sei_id
go

