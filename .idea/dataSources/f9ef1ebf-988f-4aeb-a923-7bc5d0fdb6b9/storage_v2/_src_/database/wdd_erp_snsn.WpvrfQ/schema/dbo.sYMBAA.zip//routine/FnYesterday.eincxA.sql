CREATE FUNCTION [dbo].[FnYesterday]
(
	@date DATETIME,
	@dayNum int=7
)
RETURNS @returntable TABLE
(
    num int,
	yday DATETIME
)
AS
BEGIN
    declare @beginNum int=1;
	while(@beginNum<=@dayNum)
    begin
	  insert into @returntable 
	  select @beginNum,CONVERT(VARCHAR(100),dateadd(day,-@beginNum,@date),23);
	  set @beginNum=@beginNum+1
	end; 
	RETURN
END
go

