

 CREATE VIEW [dbo].[vi_allocation_sku_outed] AS     
SELECT all_source_id,
       all_source_add_time,
       all_sku_id,
       MAX(all_gi_id)     AS all_gi_id,
       SUM(all_num)       AS all_num,
       MAX(al_source_id)  AS al_source_id
FROM   pos_allocationList
       INNER JOIN pos_allocation
            ON  all_al_id = al_id
WHERE  al_status > 0
       AND all_status > 0
       AND al_source = 5
       AND all_source_id > 0
       --AND all_source_add_time > 0
GROUP BY
       all_source_id,
       all_sku_id,
       all_source_add_time

 go

