CREATE FUNCTION [dbo].[FnCheckStock]
(
	@cp_id int,
	@old_sei_id int,
	@new_sei_id int
)
RETURNS INT
AS
BEGIN
	--用途：验证存库是否为负
    DECLARE @re INT=0;
	IF EXISTS (SELECT  * FROM  ( SELECT sl.[sid] , sl.gid , sl.skuid , sl.cp_id ,isnull(sl.pm,'') as pm,
                                                        SUM(CASE WHEN sl.countType = 1 THEN sl.gnum
                                                                 ELSE -sl.gnum
                                                            END) AS gnum
                                              FROM      vi_stockList sl
                                                        INNER JOIN b_storageinfo fd WITH ( NOLOCK ) ON sl.[sid] = fd.sei_id
                                              WHERE     sl.cp_id = @cp_id and
											            sl.[sid] in(@old_sei_id,@new_sei_id)
                                                        AND fd.sei_is_negative_inventory = 0
                                                        AND fd.sei_cp_id = @cp_id
                                              GROUP BY  sl.[sid] ,
                                                        sl.gid ,
                                                        sl.skuid ,
                                                        sl.cp_id,
														isnull(sl.pm,'') 
                                            ) AS fd
                                    WHERE   fd.gnum < 0 )
    BEGIN

	    SET @re = 1;
	END
	RETURN @re;
END
go

