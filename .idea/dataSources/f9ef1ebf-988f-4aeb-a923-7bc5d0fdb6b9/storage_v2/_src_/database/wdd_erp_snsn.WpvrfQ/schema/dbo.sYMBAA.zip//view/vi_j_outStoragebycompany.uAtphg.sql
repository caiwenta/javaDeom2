CREATE VIEW [dbo].[vi_j_outStoragebycompany]
	AS 
SELECT  jis.oo_realmoney ,
        jis.oo_num ,
        jis.oo_id ,
        jis.oo_no ,
		( 
		--SELECT SUM(var_num) FROM erp_inspectionofgoods AS ei 
	 --   INNER JOIN j_outStoragelist AS jos 
	 --   ON ei.sku_id=jos.ol_skuid AND ei.gi_id=jos.ol_siid AND ei.orderid=jos.ol_eoid
	 --   WHERE orderid=jis.oo_id and ei.warehousingtype=2 and ei.iog_status=1 AND ei.iog_status>0

		SELECT SUM(var_num) 
		FROM erp_inspectionofgoods AS ei 
		INNER join (
				SELECT jos.ol_skuid,jos.ol_siid 
				FROM j_outStoragelist jos 
				where jos.ol_status=1 and jos.ol_eoid=jis.oo_id
				GROUP BY jos.ol_skuid,jos.ol_siid
		) as jos ON ei.sku_id=jos.ol_skuid AND ei.gi_id=jos.ol_siid 
		AND orderid=jis.oo_id and ei.warehousingtype=2 AND ei.iog_status>0

		) as var_num,
		isnull(jes.eo_num,0) as ennum, 
        jes.eo_no as in_source_vo, 
        jes.eo_id as in_source_id, 
		CONVERT(VARCHAR(10),jes.eo_entrydate, 120) as eo_entrydate,

		jes.eo_siid,
	  (SELECT   cp_simplename FROM   dbo.companyinfo WHERE cp_erp_id =oo_erp_id AND cp_id=oo_cp_id)  as in_supplier_id_txt,
	    (SELECT   cp_code FROM     dbo.companyinfo WHERE  cp_erp_id =oo_erp_id AND cp_id=oo_cp_id)  AS in_supplier_code_txt,
        CONVERT (VARCHAR(10), jis.oo_entrydate, 120) AS oo_entrydate ,
        jis.oo_manual ,
        jis.oo_type ,
        jis.oo_siid ,
        jis.oo_freight ,
        jis.oo_ciid ,
        jis.oo_cost ,
        jis.oo_takemanid ,
        jis.oo_source_id ,
        jis.oo_cp_id ,
        jis.oo_di_id ,

        ( SELECT    al_vo FROM   dbo.pos_allocation AS bs WITH ( NOLOCK ) WHERE     ( al_id = jis.oo_source_id ) ) AS al_vo ,
        ( SELECT    ci_name FROM    dbo.b_clientinfo AS bs WITH ( NOLOCK ) WHERE     ( ci_id = jis.oo_ciid ) ) AS ci_name ,
        ( SELECT    ci_province FROM   dbo.b_clientinfo AS bs WITH ( NOLOCK ) WHERE     ( ci_id = jis.oo_ciid ) ) AS ci_province ,
        ( SELECT    ci_city FROM      dbo.b_clientinfo AS bs WITH ( NOLOCK ) WHERE     ( ci_id = jis.oo_ciid ) ) AS ci_city ,
        bs.sh_name AS oo_sh_id_txt ,
        bs.sh_no AS sh_no ,
        jis.oo_sh_id ,
        ( SELECT    province FROM    dbo.pos_shop AS bs WITH ( NOLOCK ) WHERE     ( sh_id = jis.oo_sh_id ) ) AS sh_province ,
        ( SELECT    city FROM      dbo.pos_shop AS bs WITH ( NOLOCK ) WHERE     ( sh_id = jis.oo_sh_id ) ) AS sh_city ,
        ( SELECT    ci_code FROM      dbo.b_clientinfo AS bs WITH ( NOLOCK ) WHERE     ( ci_id = jis.oo_ciid ) ) AS ci_code ,
        ( SELECT    sei_name FROM      dbo.b_storageinfo AS bs WITH ( NOLOCK ) WHERE     ( sei_id = jis.oo_siid ) ) AS sei_name ,
        ( SELECT    si_name FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK ) WHERE     ( si_id = jis.oo_takemanid ) ) AS takeman ,
        ( SELECT    si_name
          FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
          WHERE     ( si_id = jis.oo_addman )
        ) AS oo_addman_txt ,
        jis.oo_addman ,
        jis.oo_addtime ,
        ( SELECT    si_name FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK ) WHERE     ( si_id = jis.oo_updatemam ) ) AS oo_updatemam_txt ,
        jis.oo_updatemam ,
        jis.oo_updatetime ,
        ( SELECT    si_name FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK ) WHERE     ( si_id = jis.oo_lastmanid ) ) AS oo_lastman ,
        jis.oo_lastmanid ,
        jis.oo_auditdate ,
        jis.oo_remark ,
        jis.oo_status ,
        cpy.cp_name AS oo_to_cp_id_txt ,
        cpy.cp_code AS cp_code ,
        jis.oo_to_cp_id ,
        ( SELECT  cp_province FROM  dbo.companyinfo AS bs WITH ( NOLOCK ) WHERE     ( cp_id = jis.oo_to_cp_id ) ) AS cp_province ,
        ( SELECT  cp_city FROM  dbo.companyinfo AS bs WITH ( NOLOCK ) WHERE     ( cp_id = jis.oo_to_cp_id ) ) AS cp_city ,
        ( SELECT TOP ( 1 ) in_status FROM      dbo.vi_pos_inStorage AS bs WITH ( NOLOCK ) WHERE  ( in_source_id = jis.oo_id ) AND ( in_source_no = jis.oo_no ) AND ( in_status > 0 ) ) AS in_status ,
        jis.oo_jytype ,
        jis.oo_fo_audit_ed ,
        jis.oo_erp_id,
		jis.oo_source_type
FROM    dbo.j_outStorage AS jis WITH ( NOLOCK )
        LEFT JOIN companyinfo AS cpy WITH ( NOLOCK ) ON cpy.cp_id = jis.oo_to_cp_id
        LEFT JOIN dbo.pos_shop AS bs WITH ( NOLOCK ) ON bs.sh_id = jis.oo_sh_id
		left join j_enterStorage as jes on eo_source_type=2 AND jes.eo_source_id=jis.oo_id AND eo_status>0
go

