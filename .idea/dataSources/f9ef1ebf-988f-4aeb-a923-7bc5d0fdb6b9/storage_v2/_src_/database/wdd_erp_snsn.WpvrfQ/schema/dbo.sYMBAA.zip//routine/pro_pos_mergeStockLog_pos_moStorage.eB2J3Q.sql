CREATE PROCEDURE [dbo].[pro_pos_mergeStockLog_pos_moStorage]
	@tsl_sh_id INT,
	@negative_inventory INT = 0,
	@old_sei_id INT = 0,
	@new_sei_id INT = 0,
	@id INT = 0
AS
	EXEC pro_pos_mergeStockLog_check
	     @tsl_sh_id = @tsl_sh_id,
	     @negative_inventory = @negative_inventory,
	     @old_sei_id = @old_sei_id,
	     @new_sei_id = @new_sei_id
	IF @@ERROR != 0
	BEGIN
	    DECLARE @ERROR_MESSAGE VARCHAR(100) = '';
	    SELECT @ERROR_MESSAGE = ERROR_MESSAGE();
	    RAISERROR (@ERROR_MESSAGE, 16, 1, N'number', 5);
	    RETURN;
	END
	BEGIN
		BEGIN TRAN
		DECLARE @now DATETIME = GETDATE();
		

  update pos_stocklog set sl_status=0 where sl_status = 1 AND sl_shop_id = @tsl_sh_id and sl_eoid=@id AND sl_type between 2 and 3

		   INSERT pos_stocklog 
		(
			sl_eoid ,
            sl_elid ,
            sl_seiid ,
            sl_shop_id ,
            sl_ciid ,
            sl_giid ,
            sl_skuid ,
            sl_type ,
            sl_counttype ,
            sl_number ,
            sl_addtime ,
            sl_updatetime ,
            sl_remark ,
            sl_status ,
            sl_order_no ,
            sl_order_date ,
            sl_order_add_time ,
			sl_pm ,
			sl_erp_id
		)
		select
			so.eoid ,
            so.elid ,
            so.[sid] ,
            so.shid ,
            so.cid ,
            so.gid ,
            so.skuid ,
            so.mytype ,
            so.countType ,
            so.gnum ,
            so.addtime ,
            @now ,
            so.myremark ,
            1 ,
            so.orderno ,
            so.order_date ,
            so.order_add_time ,
			isnull(so.pm,'') ,
			so.erp_id
			from (

SELECT 
--'' AS                            ord_no,
       jms.mo_out_st_id              AS SID,
       jms.mo_sh_id                  AS shid,
       cid = 0,
       jmsl.mol_gi_id                AS gid,
       jmsl.mol_sku_id               AS skuid,
       jmsl.mol_num                  AS gnum,
	   isnull(jmsl.mol_pm,'')        As pm ,
       countType = 0,
       myremark = '移出仓库',
       addtime = jmsl.mol_add_time,
       orderno = mo_vo,
       eoid = mo_id,
       elid = mol_id,
       mytype = 2,
       order_add_time = jms.mo_add_time,
       order_date = jms.mo_date,
       mo_erp_id AS erp_id
FROM   pos_moStorage                 AS jms
       INNER JOIN pos_moStorageList  AS jmsl
            ON  jms.mo_id = jmsl.mol_mo_id and jms.mo_id=@id
WHERE  jms.mo_status > 0
       AND jmsl.mol_status = 1 
       AND jmsl.mol_gi_id > 0
       AND jms.mo_out_st_id > 0
       AND jms.mo_sh_id>0
UNION ALL
SELECT 
--'' AS                            ord_no,
       jms.mo_in_st_id               AS SID,
       jms.mo_sh_id                  AS shid,
       cid = 0,
       jmsl.mol_gi_id                AS gid,
       jmsl.mol_sku_id               AS skuid,
       jmsl.mol_num                  AS gnum,
	   isnull(jmsl.mol_pm,'')        As pm ,
       countType = 1,
       myremark = '移入仓库',
       addtime = jmsl.mol_add_time,
       orderno = mo_vo,
       eoid = mo_id,
       elid = mol_id,
       mytype = 3,
       order_add_time = jms.mo_add_time,
       order_date = jms.mo_date,
       mo_erp_id AS erp_id
FROM   pos_moStorage                 AS jms
       INNER JOIN pos_moStorageList  AS jmsl
            ON  jms.mo_id = jmsl.mol_mo_id and jms.mo_id=@id
WHERE  jms.mo_status > 0
       AND jmsl.mol_status = 1
       AND jmsl.mol_gi_id > 0
       AND jms.mo_in_st_id > 0
       AND jms.mo_sh_id>0
			   
			 ) AS so


		EXEC pro_pos_mergeStockSum_new @tsl_sh_id = @tsl_sh_id,@id=@id ,@type=2

		EXEC pro_pos_mergeStockSum_new @tsl_sh_id = @tsl_sh_id,@id=@id ,@type=3

		DELETE pos_stocklog where sl_status = 0 AND sl_shop_id = @tsl_sh_id AND sl_eoid=@id AND sl_type between 2 and 3


			IF @@ERROR <> 0
			BEGIN
				ROLLBACK TRANSACTION
			END
			ELSE
			BEGIN
				IF @@TRANCOUNT > 0
					COMMIT TRAN
			END
	END
go

