CREATE VIEW [dbo].[vi_vi_c_fundorder_list_client]
AS
select
(CASE WHEN ciname<>'' THEN ciname WHEN shname<>'' THEN shname WHEN cpname<>'' THEN cpname END)objectname,
(select cp_name from companyinfo where cp_id=fo_cp_id) set_cpname ,
TT.* 
from (
SELECT  
        convert(nvarchar(6),fo_ofdate,112)+'1' as firtday,
        DATEPART(year,fo_ofdate) AS fo_year,
        DATEPART(month,fo_ofdate) as moon,
        (CASE DATEPART(month,fo_ofdate) WHEN 1 THEN '1月' WHEN 2 THEN '2月' WHEN 3 THEN '3月' WHEN 4 THEN '4月' WHEN 5 THEN '5月' WHEN 6 THEN '6月' WHEN 7 THEN '7月' WHEN 8 THEN '8月' WHEN 9 THEN '9月' WHEN 10 THEN '10月' WHEN 11 THEN '11月' WHEN 12 THEN '12月' END) AS fo_Month ,
        qm ,
        Count ,
        qc ,
        fo_id ,
        fo_erp_id  as erp_id,
        fo_erp_id,
        fo_type ,
        fo_ciid ,
        fo_shid ,
        fo_to_cpid ,
        fo_bs ,
        fo_orderid ,
        (SELECT si_name FROM b_stafftinfo WHERE si_id = fo_takeman ) AS takeman ,
        fo_ticketno ,
        fo_realmoney ,
        fo_thiyetmoney ,
        CONVERT(VARCHAR(100),fo_ofdate,23) AS fo_ofdate ,
        fo_remark ,
        fo_lastman ,
        fo_status ,
        fo_outmoney ,
        fo_admoney ,
        fo_otheronmoney ,
        fo_otheoutmoney ,
        fo_givemoney ,
        fo_ensuremoney ,
        fo_subscription ,
        fo_no ,
        fo_addtime ,
        fo_updatetime ,
        fo_rowNum ,
        ciname ,
        qcje ,
        fo_userorderno ,
        cicode ,
        fo_cp_id ,
        qc_integral ,
        fo_realmoney_integral ,
        fo_thiyetmoney_integral ,
        fo_outmoney_integral ,
        fo_otheronmoney_integral ,
        fo_otheoutmoney_integral ,
        fo_givemoney_integral ,
        qm_integral ,
        shname ,
        cpname ,
        fo_order_id = CASE WHEN ISNULL(fo_ciid,0) = 0 THEN CASE WHEN ISNULL(fo_shid,0) = 0 THEN fo_to_cpid ELSE fo_shid END ELSE fo_ciid END,
		addman = case when fo_bs='G' and (eo_addman_txt is not null or eo_addman_txt !='')  THEN eo_addman_txt
        when fo_bs='X'  and (oo_addman_txt is not null or oo_addman_txt !='') THEN  oo_addman_txt else fo_addman end
		,remark= case when fo_bs='G' and (eo_remark is not null or eo_remark !='')  THEN eo_remark
        when fo_bs='X'  and (oo_remark is not null or oo_remark !='') THEN  oo_remark else fo_custom_remark end
		,fo_finished_money
		,fo_parts_money,
		fo_queue_status
FROM    vi_c_fundorder_list_new
WHERE   fun_status = 0 and fo_queue_status=1
UNION ALL
SELECT  
        convert(nvarchar(6),fo_ofdate,112)+'1' as firtday,
        DATEPART(year,fo_ofdate) AS fo_year ,
        DATEPART(month,fo_ofdate) as moon,
        (CASE DATEPART(month,fo_ofdate)
           WHEN 1 THEN '1月'
           WHEN 2 THEN '2月'
           WHEN 3 THEN '3月'
           WHEN 4 THEN '4月'
           WHEN 5 THEN '5月'
           WHEN 6 THEN '6月'
           WHEN 7 THEN '7月'
           WHEN 8 THEN '8月'
           WHEN 9 THEN '9月'
           WHEN 10 THEN '10月'
           WHEN 11 THEN '11月'
           WHEN 12 THEN '12月'
         END) AS fo_Month ,
        qm ,
        Count ,
        qc ,
        fo_id ,
        fo_erp_id as erp_id,
        fo_erp_id,
        fo_type ,
        fo_ciid ,
        fo_shid ,
        fo_to_cpid ,
        fo_bs ,
        fo_orderid ,
        fo_takeman ,
        fo_ticketno ,
        fo_realmoney ,
        fo_thiyetmoney ,
        fo_ofdate ,
        fo_remark ,
        fo_lastman ,
        fo_status ,
        fo_outmoney ,
        fo_admoney ,
        fo_otheronmoney ,
        fo_otheoutmoney ,
        fo_givemoney ,
        fo_ensuremoney ,
        fo_subscription ,
        fo_no ,
        fo_addtime ,
        fo_updatetime ,
        fo_rowNum ,
        ciname ,
        qcje ,
        fo_userorderno ,
        cicode ,
        ci_cp_id ,
        qc_integral ,
        fo_realmoney_integral ,
        fo_thiyetmoney_integral ,
        fo_outmoney_integral ,
        fo_otheronmoney_integral ,
        fo_otheoutmoney_integral ,
        fo_givemoney_integral ,
        qm_integral ,
        shname ,
        cpname ,
        fo_order_id = CASE WHEN ISNULL(fo_ciid,0) = 0 THEN CASE WHEN ISNULL(fo_shid,0) = 0 THEN fo_to_cpid
                                                                ELSE fo_shid
                                                           END
                           ELSE fo_ciid
                      END,
					  '',
					  '',
					  0,
					  0,
					  0
FROM    v_fundorder_vi_client_qcqm AS fd
  ) as TT
go

