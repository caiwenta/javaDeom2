CREATE PROC [dbo].[pro_mergeStockSum]
@cp_id INT=0
AS

DECLARE @now DATETIME = GETDATE();
DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
BEGIN TRY

MERGE INTO b_stockinfo AS ta 
USING 
(

Select 
sl.[sid],
sl.gid,
sl.skuid,
sl.cp_id,
Sum(Case when sl.countType=1 Then sl.gnum Else -sl.gnum End)As gnum,
MAX(sl.addtime) AS addtime
From vi_stockList_nolock sl WHERE sl.cp_id=@cp_id 
Group By 
sl.[sid],
sl.gid,
sl.skuid,
sl.cp_id

) AS so
ON 
ta.si_seiid = so.[sid] 
AND ta.si_giid = so.gid 
AND ta.si_skuid = so.skuid 
AND ta.si_cp_id=so.cp_id 
WHEN matched THEN 
UPDATE 
SET    
ta.si_number = so.gnum,
ta.si_status=1,
ta.si_indate=case when  ta.si_number!=so.gnum then @now else ta.si_indate END
WHEN NOT matched THEN
INSERT 
  (
    si_seiid,
    si_giid,
    si_skuid,
    si_number,
    si_status,
    si_indate,
    si_cp_id
  )
VALUES
  (
    so.[sid],
    so.gid,
    so.skuid,
    so.gnum,
    1,
    --so.addtime,
    @now,
    so.cp_id
   
  )
WHEN NOT matched BY source AND ta.si_status != 0 AND ta.si_cp_id=@cp_id THEN 
UPDATE 
SET    ta.si_number=0,
       ta.si_indate =CASE WHEN si_number!=0 THEN  @now ELSE si_indate END;


END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

