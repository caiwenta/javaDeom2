CREATE VIEW [dbo].[vi_j_takeStorage_Search_copy] AS 
SELECT
	*
FROM
(
	--vi_j_takeStorageList_group_goods_search el
	SELECT
	jt.tsl_ts_id,
	jt.tsl_gi_id,
	jt.tsl_old_num,
	jt.tsl_new_num,
	jt.tsl_log_num,
	jt.tsl_sku_id,
	jt.tsl_pm,
	jt.tsl_box_num,
	CONVERT (
		VARCHAR (100),
		jt.tsl_add_time,
		25
	) AS tsl_add_time,
	jt.tsl_old_money,
	jt.tsl_new_money,
	jt.tsl_log_money,
	CONVERT (
		DECIMAL (10, 2),
		jt.tsl_stock_price
	) AS tsl_stock_price,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bu.ut_name AS gi_unit,
	bu.ut_id AS gi_unit_id
	,
       jt.vertical_column_id,
       jt.vertical_column_name
FROM
	(
		SELECT
			tsl_ts_id,
			tsl_gi_id,
			tsl_add_time,
			SUM (tsl_old_num) AS tsl_old_num,
			SUM (tsl_new_num) AS tsl_new_num,
			SUM (tsl_log_num) AS tsl_log_num,
			MAX (tsl_sku_id) AS tsl_sku_id,
			AVG (tsl_stock_price) AS tsl_stock_price,
			SUM (tsl_old_money) AS tsl_old_money,
			SUM (tsl_new_money) AS tsl_new_money,
			SUM (tsl_log_money) AS tsl_log_money,
			tsl_pm='',
			SUM (tsl_box_num) AS tsl_box_num,
			

       fd.vertical_column_id,
       fd.vertical_column_name
		FROM
			(
				
				SELECT jt.*,
				--垂直列,颜色列
                  vertical_column_id = CASE 
                                            WHEN ISNULL(
                                                     dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1),
                                                     0
                                                 ) = 0 THEN --没规格
                                                 0
                                            ELSE CASE 
                                                      WHEN bg.gs_is_custom > 0 THEN CASE 
                                                                                         WHEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1)
                                                                                              )
                                                                                              = 
                                                                                              bg.gs_is_custom THEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 2), '-', 2)
                                                                                              )
                                                                                         ELSE 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 2)
                                                                                              )
                                                                                    END
                                                      ELSE CONVERT(
                                                               INT,
                                                               dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 2)
                                                           )
                                                 END
                                       END,
                  vertical_column_name = CASE 
                                              WHEN ISNULL(
                                                       dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1),
                                                       0
                                                   ) = 0 THEN --没规格
                                                   ''
                                              ELSE CASE 
                                                        WHEN bg.gs_is_custom > 0 THEN CASE 
                                                                                           WHEN 
                                                                                                CONVERT(
                                                                                                    INT,
                                                                                                    dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1)
                                                                                                )
                                                                                                = 
                                                                                                bg.gs_is_custom THEN 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 2), ':', 2)
                                                                                           ELSE 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 1), ':', 2)
                                                                                      END
                                                        ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 1), ':', 2)
                                                   END
                                         END
				
				 FROM (
				SELECT
					tsl_ts_id,
					tsl_gi_id,
					tsl_add_time,
					tsl_old_num,
					tsl_new_num,
					tsl_log_num,
					tsl_sku_id,
					tsl_stock_price,
					tsl_old_money,
					tsl_new_money,
					tsl_log_money,
					tsl_pm,
					tsl_box_num
				FROM
					dbo.j_takeStorageList AS jt
				WHERE
					jt.tsl_status = 1
				UNION ALL
					SELECT
						*, tsl_old_money = cc.sl_number * cc.tsl_stock_price,
						tsl_new_money = cc.tsl_new_num * cc.tsl_stock_price,
						tsl_log_money = cc.tsl_log_num * cc.tsl_stock_price
					FROM
						(
							SELECT
								(
									SELECT
										fd.ts_id
									FROM
										j_takeStorage fd
									WHERE
										fd.ts_vo = js.sl_order_no
								) AS tsl_ts_id,
								js.sl_giid AS tsl_gi_id,
								js.sl_addtime,
								js.sl_number,
								tsl_new_num = 0,
								tsl_log_num =- (js.sl_number),
								tsl_pm = 0,
								tsl_box_num = 0,
								js.sl_skuid,
								tsl_stock_price = (
									SELECT
										fd.gi_purchase
									FROM
										b_goodsinfo fd
									WHERE
										fd.gi_id = js.sl_giid
								)
							FROM
								j_stocklog_pal AS js
							WHERE
								js.sl_status = 2
							AND js.sl_number != 0
							AND js.sl_giid > 0
							AND js.sl_seiid > 0 --AND js.sl_order_no='PD-20150909-0001'
							--order by sl_addtime desc
						) AS cc
						
				) AS  jt	
				LEFT JOIN b_goodsruleset bg
                       ON  jt.tsl_sku_id = bg.gss_id
           
           
           
           
						
			) AS fd
		GROUP BY
			tsl_ts_id,
			tsl_gi_id,
			tsl_add_time,
			vertical_column_id,
       vertical_column_name
			
			
	) AS jt
INNER JOIN dbo.b_goodsinfo AS bg ON jt.tsl_gi_id = bg.gi_id
INNER JOIN dbo.b_unit AS bu ON bg.gi_unit = bu.ut_id
	
) el
INNER JOIN (
	SELECT
		ts_id,
		ts_vo,
		CONVERT (
			VARCHAR (100),
			ts_take_date,
			23
		) AS ts_take_date,
		ts_no,
		ts_st_id,
		ts_order_man,
		ts_it_id,
		ts_cp_id,
		ts_di_id,
		(
			SELECT
				sei_name
			FROM
				dbo.b_storageinfo AS bs
			WHERE
				(sei_id = jis.ts_st_id)
		) AS ts_st_id_txt,
		(
			SELECT
				di_name
			FROM
				dbo.b_departmentinfo AS bs
			WHERE
				(di_id = jis.ts_it_id)
		) AS ts_it_id_txt,
		(
			SELECT
				si_name
			FROM
				dbo.b_stafftinfo AS bs
			WHERE
				(si_id = jis.ts_order_man)
		) AS ts_order_man_txt,
		(
			SELECT
				si_name
			FROM
				dbo.b_stafftinfo AS bs
			WHERE
				(si_id = jis.ts_add_man)
		) AS ts_add_man_txt,
		ts_add_man,
		ts_add_time,
		(
			SELECT
				si_name
			FROM
				dbo.b_stafftinfo AS bs
			WHERE
				(si_id = jis.ts_update_man)
		) AS ts_update_man_txt,
		ts_update_man,
		ts_update_time,
		(
			SELECT
				si_name
			FROM
				dbo.b_stafftinfo AS bs
			WHERE
				(si_id = jis.ts_audit_man)
		) AS ts_audit_man_txt,
		ts_audit_man,
		ts_audit_time,
		ts_remark,
		ts_status
	FROM
		dbo.j_takeStorage AS jis
) AS eo ON el.tsl_ts_id = eo.ts_id
AND eo.ts_status > 0
go

