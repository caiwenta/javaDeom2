CREATE PROCEDURE [dbo].[pro_setPmNumberSum]
	@orderid int = 0,
	@erp_id int=0,
	@stockType int=0 --1：入库 2:出库 3:期初
AS

--获取配码每箱数量

DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';

BEGIN TRY
 

if EXISTS(SELECT * FROM s_system_set AS sss WHERE sss.s_key='batchorcode' AND sss.s_erp_id=@erp_id AND sss.s_value=1)
begin

--入库
IF @stockType=1
BEGIN

UPDATE j_enterStorageList 
set el_boxbynum=dbo.GetPmNumberSum(el_pm)
where el_eoid=@orderid and el_status=1 and isnull(el_pm,'')<>'';

END

--出库
IF @stockType=2
BEGIN

UPDATE j_outStorageList 
set ol_boxbynum=dbo.GetPmNumberSum(ol_pm)
where ol_eoid=@orderid and ol_status=1 and isnull(ol_pm,'')<>'';

end


--期初
IF @stockType=3
BEGIN

UPDATE j_initStorageList 
set inl_boxbynum=dbo.GetPmNumberSum(inl_pm)
where inl_in_id=@orderid and inl_status=1 and isnull(inl_pm,'')<>'';

end


--移出仓库
IF @stockType=4 or @stockType=5
BEGIN

UPDATE j_moStorageList 
set mol_boxbynum=dbo.GetPmNumberSum(mol_pm)
where mol_mo_id=@orderid and mol_status=1 and isnull(mol_pm,'')<>'';

end


--盈亏明细
IF @stockType=6
BEGIN

UPDATE j_plStorageList 
set ppl_boxbynum=dbo.GetPmNumberSum(ppl_pm)
where ppl_pl_id=@orderid and ppl_status=1 and isnull(ppl_pm,'')<>'';

end


--订货
IF @stockType=7
BEGIN

UPDATE pos_ogStorageList 
set ogl_boxbynum=dbo.GetPmNumberSum(ogl_pm)
where ogl_og_id=@orderid and ogl_status=1 and isnull(ogl_pm,'')<>'';

end


--配货
IF @stockType=8
BEGIN

UPDATE pos_allocationList 
set all_boxbynum=dbo.GetPmNumberSum(all_pm)
where all_al_id=@orderid and all_status=1 and isnull(all_pm,'')<>'';

end

--采购
IF @stockType=9
BEGIN

UPDATE j_purchaseStorageList 
set pll_boxbynum=dbo.GetPmNumberSum(pll_pm)
where pll_pl_id=@orderid and pll_status=1 and isnull(pll_pm,'')<>'';

end

--盘点
IF @stockType=10
BEGIN

UPDATE j_takeStorageList 
set tsl_boxbynum=dbo.GetPmNumberSum(tsl_pm)
where tsl_ts_id=@orderid and tsl_status=1 and isnull(tsl_pm,'')<>'';

end

--区域移仓
IF @stockType=11
BEGIN
print '区域移仓';

UPDATE j_orderblanklist 
set mol_boxbynum=dbo.GetPmNumberSum(mol_pm)
where mol_mo_id=@orderid and mol_status=1 and isnull(mol_pm,'')<>'';

end



end


END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

