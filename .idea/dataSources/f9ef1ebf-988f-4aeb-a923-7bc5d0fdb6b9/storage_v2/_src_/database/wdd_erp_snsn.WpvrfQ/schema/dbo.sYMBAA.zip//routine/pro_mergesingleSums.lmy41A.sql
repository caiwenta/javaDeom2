CREATE PROCEDURE [dbo].[pro_mergesingleSums]
	@orderid int = 0,
	@stockType int=0 --1：入库 2:出库
AS
--汇总数据生成表
DECLARE @source_type int=0;
declare @orderids UDTypeOrderId;--用户自定义类型
declare @count int=0;


DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';

			    
BEGIN TRY

INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'汇总数据',20 ,'开始生成汇总数据',@orderid);

IF @stockType=1 --入库
BEGIN

	select @source_type=eo_source_type 
	from j_enterStorage where eo_id=@orderid



	insert into @orderids(Id)values(@orderid);
	exec pro_mergeSums @orderids=@orderids, @stockType=1;
	delete @orderids;


	--上级订单
	if @source_type=1
	begin
	   
		print '重新生成采购'

		set @stockType=9;

		insert into @orderids(Id)
		SELECT distinct(SELECT jpsl.pll_pl_id FROM j_purchaseStorageList AS jpsl WHERE jpsl.pll_id=pe.el_source_id) 
		FROM (
		--采购入库
			SELECT 
			       jes.eo_id,
				   jesl.el_source_id
				 
			FROM   j_enterStorage AS jes
				INNER JOIN j_enterStorageList 
				AS jesl
					ON  
					jes.eo_id = jesl.el_eoid
			WHERE  
				 jesl.el_status = 1
				AND jes.eo_source_type = 1
				--and jes.eo_status > 0 订单有删除的情况
		) AS pe
		WHERE eo_id=@orderid
		
	end

end
else
IF @stockType=2 --出库
BEGIN

	select 
	@source_type=oo_source_type 
	from j_outStorage where oo_id=@orderid



	insert into @orderids(Id)values(@orderid);
	exec pro_mergeSums @orderids=@orderids, @stockType=2;
	delete @orderids;


	--上级订单
	if @source_type=1
	begin

		print '重新生成配货'
		set @stockType=8;

		insert into @orderids(Id)
		SELECT 
		distinct
		(SELECT jpsl.all_al_id FROM pos_allocationList AS jpsl WHERE jpsl.all_id=pe.ol_source_id) 
		FROM (
			SELECT 
					jos.oo_id,
				   josl.ol_source_id
			FROM   j_outStorage                 AS jos WITH (NOLOCK) 
				   INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) 
						ON  jos.oo_id = josl.ol_eoid
			WHERE  jos.oo_source_type = 1
				   AND jos.oo_source_id > 0
				   AND josl.ol_status = 1
		) AS pe
		WHERE oo_id=@orderid;

		set @count =0;
		select @count=count(1) from @orderids
		if @count>0
		begin
			exec pro_mergeSums @orderids=@orderids, @stockType=@stockType;
		end


		set @stockType=7;
		delete @orderids;
		insert into @orderids(Id)
		SELECT distinct pos.ogl_og_id FROM pos_ogStoragelist AS pos
		WHERE pos.ogl_id IN(
			SELECT
				ol_topsource_id
			FROM j_outStorageList WHERE ol_topsource_id>0 AND ol_eoid=@orderid
		)


	end


end 
else
if @stockType=8 --配货
begin


    select @source_type=al_source 
	from pos_allocation where al_id=@orderid;


	insert into @orderids(Id)values(@orderid);
	exec pro_mergeSums @orderids=@orderids, @stockType=8;
	delete @orderids;

	--上级订单
	if @source_type=5
	begin
		print '重新生成订单'
	   set @stockType=7;
	   insert into @orderids(Id)
	   SELECT distinct (select jpsl.ogl_og_id from pos_ogStorageList as jpsl where jpsl.ogl_id=pe.all_source_id)
	   FROM  (
			   SELECT 
			   al_id,
			   all_source_id
		FROM   pos_allocationList
			INNER JOIN pos_allocation ON  
			all_al_id = al_id  
			WHERE  all_status > 0 
			AND al_source = 5
			--and  al_status > 0 订单有删除的情况
	   ) AS pe where al_id=@orderid
	end

	--上级订单
	if @source_type=2
	begin
	   print '重新生成订单'
		 --  SELECT 
			--   al_id,
			--   all_num,
			--   all_pm,
			--   all_box_num,
			--   all_source_id
			--FROM   pos_allocationList
			--INNER JOIN pos_allocation ON  
			--all_al_id = al_id  
			--WHERE  al_status > 0
			--AND all_status > 0 
			--AND al_source = 2

	end


end
else
if @stockType=9 --采购
begin

    select @source_type=pl_source 
	from j_purchaseStorage where pl_id=@orderid;

	insert into @orderids(Id)values(@orderid);
	exec pro_mergeSums @orderids=@orderids, @stockType=9;
	delete @orderids;


	--上级订单
    if @source_type=1
	begin

	   print '重新生成订单'
	   set @stockType=7;
	   insert into @orderids(Id)
	   SELECT distinct (select jpsl.ogl_og_id from pos_ogStorageList as jpsl where jpsl.ogl_id=pe.pll_source_id)
	   FROM  (
		   SELECT 
				pl_id,
				pll_num,
				pll_pm,
				pll_box_num,
				pll_source_id
			FROM  j_purchaseStorageList
				INNER JOIN j_purchaseStorage
					ON  pll_pl_id = pl_id
			WHERE   pll_status > 0 
		   AND pl_source = 1 --pl_status > 0 AND
	   ) AS pe where pl_id=@orderid

	end

end
begin

	insert into @orderids(Id)values(@orderid);
end





set @count =0;
select @count=count(1) from @orderids
if @count>0
begin
	exec pro_mergeSums @orderids=@orderids, @stockType=@stockType;
end


INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'汇总数据',20 ,'生成汇总数据成功',@orderid);


END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

