CREATE PROCEDURE [dbo].[pro_objectlist_op]
	@id int = 0,
	@type int
AS

IF EXISTS(select * from a_objectlist where o_type=@type and o_objid=@id)
begin

update a_objectlist set
     o_qc=so.ci_qcje,
	 o_name=so.ci_name,
	 o_code=so.ci_code,
	 o_status=so.ci_status
from a_objectlist as ta 
inner join v_objectlist so on ta.o_objid=so.ci_id and ta.o_type=so.o_type
where ta.o_objid=@id and ta.o_type=@type;

end
else
begin

INSERT INTO a_objectlist (o_objid,o_type,o_qc,o_name,o_code,o_erp_id,o_cp_id,o_status)
select 
	tt.ci_id,
	tt.o_type,
	tt.ci_qcje,
	tt.ci_name,
	tt.ci_code,
	tt.ci_erp_id,
    isnull(tt.ci_cp_id,0), 
	tt.ci_status
from v_objectlist as tt  
where tt.ci_id=@id and tt.o_type=@type;

end
go

