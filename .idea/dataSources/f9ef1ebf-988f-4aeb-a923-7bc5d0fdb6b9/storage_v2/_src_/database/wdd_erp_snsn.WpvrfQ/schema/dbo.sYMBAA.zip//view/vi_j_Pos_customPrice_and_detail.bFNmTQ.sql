CREATE VIEW [dbo].[vi_j_Pos_customPrice_and_detail] AS 
SELECT jt.cp_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.pos_customPrice              AS jt
       INNER JOIN dbo.pos_customPriceList AS jt1
            ON  jt.cp_id = jt1.cpl_cp_id
       INNER JOIN dbo.b_goodsinfo  AS bg
            ON  jt1.cpl_gi_id = bg.gi_id
WHERE  (jt.cp_status <> 0)
go

