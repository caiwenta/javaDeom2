
CREATE VIEW [dbo].[vi_j_Pos_ReStorageList] AS 
SELECT rel_re_id,
       rel_gi_id,
       rel_add_time,
       SUM(rel_num)                    AS rel_num,
       MIN(rel_id)                     AS rel_id,
       MAX(rel_sku_id)                 AS rel_sku_id,
       SUM(rel_money)                  AS rel_money,
       CONVERT(
           DECIMAL(10, 2),
           AVG(CASE WHEN rel_num > 0 THEN rel_retail_price ELSE NULL END)
       )                               AS rel_retail_price,
       CONVERT(
           DECIMAL(10, 2),
           AVG(CASE WHEN rel_num > 0 THEN rel_stock_price ELSE NULL END)
       )                               AS rel_stock_price,
       MAX(rel_is_gift)                AS rel_is_gift,
       MAX(rel_sample_no)              AS rel_sample_no,
       CONVERT(
           DECIMAL(10, 2),
           AVG(CASE WHEN rel_num > 0 THEN rel_discount ELSE NULL END)
       )                               AS rel_discount,
       ISNULL(
           (
			   SELECT SUM(all_num) FROM pos_allocation pa
			  INNER JOIN pos_allocationList pal ON pa.al_id=pal.all_al_id AND pa.al_status<>0
			  AND pal.all_gi_id=rel_gi_id AND pa.al_source_id=rel_re_id and al_source IN (2)
           ),
           0
       )                               AS phnum,
       MAX(REPLACE(rel_pm, '*', ','))  AS rel_pm,
       MAX(rel_box_num)                AS rel_box_num
FROM   dbo.pos_reStorageList AS jt
WHERE  (rel_status = 1)
GROUP BY
       rel_re_id,
       rel_gi_id,
       rel_add_time
go

