CREATE PROC [dbo].[pro_takeStorage_op]
@tsl_box_num INT = 0,
@tsl_pm VARCHAR(500) = '',
--主键  
@tsl_id INT = 0,  
@ts_erp_id INT = 0,  
@tsl_erp_id INT = 0, 
--盘点单主键  
@tsl_ts_id INT = 0,  
--商品主键  
@tsl_gi_id INT = 0,  
--商品sku主键  
@tsl_sku_id INT = 0,  
--日期库存数量  
@tsl_old_num INT = 0,  
--实盘数量  
@tsl_new_num INT = 0,  
--盈亏数量  
@tsl_log_num INT = 0,  
--日期库存重量  
@tsl_old_weight DECIMAL(9, 2) = 0,  
--实盘重量  
@tsl_new_weight DECIMAL(9, 2) = 0,  
--盈亏重量  
@tsl_log_weight DECIMAL(9, 2) = 0,  
--原金额  
@tsl_old_money DECIMAL(9, 2) = 0,  
--盈亏金额  
@tsl_log_money DECIMAL(9, 2) = 0,  
--实盘金额  
@tsl_new_money DECIMAL(9, 2) = 0,  
--零售价  
@tsl_retail_price DECIMAL(9, 2) = 0,  
--进货价
@tsl_stock_price DECIMAL(9, 2) = 0,
--折扣
@tsl_discount DECIMAL(9, 2) = 0,
--备注  
@tsl_remark VARCHAR(200) = '',  
--添加时间  
@tsl_add_time DATETIME = '2014-11-03',  
--修改时间  
@tsl_update_time DATETIME = '2014-11-03',  
--主键  
@ts_id INT = 0,  
--仓库主键  
@ts_st_id INT = 0,  
--制单人主键  
@ts_order_man INT = 0,  
--部门主键  
@ts_it_id INT = 0,  
--盘点日期  
@ts_take_date DATETIME = '2014-11-03',  
--备注  
@ts_remark VARCHAR(50) = '',  
--添加人主键  
@ts_add_man INT = 0,  
--添加时间  
@ts_add_time DATETIME = '2014-11-03',  
--修改人主键  
@ts_update_man INT = 0,  
--修改时间  
@ts_update_time DATETIME = '2014-11-03',  
--审核人主键  
@ts_audit_man INT = 0,  
--审核时间  
@ts_audit_time DATETIME = '2014-11-03',  
--单据号  
@ts_no VARCHAR(50) = '',  
--总数量  
@ts_total_num INT = 0,  
--库存确认时间  
@tso_take_time DATETIME = '2014-11-03',  
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  
--产生了负库存是否提示
@negative_inventory INT = 0,
--结果  
@result VARCHAR(100) = '' OUT,
--公司主键
@ts_cp_id INT = 0,
--部门主键
@ts_di_id INT = 0,
--保存字符串
@savestr VARCHAR(MAX) = '',

@tsl_pddate VARCHAR(80) = null,
@tsl_expirationdate VARCHAR(80) = null,
@tsl_shelflife int=0,

@orderguid VARCHAR(500)='', --唯一guid
@IsPDA int=0,
@source_id int=0
AS
BEGIN
	--是否添加单据
	DECLARE @isInsert INT = 0;
	--是否需要更新单据
	DECLARE @need_update INT = 0;
	--旧的单据日期
	DECLARE @old_order_date DATETIME;
	--单据日期是否更改
	DECLARE @old_order_date_is_changed INT = 0;
	--凭证号前缀
	DECLARE @myprevTxt VARCHAR(50) = 'PD';
	
	
	DECLARE @sei_is_negative_inventory INT = 0;
	DECLARE @sei_is_info INT = 0;
	BEGIN TRAN
	
	
	IF @op_type = '添加修改单据,明细' OR @op_type = '修改单据'
	BEGIN
	    --pda订单
		IF @IsPDA=1 
		BEGIN
			SELECT 
			@ts_st_id=tsl_st_id,
			@ts_take_date=tsl_date 
			FROM j_takeStorageLog
			WHERE tsl_id =@source_id;
		END



	    SELECT @sei_is_negative_inventory = fd.sei_is_negative_inventory,
	           @sei_is_info = fd.sei_is_info
	    FROM   b_storageinfo fd
	    WHERE  fd.sei_id = @ts_st_id;
	    
	    IF NOT EXISTS (
	           SELECT *
	           FROM   j_takeStorageLog AS jt
	           WHERE  jt.tsl_st_id = @ts_st_id
	                  AND jt.tsl_date = @ts_take_date
	                  AND jt.tsl_status = 1
	       )
	    BEGIN
	        SET @result = '操作失败,没有对应的盘点准备!';
			
			IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	        RETURN 1
	    END
	    
	    
	    IF @ts_id != 0
	    BEGIN
	        DECLARE @old_ts_st_id INT = 0;
	        DECLARE @old_ts_take_date DATETIME;
	        DECLARE @need_update_stock_num INT = 0;
	        SELECT @old_ts_st_id = jts.ts_st_id,
	               @old_ts_take_date = jts.ts_take_date
	        FROM   j_takeStorage AS jts
	        WHERE  jts.ts_id = @ts_id;
	        
	        IF @old_ts_st_id != @ts_id
	           OR @old_ts_take_date != @ts_take_date
	        BEGIN
	            SET @need_update_stock_num = 1;
	        END
	    END
	    
	    IF @ts_id = 0
	    BEGIN
	        --添加单据
	        INSERT INTO j_takeStorage
	          (
	            ts_st_id,
	            ts_order_man,
	            ts_it_id,
	            ts_take_date,
	            ts_remark,
	            ts_status,
	            ts_add_man,
	            ts_add_time,
	            ts_update_man,
	            ts_update_time,
	            ts_vo,
	            ts_no,
	            ts_total_num,
	            ts_tsl_id,
	            tso_take_time,
	            ts_cp_id,
	            ts_di_id,ts_erp_id,do_id
	          )
	        VALUES
	          (
	            @ts_st_id,
	            @ts_order_man,
	            @ts_it_id,
	            @ts_take_date,
	            @ts_remark,
	            1,
	            @ts_add_man,
	            @ts_add_time,
	            @ts_update_man,
	            @ts_update_time,
	            NEWID(),
	            @ts_no,
	            @ts_total_num,
	            0,
	            @tso_take_time,
	            @ts_cp_id,
	            @ts_di_id,
				@ts_erp_id,
				@source_id
	          );
	        SET @ts_id = SCOPE_IDENTITY();
	        
	        SET @tsl_ts_id = @ts_id;
	        SET @isInsert = 1;
	    END
	    ELSE
	    BEGIN
	        SET @need_update = 1;
	    END
	    

	    
	    IF @op_type = '添加修改单据,明细'
	    BEGIN
	     
	        --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
	        DECLARE @savestr_item VARCHAR(MAX) = '';
	        --起始数值,每次循环后递增
	        DECLARE @start_int INT = 1;
	        --终止数值
	        DECLARE @end_int INT = 1;
	        IF @savestr != '' 
	           --AND 1=2
	        BEGIN
	            --得到明细数量
	            --即要循环的次数
	            SELECT @end_int = (LEN(@savestr) -LEN(REPLACE(@savestr, '|', '')))
	        END
	        

			if @IsPDA=1 
			BEGIN

			PRINT 'pda生成盘点明细';
			--插入有规格明细
			INSERT INTO j_takeStorageList
			(	tsl_ts_id , 
				tsl_gi_id , 
				tsl_sku_id ,
				tsl_location,
				tsl_old_num ,  --日期库存
				tsl_new_num ,  --实盘数量
				tsl_log_num ,  --盈亏数量
				tsl_discount,  --折扣
				tsl_retail_price,--零售价
				tsl_stock_price, --进货价
				tsl_old_money,  --日期金额
				tsl_new_money,  --实盘金额
				tsl_log_money,  --盈亏金额
				tsl_status,
				tsl_pm,
				tsl_box_num,
				tsl_erp_id,
				tsl_add_time
			)
			SELECT
				@ts_id,
				tke.sl_giid,
				tke.sl_skuid,
				tke.sl_location,
				tke.old_num AS tsl_old_num, --日期库存
				tke.new_num AS tsl_new_num, --实盘数量
				(tke.new_num-old_num) AS tsl_log_num,  --盈亏数量
				tke.gi_purchase_discount AS tsl_discount,      --折扣                                    
				tke.gi_retailprice as tsl_retail_price,--零售价
				tke.gi_purchase as tsl_stock_price, --进货价
				(tke.old_num*tke.gi_purchase) as tsl_old_money,  --日期金额
				(tke.new_num*tke.gi_purchase) as tsl_new_money,  --实盘金额
				((tke.new_num-tke.old_num)*tke.gi_purchase) as tsl_log_money, --盈亏金额
				1,    
				'',
				0,
				@ts_erp_id,
				GETDATE()                                                                               
			FROM (
			SELECT
				bg.gi_retailprice,
				bg.gi_purchase,
				bg.gi_purchase_discount,
				takes.*
			FROM (
				SELECT 
					SUM(new_num) AS new_num,
					SUM(old_num) AS old_num,
					sl_giid,sl_skuid,sl_location
				FROM(	
					SELECT 
						0 AS new_num, 
						ISNULL(SUM( CASE WHEN js.sl_counttype = 1 THEN js.sl_number ELSE -js.sl_number END ),0) AS old_num,
						js.sl_giid,
						js.sl_skuid,
						isnull(js.sl_location,0) AS sl_location
					FROM   j_stocklog AS js
					WHERE  js.sl_seiid = @ts_st_id
						AND (( CONVERT(VARCHAR(50), js.sl_order_date, 23) <=@ts_take_date )OR js.sl_type = 3)
						AND js.sl_status != 0
						AND js.sl_giid IN (SELECT distinct ed.goods_id FROM erp_distributionordertakelist AS ed 
						WHERE ed.do_id in (SELECT ed.do_id FROM erp_distributionorder AS ed WHERE ed.warehousingtype=17 AND ed.do_source_id=@source_id))
					GROUP BY js.sl_giid,js.sl_skuid, isnull(js.sl_pm,''), isnull(js.sl_location,0)
					
					UNION ALL 	
					
					SELECT 
						sum(dt_count) AS new_num,
						0 AS old_num,
						ed.goods_id,
						ed.sku_id,
						slt_id
					FROM erp_distributionordertakelist AS ed WHERE ed.do_id in (SELECT ed.do_id FROM erp_distributionorder AS ed WHERE ed.warehousingtype=17 AND ed.do_source_id=@source_id)
					GROUP BY slt_id,ed.goods_id,ed.sku_id

				  ) AS groupby GROUP BY sl_giid,sl_skuid,sl_location
			   ) AS takes
			   INNER JOIN b_goodsinfo AS bg ON takes.sl_giid=bg.gi_id
			) AS tke

			--审核单据
			UPDATE j_takeStorage
			SET    ts_status = 2,
					ts_audit_man = @ts_update_man,
					ts_audit_time = GETDATE()
			WHERE  ts_id = @ts_id;


			END
			ELSE
			BEGIN
			  PRINT '生成盘点明细';

			------------------扫描---------------------
			if @orderguid=''   --不是扫描
			BEGIN

				WHILE @start_int <= @end_int
				BEGIN
	            --动态赋值
	            IF @savestr != ''
	            BEGIN
	                SET @savestr_item = dbo.Get_StrArrayStrOfIndex(@savestr, '|', @start_int);
	                IF (RTRIM(LTRIM(@savestr_item)) = '')
	                BEGIN
	                    BREAK;
	                END
	                ELSE
	                BEGIN
	                    SET @tsl_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
	                    
	                    SET @tsl_gi_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
	                    
	                    SET @tsl_sku_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));
	                    
	                    SET @tsl_old_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
	                    
	                    SET @tsl_new_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5));
	                    
	                    SET @tsl_log_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6));
	                    
	                    SET @tsl_retail_price = CONVERT(
	                            DECIMAL(10, 2),
	                            dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7)
	                        );
	                    
	                    SET @tsl_stock_price = CONVERT(
	                            DECIMAL(10, 2),
	                            dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 8)
	                        );
	                    
	                    SET @tsl_box_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9));
	                    
	                    SET @tsl_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 10);
	                END
	            END	
	            
	            SET @tsl_log_num = @tsl_new_num -@tsl_old_num;
	            SET @tsl_log_money = @tsl_log_num * @tsl_stock_price;
	            SET @tsl_new_money = @tsl_new_num * @tsl_stock_price;
	            SET @tsl_old_money = @tsl_old_num * @tsl_stock_price;


	            IF @tsl_id = 0
	            BEGIN

	                INSERT INTO j_takeStorageList
	                  (
	                    tsl_ts_id,
	                    tsl_gi_id,
	                    tsl_sku_id,
	                    tsl_old_num,
	                    tsl_new_num,
	                    tsl_log_num,
	                    tsl_old_weight,
	                    tsl_new_weight,
	                    tsl_log_weight,
	                    tsl_old_money,
	                    tsl_log_money,
	                    tsl_new_money,
	                    tsl_retail_price,
	                    tsl_remark,
	                    tsl_add_time,
	                    tsl_update_time,
	                    tsl_status,
	                    tsl_stock_price,
	                    tsl_discount,
	                    tsl_box_num,
	                    tsl_pm,tsl_erp_id,
						tsl_pddate,tsl_shelflife,tsl_expirationdate
	                  )
	                VALUES
	                  (
	                    @tsl_ts_id,
	                    @tsl_gi_id,
	                    @tsl_sku_id,
	                    @tsl_old_num,
	                    @tsl_new_num,
	                    @tsl_log_num,
	                    @tsl_old_weight,
	                    @tsl_new_weight,
	                    @tsl_log_weight,
	                    @tsl_old_money,
	                    @tsl_log_money,
	                    @tsl_new_money,
	                    @tsl_retail_price,
	                    @tsl_remark,
	                    @tsl_add_time,
	                    @tsl_update_time,
	                    1,
	                    @tsl_stock_price,
	                    @tsl_discount,
	                    @tsl_box_num,
	                    @tsl_pm,@tsl_erp_id,
						@tsl_pddate,@tsl_shelflife,@tsl_expirationdate
	                  );

	                SET @tsl_id = SCOPE_IDENTITY();
	            END
	            ELSE
	            BEGIN
	                UPDATE j_takeStorageList
	                SET    tsl_ts_id = @tsl_ts_id,
	                       tsl_gi_id = @tsl_gi_id,
	                       tsl_sku_id = @tsl_sku_id,
	                       tsl_old_num = @tsl_old_num,
	                       tsl_new_num = @tsl_new_num,
	                       tsl_log_num = @tsl_new_num -@tsl_old_num,
	                       tsl_old_weight = @tsl_old_weight,
	                       tsl_new_weight = @tsl_new_weight,
	                       tsl_log_weight = @tsl_log_weight,
	                       tsl_old_money = @tsl_old_money,
	                       tsl_log_money = @tsl_log_money,
	                       tsl_new_money = @tsl_new_money,
	                       tsl_retail_price = @tsl_retail_price,
	                       tsl_remark = @tsl_remark,
	                       tsl_update_time = @tsl_update_time,
	                       tsl_stock_price = @tsl_stock_price,
	                       tsl_discount = @tsl_discount,
	                       tsl_box_num = @tsl_box_num,
	                       tsl_pm = @tsl_pm,tsl_erp_id = @tsl_erp_id,
						   tsl_pddate=@tsl_pddate,tsl_shelflife=@tsl_shelflife,tsl_expirationdate=@tsl_expirationdate
	                WHERE  tsl_id = @tsl_id;
	            END


				--更新日期库存
				UPDATE j_takeStorageList
	    SET    tsl_old_num = isnull(fd.stock_num,0),
		       tsl_old_box_num=isnull(fd.box_num,0)
	    FROM   j_takeStorageList AS jtsl
		INNER JOIN
	             ( 
				  SELECT SUM( CASE WHEN js.sl_counttype = 1 THEN js.sl_number ELSE -js.sl_number END ) AS stock_num,
						 SUM( CASE WHEN js.sl_counttype = 1 THEN js.sl_box_num ELSE -js.sl_box_num END ) AS box_num,
	                      js.sl_giid,
	                      js.sl_skuid,
						  isnull(js.sl_pm,'') as sl_pm
	               FROM   j_stocklog  AS js 
	               WHERE  js.sl_seiid = @ts_st_id
	                      AND (( CONVERT(VARCHAR(50), js.sl_order_date, 23)<= @ts_take_date ) OR js.sl_type = 3)
	                      AND js.sl_status != 0 
						  and js.sl_giid=@tsl_gi_id 
						  and js.sl_skuid=@tsl_sku_id
	               GROUP BY
	                      js.sl_giid,
	                      js.sl_skuid,
						  isnull(js.sl_pm,'')
	           ) AS fd 
			         ON jtsl.tsl_gi_id = fd.sl_giid 
			        AND jtsl.tsl_sku_id = fd.sl_skuid 
					AND jtsl.tsl_ts_id = @ts_id 
					AND jtsl.tsl_status = 1 
					and isnull(jtsl.tsl_pm,'')=fd.sl_pm

				--更新盈亏
				UPDATE j_takeStorageList 
				SET    tsl_log_num = tsl_new_num -tsl_old_num,
				       tsl_log_box_num=tsl_box_num-tsl_old_box_num
				WHERE  tsl_ts_id = @ts_id 
				and tsl_gi_id=@tsl_gi_id 
				and tsl_sku_id=@tsl_sku_id;


	            SET @start_int = @start_int + 1;
	        END;

			END
			ELSE               --扫描
			BEGIN

				MERGE INTO j_takeStorageList AS tsl
					USING
					(
				  		SELECT  @ts_id as tsl_ts_id, gi_id, sku_id,
                        number,   --实盘数量
						discount , --折扣
						retailprice , --零售价
                        purchase,--进货价
						orderstatus,
						pm,
						erp_id,
						box_num,
						dbo.FnErpStocklog(@ts_take_date,@ts_st_id,gi_id,sku_id) as stock_num --日期库存
						FROM  erp_goodslisttemp 
						WHERE orderguid = @orderguid

					) as so on tsl.tsl_gi_id=so.gi_id AND  tsl.tsl_sku_id=so.sku_id and  tsl.tsl_ts_id=so.tsl_ts_id and tsl.tsl_status=1
					 WHEN MATCHED THEN  UPDATE
                           SET  
						   tsl.tsl_new_num += so.number,
						   tsl.tsl_new_money=((tsl.tsl_new_num+so.number)*so.purchase),
						   tsl.tsl_log_num = (tsl.tsl_new_num+so.number-tsl.tsl_old_num),
						   tsl.tsl_log_money=((tsl.tsl_new_num+so.number-tsl.tsl_old_num)*so.purchase)
					  WHEN NOT MATCHED THEN
							INSERT 
							(tsl_ts_id , tsl_gi_id , tsl_sku_id ,
							tsl_old_num ,  --日期库存
							tsl_new_num ,  --实盘数量
							tsl_log_num ,  --盈亏数量
	                        tsl_discount,  --折扣
							tsl_retail_price,--零售价
	                        tsl_stock_price, --进货价
							tsl_old_money,  --日期金额
							tsl_new_money,  --实盘金额
						    tsl_log_money,  --盈亏金额
							tsl_status,
							tsl_pm,
							tsl_box_num,
							tsl_erp_id,
							tsl_add_time
							)
							VALUES
							( 
							 so.tsl_ts_id, so.gi_id, so.sku_id,
							 so.stock_num,         --日期库存
							 so.number,            --实盘数量
							 (so.number-so.stock_num),--盈亏数量
							 so.discount ,         --折扣
							 so.retailprice ,      --零售价
							 so.purchase,          --进货价
						 	 so.stock_num*so.purchase,--日期金额
							 so.number*so.purchase,   --实盘金额
							(so.number-so.stock_num)*so.purchase,--盈亏金额
							 so.orderstatus,
							 so.pm,
							 so.box_num,
							 so.erp_id,
							 (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END)  
							  FROM( SELECT GETDATE() as nows,
							              (SELECT TOP 1 tsl_add_time 
										   FROM j_takeStorageList 
										   WHERE tsl_gi_id=so.gi_id AND tsl_ts_id=so.tsl_ts_id) AS addtime) AS TT)
							);

			END
			------------------扫描---------------------
			END
			

			exec dbo.pro_setPmNumberSum @orderid=@ts_id,@erp_id=@ts_erp_id ,@stockType=10;
	    END
	END
	
	IF @op_type = '审核单据'
	BEGIN
	    --审核单据
	    UPDATE j_takeStorage
	    SET    ts_status = 2,
	           ts_audit_man = @ts_update_man,
	           ts_audit_time = GETDATE()
	    WHERE  ts_id = @ts_id;
	END
	
	IF @op_type = '取消审核单据'
	BEGIN
	    IF EXISTS(
	           SELECT *
	           FROM   j_takeStorage AS jts
	           WHERE  jts.ts_id = @ts_id
	                  AND jts.ts_tsl_id > 0
	       )
	    BEGIN
	        SET @result = '取消审核失败,该单据已经参与库存计算!';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	        RETURN 1;

	    END
	    
		if EXISTS(
			select * from  j_takeStorage AS jts where jts.ts_id = @ts_id
	                  AND jts.do_id > 0 
		)
		BEGIN
	        SET @result = '取消审核失败,移动仓储自动生成无法取消审核!';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	        RETURN 1;

	    END


	    --取消审核单据
	    UPDATE j_takeStorage
	    SET    ts_status = 1
	    WHERE  ts_id = @ts_id;
	END
	
	IF @op_type = '删除单据'
	BEGIN

	    --删除单据
	    UPDATE j_takeStorage
	    SET    ts_status = 0
	    WHERE  ts_id = @ts_id;

		--删除明细单据
	    UPDATE j_takeStoragelist
	    SET    tsl_status = 0
	    WHERE  tsl_ts_id = @ts_id;

	END
	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE j_takeStorageList
	    SET    tsl_status = 0
	    WHERE  tsl_id = @tsl_id;
	END
	
	IF @op_type = '批量删除明细'
	BEGIN
	    UPDATE j_takeStorageList
	    SET    tsl_status = 0
	    WHERE  tsl_ts_id = @tsl_ts_id
	           AND tsl_add_time = @tsl_add_time
	           AND tsl_gi_id = @tsl_gi_id;
	    
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   j_takeStorageList AS jt
	           WHERE  jt.tsl_ts_id = @tsl_ts_id
	                  AND jt.tsl_status = 1
	       )
	    BEGIN
	        UPDATE j_takeStorage
	        SET    ts_status = 0
	        WHERE  ts_id = @tsl_ts_id;
	    END
	END
	
	IF(@op_type = '添加修改单据,明细' OR @need_update = 1 OR @op_type = '修改单据' ) AND @isInsert != 1
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.ts_take_date
	    FROM   j_takeStorage AS jt
	    WHERE  jt.ts_id = @ts_id;
	    IF @old_order_date != @ts_take_date
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	    UPDATE j_takeStorage
	    SET    ts_st_id = @ts_st_id,
	           ts_order_man = @ts_order_man,
	           ts_it_id = @ts_it_id,
	           ts_take_date = @ts_take_date,
	           ts_remark = @ts_remark,
	           ts_update_man = @ts_update_man,
	           ts_update_time = @ts_update_time,
	           ts_no = @ts_no,
	           ts_total_num = @ts_total_num,
	           tso_take_time = @tso_take_time
	    WHERE  ts_id = @ts_id;
	    
	    IF (
	           SELECT fd.ts_status
	           FROM   j_takeStorage fd
	           WHERE  fd.ts_id = @ts_id
	       ) = 0
	    BEGIN
	        UPDATE j_takeStorage
	        SET    ts_status = 1
	        WHERE  ts_id = @ts_id ;
	    END
	END
	
	IF @isInsert = 1 --OR @old_order_date_is_changed = 1
	BEGIN
		
		EXEC pro_update_unique_time 
		@id=@ts_id,@type='盘点'
		
	    DECLARE @tableName VARCHAR(50) = 'j_takeStorage'
	    DECLARE @idField VARCHAR(50) = 'ts_id'
	    DECLARE @idValue INT = @ts_id;
	    
	    DECLARE @dateField VARCHAR(50) = 'ts_take_date'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @ts_take_date, 23)
	    
	    DECLARE @noField VARCHAR(50) = 'ts_vo'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN
	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	        @idField,
	        @idValue,
	        @dateField,
	        @dateValue,
	        @noField,
	        @prevTxt,
	        @outno OUTPUT,
	        0,
	        @ts_cp_id
	        
	        BEGIN TRY
	        	--更新
	        	UPDATE j_takeStorage
	        	SET    ts_vo = @outno
				,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)

	        	WHERE  ts_id = @ts_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
			PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
	        END CATCH
	    END
	END
	
	IF @op_type='计算日期库存'
	BEGIN

	    UPDATE j_takeStorageList
	    SET    tsl_old_num = isnull(fd.stock_num,0)
	    FROM   j_takeStorageList AS jtsl
		LEFT JOIN
	           (
	               SELECT SUM(
	                          CASE 
	                               WHEN js.sl_counttype = 1 THEN js.sl_number
	                               ELSE -js.sl_number
	                          END
	                      )           AS stock_num,
	                      js.sl_giid,
	                      js.sl_skuid,
						  isnull(js.sl_pm,'') as sl_pm
	               FROM   j_stocklog  AS js 
	               WHERE  js.sl_seiid = @ts_st_id
	                      AND (
	                              (
	                                
	                                  CONVERT(VARCHAR(50), js.sl_order_date, 23)<= @ts_take_date
	                              )
	                              OR js.sl_type = 3
	                          )
	                      AND js.sl_status != 0
	               GROUP BY
	                      js.sl_giid,
	                      js.sl_skuid,
						  isnull(js.sl_pm,'')
	           ) AS fd ON
	               jtsl.tsl_gi_id = fd.sl_giid
	           AND jtsl.tsl_sku_id = fd.sl_skuid
	           AND jtsl.tsl_ts_id = @ts_id
	           AND jtsl.tsl_status = 1
	           and jtsl.tsl_pm=fd.sl_pm
	      where tsl_ts_id = @ts_id

	    UPDATE j_takeStorageList
	    SET    tsl_log_num = tsl_new_num -tsl_old_num
	    WHERE  tsl_ts_id = @ts_id;

	END
	
	IF @op_type <> '审核单据' and  @op_type<> '取消审核单据'
	begin
		exec pro_mergesingleSums @orderid=@ts_id ,@stockType=10
	end

	IF @@ERROR <> 0
	BEGIN
	    SET @result = '0';

	    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @ts_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细' and @orderguid=''
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @tsl_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END
END

go

