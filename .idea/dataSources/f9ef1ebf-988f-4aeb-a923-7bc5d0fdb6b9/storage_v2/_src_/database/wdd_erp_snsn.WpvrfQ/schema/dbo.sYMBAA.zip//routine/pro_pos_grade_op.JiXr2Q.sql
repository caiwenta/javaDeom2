

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pro_pos_grade_op]
@gr_id int output,
@gr_rank varchar(50),
@gr_code varchar(50),
@gr_discount decimal(10,3),
@gr_section_start int,
@gr_section_end int,
@gr_rate decimal(10,2),
--操作类型(1:添加 2:修改 3:删除)
@op_type Int=0,
@outResult int Output,
@gr_cp_id int = 0,
@gr_erp_id int = 0,
@gr_di_id int = 0,

@gr_opter int = 0,
@gr_spending int = 0,
@gr_amount decimal(10,3) = 0,
@gr_deduction decimal(10,3) = 0,
@gr_grade int = 0,
@gr_default int = 0,
@gr_birth_discount decimal(10,3),
@gr_sh_id int = 0,
@gr_or int = 0,
@gr_rechange_onetime decimal(10,2)
AS
BEGIN
	IF @op_type=1
    Begin
	INSERT INTO [pos_grade](
	[gr_rank],[gr_discount],[gr_section_start],[gr_section_end],[gr_rate],[gr_cp_id],[gr_di_id],gr_code,gr_erp_id,gr_opter,gr_spending,gr_amount,gr_deduction,gr_grade,gr_default,gr_birth_discount,gr_sh_id,gr_or,gr_rechange_onetime
	)VALUES(
	@gr_rank,@gr_discount,@gr_section_start,@gr_section_end,@gr_rate,@gr_cp_id,@gr_di_id,@gr_code,@gr_erp_id,
	@gr_opter,@gr_spending,@gr_amount,@gr_deduction,@gr_grade,@gr_default,@gr_birth_discount,@gr_sh_id,@gr_or,@gr_rechange_onetime
	)
	SET @gr_id = SCOPE_IDENTITY()
	END
	
	IF @op_type=2 AND @gr_id>0
    Begin
    UPDATE [pos_grade] SET 
	[gr_rank] = @gr_rank,
	gr_code=@gr_code,
	[gr_discount] = @gr_discount,
	[gr_section_start] = @gr_section_start,
	[gr_section_end] = @gr_section_end,
	[gr_rate] = @gr_rate,
	gr_opter=@gr_opter,
	gr_spending=@gr_spending,
	gr_amount=@gr_amount,
	gr_deduction=@gr_deduction,
	gr_grade=@gr_grade,
	gr_default=@gr_default,
	gr_birth_discount=@gr_birth_discount,
	gr_sh_id=@gr_sh_id,
	gr_or=@gr_or,
	gr_rechange_onetime=@gr_rechange_onetime
	WHERE gr_id=@gr_id 
    END
    
    IF @op_type=3 AND @gr_id>0
    Begin
    DELETE [pos_grade]
	WHERE gr_id=@gr_id 
    END
    
    if @@error<>0 
begin 
	set @outResult=0;
end
else 
begin
   set @outResult=@gr_id;
end
  Return @outResult;
END
go

