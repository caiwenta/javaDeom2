




CREATE VIEW [dbo].[vi_j_outStorageList] AS 
SELECT ol_eoid,
      
       ol_siid,
       ol_addtime,
       SUM(ol_number)                    AS ol_number,
       MIN(ol_id)                        AS ol_id,
       MAX(ol_skuid)                     AS ol_skuid,
       SUM(ol_realmoney)                 AS ol_realmoney,
       CONVERT(DECIMAL(10, 2), AVG(ol_unit)) AS ol_unit,
       CONVERT(DECIMAL(10, 2), AVG(ol_costprice)) AS ol_costprice,
       CONVERT(DECIMAL(10, 2), AVG(ol_discount)) AS ol_discount,
       MAX(REPLACE(jt.ol_pm, '*', ','))  AS ol_pm,
       MAX(jt.ol_box_num)                AS ol_box_num,
       jt.ol_gift,
        jt.isruleprice,
       MAX(jt.ol_source_add_time) AS ol_source_add_time,
	    MAX(supplyprice) as supplyprice,
	   MAX(discount) as discount
FROM   dbo.j_outStorageList AS jt
WHERE  (ol_status = 1)
GROUP BY
       ol_eoid,
       ol_siid,
       ol_addtime,
       jt.ol_gift,  jt.isruleprice

--SELECT *
--FROM   dbo.j_outStorageList 
--WHERE  ol_status = 1 
go

