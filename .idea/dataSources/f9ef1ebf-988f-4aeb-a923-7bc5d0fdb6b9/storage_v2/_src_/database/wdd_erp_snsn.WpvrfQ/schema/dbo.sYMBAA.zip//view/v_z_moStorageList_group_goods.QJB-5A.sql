CREATE VIEW [dbo].[v_z_moStorageList_group_goods]
	AS 
SELECT
	jt.mol_mo_id,
	jt.mol_gi_id,
	jt.mol_num,
	jt.mol_stock_num,
    (case when isnull(bg.gi_skuid,'')='' then 
	 (SELECT max(jmsl.mol_id) FROM j_moStorageList AS jmsl 
	 WHERE jmsl.mol_mo_id=jt.mol_mo_id  AND jmsl.mol_gi_id=jt.mol_gi_id AND jmsl.mol_sku_id=0 AND jmsl.mol_add_time=jt.mol_add_time and jt.mol_status>0)
	 else 0 end)mol_id,
	jt.mol_discount,
	jt.mol_retail_price,
	jt.mol_stock_price,
	jt.mol_money,
	CONVERT (
		VARCHAR (100),
		jt.mol_add_time,
		25
	) AS mol_add_time,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_cratebox,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bg.gi_sampleno,--样品号
	bu.ut_name AS gi_unit,
	bu.ut_id AS gi_unit_id,
	mol_box_num,
  (SELECT SUM (mol_num) FROM j_moStorageList jmt INNER JOIN j_moStorage AS jms ON jmt.mol_mo_id=jms.mo_id AND jms.mo_source_id =jt.mol_mo_id AND jmt.mol_gi_id=jt.mol_gi_id and jmt.mol_status > 0 ) AS mo_num,
  (SELECT SUM(var_num) FROM erp_inspectionofgoods WHERE orderid=mol_mo_id AND warehousingtype=5 and iog_status=1 and gi_id=jt.mol_gi_id ) as var_num,
	mol_pm
FROM
	dbo.j_moStorageListMergeSum AS jt
INNER JOIN dbo.b_goodsinfo AS bg WITH (NOLOCK) ON jt.mol_gi_id = bg.gi_id
INNER JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
go

