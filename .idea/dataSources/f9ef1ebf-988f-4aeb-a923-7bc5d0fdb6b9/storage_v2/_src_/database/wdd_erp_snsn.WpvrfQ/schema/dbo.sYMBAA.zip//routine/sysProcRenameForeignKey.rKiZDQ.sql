
CREATE PROCEDURE [dbo].[sysProcRenameForeignKey]
-- =============================================
-- Author:		<重命名Sql Server外键约束名的方法>
-- Create date: <2015-05-03>
-- Description:	<数据库原先是采用PowerDesigner设计的，Sql Server外键约束的命名非常难看，外键约束命名规则不一致>
-- =============================================
AS
    BEGIN
        DECLARE fkcur CURSOR
        FOR
            SELECT  OBJECT_NAME(col.constraint_object_id) AS FKConstraintName ,
                    fkTable.name AS FKTable ,
                    fkCol.name AS FKColumn ,
                    pkTable.name AS PKTable ,
                    pkCol.name AS PKColumn
            FROM    sys.foreign_key_columns col -- 外键约束是建立在外键表上的，  
-- 因此foreign_key_columns表中的parent_object_id和parent_column_id分别表示外键表和外键列  
                    INNER JOIN sys.objects fkTable ON fkTable.object_id = col.parent_object_id
                    INNER JOIN sys.columns fkCol ON fkCol.column_id = col.parent_column_id
                                                    AND fkCol.object_id = fkTable.object_id  
-- foreign_key_columns表中的referenced_object_id和referenced_column_id分别指向  
-- 外键约束的主键表对象以及主键列  
                    INNER JOIN sys.objects pkTable ON pkTable.object_id = col.referenced_object_id
                    INNER JOIN sys.columns pkCol ON pkCol.column_id = col.referenced_column_id
                                                    AND pkCol.object_id = pkTable.object_id
            ORDER BY OBJECT_NAME(col.constraint_object_id)  
 
        OPEN fkcur  
        DECLARE @constraintName NVARCHAR(128)  
        DECLARE @fkTable NVARCHAR(64)  
        DECLARE @fkColumn NVARCHAR(64)  
        DECLARE @pkTable NVARCHAR(64)  
        DECLARE @pkColumn NVARCHAR(64)  
        DECLARE @newConstraintName NVARCHAR(128)  
 
        FETCH NEXT FROM fkcur INTO @constraintName, @fkTable, @fkColumn,
            @pkTable, @pkColumn  
        WHILE @@FETCH_STATUS = 0
            BEGIN  
                SET @newConstraintName = 'FK_' + @fkTable + '_' + @pkTable
                    + '_On_' + @fkColumn  
                IF @constraintName != @newConstraintName
                    BEGIN
                        EXEC sp_rename @constraintName, @newConstraintName,
                            'Object'  
                    END
                FETCH NEXT FROM fkcur INTO @constraintName, @fkTable,
                    @fkColumn, @pkTable, @pkColumn  
            END  
        CLOSE fkcur  
        DEALLOCATE fkcur 
    END

go

