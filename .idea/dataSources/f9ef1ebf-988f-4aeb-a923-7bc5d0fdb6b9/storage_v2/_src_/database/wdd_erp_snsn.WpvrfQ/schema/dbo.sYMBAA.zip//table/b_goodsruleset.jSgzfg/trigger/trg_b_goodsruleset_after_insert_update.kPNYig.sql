CREATE TRIGGER [dbo].[trg_b_goodsruleset_after_insert_update] ON [dbo].[b_goodsruleset]
    AFTER INSERT, UPDATE
AS
BEGIN
    INSERT  INTO b_goodsruleset_delete_back
            ( gss_id ,
              gi_id ,
              gss_no ,
              gs_id ,
              gs_name ,
              gs_stock ,
              gs_salesprice ,
              gs_marketprice ,
              gs_costprice ,
              gs_weight ,
              gs_upstock ,
              gs_downstork ,
              gs_alarmstock ,
              gs_columnid ,
              gs_purchase ,
              gs_oc_id ,
              gs_addtime ,
              gs_updatetime ,
              gs_type_id ,
              gs_type_id_parentid ,
              gs_taobao_id ,
              gs_is_custom ,
              gs_discount ,
              gss_cp_id ,
              gss_di_id ,
              gs_status
            )
            SELECT  gss_id ,
                    gi_id ,
                    gss_no ,
                    gs_id ,
                    gs_name + '=临时记录更新操作' ,
                    gs_stock ,
                    gs_salesprice ,
                    gs_marketprice ,
                    gs_costprice ,
                    gs_weight ,
                    gs_upstock ,
                    gs_downstork ,
                    gs_alarmstock ,
                    gs_columnid ,
                    gs_purchase ,
                    gs_oc_id ,
                    gs_addtime ,
                    gs_updatetime ,
                    gs_type_id ,
                    gs_type_id_parentid ,
                    gs_taobao_id ,
                    gs_is_custom ,
                    gs_discount ,
                    gss_cp_id ,
                    gss_di_id ,
                    gs_status
            FROM    DELETED

    UPDATE  b_goodsruleset
    SET     gs_type_id = degs.gs_type_id ,gss_lastdate=GETDATE(),
            gs_type_id_parentid = degs.gs_type_id_parentid
    FROM    b_goodsruleset fd ,
            ( SELECT    gss_id ,
                        gs_type_id ,
                        gs_type_id_parentid
              FROM      DELETED
            ) AS degs
    WHERE   fd.gss_id = degs.gss_id;

    DECLARE @gid INT= 0;
    
    SELECT  @gid = gi_id
    FROM    INSERTED;
    
    DECLARE @skustr VARCHAR(100)= '';
    
    SELECT  @gid = gi_id ,
            @skustr = gi_skuid
    FROM    b_goodsinfo
    WHERE   gi_id = @gid;

    UPDATE  b_goodsruleset
    SET     gs_columnid = gs_is_custom
    WHERE   gi_id = @gid;
END
go

