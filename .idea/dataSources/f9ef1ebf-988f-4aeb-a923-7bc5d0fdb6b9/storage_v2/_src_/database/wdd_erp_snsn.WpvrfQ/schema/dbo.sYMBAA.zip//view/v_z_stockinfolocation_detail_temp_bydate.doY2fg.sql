CREATE VIEW [dbo].[v_z_stockinfolocation_detail_temp_bydate]
	AS
select
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
locationlist.*
from 
(

select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
isnull(grl.gs_sampleno,gi_sampleno)gs_sampleno,--规格样品号
grl.gs_name,
grl.colorname color,
grl.specname as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
ln.* 
from
(

SELECT
bsil.*,
0 occupy_num,--占用库存
((CASE WHEN bsil.sl_counttype = 1 THEN bsil.sl_number ELSE -bsil.sl_number end)-0)enable_stock_num,--可用库存
bsil.sl_order_add_time AS order_add_time,
CONVERT(varchar(100),bsil.sl_order_date, 23)  AS order_date,
(CASE WHEN bsil.sl_counttype = 1 THEN bsil.sl_number ELSE -bsil.sl_number end) AS  gnum,
bsil.sl_seiid sid,
bsil.sl_erp_id as erp_id,
bsil.sl_cp_id as cp_id,
esl.slt_no,
esl.slt_id,
esl.slt_pickingpath,
ug.sei_name,--仓库
gi.gi_id,
gi_skuid,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_sampleno,--样品号
ui.ut_name --单位
FROM j_stocklog AS bsil
inner join b_storageinfo ug on ug.sei_id=bsil.sl_seiid
left JOIN erp_storagelocation AS esl ON esl.slt_id=bsil.sl_location AND esl.sei_id=bsil.sl_seiid AND esl.slt_status=1
left join b_goodsinfo gi on gi.gi_id=bsil.sl_giid and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 

WHERE bsil.sl_status=1
) as ln
left join b_goodsruleset  as grl on  grl.gss_id=ln.sl_skuid

) as locationlist
left join s_goodsruledetail rulenum on gd_id=locationlist.size
go

