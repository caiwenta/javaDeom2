CREATE FUNCTION [dbo].[FnCheckClientId] ( @ci_id INT, @erp_id INT,@cp_id INT,@status INT )
RETURNS INT
AS
BEGIN
	--用途：验证客户与erpid是否匹配 
    DECLARE @re INT;
	
    IF ( ISNULL(@ci_id, 0) = 0 or ISNULL(@erp_id,0)=0 or @status=0)
        SET @re = 1;
    ELSE
        IF EXISTS ( SELECT  1
                    FROM    dbo.b_clientinfo
                    WHERE   ci_id = @ci_id
                            AND ci_erp_id = @erp_id and ci_cp_id=@cp_id)
            SET @re = 1;
        ELSE
            SET @re = 0;
        
    RETURN @re;
END
go

