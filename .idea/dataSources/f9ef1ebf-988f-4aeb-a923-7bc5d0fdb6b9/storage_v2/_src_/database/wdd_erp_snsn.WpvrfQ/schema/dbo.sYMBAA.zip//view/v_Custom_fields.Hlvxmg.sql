CREATE VIEW dbo.v_Custom_fields
AS
SELECT     dbo.s_sys_column_info.sci_di_id, dbo.s_user_column_info.*
FROM         dbo.s_sys_column_info INNER JOIN
                      dbo.s_user_column_info ON dbo.s_sys_column_info.sci_id = dbo.s_user_column_info.uci_sci_id
go

