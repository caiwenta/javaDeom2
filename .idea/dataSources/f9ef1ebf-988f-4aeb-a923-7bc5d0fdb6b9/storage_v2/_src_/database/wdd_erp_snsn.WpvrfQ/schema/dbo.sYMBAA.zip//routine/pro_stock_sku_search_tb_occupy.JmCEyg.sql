

CREATE Proc [dbo].[pro_stock_sku_search_tb_occupy]
@cp_id INT=0,
@gi_id INT=0,
@sid INT=0,
@time DATETIME ='' 
AS
BEGIN

if @time<>''
BEGIN
	--有仓库
	SELECT fd.*,fd2.gnum,fd2.enable_stock_num,gs_money=fd2.gnum*fd.gs_purchase,bg.gi_name,bg.gi_code FROM (
	SELECT * FROM b_goodsruleset fd WHERE fd.gi_id=@gi_id
	) AS fd LEFT JOIN (
	SELECT sl.skuid,
	 take_up_num As gnum,
	 enable_stock_num
	 FROM vi_stockSumList sl 
	WHERE   sl.gid=@gi_id AND sl.sid=@sid and sl.addtime<=@time 
	) fd2 ON fd.gss_id=fd2.skuid LEFT JOIN b_goodsinfo bg ON fd.gi_id = bg.gi_id
END
else
begin
 --有仓库
	SELECT fd.*,fd2.gnum,fd2.enable_stock_num,gs_money=fd2.gnum*fd.gs_purchase,bg.gi_name,bg.gi_code FROM (
	SELECT * FROM b_goodsruleset fd WHERE fd.gi_id=@gi_id
	) AS fd LEFT JOIN (
	SELECT sl.si_skuid as skuid,
	(isnull(si_occupy_num,0)+isnull(si_allocationoccupy_num,0)+isnull(si_orderblankoccupy_num,0)) As gnum,
	si_number-(isnull(si_occupy_num,0)+isnull(si_allocationoccupy_num,0)+isnull(si_orderblankoccupy_num,0))  as enable_stock_num
	 FROM b_stockinfo sl 
	WHERE   sl.si_giid=@gi_id AND sl.si_seiid=@sid  
	) fd2 ON fd.gss_id=fd2.skuid LEFT JOIN b_goodsinfo bg ON fd.gi_id = bg.gi_id
END
END
go

