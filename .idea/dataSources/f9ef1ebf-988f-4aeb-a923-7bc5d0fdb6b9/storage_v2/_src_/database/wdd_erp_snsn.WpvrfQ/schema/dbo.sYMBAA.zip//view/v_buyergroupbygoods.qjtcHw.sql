CREATE VIEW [dbo].[v_buyergroupbygoods]
	AS 
SELECT
erl.erp_id,
erl.si_id,
erl.order_date,--日期
bg.gi_name,--名称
bg.gi_id,--名称ID
bg.gi_code,--
bs2.si_name,--买手小组
erl.number,--销售数量
(case WHEN isnull(bs.si_royaltytype,0)=2 THEN 0 ELSE (erl.purchase*erl.number) END) AS amountpayment,--货款金额
(case WHEN isnull(bs.si_royaltytype,0)=2 THEN erl.[money] ELSE erl.[money]-(erl.purchase*erl.number) END) AS profitamount,--利润金额
erl.[money],
order_no--凭证号
FROM erp_royaltyschemelog AS erl 
LEFT JOIN b_goodsinfo AS bg ON erl.gi_id=bg.gi_id and bg.gi_status>0
LEFT JOIN b_supplierinfo AS bs ON bs.si_id=bg.gi_supplierid and bs.si_status>0
LEFT JOIN b_stafftinfo AS bs2 on bs2.si_id=erl.si_id and bs2.si_status>0
WHERE erl.commissiontype=5 AND erl.[status]=1
go

