CREATE  VIEW [dbo].[vi_j_plStorage] AS 
SELECT
	pl_id,
	pl_vo,
	CONVERT (VARCHAR(10), pl_date, 120) AS pl_date,
	pl_no,
	pl_st_id,
	pl_order_man,
	pl_cp_id,
	pl_di_id,
	(
		SELECT
			sei_name
		FROM
			dbo.b_storageinfo AS bs WITH (NOLOCK) 
		WHERE
			(sei_id = jis.pl_st_id)
	) AS pl_st_id_txt,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK) 
		WHERE
			(si_id = jis.pl_order_man)
	) AS pl_order_man_txt,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK) 
		WHERE
			(si_id = jis.pl_add_man)
	) AS pl_add_man_txt,
	pl_add_man,
	pl_add_time,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK) 
		WHERE
			(si_id = jis.pl_update_man)
	) AS pl_update_man_txt,
	pl_update_man,
	pl_update_time,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK) 
		WHERE
			(si_id = jis.pl_audit_man)
	) AS pl_audit_man_txt,
	pl_audit_man,
	pl_audit_time,
	pl_remark,
	pl_status,
	(
		SELECT
			SUM (ppl_num)
		FROM
			j_plStorageList WITH (NOLOCK) 
		WHERE
			ppl_pl_id = jis.pl_id
		AND ppl_status > 0
	) AS sumnum,
	(
		SELECT
			SUM (ppl_money)
		FROM
			j_plStorageList WITH (NOLOCK) 
		WHERE
			ppl_pl_id = jis.pl_id
		AND ppl_status > 0
	) AS summoney
FROM
	dbo.j_plStorage AS jis WITH (NOLOCK)
go

