CREATE  PROCEDURE [dbo].[pro_createquota_op]
	@date DATETIME='2017-09-03',
    @erp_id INT=51
AS

delete erp_buyergroupquota WHERE bq_erpid=@erp_id AND bq_date=@date


INSERT INTO [dbo].[erp_buyergroupquota]
           (
            [bg_cp_id]
           ,[bq_date]
           ,[bq_qcquota]
           ,[purchaseexpenditure]
           ,[salesreturn]
           ,[costmoney]
           ,[availablebalance]
           ,[thiyetmoney]
           ,[purchasemoney]
           ,[money]
           ,[paymentmoney]
 ,[enterrealmoney]
 ,bq_erpid)
SELECT 
tt.cp_id,
@date AS bq_date,
isnull(tt.bq_qcquota,0) AS bq_qcquota,
tt.purchaseexpenditure,
tt.salesreturn,
tt.costmoney,

--可用余额（期初授信额+销售回款-采购支出）/3
isnull(CAST(round((isnull(bq_qcquota,0)+isnull(salesreturn,0)-isnull(purchaseexpenditure,0)),2) AS DECIMAL(18, 2)),0) AS availablebalance, 

tt.thiyetmoney,
tt.purchasemoney,
tt.[money],
tt.paymentmoney,
tt.enterrealmoney,
@erp_id
FROM(
SELECT 

--销售回款：（分公司应收登记本期收款-出库单进货金额（客户）+店铺销售买手小组分成（分公司关联买手小组分成）								
((isnull(t.thiyetmoney,0)-isnull(t.purchasemoney,0))+isnull(t.[money],0)) salesreturn,

--采购支出：分公司已付款金额（供应商分润类型 ：现金供应商、空的）+净入库金额（商品类型为现金）   
(isnull(t.paymentmoney,0)+isnull(t.enterrealmoney,0)) AS purchaseexpenditure,   

 --费用：现金银行增中买手小组字段取现金银行费用“支出一收入”
t.cost as costmoney,  
                                     
t.*
FROM 
(
SELECT
cp_id,
cp_name,

--期初授信额
ISNULL((SELECT availablebalance FROM erp_buyergroupquota AS TT  WHERE bg_cp_id=c.cp_id AND bq_date=CONVERT(varchar(100), dateadd(day,-1,@date), 23)),0) AS bq_qcquota,
    
     
--分公司应收登记本期收款	                   
(SELECT sum(fo_thiyetmoney) AS thiyetmoney FROM c_fundorder WITH (NOLOCK) WHERE fo_erp_id=@erp_id 
AND fo_type=0 AND convert(VARCHAR(10),fo_ofdate,120)=@date AND fo_status>0 
AND fo_thiyetmoney<>0 and fo_cp_id=c.cp_id) AS thiyetmoney,


--出库单代销商品进货金额（客户）
(SELECT sum(CASE WHEN st.ol_skuid>0 THEN bgs.gs_purchase*((CASE WHEN ge.oo_type=0 THEN  -st.ol_number ELSE st.ol_number END)) ELSE bg.gi_purchase*(CASE WHEN ge.oo_type=0 THEN  -st.ol_number ELSE st.ol_number END) END ) AS purchasemoney 
FROM j_outStorage ge WITH (NOLOCK)
INNER JOIN j_outStorageList st WITH (NOLOCK) ON ge.oo_id = ol_eoid AND st.ol_status = 1 
AND convert(VARCHAR(10),oo_entrydate,120)=@date AND oo_ciid>0 AND oo_cp_id=c.cp_id and ge.oo_status>0
INNER JOIN b_goodsinfo AS bg WITH (NOLOCK) ON bg.gi_id=st.ol_siid
INNER JOIN b_supplierinfo AS bs ON bs.si_id=bg.gi_supplierid AND bs.si_royaltytype=2
LEFT JOIN b_goodsruleset AS bgs WITH (NOLOCK) ON bgs.gss_id=st.ol_skuid	
) AS purchasemoney,


--店铺销售买手小组分成
(SELECT sum(MONEY) AS MONEY FROM erp_royaltyschemelog WHERE [type]=2 and erp_id=@erp_id AND convert(VARCHAR(10),order_date,120)=@date AND commissiontype=5 AND [status]<>0
AND si_id in (SELECT si_id FROM b_stafftinfo AS bs WHERE si_company=c.cp_id)) AS [money],


--分公司付款（供应商分润类型 ：现金供应商、空的)
(SELECT sum(fo_thiyetmoney) AS paymentmoney FROM c_fundorder AS cf WITH (NOLOCK) 
INNER JOIN b_supplierinfo AS bs WITH (NOLOCK) ON bs.si_id=cf.fo_ciid
WHERE  fo_erp_id=@erp_id and fo_type=1 AND fo_status>0 AND fo_thiyetmoney>0 
AND convert(VARCHAR(10),fo_ofdate,120)=@date and fo_cp_id=c.cp_id AND (si_royaltytype=1 or si_royaltytype=0)) AS paymentmoney,


--净入库金额（商品类型为现金）
(SELECT sum((CASE WHEN eo_type=1 THEN  -el_realmoney ELSE el_realmoney END)) AS el_realmoney FROM  j_enterStorage ge WITH (NOLOCK)
inner join  j_enterStorageList st WITH (NOLOCK) ON ge.eo_erp_id=@erp_id and ge.eo_id = el_eoid AND st.el_status = 1 and ge.eo_status>0 AND convert(VARCHAR(10),ge.eo_entrydate,120)=@date AND ge.eo_cp_id=c.cp_id
INNER JOIN b_goodsinfo AS bg WITH (NOLOCK) ON bg.gi_id=st.el_siid AND gi_quotatype=1
) AS enterrealmoney,
    
--费用支出一收入     
--(SELECT sum(iol_chumoney-iol_rumoney) AS cost FROM c_inoutlist WHERE iol_erp_id=@erp_id  AND convert(VARCHAR(10),iol_indate,120)=@date AND iol_cp_id=c.cp_id) AS cost 

(SELECT SUM(CASE WHEN pft.ft_type=1 THEN fg_money ELSE 0 end)-SUM(CASE WHEN pft.ft_type=2 THEN fg_money ELSE 0 end) AS chumoney FROM pos_feeregister AS pf 
INNER JOIN pos_fee_type AS pft ON pft.ft_id=pf.fg_ft_id AND pf.fg_cp_id=c.cp_id and pft.ft_erp_id=@erp_id and pf.fg_status=1 and convert(VARCHAR(10),fg_date,120)=@date) AS cost 



FROM companyinfo AS c WHERE c.cp_erp_id=@erp_id AND cp_is_zorf=2 AND c.cp_status=1 

) AS T) AS TT
go

