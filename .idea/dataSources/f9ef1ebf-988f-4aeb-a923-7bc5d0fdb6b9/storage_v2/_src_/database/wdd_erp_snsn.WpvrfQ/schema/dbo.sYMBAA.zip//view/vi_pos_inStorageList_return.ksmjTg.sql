CREATE VIEW dbo.vi_pos_inStorageList_return
AS
SELECT     a.in_id, a.in_sh_id, a.in_vo, a.in_no, a.in_date, a.in_st_id, a.in_source, a.in_supplier_sh_id, b3.sh_company, a.in_order_man, a.in_update_man, a.in_update_time, a.in_add_man, a.in_add_time, 
                      a.in_audit_man, a.in_audit_time, a.in_status, a.in_type, a.in_is_audit, a.in_remark, a.in_actual_num, a.in_source_id, a.in_main_audit_man, a.in_main_audit_time, a.ord_no, 
                      b1.sei_name AS in_st_id_txt, b2.si_name AS in_order_man_txt, b3.sh_name AS in_supplier_sh_id_txt, b4.si_name AS in_add_manc, b5.si_name AS in_update_manc, b6.si_name AS in_audit_manc,
                          (SELECT     SUM(inl_num) AS Expr1
                            FROM          dbo.pos_inStorageList
                            WHERE      (inl_in_id = a.in_id)) AS sumNum,
                          (SELECT     SUM(inl_money) AS Expr1
                            FROM          dbo.pos_inStorageList AS pos_inStorageList_1
                            WHERE      (inl_in_id = a.in_id)) AS summoney
FROM         dbo.pos_inStorage AS a INNER JOIN
                      dbo.pos_storageInfo AS b1 ON a.in_st_id = b1.sei_id LEFT OUTER JOIN
                      dbo.b_stafftinfo AS b2 ON a.in_order_man = b2.si_id INNER JOIN
                      dbo.pos_shop AS b3 ON a.in_sh_id = b3.sh_id LEFT OUTER JOIN
                      dbo.b_stafftinfo AS b4 ON a.in_add_man = b4.si_id LEFT OUTER JOIN
                      dbo.b_stafftinfo AS b5 ON a.in_update_man = b5.si_id LEFT OUTER JOIN
                      dbo.b_stafftinfo AS b6 ON a.in_audit_man = b6.si_id
go

