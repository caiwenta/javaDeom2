CREATE VIEW [dbo].[vi_StockWarningReport]
	AS 

SELECT (CASE WHEN stock_num>max_num THEN '超出'
             WHEN stock_num<min_num THEN '缺货'
             ELSE '正常' END)stock_status,--状态
       (CASE WHEN stock_num>max_num THEN stock_num-max_num
             WHEN stock_num<min_num THEN stock_num-min_num
             ELSE 0 END)difference_num,--超出/缺货数量
       * 
FROM(
SELECT (CASE WHEN a_method=1 THEN a_min
            WHEN a_method=2 THEN (CASE WHEN a_min_saletype=1 THEN (SELECT ISNULL(SUM(sal_num),0)/a_min_saledays 
                                                                   FROM pos_sale 
                                                                   LEFT JOIN pos_saleList ON sa_id=sal_sa_id
                                                                   WHERE sa_status>0 AND sal_gi_id=a_gi_id 
                                                                     AND DATEDIFF(DAY, sa_date, GETDATE())<a_min_saledays)
                                       WHEN a_min_saletype=2 THEN (SELECT ISNULL(SUM(sal_num),0) 
                                                                   FROM pos_sale 
                                                                   LEFT JOIN pos_saleList ON sa_id=sal_sa_id
                                                                   WHERE sa_status>0 AND sal_gi_id=a_gi_id 
                                                                     AND DATEDIFF(DAY, sa_date, GETDATE())<a_min_saledays) END) END)min_num, --最低库存
      (CASE WHEN a_method=1 THEN a_max
            WHEN a_method=2 THEN (CASE WHEN a_max_saletype=1 THEN (SELECT ISNULL(SUM(sal_num),0)/a_max_saledays 
                                                                   FROM pos_sale 
                                                                   LEFT JOIN pos_saleList ON sa_id=sal_sa_id
                                                                   WHERE sa_status>0 AND sal_gi_id=a_gi_id 
                                                                     AND DATEDIFF(DAY, sa_date, GETDATE())<a_max_saledays)
                                       WHEN a_max_saletype=2 THEN (SELECT ISNULL(SUM(sal_num),0) 
                                                                   FROM pos_sale 
                                                                   LEFT JOIN pos_saleList ON sa_id=sal_sa_id
                                                                   WHERE sa_status>0 AND sal_gi_id=a_gi_id 
                                                                     AND DATEDIFF(DAY, sa_date, GETDATE())<a_max_saledays) END) END)max_num, --最高库存
      ISNULL((SELECT stock_num FROM (SELECT st_gi_id,SUM(st_num)stock_num
									 FROM (
                              			SELECT st_gi_id,st_num 
                              			FROM pos_stockInfo
                              			INNER JOIN pos_shop ON st_sh_id=sh_id
                              			UNION ALL 
                              			SELECT si_giid,si_number
                              			FROM b_stockinfo
                              			INNER JOIN companyinfo ON si_cp_id=cp_id
                              			WHERE si_status>0
									 )T
                              WHERE T.st_gi_id=a_gi_id
                              GROUP BY T.st_gi_id)T),0)stock_num,--当前库存（终端库存查询）
       (SELECT si_name FROM b_stafftinfo WHERE si_id = a_addman) AS a_addman_txt, 
       (SELECT si_name FROM b_stafftinfo WHERE si_id = a_modifyman) AS a_modifyman_txt, 
       *
FROM erp_alarm
)alarm
INNER JOIN v_goodsinfo bg ON alarm.a_gi_id=bg.gi_id
go

