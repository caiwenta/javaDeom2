CREATE FUNCTION [dbo].[GetPmNumberSum](@str varchar(500))
returns int
as
begin
--获取pm号总的数量
declare @sum int=0;

if len(@str)>0
begin

IF EXISTS(SELECT * FROM erp_pmlist WHERE pm_name=@str)
BEGIN
	
SELECT @sum=pm_num FROM erp_pmlist WHERE pm_name=@str;

END
ELSE
BEGIN
	
declare @n int
declare @m int
declare @i int
set @n=len(@str)
set @m=0  
set @i=1
set @sum=0;
while @i<=@n
 begin
  set @m=substring(@str,@i,1)
  set @sum=@m+@sum
  set @i=@i+1
end 
--INSERT INTO [dbo].[erp_pmlist]([pm_num],[pm_name])VALUES(@sum,@str);
END

end

return @sum;
end
go

