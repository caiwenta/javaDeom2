
CREATE  proc [dbo].[pro_pos_MayAllNum_log]            
@UserID int,                                         
@al_st_id int,                          
@al_id int                           
as

declare @ri_can_allc_check int ;

DECLARE @result_var VARCHAR(1000) = '';
DECLARE @bool_need_error INT = 0;
DECLARE @now DATETIME = GETDATE();


select @ri_can_allc_check=ri_can_allc_check from s_role_info ro inner join b_stafftinfo fo on 
fo.si_pid=ro.ri_id and si_id=@UserID


if(@ri_can_allc_check=1)
begin
if exists(
 select n.al_id,all_gi_id,all_sku_id,st.all_num as st_all_num,stock.all_num,al_st_id from pos_allocationList st inner join pos_allocation n on
 st.all_al_id=n.al_id and st.all_al_id=@al_id left join 
(SELECT ss.gid, ss.skuid, ss.sid, ss.gnum,  (ss.gnum - ISNULL(val.all_num, 0))  AS all_num, ss.cp_id
FROM         dbo.vi_stockSum AS ss INNER JOIN
                      dbo.b_storageinfo AS bs ON ss.sid = bs.sei_id 
                      INNER JOIN
                      dbo.b_goodsinfo AS bg ON ss.gid = bg.gi_id LEFT OUTER JOIN
                      dbo.b_goodsruleset AS bg2 ON ss.skuid = bg2.gss_id INNER JOIN
                      dbo.b_unit AS bu ON bg.gi_unit = bu.ut_id LEFT OUTER JOIN
                          (SELECT     ogl_gi_id, al_st_id, ogl_sku_id, al_cp_id, SUM(all_num) AS all_num
                            FROM          dbo.vi_stockList_Allocation
                            WHERE      (al_cp_id > 0) and al_id<>@al_id and al_st_id=@al_st_id
                            GROUP BY ogl_gi_id, ogl_gi_id, al_st_id, ogl_sku_id, al_cp_id) AS val ON ss.gid = val.ogl_gi_id AND ss.sid = val.al_st_id AND ss.skuid = val.ogl_sku_id)
stock on st.all_sku_id=stock.skuid and st.all_gi_id=stock.gid and n.al_st_id=stock.[sid]
where  st.all_num> ISNULL(stock.all_num, 0) 

)
begin
 set @result_var='可配数量不足!';
 set @bool_need_error=1;
end
end
else
begin
set @bool_need_error=0;
end
IF @bool_need_error = 1
BEGIN
    RAISERROR (
        @result_var, -- Message text,
        16, -- Severity,
        1, -- State,
        N'number', -- First argument.
        5 -- Second argument.
    );
END

go

