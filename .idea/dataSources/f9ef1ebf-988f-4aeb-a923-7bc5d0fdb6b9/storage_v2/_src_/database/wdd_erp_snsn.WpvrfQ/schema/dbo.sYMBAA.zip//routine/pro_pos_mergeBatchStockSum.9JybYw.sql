CREATE PROCEDURE [dbo].[pro_pos_mergeBatchStockSum]
@tsl_sh_id INT = 0,
@id INT=0,
@type INT=0,

@negative_inventory INT=0,--产生了负库存是否提示
@old_sei_id INT=0,  
@new_sei_id INT=0
AS
	 --批次计算库存	
DECLARE @tdoc_xml VARCHAR(max)= '';
declare @erpid int=0;
SELECT @erpid=sh_erp_id FROM pos_shop ps WHERE sh_id=@tsl_sh_id

SET @tdoc_xml = '{ 
"type":"' + CONVERT(VARCHAR(50), @type) + '",
"id":"' + CONVERT(VARCHAR(50), @id) + '",
"sh_id":"' + CONVERT(VARCHAR(50), @tsl_sh_id) + '", 
"negative_inventory":"' + CONVERT(VARCHAR(50), @negative_inventory) + '", 
"old_sei_id":"' + CONVERT(VARCHAR(50), @old_sei_id) + '",
"new_sei_id":"' + CONVERT(VARCHAR(50), @new_sei_id) + '" }';

			EXEC pro_apiqueue_op 
			@tdoc_target='storage',
			@tdoc_action='batchnumber',
			@tdoc_method = 'posstorage', 
			@tdoc_xml = @tdoc_xml, 
			@tdoc_erp_id =@erpid, 
			@tdoc_state = 0;	

			EXEC pro_apiqueue_op 
			@tdoc_target='storage',
			@tdoc_action='mergeStockSumBatchNumber',
			@tdoc_method = 'posstorage', 
			@tdoc_xml = @tdoc_xml, 
			@tdoc_erp_id =@erpid, 
			@tdoc_state = 0;
go

