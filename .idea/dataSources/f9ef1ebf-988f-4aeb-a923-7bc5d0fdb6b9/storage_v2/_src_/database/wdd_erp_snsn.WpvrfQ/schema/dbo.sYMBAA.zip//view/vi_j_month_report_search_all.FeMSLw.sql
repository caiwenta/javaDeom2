CREATE VIEW [dbo].[vi_j_month_report_search_all]
as

select 
TT.*,
(start_money+enmoneyhj-ooth_moneyhj+ykmoney+oimoney) AS end_money,
(start_num+enhj-ooth_numhj+yktsnum+oinum) AS end_num
from
(
SELECT *,

mo_num+mi_num as oinum,
mo_money+mi_money as oimoney,
yk_num+ts_num as yktsnum,
yk_money+ts_money as ykmoney,
isnull(sc.en_num,0)-isnull(sc.enth_num,0) AS enhj ,
isnull(sc.en_money,0)-isnull(sc.enth_money,0) AS enmoneyhj,

isnull(abs(sc.oo_num),0)- isnull(sc.ooth_num,0)  AS ooth_numhj,
isnull(abs(oo_money),0)-isnull(sc.ooth_money,0) AS ooth_moneyhj,




 0 AS retail_start_money,0 as  retail_en_money,0 as retail_enth_money,0 AS retail_oo_money,0 as retail_ooth_money,
 0 as retail_enmoneyhj,0 AS retail_ooth_moneyhj,0 AS retail_yk_money,0 AS retail_mo_money,0 AS retail_end_money

FROM(



select 
	    fd.sei_cp_id AS company_id,
		fd.gid,
		fd.sid,
		fd.sei_erp_id AS erp_id,
		fd.gi_name,
		fd.gi_code,
		fd.gi_unit_name AS ut_name,
		fd.sei_name,
		 --0 as start_num,
		 --0 as start_money,
		SUM(case when fd.myremark='期初' then fd.gnum else 0 end) as start_num,
		SUM(case when fd.myremark='期初' then fd.allmoney else 0 end) as start_money,
		SUM(case when fd.myremark='入库' then fd.gnum else 0 end) as en_num,
		SUM(case when fd.myremark='入库' then fd.allmoney else 0 end) as en_money,
		abs(SUM(case when fd.myremark='入库退货' then fd.gnum else 0 end)) as enth_num,
		abs(SUM(case when fd.myremark='入库退货' then fd.allmoney else 0 end)) as enth_money,
		abs(SUM(case when fd.myremark='出库' then fd.gnum else 0 end)) as oo_num,
	    abs(SUM(case when fd.myremark='出库' then fd.allmoney else 0 end)) as oo_money,
		SUM(case when fd.myremark='出库退货' then fd.gnum else 0 end) as ooth_num,
		SUM(case when fd.myremark='出库退货' then fd.allmoney else 0 end) as ooth_money,
		SUM(case when fd.myremark='整仓盘点盈亏调整' then fd.gnum else 0 end) as ts_num,
	    SUM(case when fd.myremark='整仓盘点盈亏调整' then fd.allmoney else 0 end) as ts_money,
		SUM(case when fd.myremark='移出仓库' then fd.gnum else 0 end) as mo_num,
		SUM(case when fd.myremark='移出仓库' then fd.allmoney else 0 end) as mo_money,
		SUM(case when fd.myremark='移入仓库' then fd.gnum else 0 end) as mi_num,
		SUM(case when fd.myremark='移入仓库' then fd.allmoney else 0 end) as mi_money,
		SUM(case when fd.myremark='盈亏'then fd.gnum else 0 end) as yk_num,
		SUM(case when fd.myremark='盈亏'then fd.allmoney else 0 end) as yk_money,
		max(order_date) as order_date
		from vi_stockList_createmonthly as fd
GROUP BY
	    fd.sei_cp_id,
		fd.gid,fd.sei_erp_id,fd.gi_name,
		fd.gi_code,
		fd.gi_unit_name,fd.sei_name,
		fd.sid
		


) AS sc
		
) as TT
go

