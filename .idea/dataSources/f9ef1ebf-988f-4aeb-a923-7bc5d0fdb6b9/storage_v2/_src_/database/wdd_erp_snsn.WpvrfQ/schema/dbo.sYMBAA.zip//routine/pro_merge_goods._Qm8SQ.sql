CREATE Proc [dbo].[pro_merge_goods]
@oc_id int,
@timestamp datetime,
@result int OUT,
@do_other_table INT=1,
@do_all INT=0
AS

DECLARE @erp_id INT=0;
	SELECT @erp_id=mo.oc_erp_id FROM m_orderchannel mo WHERE mo.oc_id=@oc_id
--公司主键更新
DECLARE @cp_id INT=0;
SELECT TOP 1 @cp_id=c.cp_id 
FROM companyinfo c WHERE c.cp_is_zorf=1
AND c.cp_erp_id=@erp_id



--UpdateDocking_tt 商品页面 同步批量设置
--
--SELECT REPLACE('EXEC pro_batch_set_tb @dose_frmid = {0}','{0}',bg.gi_id) ,* FROM b_goodsinfo bg

--pro_batch_set_tb

--tb id添加

DECLARE @result_var VARCHAR(MAX)='';
DECLARE @all_success INT=1;
EXEC pro_del_merge
	@oc_id = @oc_id,
	@timestamp = @timestamp
	
begin TRAN

BEGIN TRY
	

--存储店中店自己的id
--用于后续关联进行数据更新
--规格明细id
--分类id
--商品信息完善
--根据商品库存字段,商品规格库存字段生成期初库存

DECLARE @sint int=1;
declare @now datetime=getdate();




IF 1=2
BEGIN

--规格处理失败要报错
RAISERROR (
        '',	
        16,	
        1,	
        N'number',	
        5 
    );
--要添加到操作日志里
--[api_tokenlog_tbl]

END


IF @do_other_table=1 OR @do_all=1
BEGIN

merge into s_goodsbrand as ta
using (select * from s_goodsbrand_merge as so WITH (NOLOCK)  where so.gb_oc_id=@oc_id and so.gb_timestamp=@timestamp) as so
on ta.gb_oc_id=so.gb_oc_id and ta.gb_type_id=so.gb_type_id  
when matched then update set ta.gb_name=so.gb_name,ta.gb_url=so.gb_url,ta.gb_logo=so.gb_logo,ta.gb_sort=so.gb_sort,ta.gb_txt=so.gb_txt,ta.gb_updatetime=@now
when not matched then insert (gb_name, gb_url, gb_logo, gb_sort, gb_txt, gb_type_id, gb_addtime, gb_updatetime, gb_oc_id)values(so.gb_name,so.gb_url,so.gb_logo,so.gb_sort,so.gb_txt,so.gb_type_id,@now,@now,so.gb_oc_id);
IF @@ROWCOUNT>0
BEGIN

SELECT so.gb_type_id INTO #s_goodsbrand_merge_p
	  from s_goodsbrand_merge as so WITH (NOLOCK)  where so.gb_oc_id=@oc_id and so.gb_timestamp=@timestamp
	  

UPDATE s_goodsbrand SET gb_status = 1 WHERE gb_oc_id=@oc_id
AND gb_type_id IN(
	SELECT * FROM #s_goodsbrand_merge_p fd WITH (NOLOCK)   
)

END

	
END

PRINT '1';



IF @do_other_table=1 OR @do_all=1
BEGIN
merge into s_goodsclass as ta
using (select * from s_goodsclass_merge as so WITH (NOLOCK)  where so.gc_oc_id=@oc_id and so.gc_timestamp=@timestamp) as so
on ta.gc_oc_id=so.gc_oc_id and ta.gc_type_id=so.gc_type_id  
when matched then update set ta.gc_name=so.gc_name,ta.gs_name=so.gs_name,ta.gs_id=so.gs_id,ta.gc_img=so.gc_img,ta.gc_priceterm=so.gc_priceterm,ta.gc_sort=so.gc_sort,ta.gc_keys=so.gc_keys,ta.gc_description=so.gc_description,ta.mid=so.mid,ta.gc_status=so.gc_status,ta.gc_type=so.gc_type,ta.gc_type_id=so.gc_type_id,ta.gc_type_id_parentid=so.gc_type_id_parentid,ta.gc_addtime=so.gc_addtime,ta.gc_updatetime=so.gc_updatetime,ta.gc_oc_id=so.gc_oc_id
when not matched then insert(gc_name,gs_name,gs_id,gc_img,gc_priceterm,gc_sort,gc_keys,gc_description,mid,gc_status,gc_type,gc_type_id,gc_type_id_parentid,gc_addtime,gc_updatetime,gc_oc_id)values(so.gc_name,so.gs_name,so.gs_id,so.gc_img,so.gc_priceterm,so.gc_sort,so.gc_keys,so.gc_description,so.mid,so.gc_status,so.gc_type,so.gc_type_id,so.gc_type_id_parentid,so.gc_addtime,so.gc_updatetime,so.gc_oc_id);  	

IF @@ROWCOUNT>0
BEGIN


SELECT so.gc_type_id INTO #s_goodsclass_merge_p
  from s_goodsclass_merge as so WITH (NOLOCK)  where so.gc_oc_id=@oc_id and so.gc_timestamp=@timestamp	
  
  
  
update s_goodsclass
set gc_fid = 0
WHERE gc_oc_id=@oc_id AND gc_type_id_parentid=0
AND gc_type_id IN(
SELECT * FROM #s_goodsclass_merge_p fd WITH (NOLOCK)   
)



UPDATE s_goodsclass SET gc_fid = fd2.gc_fid
FROM s_goodsclass fd,(
SELECT fd.gc_id,fd2.gc_id AS gc_fid
  FROM s_goodsclass fd WITH (NOLOCK)  INNER JOIN s_goodsclass fd2  WITH (NOLOCK)  ON fd2.gc_type_id=fd.gc_type_id_parentid
WHERE fd.gc_oc_id=@oc_id
) AS fd2 WHERE fd.gc_id=fd2.gc_id
AND fd.gc_type_id IN(
SELECT * FROM #s_goodsclass_merge_p fd WITH (NOLOCK)
)

UPDATE s_goodsclass SET gc_isdel = 1,gc_status=1 WHERE gc_oc_id=@oc_id AND gc_type_id IN(
SELECT * FROM #s_goodsclass_merge_p fd WITH (NOLOCK)
)


UPDATE s_goodsclass SET gc_isdel = 0
FROM s_goodsclass,(
SELECT gc_id FROM s_goodsclass WITH (NOLOCK)  WHERE gc_type_id_parentid NOT IN(
SELECT sg.gc_type_id FROM s_goodsclass sg WITH (NOLOCK) 	
) AND gc_type_id_parentid!=0
) AS fd WHERE fd.gc_id=s_goodsclass.gc_id AND s_goodsclass.gc_oc_id=@oc_id AND s_goodsclass.gc_type_id IN(
SELECT * FROM #s_goodsclass_merge_p fd WITH (NOLOCK)
) 
	
END
END

PRINT '2';
 

IF @do_other_table=0 OR @do_all=1
BEGIN

merge into s_goodsrule as ta
using (select * from  s_goodsrule_merge as so WITH (NOLOCK)  where so.gs_oc_id=@oc_id and so.gs_timestamp=@timestamp) as so
on ta.gs_oc_id=so.gs_oc_id and ta.gs_class_id=so.gs_class_id 
when matched then update set  ta.gs_fid=so.gs_fid,ta.gs_name=so.gs_name,ta.gs_type=so.gs_type,ta.gs_sort=so.gs_sort,ta.gs_remark=so.gs_remark,ta.gs_values=so.gs_values,ta.mid=so.mid,ta.gs_class=so.gs_class,ta.gs_class_id=so.gs_class_id,ta.gs_updatetime=@now,ta.gs_oc_id=so.gs_oc_id
when not matched then insert(gs_fid,gs_name,gs_type,gs_sort,gs_remark,gs_values,mid,gs_class,gs_class_id,gs_addtime,gs_updatetime,gs_oc_id)values(so.gs_fid,so.gs_name,so.gs_type,so.gs_sort,so.gs_remark,so.gs_values,so.mid,so.gs_class,so.gs_class_id,@now,@now,so.gs_oc_id);
IF @@ROWCOUNT>0
BEGIN


SELECT  gs_class_id INTO #s_goodsrule_merge_p from  s_goodsrule_merge as so WITH (NOLOCK)  where so.gs_oc_id=@oc_id and so.gs_timestamp=@timestamp


UPDATE s_goodsrule SET gs_status = 1 WHERE gs_oc_id=@oc_id
AND gs_class_id IN(
SELECT * FROM #s_goodsrule_merge_p fd WITH (NOLOCK)   
)

UPDATE s_goodsrule SET gs_remark = '尺码'
WHERE gs_id IN(
SELECT sg.gs_id
  FROM s_goodsrule sg WHERE ISNULL(sg.gs_remark,'') NOT IN('颜色','尺码') and
   sg.gs_oc_id=@oc_id
) AND gs_class_id IN(
SELECT * FROM #s_goodsrule_merge_p fd WITH (NOLOCK)   
) 

END 
	
END
PRINT '3';


IF @do_other_table=0 OR @do_all=1
BEGIN
merge into s_goodsruledetail as ta
using (select * from s_goodsruledetail_merge as so where so.gd_oc_id=@oc_id and so.gd_timestamp=@timestamp)as so
on ta.gd_oc_id=so.gd_oc_id and ta.gd_type_id=so.gd_type_id  
when matched then update set ta.gd_name=so.gd_name,ta.dg_img=so.dg_img,ta.dg_sort=so.dg_sort,ta.gd_code=so.gd_code,ta.gd_type=so.gd_type,ta.gd_type_id_parentid=so.gd_type_id_parentid,ta.gd_type_id=so.gd_type_id,ta.gd_updatetime=@now,ta.gd_oc_id=so.gd_oc_id
when not matched then insert(gd_name,dg_img,dg_sort,gd_code,gd_type,gd_type_id_parentid,gd_type_id,gd_addtime,gd_updatetime,gd_oc_id,gs_id)values(so.gd_name,so.dg_img,so.dg_sort,so.gd_code,so.gd_type,so.gd_type_id_parentid,so.gd_type_id,@now,@now,so.gd_oc_id,(
	
	select sg.gs_id
	  from s_goodsrule as sg where sg.gs_oc_id=@oc_id and sg.gs_class_id=so.gd_type_id_parentid
	  
));
IF @@ROWCOUNT>0
BEGIN
	
select gd_type_id INTO #s_goodsruledetail_merge_p from s_goodsruledetail_merge as so where so.gd_oc_id=@oc_id and so.gd_timestamp=@timestamp


update s_goodsruledetail
set gs_id = (
	select sg.gs_id
	  from s_goodsrule as sg where sg.gs_oc_id=@oc_id and sg.gs_class_id=gd_type_id_parentid
) where gd_oc_id=@oc_id AND gd_type_id IN(
SELECT * FROM #s_goodsruledetail_merge_p fd WITH (NOLOCK)   
)
	
END
END
PRINT '4';

IF @do_other_table=0 OR @do_all=1
BEGIN

UPDATE b_goodsinfo_merge SET gi_class = @do_other_table WHERE gi_oc_id=@oc_id and gi_timestamp=@timestamp
	
END
merge into b_goodsinfo as ta
using (select * from b_goodsinfo_merge as so where so.gi_oc_id=@oc_id and so.gi_timestamp=@timestamp 
--AND so.gi_status=1
 ) as so 
on ta.gi_oc_id=so.gi_oc_id and ta.gi_class_id=so.gi_class_id  
when matched then update set ta.gi_shortname=so.gi_shortname,ta.gi_name=so.gi_name,ta.gi_type=so.gi_type,ta.gi_code=so.gi_code,ta.gi_grade=so.gi_grade,ta.gi_norm=so.gi_norm,ta.gi_status=so.gi_status,ta.gi_remark=so.gi_remark,ta.gi_entrydate=so.gi_entrydate,ta.gi_unit=so.gi_unit,ta.si_img=so.si_img,ta.gi_skus=so.gi_skus,ta.gi_alarmstock=so.gi_alarmstock,ta.gi_barcode=so.gi_barcode,ta.gi_brands=so.gi_brands,ta.gi_category=so.gi_category,ta.gi_costprice=so.gi_costprice,ta.gi_downstork=so.gi_downstork,ta.gi_importprices=so.gi_importprices,ta.gi_number=so.gi_number,ta.gi_retailprice=so.gi_retailprice,ta.gi_seiid=so.gi_seiid,ta.gi_seiname=so.gi_seiname,ta.gi_typeone=so.gi_typeone,ta.gi_types=so.gi_types,ta.gi_typesid=so.gi_typesid,ta.gi_upstock=so.gi_upstock,ta.gi_virtual=so.gi_virtual,ta.gi_weight=so.gi_weight,ta.gi_simplecode=so.gi_simplecode,ta.gi_brandsid=so.gi_brandsid,ta.gi_skuid=so.gi_skuid,ta.gi_purchase=so.gi_purchase,ta.gi_class=so.gi_class,ta.gi_class_id=so.gi_class_id,ta.gi_updatetime=@now,ta.gi_oc_id=so.gi_oc_id
when not matched then insert(gi_shortname,gi_name,gi_type,gi_code,gi_grade,gi_norm,gi_status,gi_remark,gi_entrydate,gi_unit,si_img,gi_skus,gi_alarmstock,gi_barcode,gi_brands,gi_category,gi_costprice,gi_downstork,gi_importprices,gi_number,gi_retailprice,gi_seiid,gi_seiname,gi_typeone,gi_types,gi_typesid,gi_upstock,gi_virtual,gi_weight,gi_simplecode,gi_brandsid,gi_skuid,gi_purchase,gi_class,gi_class_id,gi_addtime,gi_updatetime,gi_oc_id)values(so.gi_shortname,so.gi_name,so.gi_type,so.gi_code,so.gi_grade,so.gi_norm,so.gi_status,so.gi_remark,so.gi_entrydate,so.gi_unit,so.si_img,so.gi_skus,so.gi_alarmstock,so.gi_barcode,so.gi_brands,so.gi_category,so.gi_costprice,so.gi_downstork,so.gi_importprices,so.gi_number,so.gi_retailprice,so.gi_seiid,so.gi_seiname,so.gi_typeone,so.gi_types,so.gi_typesid,so.gi_upstock,so.gi_virtual,so.gi_weight,so.gi_simplecode,so.gi_brandsid,so.gi_skuid,so.gi_purchase,so.gi_class,so.gi_class_id,so.gi_addtime,so.gi_updatetime,so.gi_oc_id);

SELECT so.gi_class_id INTO #b_goodsinfo_merge_p
  from b_goodsinfo_merge as so where so.gi_oc_id=@oc_id and so.gi_timestamp=@timestamp 
  --AND so.gi_status=1



UPDATE b_goodsinfo SET gi_status =1 
WHERE gi_oc_id=@oc_id AND gi_class_id IN(
SELECT * FROM #b_goodsinfo_merge_p fd WITH (NOLOCK)   
)



IF @do_other_table=1 OR @do_all=1
BEGIN
--品牌处理
UPDATE b_goodsinfo SET gi_brandsid = fd.gb_id
FROM b_goodsinfo,(
SELECT bg.gi_id,sg.gb_id
  FROM b_goodsinfo bg INNER JOIN s_goodsbrand sg ON bg.gi_brandsid=sg.gb_type_id
WHERE bg.gi_oc_id=@oc_id
) AS fd WHERE b_goodsinfo.gi_id=fd.gi_id
AND gi_class_id IN(
SELECT * FROM #b_goodsinfo_merge_p fd WITH (NOLOCK)   
)

END

--是否同步处理
PRINT '5'


merge into b_goodsruleset as ta
using (select * from b_goodsruleset_merge as so where so.gs_oc_id=@oc_id and so.gs_timestamp=@timestamp) as so 
on ta.gs_oc_id=so.gs_oc_id and ta.gs_type_id=so.gs_type_id  
when matched then update set ta.gss_no=so.gss_no,ta.gs_id=so.gs_id,ta.gs_name=so.gs_name,ta.gs_stock=so.gs_stock,ta.gs_salesprice=so.gs_salesprice,ta.gs_marketprice=so.gs_marketprice,ta.gs_costprice=so.gs_costprice,ta.gs_weight=so.gs_weight,ta.gs_upstock=so.gs_upstock,ta.gs_downstork=so.gs_downstork,ta.gs_alarmstock=so.gs_alarmstock,ta.gs_columnid=so.gs_columnid,ta.gs_purchase=so.gs_purchase,ta.gs_oc_id=so.gs_oc_id,ta.gs_updatetime=@now,ta.gs_type_id=so.gs_type_id,ta.gs_type_id_parentid=so.gs_type_id_parentid
when not matched then insert(gss_no,gs_id,gs_name,gs_stock,gs_salesprice,gs_marketprice,gs_costprice,gs_weight,gs_upstock,gs_downstork,gs_alarmstock,gs_columnid,gs_purchase,gs_oc_id,gs_addtime,gs_updatetime,gs_type_id,gs_type_id_parentid)values(so.gss_no,so.gs_id,so.gs_name,so.gs_stock,so.gs_salesprice,so.gs_marketprice,so.gs_costprice,so.gs_weight,so.gs_upstock,so.gs_downstork,so.gs_alarmstock,so.gs_columnid,so.gs_purchase,so.gs_oc_id,@now,@now,so.gs_type_id,so.gs_type_id_parentid);


SELECT so.gs_type_id INTO #b_goodsruleset_merge_p
  from b_goodsruleset_merge as so where so.gs_oc_id=@oc_id and so.gs_timestamp=@timestamp


update b_goodsruleset
set gi_id = (
	select bg.gi_id from b_goodsinfo as bg where bg.gi_oc_id=@oc_id and bg.gi_class_id=gs_type_id_parentid
),gs_status=1 where gs_oc_id=@oc_id AND gs_type_id IN(
SELECT * FROM #b_goodsruleset_merge_p fd WITH (NOLOCK)   
)

PRINT '6';


IF @do_other_table=0 OR @do_all=1
BEGIN
	
--处理规格id
IF 1=1
BEGIN

IF 1=2
BEGIN
	
	SELECT * FROM (
	SELECT ((LEN(fd.gs_id)-LEN(REPLACE(fd.gs_id,'/','')))+1) AS wd ,* FROM b_goodsruleset fd WITH (NOLOCK)   WHERE fd.gs_oc_id=@oc_id
	) AS fd ORDER BY wd DESC

	SELECT fd.gss_id,fd.gs_name,fd.gs_id
                            FROM b_goodsruleset fd WITH (NOLOCK) WHERE fd.gss_id=2764
           
           SELECT * FROM b_goodsruleset fd WITH (NOLOCK)  WHERE CHARINDEX('/',gs_id)!=0  
                            
          SELECT * FROM b_goodsruleset fd WITH (NOLOCK)  WHERE CHARINDEX('error',gs_id)!=0  
           
       SELECT SUBSTRING('/6-736/9-935',1,1)
       SELECT SUBSTRING('/6-736/9-935',2,LEN('/6-736/9-935'))
         
 --SELECT * FROM b_goodsruleset_merge bgm

--SELECT * FROM b_goodsruleset fd WITH (NOLOCK)   

       SELECT DISTINCT fd.gi_oc_id,fd.gi_addtime
         FROM b_goodsinfo  fd WITH (NOLOCK)   

     SELECT DISTINCT fd.gi_oc_id,fd.gi_timestamp FROM b_goodsinfo_merge fd

--DELETE FROM b_goodsinfo
--DELETE FROM b_goodsruleset
--DELETE FROM s_goodsbrand
--DELETE FROM s_goodsclass
--DELETE FROM s_goodsrule
--DELETE FROM s_goodsruledetail

        EXEC pro_merge_goods
        	@oc_id = 22,
        	@timestamp = '2016-07-25 09:15:53.590',
        	@result = 0   
          
        
          
          SELECT gd_type_id,count(1) as count from s_goodsruledetail_merge as so where so.gd_oc_id=22 and so.gd_timestamp='2016-07-25 09:15:53.590'
          GROUP BY gd_type_id ORDER BY count(1) DESC
          
          
          
          
            SELECT gd_type_id,count(1) as count from s_goodsruledetail_merge as so where so.gd_oc_id=22 and so.gd_timestamp='2016-07-18 16:45:31.873'
          GROUP BY gd_type_id ORDER BY count(1) DESC
          
      
         SELECT * FROM s_goodsruledetail_merge fd WITH (NOLOCK)  WHERE fd.gd_timestamp='2016-07-25 10:04:53.787' 
  
          
          
          
          SELECT * FROM s_goodsruledetail fd WITH (NOLOCK)   


                                        
END

DECLARE @gss_id INT=0;
DECLARE @gs_name VARCHAR(MAX)='';
DECLARE @tt_gs_id VARCHAR(MAX)='';

DECLARE sopcor CURSOR FOR(SELECT fd.gss_id,fd.gs_name,fd.gs_id
                            FROM b_goodsruleset fd WITH (NOLOCK) WHERE fd.gs_oc_id=@oc_id
                            AND fd.gs_type_id IN(
                            SELECT * FROM #b_goodsruleset_merge_p fd WITH (NOLOCK) 	
                            )
                          --WHERE fd.gss_id=2764 
                       )
OPEN sopcor
FETCH NEXT FROM sopcor INTO @gss_id,@gs_name,@tt_gs_id
		WHILE @@FETCH_STATUS =0
		BEGIN
		DECLARE @is_success INT=1;	
			
		--为空的情况
		SET @gs_name=lTRIM(RTRIM(@gs_name));
		IF @gs_name=''
		BEGIN
			
			SET @result_var='b_goodsruleset gs_name空值';
			GOTO lable_error;
			
			SET @is_success=0;
			UPDATE b_goodsruleset SET gs_id = 'error空值' where gss_id=@gss_id;
			FETCH NEXT FROM sopcor INTO @gss_id,@gs_name,@tt_gs_id
			CONTINUE;
		END	
			
		DECLARE @times INT=0;	
		SELECT @times=(LEN(@gs_name)-len(replace(@gs_name,'|','')));
		SET @times=@times+1;
		
		DECLARE @gs_id_real VARCHAR(MAX)='';
		DECLARE @temp_var VARCHAR(MAX)='';
		DECLARE @big VARCHAR(MAX)='';
		DECLARE @small VARCHAR(MAX)='';
		DECLARE @big_id INT;
		DECLARE @small_id INT;
		SET @sint=1;
		
		WHILE @sint<=@times
		BEGIN
			DECLARE @cc_gs_id VARCHAR(5000)='';
			SELECT @temp_var=dbo.Get_StrArrayStrOfIndex(@gs_name,'|',@sint);
			SELECT @cc_gs_id=dbo.Get_StrArrayStrOfIndex(@tt_gs_id,'|',@sint);
			SET @cc_gs_id=ISNULL(@cc_gs_id,'');
			SELECT @big=dbo.Get_StrArrayStrOfIndex(@temp_var,':',1);
			SELECT @small=dbo.Get_StrArrayStrOfIndex(@temp_var,':',2);
			
			SET @big_id=NULL;
			SELECT TOP 1 @big_id=gs_id
			  FROM s_goodsrule
			   WHERE gs_name=@big AND gs_status=1;
			   
			IF @cc_gs_id!=''
			BEGIN
				--第一个是大类id
				SET @big_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@cc_gs_id,',',1));
				SELECT @big_id=sg.gs_id
				  FROM s_goodsrule sg WHERE sg.gs_class_id=@big_id;
			END
			
			
			
			IF ISNULL(@big_id,0)=0
			BEGIN
				
				IF 1=1
				BEGIN
					INSERT INTO s_goodsrule
					(
						gs_name,
						gs_sort,
						gs_remark,
						gs_addtime,
						gs_updatetime,
						gs_status,
						gs_cp_id,gs_oc_id
					)
					VALUES
					(
						@big,
						0,
						'尺码',
						GETDATE(),
						GETDATE(),
						1,
						@cp_id,@oc_id
					)
					SET @big_id=SCOPE_IDENTITY();
				END
				ELSE
				BEGIN
				
				--没找到,完善处理
				SET @is_success=0;
				BREAK;
					
				END
			END
			IF @is_success=0
			BEGIN
				SET @result_var='@is_success=0';
				GOTO lable_error;
				BREAK;
			END
			
			
			
				SET @small_id=NULL;
				SELECT TOP 1 @small_id=sgat.gd_id
				  FROM s_goodsruledetail sgat WHERE sgat.gs_id=@big_id AND sgat.gd_name=@small;
				  
				  
				IF @cc_gs_id!=''
				BEGIN
				--第六是小类id
				SET @small_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@cc_gs_id,',',6));
				
				SELECT @small_id=sg.gd_id
				  FROM s_goodsruledetail sg WHERE sg.gd_type_id=@small_id
				
				END
				
				IF ISNULL(@small_id,0)=0
				BEGIN
					
					IF 1=1
					BEGIN
						INSERT INTO s_goodsruledetail
						(
							gs_id,
							gd_name,
							dg_sort,
							gd_code,
							gd_cp_id,gd_oc_id
						)
						VALUES
						(
							@big_id,
							@small,
							0,
							(SELECT isnull(count(1),0)+1 FROM s_goodsruledetail sg WHERE sg.gs_id=@big_id),
							@cp_id,@oc_id
						)
						SET @small_id=SCOPE_IDENTITY();
					END
					ELSE
					BEGIN
					
					--没找到,完善处理
					SET @is_success=0;
					BREAK;
						
					END
				END
				IF @is_success=0
				BEGIN
				SET @result_var='@is_success=0';
				GOTO lable_error;
				BREAK;
				END

					SET @gs_id_real=@gs_id_real+'/'+CONVERT(VARCHAR(50),@big_id)+'-'+CONVERT(VARCHAR(50),@small_id);
			SET @sint=@sint+1;
		END
		
		IF @is_success=1
		BEGIN
			IF ( SUBSTRING(@gs_id_real,1,1)='/')
			BEGIN
				  SELECT @gs_id_real=SUBSTRING(@gs_id_real,2,LEN(@gs_id_real))
			END
			
			UPDATE b_goodsruleset
			SET gs_id = @gs_id_real WHERE gss_id=@gss_id;
		END
		ELSE
		BEGIN
			
			SET @result_var='@is_success=0 error存在没找到';
			GOTO lable_error;
			
			UPDATE b_goodsruleset
			SET gs_id = 'error存在没找到' WHERE gss_id=@gss_id;
		END
		FETCH NEXT FROM sopcor INTO @gss_id,@gs_name,@tt_gs_id
		End
CLOSE sopcor
DEALLOCATE sopcor

END

--对比gi_norm gi_skus,gi_skuid
IF 1=1
BEGIN
if 1=2
BEGIN
SELECT bg.gi_norm,bg.gi_skus FROM b_goodsinfo bg WHERE bg.gi_id=31831
SELECT * FROM b_goodsruleset bg WHERE bg.gi_id=31831




SELECT * FROM gid_dd fd WITH (NOLOCK)   


SELECT * FROM api_dockingconfig_tbl fd WITH (NOLOCK)   


--UPDATE api_dockingconfig_tbl SET doco_number = 0
--UPDATE api_dockingconfig_tbl SET doco_code  = 'goodsinfo' WHERE doco_code='goods'



SELECT fd.*,bg.gi_norm,bg.gi_skus
,bg.gi_addtime
 FROM gid_dd fd WITH (NOLOCK)   
INNER JOIN b_goodsinfo bg ON bg.gi_id=fd.gid
ORDER BY bg.gi_addtime




SELECT * FROM b_goodsruleset bg WHERE bg.gi_id=2628

SELECT bg.gi_skus,bg.gi_norm FROM b_goodsinfo bg WHERE bg.gi_id=2628


SELECT * FROM gid_dd fd WITH (NOLOCK)   
--DELETE FROM gid_dd

SELECT SUBSTRING(bg.gi_skus,LEN(bg.gi_skus),1) AS 'cc', bg.gi_norm,bg.gi_skus FROM b_goodsinfo bg WHERE bg.gi_id=2495
--2495
--21595,21590	颜色:咖啡|辅品:均码



SELECT fd.gi_norm,fd.gi_skus,fd.gi_skuid
  FROM b_goodsinfo fd WITH (NOLOCK)   




UPDATE b_goodsinfo
SET gi_norm = gd.norm,gi_skus = gd.skus,gi_skuid =gd.gi_skuid
FROM b_goodsinfo bg,gid_dd gd
WHERE bg.gi_id=gd.gid



--DELETE FROM gid_dd


SELECT count(1) as count FROM b_goodsinfo fd WITH (NOLOCK)   
SELECT count(1) as count FROM gid_dd fd WITH (NOLOCK)   

	
SELECT * FROM b_goodsruleset bg
INNER JOIN s_goodsrule sg ON bg.gs_is_custom=sg.gs_id
AND sg.gs_remark!='尺码'
end


DECLARE @guid VARCHAR(200)='';
SELECT @guid=NEWID();
--SELECT @guid
--DELETE FROM gid_dd
DECLARE @gi_id INT = 0;
DECLARE sopcor CURSOR  
FOR
    (
        SELECT bg.gi_id
        FROM   b_goodsinfo bg 
        WITH (NOLOCK)  
        WHERE 
        --bg.gi_status=1 
        --AND 
        bg.gi_oc_id=@oc_id
        AND bg.gi_class_id IN(
       SELECT * FROM #b_goodsinfo_merge_p fd WITH (NOLOCK) 
        )
		--AND bg.gi_id=3688
        --WHERE bg.gi_code='66MN8875'
    )

OPEN sopcor
FETCH NEXT FROM sopcor INTO @gi_id
WHILE @@FETCH_STATUS = 0
BEGIN
    IF EXISTS(
           SELECT bg.gss_id
           FROM   b_goodsruleset bg
           WHERE  bg.gi_id = @gi_id
                  --AND bg.gs_is_custom > 0
       )
    BEGIN
        DECLARE @gi_norm VARCHAR(MAX) = '';
        DECLARE @gi_skus VARCHAR(MAX) = '';
        DECLARE @gi_skuid VARCHAR(MAX) = '';
        DECLARE @eint INT=0;
        SELECT TOP 1 @eint= ((LEN(fd.gs_id)-LEN(REPLACE(fd.gs_id,'/','')))+1)   FROM b_goodsruleset fd WITH (NOLOCK) WHERE fd.gi_id=@gi_id;   
        --SELECT @sint=0;
        SET @sint=0;
        WHILE @sint<@eint
        BEGIN
        	
        	SELECT @gi_skuid += fstr_id + ','
			FROM (
        	SELECT TOP 10000 * FROM (
                   SELECT DISTINCT fd.fstr_id
                   FROM   (
                              SELECT dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',@sint+1),'-',1)AS fstr_id FROM b_goodsruleset 
                              bg WHERE bg.gi_id=@gi_id
                              --AND bg.gs_is_custom!=0
                          ) AS fd
        	) AS fd ORDER BY fd.fstr_id
            ) AS fd WHERE fstr_id!='' 
            AND fstr_id IS NOT NULL
            
        	
        	SELECT @gi_norm += fstr_id + ','
			FROM (
        	SELECT TOP 10000 * FROM (
                   SELECT DISTINCT fd.fstr_id
                   FROM   (
                              SELECT dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',@sint+1),'-',2)AS fstr_id FROM b_goodsruleset 
                              bg WHERE bg.gi_id=@gi_id
                              --AND bg.gs_is_custom!=0
                          ) AS fd
        	) AS fd ORDER BY fd.fstr_id
            ) AS fd WHERE fstr_id!='' 
            AND fstr_id IS NOT NULL
            
           SELECT @gi_skus += fstr + '|'
		   FROM   (
        	SELECT TOP 10000 * FROM (
                   SELECT DISTINCT fd.fstr,fd.fstr_id
                   FROM   (
                   	
                   	
                              SELECT dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',@sint+1),'-',2)AS fstr_id,dbo.Get_StrArrayStrOfIndex(bg.gs_name,'|',@sint+1)AS fstr FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id 
                              --AND bg.gs_is_custom!=0
                          ) AS fd
        	) AS fd ORDER BY fd.fstr_id      
            ) AS fd WHERE fstr!='' AND  fstr IS NOT NULL
        	SET @sint=@sint+1;
        END
        SET @gi_norm=lTRIM(RTRIM(@gi_norm));
        SET @gi_norm=SUBSTRING(@gi_norm,0,LEN(@gi_norm));  

		SET @gi_skuid=lTRIM(RTRIM(@gi_skuid));
        SET @gi_skuid=SUBSTRING(@gi_skuid,0,LEN(@gi_skuid));  
        
        SET @gi_skus=lTRIM(RTRIM(@gi_skus));
        SET @gi_skus=SUBSTRING(@gi_skus,0,LEN(@gi_skus));
                  
                    --SELECT @gi_norm;
                  	--SELECT @gi_skus;
                  	--SELECT @gi_id;
                  IF EXISTS(
                  SELECT bg.gi_id FROM b_goodsinfo bg WHERE bg.gi_id=@gi_id
                  AND (isnull(bg.gi_norm,'')!=@gi_norm OR isnull(bg.gi_skus,'')!=@gi_skus OR isnull(bg.gi_skuid,'')!=@gi_skuid )
                  )
                  BEGIN
                  	
                  	--SELECT @gi_norm;
                  	--SELECT @gi_skus;
                  	--SELECT @gi_id;
                  	INSERT INTO gid_dd (gid, norm, skus, gi_skuid, [guid])VALUES (@gi_id,@gi_norm,@gi_skus,@gi_skuid,@guid);
                  END
    END
    FETCH NEXT FROM sopcor INTO @gi_id
END
CLOSE sopcor
DEALLOCATE sopcor;

IF EXISTS(SELECT * FROM gid_dd WHERE [guid]=@guid)
BEGIN
UPDATE b_goodsinfo
SET gi_norm = gd.norm,gi_skus = gd.skus,gi_skuid =gd.gi_skuid
FROM b_goodsinfo bg,gid_dd gd
WHERE bg.gi_id=gd.gid AND gd.[guid]=@guid
END
END

END


--处理单位
IF EXISTS(
SELECT * FROM b_unit bu WHERE bu.ut_status=1
AND bu.ut_cp_id=@cp_id
)
BEGIN
	DECLARE @gi_unit INT=0;
	--第一个
	SELECT TOP 1 @gi_unit=bu.ut_id 
	FROM b_unit bu WHERE bu.ut_status=1
	UPDATE b_goodsinfo
	SET gi_unit = @gi_unit
	WHERE gi_oc_id=@oc_id
AND gi_class_id IN(

SELECT * FROM #b_goodsinfo_merge_p fd WITH (NOLOCK)  
	
)
END
ELSE
BEGIN
	SET @result_var='没有单位';
	PRINT '没有单位!'
	GOTO lable_error;
END



IF @do_other_table=0 OR @do_all=1
BEGIN
	
--处理横排显示列 两个都是规格,取第一个
IF 1=1
BEGIN
UPDATE b_goodsruleset 
SET gs_is_custom = NULL,gs_columnid = NULL
WHERE gs_oc_id=@oc_id
AND gs_type_id IN(
SELECT * FROM #b_goodsruleset_merge_p fd WITH (NOLOCK)   
)

UPDATE b_goodsruleset 
SET gs_is_custom=fd.real_gs_is_custom,gs_columnid=fd.real_gs_is_custom
FROM b_goodsruleset,(
SELECT *,CASE WHEN lTRIM(RTRIM(fd.one_gs_remark))='颜色' then fd.two when lTRIM(RTRIM(fd.two_gs_remark))='颜色' then fd.one else fd.one end as real_gs_is_custom
 FROM (
SELECT *,(SELECT sg.gs_remark FROM s_goodsrule sg WHERE sg.gs_id=one) AS one_gs_remark,(SELECT sg.gs_remark FROM s_goodsrule sg WHERE sg.gs_id=two) AS two_gs_remark FROM (
SELECT fd.gi_id,fd2.gi_skuid,dbo.Get_StrArrayStrOfIndex(fd2.gi_skuid,',',1) AS one,dbo.Get_StrArrayStrOfIndex(fd2.gi_skuid,',',2) AS two FROM (
SELECT DISTINCT fd.gi_id FROM b_goodsruleset fd
WHERE fd.gs_oc_id=@oc_id

) AS fd INNER JOIN b_goodsinfo fd2 ON fd.gi_id=fd2.gi_id
AND (LEN(fd2.gi_skuid)-LEN(REPLACE(fd2.gi_skuid,',','')))=1
) AS fd 
) AS fd
) AS fd WHERE fd.gi_id=b_goodsruleset.gi_id
AND b_goodsruleset.gs_oc_id=@oc_id AND b_goodsruleset.gs_type_id IN(
SELECT * FROM #b_goodsruleset_merge_p fd WITH (NOLOCK)   
)

END

END


UPDATE b_goodsruleset SET gs_addtime = NULL,gs_updatetime = NULL WHERE gs_oc_id=@oc_id
AND gs_type_id IN(
SELECT * FROM #b_goodsruleset_merge_p fd WITH (NOLOCK)  	
)

IF @do_other_table=1 OR @do_all=1
BEGIN
	
--商品表的分类字段处理
DECLARE @type_gi_id INT=0;
DECLARE @type_gi_typesid VARCHAR(MAX)='';
DECLARE sopcor CURSOR FOR(SELECT bg.gi_id,bg.gi_typesid FROM b_goodsinfo bg
WHERE bg.gi_oc_id=@oc_id
AND gi_class_id IN(
SELECT * FROM #b_goodsinfo_merge_p fd WITH (NOLOCK)   
)


)
OPEN sopcor
FETCH NEXT FROM sopcor INTO @type_gi_id,@type_gi_typesid
		WHILE @@FETCH_STATUS =0
		begin
		DECLARE @real_gi_typesid VARCHAR(MAX)='';
		DECLARE @t_id VARCHAR(50)='';
		SET @sint=1;
		--DECLARE @sint INT=1;
		--DECLARE @eint INT=5;
		SELECT @eint=((LEN(@type_gi_typesid)-LEN(REPLACE(@type_gi_typesid,',',''))+1))
		WHILE @sint<=@eint
		BEGIN
		
			SET @t_id=dbo.Get_StrArrayStrOfIndex(@type_gi_typesid,',',@sint);
			IF @t_id!=''
			BEGIN
				SELECT @real_gi_typesid=@real_gi_typesid+CONVERT(VARCHAR(50),sg.gc_id)+','
				  FROM s_goodsclass sg WHERE sg.gc_type_id=@t_id;
			END
			SET @sint=@sint+1;
		END
		
		IF @real_gi_typesid!='' AND @real_gi_typesid!=','
		BEGIN
		
		SELECT @real_gi_typesid=SUBSTRING(@real_gi_typesid,0,LEN(@real_gi_typesid));
		UPDATE b_goodsinfo SET gi_typesid =@real_gi_typesid WHERE gi_id=@type_gi_id
			
		END
		FETCH NEXT FROM sopcor INTO @type_gi_id,@type_gi_typesid
		End
CLOSE sopcor
DEALLOCATE sopcor

END



IF OBJECT_ID('tempdb..#b_goodsinfo_merge_p') is NOT NULL
	    		BEGIN
UPDATE b_goodsinfo SET gi_cp_id = @cp_id,gi_erp_id = @erp_id
WHERE gi_oc_id =@oc_id
AND gi_class_id IN(
SELECT * FROM #b_goodsinfo_merge_p fd WITH (NOLOCK)   
)
	END

IF OBJECT_ID('tempdb..#b_goodsruleset_merge_p') is NOT NULL
	    		BEGIN
UPDATE b_goodsruleset SET gss_cp_id  = @cp_id,gss_erp_id=@erp_id
WHERE gss_cp_id =@oc_id
AND gs_type_id IN(
SELECT * FROM #b_goodsruleset_merge_p fd WITH (NOLOCK)   
)
	    		END
	    		
	    		
IF OBJECT_ID('tempdb..#s_goodsbrand_merge_p') is NOT NULL
	    		BEGIN
UPDATE s_goodsbrand SET gb_cp_id = @cp_id,gb_erp_id =@erp_id
WHERE gb_oc_id =@oc_id
AND gb_type_id IN(
	SELECT * FROM #s_goodsbrand_merge_p fd WITH (NOLOCK)   
)

END

	    		
IF OBJECT_ID('tempdb..#s_goodsclass_merge_p') is NOT NULL
	    		BEGIN
UPDATE s_goodsclass SET gc_cp_id  = @cp_id,gc_erp_id =@erp_id
WHERE gc_oc_id =@oc_id
AND gc_type_id IN(
SELECT * FROM #s_goodsclass_merge_p fd WITH (NOLOCK)   
)
END

	    		
IF OBJECT_ID('tempdb..#s_goodsrule_merge_p') is NOT NULL
	    		BEGIN
UPDATE s_goodsrule SET gs_cp_id  = @cp_id,gs_erp_id = @erp_id
WHERE gs_oc_id =@oc_id
AND gs_class_id IN(
SELECT * FROM #s_goodsrule_merge_p fd WITH (NOLOCK)   
)
END

IF OBJECT_ID('tempdb..#s_goodsruledetail_merge_p') is NOT NULL
	    		BEGIN
UPDATE s_goodsruledetail SET gd_cp_id = @cp_id,gd_erp_id = @erp_id 
WHERE gd_oc_id =@oc_id
AND gd_type_id IN(
SELECT * FROM #s_goodsruledetail_merge_p fd WITH (NOLOCK)   
)
END


	
END TRY
BEGIN CATCH
	SET @all_success=0
	SELECT
			ERROR_NUMBER() AS ErrorNumber,
			ERROR_SEVERITY() AS ErrorSeverity,
			ERROR_STATE() AS ErrorState,
			ERROR_PROCEDURE() AS ErrorProcedure,
			ERROR_LINE() AS ErrorLine,
			ERROR_MESSAGE() AS ErrorMessage
END CATCH

if @all_success=0
BEGIN
	set @result=0;

	IF @@TRANCOUNT > 0 rollback TRAN;
	RETURN;
end
else
BEGIN
	set @result=1;
	PRINT '成功';
	IF @@TRANCOUNT > 0 commit TRAN
	RETURN;
END
lable_error:
 RAISERROR (
        @result_var,	
        16,	
        1,	
        N'number',	
        5 
);
RETURN;
go

