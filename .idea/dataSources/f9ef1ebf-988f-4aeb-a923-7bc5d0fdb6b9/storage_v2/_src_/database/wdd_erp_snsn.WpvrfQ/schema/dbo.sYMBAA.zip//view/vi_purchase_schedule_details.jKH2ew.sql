
CREATE VIEW [dbo].[vi_purchase_schedule_details]
	AS 
	
	--采购进度查询明细表

select 
ep.ap_id,
CONVERT(varchar(100),ep.ap_date, 23)ap_date,
ep.ap_cp_id,
(SELECT cp_name FROM dbo.companyinfo WHERE cp_id = ep.ap_cp_id) AS ap_cp_name,
ep.ap_addman,
(SELECT si_name FROM dbo.b_stafftinfo WHERE si_id = ep.ap_addman) AS ap_addman_manc,
ep.ap_fundsno,
ep.ap_num,
ep.ap_price,
ep.ap_purpose,
ep.ap_audittime,
ep.ap_status,
ep.ap_plan_indate,--预计入库日期
ep.ap_plan_ondate,--预计上架时间
ep.ap_erp_id,
t.gi_id,
t.eo_no,
t.eo_auditdate,
t.oo_no,
t.oo_auditdate,
t.in_vo,
t.in_add_time,--上架日期
t.el_money_sum,--实际入库金额
t.el_num_sum ,--入库数量,
t.ol_money_sum,--实际出库金额
t.ol_num_sum--实际出库数量
,bg.gi_types
,bg.gi_typename1,bg.gi_typename2,bg.gi_typename3,bg.gi_typename4
,bg.gi_code
,bg.gi_name
,bg.gi_barcode,
(case when rk_hh > 0 then  CEILING(cast(rk_hh as float)/24) when rk_hh <=0 then 0 end )rk_days,--入库超时天数

(case when sj_hh > 0 then  CEILING(cast(sj_hh as float)/24) when sj_hh <=0 then 0 end )sj_days,--上架超时天数
(cast( rk_fine as decimal(18,2))+cast(sj_fine as decimal(18,2) ))fine,--罚金
(case when ol_num_sum <= si_number then el_num_sum when ol_num_sum >si_number then (el_num_sum+si_number-ol_num_sum) end) stock_num,--剩余库存
(select top 1 si_name from j_purchaseStorage  jp inner join  j_purchaseStoragelist jpl on jp.pl_id=jpl.pll_pl_id and pl_status>0
inner join b_supplierinfo bp on bp.si_id=jp.pl_ci_id  where pl_no=ep.ap_fundsno and pl_erp_id=ep.ap_erp_id and pll_gi_id=t.gi_id  order by pl_add_time asc)supplier--供应商

 from

(
select 
ap_id,
ap_date,
ap_cp_id,
ap_addman,
ap_fundsno,
ap_num,
ap_price,
ap_purpose,
ap_audittime,
ap_status,
ap_plan_indate,--预计入库日期
ap_plan_ondate,--预计上架时间
ap_erp_id,
gi_id,
max(eo_no)eo_no,
max(eo_auditdate)eo_auditdate,
max(oo_no)oo_no,
max(oo_auditdate)oo_auditdate,
max(in_vo)in_vo,
max(in_add_time)in_add_time,--上架日期
sum(el_realmoney)el_money_sum,--实际入库金额
sum(el_number)el_num_sum ,--入库数量,
sum(ol_realmoney)ol_money_sum,--实际出库金额
sum(ol_number)ol_num_sum,--实际出库数量
(
 SELECT SUM( CASE WHEN js.sl_counttype = 1 THEN js.sl_number ELSE -js.sl_number END )
FROM   j_stocklog AS js
WHERE 
 (( CONVERT(VARCHAR(50), js.sl_order_date, 23) <= DATEADD(dd,-1,max(eo_auditdate)) )OR js.sl_type = 3)
 AND
 js.sl_status > 0
 AND js.sl_giid = gi_id and js.sl_erp_id=ap_erp_id
 
 )si_number,--入库前一天的日期库存
  DATEDIFF (hh ,ap_plan_indate , max(eo_auditdate) )rk_hh, --入库超时(小时)
 DATEDIFF (hh ,ap_plan_ondate , max(in_add_time) )sj_hh, --上架超时(小时),
 (case when  DATEDIFF (hh ,ap_plan_indate , max(eo_auditdate) )>0
 then (select cast(s_othervalue as decimal(18,2)) as rk_fine from s_system_set where s_erp_id=ap_erp_id and s_key='rk_fine') else 0
 end
 )rk_fine,--入库超时罚金
 (case when DATEDIFF (hh ,ap_plan_ondate , max(in_add_time) )>0
 then (select cast(s_othervalue as  decimal(18,2)) as rk_fine from s_system_set where s_erp_id=ap_erp_id and s_key='sj_fine') else 0
 end
 )sj_fine --上架超时罚金
 from

(
SELECT T.* 

FROM(

SELECT ap_id , 
       ap_date , 
       ap_cp_id , 
       ap_addman , 
       ap_fundsno , 
       ap_num , 
       ap_price , 
       ap_purpose , 
       ap_audittime , 
       ap_status , 
       ap_plan_indate , 
       ap_plan_ondate,
	  ap_erp_id,
	  '' as eo_no,--入库凭证号(首单)
	  null as eo_auditdate,--审核时间(入库时间)
	  min(oo_no)oo_no,--出库凭证号(首单)
       min(oo_auditdate)oo_auditdate,--审核时间(出库时间)
	  '' as in_vo,--上架凭证号(首单)
	  null as in_add_time,--添加时间(上架时间)
	  null as el_realmoney,--实际入库金额
	  null as el_number,--入库数量,
	  sum(ol_realmoney)ol_realmoney,--实际出库金额
	 sum(jol.ol_number)ol_number,--出库数量,
	  ol_siid AS gi_id
	  
  FROM
       erp_fundsapply ef LEFT JOIN j_outStorage jo
       ON ef.ap_fundsno
          = 
          jo.oo_manual
		and jo.oo_status=2
      AND ef.ap_erp_id
          = 
          jo.oo_erp_id

		inner join
		j_outStorageList jol on jol.ol_eoid=jo.oo_id
	 
		and jol.ol_status=1


  GROUP BY ap_id , 
           ap_date , 
           ap_cp_id , 
           ap_addman , 
           ap_fundsno , 
           ap_num , 
           ap_price , 
           ap_purpose , 
           ap_audittime , 
           ap_status , 
           ap_plan_indate , 
           ap_plan_ondate,
		 ap_erp_id,
		 ol_siid 
		
union all


SELECT ap_id , 
       ap_date , 
       ap_cp_id , 
       ap_addman , 
       ap_fundsno , 
       ap_num , 
       ap_price , 
       ap_purpose , 
       ap_audittime , 
       ap_status , 
       ap_plan_indate , 
       ap_plan_ondate,
	  ap_erp_id,
	  min(eo_no)no,--入库凭证号(首单)
	  min(eo_auditdate)eo_auditdate,--审核时间(入库时间)
	  '' as oo_no,--出库凭证号(首单)
       null as oo_auditdate,--审核时间(出库时间)
	  '' as in_vo,--上架凭证号(首单)
	  null as in_add_time,--添加时间(上架时间)
	  sum(el_realmoney)el_realmoney,--实际入库金额
	 sum(jsl.el_number)el_number,--入库数量
	  null as ol_realmoney,--实际出库金额
	  null as ol_number,--出库数量,
	  el_siid as gi_id
	
	  
  FROM
       erp_fundsapply ef LEFT JOIN j_enterStorage js
       ON ef.ap_fundsno
          = 
          js.eo_manual
		and js.eo_status=2
      AND ef.ap_erp_id
          = 
          js.eo_erp_id

		inner join
		j_enterStorageList jsl on jsl.el_eoid=js.eo_id
		and jsl.el_status=1

  GROUP BY ap_id , 
           ap_date , 
           ap_cp_id , 
           ap_addman , 
           ap_fundsno , 
           ap_num , 
           ap_price , 
           ap_purpose , 
           ap_audittime , 
           ap_status , 
           ap_plan_indate , 
           ap_plan_ondate,
		 ap_erp_id,
		 el_siid
	
union all

SELECT ap_id , 
       ap_date , 
       ap_cp_id , 
       ap_addman , 
       ap_fundsno , 
       ap_num , 
       ap_price , 
       ap_purpose , 
       ap_audittime , 
       ap_status , 
       ap_plan_indate , 
       ap_plan_ondate,
	  ap_erp_id,
	  '' as eo_no,--入库凭证号(首单)
	  null as eo_auditdate,--审核时间(入库时间)
	  '' as oo_no,--出库凭证号(首单)
       null as oo_auditdate,--审核时间(出库时间)
	  min(in_vo)no,--上架库凭证号(首单)
	  min(in_add_time)in_add_time,--审核时间(入库时间)
	  null as el_realmoney,--实际入库金额
	  null as el_number,--入库数量,
	  null as ol_realmoney,--实际出库金额
	  null as ol_number,--出库数量,

	  inl_gi_id as gi_id
  FROM
       erp_fundsapply ef
     LEFT JOIN Pos_InStorage ps ON ps.in_erp_id = ef.ap_erp_id AND ef.ap_fundsno
          =  ps.in_no and ps.in_status>0 inner join  Pos_InStoragelist psl on psl.inl_in_id=ps.in_id and psl.inl_status>0


   
  GROUP BY ap_id , 
           ap_date , 
           ap_cp_id , 
           ap_addman , 
           ap_fundsno , 
           ap_num , 
           ap_price , 
           ap_purpose , 
           ap_audittime , 
           ap_status , 
           ap_plan_indate , 
           ap_plan_ondate,
		 ap_erp_id,
		 inl_gi_id
	




)AS T
) as tt


GROUP by
ap_id,
ap_date,
ap_cp_id,
ap_addman,
ap_fundsno,
ap_num,
ap_price,
ap_purpose,
ap_audittime,
ap_status,
ap_plan_indate,
ap_plan_ondate,
ap_erp_id,
gi_id
)as t  inner join v_goodsinfo bg on bg.gi_id=t.gi_id  right join  erp_fundsapply ep on ep.ap_erp_id=t.ap_erp_id and ep.ap_fundsno=t.ap_fundsno

where ep.ap_status>0
go

