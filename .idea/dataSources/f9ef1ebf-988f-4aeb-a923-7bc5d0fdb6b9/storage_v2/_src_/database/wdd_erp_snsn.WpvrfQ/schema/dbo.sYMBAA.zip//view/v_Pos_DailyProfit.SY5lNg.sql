CREATE VIEW [dbo].[v_Pos_DailyProfit]
	AS 

SELECT *,
       (paidmomey-costmoney-feemomey-commomey-salary)profit,
       (SELECT sh_name FROM pos_shop WHERE sh_id=sa_sh_id)sh_name
FROM(
SELECT sar_erp_id sa_erp_id,sar_sh_id sa_sh_id,CONVERT(varchar(100), sar_date, 23)sa_date,--sa_erp_id,sa_sh_id,CONVERT(varchar(100), sa_date, 23)sa_date,
       SUM((CASE WHEN sa_type='销售实收金额' then sal_paidmomey else 0 end))paidmomey,
       SUM((CASE WHEN sa_type='销售成本金额' then sal_paidmomey else 0 end))costmoney,
       SUM((CASE WHEN sa_type='费用' then sal_paidmomey else 0 end))feemomey,
       SUM((CASE WHEN sa_type='提成' then sal_paidmomey else 0 end))commomey,
       (SELECT cast(isnull(SUM(si_salary),0)/
                           day(dateadd(ms,-3,DATEADD(m, DATEDIFF(m,0,sar_date)+1,0))) AS DECIMAL(18,2))si_salary
		FROM b_stafftinfo 
		WHERE si_isdel=1 and si_erp_id=sar_erp_id AND si_shop_id IS NOT NULL AND si_shop_id=sar_sh_id)salary  --基本工资
FROM

--以结算记录表为主表，以店铺和销售时间为依据，筛选添加事件最新的，且类型为结算
(SELECT sar_date,max(sar_add_time)sar_add_time, sar_sh_id,(SELECT sh_erp_id FROM pos_shop WHERE sh_id=sar_sh_id)sar_erp_id
FROM pos_sale_record a
WHERE (SELECT TOP 1 sar_type
	   FROM pos_sale_record b
	   WHERE b.sar_date=a.sar_date AND b.sar_sh_id=a.sar_sh_id
	   ORDER BY sar_id DESC )='结算'
GROUP BY sar_sh_id,sar_date)psr 

left join 

(
SELECT sa_erp_id,sa_sh_id,sa_date,
      (CASE WHEN sal_is_return = 1 OR sal_is_change = 1 THEN -ABS(sal_paidmomey)
            WHEN sal_is_gift = 1 OR sal_is_in = 1 THEN 0
            ELSE (sal_paidmomey)
       END)sal_paidmomey,
	   '销售实收金额'sa_type
FROM   pos_sale ps WITH (NOLOCK)
INNER JOIN pos_saleList psl WITH (NOLOCK) 
ON psl.sal_sa_id = ps.sa_id AND psl.sal_status = 1 AND ps.sa_status > 0 AND psl.sal_is_gift=0 AND psl.sal_is_in=0
--WHERE (SELECT TOP 1 sar_type
--	   FROM pos_sale_record
--	   WHERE sar_date=sa_date AND sar_sh_id=sa_sh_id
--	   ORDER BY sar_id DESC )='结算'

UNION ALL 

SELECT sa_erp_id,sa_sh_id,sa_date,
      (ISNULL(CASE WHEN psl.sal_is_return = 1 OR psl.sal_is_change = 1 THEN -ABS(sal_num)
                   ELSE sal_num END,0)*(CASE WHEN sal_sku_id>0 THEN (SELECT gs_costprice 
                                             FROM b_goodsruleset AS bg
                                             WHERE bg.gi_id=psl.sal_gi_id AND bg.gss_id=psl.sal_sku_id and bg.gs_status>0)
                     ELSE (SELECT gi_costprice 
                           FROM b_goodsinfo AS bg 
                           WHERE bg.gi_id=psl.sal_gi_id and bg.gi_status>0) END))sal_costmoney,'销售成本金额'sa_type 
FROM   pos_sale ps WITH (NOLOCK)
INNER JOIN pos_saleList psl WITH (NOLOCK) 
ON psl.sal_sa_id = ps.sa_id AND psl.sal_status = 1 AND ps.sa_status > 0
--WHERE (SELECT TOP 1 sar_type
--	   FROM pos_sale_record
--	   WHERE sar_date=sa_date AND sar_sh_id=sa_sh_id
--	   ORDER BY sar_id DESC )='结算'

UNION ALL 

SELECT fg_erp_id,fg_sh_id,fg_date,
      (CASE WHEN (SELECT ft_type FROM pos_fee_type WHERE ft_id=fg_ft_id)=1 THEN fg_money
            WHEN (SELECT ft_type FROM pos_fee_type WHERE ft_id=fg_ft_id)=2 THEN -fg_money ELSE 0 END)fg_money,
       '费用'sa_type 
FROM pos_feeregister
WHERE fg_isdel=0 --AND (SELECT TOP 1 sar_type
				      --FROM pos_sale_record
				      --WHERE sar_date=fg_date AND sar_sh_id=fg_sh_id
				      --ORDER BY sar_id DESC )='结算'

UNION ALL 

SELECT erp_id,sh_id,order_date,money,'提成'sa_type 
FROM erp_royaltyschemelog
WHERE status=1 AND sh_id>0 AND 
      si_id in (SELECT si_id FROM b_stafftinfo AS bs WHERE bs.si_id=si_id AND bs.si_shop_id=sh_id)
     -- AND (SELECT TOP 1 sar_type
	    --   FROM pos_sale_record
		   --WHERE sar_date=order_date AND sar_sh_id=sh_id
		   --ORDER BY sar_id DESC )='结算'
)T

on psr.sar_date=T.sa_date and psr.sar_sh_id=T.sa_sh_id

GROUP BY sar_erp_id,sar_sh_id,sar_date--sa_erp_id,sa_sh_id,sa_date
)TT
go

