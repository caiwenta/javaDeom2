CREATE VIEW [dbo].[vi_pos_initStorageList] AS 
select jt.inl_in_id,jt.inl_gi_id,jt.inl_add_time,sum(jt.inl_num) as 
 inl_num,
 min(jt.inl_id) as inl_id,
 max(jt.inl_sku_id) as inl_sku_id,
 sum(jt.inl_money) as inl_money,
 convert(decimal(10,2),avg(jt.inl_retail_price)) as inl_retail_price,
  convert(decimal(10,2),avg(jt.inl_discount)) as inl_discount
,convert(decimal(10,2),avg(jt.inl_stock_price)) as inl_stock_price

,max(replace(inl_pm,'*',',')) as inl_pm,max(inl_box_num) as  inl_box_num
from pos_initStorageList as jt where jt.inl_status=1
group by jt.inl_in_id,jt.inl_gi_id,jt.inl_add_time
go

