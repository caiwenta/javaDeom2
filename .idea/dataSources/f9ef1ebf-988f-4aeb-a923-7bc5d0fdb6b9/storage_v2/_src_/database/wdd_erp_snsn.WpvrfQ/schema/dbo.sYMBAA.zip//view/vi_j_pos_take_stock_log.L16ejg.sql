



CREATE VIEW [dbo].[vi_j_pos_take_stock_log] AS 
SELECT bs3.sei_sh_id,
       jt.tsl_id,
       CONVERT(VARCHAR(50),jt.tsl_date,23)tsl_date,
       jt.tsl_status,
       jt.tsl_type,
       jt.tsl_add_time,
       jt.tsl_update_time,
       jt.tsl_remark,
       bs.si_name                 AS tsl_add_man,
       bs2.si_name                AS tsl_update_man,
       bs3.sei_name               AS tsl_st_id,
	   jt.tsl_st_id               AS tsl_st_id_id
FROM   pos_takeStorageLog         AS jt
       LEFT JOIN b_stafftinfo     AS bs
            ON  jt.tsl_add_man = bs.si_id
       LEFT JOIN b_stafftinfo     AS bs2
            ON  jt.tsl_update_man = bs2.si_id
       INNER JOIN pos_storageInfo  AS bs3
            ON  jt.tsl_st_id = bs3.sei_id
go

