
CREATE PROCEDURE [dbo].[sysProcGetIndexProposal]
    @tableName VARCHAR(50) = ''
AS
    BEGIN
    -- =============================================
	-- Author:		<获取索引建议报告>
	-- Create date: <2015-07-27>
	-- sys.dm_db_missing_index_details:当前数据库下所有的missing index的信息,他针对的是SQLSERVER从启动以来所有运行的语句
	-- sys.dm_db_missing_index_columns:返回与缺少索引（不包括空间索引）的数据库表列有关的信息
	-- sys.dm_db_missing_index_groups:返回有关特定缺失索引组中包含的缺失索引（不包括空间索引）的信息
	-- sys.dm_db_missing_index_group_stats:返回缺失索引组的摘要信息，不包括空间索引
	-- index_handle:标识特定的缺失索引。该标识符在服务器中是唯一的。index_handle 是此表的密钥
	-- database_id :标识带有缺失索引的表所驻留的数据库
	-- object_id :标识索引缺失的表
	-- equality_columns:构成相等谓词的列的逗号分隔列表 即哪个字段缺失了索引会在这里列出来（简单来讲就是where 后面的筛选字段）
	--					谓词的形式如下：table.column =constant_value
	-- inequality_columns :构成不等谓词的列的逗号分隔列表
	--					   谓词的形式如下：table.column > constant_value “=”之外的任何比较运算符都表示不相等。
	-- included_columns:用于查询的涵盖列的逗号分隔列表（简单来讲就是 select 后面的字段）。
	-- statement:索引缺失的表的名称
	-- "Avg_User_Impact"：实现此缺失索引组后，用户查询可能获得的平均百分比收益
	-- =============================================
	
        IF @tableName = ''
            BEGIN
                SELECT  avg_user_impact AS "Avg_User_Impact" ,
                        avg_total_user_cost AS "Avg_Total_User_Cost" ,
                        c.last_user_seek AS "Last_User_Seek" ,
                        c.last_user_scan AS "Last_User_Scan" ,
                        c.user_seeks AS "User_Seek" ,
                        c.user_scans AS "User_Scan" ,
                        [statement] AS "Statement" ,
                        OBJECT_NAME(a.object_id) AS "Table_Name" ,
                        equality_columns AS "Equality_Columns" ,
                        inequality_columns AS "Inequality_Columns" ,
                        included_columns AS "Included_Columns" ,
                        'CREATE INDEX IX_' + OBJECT_NAME(a.object_id) + '_'
                        + ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(equality_columns,
                                                              '[', ''), ']',
                                                         ''), ',', '_'), ' ',
                                         ''), '')
                        + ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(inequality_columns,
                                                              '[', ''), ']',
                                                         ''), ',', '_'), ' ',
                                         ''), '') + ' ON ' + [statement]
                        + ' (' + ISNULL(equality_columns, ' ')
                        + ISNULL(inequality_columns, ' ') + ')'
                        + ISNULL(' INCLUDE (' + included_columns + ')', '') AS Create_Missing_Index_Command
                FROM    sys.dm_db_missing_index_details a
                        INNER JOIN sys.dm_db_missing_index_groups b ON a.index_handle = b.index_handle
                        INNER JOIN sys.dm_db_missing_index_group_stats c ON b.index_group_handle = c.group_handle
                WHERE   avg_user_impact > = 40
                ORDER BY "User_Seek" DESC
            END
        ELSE
            BEGIN
                SELECT  avg_user_impact AS "Avg_User_Impact" ,
                        avg_total_user_cost AS "Avg_Total_User_Cost" ,
                        c.last_user_seek AS "Last_User_Seek" ,
                        c.last_user_scan AS "Last_User_Scan" ,
                        c.user_seeks AS "User_Seek" ,
                        c.user_scans AS "User_Scan" ,
                        [statement] AS "Statement" ,
                        OBJECT_NAME(a.object_id) AS "Table_Name" ,
                        equality_columns AS "Equality_Columns" ,
                        inequality_columns AS "Inequality_Columns" ,
                        included_columns AS "Included_Columns" ,
                        'CREATE INDEX IX_' + OBJECT_NAME(a.object_id) + '_'
                        + ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(equality_columns,
                                                              '[', ''), ']',
                                                         ''), ',', '_'), ' ',
                                         ''), '')
                        + ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(inequality_columns,
                                                              '[', ''), ']',
                                                         ''), ',', '_'), ' ',
                                         ''), '') + ' ON ' + [statement]
                        + ' (' + ISNULL(equality_columns, ' ')
                        + ISNULL(inequality_columns, ' ') + ')'
                        + ISNULL(' INCLUDE (' + included_columns + ')', '') AS Create_Missing_Index_Command
                FROM    sys.dm_db_missing_index_details a
                        INNER JOIN sys.dm_db_missing_index_groups b ON a.index_handle = b.index_handle
                        INNER JOIN sys.dm_db_missing_index_group_stats c ON b.index_group_handle = c.group_handle
                WHERE   avg_user_impact > = 10
                        AND OBJECT_NAME(a.object_id) = @tableName
                ORDER BY "User_Seek" DESC
            END
    END
go

