Create View [dbo].[vi_fahuodan]
    As
Select mo.oi_id,mo.oi_no,mo.oi_realmoney,mo.oi_totalmoney,mo.oi_couponmoney,mo.si_name,mo.oi_delivery,mo.ci_name,mo.ci_linkman,mo.ci_phone,mo.oi_orderdate,mo.oi_pay,mo.oi_aendtype,mo.og_goodsid,mo.og_title,mo.gs_weight,mo.gs_name,mo.og_buynum,mo.og_actualprice,mo.totalmoney,mo.gi_unit,mo.gi_types From vi_m_orderinfo mo
go

