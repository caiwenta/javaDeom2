CREATE FUNCTION [dbo].[FuNetOrderOccupy]
(
    @type VARCHAR(50),--store  node
	@id INT = 0,
	@sid int=0
)
RETURNS @returntable TABLE
(
	ord_no VARCHAR(255),
	ord_id int,
	[sid] int,
	gi_id int,
	sku_id int,
	number int
)
AS
BEGIN
    DECLARE @out_id INT=0;
	IF @type = 'store'
            BEGIN	
                IF EXISTS ( SELECT  *
                            FROM    pos_storageInfo fd
                            WHERE   fd.sei_sh_id = @id
                                    AND fd.sei_is_net = 1 )
                    BEGIN
                        SELECT TOP 1
                                @out_id = fd.sei_id
                        FROM    pos_storageInfo fd
                        WHERE   fd.sei_sh_id = @id
                                AND fd.sei_is_net = 1
                    END
                ELSE
                    BEGIN
                        SELECT TOP 1
                                @out_id = fd.sei_id
                        FROM    pos_storageInfo fd
                        WHERE   fd.sei_sh_id = @id
                                AND fd.sei_is_tb = 1;
                    END
            END
        ELSE
            BEGIN
                IF EXISTS ( SELECT  *
                            FROM    b_storageinfo fd
                            WHERE   fd.sei_cp_id = @id
                                    AND fd.sei_is_net = 1 )
                    BEGIN
                        SELECT TOP 1
                                @out_id = fd.sei_id
                        FROM    b_storageinfo fd
                        WHERE   fd.sei_cp_id = @id
                                AND fd.sei_is_net = 1
                    END
                ELSE
                    BEGIN
                        SELECT TOP 1
                                @out_id = fd.sei_id
                        FROM    b_storageinfo fd
                        WHERE   fd.sei_cp_id = @id
                                AND fd.sei_is_tb = 1;
                    END

            END

			--是否为网络订单
			if @out_id=@sid or @sid=0
			begin

				INSERT INTO @returntable
				SELECT  
					nt.ord_no,
					n.o_ord_id,
					@sid,
					isnull(n.o_gi_id,0) ,
					ISNULL(n.o_sku_id, 0) AS o_sku_id ,
					n.o_nog_buynumber
				FROM  netorder_occupy_tbl n WITH ( NOLOCK )
				LEFT JOIN netorder_tbl nt WITH ( NOLOCK ) ON n.o_ord_id=nt.ord_id
				WHERE   n.o_ord_sendtype =@type
				AND n.o_ord_send_erp_sid =@id
				AND n.o_status = 1 

			end




	RETURN
END
go

