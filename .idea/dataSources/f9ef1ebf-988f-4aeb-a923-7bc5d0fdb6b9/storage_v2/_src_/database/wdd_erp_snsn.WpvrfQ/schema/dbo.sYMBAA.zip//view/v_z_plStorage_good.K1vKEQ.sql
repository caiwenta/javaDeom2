CREATE VIEW [dbo].[v_z_plStorage_good]
	AS 

select 

plStorag.*, 
sg.sei_name AS pl_st_id_txt,--仓库
sg.sei_name,--仓库
gi.gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_skuid,--规格组编号
gi.gi_sampleno,--样品号
ui.ut_name--单位

from(

SELECT
pltype=0,
isnull((st.ppl_retail_price*st.ppl_num),0)ppl_zero_money,--零售金额
ge.pl_id,
isnull(st.ppl_pm,'') as ppl_pm,
st.ppl_id,
ge.pl_cp_id,
ge.pl_erp_id as erp_id,
ge.pl_vo,--凭证号
ge.pl_no,--单据号
         ----单据日期
CONVERT(varchar(10),ge.pl_date,120) as pl_date ,
isnull(st.ppl_num,0) as num,--盈亏数

isnull(st.ppl_stock_num,0) as ppl_stock_num,--日期库存数量 
'' as ppl_new_num,  --实盘数量      
isnull(st.ppl_num,0) as ppl_num,--盈亏数量
isnull(st.ppl_retail_price,0) as ppl_retail_price,--零售价
isnull(st.ppl_discount,0) as ppl_discount,--折率
isnull(st.ppl_stock_price,0) as ppl_stock_price,--进货价
isnull(st.ppl_money,0) as ppl_money,--金额
isnull(st.ppl_boxbynum,0)ppl_boxbynum,--数量/箱
(case when isnull(st.ppl_boxbynum,0)=0 then 0 else ceiling(ppl_num/ppl_boxbynum) end) as ppl_box_num, --箱数

ppl_add_time,--单据商品添加时间
pl_order_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_order_man ),--经手人
pl_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =pl_add_man ),--单据添加人
pl_add_time,--单据添加时间
pl_update_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_update_man ),--单据修改人
pl_update_time,--单据修改时间
pl_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_audit_man ),--单据审核人
pl_audit_time,--单据审核时间
pl_remark,--备注
pl_status,--单据状态
pl_st_id,
ppl_gi_id
FROM j_plStorage ge
LEFT join  j_plStorageListMergeSum st ON st.ppl_type=0 and ge.pl_id = st.ppl_pl_id  AND st.ppl_status = 1 and ge.pl_status>0

UNION ALL


SELECT
pltype=1,
isnull((ppl_retail_price*ppl_num),0) ppl_zero_money,--零售金额
jt.tsl_id,
ppl_pm,
js.ppl_pl_id,
jt.tsl_cp_id,
jt.tsl_erp_id,
sl_order_no sl_order_no,
'',
CONVERT(varchar(10),jt.tsl_date,120) as ts_take_date ,
ppl_num AS num,--盈亏数
ppl_stock_num ppl_stock_num, --日期库存数量=实盘数-盈亏数
(ppl_stock_num+ppl_num) sl_takenum,   --实盘数量               
ppl_num AS ppl_num,--盈亏数
ppl_retail_price as gi_retailprice,--零售价   
ppl_discount, --折率
ppl_stock_price AS  gs_purchase,
ppl_money as menoy, --金额
ppl_box_num, --箱数
ppl_boxbynum,--数量/箱
jt.tsl_add_time,--单据商品添加时间
pl_order_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =jt.tsl_add_man ),--经手人
pl_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =jt.tsl_add_man ),--单据添加人
jt.tsl_add_time,--单据添加时间
pl_update_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = jt.tsl_update_man ),--单据修改人
jt.tsl_update_time,--单据修改时间
pl_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = jt.tsl_update_man ),--单据审核人
jt.tsl_update_time,--单据审核时间
jt.tsl_remark,--备注
jt.tsl_status,--单据状态
jt.tsl_st_id,
js.ppl_gi_id
FROM  j_plStorageListMergeSum AS js
LEFT JOIN j_takeStorageLog jt  ON js.ppl_type=1 and js.ppl_pl_id=jt.tsl_id AND jt.tsl_status<>0

) as plStorag
LEFT join b_goodsinfo gi on gi.gi_id=plStorag.ppl_gi_id and gi_status=1
LEFT join b_unit ui on ui.ut_id=gi.gi_unit 
LEFT join b_storageinfo sg on sg.sei_id=plStorag.pl_st_id--仓库
go

