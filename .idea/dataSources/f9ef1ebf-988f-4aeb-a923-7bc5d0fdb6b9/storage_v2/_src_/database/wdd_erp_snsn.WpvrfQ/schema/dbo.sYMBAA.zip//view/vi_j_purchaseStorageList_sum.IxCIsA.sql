CREATE VIEW [dbo].[vi_j_purchaseStorageList_sum]
	AS 
SELECT 
jpsl.pll_pl_id,
(SELECT SUM(isnull(pll_box_num,0)) FROM (
Select (case when fd.pll_boxbynum=0 then 0 else ceiling(sum(fd.pll_num)/fd.pll_boxbynum) end) as pll_box_num
From j_purchaseStorageList fd where fd.pll_status=1 AND fd.pll_pl_id=jpsl.pll_pl_id
GROUP BY fd.pll_gi_id,isnull(fd.pll_pm,''),fd.pll_boxbynum
) AS BB) AS pll_boxnum,
SUM(jpsl.pll_num) AS pll_num,
SUM(jpsl.pll_num * jpsl.pll_stock_price) AS pl_money
FROM  j_purchaseStorageList AS jpsl
WHERE jpsl.pll_status = 1
GROUP BY jpsl.pll_pl_id
go

