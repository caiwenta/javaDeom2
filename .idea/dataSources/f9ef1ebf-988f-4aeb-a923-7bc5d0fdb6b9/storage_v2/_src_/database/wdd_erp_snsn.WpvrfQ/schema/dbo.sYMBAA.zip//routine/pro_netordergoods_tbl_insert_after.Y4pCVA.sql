CREATE PROC [dbo].[pro_netordergoods_tbl_insert_after]
    @new_id INT ,--订单商品id
    @type VARCHAR(50) = '换货'--操作类别
AS
    BEGIN
		------------------------------------
		--用途：生成订单售后相应的单据（换货单，补货storerule） 
		------------------------------------
        DECLARE @ord_supplierid INT= 0;
        DECLARE @ord_suppliername VARCHAR(500)= '';
        DECLARE @ord_suppliercode VARCHAR(500)= '';
        DECLARE @ord_suppliertype VARCHAR(500)= '';
        DECLARE @supplier_id INT= 0; --供应商id
        DECLARE @shop_id INT= 0; --店铺id
        DECLARE @erp_id INT= 0; --企业ID
        DECLARE @t2out DATETIME= GETDATE();
        DECLARE @nog_type INT= 0;
        DECLARE @nog_pid INT= 0; --退货订单商品ID
        DECLARE @nog_id INT= 0; --换货订单商品ID
        DECLARE @nog_vr_state VARCHAR(50)= '';
        DECLARE @ord_id INT = 0;	
        DECLARE @ord_status INT = 0;
        DECLARE @ord_saletype VARCHAR(50) = '';
        DECLARE @ord_sale_erp_sid INT = 0;
        DECLARE @ord_sendtype VARCHAR(50) = '';
        DECLARE @ord_send_erp_sid INT = 0;
        DECLARE @oo_addman INT = 0;
        DECLARE @now DATETIME= GETDATE();
        DECLARE @ord_oc_id INT = 0;
        DECLARE @ord_orderdate VARCHAR(50) = CONVERT(VARCHAR(50), GETDATE(), 23);
        DECLARE @oc_client_id INT = 0; --客户主键
        DECLARE @oc_stock_id INT = 0; --仓库主键
        DECLARE @real_ord_sn VARCHAR(100); 
        DECLARE @is_node_to_store INT = 0;
        DECLARE @oo_id INT = 0;
        DECLARE @gi_id INT = 0;
        DECLARE @sku_id INT = 0;
        DECLARE @nog_buynumber INT = 0;
        DECLARE @gi_purchase_discount DECIMAL(10, 2) = 0;
        DECLARE @gi_retailprice DECIMAL(10, 2) = 0;
        DECLARE @gi_purchase DECIMAL(10, 2) = 0;
        DECLARE @gi_comgoods DECIMAL(10, 2) = 0;
        DECLARE @ord_addtime DATETIME;
        DECLARE @sa_id INT = 0;
        DECLARE @sa_add_time DATETIME = GETDATE();
        DECLARE @old_ord_addtime DATETIME = GETDATE();
        DECLARE @ord_sh_id INT = 0;
        DECLARE @sa_paytype VARCHAR(100)= '';
        DECLARE @nog_servtype INT = 0;
        DECLARE @nog_servstatus INT = 0;
        DECLARE @nog_oc_id INT = 0;
        DECLARE @ord_payway VARCHAR(100)= '';
        DECLARE @result VARCHAR(500) = '';
        DECLARE @ROLLBACK_msg VARCHAR(500) = '';
	
        SELECT  @nog_type = nog_type ,
                @nog_pid = nog_pid ,
                @nog_id = nog_id ,
                @nog_vr_state = nog_vr_state ,
                @ord_id = ord.ord_id ,
                @erp_id = ord.ord_erp_id ,
                @ord_status = ord_status ,
                @ord_saletype = ord_saletype ,
                @ord_sale_erp_sid = ord_sale_erp_sid ,
                @ord_sendtype = ord_sendtype ,
                @ord_send_erp_sid = ord_send_erp_sid ,
                @real_ord_sn = ord.ord_sn ,
                @ord_oc_id = ord.ord_oc_id ,
                @ord_supplierid = ord.ord_supplierid ,
                @ord_suppliername = ord.ord_suppliername ,
                @ord_suppliercode = ord.ord_suppliercode ,
                @ord_suppliertype = ord.ord_suppliertype
        FROM    netordergoods_tbl nog WITH ( NOLOCK )
                INNER JOIN netorder_tbl ord WITH ( NOLOCK ) ON nog.ord_sn = ord.ord_sn
        WHERE   nog.nog_id = @new_id

        IF @type = '换货'
            BEGIN
                SET @nog_vr_state = LTRIM(RTRIM(@nog_vr_state));
                      
                IF @nog_vr_state != '9'
                    RETURN;
            END
		--订单渠道
        SELECT  @oc_client_id = oc_client_id ,
                @oc_stock_id = oc_stock_id
        FROM    m_orderchannel WITH ( NOLOCK )
        WHERE   oc_id = @ord_oc_id;

        IF @type = '换货'
            AND @nog_type = 1
            BEGIN
				--要换的商品生成出库单
				--作废或退款，取消锁定库存
                IF @ord_status = -2
                    OR @ord_status = -1
                    OR @ord_status = 4
                    BEGIN
                        UPDATE  netorder_occupy_tbl
                        SET     o_status = 0 ,
                                o_update_time = GETDATE() ,
                                o_status_int = @ord_status
                        WHERE   o_ord_id = @ord_id
                                AND o_nog_id = @nog_id
                                AND o_status <> 0;

                        IF @@ROWCOUNT > 0
                            EXEC pro_update_occupy_num @ord_id;
                    END
				--需要生成销售单	
                IF @ord_saletype = 'node'
                    AND @ord_sendtype = 'store'
                    SET @is_node_to_store = 1;

                IF ( @ord_sendtype = 'node'
                     AND @is_node_to_store = 0
                     AND @ord_status = 4
                   )
                    AND NOT EXISTS ( SELECT 1
                                     FROM   j_outStorage oo WITH ( NOLOCK )
                                            INNER JOIN j_outStorageList ol ON ol.ol_eoid = oo.oo_id
                                     WHERE  oo.oo_status > 0
                                            AND oo.oo_di_id = @ord_id
                                            AND oo.oo_type = 1
                                            AND ol.ol_di_id = @nog_id )
                    BEGIN
						--得到添加人
                        SELECT TOP 1
                                @oo_addman = si_id
                        FROM    b_stafftinfo WITH ( NOLOCK )
                        WHERE   si_cp_id = @ord_send_erp_sid
                                AND si_isdel = 1
						--仓库
                        EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'send', 'node', @ord_send_erp_sid
                        IF @oc_stock_id = 0
                            BEGIN
                                SET @ROLLBACK_msg = '未设置发货方的网络订单仓库';
                                GOTO theEnd;
                            END
						--事务开始
                        BEGIN TRAN
						--添加单据
                        INSERT  INTO j_outStorage
                                ( oo_ciid ,
                                  oo_siid ,
                                  oo_no ,
                                  oo_manual ,
                                  oo_entrydate ,
                                  oo_itid ,
                                  oo_type ,
                                  oo_status ,
                                  oo_takemanid ,
                                  oo_cost ,
                                  oo_freight ,
                                  oo_express ,
                                  oo_expressno ,
                                  oo_remark ,
                                  oo_source_type ,
                                  oo_source_id ,
                                  oo_addman ,
                                  oo_addtime ,
                                  oo_lastmanid ,
                                  oo_auditdate ,
                                  oo_updatemam ,
                                  oo_updatetime ,
                                  oo_num ,
                                  oo_realmoney ,
                                  oo_totalmoney ,
                                  oo_sh_id ,
                                  oo_cp_id ,
                                  oo_di_id ,
                                  oo_jytype ,
                                  oo_to_cp_id ,
                                  oo_erp_id
	                            )
                        VALUES  ( @oc_client_id ,
                                  @oc_stock_id ,
                                  NEWID() ,
                                  '' ,
                                  '2004-01-02' ,
                                  0 ,
                                  1 ,
                                  1 ,
                                  0 ,
                                  0 ,
                                  0 ,
                                  0 ,
                                  0 ,
                                  '网络订单-换货' ,
                                  0 ,
                                  0 ,
                                  @oo_addman , --发货人
                                  GETDATE() ,
                                  NULL ,
                                  NULL ,
                                  NULL ,
                                  NULL ,
                                  0 ,
                                  0 ,
                                  0 ,
                                  0 ,
                                  @ord_send_erp_sid ,
                                  @ord_id ,
                                  0 ,
                                  0 ,
                                  @erp_id
	                            )
                        SET @oo_id = SCOPE_IDENTITY();
						--添加明细
                        INSERT  INTO j_outStorageList
                                ( ol_eoid ,
                                  ol_siid ,
                                  ol_skuid ,
                                  ol_number ,
                                  ol_realmoney ,
                                  ol_discount ,
                                  ol_remark ,
                                  ol_unit ,
                                  ol_costprice ,
                                  ol_addtime ,
                                  ol_status ,
                                  ol_di_id ,
                                  ol_erp_id
	                            )
                                SELECT  @oo_id AS ol_eoid ,
                                        gi.gi_id ,
                                        sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id
                                                      ELSE 0
                                                 END ,
                                        nog.nog_buynumber ,
                                        ( nog.nog_buynumber * nog.nog_actualprice ) AS ol_realmoney ,
                                        1 AS gi_purchase_discount ,
                                        '' AS ol_remark ,
                                        nog.nog_marketprice ,
                                        nog.nog_actualprice ,
                                        ord.ord_addtime ,
                                        1 AS ol_status ,
                                        @nog_id ,
                                        @erp_id
                                FROM    netordergoods_tbl nog WITH ( NOLOCK )
                                        INNER JOIN netorder_tbl ord WITH ( NOLOCK ) ON nog.ord_sn = ord.ord_sn
                                        INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                                     AND ord.ord_erp_id = gi.gi_erp_id
                                        LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gss.gi_id = gi.gi_id
                                                                                        AND nog.nog_skucode = gss.gss_no
                                WHERE   ord.ord_id = @ord_id
                                        AND gi.gi_status = 1
                                        AND nog.nog_id = @nog_id
						--调用存储过程生成出库单
                        EXEC pro_outStorage_op @ol_box_num = 0, @ol_pm = '', @oo_id = @oo_id, @oo_ciid = @oc_client_id, @oo_sh_id = 0, @oo_siid = @oc_stock_id,
                            @oo_takemanid = 0, @oo_remark = '网络订单-换货', @oo_entrydate = @ord_orderdate, @oo_lastmanid = 0, @oo_itid = 0, @oo_type = 1,
                            @oo_status = 1, @oo_manual = '', @oo_jytype = 0, @oo_updatemam = @oo_addman, @ol_id = NULL, @ol_siid = NULL, @ol_number = NULL,
                            @ol_discount = NULL, @ol_realmoney = NULL, @ol_remark = NULL, @ol_unit = NULL, @ol_costprice = NULL, @ol_addtime = NULL,
                            @ol_skuid = NULL, @ol_source_id = NULL, @oo_cp_id = @ord_send_erp_sid, @oo_di_id = NULL, @ol_source_add_time = NULL,
                            @not_in_ids = NULL, @savestr = NULL, @oo_to_cp_id = NULL, @negative_inventory = 1, @op_type = '修改单据', @oo_erp_id = @erp_id,
                            @ol_erp_id = @erp_id, @result = @result OUT
	        
                        IF @result = '0'
                            OR @@ERROR <> 0
                            BEGIN
                                SET @ROLLBACK_msg = '换货生成出库单失败';
                                GOTO theEnd;
                            END
                        ELSE
                            IF @@TRANCOUNT > 0
                                COMMIT TRAN;
                    END
                ELSE
                    IF ( @ord_saletype = 'store'
                         OR @is_node_to_store = 1
                       )
                        AND @ord_sendtype <> 'node'
                        AND ( @ord_status = 4
                              AND NOT EXISTS ( SELECT   1
                                               FROM     pos_sale_net psn
                                                        INNER JOIN pos_sale ps ON psn.sa_net_sa_id = ps.sa_id
                                               WHERE    psn.sa_net_ord_id = @ord_id
                                                        AND psn.sa_net_nog_id = @nog_id
                                                        AND ps.sa_status > 0
                                                        AND ps.sa_type = 0 )
                            )
                        BEGIN
                            SET @ord_sh_id = @ord_sale_erp_sid;
	        
                            IF @is_node_to_store = 1
                                SET @ord_sh_id = @ord_send_erp_sid;
							--得到添加人
                            SELECT TOP 1
                                    @oo_addman = si_id
                            FROM    b_stafftinfo WITH ( NOLOCK )
                            WHERE   si_shop_id = @ord_sh_id
                                    AND si_isdel = 1
							--仓库
                            EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'send', 'store', @ord_sh_id
                            IF @oc_stock_id = 0
                                BEGIN
                                    SET @ROLLBACK_msg = '未设置发货方的网络订单仓库';
                                    GOTO theEnd;
                                END
							--事务开始
                            BEGIN TRAN
							--游标
                            DECLARE sopcor CURSOR
                            FOR
                                ( SELECT    gi.gi_id ,
                                            sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id
                                                          ELSE 0
                                                     END ,
                                            nog.nog_buynumber ,
                                            gi.gi_purchase_discount ,
                                            gi_retailprice = CASE WHEN CHARINDEX('现金支付', ord.ord_payway) != 0 THEN nog.nog_marketprice
                                                                  ELSE nog.nog_marketprice
                                                             END ,
                                            gi_purchase = CASE WHEN CHARINDEX('现金支付', ord.ord_payway) != 0 THEN nog.nog_actualprice
                                                               ELSE nog.nog_actualprice
                                                          END ,
                                            ord.ord_addtime ,
                                            ord.ord_payway ,
											ISNULL(nog.nog_comgoods, 0) AS nog_comgoods
                                  FROM      netordergoods_tbl nog WITH ( NOLOCK )
                                            INNER JOIN netorder_tbl ord WITH ( NOLOCK ) ON nog.ord_sn = ord.ord_sn
                                            INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                                         AND ord.ord_erp_id = gi.gi_erp_id
                                            LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gss.gi_id = gi.gi_id
                                                                                            AND nog.nog_skucode = gss.gss_no
                                  WHERE     ord.ord_id = @ord_id
                                            AND gi.gi_status = 1
                                            AND nog.nog_id = @nog_id
                                )
                            OPEN sopcor
                            FETCH NEXT FROM sopcor INTO @gi_id, @sku_id, @nog_buynumber, @gi_purchase_discount, @gi_retailprice, @gi_purchase, @ord_addtime,
                                @sa_paytype, @gi_comgoods
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    IF @old_ord_addtime = @ord_addtime
                                        BEGIN
                                            SET @ord_addtime = GETDATE();
                                            SET @old_ord_addtime = @ord_addtime;
                                        END
                                    ELSE
                                        SET @old_ord_addtime = @ord_addtime;

                                    EXEC pro_get_rand_time @t1 = @t2out, @t2out = @t2out OUT

                                    SELECT  @ord_addtime = @t2out
	            
                                    EXEC pro_pos_sale_temp_op @sal_id = 0, @sal_sa_id = @sa_id, @sal_gi_id = @gi_id, @sal_sku_id = @sku_id,
                                        @sal_num = @nog_buynumber, @sal_retail_price = @gi_retailprice, @sal_discount = @gi_purchase_discount,
                                        @sal_list_man = @oo_addman, @sal_real_price = @gi_purchase, @sal_add_time = @ord_addtime, @sa_id = @sa_id,
                                        @sa_sh_id = @ord_sh_id, @sa_co_man = @oo_addman, @sa_date = @ord_orderdate, @sa_st_id = @oc_stock_id,
                                        @sa_add_man = @oo_addman, @sa_add_time = @sa_add_time, @sa_type = 0, @sa_sa_type = 1, @sa_remark = '网络订单-换货',
                                        @op_type = '添加修改单据,明细', @sa_paytype = @sa_paytype, @sal_deduction = @gi_comgoods, @result = @result OUT
	            
                                    IF @result = '0'
                                        BREAK;
	            
                                    IF @sa_id = 0
                                        SET @sa_id = CONVERT(INT, @result);
	            
                                    FETCH NEXT FROM sopcor INTO @gi_id, @sku_id, @nog_buynumber, @gi_purchase_discount, @gi_retailprice, @gi_purchase,
                                        @ord_addtime, @sa_paytype, @gi_comgoods
                                END
                            CLOSE sopcor
                            DEALLOCATE sopcor

                            IF @result != '0'
                                BEGIN
                                    EXEC pro_pos_sale_temp_op @sa_id = @sa_id, @sa_sh_id = @ord_sh_id, @sa_co_man = @oo_addman, @sa_date = @ord_orderdate,
                                        @sa_st_id = @oc_stock_id, @sa_type = 0, @sa_sa_type = 1, @sa_remark = '网络订单-换货', @negative_inventory = 1,
                                        @sa_paytype = @sa_paytype, @op_type = '修改单据', @result = @result OUT

									UPDATE  netorder_tbl SET [ord_sa_id]=@sa_id
									WHERE   ord_id = @ord_id

									INSERT  INTO pos_sale_net
											( sa_net_sa_id ,
											  sa_net_ord_id ,
											  sa_net_nog_id ,
											  sa_net_add_time
											)
									VALUES  ( @sa_id ,
											  @ord_id ,
											  @nog_id ,
											  GETDATE()
											)
                                END
	        
                            IF @result = '0'
                                OR @@ERROR <> 0
                                BEGIN
                                    SET @ROLLBACK_msg = '换货生成POS销售单失败';
                                    GOTO theEnd;
                                END
                            ELSE
                                IF @@TRANCOUNT > 0
                                    COMMIT TRAN;
                        END
				--被换的商品生成退货单
                EXEC pro_netordergoods_tbl_nog_servtype_update_after @nog_pid, @ord_id, 'exchange'
            END

        IF CHARINDEX('补货', @type) != 0
            BEGIN
                SET @shop_id = @ord_sale_erp_sid;
				/*
				* erp
				* 接口接收订单数据,要判断商品数据在erp是否已经存在
				* 没有存在的话,请求得到商品数据
				* */
				--供应商添加
                IF ISNULL(@ord_supplierid, 0) = 0
                    BEGIN
                        SET @ROLLBACK_msg = '是补货单,但却没有供应商id';
                        GOTO theEnd;
                    END
	
                IF EXISTS ( SELECT  1
                            FROM    b_supplierinfo bs
                            WHERE   bs.si_out_id = @ord_supplierid
                                    AND bs.si_status = 1
                                    AND bs.si_out_type = @ord_suppliertype )
                    BEGIN
                        SELECT TOP 1
                                @supplier_id = bs.si_id
                        FROM    b_supplierinfo bs
                        WHERE   bs.si_out_id = @ord_supplierid
                                AND bs.si_status = 1
                                AND bs.si_out_type = @ord_suppliertype
                    END
                ELSE
                    BEGIN
                        DECLARE @si_flid INT= 0;
		
                        SELECT TOP 1
                                @si_flid = ct.[type_id]
                        FROM    cors_type ct
                        WHERE   ct.type_cors = 2
                                AND ct.type_status = 1
                                AND ct.type_cp_id = @ord_send_erp_sid;
						--供应商编号自增
                        SET @ord_suppliercode = CONVERT(VARCHAR(50), ( SELECT   ISNULL(COUNT(1), 1)
                                                                       FROM     b_supplierinfo
                                                                       WHERE    si_out_id > 0
                                                                                AND si_cp_id = @ord_send_erp_sid
                                                                                AND si_status > 0
                                                                     ));
		
                        INSERT  INTO b_supplierinfo
                                ( si_name ,
                                  si_code ,
                                  si_status ,
                                  si_province ,
                                  si_city ,
                                  si_county ,
                                  si_flid ,
                                  si_isdel ,
                                  si_add_time ,
                                  si_update_time ,
                                  si_cp_id ,
                                  si_out_id ,
                                  si_out_type ,
                                  si_erp_id
		                        )
                        VALUES  ( @ord_suppliername ,
                                  @ord_suppliercode ,
                                  1 ,
                                  '无' ,
                                  '无' ,
                                  '无' ,
                                  @si_flid ,
                                  1 ,
                                  GETDATE() ,
                                  GETDATE() ,
                                  @ord_send_erp_sid ,
                                  @ord_supplierid ,
                                  @ord_suppliertype ,
                                  @erp_id
		                        )
                        SET @supplier_id = SCOPE_IDENTITY();
                    END
				--仓库
                EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'send', 'node', @ord_send_erp_sid
                IF @oc_stock_id = 0
                    BEGIN
                        SET @ROLLBACK_msg = '未设置发货方的网络订单仓库';
                        GOTO theEnd;
                    END
				--得到添加人
                SELECT TOP 1
                        @oo_addman = si_id
                FROM    b_stafftinfo WITH ( NOLOCK )
                WHERE   si_cp_id = @ord_send_erp_sid
                        AND si_isdel = 1

                SET @oc_client_id = @supplier_id;

                DECLARE @eo_type INT= 0;
                DECLARE @oo_type INT= 0;

                IF @type = '补货'
                    BEGIN
                        SET @eo_type = 0;
                        SET @oo_type = 1;
                    END
                ELSE
                    IF @type = '补货售后'
                        BEGIN
                            SET @eo_type = 1;
                            SET @oo_type = 0;
                        END
				--总部入库单
                BEGIN TRAN
				--添加单据
                INSERT  INTO j_enterStorage
                        ( eo_ciid ,
                          eo_siid ,
                          eo_no ,
                          eo_manual ,
                          eo_entrydate ,
                          eo_itid ,
                          eo_type ,
                          eo_status ,
                          eo_takemanid ,
                          eo_cost ,
                          eo_freight ,
                          eo_express ,
                          eo_expressno ,
                          eo_remark ,
                          eo_source_type ,
                          eo_source_id ,
                          eo_addman ,
                          eo_addtime ,
                          eo_lastmanid ,
                          eo_auditdate ,
                          eo_updateman ,
                          eo_updatetime ,
                          eo_num ,
                          eo_realmoney ,
                          eo_totalmoney ,
                          eo_cp_id ,
                          eo_di_id ,
                          eo_to_cp_id ,
                          eo_erp_id
					    )
                VALUES  ( @oc_client_id ,
                          @oc_stock_id ,
                          NEWID() ,
                          '' ,
                          '2004-01-02' ,
                          0 ,
                          @eo_type ,
                          1 ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          '网络订单-补货' ,
                          0 ,
                          0 ,
                          @oo_addman ,--发货人
                          GETDATE() ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          0 ,
                          0 ,
                          0 ,
                          @ord_send_erp_sid ,
                          @ord_id ,
                          0 ,
                          @erp_id
					    )
                SET @oo_id = SCOPE_IDENTITY();
				--添加明细
                INSERT  INTO j_enterStorageList
                        ( el_eoid ,
                          el_siid ,
                          el_skuid ,
                          el_number ,
                          el_realmoney ,
                          el_discount ,
                          el_remark ,
                          el_unit ,
                          el_costprice ,
                          el_addtime ,
                          el_status ,
                          el_di_id ,
                          el_erp_id
					    )
                        SELECT  @oo_id AS el_eoid ,
                                gi.gi_id ,
                                sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id
                                              ELSE 0
                                         END ,
                                nog.nog_buynumber ,
                                ( nog.nog_buynumber * gi.gi_importprices ) AS el_realmoney ,
                                1 AS gi_purchase_discount ,
                                '' AS el_remark ,
                                gi.gi_retailprice ,
                                gi.gi_importprices ,
                                ord.ord_addtime ,
                                1 AS el_status ,
                                nog.nog_id ,
                                @erp_id
                        FROM    netordergoods_tbl nog WITH ( NOLOCK )
                                INNER JOIN netorder_tbl ord WITH ( NOLOCK ) ON nog.ord_sn = ord.ord_sn
                                INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                             AND ord.ord_erp_id = gi.gi_erp_id
                                LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gss.gi_id = gi.gi_id
                                                                                AND nog.nog_skucode = gss.gss_no
                        WHERE   ord.ord_id = @ord_id
                                AND gi.gi_status = 1

                IF @type = '补货售后'
                    BEGIN
                        DELETE  FROM j_enterStorageList
                        WHERE   el_eoid = @oo_id
                                AND el_di_id != @new_id;
                    END
				--调用存储过程生成入库单
                EXEC pro_enterStorage_op @el_box_num = 0, @el_pm = '', @eo_id = @oo_id, @eo_ciid = @oc_client_id, @eo_siid = @oc_stock_id, @eo_takemanid = 0,
                    @eo_remark = '网络订单-补货', @eo_entrydate = @ord_orderdate, @eo_lastmanid = 0, @eo_itid = 0, @eo_type = @eo_type, @eo_status = 1,
                    @eo_manual = '', @eo_updateman = @oo_addman, @el_id = NULL, @el_siid = NULL, @el_number = NULL, @el_discount = NULL, @el_realmoney = NULL,
                    @el_remark = NULL, @el_unit = NULL, @el_costprice = NULL, @el_addtime = NULL, @el_skuid = NULL, @el_source_id = NULL,
                    @eo_cp_id = @ord_send_erp_sid, @eo_di_id = NULL, @el_source_add_time = NULL, @not_in_ids = NULL, @savestr = NULL, @eo_to_cp_id = NULL,
                    @negative_inventory = 1, @op_type = '修改单据', @eo_erp_id = @erp_id, @el_erp_id = @erp_id, @result = @result OUT

                IF @result = '0'
                    OR @@ERROR <> 0
                    BEGIN
                        SET @ROLLBACK_msg = '补货生成入库单失败';
                        GOTO theEnd;
                    END
                ELSE
                    IF @@TRANCOUNT > 0
                        COMMIT TRAN;
				--总部出库单到店铺
				--事务开始			
                BEGIN TRAN
				--添加单据
                INSERT  INTO j_outStorage
                        ( oo_ciid ,
                          oo_siid ,
                          oo_no ,
                          oo_manual ,
                          oo_entrydate ,
                          oo_itid ,
                          oo_type ,
                          oo_status ,
                          oo_takemanid ,
                          oo_cost ,
                          oo_freight ,
                          oo_express ,
                          oo_expressno ,
                          oo_remark ,
                          oo_source_type ,
                          oo_source_id ,
                          oo_addman ,
                          oo_addtime ,
                          oo_lastmanid ,
                          oo_auditdate ,
                          oo_updatemam ,
                          oo_updatetime ,
                          oo_num ,
                          oo_realmoney ,
                          oo_totalmoney ,
                          oo_sh_id ,
                          oo_cp_id ,
                          oo_di_id ,
                          oo_jytype ,
                          oo_to_cp_id ,
                          oo_erp_id
					    )
                VALUES  ( 0 ,
                          @oc_stock_id ,
                          NEWID() ,
                          '' ,
                          '2004-01-02' ,
                          0 ,
                          @oo_type ,
                          1 ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          '网络订单-换货' ,
                          0 ,
                          0 ,
                          @oo_addman ,--发货人
                          GETDATE() ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          0 ,
                          0 ,
                          0 ,
                          @shop_id ,
                          @ord_send_erp_sid ,
                          @ord_id ,
                          0 ,
                          0 ,
                          @erp_id
					    )
                SET @oo_id = SCOPE_IDENTITY();
				--添加明细
                INSERT  INTO j_outStorageList
                        ( ol_eoid ,
                          ol_siid ,
                          ol_skuid ,
                          ol_number ,
                          ol_realmoney ,
                          ol_discount ,
                          ol_remark ,
                          ol_unit ,
                          ol_costprice ,
                          ol_addtime ,
                          ol_status ,
                          ol_di_id ,
                          ol_erp_id
					    )
                        SELECT  @oo_id AS ol_eoid ,
                                gi.gi_id ,
                                sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id
                                              ELSE 0
                                         END ,
                                nog.nog_buynumber ,
                                ( nog.nog_buynumber * nog.nog_actualprice ) AS ol_realmoney ,
                                1 AS gi_purchase_discount ,
                                '' AS ol_remark ,
                                nog.nog_marketprice ,
                                nog.nog_actualprice ,
                                ord.ord_addtime ,
                                1 AS ol_status ,
                                nog.nog_id ,
                                @erp_id
                        FROM    netordergoods_tbl nog WITH ( NOLOCK )
                                INNER JOIN netorder_tbl ord WITH ( NOLOCK ) ON nog.ord_sn = ord.ord_sn
                                INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                             AND ord.ord_erp_id = gi.gi_erp_id
                                LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gss.gi_id = gi.gi_id
                                                                                AND nog.nog_skucode = gss.gss_no
                        WHERE   ord.ord_id = @ord_id
                                AND gi.gi_status = 1

                IF @type = '补货售后'
                    BEGIN
                        DELETE  FROM j_outStorageList
                        WHERE   ol_eoid = @oo_id
                                AND ol_di_id != @new_id;
                    END
				--调用存储过程生成出库单
                EXEC pro_outStorage_op @ol_box_num = 0, @ol_pm = '', @oo_id = @oo_id, @oo_ciid = 0, @oo_sh_id = @shop_id, @oo_siid = @oc_stock_id,
                    @oo_takemanid = 0, @oo_remark = '网络订单-补货', @oo_entrydate = @ord_orderdate, @oo_lastmanid = 0, @oo_itid = 0, @oo_type = @oo_type,
                    @oo_status = 1, @oo_manual = '', @oo_jytype = 0, @oo_updatemam = @oo_addman, @ol_id = NULL, @ol_siid = NULL, @ol_number = NULL,
                    @ol_discount = NULL, @ol_realmoney = NULL, @ol_remark = NULL, @ol_unit = NULL, @ol_costprice = NULL, @ol_addtime = NULL, @ol_skuid = NULL,
                    @ol_source_id = NULL, @oo_cp_id = @ord_send_erp_sid, @oo_di_id = NULL, @ol_source_add_time = NULL, @not_in_ids = NULL, @savestr = NULL,
                    @oo_to_cp_id = NULL, @negative_inventory = 1, @op_type = '修改单据', @oo_erp_id = @erp_id, @ol_erp_id = @erp_id, @result = @result OUT
			        
                IF @result = '0'
                    OR @@ERROR <> 0
                    BEGIN
                        SET @ROLLBACK_msg = '补货生成出库单失败';
                        GOTO theEnd;
                    END
                ELSE
                    IF @@TRANCOUNT > 0
                        COMMIT TRAN;
            END

        theEnd:
        IF @ROLLBACK_msg <> ''
            OR @@ERROR <> 0
            BEGIN
                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN;

				UPDATE netorder_tbl 
				SET    ord_is_ok=2 
				WHERE  ord_id=@ord_id

                UPDATE  netordergoods_tbl
                SET     nog_is_ok = 2 ,
                        nog_is_ok_msg = @ROLLBACK_msg
                WHERE   nog_id = @nog_id;
            END
        ELSE
            UPDATE  netordergoods_tbl
            SET     nog_is_ok = 1 ,
                    nog_is_ok_msg = ''
            WHERE   nog_id = @nog_id;
    END
go

