CREATE TRIGGER [dbo].[trg_c_inoutlist_insert] ON [dbo].[c_inoutlist]
    AFTER INSERT
AS
    BEGIN
        DECLARE @myprevTxt VARCHAR(50)= 'XJYH';
        DECLARE @bk_id INT= 0;
        DECLARE @iol_id INT= 0;
        DECLARE @iol_indate DATETIME;
        DECLARE @iol_cp_id INT= 0;
        DECLARE @iol_itid INT= 0;
        DECLARE @iol_ciid INT= 0;
        DECLARE @iol_shid INT= 0;
        DECLARE @iol_cpid INT= 0;
        DECLARE @iol_status INT= 0;
        DECLARE @iol_rumoney DECIMAL(10, 2);
        DECLARE @iol_chumoney DECIMAL(10, 2);
        DECLARE @iol_erp_id INT= 0;

        SELECT  @bk_id = bk_id ,
                @iol_erp_id = iol_erp_id ,
                @iol_id = iol_id ,
                @iol_indate = iol_indate ,
                @iol_cp_id = iol_cp_id ,
                @iol_rumoney = iol_rumoney ,
                @iol_chumoney = iol_chumoney ,
                @iol_status = iol_status ,
                @iol_ciid = iol_ciid ,
                @iol_shid = iol_shid ,
                @iol_cpid = iol_cpid ,
                @iol_itid = iol_itid
        FROM    INSERTED
		--序号
        UPDATE  c_inoutlist
        SET     iol_row_num = rix.rowNum
        FROM    c_inoutlist iol ,
                ( SELECT    iol_id ,
                            ROW_NUMBER() OVER ( ORDER BY iol_indate, iol_id ) AS rowNum
                  FROM      c_inoutlist
                  WHERE     iol_status > 0
                            AND bk_id = @bk_id
                ) AS rix
        WHERE   iol.iol_id = rix.iol_id;
		--更新凭证号	
        DECLARE @tableName VARCHAR(50)= 'c_inoutlist'
        DECLARE @idField VARCHAR(50)= 'iol_id'
        DECLARE @idValue INT= @iol_id
        DECLARE @dateField VARCHAR(50)= 'iol_indate'
        DECLARE @dateValue VARCHAR(50)= CONVERT(VARCHAR(50), @iol_indate, 23)
        DECLARE @noField VARCHAR(50)= 'iol_vo'
        DECLARE @prevTxt VARCHAR(50)= @myprevTxt
        DECLARE @outno VARCHAR(100)= ''
        DECLARE @while INT= 0;
        WHILE @while = 0
            BEGIN
			--得到凭证号
                EXECUTE [dbo].[pro_gen_orderNo] @tableName, @idField, @idValue, @dateField, @dateValue, @noField, @prevTxt, @outno OUTPUT, 0, @iol_cp_id
                BEGIN TRY
				--更新
                    UPDATE  c_inoutlist
                    SET     iol_vo = @outno ,
                            pzone = dbo.Get_StrArrayStrOfIndex(@outno, '-', 1) ,
                            pztwo = dbo.Get_StrArrayStrOfIndex(@outno, '-', 2) ,
                            pzthree = dbo.Get_StrArrayStrOfIndex(@outno, '-', 3)
                    WHERE   iol_id = @iol_id;
				--更新成功,赋值,结束循环
                    SET @while = 1;
                END TRY
                BEGIN CATCH
                    PRINT '';
                END CATCH
            END
		--账款生成
        DECLARE @it_type INT= 0;
        DECLARE @cha DECIMAL(10, 2);
        DECLARE @fo_bs VARCHAR(50)= '';
        DECLARE @fo_type INT= 0;
	
        SELECT  @it_type = it_type
        FROM    c_infotype
        WHERE   it_id = @iol_itid;

        IF @it_type IN ( 1, 2 )
            BEGIN
                SET @cha = ISNULL(@iol_rumoney, 0) - ISNULL(@iol_chumoney, 0);
				--应收
                IF @it_type = 1
                    BEGIN
                        SET @fo_bs = 'X';
                        SET @fo_type = 0;
                    END
                ELSE
                    BEGIN
						--应付
                        SET @cha = ISNULL(@iol_chumoney, 0) - ISNULL(@iol_rumoney, 0);
                        SET @fo_bs = 'G';
                        SET @fo_type = 1;
                    END

                DECLARE @RC INT = 0;
                DECLARE @fo_id INT = 0;            
                DECLARE @fo_cp_id INT = @iol_cp_id;
                DECLARE @fo_erp_id INT = @iol_erp_id;
                DECLARE @fo_ciid INT = @iol_ciid;
                DECLARE @fo_orderid VARCHAR(50) = @outno;
                DECLARE @fo_takeman VARCHAR(50) = '';
                DECLARE @fo_ticketno VARCHAR(50) = '';
                DECLARE @fo_realmoney DECIMAL(15, 2) = 0;
                DECLARE @fo_thiyetmoney DECIMAL(15, 2) = @cha;
                DECLARE @fo_ofdate DATETIME = CONVERT(VARCHAR(50), @iol_indate, 23);
                DECLARE @fo_remark VARCHAR(200) = '现金银行';
                DECLARE @fo_lastman VARCHAR(50) = '';
                DECLARE @fo_status TINYINT = 1;
                DECLARE @fo_outmoney DECIMAL(15, 2) = 0;
                DECLARE @fo_admoney DECIMAL(15, 2) = 0; --垫付运费
                DECLARE @fo_otheronmoney DECIMAL(15, 2) = 0; --其他应收
                DECLARE @fo_otheoutmoney DECIMAL(15, 2) = 0; --其他应付
                DECLARE @fo_givemoney DECIMAL(15, 2) = 0;
                DECLARE @fo_ensuremoney DECIMAL(15, 2) = 0;
                DECLARE @fo_subscription DECIMAL(15, 2) = 0;
                DECLARE @fo_no VARCHAR(50) = '';
                DECLARE @fo_userorderno VARCHAR(50) = '';
                DECLARE @fo_shid INT = @iol_shid;
                DECLARE @fo_to_cpid INT = @iol_cpid;
                DECLARE @fo_source_id INT = @iol_id;
                DECLARE @outResult INT = 0;

                EXECUTE @RC = [pro_c_fundorder_op] @fo_id = @fo_id, @fo_type = @fo_type, @fo_ciid = @fo_ciid, @fo_bs = @fo_bs, @fo_orderid = @fo_orderid,
                    @fo_takeman = @fo_takeman, @fo_ticketno = @fo_ticketno, @fo_realmoney = @fo_realmoney, @fo_thiyetmoney = @fo_thiyetmoney,
                    @fo_ofdate = @fo_ofdate, @fo_remark = @fo_remark, @fo_lastman = @fo_lastman, @fo_status = @fo_status, @fo_outmoney = @fo_outmoney,
                    @fo_admoney = @fo_admoney, @fo_otheronmoney = @fo_otheronmoney, @fo_otheoutmoney = @fo_otheoutmoney, @fo_givemoney = @fo_givemoney,
                    @fo_ensuremoney = @fo_ensuremoney, @fo_subscription = @fo_subscription, @fo_no = @fo_no, @fo_userorderno = @fo_userorderno,
                    @outResult = @outResult OUTPUT, @fo_cp_id = @fo_cp_id, @fo_di_id = 0, @fo_shid = @fo_shid, @fo_to_cpid = @fo_to_cpid,
                    @fo_erp_id = @fo_erp_id, @fo_order_id = 0, @fo_source_id = @fo_source_id
            END
    END
go

