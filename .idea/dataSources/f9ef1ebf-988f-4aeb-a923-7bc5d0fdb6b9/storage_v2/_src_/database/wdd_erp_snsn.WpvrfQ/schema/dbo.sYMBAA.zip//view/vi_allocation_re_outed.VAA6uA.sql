
CREATE View [dbo].[vi_allocation_re_outed]
As
select 
jos.re_id,
josl.rel_id,
josl.rel_gi_id,
josl.rel_num,
josl.rel_add_time
from pos_reStorage as jos inner join pos_reStorageList as josl on jos.re_id=josl.rel_re_id 
where  josl.rel_status=1 and jos.re_status>0

go

