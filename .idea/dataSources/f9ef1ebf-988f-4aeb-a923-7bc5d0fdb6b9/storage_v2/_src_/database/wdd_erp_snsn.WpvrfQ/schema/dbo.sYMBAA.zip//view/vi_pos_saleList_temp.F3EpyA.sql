
CREATE VIEW [dbo].[vi_pos_saleList_temp] AS 
SELECT sl.sal_id
      ,sl.sal_sa_id
      ,sl.sal_gi_id
	  ,sl.sal_acid as sal_pgid
      ,sal_old_record
      ,sal_real_price_old
      ,sal_discount_old
      ,sal_deduct_money_old
      ,sl.sal_acid
	  ,sl.sal_pkindex
      ,ISNULL(sal_in_money ,0) AS sal_in_money
      ,sl.sal_buyingteamid
      ,sl.sal_returnedid
      ,(
           CASE 
                WHEN LEN(ISNULL(bg.gi_skuid ,''))<1 THEN 0
                ELSE sl.sal_sku_id
           END
       ) AS sal_sku_id
      ,CASE 
            WHEN sl.sal_is_return=1 OR
                 sl.sal_is_change=1 THEN - ABS(sal_num)
            ELSE sal_num
       END AS sal_num
      ,sl.sal_retail_price
      ,sl.sal_discount
      ,sl.sal_list_man
      ,(
           SELECT st_st_id
           FROM   pos_staffClassSet AS bs WITH (NOLOCK)
           WHERE  (st_id=sl.sal_list_man)
       ) AS sal_list_man_txt
      ,sl.sal_real_price
      ,CASE 
            WHEN sl.sal_is_return=1 OR
                 sl.sal_is_change=1 THEN -((ABS(sal_num)*sal_real_price)- sal_deduct_money)
            WHEN sl.sal_is_gift=1 OR
                 sl.sal_is_in=1 THEN 0
            ELSE ((sal_num*sal_real_price)- sal_deduct_money)
       END AS sal_money
      ,CASE 
            WHEN sl.sal_is_return=1 OR sl.sal_is_change=1 THEN -sal_paidmomey
            WHEN sl.sal_is_gift=1 OR sl.sal_is_in=1 THEN 0
            ELSE sal_paidmomey
       END AS sal_paidmomey
      ,sl.sal_deduct_money
      ,sl.sal_is_gift
      ,sl.sal_is_change
      ,sl.sal_is_in
      ,sl.sal_in_num
      ,sl.sal_is_return
      ,sl.sal_is_tejia
      ,sl.sal_is_zhengjia
      ,sl.sal_remark
      ,sl.sal_remark2
      ,sl.sal_status
      ,CONVERT(VARCHAR(100) ,sl.sal_add_time ,25) AS sal_add_time
      ,bg.gi_code
      ,bg.gi_name
      ,bu.ut_name AS gi_unit
      ,bg2.gss_no
      ,bg2.gs_name
      ,sl.sal_st_id
      ,fd3.sei_name AS sal_st_id_txt
FROM   dbo.pos_saleList_temp AS sl WITH (NOLOCK) INNER
       JOIN dbo.b_goodsinfo AS bg WITH (NOLOCK)
            ON  sl.sal_gi_id = bg.gi_id
       LEFT OUTER JOIN dbo.b_goodsruleset AS bg2 WITH (NOLOCK)
            ON  sl.sal_sku_id = bg2.gss_id
       INNER JOIN dbo.b_unit AS bu WITH (NOLOCK)
            ON  bg.gi_unit = bu.ut_id
       LEFT OUTER JOIN dbo.pos_storageInfo AS fd3 WITH (NOLOCK)
            ON  sl.sal_st_id = fd3.sei_id
WHERE  (sl.sal_status=1)
go

