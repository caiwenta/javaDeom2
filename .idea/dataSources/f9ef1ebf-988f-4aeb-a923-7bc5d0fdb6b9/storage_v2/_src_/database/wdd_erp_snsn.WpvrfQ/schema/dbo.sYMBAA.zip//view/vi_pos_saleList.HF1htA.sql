CREATE VIEW [dbo].[vi_pos_saleList]
AS
SELECT  sal_buyingteamid ,   --买手小组
        (SELECT si_name
         FROM   b_stafftinfo WITH (NOLOCK) 
         WHERE  si_id = sal_buyingteamid
                AND si_erp_id = bg.gi_erp_id
        ) AS gi_buyingteam ,
        sal_old_record ,
        sal_real_price_old ,
        sal_discount_old ,
        sal_deduct_money_old ,
        bg.gi_supplierid ,     --供应商
        (SELECT si_name
         FROM   b_supplierinfo WITH (NOLOCK) 
         WHERE  si_id = bg.gi_supplierid
                AND si_erp_id = bg.gi_erp_id
        ) AS gi_supplier ,
        sal_id ,
        sal_sa_id ,
        sal_gi_id ,
        (CASE WHEN LEN(ISNULL(bg.gi_skuid,'')) < 1 THEN 0
              ELSE sl.sal_sku_id
         END) AS sal_sku_id ,
        sal_num = CASE WHEN sl.sal_is_return = 1
                            OR sl.sal_is_change = 1 THEN -ABS(sal_num)
                       ELSE sal_num
                  END ,
        sal_retail_price ,
        sal_discount ,
        sal_list_man ,
        (SELECT bs.st_st_id
         FROM   pos_staffClassSet AS bs WITH (NOLOCK)
         WHERE  bs.st_id = sal_list_man
                AND bs.st_status = 1
        ) AS sal_list_man_txt ,
        sal_real_price ,
        sal_money = --((sal_num*sal_real_price)-sal_deduct_money)
        CASE WHEN sl.sal_is_return = 1
                  OR sl.sal_is_change = 1 THEN -((ABS(sal_num) * sal_real_price) - sal_deduct_money)
             WHEN sl.sal_is_gift = 1
                  OR sl.sal_is_in = 1 THEN 0
             ELSE ((sal_num * sal_real_price) - sal_deduct_money)
        END ,
		isnull(sal_in_money,0) as sal_in_money,
        sal_deduct_money ,
        sal_is_gift ,
        sal_is_change ,
        sal_is_in ,
        sal_in_num ,
        sal_is_return ,
        sal_is_tejia ,
        sal_is_zhengjia ,
        sal_remark ,
        sal_remark2 ,
        sal_status ,
        sal_add_time = CONVERT(VARCHAR(100),sl.sal_add_time,25) ,
        bg.gi_code ,
        bg.gi_name ,
        bg.gi_barcode ,
        bg.gi_attribute_ids ,
        bg.gi_attribute_parentids ,
        bg.gi_types ,
        bg.gi_typesid ,
        gi_unit = bu.ut_name ,
        bu.ut_id AS gi_unit_id ,
        bg2.gss_no ,
        bg2.gs_name ,
        sl.sal_st_id ,
        sl.sal_paiddiscount ,
		sl.sal_acid,
		sl.sal_returnedid,
        (CASE WHEN sl.sal_is_return = 1
                   OR sl.sal_is_change = 1 THEN -ABS(sal_paidmomey)
              WHEN sl.sal_is_gift = 1
                   OR sl.sal_is_in = 1 THEN 0
              ELSE (sal_paidmomey)
         END) AS sal_paidmomey ,
        fd3.sei_name AS sal_st_id_txt,
		ISNULL((select gc_name from s_goodsclass where gc_id=bg.gi_type1),'')as  gc_name1,
						ISNULL((select gc_name from s_goodsclass where gc_id=bg.gi_type2),'')as  gc_name2,
						ISNULL((select gc_name from s_goodsclass where gc_id=bg.gi_type3),'')as  gc_name3,
						ISNULL((select gc_name from s_goodsclass where gc_id=bg.gi_type4),'')as  gc_name4,
						(select (CONVERT(VARCHAR(10),YEAR(sa_date))+'年'+CONVERT(VARCHAR(10),MONTH(sa_date))+'月') from pos_sale where sa_id=sl.sal_sa_id)as sa_month --销售月份
FROM    pos_saleList AS sl WITH (NOLOCK)
INNER JOIN b_goodsinfo AS bg WITH (NOLOCK) ON sl.sal_gi_id = bg.gi_id

LEFT JOIN b_goodsruleset AS bg2 WITH (NOLOCK) ON sl.sal_sku_id = bg2.gss_id

LEFT JOIN b_unit AS bu WITH (NOLOCK) ON bg.gi_unit = bu.ut_id

LEFT JOIN pos_storageInfo fd3 WITH (NOLOCK) ON sl.sal_st_id = fd3.sei_id

WHERE   sl.sal_status = 1
go

