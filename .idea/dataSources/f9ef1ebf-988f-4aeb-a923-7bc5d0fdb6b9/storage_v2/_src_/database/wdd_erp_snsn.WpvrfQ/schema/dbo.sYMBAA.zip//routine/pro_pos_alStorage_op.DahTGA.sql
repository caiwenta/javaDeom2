CREATE PROC [dbo].[pro_pos_alStorage_op]
    @all_box_num INT = 0 ,
    @all_pm VARCHAR(500) = '' ,
    @al_id INT = 0 ,  --主键  
    @al_erp_id INT = 0 ,
    @all_erp_id INT = 0 ,
    @al_sh_id INT = 0 ,  --店铺主键 
    @al_no VARCHAR(50) = '' ,  --单据号 
    @al_date DATETIME = '2014-10-24' , --调拨日期   
    @al_cp_do INT = 0 ,--公司调拨标识 1为公司帮店铺做的调拨
    @al_get_sh_id INT = 0 , --调入店铺主键   
    @al_st_id INT = 0 , --仓库主键
    @al_order_man INT = 0 , --制单人主键   
    @al_add_man INT = 0 , --添加人主键 
    @al_add_time DATETIME = '2014-10-24' , --添加时间 
    @al_update_man INT = 0 , --修改人主键 
    @al_update_time DATETIME = '2014-10-24' , --修改时间  
    @al_audit_man INT = 0 , --审核人主键 
    @al_audit_time DATETIME = '2014-10-24' , --审核时间 
    @al_remark VARCHAR(50) = '' , --备注 
    @all_id INT = 0 , --主键  
    @all_al_id INT = 0 , --调拨单主键 
    @all_gi_id INT = 0 , --商品主键 
    @all_sku_id INT = 0 , --商品sku主键 
    @all_num INT = 0 , --数量 
    @all_retail_price DECIMAL(9, 2) = 0 , --零售价 
    @all_discount DECIMAL(9, 2) = 0 , --折率 
    @all_stock_price DECIMAL(9, 2) = 0 ,  --进货价 
    @all_money DECIMAL(9, 2) = 0 ,  --金额
    @all_gift INT = 0 ,  --是否获赠  
    @all_remark VARCHAR(50) = '' ,  --备注  
    @all_add_time DATETIME = '2014-10-24' ,  --添加时间  
    @op_type VARCHAR(100) = '添加修改单据,明细' , --操作类型  
    @negative_inventory INT = 0 ,
    @result VARCHAR(100) = '' OUT , --结果  
    @savestr VARCHAR(MAX) = '' , --保存字符串
    @ids VARCHAR(MAX) = '' ,
	@ord_sn VARCHAR(100) = '', --网络ERP订单号
    @ord_no VARCHAR(100) = '', --网络订单号
	@isInsert INT = 0, --是否添加单据
	@orderguid VARCHAR(500)='', --唯一guid
	@al_source_id int=0
AS
    BEGIN
        DECLARE @old_sei_id INT= 0;
        DECLARE @new_sei_id INT= @al_st_id;
        DECLARE @sei_is_negative INT= 0;
        DECLARE @need_update INT = 0; --是否需要更新单据
        DECLARE @old_order_date DATETIME; --旧的单据日期
        DECLARE @old_order_date_is_changed INT = 0; --单据日期是否更改
        DECLARE @myprevTxt VARCHAR(50) = 'TB'; --凭证号前缀
        
        BEGIN TRAN
        SELECT  @sei_is_negative = sei_is_negative_inventory
        FROM    pos_storageInfo
        WHERE   sei_id = @al_st_id
	
        IF @op_type = '添加修改单据,明细'
            BEGIN
                IF @al_id = 0  --调拨主键  
                    BEGIN
						--添加单据
                        INSERT  INTO pos_alStorage
                                ( al_sh_id ,
                                  al_vo ,
                                  al_no ,
                                  al_date ,
                                  al_get_sh_id ,
                                  al_st_id ,
                                  al_add_man ,
                                  al_add_time ,
                                  al_update_man ,
                                  al_update_time ,
                                  al_status ,
                                  al_remark ,
                                  al_order_man ,
                                  ord_sn ,
								  ord_no ,
                                  al_erp_id ,
                                  al_cp_do,
								  al_source_id
	                            )
                        VALUES  ( @al_sh_id , --店铺主键
                                  NEWID() ,
                                  @al_no ,--单据号
                                  @al_date ,  --调拨日期
                                  @al_get_sh_id ,--调入店铺主键 
                                  @al_st_id ,  --仓库主键
                                  @al_add_man ,  --添加人主键
                                  @al_add_time ,--添加时间  
                                  @al_update_man ,  --修改人主键  
                                  @al_update_time , --修改时间  
                                  1 ,
                                  @al_remark , --备注  
                                  @al_order_man ,  --制单人主键  
                                  @ord_sn ,
								  @ord_no ,
                                  @al_erp_id ,
                                  @al_cp_do,
								  @al_source_id
	                            );
                        SET @al_id = SCOPE_IDENTITY();  --得到调拨主键
                        SET @all_al_id = @al_id;--调拨主键  
                        SET @isInsert = 1;
                    END
                ELSE
                    SET @need_update = 1;
                    
                IF EXISTS ( SELECT  1
                            FROM    pos_alStorageList AS jt
                            WHERE   jt.all_al_id = @al_id  --调拨主键
                                    AND jt.all_status = 1
                                    AND jt.all_add_time = @all_add_time  --添加时间
                                    AND jt.all_gi_id != @all_gi_id --商品主键
					)   --是否存在  调拨id为@al_id 的调拨名细
                    BEGIN
                        UPDATE  pos_alStorageList
                        SET     all_status = 0   --存在，就休息为不可用
                        WHERE   all_al_id = @al_id   --调拨主键
                                AND all_add_time = @all_add_time
                                AND all_status = 1
                                AND all_gi_id != @all_gi_id;
                        SET @all_id = 0;
                    END
	    
                DECLARE @savestr_item VARCHAR(MAX)= ''; --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
                DECLARE @start_int INT= 1; --起始数值,每次循环后递增
                DECLARE @end_int INT= 1; --终止数值
			
		 if @al_cp_do=2
		      begin

		    MERGE INTO pos_alStorageList AS ta
						USING
						(
			select
			number*purchase as all_money,--入库金额
			 k.*
			from (

		   SELECT 
				@al_id as all_al_id,
				inl_gi_id as gi_id, 
				inl_sku_id as sku_id,
				inl_pm as pm,
				inl_erp_id as erp_id,
				inl_gift as gift,
				inl_num AS number,
				(SELECT gs_discount FROM FnPosGoodsPrice(inl_gi_id,@al_get_sh_id)) as discount,
				(SELECT gs_marketprice FROM FnPosGoodsPrice(inl_gi_id,@al_get_sh_id)) as retailprice,
				(SELECT gs_purchase FROM FnPosGoodsPrice(inl_gi_id,@al_get_sh_id)) AS purchase,
				inl_status as orderstatus,
				inl_box_num as box_num
			FROM erp_instructionNoticeList
			WHERE inl_in_id=(SELECT io_in_id FROM erp_instructionObject WHERE io_id=@al_source_id) AND inl_status=1
			) as k



						) AS so on  ta.all_gi_id=so.gi_id AND ta.all_sku_id=so.sku_id and  ta.all_al_id=so.all_al_id and ta.all_status=1
						  WHEN MATCHED THEN  UPDATE
                           SET  
						   ta.all_num += so.number,
						   ta.all_money=((ta.all_num+so.number)*so.purchase)
						    WHEN NOT MATCHED THEN
                              INSERT
                                (all_al_id , all_gi_id , all_sku_id ,all_pm ,all_gift,all_erp_id ,
								all_num , 
								all_discount , --折扣
								all_retail_price , --零售价
								all_stock_price, --供货价
								all_money,--出库金额
								all_status ,
								all_box_num,
								all_add_time )
								 VALUES
							   (
                                   so.all_al_id ,
                                   so.gi_id ,
                                   so.sku_id ,
                                   so.pm ,
                                   so.gift ,
                                   so.erp_id ,
                                   so.number ,
                                   so.discount ,--折扣
                                   so.retailprice ,--销售价
                                   so.purchase ,--进货价
                                   so.all_money ,--进货金额
                                   so.orderstatus ,
                                   so.box_num ,
                                       (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
							           SELECT GETDATE() as nows,
                                      (SELECT TOP 1 all_add_time FROM pos_alStorageList WHERE all_gi_id=so.gi_id AND all_al_id=so.all_al_id) AS addtime) AS TT)
									  );

		 end
	     else if @orderguid=''
			  begin
                IF @savestr != '' 
                    BEGIN
                        SELECT  @end_int = ( LEN(@savestr) - LEN(REPLACE(@savestr, '|', '')) ) --得到明细数量,即要循环的次数
                    END
                WHILE @start_int <= @end_int
                    BEGIN
						--动态赋值
                        IF @savestr != ''
                            BEGIN                                          --被分串 分割符   取条几个
                                SET @savestr_item = dbo.Get_StrArrayStrOfIndex(@savestr, '|', @start_int);

                                IF ( RTRIM(LTRIM(@savestr_item)) = '' )
                                    BEGIN
                                        BREAK;
                                    END
                                ELSE
                                    BEGIN
                                        SET @all_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
                                        SET @all_gi_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));--商品主键
                                        SET @all_sku_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));--商品sku主键  
                                        SET @all_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));----数量  
                                        SET @all_retail_price = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5)); --零售价  
                                        SET @all_stock_price = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6));--进货价  
                                        SET @all_discount = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7));  --折率  
                                    END
                            END	


	   IF @all_id = 0
	    BEGIN

	     select @all_id=all_id, @all_num=all_num+ @all_num FROM pos_alStorageList jpsl WHERE all_al_id=@all_al_id AND all_gi_id= @all_gi_id  AND all_sku_id=@all_sku_id
	   
	    END
	    


                        IF @all_id = 0
                            BEGIN
                                INSERT  INTO pos_alStorageList   --添加调拨名细
                                        ( all_al_id ,
                                          all_gi_id ,
                                          all_sku_id ,
                                          all_num ,
                                          all_retail_price ,
                                          all_discount ,
                                          all_stock_price ,
                                          all_money ,
                                          all_gift ,
                                          all_remark ,
                                          all_status ,
                                          all_add_time ,
                                          all_box_num ,
                                          all_pm ,
                                          all_erp_id
	                                    )
                                VALUES  ( @all_al_id ,  --调拨单主键  
                                          @all_gi_id ,--商品主键  
                                          @all_sku_id ,--商品sku主键 
                                          @all_num ,--数量
                                          @all_retail_price ,  --零售价  
                                          @all_discount ,--折率  
                                          @all_stock_price ,--进货价  
                                          @all_stock_price * @all_num ,
                                          @all_gift ,--是否获赠  
                                          @all_remark ,--备注  
                                          1 ,
                                          @all_add_time ,
                                          @all_box_num ,
                                          @all_pm ,
                                          @all_erp_id
	                                    );
                                SET @all_id = SCOPE_IDENTITY();  --得到名细主键
                            END
                        ELSE
                            BEGIN
                                UPDATE  pos_alStorageList
                                SET     all_al_id = @all_al_id ,
                                        all_gi_id = @all_gi_id ,
                                        all_sku_id = @all_sku_id ,
                                        all_num = @all_num ,
                                        all_retail_price = @all_retail_price ,
                                        all_discount = @all_discount ,
                                        all_stock_price = @all_stock_price , --进货价  
                                        all_money = @all_stock_price * @all_num ,
                                        all_gift = @all_gift ,--是否获赠  
                                        all_remark = @all_remark ,--备注  
                                        all_box_num = @all_box_num ,
                                        all_pm = @all_pm ,
                                        all_erp_id = @all_erp_id
                                WHERE   all_id = @all_id
	   
                            END
                        SET @start_int = @start_int + 1;
                    END
		      end
		 else if @orderguid<>''
		      begin

			  MERGE INTO pos_alStorageList AS ta
						USING
						(
					    SELECT  @al_id as all_al_id, gi_id, sku_id,pm,gift,erp_id,
                        number,
						discount,--折扣
						retailprice,--零售价
                        purchase,--进货价
						number*purchase as all_money,--入库金额
						orderstatus,
						box_num
				FROM  erp_goodslisttemp WHERE orderguid = @orderguid 
						) AS so on  ta.all_gi_id=so.gi_id AND ta.all_sku_id=so.sku_id and  ta.all_al_id=so.all_al_id and ta.all_status=1
						  WHEN MATCHED THEN  UPDATE
                           SET  
						   ta.all_num += so.number,
						   ta.all_money=((ta.all_num+so.number)*so.purchase)
						    WHEN NOT MATCHED THEN
                              INSERT
                                (all_al_id , all_gi_id , all_sku_id ,all_pm ,all_gift,all_erp_id ,
								all_num , 
								all_discount , --折扣
								all_retail_price , --零售价
								all_stock_price, --供货价
								all_money,--出库金额
								all_status ,
								all_box_num,
								all_add_time )
								 VALUES
							   (
                                   so.all_al_id ,
                                   so.gi_id ,
                                   so.sku_id ,
                                   so.pm ,
                                   so.gift ,
                                   so.erp_id ,
                                   so.number ,
                                   so.discount ,--折扣
                                   so.retailprice ,--销售价
                                   so.purchase ,--进货价
                                   so.all_money ,--进货金额
                                   so.orderstatus ,
                                   so.box_num ,
                                       (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
							           SELECT GETDATE() as nows,
                                      (SELECT TOP 1 all_add_time FROM pos_alStorageList WHERE all_gi_id=so.gi_id AND all_al_id=so.all_al_id) AS addtime) AS TT)
									  );

			exec pro_setGoodsPurchasePrice @oo_id=@al_id,@wt=5;
			  end 
		
		
		exec pro_update_unique_time_source '调拨',@al_id
      END
	


        IF @op_type = '审核单据'
            BEGIN
                IF @al_sh_id = 0
                    OR @al_st_id = 0
                    BEGIN
                        SELECT  @al_st_id = al_st_id ,
                                @al_sh_id = al_sh_id
                        FROM    pos_alStorage
                        WHERE   al_id = @al_id;--得到仓库id
                    END	

                SELECT  @al_st_id = al_st_id
                FROM    pos_alStorage
                WHERE   al_id = @al_id; --得到仓库id

                UPDATE  pos_alStorage
                SET     al_status = 2 ,
                        al_audit_man = @al_update_man ,
                        al_audit_time = GETDATE()
                WHERE   al_id = @al_id
                        AND al_sh_id = @al_sh_id;
            END
	
        IF @op_type = '总部审核单据'
            BEGIN
                SELECT  @al_st_id = al_st_id
                FROM    pos_alStorage
                WHERE   al_id = @al_id;--得到仓库id

                UPDATE  pos_alStorage
                SET     al_status = 3 ,
                        al_audit_man = @al_update_man ,
                        al_audit_time = GETDATE()
                WHERE   al_id = @al_id
                        AND al_sh_id = @al_sh_id;
            END
	
        IF @op_type = '取消审核单据'
            BEGIN
                IF @al_sh_id = 0
                    OR @al_st_id = 0
                    BEGIN
                        SELECT  @al_st_id = al_st_id ,
                                @al_sh_id = al_sh_id
                        FROM    pos_alStorage
                        WHERE   al_id = @al_id;--得到仓库id
                    END	
	   
                UPDATE  pos_alStorage
                SET     al_status = 1
                WHERE   al_id = @al_id
                        AND al_sh_id = @al_sh_id;
            END
	
        IF @op_type = '全部审核'
            BEGIN
                DECLARE @sql NVARCHAR(MAX)= 'UPDATE pos_alStorage SET al_status = 3 , al_audit_man ='
                SET @sql += CONVERT(VARCHAR(100), @al_update_man);
                SET @sql += ',al_audit_time =GETDATE() ' + 'WHERE al_id in( '
                SET @sql = @sql + @ids + ')';
	
                EXEC sp_executesql @sql
            END
 
        IF @op_type = '全部取消审核'
            BEGIN
                DECLARE @sql2 NVARCHAR(MAX)= 'UPDATE pos_alStorage SET al_status = 1 , al_audit_man ='''''
                SET @sql2 += 'WHERE al_id in( '
                SET @sql2 = @sql2 + @ids + ')';
	
                EXEC sp_executesql @sql2
            END
 
        IF @op_type = '删除单据'
            BEGIN
                IF @al_sh_id = 0
                    OR @al_st_id = 0
                    BEGIN
                        SELECT  @al_st_id = al_st_id ,
                                @al_sh_id = al_sh_id
                        FROM    pos_alStorage
                        WHERE   al_id = @al_id; --得到仓库id
                    END	

                SELECT  @old_sei_id = al_st_id ,
                        @al_st_id = al_st_id
                FROM    pos_alStorage
                WHERE   al_id = @al_id;

                UPDATE  pos_alStorage
                SET     al_status = 0
                WHERE   al_id = @al_id
                        AND al_sh_id = @al_sh_id;
            END
	
        IF @op_type = '删除明细'
            BEGIN
                UPDATE  pos_alStorageList
                SET     all_status = 0
                WHERE   all_id = @all_id;
            END
	
        IF @op_type = '批量删除明细'
            BEGIN
                SELECT  @old_sei_id = al_st_id
                FROM    pos_alStorage
                WHERE   al_id = @al_id;
	      
                UPDATE  pos_alStorageList
                SET     all_status = 0
                WHERE   all_al_id = @all_al_id
                        AND all_add_time = @all_add_time
                        AND all_gi_id = @all_gi_id;
	    
                IF NOT EXISTS ( SELECT  1
                                FROM    pos_alStorageList AS jt
                                WHERE   jt.all_al_id = @all_al_id
                                        AND jt.all_status = 1 )
                    BEGIN
                        UPDATE  pos_alStorage
                        SET     al_status = 0
                        WHERE   al_id = @all_al_id
                                AND al_sh_id = @al_sh_id;
                    END
            END
	
        IF ( @op_type = '添加修改单据,明细'
             OR @need_update = 1
             OR @op_type = '修改单据'
           )
            AND @isInsert != 1
            BEGIN
				--得到旧的单据日期
                SELECT  @old_order_date = jt.al_date
                FROM    pos_alStorage AS jt
                WHERE   jt.al_id = @al_id;

                IF @old_order_date != @al_date
                    BEGIN
                        SET @old_order_date_is_changed = 1;
                    END
	    
                SELECT  @old_sei_id = al_st_id
                FROM    pos_alStorage
                WHERE   al_id = @al_id;
	      
                UPDATE  pos_alStorage
                SET     al_sh_id = @al_sh_id ,
                        al_no = @al_no ,
                        al_date = @al_date ,
                        al_get_sh_id = @al_get_sh_id ,
                        al_st_id = @al_st_id ,
                        al_update_man = @al_update_man ,
                        al_update_time = @al_update_time ,
                        al_remark = @al_remark ,
                        al_order_man = @al_order_man
                WHERE   al_id = @al_id
                        AND al_sh_id = @al_sh_id;
	    
                IF ( SELECT fd.al_status
                     FROM   pos_alStorage fd
                     WHERE  fd.al_id = @al_id
                   ) = 0
                    BEGIN
                        UPDATE  pos_alStorage
                        SET     al_status = 1
                        WHERE   al_id = @al_id
                                AND al_sh_id = @al_sh_id;
                    END    
            END
	
        SET @old_order_date_is_changed = 0;

        IF EXISTS ( SELECT  1
                    FROM    pos_alStorage jos
                    WHERE   ISNULL(jos.ord_sn, '') != ''
                            AND jos.al_id = @al_id
                            AND CHARINDEX('网络订单', jos.al_remark) != 0 )
            BEGIN
                SET @old_order_date_is_changed = 1;
            END
	
        IF @isInsert = 1
            OR @old_order_date_is_changed = 1
            BEGIN
				--凭证号生成
				--更新凭证号 
                DECLARE @tableName VARCHAR(50) = 'pos_alStorage'
                DECLARE @idField VARCHAR(50) = 'al_id'
                DECLARE @idValue INT = @al_id;
                DECLARE @dateField VARCHAR(50) = 'al_date'
                DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @al_date, 23)
                DECLARE @noField VARCHAR(50) = 'al_vo'
                DECLARE @prevTxt VARCHAR(50) = @myprevTxt
                DECLARE @outno VARCHAR(100) = ''
                DECLARE @while INT = 0;

                WHILE @while = 0
                    BEGIN
						--得到凭证号
                        EXECUTE [pro_gen_orderNo] @tableName, @idField, @idValue, @dateField, @dateValue, @noField, @prevTxt, @outno OUTPUT, @al_sh_id
	        
                        BEGIN TRY
	        				--更新
                            UPDATE  pos_alStorage
                            SET     al_vo = @outno ,
                                    pzone = dbo.Get_StrArrayStrOfIndex(@outno, '-', 1) ,
                                    pztwo = dbo.Get_StrArrayStrOfIndex(@outno, '-', 2) ,
                                    pzthree = dbo.Get_StrArrayStrOfIndex(@outno, '-', 3)
                            WHERE   al_id = @al_id
                                    AND al_sh_id = @al_sh_id;
	        				--更新成功,赋值,结束循环
                            SET @while = 1;
                        END TRY
                        BEGIN CATCH
                            PRINT '';
                        END CATCH
                    END
            END
	
        IF @op_type != '审核单据'
            AND @op_type != '取消审核单据'
            BEGIN

                EXEC [dbo].[pro_pos_mergeStockLog_pos_alstorage] 
				@tsl_sh_id = @al_sh_id, 
				@negative_inventory = 
				@negative_inventory, 
				@old_sei_id = @old_sei_id,
                @new_sei_id = @new_sei_id,
				@id=@al_id  

                IF @@ERROR <> 0
                    BEGIN
                        SET @result = '';
                        IF @@TRANCOUNT > 0
                            ROLLBACK TRAN;
                        RETURN 1
                    END
            END
	

	 --   IF @al_cp_do = 2
		--BEGIN
		    
		--	PRINT '更新订单状态';
		--	update erp_instructionObject 
		--				set io_upstatus=1,
		--					io_sys_senderdate=getdate(),
		--					io_send_vo=(select al_vo from pos_alStorage where al_id=@al_id)
		--	WHERE io_id = @al_source_id

		--end
	    
		exec pro_instructionstate @orderid=@al_id ,@type=3;

        IF @@ERROR <> 0
            BEGIN
                SET @result = '0';
                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN;
            END
        ELSE
            BEGIN
                IF @isInsert = 1
                    BEGIN
                        SET @result = CONVERT(VARCHAR(50), @al_id);
                    END
                ELSE
                    BEGIN
                        IF @op_type = '添加修改单据,明细'  and @orderguid=''
                            BEGIN
                                SET @result = CONVERT(VARCHAR(50), @all_id);
                            END
                        ELSE
                            BEGIN
                                SET @result = '1';
                            END
                    END

                IF @@TRANCOUNT > 0
                    COMMIT TRAN;
            END
    END
go

