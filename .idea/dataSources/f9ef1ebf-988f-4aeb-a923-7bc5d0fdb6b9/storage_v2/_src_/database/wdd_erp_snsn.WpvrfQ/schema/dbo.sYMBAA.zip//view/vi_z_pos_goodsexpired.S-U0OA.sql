CREATE VIEW [dbo].[vi_z_pos_goodsexpired]
	AS


SELECT 
(CASE WHEN shelflife<>0 THEN CONVERT(varchar,CONVERT(DECIMAL(10,0),(((remainderdays*0.1)/(shelflife*0.1))*100)))+'%' ELSE '' END) AS percentagedays, 
 (SELECT  sh_cp_id FROM pos_shop AS ps WHERE ps.sh_id=ty.sh_id ) AS sh_company,  
   * FROM
(
SELECT isnull(DateDiff (Day,GETDATE(),expdate),0) AS remainderdays,* FROM
(	
SELECT 
ebn.productiondate,
ebn.expirationdate AS expdate,
isnull(ebn.shelflife,0) AS shelflife,
bg.gi_id,
bg.gi_skuid,
bg.gi_name,bg.gi_code,bg.gi_barcode,
bg.gi_retailprice,
bg.gi_purchase,
bg.gi_costprice,
bg.gi_shelflife,
ps.sh_name,
ps.sh_id,
bs.sei_id,bs.sei_name,bs.sei_is_tb,
bg.gi_erp_id,
ss.* 
FROM(

SELECT 
st_gi_id as si_giid,
st_st_id as si_seiid,
st_sh_id ,
sum(st_num) as gnum,
MAX (add_time) AS si_indate,
max(st_pm) as st_pm
FROM dbo.pos_stockInfobatch
GROUP BY st_gi_id,st_st_id,st_sh_id,st_pm

) ss
INNER JOIN dbo.pos_storageInfo  AS bs WITH (NOLOCK) ON  ss.si_seiid = bs.sei_id 
INNER JOIN dbo.b_goodsinfo AS bg WITH (NOLOCK) ON  ss.si_giid = bg.gi_id
INNER JOIN pos_shop as ps WITH (NOLOCK) ON  ps.sh_id=ss.st_sh_id
LEFT JOIN erp_batchnumber AS ebn WITH (NOLOCK) ON ebn.bn_giid = bg.gi_id AND ebn.bn_pm=ss.st_pm
) AS sf
) AS ty
go

