CREATE VIEW [dbo].[v_z_pos_sale_detail]
AS
    SELECT  '' AS specname ,--暂时为空  
            ( CASE WHEN rulenum.gd_row_number IS NULL THEN '无'
                   ELSE 'spec' + CONVERT(VARCHAR, rulenum.gd_row_number)
              END ) AS spec2 ,
            ( CASE WHEN rulenum.gd_row_number IS NULL THEN ''
                   ELSE 'spec' + CONVERT(VARCHAR, rulenum.gd_row_number)
              END ) AS specno ,
            rulenum.gd_row_number ,
            salist.* ,
            rulenum.gd_code AS rulecode ,
            rulenum.gd_code AS sizecode ,
            colorrule.gd_code AS colorcode
    FROM    ( SELECT    ISNULL(grl.gss_no, '') AS gss_no ,--规格编码,
                        ISNULL(grl.gs_name, '') AS gs_name ,--商品规格
                        grl.colorgroupname AS colorgroupname ,
                        grl.colorname AS color ,
                        grl.specngroupname AS specngroupname ,
                        grl.specname AS spec ,
                        ISNULL(grl.colorid, 0) AS colorid ,
                        ISNULL(grl.specid, 0) AS size ,
                        ISNULL(grl.specngroupid, 0) AS specid ,
                        ( sal_retail_price * sal_num ) AS sal_retail_money , --零售金额
                        ( CASE WHEN sal_sku_id > 0 THEN gs_costprice
                               ELSE gi_costprice_z
                          END ) AS gi_costprice ,
                        ( ( CASE WHEN sal_sku_id > 0 THEN gs_costprice
                                 ELSE gi_costprice_z
                            END ) * sal_num ) gi_costprice_money ,--成本金额
                        sal.*
              FROM      ( SELECT    st.sal_id ,
                                    sal_customprice ,--调价名称 
									(CASE WHEN ge.sa_ac_names!='' THEN ge.sa_ac_names
									      ELSE STUFF(( SELECT ', ' + ac_name 
													   FROM pos_active WITH (NOLOCK) 
													   WHERE ac_id IN (select sal_acid from pos_saleList WHERE sal_sa_id=sa_id)
												FOR XML PATH('')), 1, 1, '') END)sa_ac_names,--活动名称
                                    --ge.sa_ac_names ,--活动名称
                                    ps.sh_company ,
                                    ps.sh_erp_id AS erp_id ,
                                    gi.gi_id ,
                                    gi.gi_skuid ,--规格id
                                    gi.gi_brandsid ,
                                    ( SELECT gb_name FROM s_goodsbrand WITH (NOLOCK) WHERE gb_id = gi.gi_brandsid
                                    ) AS gb_name ,--品牌
                                    st.sal_gi_id ,
                                    gi.gi_attribute_parentids ,
                                    gi.gi_attribute_ids ,
                                    gi.gi_typesid ,
                                    gi.gi_types ,
                                    gi.gi_type1 ,
                                    gi.gi_type2 ,
                                    gi.gi_type3 ,
                                    gi.gi_type4 ,
                                    ISNULL(( SELECT gc_name FROM s_goodsclass WITH (NOLOCK) WHERE gc_id = gi.gi_type1
                                           ), '') AS gc_name1 ,
                                    ISNULL(( SELECT gc_name FROM s_goodsclass WITH (NOLOCK) WHERE gc_id = gi.gi_type2
                                           ), '') AS gc_name2 ,
                                    ISNULL(( SELECT gc_name FROM s_goodsclass WITH (NOLOCK) WHERE gc_id = gi.gi_type3
                                           ), '') AS gc_name3 ,
                                    ISNULL(( SELECT gc_name FROM s_goodsclass WITH (NOLOCK) WHERE gc_id = gi.gi_type4
                                           ), '') AS gc_name4 ,
                                    STUFF(( SELECT ', ' + vl_no FROM pos_salevoucher psv WITH (NOLOCK) WHERE psv.sa_id = ge.sa_id
                                          FOR
                                            XML PATH('')
                                          ), 1, 1, '') vl_no , --代金券券号
                                    ge.sa_id ,
                                    ge.sa_salman ,
                                    ge.sa_salmanname ,
                                    ge.sa_vo ,--凭证号
                                    ge.sa_no ,--单据号
									--CONVERT(varchar(7),ge.sa_date,120) AS sa_month , --销售月份
                                    ( CONVERT(VARCHAR(10), YEAR(ge.sa_date)) + '年' + CONVERT(VARCHAR(10), MONTH(ge.sa_date)) + '月' ) AS sa_month , --销售月份
                                    CONVERT (VARCHAR(10), ge.sa_date, 120) AS sa_date ,--销售日期
                                    sg.sei_name ,--仓库
                                    ps.sh_id ,
                                    ge.sa_sh_id ,
                                    ISNULL(ps.sh_name, '') AS sa_sh_id_txt ,
                                    ISNULL(ps.sh_name, '') AS sh_name ,--店铺
                                    ISNULL(ps.sh_no, '') AS sh_no ,--店铺代号
                                    gi.gi_code ,--商品编号
                                    gi.gi_name ,--商品名称
                                    gi.gi_barcode ,--商品条形码
									--营业员
                                    st.sal_list_man st_id ,
									--pscs.st_id ,
                                    pscs.st_st_id ,
                                    CASE WHEN st.sal_is_return = 1
                                              OR st.sal_is_change = 1 THEN -ABS(sal_num)
                                         ELSE sal_num
                                    END AS num ,--规格数量
                                    ( CASE WHEN sa_cashmoney <> 0 THEN '现金支付,'
                                           ELSE ''
                                      END + CASE WHEN sa_storedmoney <> 0 THEN '储值卡,'
                                                 ELSE ''
                                            END + CASE WHEN sa_alipaymoney <> 0 THEN '支付宝,'
                                                       ELSE ''
                                                  END + CASE WHEN sa_weixinmoney <> 0 THEN '微信支付,'
                                                             ELSE ''
                                                        END + CASE WHEN sa_bankmomey <> 0 THEN '刷卡,'
                                                                   ELSE ''
                                                              END ) AS sa_paytype ,--支付方式
                                    ge.sa_me_id ,
                                    ISNULL(( SELECT me_name FROM pos_memberInfo AS pmi WHERE (me_id = ge.sa_me_id)
                                           ), '零售') AS me_name ,--客户
                                    ( SELECT me_card FROM pos_memberInfo WHERE me_id = ge.sa_me_id
                                    ) AS me_card ,--客户卡号
                                    CASE WHEN ge.sa_me_id > 0 THEN '是'
                                         ELSE '否'
                                    END AS vip ,
                                    pscs.st_st_id AS sa_co_man_txt ,
                                    pscs.st_st_id AS sal_list_man_txt ,
                                    ISNULL(ge.sa_get_in_num, 0) AS sa_get_in_num , --获得积分 
                                    ISNULL(ge.sa_current_vo, 0) AS sa_current_vo , --现有积分 
                                    ui.ut_name AS gi_unit ,  --单位
                                    ui.ut_name ,--单位
                                    ISNULL(st.sal_retail_price, 0) AS sal_retail_price ,--零售价
                                    sal_discount = ISNULL(CASE WHEN sal_is_gift = 1
                                                                    OR sal_is_in = 1 THEN 0
                                                               ELSE st.sal_discount
                                                          END, 0) ,--折率
                                    ISNULL(st.sal_real_price, 0) AS sal_real_price ,--实售价
                                    sal_num = ISNULL(CASE WHEN st.sal_is_return = 1
                                                               OR st.sal_is_change = 1 THEN -ABS(sal_num)
                                                          ELSE sal_num
                                                     END, 0) ,
                                    sal_deduct_money = ISNULL(CASE WHEN sal_is_gift = 1
                                                                        OR sal_is_in = 1 THEN 0
                                                                   ELSE st.sal_deduct_money
                                                              END, 0) ,----扣除金额
                                    sal_money = ISNULL(CASE WHEN st.sal_is_return = 1
                                                                 OR st.sal_is_change = 1 THEN -( ( ABS(sal_num) * sal_real_price ) - sal_deduct_money )
                                                            WHEN st.sal_is_gift = 1
                                                                 OR st.sal_is_in = 1 THEN 0
                                                            ELSE ( ( sal_num * sal_real_price ) - sal_deduct_money )
                                                       END, 0) ,--金额
                                    ( CASE WHEN sal_is_return = 1
                                                OR sal_is_change = 1 THEN '退换货'
                                           ELSE '销售单'
                                      END ) saltype ,--单据类型
                                    sal_is_gift ,--赠送
                                    ( CASE WHEN sal_is_return = 1
                                                OR sal_is_change = 1 THEN -ABS(sal_paidmomey)
                                           WHEN sal_is_gift = 1
                                                OR sal_is_in = 1 THEN 0
                                           ELSE ( sal_paidmomey )
                                      END ) AS sal_paidmomey ,
                                    ( CASE WHEN sal_is_return = 1
                                                OR sal_is_change = 1 THEN 0
                                           WHEN sal_is_gift = 1
                                                OR sal_is_in = 1 THEN 0
                                           ELSE ( sal_paidmomey )
                                      END ) AS salpaidmomey ,--销售金额
                                    ( CASE WHEN sal_is_return = 1
                                                OR sal_is_change = 1 THEN -ABS(sal_paidmomey)
                                           WHEN sal_is_gift = 1
                                                OR sal_is_in = 1 THEN 0
                                           ELSE 0
                                      END ) AS returnsalpaidmomey ,--退货金额
                                    CASE WHEN st.sal_is_return = 1
                                              OR st.sal_is_change = 1 THEN 0
                                         ELSE sal_num
                                    END AS salnum ,--销售数量
                                    CASE WHEN st.sal_is_return = 1
                                              OR st.sal_is_change = 1 THEN -ABS(sal_num)
                                         ELSE 0
                                    END AS returnsalnum ,--退货数量
                                    sa_add_man ,
                                    sal_paiddiscount ,--赠送
                                    sal_is_change ,--换货
                                    sal_is_return ,--退货
                                    sal_is_in ,--积分兑换
                                    sal_remark ,--备注
                                    sal_remark2 ,--备注2
                                    sa_status ,--单据状态
                                    sg.sei_name AS sa_st_id_txt ,--仓库
                                    ge.sa_st_id ,
                                    sa_order_man_txt = ( SELECT si_name FROM dbo.b_stafftinfo
                                                              AS bs WITH (NOLOCK) WHERE si_id = sa_order_man
                                                       ) ,--经手人
                                    sa_add_man_txt = ( SELECT si_name FROM dbo.b_stafftinfo
                                                              AS bs WITH (NOLOCK) WHERE si_id = sa_add_man
                                                     ) ,--单据添加人
                                    sa_add_time ,--单据添加时间
                                    sa_update_man_txt = ( SELECT si_name FROM dbo.b_stafftinfo
                                                              AS bs WITH (NOLOCK) WHERE si_id = sa_update_man
                                                        ) ,--单据修改人
                                    sa_update_time ,--单据修改时间
                                    sa_audit_man_txt = ( SELECT si_name FROM dbo.b_stafftinfo
                                                              AS bs WITH (NOLOCK) WHERE si_id = sa_audit_man
                                                       ) ,--单据审核人
                                    sa_audit_time ,--单据审核时间
                                    sal_add_time ,
                                    st.sal_sku_id ,
                                    nt.ord_no AS oi_no ,
                                    sal_buyingteamid ,   --买手小组
                                    ( SELECT si_name FROM b_stafftinfo WITH (NOLOCK) WHERE si_id = sal_buyingteamid
                                    ) AS gi_buyingteam ,
                                    gi.gi_supplierid ,     --供应商
                                    ( SELECT si_name FROM b_supplierinfo WITH (NOLOCK) WHERE si_id = gi.gi_supplierid
                                    ) AS gi_supplier ,
                                    gi.gi_purchase , --进货价
                                    ( gi.gi_purchase * sal_num ) gi_purchase_money ,--进货金额 
                                    gi.gi_costprice AS gi_costprice_z
									,sa_remark
                          FROM      pos_sale AS ge WITH ( NOLOCK )
                          INNER JOIN pos_saleList AS st WITH ( NOLOCK ) ON st.sal_sa_id = ge.sa_id
                                                                           AND st.sal_status = 1
                                                                           AND ge.sa_status > 0
                          LEFT JOIN b_goodsinfo AS gi WITH ( NOLOCK ) ON gi.gi_id = st.sal_gi_id
                                                                         AND gi.gi_status = 1
                          LEFT JOIN b_unit AS ui WITH ( NOLOCK ) ON ui.ut_id = gi.gi_unit
                          LEFT JOIN pos_storageInfo AS sg WITH ( NOLOCK ) ON sg.sei_id = ge.sa_st_id
                          LEFT JOIN pos_shop AS ps WITH ( NOLOCK ) ON ps.sh_id = ge.sa_sh_id
                          LEFT JOIN pos_staffClassSet AS pscs WITH ( NOLOCK ) ON pscs.st_id = st.sal_list_man
                                                                                 AND pscs.st_status = 1
                          LEFT JOIN dbo.netorder_tbl AS nt WITH ( NOLOCK ) ON nt.ord_sa_id = ge.sa_id
                                                                              AND nt.ord_sa_id > 0
                        ) AS sal
              LEFT JOIN b_goodsruleset AS grl WITH ( NOLOCK ) ON grl.gss_id = sal_sku_id
            ) AS salist
    LEFT JOIN s_goodsruledetail AS rulenum WITH ( NOLOCK ) ON rulenum.gd_id = salist.size
    LEFT JOIN s_goodsruledetail AS colorrule WITH ( NOLOCK ) ON colorrule.gd_id = salist.colorid
go

