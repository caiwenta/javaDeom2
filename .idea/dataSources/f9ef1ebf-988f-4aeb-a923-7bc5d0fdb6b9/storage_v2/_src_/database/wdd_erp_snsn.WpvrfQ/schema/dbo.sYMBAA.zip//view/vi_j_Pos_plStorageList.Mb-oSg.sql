CREATE VIEW [dbo].[vi_j_Pos_plStorageList] AS 
SELECT     ppl_pl_id, ppl_gi_id, ppl_add_time, SUM(ppl_num) AS ppl_num, MIN(ppl_id) AS ppl_id, MAX(ppl_sku_id) AS ppl_sku_id, SUM(ppl_stock_num) 
                      AS ppl_stock_num,CONVERT(decimal(10,2), avg(ppl_discount)) as ppl_discount,CONVERT(decimal(10,2), avg(ppl_retail_price))  as ppl_retail_price,CONVERT(decimal(10,2), avg(ppl_stock_price)) as ppl_stock_price,SUM(ppl_money) as ppl_money
                      ,max(replace(ppl_pm,'*',',')) as ppl_pm,max(ppl_box_num) as  ppl_box_num
                      
                      
FROM         dbo.pos_plStorageList AS jt
WHERE     (ppl_status = 1)
GROUP BY ppl_pl_id, ppl_gi_id, ppl_add_time
go

