


CREATE view [dbo].[v_z_plStorage_detail]
as
select 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
rulenum.gd_code as sizecode,--尺码代号
pllist.*
from 
(

select 
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=isnull(grl.colorid,0))as colorcode,--颜色代号
isnull(grl.gss_no,'') as gss_no,--规格编码,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
pl.* 
from
(
select 

plStorag.*, 
sg.sei_name AS pl_st_id_txt,--仓库
sg.sei_name,--仓库
gi.gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_skuid,--规格组编号
ui.ut_name--单位

from(
SELECT
isnull((st.ppl_retail_price*st.ppl_num),0)ppl_zero_money,--零售金额
ge.pl_id,
st.ppl_pm,
st.ppl_id,
ge.pl_cp_id,
ge.pl_erp_id as erp_id,
ge.pl_vo,--凭证号
ge.pl_no,--单据号
         ----单据日期
 CONVERT(varchar(10),ge.pl_date,120) as pl_date ,
isnull(st.ppl_num,0) as num,--盈亏数

isnull(st.ppl_stock_num,0) as ppl_stock_num,--日期库存数量 
'' as ppl_new_num,  --实盘数量      
isnull(st.ppl_num,0) as ppl_num,--盈亏数量
isnull(st.ppl_retail_price,0) as ppl_retail_price,--零售价
isnull(st.ppl_discount,0) as ppl_discount,--折率
isnull(st.ppl_stock_price,0) as ppl_stock_price,--进货价
isnull(st.ppl_money,0) as ppl_money,--金额
isnull(st.ppl_box_num,0) as ppl_box_num,--箱数

ppl_add_time,--单据商品添加时间
pl_order_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_order_man ),--经手人
pl_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =pl_add_man ),--单据添加人
pl_add_time,--单据添加时间
pl_update_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_update_man ),--单据修改人
pl_update_time,--单据修改时间
pl_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_audit_man ),--单据审核人
pl_audit_time,--单据审核时间
pl_remark,--备注
pl_status,--单据状态
pl_st_id,
ppl_gi_id,
st.ppl_sku_id
FROM   j_plStorage ge
inner join  j_plStorageList st ON ge.pl_id = st.ppl_pl_id  AND st.ppl_status = 1 and ge.pl_status>0
UNION ALL



SELECT
isnull((gi_retailprice*js.sl_number),0)ppl_zero_money,--零售金额
jt.tsl_id,
js.sl_pm,
js.sl_id,
jt.tsl_cp_id,
jt.tsl_erp_id,
js.sl_order_no,
'',
CONVERT(varchar(10),jt.tsl_date,120) as ts_take_date ,
isnull((Case when sl_counttype=1 Then sl_number Else -sl_number END),0) AS num,--盈亏数
(sl_takenum-(CASE WHEN sl_counttype = 1 THEN sl_number ELSE -sl_number END))ppl_stock_num, --日期库存数量=实盘数-盈亏数
sl_takenum,   --实盘数量               
isnull((Case when sl_counttype=1 Then sl_number Else -sl_number END),0) AS ppl_num,--盈亏数
isnull(bg.gi_retailprice,0) as gi_retailprice,--零售价   
0, --折率
(CASE WHEN sl_skuid=0 THEN gi_purchase ELSE gs_purchase END ) AS  gs_purchase,
isnull((CASE WHEN sl_skuid=0 THEN(gi_purchase* (Case when sl_counttype=1 Then sl_number Else -sl_number End)) ELSE 
(gs_purchase* (Case when sl_counttype=1 Then sl_number Else -sl_number End))END ),0) as menoy, --金额
0, --箱数
jt.tsl_add_time,--单据商品添加时间
pl_order_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =jt.tsl_add_man ),--经手人
pl_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =jt.tsl_add_man ),--单据添加人
jt.tsl_add_time,--单据添加时间
pl_update_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = jt.tsl_update_man ),--单据修改人
jt.tsl_update_time,--单据修改时间
pl_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = jt.tsl_update_man ),--单据审核人
jt.tsl_update_time,--单据审核时间
jt.tsl_remark,--备注
jt.tsl_status,--单据状态
jt.tsl_st_id,
js.sl_giid,     
sl_skuid
FROM  j_stocklog_pal AS js
LEFT JOIN j_takeStorageLog jt  ON js.sl_elid=jt.tsl_id AND js.sl_eoid=jt.tsl_id AND jt.tsl_status<>0
LEFT JOIN b_goodsinfo AS bg ON js.sl_giid=bg.gi_id
LEFT JOIN b_goodsruleset AS bg2 ON bg2.gss_id=sl_skuid
--WHERE  sl_number!=0










) as plStorag
inner join b_goodsinfo gi on gi.gi_id=plStorag.ppl_gi_id and gi_status=1
inner join b_unit ui on ui.ut_id=gi.gi_unit 
inner join b_storageinfo sg on sg.sei_id=plStorag.pl_st_id--仓库
) as pl
left join b_goodsruleset  as grl on  grl.gss_id=ppl_sku_id

) as pllist
left join s_goodsruledetail rulenum on gd_id=pllist.size
go

