CREATE view vi_pos_stockSum_group
as 
SELECT shid,sh_name,COUNT(1) as gscount,sei_name,sid,SUM(gnum) as gnumsum 
FROM vi_pos_stockSumList_search group by  sh_name,shid,sei_name,sid
go

