CREATE VIEW [dbo].[vi_j_Pos_OgStorage_group_goods] AS 

SELECT

    bg.gi_erp_id,
	jt.ogl_og_id,
	jt.ogl_gi_id,
	jt.ogl_num,
	jt.ol_num,--发货数量
	jt.ogl_id,
	jt.ogl_money,
	jt.ogl_retail_money,
	jt.ogl_retail_price,
	jt.ogl_stock_price,
	jt.ogl_sku_id,
	CONVERT (
		VARCHAR (100),
		jt.ogl_add_time,
		25
	) AS ogl_add_time,
	jt.ogl_discount,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_cratebox,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bu.ut_name AS gi_unit,
	bu.ut_id AS gi_unit_id,
	jt.ogl_box_num,
	jt.ogl_pm,
	ISNULL(
		(
		
			SELECT
				SUM (
					dbo.pos_allocationList.all_num
				) AS Expr1
			FROM
				dbo.pos_allocation WITH (NOLOCK) 
			INNER JOIN dbo.pos_allocationList  WITH (NOLOCK) ON dbo.pos_allocation.al_id = dbo.pos_allocationList.all_al_id
			WHERE
				(
					dbo.pos_allocation.al_source_id = jt.ogl_og_id
				)
			AND (
				dbo.pos_allocation.al_status > 0
			)
			AND (
				dbo.pos_allocationList.all_status > 0
			)
			AND (
				dbo.pos_allocation.al_source = 5
			)
		),
		0
	) AS all_num,
	ISNULL(
		(
			SELECT
				SUM (
					dbo.j_purchaseStorageList.pll_num
				) AS Expr1
			FROM
				dbo.j_purchaseStorage WITH (NOLOCK) 
			INNER JOIN dbo.j_purchaseStorageList  WITH (NOLOCK) ON dbo.j_purchaseStorage.pl_id = dbo.j_purchaseStorageList.pll_pl_id
			WHERE
				(
					dbo.j_purchaseStorage.pl_source_id = jt.ogl_og_id
				)
			AND (
				dbo.j_purchaseStorage.pl_status > 0
			)
			AND (
				dbo.j_purchaseStorageList.pll_status > 0
			)
			AND (
				dbo.j_purchaseStorage.pl_source = 1
			)
		),
		0
	) AS pll_num
FROM
	dbo.vi_j_Pos_OgStorageList AS jt
INNER JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON jt.ogl_gi_id = bg.gi_id
left JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
go

