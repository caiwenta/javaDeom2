CREATE  VIEW [dbo].[vi_j_Pos_OgStorage_group_goods] AS 

SELECT

    bg.gi_erp_id,
	jt.ogl_og_id,
	jt.ogl_gi_id,
	jt.ogl_num,
	ogl_num_ed_ol as ol_num,--发货数量
	(select max(jesl.ogl_id) from pos_ogStorageList as jesl where jesl.ogl_og_id=jt.ogl_og_id and jesl.ogl_gi_id=jt.ogl_gi_id AND jesl.ogl_add_time=jt.ogl_add_time and jt.ogl_status>0) as ogl_id,
	jt.ogl_money,
	jt.ogl_retail_money,
	jt.ogl_retail_price,
	jt.ogl_stock_price,
	(case when isnull(bg.gi_skuid,'')='' then 0 else 1 end) as ogl_sku_id,
	CONVERT (
		VARCHAR (100),
		jt.ogl_add_time,
		25
	) AS ogl_add_time,
	jt.ogl_discount,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_cratebox,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bg.gi_sampleno,--样品号
	bu.ut_name AS gi_unit,
	bu.ut_id AS gi_unit_id,
	jt.ogl_boxbynum,
	(case when isnull(jt.ogl_boxbynum,0)=0 then 0 else ceiling(ogl_num/ogl_boxbynum) end) as ogl_box_num,
	jt.ogl_pm,
	ISNULL(ogl_num_ed,0) AS all_num,
	ISNULL(ogl_num_ed_pll,0) AS pll_num
FROM
	dbo.pos_ogStorageListMergeSum AS jt
left JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON jt.ogl_gi_id = bg.gi_id
left JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
go

