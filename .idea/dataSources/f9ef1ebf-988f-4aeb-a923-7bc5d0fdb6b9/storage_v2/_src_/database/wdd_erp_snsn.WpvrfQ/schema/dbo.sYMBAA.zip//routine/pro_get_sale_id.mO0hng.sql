CREATE Proc [dbo].[pro_get_sale_id]
@ord_id INT=0
as

SELECT top 1 fd.sa_net_sa_id FROM (
SELECT * FROM pos_sale_net psn WITH (NOLOCK) 
 WHERE psn.sa_net_ord_id=@ord_id
) AS fd INNER JOIN pos_sale ps ON fd.sa_net_sa_id=ps.sa_id
WHERE ps.sa_status>0 AND ps.sa_type=0
go

