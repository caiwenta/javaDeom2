CREATE VIEW [dbo].[vi_button_page_info] AS 
select * from s_buttoninfo as sb inner join s_pageInfo as spi on sb.bi_pi_id=spi.pi_id where sb.bi_status=1 and spi.pi_status=1
go

