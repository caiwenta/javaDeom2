CREATE PROCEDURE [dbo].[pro_pos_stocklog_pal_sku_search_tb]
    @takelogid int,
	@gi_id int,
	@sh_id int,
	@erp_id int
AS
SELECT
(p1.ppl_num*bg.gs_purchase) as tsl_log_money,
bg2.gi_name,
bg2.gi_code, 
bg.*,
p1.*
FROM b_goodsruleset  AS bg
LEFT JOIN (
	SELECT
	js.sl_elid,
	isnull(sl_pm,'') as sl_pm,
	0 box_num,
	1 discount,
	CONVERT(varchar(10),js.sl_order_date,120) as order_date ,

	sum(isnull((Case when sl_counttype=1 Then sl_number Else -sl_number END),0)) AS ppl_num,--盈亏数  
	sum((sl_takenum-(CASE WHEN sl_counttype = 1 THEN sl_number ELSE -sl_number END)))ppl_stocknum, --日期库存数量=实盘数-盈亏数
	sum(sl_takenum) as pll_takenum,   --实盘数量   
	          
	js.sl_giid,     
	sl_skuid
	FROM pos_stocklog_pal AS js
	WHERE js.sl_status>0 AND js.sl_shid=@sh_id AND js.sl_erp_id=@erp_id AND js.sl_elid=@takelogid and js.sl_giid= @gi_id
	GROUP BY js.sl_elid,js.sl_order_date,js.sl_giid,sl_skuid,isnull(sl_pm,'')
) AS p1
ON  bg.gi_id = p1.sl_giid
AND bg.gss_id = p1.sl_skuid 
LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;
go

