CREATE Proc [dbo].[pro_update_b_stockinfo_si_pddate]
@order_id INT=0,
@order_type VARCHAR(10)=''
AS


DECLARE @sid INT=0;
DECLARE @now DATETIME;

DECLARE @sh_id INT=0;
DECLARE @cp_id INT=0;
SET @now=GETDATE();
IF @order_id>0
BEGIN
 IF @order_type='pos入库'
 BEGIN
  IF NOT EXISTS (
  SELECT TOP 1 1 FROM pos_inStorageList pisl WHERE pisl.inl_in_id=@order_id
  AND pisl.inl_status>0 AND pisl.inl_pddate IS NOT NULL )
  BEGIN
   RETURN;
  END
  
  SELECT @sid=pis.in_st_id,@sh_id=pis.in_sh_id
    FROM pos_inStorage pis WHERE pis.in_id=@order_id
  
  SELECT pisl.inl_gi_id,MAX(pisl.inl_pddate) AS inl_pddate,MAX(pisl.inl_add_time) AS inl_add_time
    INTO #pos_inl_t
    FROM pos_inStorageList pisl WHERE pisl.inl_in_id=@order_id
    AND pisl.inl_status>0 AND pisl.inl_pddate IS NOT NULL 
    
    
    AND pisl.inl_gi_id NOT IN(
   SELECT DISTINCT fd.l_gi_id
     FROM b_stockinfo_ppdate_change_log fd WITH (NOLOCK)   WHERE fd.l_type=2 AND fd.l_order_id=@order_id
  )
  AND pisl.inl_add_time NOT IN(
   SELECT DISTINCT fd.l_list_add_time
     FROM b_stockinfo_ppdate_change_log fd WITH (NOLOCK)   WHERE fd.l_type=2 AND fd.l_order_id=@order_id
  )
    
  GROUP BY pisl.inl_gi_id
  
  INSERT INTO b_stockinfo_ppdate_change_log
  (
   
   l_gi_id,
   l_gen_date,
   l_type,
   l_add_time,l_order_id,l_list_add_time,l_sh_id
  )
  SELECT inl_gi_id,inl_pddate,2,@now,@order_id,inl_add_time,@sh_id FROM #pos_inl_t fd WITH (NOLOCK)   


  
  
  
  UPDATE pos_stockInfo
  SET st_pddate = fd2.inl_pddate,
   st_pddate_source =@order_type,
   st_pddate_update_time = @now,
   st_pddate_update_order_id = @order_id
  FROM pos_stockInfo fd,#pos_inl_t fd2
  WHERE fd.st_gi_id=fd2.inl_gi_id
  --fd.st_st_id=@sid AND 
 END
 IF @order_type='erp入库'
 BEGIN
  
  IF NOT EXISTS(
  SELECT TOP 1 1 FROM j_enterStorageList jesl WHERE jesl.el_eoid=@order_id AND jesl.el_status>0
  AND jesl.el_pddate IS NOT NULL
  )
  BEGIN
   RETURN;
  END
  
  
  
  SELECT @sid=jes.eo_siid,@cp_id=eo_cp_id
  FROM j_enterStorage jes 
  WHERE jes.eo_id=@order_id
  
  SELECT  jesl.el_siid,
  max(jesl.el_pddate) AS el_pddate,MAX(jesl.el_addtime) AS el_addtime
  INTO #eo_t
    FROM j_enterStorageList jesl 
  WHERE jesl.el_eoid=@order_id 
  AND jesl.el_status>0
  AND jesl.el_pddate IS NOT NULL
  AND jesl.el_siid NOT IN(
   SELECT DISTINCT fd.l_gi_id
     FROM b_stockinfo_ppdate_change_log fd WITH (NOLOCK)   WHERE fd.l_type=1 AND fd.l_order_id=@order_id
  )
  AND jesl.el_addtime NOT IN(
   SELECT DISTINCT fd.l_list_add_time
     FROM b_stockinfo_ppdate_change_log fd WITH (NOLOCK)   WHERE fd.l_type=1 AND fd.l_order_id=@order_id
  )
  GROUP BY el_siid
  
  
  
  
  INSERT INTO b_stockinfo_ppdate_change_log
  (
   
   l_gi_id,
   l_gen_date,
   l_type,
   l_add_time,
   l_order_id,
   l_list_add_time,l_cp_id
  )
  SELECT el_siid,el_pddate,1,@now,@order_id,el_addtime,@cp_id FROM #eo_t fd WITH (NOLOCK) 
  
  
  
  
  UPDATE b_stockinfo
  SET 
  si_pddate = fd2.el_pddate,
  si_pddate_source=@order_type,   si_pddate_update_time=@now,
  si_pddate_update_order_id=@order_id
  FROM b_stockinfo fd,#eo_t fd2
  WHERE fd.si_giid=fd2.el_siid
  --fd.si_seiid=@sid 
  --AND 

 END
END
go

