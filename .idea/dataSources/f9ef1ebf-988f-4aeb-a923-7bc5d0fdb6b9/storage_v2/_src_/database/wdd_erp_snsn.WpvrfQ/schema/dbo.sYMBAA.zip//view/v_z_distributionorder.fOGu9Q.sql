CREATE VIEW [dbo].[v_z_distributionorder]
	AS 
select 
(
CASE stocktype
WHEN 0 THEN (SELECT SUM(eo_num) FROM j_enterStorage jes WHERE jes.eo_source_id=vz.do_source_id AND jes.do_id=vz.do_id AND jes.eo_siid=vz.sei_id AND jes.eo_status<>0) 
WHEN 1 THEN (SELECT SUM(jos.oo_num) FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 2 THEN (SELECT SUM(jos.oo_num) FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 3 THEN (SELECT SUM(jos.oo_num) FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 5 THEN (SELECT sum(jms.mo_num) FROM j_moStorage AS jms WHERE jms.do_id=vz.do_id and jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
WHEN 8 THEN (SELECT SUM(jos.oo_num) FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 27 THEN (SELECT sum(jms.mo_num) FROM j_moStorage AS jms WHERE jms.do_id=vz.do_id and jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
end
) eo_num,

 (
 CASE stocktype
 WHEN 0 THEN (SELECT TOP 1 jes.eo_no FROM j_enterStorage jes WHERE jes.eo_source_id=vz.do_source_id AND jes.eo_source_type=1 AND jes.do_id=vz.do_id AND jes.eo_siid=vz.sei_id )
 WHEN 1 THEN (SELECT TOP 1 jos.oo_no FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
 WHEN 2 THEN (SELECT TOP 1 jos.oo_no FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
 WHEN 3 THEN (SELECT TOP 1 jos.oo_no FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
 WHEN 5 THEN (SELECT TOP 1 jms.mo_vo  FROM j_moStorage AS jms WHERE jms.do_id=vz.do_id and jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
 WHEN 8 THEN (SELECT TOP 1 jos.oo_no FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
 WHEN 27 THEN (SELECT TOP 1 jms.mo_vo  FROM j_moStorage AS jms WHERE jms.do_id=vz.do_id and jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
 end
 ) eo_no,
CONVERT(VARCHAR(10), (
CASE stocktype
WHEN 0 THEN (SELECT TOP 1 CONVERT(varchar(100), jes.eo_entrydate, 23) FROM j_enterStorage jes WHERE jes.eo_source_id=vz.do_source_id AND jes.eo_source_type=1 AND jes.do_id=vz.do_id AND jes.eo_siid=vz.sei_id ) 
WHEN 1 THEN (SELECT TOP 1 jos.oo_entrydate FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 2 THEN (SELECT TOP 1 jos.oo_entrydate FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 3 THEN (SELECT TOP 1 jos.oo_entrydate FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 5 THEN (SELECT TOP 1 jms.mo_date  FROM j_moStorage AS jms WHERE jms.do_id=vz.do_id and jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
WHEN 8 THEN (SELECT TOP 1 jos.oo_entrydate FROM j_outStorage jos WHERE jos.do_id=vz.do_id and jos.oo_source_id=vz.do_source_id AND jos.oo_status<>0 )
WHEN 27 THEN (SELECT TOP 1 jms.mo_date  FROM j_moStorage AS jms WHERE jms.do_id=vz.do_id and jms.mo_source_id=vz.do_source_id and jms.mo_source_type>0 AND jms.mo_status>0 )
end
), 120) eo_entrydate,
(SELECT pl_ci_id FROM j_purchaseStorage jps  WHERE jps.pl_status<>0 AND jps.pl_id=do_source_id ) AS ci_id, 
vz.*,
vz.do_applyqty AS dol_applyqty,
vz.do_inspectionnum AS inspectionnum,
(do_applyqty-do_inspectionnum) AS differencenum
from
(

select
    edi.do_id,
	edi.warehousingtype as stocktype,
	edi.do_vo,
	--0:入库　1:出库　3:盘点 4：移动移仓
	(
case edi.warehousingtype
when 0 then (SELECT  top 1 pl_pltype FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
when 1 then 0
when 3 then (
case (SELECT  top 1 al_source FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
		when 4 then 0
		when 6 then 0
		else 1 
		end)
WHEN 5 THEN 0
when 8 then 0
when 27 then (
CASE (SELECT top 1 pa.mo_type FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id) WHEN 0 then 1 WHEN 1 THEN 4 ELSE 0 end
)
else
	edi.warehousingtype
end
) as warehousingtype,

(
   case edi.warehousingtype
   when 27 then (SELECT top 1 pa.mo_locationid FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id)
   else 0 end
) as locationid,


(case edi.warehousingtype 
when 0 then
			(case (SELECT  top 1 pl_pltype FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
			      when 0 then  '入库单'  else  '供应商退货'  end
			)
when 1 then '分公司退货'
when 3 then(case (SELECT  top 1 al_source FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
		    when 3 then '店铺退货单' 
		    when 4 then '客户退货单'
		    when 6 then '分公司退货'
            else '出库单' end
)
WHEN 5 THEN '移仓入库单'
when 8 then '店铺退货单'
when 27 THEN  CASE (SELECT top 1 pa.mo_type FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id) WHEN 0 then '移仓出库单' WHEN 1 THEN  '移仓单' ELSE '移仓出库单' end  
else '盘点'
end
) as typename,
(
case edi.warehousingtype 
when 0 then (SELECT top 1 pl_vo FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
when 1 then (SELECT top 1 jps.eo_no FROM j_enterStorage jps WHERE jps.eo_id=edi.do_source_id)
when 3 then (SELECT top 1 al_vo FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
WHEN 5 then (SELECT top 1 mo_vo FROM j_moStorage AS jms  WHERE jms.mo_source_type=1 AND jms.mo_id=edi.do_source_id )
when 8 then (SELECT top 1 pa.in_vo FROM pos_inStorage pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT top 1 pa.mo_vo FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id )
end
) as do_no,
(
case edi.warehousingtype 
when 0 then (SELECT top 1 pl_date FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
when 1 then (SELECT top 1 jps.eo_entrydate FROM j_enterStorage jps WHERE jps.eo_id=edi.do_source_id)
when 3 then (SELECT top 1 al_date FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
WHEN 5 then (SELECT top 1 mo_date FROM j_moStorage AS jms  WHERE jms.mo_source_type=1 AND jms.mo_id=edi.do_source_id )
when 8 then (SELECT top 1 pa.in_date FROM pos_inStorage pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT top 1 pa.mo_date FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id )
end
)  AS do_date,
bsi.sei_name,
bsi.sei_code,

--对象名称（单位）
(case edi.warehousingtype 
when 0 then (SELECT top 1 pl_ci_id_txt FROM v_z_purchaseStorage_detail jps WHERE jps.pl_id=edi.do_source_id)
when 1 THEN (SELECT top 1 (SELECT cp_name FROM companyinfo c WHERE c.cp_id=jps.eo_cp_id) FROM v_z_enterStorage jps WHERE jps.eo_id=edi.do_source_id)
when 3 then (SELECT top 1 subname FROM v_z_allocation_detail pa WHERE pa.al_id=edi.do_source_id)
WHEN 5 then (SELECT top 1 mo_out_st_id_txt FROM v_z_moStorage_detail AS jms  WHERE  jms.mo_id=edi.do_source_id )
when 8 then (SELECT top 1 pa.sh_name FROM v_z_pos_inStorage_detail pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT sei_name FROM b_storageinfo WHERE sei_id=(SELECT top 1 pa.mo_in_st_id FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id))
end
) as subname,
edi.sei_id,
edi.do_source_id,
edi.do_status,
edi.do_addtime,
edi.cp_id,
edi.do_applyqty,
edi.do_inspectionnum,
edi.erp_id,
(SELECT si_name FROM b_stafftinfo bs WHERE bs.si_id=do_man) as do_man


FROM erp_distributionorder AS edi
left join b_storageinfo as bsi on bsi.sei_id=edi.sei_id
where edi.do_status>0

) as vz
go

