CREATE TRIGGER [dbo].[trg_c_inoutlist_update] ON [dbo].[c_inoutlist]
    AFTER UPDATE
AS
    BEGIN
        IF UPDATE(iol_row_num)
            BEGIN
                RETURN;
            END

        DECLARE @bk_id INT= 0;
        DECLARE @iol_rumoney DECIMAL(10, 2);
        DECLARE @iol_chumoney DECIMAL(10, 2);
        DECLARE @cha DECIMAL(10, 2);
        DECLARE @iol_id INT= 0;
        DECLARE @iol_itid INT= 0;
        DECLARE @iol_ciid INT= 0;
        DECLARE @iol_status INT= 0;
    
        SELECT  @bk_id = bk_id ,
                @iol_status = iol_status ,
                @iol_ciid = iol_ciid ,
                @iol_rumoney = iol_rumoney ,
                @iol_chumoney = iol_chumoney ,
                @iol_id = iol_id ,
                @iol_itid = iol_itid
        FROM    INSERTED
		--序号
        UPDATE  c_inoutlist
        SET     iol_row_num = rix.rowNum
        FROM    c_inoutlist iol ,
                ( SELECT    iol_id ,
                            ROW_NUMBER() OVER ( ORDER BY iol_indate, iol_id ) AS rowNum
                  FROM      c_inoutlist
                  WHERE     iol_status > 0
                            AND bk_id = @bk_id
                ) AS rix
        WHERE   iol.iol_id = rix.iol_id;
		--删除,账款跟着删除
        IF @iol_status = 0
            BEGIN
                UPDATE  c_fundorder
                SET     fo_status = 0
                WHERE   fo_source_id = @iol_id;
            END
        ELSE
            BEGIN
                IF ( SELECT TOP 1
                            fo_bs
                     FROM   c_fundorder
                     WHERE  fo_source_id = @iol_id
                   ) = 'X'
                    BEGIN
                        SET @cha = ISNULL(@iol_rumoney, 0) - ISNULL(@iol_chumoney, 0);
                    END
                ELSE
                    BEGIN
                        SET @cha = ISNULL(@iol_chumoney, 0) - ISNULL(@iol_rumoney, 0);
                    END

                UPDATE  c_fundorder
                SET     fo_thiyetmoney = @cha
                WHERE   fo_source_id = @iol_id;
            END
    END
go

