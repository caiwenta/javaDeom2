CREATE PROC [dbo].[pro_netorder_tbl_ord_status_update_after] @ord_id INT --订单ID
AS
    BEGIN
	   		------------------------------------
			--用途：发货生产单据
			------------------------------------
        DECLARE @ord_status INT = 0;
        DECLARE @ord_saletype VARCHAR(50) = '';
        DECLARE @ord_sale_erp_sid INT = 0; --销售门店id
        DECLARE @ord_sendtype VARCHAR(50) = '';
        DECLARE @ord_send_erp_sid INT = 0;
        DECLARE @ord_erp_id INT = 0;
        DECLARE @ord_sending INT; --发货状态，1发货中，2发货成功
        DECLARE @oo_addman INT = 0;
        DECLARE @now DATETIME= GETDATE();
        DECLARE @ord_oc_id INT = 0;
        DECLARE @ord_orderdate VARCHAR(50) = CONVERT(VARCHAR(50), GETDATE(), 23);
        DECLARE @oc_client_id INT = 0; --客户主键
        DECLARE @oc_stock_id INT = 0; --仓库主键
        DECLARE @ord_no VARCHAR(100);--网络订单号
        DECLARE @ord_sn VARCHAR(100);                
        DECLARE @ord_fromtype VARCHAR(50)= '';	
        DECLARE @result VARCHAR(500) = '';
        DECLARE @ROLLBACK_msg VARCHAR(500) = '';
	
        SELECT  @ord_status = ord_status ,

                @ord_sending = ord_sending ,
                @ord_id = ord_id ,

                @ord_saletype = ord_saletype ,--销售类型
                @ord_sale_erp_sid = ord_sale_erp_sid ,--销售方ID

                @ord_sendtype = ord_sendtype ,--发货方类型
                @ord_send_erp_sid = ord_send_erp_sid ,--发货方ID

                @ord_erp_id = ord_erp_id ,
                @ord_no = ord_no ,
                @ord_sn = ord_sn ,
                @ord_fromtype = ord_fromtype ,
                @ord_oc_id = ord_oc_id
        FROM    netorder_tbl WITH ( NOLOCK )
        WHERE   ord_id = @ord_id

        SET @ord_fromtype = LTRIM(RTRIM(@ord_fromtype));
	
        IF @ord_fromtype = 'storerule'
            BEGIN
                DECLARE @new_id INT= 0;
		
                SELECT TOP 1
                        @new_id = nog_id
                FROM    netordergoods_tbl WITH ( NOLOCK )
                WHERE   ord_sn = @ord_sn;
		
                EXEC pro_netordergoods_tbl_insert_after @new_id = @new_id, @type = '补货'
                RETURN;
            END
	
        SELECT  @oc_client_id = oc_client_id ,
                @oc_stock_id = oc_stock_id
        FROM    m_orderchannel WITH ( NOLOCK )
        WHERE   oc_id = @ord_oc_id;

        IF @ord_status = 4
            BEGIN
					  --取消库存锁定
                UPDATE  netorder_occupy_tbl
                SET     o_status = 0 ,
                        o_update_time = GETDATE() ,
                        o_status_int = @ord_status
                WHERE   o_ord_id = @ord_id
                        AND o_status <> 0;

                IF @@ROWCOUNT > 0
                    EXEC pro_update_occupy_num @id = @ord_id;
            END

        DECLARE @is_node_to_store INT = 0;
		     --需要生成销售单	
        IF @ord_saletype = 'node' AND @ord_sendtype = 'store'
            SET @is_node_to_store = 1;

        IF @ord_sendtype = 'node' AND @is_node_to_store = 0 AND @ord_status = 4
            AND NOT EXISTS (SELECT 1 FROM j_outStorage WHERE oo_status > 0 AND oo_di_id = @ord_id AND oo_type = 1)
            BEGIN
                --仓库
                EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'send', 'node', @ord_send_erp_sid

                IF @oc_stock_id = 0 
                    BEGIN
                        SET @ROLLBACK_msg = '未设置网络订单仓库';
                        GOTO theEnd;
                    END
				--得到添加人
                SELECT TOP 1
                        @oo_addman = si_id
                FROM    b_stafftinfo WITH ( NOLOCK )
                WHERE   si_cp_id = @ord_send_erp_sid
                        AND si_isdel = 1
				--添加单据
                DECLARE @oo_id INT = 0;
				--事务开始
                BEGIN TRAN

                INSERT  INTO j_outStorage
                        ( oo_ciid ,
                          oo_siid ,
                          oo_no ,
                          oo_manual ,
                          oo_entrydate ,
                          oo_itid ,
                          oo_type ,
                          oo_status ,
                          oo_takemanid ,
                          oo_cost ,
                          oo_freight ,
                          oo_express ,
                          oo_expressno ,
                          oo_remark ,
                          oo_source_type ,
                          oo_source_id ,
                          oo_addman ,
                          oo_addtime ,
                          oo_lastmanid ,
                          oo_auditdate ,
                          oo_updatemam ,
                          oo_updatetime ,
                          oo_num ,
                          oo_realmoney ,
                          oo_totalmoney ,
                          oo_sh_id ,
                          oo_cp_id ,
                          oo_di_id ,
                          oo_jytype ,
                          oo_to_cp_id ,
                          oo_erp_id
	                    )
                VALUES  ( @oc_client_id ,
                          @oc_stock_id ,
                          NEWID() ,
                          '' ,
                          '2004-01-02' ,
                          0 ,
                          1 ,
                          1 ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          '网络订单' ,
                          0 ,
                          0 ,
                          @oo_addman ,--发货人
                          GETDATE() ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          @ord_send_erp_sid ,
                          @ord_id ,
                          0 ,
                          0 ,
                          @ord_erp_id
	                    )
                SET @oo_id = SCOPE_IDENTITY();
					  --添加明细
                INSERT  INTO j_outStorageList
                        ( ol_eoid ,
                          ol_siid ,
                          ol_skuid ,
                          ol_number ,
                          ol_realmoney ,
                          ol_discount ,
                          ol_remark ,
                          ol_unit ,
                          ol_costprice ,
                          ol_addtime ,
                          ol_erp_id ,
                          ol_status
	                    )
                        SELECT  @oo_id AS ol_eoid ,
                                gi.gi_id ,
                                sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id
                                              ELSE 0
                                         END ,
                                nog.nog_buynumber ,
                                ( nog.nog_buynumber * nog.nog_actualprice ) AS ol_realmoney ,
                                1 AS gi_purchase_discount ,
                                '' AS ol_remark ,
                                nog.nog_marketprice ,
                                nog.nog_actualprice ,
                                ord.ord_addtime ,
                                ord.ord_erp_id ,
                                1 AS ol_status
                        FROM    netordergoods_tbl nog WITH ( NOLOCK )
                                INNER JOIN netorder_tbl ord WITH ( NOLOCK ) ON nog.ord_sn = ord.ord_sn
                                INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                             AND ord.ord_erp_id = gi.gi_erp_id
                                LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gi.gi_id = gss.gi_id
                                                                                AND nog.nog_skucode = gss.gss_no
                        WHERE   ord.ord_id = @ord_id
                                AND gi.gi_status = 1
                                AND nog_servstatus <> 2
					  --调用存储过程生成出库单
                EXEC pro_outStorage_op @ol_box_num = 0, @ol_pm = '', @oo_id = @oo_id, @oo_ciid = @oc_client_id, @oo_sh_id = 0, @oo_siid = @oc_stock_id,
                    @oo_takemanid = 0, @oo_remark = '网络订单', @oo_entrydate = @ord_orderdate, @oo_lastmanid = 0, @oo_itid = 0, @oo_type = 1, @oo_status = 1,
                    @oo_manual = '', @oo_jytype = 0, @oo_updatemam = @oo_addman, @ol_id = NULL, @ol_siid = NULL, @ol_number = NULL, @ol_discount = NULL,
                    @ol_realmoney = NULL, @ol_remark = NULL, @ol_unit = NULL, @ol_costprice = NULL, @ol_addtime = NULL, @ol_skuid = NULL, @ol_source_id = NULL,
                    @oo_cp_id = @ord_send_erp_sid, @oo_di_id = NULL, @ol_source_add_time = NULL, @oo_erp_id = @ord_erp_id, @ol_erp_id = @ord_erp_id,
                    @not_in_ids = NULL, @savestr = NULL, @oo_to_cp_id = NULL, @negative_inventory = 1, @op_type = '修改单据', @result = @result OUT

                IF @result = '0' OR @@ERROR <> 0
                    BEGIN
                        SET @ROLLBACK_msg = '生成出库单失败';
                        GOTO theEnd;
                    END
                ELSE
                    IF @@TRANCOUNT > 0
                        COMMIT TRAN;
            END
        ELSE
            IF ( @ord_saletype = 'store' OR @is_node_to_store = 1 ) AND @ord_status = 4
                AND NOT EXISTS ( SELECT 1
                                 FROM   pos_sale_net psn WITH ( NOLOCK )
                                        INNER JOIN pos_sale ps WITH ( NOLOCK ) ON psn.sa_net_sa_id = ps.sa_id
                                 WHERE  psn.sa_net_ord_id = @ord_id AND ps.sa_status > 0 AND ps.sa_type = 0 )
                BEGIN
					--调拨单生成,自动入库审核
                    IF @ord_sale_erp_sid <> @ord_send_erp_sid AND @is_node_to_store = 0
                        BEGIN

							--生成调拨单到@ord_sale_erp_sid
                            EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'send', 'store', @ord_send_erp_sid
                            IF @oc_stock_id = 0
                                BEGIN
                                    SET @ROLLBACK_msg = '未设置发货方网络订单仓库';
                                    GOTO theEnd;
                                END
							--添加人
                            SELECT TOP 1
                                    @oo_addman = si_id
                            FROM    b_stafftinfo WITH ( NOLOCK )
                            WHERE   si_shop_id = @ord_send_erp_sid
                                    AND si_isdel = 1
              
                            DECLARE @al_id INT = 0;
							--事务开始	                    
                            BEGIN TRAN

                            INSERT  INTO pos_alStorage
                                    ( al_sh_id ,
                                      al_vo ,
                                      al_no ,
                                      al_date ,
                                      al_get_sh_id ,
                                      al_st_id ,
                                      al_order_man ,
                                      al_add_man ,
                                      al_add_time ,
                                      al_update_man ,
                                      al_update_time ,
                                      al_audit_man ,
                                      al_audit_time ,
                                      al_status ,
                                      al_remark ,
                                      al_get_to_cp_id ,
                                      ord_sn ,
                                      al_erp_id
	                                )
                            VALUES  ( @ord_send_erp_sid ,
                                      NEWID() ,
                                      '' ,
                                      '2004-01-02' ,
                                      @ord_sale_erp_sid ,
                                      @oc_stock_id ,
                                      0 ,
                                      @oo_addman ,
                                      GETDATE() ,
                                      @oo_addman ,
                                      GETDATE() ,
                                      @oo_addman ,
                                      GETDATE() ,
                                      1 ,
                                      '网络订单' ,
                                      0 ,
                                      @ord_no ,
                                      @ord_erp_id
	                                )
                            SET @al_id = SCOPE_IDENTITY();
							--添加明细
                            INSERT  INTO pos_alStorageList
                                    ( all_al_id ,
                                      all_gi_id ,
                                      all_sku_id ,
                                      all_num ,
                                      all_retail_price ,
                                      all_discount ,
                                      all_stock_price ,
                                      all_money ,
                                      all_gift ,
                                      all_remark ,
                                      all_status ,
                                      all_add_time ,
                                      all_erp_id
	                                )
                                    SELECT  @al_id AS al_id ,
                                            gi.gi_id ,
                                            sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id
                                                          ELSE 0
                                                     END ,
                                            nog.nog_buynumber ,
                                            gi.gi_retailprice ,
                                            1 AS gi_purchase_discount ,
                                            gi.gi_retailprice AS gi_retailpricec ,
                                            ( nog.nog_buynumber * gi.gi_retailprice ) AS all_money ,
                                            0 AS all_gift ,
                                            '' AS all_remark ,
                                            1 AS all_status ,
                                            @oo_addman AS all_add_time ,
                                            ord.ord_erp_id
                                    FROM    netordergoods_tbl nog WITH ( NOLOCK )
                                            INNER JOIN netorder_tbl ord WITH ( NOLOCK ) ON nog.ord_sn = ord.ord_sn
                                            INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                                         AND ord.ord_erp_id = gi.gi_erp_id
                                            LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gi.gi_id = gss.gi_id
                                                                                            AND nog.nog_skucode = gss.gss_no
                                    WHERE   ord.ord_id = @ord_id
                                            AND gi.gi_status = 1
                                            AND nog_servstatus <> 2
							--生成调拨单
                            EXEC pro_pos_alStorage_op @al_id = @al_id, @al_sh_id = @ord_send_erp_sid, @al_no = '', @al_date = @ord_orderdate,
                                @al_get_sh_id = @ord_sale_erp_sid, @al_st_id = @oc_stock_id, @al_order_man = 0, @al_add_man = @oo_addman, @al_add_time = @now,
                                @al_update_man = @oo_addman, @al_update_time = @now, @al_audit_man = @oo_addman, @al_audit_time = @now, @al_remark = '网络订单',
                                @all_id = NULL, @all_al_id = NULL, @all_gi_id = NULL, @all_sku_id = NULL, @all_num = NULL, @all_retail_price = NULL,
                                @all_discount = NULL, @all_stock_price = NULL, @all_money = NULL, @all_gift = NULL, @all_remark = NULL, @all_add_time = NULL,
                                @all_erp_id = @ord_erp_id, @al_erp_id = @ord_erp_id, @op_type = '修改单据', @negative_inventory = 1, @result = @result OUT,
                                @savestr = NULL, @ids = NULL, @ord_sn = @ord_sn , @ord_no = @ord_no

                            IF @result = '0' OR @@ERROR <> 0
                                BEGIN
                                    SET @ROLLBACK_msg = '生成发货方调拨单失败';
                                    GOTO theEnd;
                                END
                            ELSE
                                IF @@TRANCOUNT > 0
                                    COMMIT TRAN;
							--仓库
                            EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'send', 'store', @ord_sale_erp_sid
                            IF @oc_stock_id = 0
                                BEGIN
                                    SET @ROLLBACK_msg = '未设置销售方网络订单仓库';
                                    GOTO theEnd;
                                END
							--添加人
                            SELECT TOP 1
                                    @oo_addman = si_id
                            FROM    b_stafftinfo WITH ( NOLOCK )
                            WHERE   si_shop_id = @ord_sale_erp_sid
                                    AND si_isdel = 1
	            			--事务开始	                    
                            BEGIN TRAN
							--生成调拨入库单
                            EXEC pro_pos_inStorage_op @inl_box_num = NULL, @inl_pm = NULL, @in_id = 0, @in_sh_id = @ord_sale_erp_sid, @in_no = '',
                                @in_date = @ord_orderdate, @in_st_id = @oc_stock_id, @in_source = 2, @in_supplier_sh_id = @ord_send_erp_sid, @in_order_man = 0,
                                @in_update_man = @oo_addman, @in_update_time = @now, @in_add_man = @oo_addman, @in_add_time = @now, @in_audit_man = @oo_addman,
                                @in_audit_time = @now, @in_type = 0, @in_remark = '网络订单', @in_actual_num = 0, @in_source_id = @al_id, @in_erp_id = @ord_erp_id,
                                @inl_erp_id = @ord_erp_id, @inl_id = NULL, @inl_in_id = 0, @inl_gi_id = NULL, @inl_sku_id = NULL, @inl_num = NULL,
                                @inl_retail_price = NULL, @inl_discount = NULL, @inl_stock_price = NULL, @inl_money = NULL, @inl_sample_no = NULL,
                                @inl_gift = NULL, @inl_remark = NULL, @inl_add_time = NULL, @inl_source_id = NULL, @inl_source_add_time = NULL,
                                @op_type = '添加修改单据,明细', @negative_inventory = 1, @result = @result OUT, @savestr = ''
							--更新网络订单号
                            UPDATE  pos_inStorage
                            SET     ord_no = @ord_no
                            WHERE   in_source = 2
                                    AND in_source_id = @al_id
                                    AND in_sh_id = @ord_sale_erp_sid;
	            
                            IF @result = '0' OR @@ERROR <> 0
                                BEGIN
                                    SET @ROLLBACK_msg = '生成销售方调拨单失败';
                                    GOTO theEnd;
                                END
                            ELSE
                                IF @@TRANCOUNT > 0
                                    COMMIT TRAN;
                        END
					--发货门店ID
                    DECLARE @ord_sh_id INT = @ord_sale_erp_sid;
	        
                    IF @is_node_to_store = 1
                        SET @ord_sh_id = @ord_send_erp_sid;
					--仓库
                    EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'send', 'store', @ord_sh_id
                    IF @oc_stock_id = 0
                        BEGIN
                            SET @ROLLBACK_msg = '未设置发货方的网络订单仓库';
                            GOTO theEnd;
                        END
					--得到添加人
                    SELECT TOP 1
                            @oo_addman = si_id
                    FROM    b_stafftinfo WITH ( NOLOCK )
                    WHERE   si_shop_id = @ord_sh_id
                            AND si_isdel = 1
	        
                    DECLARE @gi_id INT = 0;
                    DECLARE @sku_id INT = 0;
                    DECLARE @nog_buynumber INT = 0;
                    DECLARE @gi_purchase_discount DECIMAL(10, 2) = 0;
                    DECLARE @gi_retailprice DECIMAL(10, 2) = 0;
                    DECLARE @gi_purchase DECIMAL(10, 2) = 0;
                    DECLARE @gi_comgoods DECIMAL(10, 2) = 0;
                    DECLARE @ord_addtime DATETIME;
                    DECLARE @sa_id INT = 0;
                    DECLARE @sa_add_time DATETIME= GETDATE();
                    DECLARE @old_ord_addtime DATETIME = GETDATE();
                    DECLARE @t2out DATETIME= GETDATE();
                    DECLARE @sa_paytype VARCHAR(100)= '';
					--事务开始	                    
                    BEGIN TRAN
					--游标
                    DECLARE sopcor CURSOR
                    FOR
                        ( SELECT	gi.gi_id ,
                                    sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id ELSE 0 END ,
                                    nog.nog_buynumber ,
                                    gi.gi_purchase_discount ,
                                    gi_retailprice = CASE WHEN CHARINDEX('现金支付', ord.ord_payway) != 0 THEN nog.nog_marketprice ELSE nog.nog_marketprice END ,
                                    gi_purchase = CASE WHEN CHARINDEX('现金支付', ord.ord_payway) != 0 THEN nog.nog_actualprice ELSE nog.nog_actualprice END ,
                                    ord.ord_addtime ,
                                    ord.ord_payway ,
                                    ord.ord_erp_id ,
									ISNULL(nog.nog_comgoods, 0) AS nog_comgoods
                          FROM      netordergoods_tbl nog WITH ( NOLOCK )
                                    INNER JOIN netorder_tbl ord WITH ( NOLOCK ) ON nog.ord_sn = ord.ord_sn
                                    INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                                 AND ord.ord_erp_id = gi.gi_erp_id
                                    LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gi.gi_id = gss.gi_id
                                                                                    AND nog.nog_skucode = gss.gss_no
                          WHERE     ord.ord_id = @ord_id
                                    AND gi.gi_status = 1
                                    AND nog_servstatus <> 2
                        )
                    OPEN sopcor
                    FETCH NEXT FROM sopcor INTO @gi_id, @sku_id, @nog_buynumber, @gi_purchase_discount, @gi_retailprice, @gi_purchase, @ord_addtime, @sa_paytype,
                        @ord_erp_id, @gi_comgoods
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            IF @old_ord_addtime = @ord_addtime
                                BEGIN
                                    SET @ord_addtime = GETDATE();
                                    SET @old_ord_addtime = @ord_addtime;
                                END
                            ELSE
                                SET @old_ord_addtime = @ord_addtime;
	            
                            EXEC pro_get_rand_time @t1 = @t2out, @t2out = @t2out OUT
				
                            SELECT  @ord_addtime = @t2out
	            
                            EXEC pro_pos_sale_temp_op @sal_id = 0, @sal_sa_id = @sa_id, @sal_gi_id = @gi_id, @sal_sku_id = @sku_id, @sal_num = @nog_buynumber,
                                @sal_retail_price = @gi_retailprice, @sal_discount = @gi_purchase_discount, @sal_list_man = @oo_addman,
                                @sal_real_price = @gi_purchase, @sal_add_time = @ord_addtime, @sa_id = @sa_id, @sa_sh_id = @ord_sh_id, @sa_co_man = @oo_addman,
                                @sa_date = @ord_orderdate, @sa_st_id = @oc_stock_id, @sa_add_man = @oo_addman, @sa_add_time = @sa_add_time, @sa_type = 0,
                                @sa_sa_type = 1, @sa_remark = '网络订单', @sal_erp_id = @ord_erp_id, @op_type = '添加修改单据,明细', @sa_paytype = @sa_paytype,
                                @sal_deduction = @gi_comgoods, @result = @result OUT
	            
                            IF @result = '0'
                                BREAK;
	            
                            IF @sa_id = 0
                                SET @sa_id = CONVERT(INT, @result);
	            
                            FETCH NEXT FROM sopcor INTO @gi_id, @sku_id, @nog_buynumber, @gi_purchase_discount, @gi_retailprice, @gi_purchase, @ord_addtime,
                                @sa_paytype, @ord_erp_id, @gi_comgoods
                        END
                    CLOSE sopcor
                    DEALLOCATE sopcor

                    IF @sa_id > 0
                        BEGIN
                            EXEC pro_pos_sale_temp_op @sa_id = @sa_id, @sa_sh_id = @ord_sh_id, @sa_co_man = @oo_addman, @sa_date = @ord_orderdate,
                                @sal_erp_id = @ord_erp_id, @sa_st_id = @oc_stock_id, @sa_type = 0, @sa_sa_type = 1, @sa_remark = '网络订单', @negative_inventory = 1,
                                @sa_paytype = @sa_paytype, @op_type = '修改单据', @result = @result OUT
							
							UPDATE  netorder_tbl SET [ord_sa_id]=@sa_id
							WHERE   ord_id = @ord_id

                            INSERT  INTO pos_sale_net
                                    ( sa_net_sa_id ,
                                      sa_net_ord_id ,
                                      sa_net_add_time
					                )
                            VALUES  ( @sa_id ,
                                      @ord_id ,
                                      GETDATE()
                                    );


							DECLARE @tdoc_xml VARCHAR(max)='{"orderid":"' + CONVERT(VARCHAR(50), @sa_id) + '","viewname":"v_z_pos_sale_detail","op_type":"网络订单"}';
							EXEC pro_apiqueue_op @tdoc_method = 'viewdatacuring', @tdoc_xml = @tdoc_xml;
                        END

                    IF @result = '0' OR @@ERROR <> 0
                        BEGIN
                            SET @ROLLBACK_msg = '发货生成POS销售单失败';
                            GOTO theEnd;
                        END
                    ELSE
                        IF @@TRANCOUNT > 0
                            COMMIT TRAN;
                END

        theEnd:
        IF @ROLLBACK_msg <> '' OR @@ERROR <> 0
            BEGIN
                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN;
                      
                UPDATE  netorder_tbl
                SET     ord_is_ok = 0 ,
                        ord_is_ok_msg = @ROLLBACK_msg
                WHERE   ord_id = @ord_id;
            END
        ELSE
            UPDATE  netorder_tbl
            SET     ord_is_ok = 1 ,
                    ord_is_ok_msg = ''
            WHERE   ord_id = @ord_id;
    END
go

