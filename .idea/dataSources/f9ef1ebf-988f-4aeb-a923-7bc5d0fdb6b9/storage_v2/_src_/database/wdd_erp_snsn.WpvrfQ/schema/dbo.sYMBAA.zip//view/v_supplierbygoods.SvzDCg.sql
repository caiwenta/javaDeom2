CREATE VIEW [dbo].[v_supplierbygoods]
AS
SELECT 
CONVERT(VARCHAR(100),sa_date,23) AS sa_date,gi_name,gi_code,gi_barcode,gi_supplierid,si_name,si_code,sum(sal_num) AS sal_num,si_erp_id,si_cp_id
FROM(
--销售
SELECT CONVERT(VARCHAR(100),ps.sa_date,23) AS sa_date,bg.gi_name,bg.gi_code,bg.gi_barcode,gi_supplierid,bs.si_name,bs.si_code,psl.sal_num,bs.si_erp_id,bs.si_cp_id FROM pos_sale AS ps
INNER JOIN pos_saleList AS psl ON psl.sal_sa_id=ps.sa_id AND ps.sa_status>0 AND ps.sa_date>0
INNER JOIN b_goodsinfo AS bg ON bg.gi_id=psl.sal_gi_id and bg.gi_supplierid>0
INNER JOIN b_supplierinfo AS bs ON bs.si_id=bg.gi_supplierid AND bs.si_status>0
UNION ALL
--出库
SELECT  CONVERT(VARCHAR(100),jos.oo_entrydate,23) AS oo_entrydate,bg.gi_name,bg.gi_code,bg.gi_barcode,gi_supplierid,bs.si_name,bs.si_code,josl.ol_number,bs.si_erp_id,bs.si_cp_id FROM j_outStorage AS jos
INNER JOIN j_outStorageList AS josl ON jos.oo_id=josl.ol_eoid AND jos.oo_status>0 AND jos.oo_ciid>0 AND josl.ol_status>0
INNER JOIN b_goodsinfo AS bg ON bg.gi_id=josl.ol_siid and bg.gi_supplierid>0
INNER JOIN b_supplierinfo AS bs ON bs.si_id=bg.gi_supplierid AND bs.si_status>0

) AS TT
GROUP BY sa_date,gi_name,gi_code,gi_barcode,gi_supplierid,si_name,si_code,si_erp_id,si_cp_id
go

