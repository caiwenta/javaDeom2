CREATE PROCEDURE [dbo].[pro_check_barcode]
    @gi_id int=0,
	@erpid int = 0,
	@barcode varchar(100)
AS
DECLARE @result VARCHAR(100) = '';
--返回1则表示可以不存在
SET @result = '1';
if(@gi_id=0)
begin
IF EXISTS(
          SELECT 1 FROM b_goodsruleset WHERE gss_erp_id=@erpid AND gss_no=@barcode AND gs_status>0
       )
    BEGIN
        SET @result = '条形码已存在!';
    END
ELSE IF EXISTS(
  	
  	SELECT 1 FROM b_goodsinfo bg WHERE bg.gi_erp_id=@erpid AND gi_code=@barcode and gi_status>0
       )
    BEGIN
        SET @result = '条形码已存在!';
END 
ELSE IF EXISTS(
  	
  	SELECT 1 FROM b_goodsinfo bg WHERE bg.gi_erp_id=@erpid AND gi_barcode=@barcode and gi_status>0 and gi_status>0
       )
    BEGIN
        SET @result = '条形码已存在!';
END    
ELSE IF EXISTS(
  	
  	SELECT 1 FROM b_goodsarcode bg WHERE bg.ga_erp_id=@erpid AND ga_barcode=@barcode
       )
    BEGIN
        SET @result = '条形码已存在!';
END 
end
else
 begin

IF EXISTS(
          SELECT 1 FROM b_goodsruleset WHERE gss_erp_id=@erpid AND gss_no=@barcode and gi_id<>@gi_id  AND gs_status>0
       )
    BEGIN
        SET @result = '条形码已存在!';
    END
ELSE IF EXISTS(
  	SELECT 1 FROM b_goodsinfo bg WHERE bg.gi_erp_id=@erpid AND gi_code=@barcode and gi_id<>@gi_id and gi_status>0
       )
    BEGIN
        SET @result = '条形码已存在!';
END 
ELSE IF EXISTS(
  	SELECT 1 FROM b_goodsinfo bg WHERE bg.gi_erp_id=@erpid AND gi_barcode=@barcode and gi_id<>@gi_id and gi_status>0
       )
    BEGIN
        SET @result = '条形码已存在!';
END    
ELSE IF EXISTS(
  	
  	SELECT 1 FROM b_goodsarcode bg WHERE bg.ga_erp_id=@erpid AND ga_barcode=@barcode and gi_id<>@gi_id
       )
    BEGIN
        SET @result = '条形码已存在!';
END 
end 
   
SELECT @result AS info
go

