CREATE VIEW dbo.vi_pos_fundsList_sum
AS
SELECT     ful_fu_id, SUM(ful_ensure_money) AS ful_ensure_money, SUM(ful_handsel_money) AS ful_handsel_money, SUM(ful_start_money) 
                      AS ful_start_money, SUM(ful_money) AS ful_money, SUM(ful_freight) AS ful_freight, SUM(ful_other_in_money) AS ful_other_in_money, 
                      SUM(ful_in_money) AS ful_in_money, SUM(ful_out_money) AS ful_out_money, SUM(ful_end_money) AS ful_end_money
FROM         dbo.pos_fundsList
WHERE     (ful_status > 0)
GROUP BY ful_fu_id
go

