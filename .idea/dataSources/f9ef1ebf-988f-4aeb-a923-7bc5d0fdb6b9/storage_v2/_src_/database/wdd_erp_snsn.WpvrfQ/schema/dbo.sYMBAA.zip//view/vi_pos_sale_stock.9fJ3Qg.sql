
CREATE VIEW [dbo].[vi_pos_sale_stock] AS 
SELECT 
(CASE WHEN rulenum.gd_row_number IS NULL THEN '无' ELSE  'spec' + CONVERT(VARCHAR,rulenum.gd_row_number) END) AS spec2,
 ps.sh_id,
       ps.sh_name,
	   bg.gi_id,
       bg.gi_name,
       bg2.gs_name,
        isnull(bg2.colorname,'无') as color,
       '' as specname,
       (case when bg2.gss_no is not null then bg2.gss_no else bg.gi_barcode end)as codes,
       bg2.gss_no,
        bg2.specid,
       bg.gi_typesid,
       bg.gi_attribute_ids,
       bg.gi_attribute_parentids,
       fd.gnum,
       bg.gi_code,
	   bg.gi_barcode,
       fd.[sid],
       sei_name,
	   sh_company
FROM   pos_shop                  AS ps
       INNER JOIN (
                SELECT fd.shid,
                       fd.gid,
                       fd.[sid],
                       fd.skuid,
                       SUM(fd.gnum)     AS gnum
                FROM   vi_pos_stockSum  AS fd
                GROUP BY
                       fd.shid,
                       fd.gid,
                       fd.skuid,
                       fd.[sid]
            )                    AS fd
            ON  ps.sh_id = fd.shid
       INNER JOIN b_goodsinfo    AS bg
            ON  fd.gid = bg.gi_id
       LEFT JOIN b_goodsruleset  AS bg2
            ON  fd.skuid = bg2.gss_id
            left join s_goodsruledetail as rulenum 
            on rulenum.gd_id=bg2.specid
            inner join pos_storageInfo psi on psi.sei_id=sid
go

