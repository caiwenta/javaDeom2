CREATE PROCEDURE [dbo].[pro_pos_mergeStockLog]
    @tsl_sh_id INT ,
    @negative_inventory INT = 0 ,
    @old_sei_id INT = 0 ,
    @new_sei_id INT = 0
AS
    EXEC pro_pos_mergeStockLog_check @tsl_sh_id = @tsl_sh_id, @negative_inventory = @negative_inventory, @old_sei_id = @old_sei_id, @new_sei_id = @new_sei_id
    
    IF @@ERROR != 0
        BEGIN
            DECLARE @ERROR_MESSAGE VARCHAR(100) = '';
            SELECT  @ERROR_MESSAGE = ERROR_MESSAGE();
            RAISERROR (@ERROR_MESSAGE, 16, 1, N'number', 5);
            RETURN;
        END
    BEGIN
        BEGIN TRAN
		
        DECLARE @now DATETIME = GETDATE();
		
		print N'删除变对明细'
		DELETE pos_stocklog where sl_shop_id= @tsl_sh_id;

		print N'重新计算变对明细'
		INSERT  pos_stocklog(
                                  sl_eoid ,
                                  sl_elid ,
                                  sl_seiid ,
                                  sl_shop_id ,
                                  sl_ciid ,
                                  sl_giid ,
                                  sl_skuid ,
                                  sl_type ,
                                  sl_counttype ,
                                  sl_number ,
                                  sl_addtime ,
                                  sl_updatetime ,
                                  sl_remark ,
                                  sl_status ,
                                  sl_order_no ,
                                  sl_order_date ,
                                  sl_order_add_time ,
								  sl_pm ,
								  sl_erp_id
		                        )
                    select        so.eoid ,
                                  so.elid ,
                                  so.[sid] ,
                                  so.shid ,
                                  so.cid ,
                                  so.gid ,
                                  so.skuid ,
                                  so.mytype ,
                                  so.countType ,
                                  so.gnum ,
                                  so.addtime ,
                                  @now ,
                                  so.myremark ,
                                  1 ,
                                  so.orderno ,
                                  so.order_date ,
                                  so.order_add_time ,
								  isnull(so.pm,'') ,
								  so.erp_id
           from vi_pos_stockList AS so where so.shid= @tsl_sh_id

		print N'合并库存'
        EXEC pro_pos_mergeStockSum @tsl_sh_id = @tsl_sh_id
		

        IF @@ERROR <> 0
            BEGIN
                ROLLBACK TRANSACTION
            END
        ELSE
            BEGIN
                IF @@TRANCOUNT > 0
                    COMMIT TRAN
            END
    END
go

