CREATE  VIEW [dbo].[v_z_outStorage_good]
AS

SELECT oo.*,
       (oo.sh_name + oo.ci_name+oo.cp_name) AS sh_ci_name ,--店铺&客户
       (oo.sh_no + oo.ci_code+oo.cp_code) AS sh_ci_code --店铺&客户代号  
FROM
(
SELECT  ge.oo_no ,--凭证号
		ge.oo_id ,
        ge.oo_manual ,--单据号
        CONVERT(VARCHAR(100),ge.oo_entrydate,23) AS oo_entrydate ,--出货日期
		(CONVERT(VARCHAR(10),YEAR(oo_entrydate))+'年'+CONVERT(VARCHAR(10),MONTH(oo_entrydate))+'月') AS oo_month , --月份
        ge.oo_cp_id ,
		(SELECT cp_code FROM [companyinfo] WHERE cp_id=ge.oo_cp_id) as oo_cp_code,
		(SELECT cp_name FROM [companyinfo] WHERE cp_id=ge.oo_cp_id) as oo_cp_name,
        sg.sei_id ,
        sg.sei_erp_id AS erp_id ,
        oo_erp_id,
        sg.sei_name ,--仓库
        (case when oo_ciid<>0 then 1 when oo_sh_id <>0 then 2 when oo_to_cp_id<>0 then 3 end)oo_object,--出库对象，1-客户  2-店铺  3-分公司
        ge.oo_ciid ,
        ISNULL(ci.ci_name,'') AS ci_name ,--客户
        ISNULL(ci.ci_code,'') AS ci_code ,--客户代号
		(select type_name from cors_type where type_id= ci.ci_flid) as ci_type,--客户分类
        ge.oo_sh_id ,
        ISNULL(ps.sh_name,'') AS sh_name ,--店铺
        ISNULL(ps.sh_name,'') AS oo_sh_id_txt ,
        ISNULL(ps.sh_no,'') AS sh_no ,--店铺代号
        ISNULL(ps.type,'') AS sh_type ,--店铺类型
		(
		CASE WHEN  ps.type = 1 THEN '加盟专卖店'
		     WHEN  ps.type = 2 THEN '联营专卖店'
			 WHEN  ps.type = 3 THEN '直营专卖店'
			 WHEN  ps.type = 4 THEN '托管专卖店'
			 WHEN  ps.type = 5 THEN '代理商'
			 WHEN  ps.type = 6 THEN '直营分公司'
		     WHEN  ps.type = 7 THEN '联营分公司'
			 WHEN  ps.type = 8 THEN '总公司'
			 WHEN  ps.type = 9 THEN '特价专卖店'
			 end
		) pstype,
        ps.sh_clientname ,
        ps.sh_attribute_ids ,
        ps.sh_attribute_parentids ,
        ge.oo_to_cp_id ,
        ISNULL(cp.cp_name,'') AS cp_name ,--分公司
        ISNULL(cp.cp_code,'') AS cp_code ,--分公司代号
        ISNULL(cp.cp_code,'') AS oo_to_cp_id_txt ,--分公司代号
               
		 oo_source_type,
         (CASE oo_source_type WHEN 1 THEN (SELECT  al_vo FROM  pos_allocation AS bs WITH ( NOLOCK ) WHERE   al_id = ol_source_id )
							  WHEN 2 THEN (SELECT eo_no FROM  j_enterStorage AS bs WITH ( NOLOCK ) WHERE  eo_id = ol_source_id )
							  WHEN 3 THEN (SELECT  in_vo FROM   pos_inStorage AS bs WITH ( NOLOCK ) WHERE  in_id = ol_source_id )
		 ELSE '' END ) AS al_vo ,
		 st.ol_source_id AS source_id ,
        oo_jytype ,--交易类型
		(CASE WHEN oo_jytype = 1 THEN '订货' 
		      WHEN oo_jytype = 2 THEN '补货' 
		      WHEN oo_jytype = 3 THEN '铺货' 
		      WHEN oo_jytype = 4 THEN '买断' END) oojytype,                              
        ISNULL(st.ol_gift,0) AS ol_gift ,--赠送
        (CASE WHEN ISNULL(st.ol_gift,0) = 0 THEN '否' ELSE '是' END) AS gift ,--赠送
        ge.oo_status ,--单据状态
		( CASE WHEN ge.oo_status = 1 THEN '未审核' WHEN ge.oo_status = 2 THEN '已审核' END ) as oostatus,
        oo_freight ,--垫付运费
        oo_cost ,--其他应收
        takeman ,    --经手人
        oo_addman_txt ,--单据添加人
        oo_addtime ,   --单据添加时间
        oo_updatemam_txt , --单据修改人
        oo_updatetime ,  --单据修改时间
        oo_lastman ,   --单据审核人
        oo_auditdate , --单据审核时间
        oo_remark , --备注
        fd.ord_no AS oi_no ,  --网络订单号
        ge.oo_io_logistics,   --指令单物流公司
        ge.oo_logistics_no,   --指令单物流单号
	   (SELECT in_vo FROM dbo.erp_instructionNotice AS eis WITH (NOLOCK) 
	            LEFT JOIN dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id where eio.io_id=oo_io_id)instru_vo, --指令单凭证号
		
        ol_addtime , --单据商品添加时间
        gi.gi_id ,
        st.ol_siid ,
        gi.gi_code ,--商品编号
        gi.gi_name ,--商品名称
        gi.gi_barcode ,--商品条形码
		gi.gi_sampleno,--样品号
        gi.gi_attribute_parentids ,
        gi.gi_attribute_ids ,
        gi.gi_typesid ,
        gi.gi_types ,
		gi.gi_type1,
		gi.gi_type2,
		gi.gi_type3,
		gi.gi_type4,
        gi.gi_skuid ,
        gi.gi_brands ,
        gi.gi_brandsid ,
        isnull((SELECT si_name FROM b_stafftinfo WHERE si_id=ol_buyingteamid),'') AS gi_buyingteam,--买手小组
        isnull((SELECT si_name FROM b_supplierinfo WHERE si_id=gi.gi_supplierid),'') AS gi_supplier,--供应商
        (SELECT (CASE WHEN si_royaltytype=1 THEN '现金供应商' 
                      WHEN si_royaltytype=2 THEN '代销供应商' end) FROM b_supplierinfo WHERE si_id=gi.gi_supplierid) AS si_royaltytype,--分润类型
        ui.ut_name ,--单位
        ui.ut_name AS gi_unit ,--单位
                      
        gi.gi_purchase,--商品表的进货价
        ISNULL(gi.gi_costprice,0) AS gi_costprice ,--成本价
        ISNULL(st.ol_unit,0) AS ol_unit ,--零售价
        ISNULL(st.ol_costprice,0) AS ol_costprice ,--供货价
        ISNULL(st.ol_discount,0) AS ol_discount ,--折率
	    st.discount,--出货价折扣
		st.supplyprice,--出货价
       (CASE WHEN st.supplyprice=0 THEN 0 ELSE CONVERT(DECIMAL(9,2), (st.ol_costprice/st.supplyprice)) END) AS realitydiscount,--实际折扣
                                                                                                                               
        ISNULL((st.ol_number * gi_purchase),0) AS gi_purchase_money ,--进货金额
		ISNULL((st.ol_number * gi.gi_costprice),0) AS gi_costprice_money ,--成本金额
        ISNULL((st.ol_number * st.ol_unit),0) AS ol_unit_money ,--零售金额
                                                                                                          
        ISNULL(st.ol_realmoney,0) AS ol_realmoney ,--合计金额
		ISNULL(st.ol_realmoney,0) AS realmoney ,--合计金额             
		ISNULL((CASE WHEN ge.oo_type = 1 THEN st.ol_realmoney ELSE 0 END),0) AS oo_realmoney ,--出库金额
		ISNULL((CASE WHEN ge.oo_type = 0 THEN st.ol_realmoney ELSE 0 END),0) AS oo_returnrealmoney ,--退货金额
                                          
        oo_type ,
        (CASE WHEN oo_type = 0 THEN '退货' WHEN oo_type = 1 THEN '出库' END) ootype ,  --单据类型                                                                                       
        ISNULL(st.ol_number,0) AS ol_number ,--数量
		ISNULL((CASE WHEN ge.oo_type = 1 THEN st.ol_number ELSE 0 END),0) AS oo_num ,--出库数量 
		ISNULL((CASE WHEN ge.oo_type = 0 THEN st.ol_number ELSE 0 END),0) AS oo_returnnum, --退货数量   
        
        
        ISNULL(st.ol_pm,'') as ol_pm ,--配码
        ISNULL(st.ol_boxbynum,0) AS ol_boxbynum , --数量/箱
        ISNULL(st.ol_box_num,0) AS ol_box_num, --箱数
		ISNULL((CASE WHEN ge.oo_type = 1 THEN st.ol_box_num ELSE 0 END),0) AS oo_box_num ,--出库箱数
		ISNULL((CASE WHEN ge.oo_type = 0 THEN st.ol_box_num ELSE 0 END),0) AS oo_box_returnnum --退货箱数  
  
 FROM   j_outStorage ge WITH (NOLOCK)
 INNER JOIN j_outStorageListMergeSum st WITH (NOLOCK) ON ge.oo_id = ol_eoid AND st.ol_status = 1
 LEFT JOIN b_goodsinfo gi WITH (NOLOCK) ON gi.gi_id = st.ol_siid AND gi_status = 1
 LEFT JOIN b_unit ui WITH (NOLOCK) ON ui.ut_id = gi.gi_unit
 LEFT JOIN b_storageinfo sg WITH (NOLOCK) ON ge.oo_siid = sg.sei_id
 LEFT JOIN b_clientinfo ci WITH (NOLOCK) ON ci.ci_id = ge.oo_ciid AND ci.ci_status = 1
 LEFT JOIN pos_shop ps WITH (NOLOCK) ON ps.sh_id = ge.oo_sh_id
 LEFT JOIN companyinfo cp WITH (NOLOCK) ON cp.cp_id = ge.oo_to_cp_id
 LEFT JOIN netorder_tbl fd WITH (NOLOCK) ON ge.oo_di_id = fd.ord_id
 WHERE ge.oo_status > 0 
  )oo
go

