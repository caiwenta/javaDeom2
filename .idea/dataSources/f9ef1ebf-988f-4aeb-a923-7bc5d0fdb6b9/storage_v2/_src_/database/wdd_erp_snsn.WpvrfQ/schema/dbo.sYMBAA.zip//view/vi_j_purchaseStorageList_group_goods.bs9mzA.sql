CREATE VIEW [dbo].[vi_j_purchaseStorageList_group_goods] AS 
SELECT
	jt.pll_pl_id,
	jt.pll_gi_id,
	jt.pll_num,
	jt.pll_stock_price,
	jt.pll_retail_price,
	jt.pll_discount,
	jt.pll_money,
	jt.pll_id,
	jt.pll_sku_id,
	CONVERT (
		VARCHAR (100),
		jt.pll_add_time,
		25
	) AS pll_add_time,
	jt.pll_status,
	jt.pll_integral,
	jt.pll_totalintegral,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_factoryprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bu.ut_name AS gi_unit,
	bu.ut_id AS gi_unit_id,
	jt.pll_box_num,
	jt.pll_pm,
	pll_pause_num AS pll_pause_num1,
	ISNULL(fd_1.el_number, 0) AS pll_num_ed,
	jt.pll_num - ISNULL(fd_1.el_number, 0) - ISNULL(jt.pll_pause_num, 0) AS pll_num_ding,
	jt.pll_num - (ISNULL(fd_1.el_number, 0)) - ISNULL(jt.pll_pause_num, 0) AS pll_num_do,
	jt.pll_num - (ISNULL(fd_1.el_number, 0)) - ISNULL(jt.pll_pause_num, 0) AS pll_num_end,
	ISNULL(
		(
			SELECT
				abs(SUM (fd2.el_number)) AS el_number
			FROM
				dbo.j_enterStorage AS fd WITH (NOLOCK)
			INNER JOIN dbo.j_enterStorageList AS fd2  WITH (NOLOCK) ON fd.eo_id = fd2.el_eoid
			AND fd.eo_source_type = 1 --AND fd.eo_source_id = jt.pll_pl_id
			AND fd2.el_status = 1
			AND fd.eo_status <> 0
			--AND fd.eo_type = 0
			AND fd2.el_source_id IN (
				SELECT
					jpsl.pll_id
				FROM
					j_purchaseStorageList jpsl
				WHERE
					jpsl.pll_pl_id = jt.pll_pl_id
			)
			AND fd2.el_source_add_time = jt.pll_add_time
		),
		0
	) AS rk_el_number,
	ISNULL(
		(
			SELECT
				SUM (fd2.el_number) AS el_number
			FROM
				dbo.j_enterStorage AS fd  WITH (NOLOCK)
			INNER JOIN dbo.j_enterStorageList AS fd2   WITH (NOLOCK) ON fd.eo_id = fd2.el_eoid
			AND fd.eo_source_type = 1
			AND fd.eo_source_id = jt.pll_pl_id
			AND fd2.el_status = 1
			AND fd.eo_status <> 0
			AND fd.eo_type = 1
			AND fd2.el_source_id IN (
				SELECT
					jpsl.pll_id
				FROM
					j_purchaseStorageList jpsl WITH (NOLOCK) 
				WHERE
					jpsl.pll_pl_id = jt.pll_pl_id
			)
			AND fd2.el_source_add_time = jt.pll_add_time
		),
		0
	) AS rkth_el_number,
	(
		SELECT
			fd.og_vo
		FROM
			pos_ogStorage fd WITH (NOLOCK) 
		WHERE
			fd.og_id = (
				SELECT
					MAX (fd.ogl_og_id)
				FROM
					pos_ogStorageList fd WITH (NOLOCK) 
				WHERE
					fd.ogl_add_time = jt.pll_source_add_time
			)
	) AS og_vo,

	 isnull((
	 SELECT ci_name FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = (select og_ci_id from pos_ogStorage where og_id= (select pl_source_id froM j_purchaseStorage where pl_id=jt.pll_pl_id)))
	 ) ,'')AS og_ci_id_txt,--客户名称

	 isnull((  SELECT ci_code FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = (select og_ci_id from pos_ogStorage where og_id= (select pl_source_id froM j_purchaseStorage where pl_id=jt.pll_pl_id))) 
	  ),'')AS og_ci_code_txt--客户代号
FROM
	dbo.vi_j_purchaseStorageList AS jt WITH (NOLOCK) 
INNER JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON jt.pll_status<>0 and jt.pll_gi_id = bg.gi_id
INNER JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
LEFT OUTER JOIN (
	SELECT
		--eo_source_id,
		el_siid,
		el_source_add_time,
		SUM (en_number) AS el_number
	FROM
		(
			SELECT
				jes.eo_id,
				jes.eo_ciid,
				jes.eo_siid,
				jes.eo_no,
				jes.eo_remark,
				jes.eo_entrydate,
				jes.eo_itid,
				jes.eo_type,
				jes.eo_status,
				jes.eo_totalmoney,
				jes.eo_couponmoney,
				jes.eo_realmoney,
				jes.eo_num,
				jes.eo_lastmanid,
				jes.eo_auditdate,
				jes.eo_addman,
				jes.eo_addtime,
				jes.eo_updateman,
				jes.eo_updatetime,
				jes.eo_manual,
				jes.eo_takemanid,
				jes.eo_cost,
				jes.eo_freight,
				jes.eo_express,
				jes.eo_expressno,
				jes.eo_source_type,
				jes.eo_source_id,
				jes.eo_cp_id,
				jes.eo_di_id,
				jes.eo_to_cp_id,
				jesl.el_id,
				jesl.el_eoid,
				jesl.el_siid,
				jesl.el_skuid,
				jesl.el_number,
				jesl.el_discount,
				jesl.el_realmoney,
				jesl.el_remark,
				jesl.el_unit,
				jesl.el_costprice,
				jesl.el_addtime,
				jesl.el_status,
				jesl.el_source_id,
				jesl.el_source_add_time,
				jesl.el_cp_id,
				jesl.el_di_id,
				jesl.el_box_num,
				jesl.el_pm,
				jesl.el_gift,
				(
					CASE jes.eo_type
					WHEN 1 THEN
						- jesl.el_number
					WHEN 0 THEN
						jesl.el_number
					ELSE
						0
					END
				) AS en_number
			FROM
				dbo.j_enterStorage AS jes WITH (NOLOCK) 
			INNER JOIN dbo.j_enterStorageList AS jesl  WITH (NOLOCK) ON jes.eo_id = jesl.el_eoid
			WHERE
				(jes.eo_status > 0)
			AND (jesl.el_status = 1)
			AND (jes.eo_source_type = 1)
		) AS aa
	GROUP BY
		--eo_source_id,
		el_siid,
		el_source_add_time
) AS fd_1 ON --jt.pll_pl_id = fd_1.eo_source_id
--AND 
jt.pll_gi_id = fd_1.el_siid
AND jt.pll_add_time = fd_1.el_source_add_time
go

