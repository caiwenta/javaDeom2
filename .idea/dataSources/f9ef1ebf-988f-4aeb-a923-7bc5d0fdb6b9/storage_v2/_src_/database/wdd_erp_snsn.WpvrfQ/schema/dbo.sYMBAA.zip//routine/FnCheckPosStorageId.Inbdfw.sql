CREATE FUNCTION [dbo].[FnCheckPosStorageId]
(
	@sei_id int,
	@sh_id int,
	@status int
)
RETURNS INT
AS
BEGIN
	DECLARE @re INT=1;

	IF @status<>0
	BEGIN
	IF EXISTS (SELECT 1 FROM dbo.pos_storageinfo WHERE sei_id = @sei_id AND sei_sh_id=@sh_id)
			SET @re = 1;
       ELSE
			SET @re = 0;
    END
	RETURN @re;
END
go

