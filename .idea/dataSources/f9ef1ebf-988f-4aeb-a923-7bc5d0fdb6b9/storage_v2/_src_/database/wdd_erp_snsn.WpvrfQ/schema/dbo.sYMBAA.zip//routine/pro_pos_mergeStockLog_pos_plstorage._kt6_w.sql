CREATE PROCEDURE [dbo].[pro_pos_mergeStockLog_pos_plstorage]
	@tsl_sh_id INT,
	@negative_inventory INT = 0,
	@old_sei_id INT = 0,
	@new_sei_id INT = 0,
	@id INT = 0
AS
	EXEC pro_pos_mergeStockLog_check
	     @tsl_sh_id = @tsl_sh_id,
	     @negative_inventory = @negative_inventory,
	     @old_sei_id = @old_sei_id,
	     @new_sei_id = @new_sei_id
	IF @@ERROR != 0
	BEGIN
	    DECLARE @ERROR_MESSAGE VARCHAR(100) = '';
	    SELECT @ERROR_MESSAGE = ERROR_MESSAGE();
	    RAISERROR (@ERROR_MESSAGE, 16, 1, N'number', 5);
	    RETURN;
	END
	BEGIN
		BEGIN TRAN
		DECLARE @now DATETIME = GETDATE();


		   update pos_stocklog set sl_status=0 where sl_status = 1 AND sl_shop_id = @tsl_sh_id and sl_eoid=@id AND sl_type=4

		   INSERT pos_stocklog 
		(
			sl_eoid ,
            sl_elid ,
            sl_seiid ,
            sl_shop_id ,
            sl_ciid ,
            sl_giid ,
            sl_skuid ,
            sl_type ,
            sl_counttype ,
            sl_number ,
            sl_addtime ,
            sl_updatetime ,
            sl_remark ,
            sl_status ,
            sl_order_no ,
            sl_order_date ,
            sl_order_add_time ,
			sl_pm ,
			sl_erp_id
		)
		select
			so.eoid ,
            so.elid ,
            so.[sid] ,
            so.shid ,
            so.cid ,
            so.gid ,
            so.skuid ,
            so.mytype ,
            so.countType ,
            so.gnum ,
            so.addtime ,
            @now ,
            so.myremark ,
            1 ,
            so.orderno ,
            so.order_date ,
            so.order_add_time ,
			isnull(so.pm,'') ,
			so.erp_id
			from (
SELECT 
       jps.pl_st_id                  AS SID,
       jps.pl_sh_id                  AS shid,
       cid = 0,
       jpsl.ppl_gi_id                AS gid,
       jpsl.ppl_sku_id               AS skuid,
       ABS(jpsl.ppl_num)             AS gnum,
	   isnull(jpsl.ppl_pm,'')        As pm ,
       countType = (CASE WHEN jpsl.ppl_num >= 0 THEN 1 ELSE 0 END),
       myremark = '盈亏',
       addtime = jpsl.ppl_add_time,
       orderno = jps.pl_vo,
       eoid = jps.pl_id,
       elid = jpsl.ppl_id,
       mytype = 4,
       order_add_time = jps.pl_add_time,
       order_date = jps.pl_date,
       pl_erp_id AS erp_id
FROM   pos_plStorage                 AS jps
       INNER JOIN pos_plStorageList  AS jpsl ON jps.pl_id = jpsl.ppl_pl_id
	   and jps.pl_id=@id
WHERE  jps.pl_status=2  
       AND jpsl.ppl_status = 1
       AND jpsl.ppl_gi_id > 0
       AND jps.pl_st_id > 0
       AND jps.pl_sh_id>0
			   
			 ) AS so




		EXEC pro_pos_mergeStockSum_new @tsl_sh_id = @tsl_sh_id,@id=@id ,@type=4

		DELETE pos_stocklog where sl_status = 0 AND sl_shop_id = @tsl_sh_id 
		AND sl_eoid=@id AND sl_type=4


			IF @@ERROR <> 0
			BEGIN
				ROLLBACK TRANSACTION
			END
			ELSE
			BEGIN
				IF @@TRANCOUNT > 0
					COMMIT TRAN
			END
	END
go

