

 CREATE VIEW [dbo].[vi_j_purchaseStorage_sku_outed] AS     
SELECT pll_sku_id,
       pll_source_id,
       pll_source_add_time,
       MAX(pll_gi_id)     AS pll_gi_id,
       SUM(pll_num)       AS pll_num,
       MAX(pl_source_id)  AS pl_source_id
FROM   j_purchaseStorageList
       INNER JOIN j_purchaseStorage
            ON  pll_pl_id = pl_id
WHERE  pl_status > 0
       AND pll_status > 0
       AND pl_source = 1
       AND pll_source_id > 0
       AND pll_source_add_time > 0
GROUP BY
       pll_source_id,
       pll_sku_id,
       pll_source_add_time


 go

