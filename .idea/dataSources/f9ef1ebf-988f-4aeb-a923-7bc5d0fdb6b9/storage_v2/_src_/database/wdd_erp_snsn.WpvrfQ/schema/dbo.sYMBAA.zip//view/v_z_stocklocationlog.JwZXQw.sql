CREATE  VIEW [dbo].[v_z_stocklocationlog]
AS
SELECT  '' AS specname ,--暂时为空  
        (CASE WHEN rulenum.gd_row_number IS NULL THEN '无'
              ELSE 'spec' + CONVERT(VARCHAR,rulenum.gd_row_number)
         END) AS spec2 ,
        rulenum.gd_row_number ,
        locationlist.*
FROM    (SELECT ISNULL(grl.gss_no,'') AS gss_no ,--规格编码,
				isnull(grl.colorname,'无') as color,
				isnull(grl.specname,'无') as spec,
				isnull(grl.specid,0) as size,
				isnull(grl.specngroupid,0) as specid,

                ln.*
         FROM   (SELECT esl.slt_no ,
                        esl.slt_id ,
                        sl_eoid AS eoid ,
                        sl_pm AS pm ,
                        sl_order_no AS orderno ,
                        bs.sei_name ,
                        bg.gi_name ,
                        bg.gi_code ,
                        bg.gi_barcode ,
                        bg.gi_types ,
						bg.gi_type1,
						bg.gi_type2,
						bg.gi_type3,
						bg.gi_type4,
                        js.sl_erp_id AS erp_id ,
                        (CASE WHEN js.sl_counttype = 1 THEN js.sl_number
                              ELSE -js.sl_number
                         END) AS gnum ,
                        sl_remark AS myremark ,
                        sl_order_date AS order_date ,
                        sl_addtime AS order_add_time ,
                        sl_seiid AS sei_id ,
                        sl_giid AS gi_id ,
                        sl_skuid AS sku_id ,
                        sl_type ,
                        sl_cp_id AS cp_id ,
                        (CASE sl_type
                           WHEN 1 THEN (SELECT  si_name
                                        FROM    b_supplierinfo bs
                                        WHERE   bs.si_status <> 0
                                                AND bs.si_id = sl_ciid
                                       )
                           WHEN 2 THEN (SELECT  (CASE WHEN oo_sh_id_txt <> '' THEN oo_sh_id_txt
                                                      WHEN ci_name <> '' THEN ci_name
                                                      WHEN oo_to_cp_id_txt <> '' THEN oo_to_cp_id_txt
                                                      ELSE '其它'
                                                 END) AS sup
                                        FROM    vi_j_outStorage
                                        WHERE   oo_id = sl_eoid
                                       )
                           ELSE '其它'
                         END) AS sup ,
                        (SELECT (CASE WHEN type = 1 THEN '加盟专卖店'
                                      WHEN type = 3 THEN '直营专卖店'
                                      ELSE ''
                                 END)
                         FROM   pos_shop
                         WHERE  sh_id = (SELECT (CASE WHEN oo_sh_id <> 0 THEN oo_sh_id
                                                      ELSE ''
                                                 END) AS shop
                                         FROM   vi_j_outStorage
                                         WHERE  oo_id = sl_eoid
                                        )
                        ) shop_type
                 FROM   j_stocklog js
                 INNER JOIN dbo.b_storageinfo AS bs ON js.sl_seiid = bs.sei_id
                                                       AND bs.sei_status > 0
                 INNER JOIN dbo.b_goodsinfo AS bg ON js.sl_giid = bg.gi_id
                 INNER JOIN erp_storagelocation AS esl ON esl.slt_id = js.sl_location
                                                          AND esl.slt_status = 1
                 WHERE  js.sl_status > 0
                        AND js.sl_location > 0
                ) AS ln
         LEFT JOIN b_goodsruleset AS grl ON grl.gss_id = ln.sku_id
        ) AS locationlist
LEFT JOIN s_goodsruledetail rulenum ON gd_id = locationlist.size
go

