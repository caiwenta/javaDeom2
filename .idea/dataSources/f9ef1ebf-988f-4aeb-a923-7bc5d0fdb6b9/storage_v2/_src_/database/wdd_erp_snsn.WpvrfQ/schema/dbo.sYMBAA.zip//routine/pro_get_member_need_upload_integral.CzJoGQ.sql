CREATE PROC [dbo].[pro_get_member_need_upload_integral] @erp_id INT
AS
BEGIN
      BEGIN TRANSACTION
      
      SELECT TOP 100
                me.dzd_miid AS uid ,
                ir.ir_integral AS integral ,
                ir.ir_remark AS remark ,
                ir.ir_me_id AS iid ,
                ir.ir_id ,
                ps.sa_vo
      INTO      #integral
      FROM      pos_integral_record ir
      INNER JOIN pos_memberInfo me ON ir.ir_me_id = me.me_id
      LEFT JOIN pos_sale ps ON ir.ir_sa_id = ps.sa_id
      WHERE     ir.ir_is_success = 0
                AND ir_integral != 0
                AND me.me_erp_id = @erp_id
                AND ISNULL(me.dzd_miid,0) > 0
      ORDER BY  ir.ir_id

      UPDATE    pos_integral_record
      SET       ir_is_success = 1
      WHERE     ir_id IN (SELECT    ir_id
                          FROM      #integral)

      SELECT    *
      FROM      #integral 

      SELECT    me.dzd_miid AS uid ,
                ir.ir_integral AS integral ,
                ir.ir_remark AS remark ,
                ir.ir_me_id AS iid ,
                ir.ir_id ,
                ps.sa_vo AS orderno ,
                ir.ir_integral AS consumeinter ,
                (CASE WHEN ps.sa_status = 0 THEN 0
                      ELSE ps.sa_money
                 END) AS consumemoney ,
                ps.sal_num AS goodsnumber ,
                ps.sa_sh_id AS shopid ,
                (SELECT sh_name
                 FROM   dbo.pos_shop
                 WHERE  sh_id = ps.sa_sh_id
                ) AS shopname ,
                ps.sa_add_time AS consumedata
      FROM      pos_integral_record ir
      INNER JOIN pos_memberInfo me ON ir.ir_me_id = me.me_id
      INNER JOIN vi_pos_sale ps ON ir.ir_sa_id = ps.sa_id
      WHERE     ir.ir_id IN (SELECT ir_id
                             FROM   #integral)
      IF @@error <> 0
         ROLLBACK TRANSACTION                                                
      ELSE
         COMMIT TRANSACTION
END
go

