CREATE Proc [dbo].[pro_check_have_negative]
@id INT=0,
@type int=0
AS

--返回1则表示此仓库有负库存,返回0则表示没有.
DECLARE @result VARCHAR(100)='';

if @type=0
begin

IF EXISTS(
SELECT * FROM 
(           
SELECT sl.[sid],
       sl.gid,
       sl.skuid,
       sl.cp_id,
       SUM(CASE WHEN sl.countType = 1 
       THEN sl.gnum ELSE -sl.gnum END) 
       AS gnum
FROM   vi_stockList sl
WHERE sl.[sid]=@id
GROUP BY
       sl.[sid],
       sl.gid,
       sl.skuid,
       sl.cp_id
) AS fd WHERE fd.gnum<0	
)
BEGIN
	SET @result='1';
END
ELSE
BEGIN
	SET @result='0';
END

end


--占用存库判断负库存
if @type=1
begin

IF EXISTS (
	SELECT * FROM (
	SELECT 
	enable_stock_num=bs.si_number-(ISNULL(bs.si_occupy_num,0)+ISNULL(bs.si_allocationoccupy_num,0)+ISNULL(bs.si_orderblankoccupy_num,0)) 
	FROM b_stockinfo AS bs 
	WHERE bs.si_seiid=@id ) AS fd 
	WHERE enable_stock_num<0
)
BEGIN
	SET @result='1';
END
ELSE
BEGIN
	SET @result='0';
END

end



SELECT @result AS info
go

