

CREATE Proc [dbo].[pro_back_current_data]
@back_type INT=0,
@path VARCHAR(50)=''
AS


IF CHARINDEX('erp',DB_NAME())!=0 AND 1=2
BEGIN

DECLARE @result VARCHAR(50)='';
--SELECT ('exec sp_refreshview '+REPLACE( fd.name,'dbo.','')) 
--AS 'refresh',GETDATE() AS refresh_time
----INTO refresh_record
-- FROM vi_db_obj fd WHERE fd.[type]='v'
--DELETE FROM refresh_record
--SELECT *,REPLACE(fd.refresh,'exec sp_refreshview ','') AS name FROM refresh_record fd

DECLARE @now DATETIME;
SET @now=GETDATE();
DECLARE @sql NVARCHAR(MAX)=''
DECLARE sopcor CURSOR FOR(SELECT ('exec sp_refreshview '+REPLACE( fd.name,'dbo.','')) 
AS 'refresh'
 FROM 
 (
 --vi_db_obj fd
 select a.name,a.[type],b.[definition] from sys.all_objects a,sys.sql_modules b where a.is_ms_shipped=0 and a.object_id = b.object_id
 ) fd
  WHERE fd.[type]='v')
OPEN sopcor
FETCH NEXT FROM sopcor INTO @sql
		WHILE @@FETCH_STATUS =0
		BEGIN
			DECLARE @need_insert INT=0;
			BEGIN TRY
				exec sp_executesql @sql
			END TRY
			BEGIN CATCH
				SET @need_insert=1;

				IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;	
				/* 
					SELECT
						ERROR_NUMBER() AS ErrorNumber,
						ERROR_SEVERITY() AS ErrorSeverity,
						ERROR_STATE() AS ErrorState,
						ERROR_PROCEDURE() AS ErrorProcedure,
						ERROR_LINE() AS ErrorLine,
						ERROR_MESSAGE() AS ErrorMessage
				*/
			END CATCH
			IF @need_insert=1
			BEGIN
				INSERT INTO refresh_record
				(
					refresh,
					refresh_time
				)
				VALUES
				(
					@sql,
					@now
				)
			END
		FETCH NEXT FROM sopcor INTO @sql
		End
CLOSE sopcor
DEALLOCATE sopcor

IF EXISTS(
SELECT * FROM refresh_record fd WHERE fd.refresh_time=@now
)
BEGIN
	
	SET @result='存在刷新失败的视图!';
	
END
ELSE
BEGIN
	SET @result='全部刷新成功!';
END
PRINT @result
	
END





DECLARE @db_name VARCHAR(MAX)='';
SET @db_name=DB_NAME();
DECLARE @file VARCHAR(MAX)='';
SET @file=
substring(convert(varchar(100),getdate(),21),0,21)+convert(varchar(10),floor(rand()*3))+convert(varchar(10),floor(rand()*4) )+convert(varchar(10),floor(rand()*5));

IF @back_type=0
BEGIN

SET @file=REPLACE(REPLACE(@file,':',''),'.','')+'_'+@db_name+'_完整.bak';
IF @path!=''
BEGIN
	SET @file=@path+@file;
END
Backup Database @db_name TO DISK =@file;
	
END
ELSE
BEGIN
	
SET @file=REPLACE(REPLACE(@file,':',''),'.','')+'_'+ @db_name+'_差异.bak';

IF @path!=''
BEGIN
	SET @file=@path+@file;
END
Backup Database @db_name TO DISK =@file WITH DIFFERENTIAL

END
go

