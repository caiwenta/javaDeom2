
CREATE VIEW [dbo].[v_z_inStorage_detail] AS 
SELECT *,gi_id AS giid FROM v_z_pos_inStorage_detail
	where intype='入库退货' and in_type=1  and in_is_audit=0 AND in_source=0  AND num<>0
go

