CREATE VIEW [dbo].[vi_j_initStorage_Search] AS 
SELECT
	(inl_retail_price*inl_num) AS inl_retail_money,*
FROM
	vi_j_initStorageList_group_goods el
LEFT JOIN vi_j_initStorage eo ON el.inl_in_id = eo.in_id
AND eo.in_status > 0
go

