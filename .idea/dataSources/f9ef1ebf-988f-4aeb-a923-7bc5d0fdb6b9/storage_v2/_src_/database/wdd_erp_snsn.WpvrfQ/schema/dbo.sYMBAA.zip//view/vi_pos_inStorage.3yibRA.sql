

CREATE VIEW [dbo].[vi_pos_inStorage] AS 
SELECT
	in_id,
	in_sh_id,
	in_vo,
	CONVERT (VARCHAR(10), in_date, 120) AS in_date,
	in_no,
	in_source,
	in_source_id,
	in_type,
	in_st_id,
	in_is_audit,
	in_actual_num,
	in_supplier_sh_id,
	in_order_man,
	(
		SELECT
			cp_simplename
		FROM
			dbo.companyinfo AS bs WITH (NOLOCK)
		WHERE
			(cp_id = 1)
	) AS in_company,
	(
		CASE
		WHEN in_source = 1 THEN
			(
				SELECT
					oo_no
				FROM
					j_outStorage WITH (NOLOCK)
				WHERE
					oo_id = jis.in_source_id
			)
		ELSE
			(
				SELECT
					al_vo
				FROM
					pos_alStorage WITH (NOLOCK)
				WHERE
					al_id = jis.in_source_id
			)
		END
	) AS in_source_no,
	CONVERT (
		VARCHAR (10),
		(
			CASE
			WHEN in_source = 1 THEN
				(
					SELECT
						oo_entrydate
					FROM
						j_outStorage WITH (NOLOCK)
					WHERE
						oo_id = jis.in_source_id
				)
			ELSE
				(
					SELECT
						al_date
					FROM
						pos_alStorage WITH (NOLOCK)
					WHERE
						al_id = jis.in_source_id
				)
			END
		),
		120
	) AS in_source_date,
	(
		SELECT
			sei_name
		FROM
			dbo.pos_storageInfo AS bs WITH (NOLOCK)
		WHERE
			(sei_id = jis.in_st_id)
	) AS in_st_id_txt,

	(
		CASE 
		     WHEN in_source=0 THEN --公司
		         (SELECT    bs.si_name FROM       pos_supplierinfo AS bs WHERE    bs.si_id = jis.in_supplier_sh_id)
		     WHEN  in_source =1 THEN --公司
				(SELECT  cp_simplename FROM    dbo.companyinfo WHERE   cp_id =(select top 1 oo_cp_id from j_outStorage where oo_id= jis.in_source_id))
		      WHEN in_source = 2  AND jis.in_remark<>'网络订单'  then   
				(SELECT sh_name FROM pos_shop WHERE sh_id=(SELECT al_sh_id FROM pos_alStorage WITH (NOLOCK) WHERE al_id = jis.in_source_id))
	          WHEN in_source = 2 AND jis.in_remark='网络订单' THEN (SELECT sh_no FROM pos_shop WITH (NOLOCK) WHERE sh_id= jis.in_supplier_sh_id)
				ELSE 
		     (SELECT sh_name FROM pos_shop WHERE sh_id=(SELECT al_sh_id FROM pos_alStorage WITH (NOLOCK) WHERE al_id = jis.in_source_id))
		END
	) AS in_supplier_sh_id_txt,
	
	(
		CASE 
		     WHEN in_source=0 THEN --公司
		         (SELECT  bs.si_code FROM       pos_supplierinfo AS bs WHERE    bs.si_id = jis.in_supplier_sh_id)
		     WHEN  in_source =1 THEN --公司
				(SELECT  cp_code FROM    dbo.companyinfo WHERE   cp_id =(select top 1 oo_cp_id from j_outStorage where oo_id= jis.in_source_id))
		      WHEN in_source = 2  AND jis.in_remark<>'网络订单'  then   
				(SELECT sh_no FROM pos_shop WHERE sh_id=(SELECT al_sh_id FROM pos_alStorage WITH (NOLOCK) WHERE al_id = jis.in_source_id))
	          WHEN in_source = 2 AND jis.in_remark='网络订单' THEN (SELECT sh_no FROM pos_shop WITH (NOLOCK) WHERE sh_id= jis.in_supplier_sh_id)
				ELSE 
		     (SELECT sh_no FROM pos_shop WHERE sh_id=(SELECT al_sh_id FROM pos_alStorage WITH (NOLOCK) WHERE al_id = jis.in_source_id))
		END
	) AS in_supplier_sh_code_txt,
	(
		SELECT
			sh_name
		FROM
			dbo.pos_shop AS bs WITH (NOLOCK)
		WHERE
			(sh_id = jis.in_sh_id)
	) AS in_sh_id_txt,
	--数量合计
	(
		SELECT
			SUM (inl_num)
		FROM
			dbo.pos_inStorageList AS bs WITH (NOLOCK)
		WHERE
			(
				inl_in_id = jis.in_id
				AND inl_status = 1
			)
	) AS in_snum,
	--金额合计
	(
		SELECT
			SUM (inl_money)
		FROM
			dbo.pos_inStorageList AS bs WITH (NOLOCK)
		WHERE
			(
				inl_in_id = jis.in_id
				AND inl_status = 1
			)
	) AS in_smoney,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			(si_id = jis.in_order_man)
	) AS in_order_man_txt,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			(si_id = jis.in_add_man)
	) AS in_add_man_txt,
	in_add_man,
	in_add_time,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			(si_id = jis.in_update_man)
	) AS in_update_man_txt,
	in_update_man,
	in_update_time,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			(si_id = jis.in_audit_man)
	) AS in_audit_man_txt,
	in_audit_man,
	in_audit_time,
	in_remark,
	in_status,
	fd.sh_company,
	fd.sh_erp_id,
	jis.ord_no,
	jis.in_erp_id,
	jis.in_erp_id as erp_id,
	( SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id where eio.io_id=jis.in_io_id)instru_vo --指令单凭证号
FROM
	pos_inStorage AS jis WITH (NOLOCK)
INNER JOIN pos_shop fd WITH (NOLOCK) ON jis.in_sh_id = fd.sh_id
go

