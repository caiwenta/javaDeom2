CREATE VIEW [dbo].[vi_j_enterStorage_and_detail] AS 
SELECT jt.eo_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.j_enterStorage                 AS jt
       INNER JOIN dbo.j_enterStorageList  AS jt1
            ON  jt.eo_id = jt1.el_eoid
       INNER JOIN dbo.b_goodsinfo    AS bg
            ON  jt1.el_siid = bg.gi_id
WHERE  (jt1.el_status = 1)
       AND (jt.eo_status <> 0)
go

