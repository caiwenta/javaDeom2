CREATE VIEW [dbo].[v_z_pos_ogstorage]
	AS 
select 
og_totalboxnum,og_id, og_vo, og_date, og_ph_audit, og_cg_audit, og_no, og_type, og_refe_no, og_is_lock, og_erp_id, og_erp_id as erp_id,
og_business, og_trans, og_out_date, og_sh_id, og_ci_id, og_to_cp_id, og_order_man, og_update_man,  og_audit_man, 
og_cp_id, og_di_id, og_sh_id_txt, sh_province, sh_city, og_ci_id_txt,og_ci_code_txt, ci_province, ci_city,
og_to_cp_id_txt, cp_province, cp_city, og_business_txt, og_order_man_txt,  og_add_man_txt, og_add_man, 
og_add_time, og_update_man_txt, og_update_time, og_audit_man_txt, og_audit_time, og_remark, og_status,
is_al_audited, is_pl_audited, 
sh_id,sh_company,
allsumnum, 
(SELECT re_vo FROM pos_reStorage prs WHERE prs.re_cp_id>0 AND re_id=og_source_id) as re_vo,
allogl_pause_num, allsummoney, allal_num, allpl_num,
allsumnum - allpl_num - ISNULL(allogl_pause_num, 0) AS allpl_num_do, 
allsumnum - allal_num - ISNULL(allogl_pause_num, 0)  AS allal_num_do 
from (
	
select 

M.og_totalboxnum,M.og_id,  M.og_vo, CONVERT(VARCHAR(10),  M.og_date, 120) AS og_date, M.og_erp_id,M.og_source_id,
M.og_ph_audit, M.og_cg_audit,  M.og_no,  M.og_type,  M.og_refe_no,  M.og_is_lock,  
M.og_business,  M.og_trans,   M.og_out_date,  M.og_sh_id,  M.og_ci_id,  M.og_to_cp_id, 
M.og_order_man,  M.og_update_man,   M.og_audit_man,  M.og_cp_id,  M.og_di_id,M.og_add_man, 
M.og_add_time,M.og_audit_time,   M.og_remark, M.og_status,M.og_update_time ,
op.sh_name og_sh_id_txt,op.province sh_province ,op.city sh_city,  cl.ci_name  og_ci_id_txt,cl.ci_province,cl.ci_city,
op.sh_id,op.sh_company,
  
co.cp_name  og_to_cp_id_txt,co.cp_province,co.cp_city, 
(SELECT ci_code FROM dbo.b_clientinfo AS cl WHERE  (cl.ci_id = M.og_ci_id)) AS og_ci_code_txt, 
(SELECT si_name FROM dbo.b_stafftinfo AS bs WHERE  (si_id = M.og_business)) AS og_business_txt, 
(SELECT si_name FROM dbo.b_stafftinfo AS bs WHERE (si_id = M.og_order_man)) AS og_order_man_txt, 
(SELECT si_name FROM dbo.b_stafftinfo AS bs WHERE (si_id = M.og_add_man)) AS og_add_man_txt, 
(SELECT si_name FROM dbo.b_stafftinfo AS bs WHERE (si_id = M.og_update_man)) AS og_update_man_txt,  
(SELECT si_name FROM dbo.b_stafftinfo AS bs WHERE (si_id = M.og_audit_man)) AS og_audit_man_txt,  
(SELECT TOP (1) al_id FROM dbo.pos_allocation WHERE (al_source_id = M.og_id) AND (al_status > 0)  AND (al_source = 5)) AS is_al_audited, 
(SELECT TOP (1) pl_id FROM dbo.j_purchaseStorage WHERE (pl_source_id = M.og_id) AND  (pl_status > 0) AND (pl_source = 1) ) AS is_pl_audited,
(SELECT SUM(ogl_num) AS Expr1 FROM dbo.pos_ogStorageList WHERE (ogl_og_id = M.og_id) AND(ogl_status > 0)) AS allsumnum, 
(SELECT SUM(ogl_pause_num) AS Expr1 FROM dbo.pos_ogStorageList WHERE (ogl_og_id = M.og_id) AND  (ogl_status > 0)) AS allogl_pause_num,  
(SELECT SUM(ogl_money) AS Expr1 FROM dbo.pos_ogStorageList  WHERE (ogl_og_id = M.og_id) AND  (ogl_status > 0)) AS allsummoney, 
ISNULL((SELECT SUM(pal.all_num) AS Expr1  
FROM dbo.pos_allocation AS pa
INNER JOIN  dbo.pos_allocationList AS pal ON pa.al_id = pal.all_al_id  WHERE (pa.al_status > 0)AND (pal.all_status > 0) AND (pa.al_source = 5) AND  (pal.all_source_id 
IN ((SELECT ogl_id FROM dbo.pos_ogStorageList AS posl WHERE (ogl_og_id = M.og_id))))), 0) AS allal_num, ISNULL((SELECT SUM(jpl.pll_num) AS Expr1
FROM dbo.j_purchaseStorage AS jp
INNER JOIN dbo.j_purchaseStorageList AS jpl ON jp.pl_id = jpl.pll_pl_id 
WHERE (jp.pl_status > 0) AND (jpl.pll_status > 0) 
AND (jp.pl_source = 1) 
AND  (jpl.pll_source_id IN((SELECT ogl_id FROM dbo.pos_ogStorageList AS posl WHERE (ogl_og_id = M.og_id))))), 0) AS allpl_num 

from (
	
	
SELECT M.og_totalboxnum,M.og_id,  M.og_vo, CONVERT(VARCHAR(10),  M.og_date, 120) AS og_date, M.og_erp_id,M.og_source_id,
M.og_ph_audit, M.og_cg_audit,  M.og_no,  M.og_type,  M.og_refe_no,  M.og_is_lock,  M.og_business,  M.og_trans,  
M.og_out_date,  M.og_sh_id,  M.og_ci_id,  M.og_to_cp_id,  M.og_order_man,  M.og_update_man,   M.og_audit_man, 
M.og_cp_id,  M.og_di_id,M.og_add_man, M.og_add_time,M.og_audit_time,   
M.og_remark, M.og_status,M.og_update_time  
FROM (


SELECT M.og_totalboxnum, M.og_id,  M.og_vo, CONVERT(VARCHAR(10),  M.og_date, 120) AS og_date, og_erp_id,M.og_source_id,
M.og_ph_audit, M.og_cg_audit,  M.og_no,  M.og_type,  M.og_refe_no,  M.og_is_lock,  M.og_business,  
M.og_trans,   M.og_out_date,  M.og_sh_id,  M.og_ci_id,  M.og_to_cp_id,  M.og_order_man,  M.og_update_man,   
M.og_audit_man,  M.og_cp_id,  M.og_di_id,M.og_add_man, M.og_add_time,M.og_audit_time,   
M.og_remark, M.og_status,M.og_update_time  
from  dbo.pos_ogStorage  M  
WHERE   og_status!=0 
and og_id in(select vi.og_id from vi_j_Pos_OgStorage_and_detail vi)

) M 


)  as M  

left join pos_shop op on M.og_sh_id=op.sh_id left join b_clientinfo cl on cl.ci_id = M.og_ci_id 
left join companyinfo co on co.cp_id = M.og_to_cp_id 
) as fd
go

