CREATE VIEW dbo.New_b_stafftinfo
AS
SELECT     TOP 50 si_id, si_did, si_department, si_position, si_pid, si_ids, si_name, si_email, si_phone, si_status, si_isdel, si_shop_id
FROM         b_stafftinfo
UNION ALL
SELECT     CONVERT(int, (CONVERT(varchar, t .st_id) + CONVERT(varchar, bb.si_id))) AS id, 0 si_did, '' si_department, '' si_position, bb.si_pid, bb.si_ids, st_st_id, '' si_email, '' si_phone, 1 si_status, 
                      1 si_isdel, bb.si_shop_id
FROM         pos_staffClassSet T INNER JOIN
                      pos_class s ON s.cl_id = T .st_cl_id INNER JOIN
                      b_stafftinfo bb ON bb.si_id = T .st_add_man
go

