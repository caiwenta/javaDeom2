CREATE VIEW [dbo].[v_pos_scandetails]
	AS 
	--pos 扫描商品明细
select ed.do_id,ed.erp_id,vgd.gi_name,vgd.gi_code,(case when vgd.gss_no='0' then '' else vgd.gss_no end)gss_no,vgd.colorname,vgd.specname,edl.orderguid,edl.number,edl.addtime  from erp_distributionorder ed 
inner join erp_goodslisttemp edl on ed.orderguid=edl.orderguid and edl.number>0
inner join v_goods_detail_all vgd on vgd.gss_id=edl.sku_id and vgd.gi_id=edl.gi_id
go

