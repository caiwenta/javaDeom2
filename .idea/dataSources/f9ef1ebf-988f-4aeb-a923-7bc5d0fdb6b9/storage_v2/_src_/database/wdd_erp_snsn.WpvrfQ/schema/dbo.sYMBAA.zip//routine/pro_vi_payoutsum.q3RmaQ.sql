CREATE PROCEDURE [dbo].[pro_vi_payoutsum]
@sa_sh_id INT,
@sa_date DATETIME= '2014-7-22',
@sa_erp_id INT

AS
BEGIN
SELECT 
payout.*,
(payout.sal_money+payout.income)-(ABS(payout.sal_change_money)+ABS(payout.payout)+ABS(payout.bspayout)) AS balance
FROM
(
SELECT 
sa_sh_id,
sa_date,
sa_erp_id,
SUM(sal_money) AS sal_money,
SUM(sal_change_money) AS sal_change_money,
SUM(payout) AS payout,
SUM(income) AS income,
SUM(bspayout) AS bspayout
FROM
(

---销售	
SELECT 
ps.sa_sh_id,
ps.sa_erp_id,
CONVERT(VARCHAR(50), ps.sa_date, 23) AS sa_date,
SUM(case when psl.sal_is_gift=0 and psl.sal_is_change=0 and psl.sal_is_in=0 and psl.sal_is_return=0
then (psl.sal_num*psl.sal_real_price)-psl.sal_deduct_money else 0 end)as sal_money,
SUM(case when psl.sal_is_return=1 or psl.sal_is_change=1 then -((ABS(psl.sal_num)*psl.sal_real_price)-sal_deduct_money)else 0 END)as sal_change_money,
0 as payout,
0 AS income,
0 AS bspayout
FROM pos_sale ps WITH (NOLOCK) 
INNER JOIN
pos_salelist psl  WITH (NOLOCK) 
ON psl.sal_sa_id=ps.sa_id AND psl.sal_status<>0 AND ps.sa_status<>0
AND ps.sa_remark='' or ps.sa_remark IS NULL
WHERE ps.sa_sh_id=@sa_sh_id AND ps.sa_erp_id=@sa_erp_id
GROUP BY ps.sa_sh_id,ps.sa_date,ps.sa_erp_id


UNION ALL

--网络订单
SELECT 
ps.sa_sh_id,
ps.sa_erp_id,
CONVERT(VARCHAR(50), ps.sa_date, 23) AS sa_date,
SUM(case when psl.sal_is_gift=0 and psl.sal_is_change=0 and psl.sal_is_in=0 and psl.sal_is_return=0
then (psl.sal_num*psl.sal_real_price)-psl.sal_deduct_money else 0 end)as sal_money,
SUM(case when psl.sal_is_return=1 or psl.sal_is_change=1 then -((ABS(psl.sal_num)*psl.sal_real_price)-sal_deduct_money)else 0 END)as sal_change_money,
0 as payout,
0 AS income,
0 AS bspayout
FROM pos_sale ps WITH (NOLOCK) 
INNER JOIN
pos_salelist psl  WITH (NOLOCK) 
ON psl.sal_sa_id=ps.sa_id AND psl.sal_status<>0 AND ps.sa_status<>0
AND ps.sa_remark<>'' AND ps.sa_paytype='现金支付'
WHERE ps.sa_sh_id=@sa_sh_id AND ps.sa_erp_id=@sa_erp_id
GROUP BY ps.sa_sh_id,ps.sa_date,ps.sa_erp_id


UNION ALL	


--刷卡支付 消费代金券 积分抵扣额
SELECT
ps.sa_sh_id,
ps.sa_erp_id,
CONVERT(VARCHAR(50), ps.sa_date, 23) AS sa_date, 
-ps.sa_card_money-ps.sa_in_money-ps.sa_sa_vo as sal_money,
0 as sal_change_money,
0 as payout,
0 AS income,
0 AS bspayout
FROM pos_sale ps
WHERE (ps.sa_card_money<>0 OR ps.sa_in_money<>0 OR sa_sa_vo<>0)  AND ps.sa_status<>0
AND ps.sa_sh_id=@sa_sh_id AND ps.sa_erp_id=@sa_erp_id

UNION ALL		

--钱箱
SELECT 
psp.p_sh_id,
psp.po_erp_id,
psp.add_time,
0 AS sal_money,
0 AS sal_change_money,
isnull(SUM(CASE WHEN p_type=0 THEN p_money ELSE 0 END),0) AS payout,
isnull(SUM (CASE WHEN p_type=1 THEN p_money ELSE 0	END),0)  AS income,
isnull(SUM (CASE WHEN p_type=2 THEN p_money ELSE 0 END),0)  AS bspayout
FROM
(
SELECT 
p_sh_id,po_erp_id,p_type,convert(varchar(50),p_add_time,23) AS add_time,
CASE WHEN pp.p_counttype=1 THEN  pp.p_money ELSE - pp.p_money END AS p_money
FROM
pos_payout pp  WITH (NOLOCK)  WHERE pp.p_status<>0
and pp.p_sh_id=@sa_sh_id AND po_erp_id=@sa_erp_id
) AS psp
GROUP BY psp.p_sh_id, psp.add_time,psp.po_erp_id


) AS paut
GROUP BY sa_sh_id,sa_date,paut.sa_erp_id
) AS payout
END
go

