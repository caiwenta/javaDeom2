CREATE PROCEDURE [dbo].[pro_saleorder_op]
	@sa_update_man int = 0,
	@sa_update_time DATETIME = '2014-10-24' ,
	@sa_add_man int=0,
	@sa_add_time DATETIME = '2014-10-24' ,
	@sa_audit_man int=0,
	@sa_audit_time DATETIME = '2014-10-24' ,
	@sa_status int=1,
	@sa_type int=0,
	@sa_sa_type int=0,
	@sa_me_id int=0,
	@sa_sh_id int=0,
	@sa_remark varchar(50)='',
	@sa_in_id int=0,
	@sa_in_num int=0,
	@sa_get_in_num int=0,
	@sa_deduct_money DECIMAL(9, 2) = 0 ,  --扣除金额
	@sa_sa_vo INT = 0 ,  --消费代金劵
	@sa_gift_vo INT = 0 ,  --赠送代金券
	@sa_in_money DECIMAL(9, 2) = 0 ,  --积分抵扣额
	@sa_card_money DECIMAL(9, 2) = 0 ,  --刷卡金额
	@sa_shop_money DECIMAL(9, 2) = 0 ,  --商城金额
	@sa_co_man INT = 0 ,  --收银人员主键
	@sa_money DECIMAL(9, 2) = 0 ,  --应收金额
	@sa_real_money DECIMAL(9, 2) = 0 ,  --实收金额
	@sa_charge_money DECIMAL(9, 2) = 0 ,  --挂账金额
    @sa_surplus_money DECIMAL(9, 2) = 0 ,  --找零
	@sa_select INT = 0 ,  --收款方式
	@sa_sale_money DECIMAL(9, 2) = 0 , --销售金额
	@sa_change_money DECIMAL(9, 2) = 0 , --退货金额
	@sa_gift_money DECIMAL(9, 2) = 0 , --赠送金额
    @sa_current_vo INT = 0 ,--现有积分
    @sa_is_charge INT = 0 , --是否挂账
	@sa_date DATETIME = '2014-10-24' ,  --销售日期
	@sa_is_calculated int=0,
	@sa_paytype VARCHAR(100) = '' , --支付方式
	@sa_no VARCHAR(50) = '' ,  --单据号
	@sa_ac_id INT = 0 ,  --活动主键
	@sa_order_man INT = 0 ,  --制单人主键
    @sa_st_id INT = 0 ,  --仓库主键
	@sa_erp_id int=0,
	@sa_salman VARCHAR(100)='',
	@sa_receivedmomey DECIMAL(9, 2) = 0 ,
	@sa_paidmomey DECIMAL(9, 2) = 0 ,
	@sa_cashmoney DECIMAL(9, 2) = 0 ,
	@sa_bankmomey DECIMAL(9, 2) = 0 ,
	@sa_weixinmoney DECIMAL(9, 2) = 0 ,
	@sa_alipaymoney DECIMAL(9, 2) = 0 ,
	@sa_storedmoney DECIMAL(9, 2) = 0 ,
	@sa_salmanname VARCHAR(1000) = '' , 
	@sa_ac_ids VARCHAR(100) = '' , 
	@sa_ac_names VARCHAR(500) = '',
	@sa_id int=0 output, --主键,
	@isInsert int=0
AS
  

   IF @isInsert = 0 
   BEGIN

   DECLARE @tableName VARCHAR(50) = 'pos_sale_temp';
   DECLARE @idField VARCHAR(50) = 'sa_id';
   DECLARE @idValue INT = 0;
   DECLARE @dateField VARCHAR(50) = 'sa_date';
   DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @sa_date, 23);
   DECLARE @noField VARCHAR(50) = 'sa_vo';
   DECLARE @prevTxt VARCHAR(50) = 'XS';
   DECLARE @outno VARCHAR(100) = '';
   DECLARE @sa_vo VARCHAR(50) = ''; --凭证号
   DECLARE @pzone VARCHAR(10) = '';
   DECLARE @pztwo int=0;
   DECLARE @pzthree int=0;

    --凭证号生成
   EXECUTE [pro_gen_orderNo] @tableName, @idField, @idValue, 
   @dateField, @dateValue, @noField, @prevTxt, @outno OUTPUT, @sa_sh_id
   set @sa_vo = @outno ;
   set @pzone = dbo.Get_StrArrayStrOfIndex(@outno, '-', 1) ;
   set @pztwo = dbo.Get_StrArrayStrOfIndex(@outno, '-', 2) ;
   set @pzthree = dbo.Get_StrArrayStrOfIndex(@outno, '-', 3);

 insert into pos_sale_temp(
	sa_update_man,sa_update_time,sa_add_man,sa_add_time,sa_audit_man,sa_audit_time,sa_status,sa_type,sa_sa_type,sa_me_id,sa_sh_id,sa_remark,sa_in_id,sa_in_num,sa_get_in_num,sa_deduct_money,sa_sa_vo,sa_gift_vo,sa_in_money,sa_card_money,sa_shop_money,sa_co_man,sa_money,sa_real_money,sa_charge_money,sa_surplus_money,sa_select,sa_sale_money,sa_change_money,sa_gift_money,sa_current_vo,sa_is_charge,sa_date,sa_is_calculated,sa_paytype,sa_no,sa_vo,sa_ac_id,sa_order_man,sa_st_id,sa_erp_id,pzone,pztwo,pzthree,sa_salman,sa_receivedmomey,sa_paidmomey,sa_cashmoney,sa_bankmomey,sa_weixinmoney,sa_alipaymoney,sa_storedmoney,sa_salmanname,sa_ac_ids,sa_ac_names)
	values (
	@sa_update_man,@sa_update_time,@sa_add_man,@sa_add_time,@sa_audit_man,@sa_audit_time,@sa_status,@sa_type,@sa_sa_type,@sa_me_id,@sa_sh_id,@sa_remark,@sa_in_id,@sa_in_num,@sa_get_in_num,@sa_deduct_money,@sa_sa_vo,@sa_gift_vo,@sa_in_money,@sa_card_money,@sa_shop_money,@sa_co_man,@sa_money,@sa_real_money,@sa_charge_money,@sa_surplus_money,@sa_select,@sa_sale_money,@sa_change_money,@sa_gift_money,@sa_current_vo,@sa_is_charge,@sa_date,@sa_is_calculated,@sa_paytype,@sa_no,@sa_vo,@sa_ac_id,@sa_order_man,@sa_st_id,@sa_erp_id,@pzone,@pztwo,@pzthree,@sa_salman,@sa_receivedmomey,@sa_paidmomey,@sa_cashmoney,@sa_bankmomey,@sa_weixinmoney,@sa_alipaymoney,@sa_storedmoney,@sa_salmanname,@sa_ac_ids,@sa_ac_names);
	SET @sa_id = SCOPE_IDENTITY();

  END
else
  Begin

update pos_sale_temp set 
sa_update_man=@sa_update_man,
sa_update_time=@sa_update_time,
sa_type=@sa_type,
sa_sa_type=@sa_sa_type,
sa_me_id=@sa_me_id,
sa_sh_id=@sa_sh_id,
sa_remark=@sa_remark,
sa_in_id=@sa_in_id,
sa_in_num=@sa_in_num,
sa_get_in_num=@sa_get_in_num,
sa_deduct_money=@sa_deduct_money,
sa_sa_vo=@sa_sa_vo,
sa_gift_vo=@sa_gift_vo,
sa_in_money=@sa_in_money,
sa_card_money=@sa_card_money,
sa_shop_money=@sa_shop_money,
sa_co_man=@sa_co_man,
sa_money=@sa_money,
sa_real_money=@sa_real_money,
sa_charge_money=@sa_charge_money,
sa_surplus_money=@sa_surplus_money,
sa_select=@sa_select,
sa_sale_money=@sa_sale_money,
sa_change_money=@sa_change_money,
sa_gift_money=@sa_gift_money,
sa_current_vo=@sa_current_vo,
sa_is_charge=@sa_is_charge,
sa_date=@sa_date,
sa_paytype=@sa_paytype,
sa_no=@sa_no,
sa_ac_id=@sa_ac_id,
sa_order_man=@sa_order_man,
sa_st_id=@sa_st_id,
sa_erp_id=@sa_erp_id,
sa_receivedmomey=@sa_receivedmomey,
sa_paidmomey=@sa_paidmomey,
sa_cashmoney=@sa_cashmoney,
sa_bankmomey=@sa_bankmomey,
sa_weixinmoney=@sa_weixinmoney,
sa_alipaymoney=@sa_alipaymoney,
sa_storedmoney=@sa_storedmoney,
sa_salman=@sa_salman,
sa_salmanname=@sa_salmanname, 
sa_ac_ids=@sa_ac_ids, 
sa_ac_names=@sa_ac_names 
where sa_id=@sa_id

end
go

