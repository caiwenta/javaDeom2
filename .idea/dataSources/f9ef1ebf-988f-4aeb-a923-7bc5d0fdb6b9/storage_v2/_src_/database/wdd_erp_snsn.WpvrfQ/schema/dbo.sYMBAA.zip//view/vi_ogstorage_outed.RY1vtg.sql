CREATE VIEW [dbo].[vi_ogstorage_outed]
	AS 

--订单发货 
SELECT 
        ol_siid,
        ol_topsource_id,
		ol_pm,
		ol_box_num,
        ol_number
FROM   j_outStorageList
        INNER JOIN j_outStorage
            ON  ol_eoid = oo_id
WHERE  oo_status > 0
        AND ol_status > 0
        AND oo_source_type = 1
go

