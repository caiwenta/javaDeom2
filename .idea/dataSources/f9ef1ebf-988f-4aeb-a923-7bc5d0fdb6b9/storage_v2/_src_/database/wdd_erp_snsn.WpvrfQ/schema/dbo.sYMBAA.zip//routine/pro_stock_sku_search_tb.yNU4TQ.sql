



CREATE Proc [dbo].[pro_stock_sku_search_tb]
@cp_id INT=0,
@gi_id INT=0,
@sid INT=0,
@stock_date VARCHAR(10)='',
@pm VARCHAR(50)='',
@batch INT=0
AS
IF isnull(@sid,0)=0 
BEGIN
	--没有仓库
	SELECT fd.*,fd2.gnum,gs_money=fd2.gnum*fd.gs_purchase,bg.gi_name,bg.gi_code FROM (
	SELECT * FROM b_goodsruleset fd WHERE fd.gi_id=@gi_id
	) AS fd LEFT JOIN (
	 
	--wt 2016-6-24
	SELECT si_number AS gnum,si_skuid AS skuid FROM b_stockinfo 
	WHERE si_giid=@gi_id  AND si_cp_id=@cp_id and si_status<>0	
			
	) fd2 ON fd.gss_id=fd2.skuid LEFT JOIN b_goodsinfo bg ON fd.gi_id = bg.gi_id
END
ELSE
BEGIN
    
    --wt 日期库存
    IF @stock_date<>''
    BEGIN
    	
    	SELECT fd.*,fd2.gnum,gs_money=fd2.gnum*fd.gs_purchase,bg.gi_name,bg.gi_code FROM (
		SELECT * FROM b_goodsruleset fd WHERE fd.gi_id=@gi_id
		) AS fd LEFT JOIN (
		SELECT sl.skuid,
		Sum(Case when sl.countType=1 Then sl.gnum Else -sl.gnum End)As gnum 
		--wt FROM vi_stockList sl 
		FROM (
		SELECT sl_seiid AS SID,sl_number AS gnum,sl_ciid AS cid,sl_giid AS gid,sl_cp_id AS cp_id,sl_counttype AS countType,sl_order_date AS stock_date ,sl_skuid AS skuid
		From j_stocklog 
		WHERE sl_status<>0 AND ((convert(varchar(50),sl_order_date,23)<=@stock_date) or sl_type=3)
		) AS sl 
		WHERE sl.cp_id=@cp_id AND sl.gid=@gi_id AND sl.[sid]=@sid
		GROUP BY sl.skuid	
		) fd2 ON fd.gss_id=fd2.skuid LEFT JOIN b_goodsinfo bg ON fd.gi_id = bg.gi_id
   
    END
	ELSE
    BEGIN

	    IF @batch<>0
        BEGIN
    	--有仓库
		SELECT fd.*,
		fd2.gnum,
		fd2.box_num,
		fd2.si_pm,
		gs_money=fd2.gnum*fd.gs_purchase,
		bg.gi_name,
		bg.gi_code 
		FROM (
		SELECT * FROM b_goodsruleset fd WHERE fd.gi_id=@gi_id
		) AS fd LEFT JOIN 
		(

	    SELECT 
		sum(si_number)AS gnum,
		sum(sl_box_num) as box_num,
		si_pm,
		si_skuid AS skuid 
		FROM b_stockinfobatch 
		WHERE si_giid=@gi_id AND si_seiid=@sid AND si_cp_id=@cp_id and si_pm=@pm and si_status<>0 
		GROUP BY si_skuid,si_pm
		
		) fd2 
		ON fd.gss_id=fd2.skuid LEFT JOIN b_goodsinfo bg ON fd.gi_id = bg.gi_id
		END
		ELSE
        BEGIN
		--有仓库
		SELECT fd.*,fd2.gnum,gs_money=fd2.gnum*fd.gs_purchase,bg.gi_name,bg.gi_code FROM (
		SELECT * FROM b_goodsruleset fd WHERE fd.gi_id=@gi_id
		) AS fd LEFT JOIN 
		(
	     SELECT sum(si_number)AS gnum,si_skuid AS skuid FROM b_stockinfo 
		WHERE si_giid=@gi_id AND si_seiid=@sid AND si_cp_id=@cp_id and si_status<>0 
		GROUP BY si_skuid	
		
		) fd2 
		ON fd.gss_id=fd2.skuid LEFT JOIN b_goodsinfo bg ON fd.gi_id = bg.gi_id
	    END
    END
END
go

