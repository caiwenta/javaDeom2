CREATE VIEW [dbo].[vi_vi_c_fundorder_vi_detail_qcqm]
AS

select
(CASE WHEN ciname<>'' THEN ciname WHEN shname<>'' THEN shname WHEN cpname<>'' THEN cpname END)objectname,
(select cp_name from companyinfo where cp_id=fo_cp_id) set_cpname ,
TT.* 


from (

SELECT 
	   [cq_id]
      ,[qm]
      ,[COUNT]
      ,[qc]
      ,[fo_id]
      ,[fo_erp_id]
      ,[fo_cp_id]
      ,[fo_type]
      ,[fo_ciid]
      ,[fo_shid]
      ,[fo_to_cpid]
      ,[fo_bs]
      ,[fo_orderid]
      ,[fo_takeman]
      ,[fo_ticketno]
      ,(ISNULL([fo_realmoney],0)-ISNULL([fo_outmoney],0)) as fo_realmoney
      ,[fo_thiyetmoney]
      ,[fo_ofdate]
      ,[fo_remark]
      ,[fo_lastman]
      ,(case when [fo_status]=1 then '未审核' when [fo_status]=2 then '已审核' end)fo_status
      ,[fo_outmoney]
      ,[fo_admoney]
      ,[fo_otheronmoney]
      ,[fo_otheoutmoney]
      ,[fo_givemoney]
      ,[fo_ensuremoney]
      ,[fo_subscription]
      ,[fo_no]
      ,[fo_addtime]
      ,[fo_updatetime]
      ,[fo_rowNum]
      ,[ciname]
      ,[shname]
      ,[cpname]
      ,[qcje]
      ,[fo_userorderno]
      ,[cicode]
      ,[integral_status]
      ,[fun_status]
      ,[ci_cp_id]
      ,[qc_integral]
      ,[fo_realmoney_integral]
      ,[fo_thiyetmoney_integral]
      ,[fo_outmoney_integral]
      ,[fo_otheronmoney_integral]
      ,[fo_otheoutmoney_integral]
      ,[fo_givemoney_integral]
      ,[qm_integral]
      ,[gi_code]
      ,[gi_name]
      ,[gi_unit]
      ,[f_number]
      ,[f_costprice]
      ,f_type
      ,(SELECT (case when fo_bs='G' and (eo_remark is not null or eo_remark !='')  THEN eo_remark when fo_bs='X'  and (oo_remark is not null or oo_remark !='') THEN  oo_remark else fo_custom_remark end) FROM vi_c_fundorder_list_new vi WHERE vi.fo_id=c_fundorder_vi_detail_qcqm.fo_id)remark
	    ,(case when fo_outmoney >0 then -fo_finished_money else fo_finished_money end)fo_finished_money
	   ,(case when fo_outmoney >0 then -fo_parts_money else fo_parts_money end)fo_parts_money
  FROM c_fundorder_vi_detail_qcqm

union  all
 
SELECT 
      0
      ,[qm]
      ,[COUNT]
      ,[qc]
      ,[fo_id]
      ,[fo_erp_id]
      ,[ci_cp_id]
      ,[fo_type]
      ,[fo_ciid]
      ,[fo_shid]
      ,[fo_to_cpid]
      ,[fo_bs]
      ,'期初'
      ,[fo_takeman]
      ,[fo_ticketno]
      ,([fo_realmoney]-[fo_outmoney])
      ,[fo_thiyetmoney]
      ,[fo_ofdate]
      ,[fo_remark]
      ,[fo_lastman]
      ,(case when [fo_status]=1 then '未审核' when [fo_status]=2 then '已审核' end)fo_status
      ,[fo_outmoney]
      ,[fo_admoney]
      ,[fo_otheronmoney]
      ,[fo_otheoutmoney]
      ,[fo_givemoney]
      ,[fo_ensuremoney]
      ,[fo_subscription]
      ,[fo_no]
      ,[fo_addtime]
      ,[fo_updatetime]
      ,[fo_rowNum]
      ,[ciname]
      ,[shname]
      ,[cpname]
      ,[qcje]
      ,[fo_userorderno]
      ,[cicode]
      ,0
      ,0
      ,[ci_cp_id]
      ,[qc_integral]
      ,[fo_realmoney_integral]
      ,[fo_thiyetmoney_integral]
      ,[fo_outmoney_integral]
      ,[fo_otheronmoney_integral]
      ,[fo_otheoutmoney_integral]
      ,[fo_givemoney_integral]
      ,[qm_integral]
      ,''
      ,''
      ,''
      ,0
      ,0
      ,''
      ,''
	  ,0
	  ,0
  FROM v_fundorder_vi_client_qcqm


  ) as TT
go

