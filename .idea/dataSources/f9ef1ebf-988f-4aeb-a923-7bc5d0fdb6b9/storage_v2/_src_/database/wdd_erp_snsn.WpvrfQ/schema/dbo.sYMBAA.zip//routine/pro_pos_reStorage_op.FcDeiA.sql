



CREATE PROC [dbo].[pro_pos_reStorage_op]
@rel_box_num INT = 0,
@rel_pm VARCHAR(500) = '',
--主键  
@re_id INT = 0, 
@re_erp_id INT = 0,  
@rel_erp_id INT = 0,  
--店铺主键  
@re_sh_id INT = 0,  
--单据号  
@re_no VARCHAR(50) = '',  
--提交日期  
@re_date DATETIME = '2014-10-24',  
--供方店铺主键  
@re_supplier_sh_id INT = 0,  
--添加人主键  
@re_add_man INT = 0,  
--添加时间  
@re_add_time DATETIME = '2014-10-24',  
--修改人主键  
@re_update_man INT = 0,  
--修改时间  
@re_update_time DATETIME = '2014-10-24',  
--审核人主键  
@re_audit_man INT = 0,  
--审核时间  
@re_audit_time DATETIME = '2014-10-24',  
--制单人主键  
@re_order_man INT = 0,  
--备注  
@re_remark VARCHAR(50) = '',  
--主键  
@rel_id INT = 0,  
--产品补货登记主键  
@rel_re_id INT = 0,  
--商品主键  
@rel_gi_id INT = 0,  
--商品sku主键  
@rel_sku_id INT = 0,  
--数量  
@rel_num INT = 0,  
--零售价  
@rel_retail_price DECIMAL(9, 2) = 0,  
--折率  
@rel_discount DECIMAL(9, 2) = 0,  
--进货价  
@rel_stock_price DECIMAL(9, 2) = 0,  
--金额  
@rel_money DECIMAL(9, 2) = 0,  
--样品号  
@rel_sample_no VARCHAR(50) = '',  
--是否获赠  
@rel_is_gift INT = 0,  
--备注  
@rel_remark VARCHAR(50) = '',  
--添加时间  
@rel_add_time DATETIME = '2014-10-24',  
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  
--结果  
@result VARCHAR(4000) = '' OUT,
--保存字符串
@savestr VARCHAR(MAX)='',

@re_cp_id int=0,
@st_id int=0,
--供方公司
@re_tocompanyid INT = 0,
@isInsert INT = 0 ,--是否添加单据
--供方公司的仓库
@re_tocompany_sei_id INT = 0,
@orderguid VARCHAR(500) = '' --唯一guid,
AS
BEGIN
	--是否需要更新单据
	DECLARE @need_update INT = 0;
	--旧的单据日期
	DECLARE @old_order_date DATETIME;
	--单据日期是否更改
	DECLARE @old_order_date_is_changed INT = 0;
	--凭证号前缀
	DECLARE @myprevTxt VARCHAR(50) = 'BH';
	BEGIN TRAN


	IF @op_type = '添加修改单据,明细'
	BEGIN

	    IF @re_id = 0
	    BEGIN
	        --添加单据
	        INSERT INTO pos_reStorage
	          (
	            re_sh_id,
	            re_vo,
	            re_no,
	            re_date,
	            re_supplier_sh_id,
	            re_add_man,
	            re_add_time,
	            re_update_man,
	            re_update_time,
	            re_order_man,
	            re_status,
	            re_remark,
	            re_erp_id,
				re_tocompanyid,
				re_cp_id,
				re_tocompany_sei_id
	          )
	        VALUES
	          (
	            @re_sh_id,
	            NEWID(),
	            @re_no,
	            @re_date,
	            @re_supplier_sh_id,
	            @re_add_man,
	            @re_add_time,
	            @re_update_man,
	            @re_update_time,
	            @re_order_man,
	            1,
	            @re_remark,
                @re_erp_id,
				@re_tocompanyid,
				@re_cp_id,
				@re_tocompany_sei_id
	          );
	        SET @re_id = SCOPE_IDENTITY();
	        
	        SET @rel_re_id = @re_id;
	        SET @isInsert = 1;
	    END
	    ELSE
	    BEGIN
	        SET @need_update = 1;
	    END
	    IF EXISTS(
	           SELECT *
	           FROM   pos_reStorageList AS jt
	           WHERE  jt.rel_re_id = @re_id
	                  AND jt.rel_status = 1
	                  AND jt.rel_add_time = @rel_add_time
	                  AND jt.rel_gi_id != @rel_gi_id
	       )
	    BEGIN
	        UPDATE pos_reStorageList
	        SET    rel_status           = 0
	        WHERE  rel_re_id            = @re_id
	               AND rel_add_time     = @rel_add_time
	               AND rel_status       = 1
	               AND rel_gi_id != @rel_gi_id;
	        SET @rel_id = 0;
	    END
	    
	    --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
	    DECLARE @savestr_item VARCHAR(MAX)='';
	    --起始数值,每次循环后递增
	    DECLARE @start_int INT=1;
	    --终止数值
		DECLARE @end_int INT=1;


		 IF @orderguid = ''
         BEGIN

	    IF @savestr!='' 
	    --AND 1=2
	    BEGIN
	    	--得到明细数量
	    	--即要循环的次数
	    	SELECT @end_int=(LEN(@savestr)-LEN(REPLACE(@savestr,'|','')))

	    END

	    WHILE @start_int<=@end_int
		BEGIN
			
	    --动态赋值
	    IF @savestr!='' 

	    BEGIN
	    	SET @savestr_item=dbo.Get_StrArrayStrOfIndex(@savestr,'|',@start_int);
	    	IF(RTRIM(LTRIM(@savestr_item))='')
			BEGIN
				BREAK;
			END
			ELSE
			BEGIN

				SET @rel_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));
				
				SET @rel_gi_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));
				
				SET @rel_sku_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3));
				
				SET @rel_num=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));
				
				SET @rel_retail_price=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5));
				
				SET @rel_stock_price=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',6));
				
				SET @rel_discount=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',7));
				
				
				
			END
	    END	
	    
	    
	    IF @rel_id = 0
	    BEGIN
	        INSERT INTO pos_reStorageList
	          (
	            rel_re_id,
	            rel_gi_id,
	            rel_sku_id,
	            rel_num,
	            rel_retail_price,
	            rel_discount,
	            rel_stock_price,
	            rel_money,
	            rel_sample_no,
	            rel_is_gift,
	            rel_remark,
	            rel_status,
	            rel_add_time,
	            rel_box_num,
	            rel_pm,
	            rel_erp_id
	          )
	        VALUES
	          (
	            @rel_re_id,
	            @rel_gi_id,
	            @rel_sku_id,
	            @rel_num,
	            @rel_retail_price,
	            @rel_discount,
	            @rel_stock_price,
	            @rel_stock_price * @rel_num,
	            @rel_sample_no,
	            @rel_is_gift,
	            @rel_remark,
	            1,
	            @rel_add_time,
	            @rel_box_num,
	            @rel_pm,
	            @rel_erp_id
	          );
	        SET @rel_id = SCOPE_IDENTITY();
	    END
	    ELSE
	    BEGIN
	        UPDATE pos_reStorageList
	        SET    rel_re_id            = @rel_re_id,
	               rel_gi_id            = @rel_gi_id,
	               rel_sku_id           = @rel_sku_id,
	               rel_num              = @rel_num,
	               rel_retail_price     = @rel_retail_price,
	               rel_discount         = @rel_discount,
	               rel_stock_price      = @rel_stock_price,
	               rel_money            = @rel_stock_price * @rel_num,
	               rel_sample_no        = @rel_sample_no,
	               rel_is_gift          = @rel_is_gift,
	               rel_remark           = @rel_remark,
	               rel_box_num          = @rel_box_num,
	               rel_pm               = @rel_pm,
	                rel_erp_id          = @rel_erp_id
	        WHERE  rel_id               = @rel_id;
	        
	    END
	    SET @start_int=@start_int+1;


	END
	    END
         ELSE
         BEGIN

			MERGE INTO pos_reStorageList AS ta
					USING
					(
					     SELECT  @re_id as rel_re_id, 
						    gi_id, 
							sku_id,
							pm,
							gift ,
							erp_id,
							number,
							discount,--折扣
							retailprice,--销售价
							purchase,--供货价
							orderstatus,
							box_num,
							slt_id
						FROM  erp_goodslisttemp WHERE orderguid = @orderguid
					)as so on ta.rel_gi_id=so.gi_id AND  ta.rel_sku_id=so.sku_id and ta.rel_re_id=so.rel_re_id and ta.rel_status=1
					 WHEN MATCHED THEN  UPDATE
                           SET  
						   ta.rel_num += so.number,
						   ta.rel_money=((ta.rel_num+so.number)*so.purchase)
					  WHEN NOT MATCHED THEN
					  		INSERT 
							(
							rel_re_id,
							rel_gi_id,
							rel_sku_id,
							rel_num,
							rel_retail_price,
							rel_discount,
							rel_stock_price,
							rel_money,
							rel_is_gift,
							rel_status,
							rel_add_time,
							rel_box_num,
							rel_pm,
							rel_erp_id
							)
							VALUES
							( 
							 so.rel_re_id, 
							 so.gi_id, 
							 so.sku_id,
							 so.number,
							 so.retailprice,--销售价
							 so.discount,--折扣
							 so.purchase,
							 so.number*so.purchase,--入库金额
							 so.gift ,
							 so.orderstatus,
								(SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
								SELECT GETDATE() as nows,
								(SELECT TOP 1 rel_add_time FROM pos_reStorageList psl WHERE psl.rel_gi_id=so.gi_id AND rel_re_id=so.rel_re_id) AS addtime) AS TT),
							 so.box_num,
							 so.pm,
							 so.erp_id
							);
			exec pro_setGoodsPurchasePrice @oo_id=@re_id,@wt=4;

		 END

		 
		
	END



	IF @op_type = '审核单据'
	BEGIN
	    
		EXEC pro_update_unique_time @id=@re_id, @type='pos补货';

	    --审核单据
	    UPDATE pos_reStorage
	    SET    re_status         = 2,
	           re_audit_man      = @re_update_man,
	           re_audit_time     = GETDATE()
	    WHERE  re_id             = @re_id;
	END
	


	IF @op_type = '取消审核单据'
	BEGIN
	    --取消审核单据
	    UPDATE pos_reStorage
	    SET    re_status     = 1
	    WHERE  re_id         = @re_id;
	END


	
	IF @op_type = '删除单据'
	BEGIN
	    --删除单据
	    UPDATE pos_reStorage
	    SET    re_status     = 0
	    WHERE  re_id         = @re_id;
	END


	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE pos_reStorageList
	    SET    rel_status     = 0
	    WHERE  rel_id         = @rel_id;
	END


	
	IF @op_type = '批量删除明细'
	BEGIN
	    UPDATE pos_reStorageList
	    SET    rel_status           = 0
	    WHERE  rel_re_id            = @rel_re_id
	           AND rel_add_time     = @rel_add_time
	           AND rel_gi_id        = @rel_gi_id;
	    
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   pos_reStorageList AS jt
	           WHERE  jt.rel_re_id = @rel_re_id
	                  AND jt.rel_status = 1
	       )
	    BEGIN
	        UPDATE pos_reStorage
	        SET    re_status     = 0
	        WHERE  re_id         = @rel_re_id;
	    END
	END


	
	IF (@op_type = '添加修改单据,明细'
	   OR @need_update = 1
	   OR @op_type = '修改单据')
	   AND @isInsert != 1
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.re_date
	    FROM   pos_reStorage AS jt
	    WHERE  jt.re_id = @re_id;
	    IF @old_order_date != @re_date
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	    UPDATE pos_reStorage
	    SET    re_sh_id              = @re_sh_id,
	           re_no                 = @re_no,
	           re_date               = @re_date,
	           re_supplier_sh_id     = @re_supplier_sh_id,
	           re_update_man         = @re_update_man,
	           re_update_time        = @re_update_time,
	           re_order_man          = @re_order_man,
	           re_remark             = @re_remark,
			   re_tocompanyid		 = @re_tocompanyid,
			   re_tocompany_sei_id   =@re_tocompany_sei_id
	    WHERE  re_id                 = @re_id;
	    
	    IF(SELECT fd.re_status FROM pos_reStorage  fd 
	       WHERE fd.re_id =@re_id)=0
	    BEGIN
	    	UPDATE pos_reStorage
	        SET    re_status = 1
	        WHERE  re_id = @re_id ;
	    END    
	END


	
	
	IF @isInsert = 1
	   --OR @old_order_date_is_changed = 1
	BEGIN
	    --凭证号生成
	    --更新凭证号 
	    DECLARE @tableName VARCHAR(50) = 'pos_reStorage'
	    DECLARE @idField VARCHAR(50) = 're_id'
	    DECLARE @idValue INT = @re_id;
	    
	    DECLARE @dateField VARCHAR(50) = 're_date'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @re_date, 23)
	    
	    DECLARE @noField VARCHAR(50) = 're_vo'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN

	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	             @idField,
	             @idValue,
	             @dateField,
	             @dateValue,
	             @noField,
	             @prevTxt,
	             @outno OUTPUT,
	             @re_sh_id,
				 @re_cp_id

	        BEGIN TRY
	        	--更新
	        	UPDATE pos_reStorage
	        	SET    re_vo     = @outno
				,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)
	        	WHERE  re_id     = @re_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
			PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
	        END CATCH
	    END
	END
	



	IF @op_type = '分公司补货审核'
	BEGIN


	EXEC pro_update_unique_time @id=@re_id, @type='pos补货';

	DECLARE @si_company INT= 0;
	DECLARE @al_to_cp_id INT= 0;
    DECLARE @nowal DATETIME = GETDATE();
	if @re_cp_id>0
	begin
				UPDATE pos_reStorage
			    SET re_status=2,
				re_main_audit_time = GETDATE(),
				re_main_audit_man = @re_add_man
				WHERE  re_id = @re_id;
		end
	END


	if @op_type='取消分公司补货审核'
	begin

			UPDATE pos_reStorage
			    SET re_status=1,
				re_main_audit_time = GETDATE(),
				re_main_audit_man = @re_add_man
				WHERE  re_id = @re_id;


		--IF EXISTS(SELECT 1 FROM pos_ogStorage AS pa WHERE  pa.og_source_type=1 AND pa.og_source_id=@re_id and pa.og_status=1 )
	 --   BEGIN
		   	
		--	--来源类型
		--	DECLARE @source INT = 0;
		--	--来源主键
		--	DECLARE @og_id INT = 0;

		--    SELECT @source = jt.og_source_type,
	 --              @og_id = jt.og_id
	 --       FROM   pos_ogStorage AS jt
	 --       WHERE  jt.og_source_type=1 AND jt.og_source_id=@re_id and jt.og_status=1


		--	IF @source = 1
	 --       BEGIN
	            
		--	   UPDATE pos_ogStorage
		--	   SET    og_status = 0
		--	   WHERE  og_id = @og_id;

		--	   UPDATE pos_ogStorageList
		--	   SET    ogl_status = 0
		--	   WHERE  ogl_og_id = @og_id
	 --       END

		--end

	end



	IF @op_type = '补货审核'
	BEGIN
	    SET @result = '';

	    DECLARE @fristflag INT = 0;
	    BEGIN
	    	
			EXEC pro_goodsstock_op @re_id , 'posshoprestorage' , @re_erp_id , @orderguid OUT
			IF @@error <> 0
             BEGIN
               IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION 
               SET @result = '0';
               RETURN 0;
             END

		   IF @orderguid <> ''
           BEGIN

		    declare @cp_id int=0;
		    select 
			@cp_id=re_tocompanyid
			from pos_reStorage where re_id=@re_id;


			DECLARE @now DATETIME = GETDATE();
			EXEC pro_pos_allocation_op
	    	         @al_id = @fristflag,
	    	         @al_update_time = @now,
	    	         @al_type = 2,
	    	         @al_source = 2,
					 @al_cp_id=@cp_id,
	    	         @al_source_id = @re_id,
	    	         @al_sh_id = @re_sh_id,
					 @al_to_cp_id=@re_cp_id,
	    	         @al_date = @now,
	    	         @al_order_man = @re_add_man,
	    	         @al_add_man = @re_add_man,
					 @al_erp_id=@re_erp_id,
	    	         @al_add_time = @now,
	    	         @op_type = '添加修改单据,明细',
					 @orderguid=@orderguid,
	    	         @result = @result OUT 

			SET @fristflag = @result;


			SET @result = CONVERT(VARCHAR(50), @fristflag);
	    	--CONVERT(varchar(50),@fristflag);
	    	/*
	    	1.单击审核按钮，生成配货单（数据副本），处于删除状态，得到配货单的主键值。
	    	2.有了主键值，使用配货编辑页面，使用里面的增删改功能
	    	3.配货编辑页面的保存按钮要判断是从补货审核那边过来的，是的话，更新配货单的状态为审核状态。
	    	4.为此，就把配货单生成了。
	    	*/
	    	UPDATE pos_allocation
	    	SET    al_status         = 0,
	    	       al_audit_man      = @re_add_man,
	    	       al_audit_time     = @now
	    	WHERE  al_id             = @fristflag;
	    	

				----完成事务
	    	IF @@TRANCOUNT > 0 COMMIT TRANSACTION


	    	END
	    END
	END
	
	
	IF @op_type = '删除补货审核单据'
	BEGIN
	    --删除单据
	    UPDATE pos_allocation
	    SET    al_status         = 0
	    WHERE  al_source_id      = @re_id
	           AND al_source     = 2;
	    
	    --取消补货单据
	    UPDATE pos_reStorage
	    SET    re_is_audit     = 0
	    WHERE  re_id           = @re_id;
	END
	
	IF @op_type = '拒绝审核'
	BEGIN
	    UPDATE pos_reStorage
	    SET    re_is_audit            = 2,
	           re_main_audit_time     = GETDATE(),
	           re_main_audit_man      = @re_add_man
	    WHERE  re_id                  = @re_id;
	END
	
	UPDATE pos_reStorage SET 
re_sh_no
=
	         (
           SELECT sh_no
           FROM   dbo.pos_shop  as  bs
           WHERE  (sh_id = jis.re_supplier_sh_id)
       ),
re_supplier_sh_id_txt
=
       (
           SELECT sh_name
           FROM   dbo.pos_shop  as  bs
           WHERE  (sh_id = jis.re_supplier_sh_id)
       ),
re_sh_id_txt
=
       (
           SELECT sh_name
           FROM   dbo.pos_shop  as  bs
           WHERE  (sh_id = jis.re_sh_id)
       ),
re_order_man_txt
=
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo  as  bs
           WHERE  (si_id = jis.re_order_man)
       ),
re_add_man_txt
=
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo  as  bs
           WHERE  (si_id = jis.re_add_man)
       ),
re_update_man_txt
=
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo  as  bs
           WHERE  (si_id = jis.re_update_man)
       ),
re_main_audit_man_txt
=
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo  as  bs
           WHERE  (si_id = jis.re_main_audit_man)
       ),
in_company
=
       (
           SELECT cp_simplename
           FROM   dbo.companyinfo  as  bs
           WHERE  (cp_id = 1)
       ),
re_audit_man_txt
=
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo  as  bs
           WHERE  (si_id = jis.re_audit_man)
       ),
sumnum
=
       (
           SELECT SUM(rel_num)
           FROM   pos_reStorageList
           WHERE  rel_re_id = jis.re_id
                  AND rel_status = 1
       ),
sum_alnum
=
       (
           SELECT SUM(rel_num)
           FROM   pos_reStorageList
                  LEFT JOIN pos_reStorage
                       ON  rel_re_id = re_id
                  LEFT JOIN pos_allocationList
                       ON  all_source_id = rel_id
                  LEFT JOIN pos_allocation
                       ON  al_id = all_al_id
           WHERE  al_status > 0
                  AND rel_re_id = jis.re_id
                  AND al_source_id = jis.re_id
                  AND rel_status > 0
                  AND re_status > 0
                  AND all_status > 0
                  AND all_source_id > 0
                  AND pos_allocation.al_source=2
                  AND all_source_add_time IS NOT NULL
       ),
summoney
=
       (
           SELECT SUM(rel_money)
           FROM   pos_reStorageList
           WHERE  rel_re_id = jis.re_id
                  AND rel_status = 1
       ),
source_id
=
       (
           SELECT TOP 1 al_id
           FROM   pos_allocation
           WHERE  al_source_id = jis.re_id
                  AND al_status > 0
                  AND al_source_id > 0
                  AND pos_allocation.al_source=2
           ORDER BY
                  al_id
       ),
oo_status
=
       (
           SELECT MAX(oo_status)
           FROM   vi_JoinFK_Allocation
           WHERE  al_source_id = jis.re_id
                  AND al_status > 0
                  AND al_source_id > 0
       ),
cp_name
=
             (
           SELECT  cp_name
           FROM   companyinfo  as  cp
           WHERE  cp.cp_id= fd.sh_company
            
       ),
cp_code
--
=
             (
           SELECT  cp_code
           FROM   companyinfo  as  cp
           WHERE  cp.cp_id= fd.sh_company
            
       ) FROM  pos_reStorage jis INNER JOIN pos_shop fd
on jis.re_sh_id=fd.sh_id
	WHERE jis.re_id=@re_id;
	
	
	IF @@ERROR <> 0
	BEGIN
	    SET @result = '0';
	    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @re_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细'
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @rel_id);
	        END
	        ELSE 
	        IF @op_type = '补货审核'
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @fristflag);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END
END
go

