





CREATE PROC [dbo].[pro_pos_ogStorageList_sku_search_tb]
@ogl_og_id INT = 0,
@ogl_add_time DATETIME = '2004-10-17',
@date VARCHAR(30) ='',
@gi_id INT,
@ci_id INT,
@sh_id INT,
@to_cp_id INT,
@type INT,
@do_type INT=0,
@cpzorf_id int=0,
@cp_id INT = 0 
AS

DECLARE @ghj DECIMAL(9, 2) = 0;
DECLARE @ghj_type INT = 0;
DECLARE @lsj       DECIMAL(9, 2) = 0;
BEGIN

IF @do_type=0   --订货数量
BEGIN
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p
FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT jisl.*
                FROM   pos_ogStorageList AS jisl     
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_status = 1

            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;
END
ELSE IF @do_type=2 --未采购数量
BEGIN
	--订单采购
	SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p2
	FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT 
                ogl_id, ogl_og_id, ogl_gi_id, ogl_sku_id, 
               (ogl_num-ISNULL(fd.pll_num,0)-ISNULL(jisl.ogl_pause_num_pll,0)) AS ogl_num, 
               ogl_retail_price, ogl_stock_price, ogl_money, 
               ogl_retail_money, ogl_remark, ogl_status, 
               ogl_add_time, ogl_discount, (ogl_box_num-fd.pll_box_num) as ogl_box_num,
                ogl_pm
                
                FROM   pos_ogStorageList AS jisl
                 LEFT JOIN
                (
                       SELECT 
                       pll_gi_id,
                       pll_source_add_time,
                       pl_source_id,
                       pll_source_id,pll_box_num,
                       SUM(pll_num) AS pll_num
                FROM   j_purchaseStorageList
                       INNER JOIN j_purchaseStorage
                            ON  pll_pl_id = pl_id
                WHERE  pl_status > 0
                       AND pll_status > 0
                       AND pl_source = 1
                       AND pll_source_add_time > 0
                       
                GROUP BY
                       pl_source_id,
                       pll_gi_id,
                       pll_source_add_time,
                       pll_source_id,
                       pll_box_num
                ) fd ON  
            ogl_og_id = pl_source_id
            AND 
            pll_gi_id = ogl_gi_id
            AND 
            pll_source_add_time = ogl_add_time
            AND fd.pll_source_id=jisl.ogl_id  
                            
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1
            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;
--UPDATE #p2 SET ogl_retail_price=fd2.gi_retailprice,ogl_stock_price=fd2.gi_purchase,ogl_discount=fd2.gi_purchase_discount
--FROM #p2,b_goodsinfo fd2
--WHERE #p2.gi_id=fd2.gi_id

END
ELSE IF @do_type=1 --未配货数量
BEGIN
	--未订单配货
	SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p3
	FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT 
                ogl_id, ogl_og_id, ogl_gi_id, ogl_sku_id, 
               (ogl_num-ISNULL(fd.all_num,0)-ISNULL(jisl.ogl_pause_num,0)) AS ogl_num, ogl_retail_price, ogl_stock_price, ogl_money, ogl_retail_money, ogl_remark, ogl_status, ogl_add_time, ogl_discount, ogl_box_num, ogl_pm
                
                FROM   pos_ogStorageList AS jisl
                LEFT JOIN
                (
                    SELECT all_gi_id,
                       SUM(all_num) AS all_num,
                       all_source_add_time
                
                       ,all_source_id
                FROM   pos_allocationList
                       INNER JOIN pos_allocation
                            ON  all_al_id = al_id
                WHERE  al_status > 0
                       AND all_status > 0
                       AND al_source = 5
                       AND all_source_add_time > 0
                GROUP BY
                    
                       all_gi_id,
                       all_source_add_time,all_source_id
                ) fd  ON  
             fd.all_gi_id = ogl_gi_id
            AND fd.all_source_add_time = ogl_add_time
            AND fd.all_source_id=jisl.ogl_id                
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1
            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;
END
else if @do_type=4--配货数量
begin
  SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p4
	FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT 
                ogl_id, ogl_og_id, ogl_gi_id, ogl_sku_id, 
                fd.all_num AS ogl_num, ogl_retail_price, ogl_stock_price, ogl_money, ogl_retail_money, ogl_remark, ogl_status, ogl_add_time, ogl_discount, ogl_box_num, ogl_pm
                
                FROM   pos_ogStorageList AS jisl
                LEFT JOIN
                (
                    SELECT all_gi_id,
                       SUM(all_num) AS all_num,
                       all_source_add_time,
                       al_source_id,all_source_id
                FROM   pos_allocationList
                       INNER JOIN pos_allocation
                            ON  all_al_id = al_id
                WHERE  al_status > 0
                       AND all_status > 0
                       AND al_source = 5
                       AND all_source_add_time > 0
                GROUP BY
                       al_source_id,
                       all_gi_id,
                       all_source_add_time,all_source_id
                ) fd  ON  ogl_og_id = fd.al_source_id
            AND fd.all_gi_id = ogl_gi_id
            AND fd.all_source_add_time = ogl_add_time
            AND fd.all_source_id=jisl.ogl_id                
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1
            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;
end
else if @do_type=5--采购数量
begin
  	--订单采购
	SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p5
	FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT 
                ogl_id, ogl_og_id, ogl_gi_id, ogl_sku_id, 
                fd.pll_num AS ogl_num, 
               ogl_retail_price, ogl_stock_price, ogl_money, 
               ogl_retail_money, ogl_remark, ogl_status, 
               ogl_add_time, ogl_discount, (ogl_box_num-fd.pll_box_num) as ogl_box_num,
                ogl_pm
                
                FROM   pos_ogStorageList AS jisl
                 LEFT JOIN
                (
                       SELECT 
                       pll_gi_id,
                       pll_source_add_time,
                       pl_source_id,
                       pll_source_id,pll_box_num,
                       SUM(pll_num) AS pll_num
                FROM   j_purchaseStorageList
                       INNER JOIN j_purchaseStorage
                            ON  pll_pl_id = pl_id
                WHERE  pl_status > 0
                       AND pll_status > 0
                       AND pl_source = 1
                       AND pll_source_add_time > 0
                       
                GROUP BY
                       pl_source_id,
                       pll_gi_id,
                       pll_source_add_time,
                       pll_source_id,
                       pll_box_num
                ) fd ON  
            ogl_og_id = pl_source_id
            AND 
            pll_gi_id = ogl_gi_id
            AND 
            pll_source_add_time = ogl_add_time
            AND fd.pll_source_id=jisl.ogl_id  
                            
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1
            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;
end 
else if @do_type=6 --配货终止数量
begin
  SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p6
	FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT 
                jisl.ogl_id, jisl.ogl_og_id, jisl.ogl_gi_id, jisl.ogl_sku_id, 
                fd.ogl_pause_num AS ogl_num, jisl.ogl_retail_price, jisl.ogl_stock_price, ogl_money, ogl_retail_money, ogl_remark, jisl.ogl_status, jisl.ogl_add_time, ogl_discount, fd.ogl_box_num, jisl.ogl_pm
                
                FROM   pos_ogStorageList AS jisl
                LEFT JOIN
                (
                
                 SELECT     ogl_og_id, ogl_gi_id, ogl_add_time, SUM(ogl_pause_num) AS ogl_pause_num, SUM(ogl_num) AS ogl_num, MIN(ogl_id) AS ogl_id, MAX(ogl_sku_id) AS ogl_sku_id, 
                      CONVERT(DECIMAL(10, 2), AVG(ogl_stock_price)) AS ogl_stock_price, MAX(ogl_discount) AS pll_discount, SUM(ogl_money) AS pll_money, CONVERT(DECIMAL(10, 2), AVG(ogl_retail_price)) 
                      AS ogl_retail_price, MAX(ogl_status) AS ogl_status, MAX(REPLACE(ogl_pm, '*', ',')) AS ogl_pm, MAX(ogl_box_num) AS ogl_box_num
FROM         dbo.pos_ogStorageList AS jt
GROUP BY ogl_og_id, ogl_gi_id, ogl_add_time,ogl_id

                
                
                ) fd  ON  jisl.ogl_og_id = fd.ogl_og_id
            AND fd.ogl_gi_id = jisl.ogl_gi_id
            AND fd.ogl_add_time = jisl.ogl_add_time
            AND fd.ogl_id=jisl.ogl_id                
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1
            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;


end
else if @do_type=7--采购终止数量
begin

SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p7
	FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT 
                jisl.ogl_id, jisl.ogl_og_id, jisl.ogl_gi_id, jisl.ogl_sku_id, 
                fd.ogl_pause_num_pll AS ogl_num, jisl.ogl_retail_price, jisl.ogl_stock_price, ogl_money, ogl_retail_money, ogl_remark, jisl.ogl_status, jisl.ogl_add_time, ogl_discount, fd.ogl_box_num, jisl.ogl_pm
                
                FROM   pos_ogStorageList AS jisl
                LEFT JOIN
                (
                
                 SELECT     ogl_og_id, ogl_gi_id, ogl_add_time, SUM(ogl_pause_num_pll) AS ogl_pause_num_pll, SUM(ogl_num) AS ogl_num, MIN(ogl_id) AS ogl_id, MAX(ogl_sku_id) AS ogl_sku_id, 
                      CONVERT(DECIMAL(10, 2), AVG(ogl_stock_price)) AS ogl_stock_price, MAX(ogl_discount) AS pll_discount, SUM(ogl_money) AS pll_money, CONVERT(DECIMAL(10, 2), AVG(ogl_retail_price)) 
                      AS ogl_retail_price, MAX(ogl_status) AS ogl_status, MAX(REPLACE(ogl_pm, '*', ',')) AS ogl_pm, MAX(ogl_box_num) AS ogl_box_num
FROM         dbo.pos_ogStorageList AS jt
GROUP BY ogl_og_id, ogl_gi_id, ogl_add_time,ogl_id

                
                
                ) fd  ON  jisl.ogl_og_id = fd.ogl_og_id
            AND fd.ogl_gi_id = jisl.ogl_gi_id
            AND fd.ogl_add_time = jisl.ogl_add_time
            AND fd.ogl_id=jisl.ogl_id                
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1
            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;

end
else if @do_type=8--发货数量
begin
  	--订单发货
	SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p8
	FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT 
                ogl_id, ogl_og_id, ogl_gi_id, ogl_sku_id, 
                fd.ol_number AS ogl_num, 
               ogl_retail_price, ogl_stock_price, ogl_money, 
               ogl_retail_money, ogl_remark, ogl_status, 
               ogl_add_time, ogl_discount, (ogl_box_num-fd.ol_box_num) as ogl_box_num,
                ogl_pm
                
                FROM   pos_ogStorageList AS jisl
                 LEFT JOIN
                (
                       SELECT 
                       ol_siid,
                       ol_topsource_id,
					   ol_box_num,
                       SUM(ol_number) AS ol_number
                FROM   j_outStorageList
                       INNER JOIN j_outStorage
                            ON  ol_eoid = oo_id
                WHERE  oo_status > 0
                       AND ol_status > 0
                       AND oo_source_type = 1
                       AND ol_source_add_time > 0
                       
                GROUP BY
                       ol_siid,
                       ol_topsource_id,
					   ol_box_num
                ) fd ON ol_siid = ogl_gi_id
            AND fd.ol_topsource_id=jisl.ogl_id  
                            
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1
            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;
end 
else if @do_type=9--未发数量
begin
  	--订单发货
	SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p9
	FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT 
                ogl_id, ogl_og_id, ogl_gi_id, ogl_sku_id, 
               (ogl_num-fd.ol_number) AS ogl_num, 
               ogl_retail_price, ogl_stock_price, ogl_money, 
               ogl_retail_money, ogl_remark, ogl_status, 
               ogl_add_time, ogl_discount, (ogl_box_num-fd.ol_box_num) as ogl_box_num,
                ogl_pm
                
                FROM   pos_ogStorageList AS jisl
                 LEFT JOIN
                (
                       SELECT 
                       ol_siid,
                       ol_topsource_id,
					   ol_box_num,
                       SUM(ol_number) AS ol_number
                FROM   j_outStorageList
                       INNER JOIN j_outStorage
                            ON  ol_eoid = oo_id
                WHERE  oo_status > 0
                       AND ol_status > 0
                       AND oo_source_type = 1
                       AND ol_source_add_time > 0
                       
                GROUP BY
                       ol_siid,
                       ol_topsource_id,
					   ol_box_num
                ) fd ON ol_siid = ogl_gi_id
            AND fd.ol_topsource_id=jisl.ogl_id  
                            
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1
            )          AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id;
end 



--分公司时设置零售价为吊牌价
IF @cpzorf_id != 0
BEGIN
if EXISTS(SELECT c.cp_goods_type FROM  companyinfo c WHERE  c.cp_id = @cpzorf_id and cp_goods_type!=0)
		BEGIN
    SELECT @lsj = gd_price
    FROM   b_goods_discount
    WHERE  gd_gi_id = @gi_id
           AND gd_type IN (SELECT c.cp_goods_type
                           FROM   companyinfo c
                           WHERE  c.cp_id = @cpzorf_id)
           AND gd_class = 1
    
    IF @do_type = 0
    BEGIN
        UPDATE #p
        SET    gs_marketprice = @lsj
        
        UPDATE #p
        SET    gs_purchase = gs_marketprice * gs_discount
    END
    ELSE 
    IF @do_type = 1
    BEGIN
        UPDATE #p3
        SET    gs_marketprice = @lsj
        
        UPDATE #p3
        SET    gs_purchase = gs_marketprice * gs_discount
    END
    ELSE 
    IF @do_type = 2
    BEGIN
        UPDATE #p2
        SET    gs_marketprice = @lsj
        
        UPDATE #p2
        SET    gs_purchase = gs_marketprice * gs_discount
    END
	END
END

DECLARE @discount  DECIMAL(9, 2) = 1
IF @do_type=0
BEGIN

declare @returntable table(
		cspid int,
		gi_id int,
		sku_id int,
		retailprice DECIMAL(9, 2),--零售价
		discount DECIMAL(9, 2),
		importprices DECIMAL(9, 2)    --供货价
)
IF @date !=''
BEGIN
	INSERT @returntable
	SELECT 
	cspid,gi_id,sku_id,retailprice,discount,importprices 
	FROM dbo.FnGoodsCustomPrice(@ci_id,@sh_id,@to_cp_id,@date,@gi_id,0,@cp_id)
END

if exists (select * from @returntable)  
begin

	update #p set
		  gs_marketprice=l.retailprice,
		  gs_salesprice= l.importprices,
		  gs_purchase = l.importprices,
		  gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id

end
else
begin
	INSERT @returntable
	SELECT
				0,
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
	FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,@ci_id,@sh_id,@to_cp_id,@type)
	 
	 update #p set
		        gs_salesprice= l.importprices,
				gs_purchase = l.importprices,
				gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id
end


--客户主键大于0
--IF @ci_id > 0 AND @type>0
--BEGIN

--     IF @type = 1
--			BEGIN
--		        SELECT @ghj_type = ci_dhprice,@discount=ci_dhdiscount FROM   b_clientinfo WHERE  ci_id = @ci_id AND ci_dhprice > 0
--		    END	          
--		    ELSE 
--		    IF @type = 2
--			BEGIN
--		        SELECT @ghj_type = ci_bhprice,@discount=ci_bhdiscount FROM  b_clientinfo WHERE  ci_id = @ci_id AND ci_bhprice > 0
--		    END	
--		    ELSE 
--		    IF @type = 3
--			BEGIN
--		        SELECT @ghj_type = ci_phprice,@discount=ci_phdiscount FROM   b_clientinfo WHERE  ci_id = @ci_id AND ci_phprice > 0
--		    END	 
--		    ELSE 
--		    IF @type = 4
--			BEGIN
--		        SELECT @ghj_type = ci_mdprice,@discount=ci_mddiscount FROM   b_clientinfo WHERE  ci_id = @ci_id AND ci_mdprice > 0
--			END
	
	
		
	
--    SELECT @ghj = gd_price
--    FROM   b_goods_discount
--    WHERE  gd_gi_id = @gi_id
--           AND gd_class = 2
--           AND gd_type = @ghj_type
    
--         SELECT @lsj = gi_retailprice
--		    FROM   b_goodsinfo
--		    WHERE   gi_id = @gi_id
--    IF @ghj > 0.00
--    BEGIN
--	   set @ghj=@ghj*@discount
--        UPDATE #p
--        SET    gs_purchase = @ghj
--       , gs_salesprice = @ghj
              
--           UPDATE #p
--		        SET    gs_marketprice = @lsj
--        UPDATE #p
--        SET    gs_discount = (
--                   CASE 
--                        WHEN gs_marketprice = 0.00 THEN 0.00
--                        ELSE gs_purchase / gs_marketprice
--                   END
--               )
--    END
--    ELSE
--    BEGIN
    	
--        --UPDATE #p
--        --SET    gs_purchase = gs_salesprice
        
--        UPDATE #p
--        SET    gs_purchase = gs_marketprice
        
--        UPDATE #p
--        SET    gs_discount = (
--                   CASE 
--                        WHEN gs_marketprice = 0.00 THEN 0.00
--                        ELSE gs_purchase / gs_marketprice
--                   END
--        )
        
--    END
    
	
	
    
    
    
--END 
--ELSE IF @sh_id>0 AND @type>0
--		BEGIN
			
			
--			--有选择店铺,并且有设置交易方式
--		     IF @type = 1
--			BEGIN

--		        SELECT @ghj_type = sh_dhprice,@discount= sh_dhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_dhprice>0
--		    END         
--		    ELSE 
--		    IF @type = 2
--			BEGIN

--		        SELECT @ghj_type = sh_bhprice,@discount= sh_bhdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_bhprice>0
--		    END 
--		    ELSE 
--		    IF @type = 3
--			BEGIN
	
--		        SELECT @ghj_type = sh_phprice,@discount= sh_phdiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_phprice>0
		               
--		    END	           
--		    ELSE 
--		    IF @type = 4
--			BEGIN
		
--		        SELECT @ghj_type = sh_mdprice,@discount= sh_mddiscount FROM pos_shop WHERE sh_id = @sh_id AND sh_mdprice>0
--			END	
		    
--		    --得到价格
--		    SELECT @ghj = gd_price
--		    FROM   b_goods_discount
--		    WHERE  gd_gi_id = @gi_id
--		           AND gd_class = 2
--		           AND gd_type = @ghj_type
		           
--		           SELECT @lsj = gi_retailprice
--		    FROM   b_goodsinfo
--		    WHERE   gi_id = @gi_id

--    IF @ghj > 0.00
--    BEGIN
--		set @ghj=@ghj*@discount
--        UPDATE #p
--        SET    gs_purchase = @ghj
--               , gs_salesprice = @ghj
--           UPDATE #p
--		        SET    gs_marketprice = @lsj
		
		        
--		        --更新折扣价
--		        UPDATE #p
--		        SET    gs_discount = (
--		                   CASE 
--		                        WHEN gs_marketprice = 0.00 THEN 0.00
--		                        ELSE gs_purchase / gs_marketprice
--		                   END
--		        )
		        
--		    END
--		    ELSE
--		    BEGIN
		    	
		    	
--		        --UPDATE #p
--		        --SET    gs_purchase = gs_salesprice
		       
--		        UPDATE #p
--		        SET    gs_purchase = gs_marketprice
		        
--		        UPDATE #p
--		        SET    gs_discount = (
--		                   CASE 
--		                        WHEN gs_marketprice = 0.00 THEN 0.00
--		                        ELSE gs_purchase / gs_marketprice
--		                   END
--		        )
		        
		        
--			END
--	END	
--	ELSE IF @to_cp_id>0 AND @type>0
--		BEGIN
			
			
--			--有选择店铺,并且有设置交易方式
--		     IF @type = 1
--			BEGIN
	
--		        SELECT @ghj_type = cp_dhprice,@discount=cp_dhdiscount FROM   companyinfo WHERE  cp_id = @to_cp_id AND cp_dhprice > 0
--		    END	          
--		    ELSE 
--		    IF @type = 2
--			BEGIN
		
--		        SELECT @ghj_type = cp_bhprice,@discount=cp_bhdiscount FROM   companyinfo WHERE  cp_id = @to_cp_id AND cp_bhprice > 0
--		    END	
--		    ELSE 
--		    IF @type = 3
--			BEGIN
		
--		        SELECT @ghj_type = cp_phprice,@discount=cp_phdiscount FROM   companyinfo WHERE  cp_id = @to_cp_id AND cp_phprice > 0
--		    END	 
--		    ELSE 
--		    IF @type = 4
--			BEGIN
		
--		        SELECT @ghj_type = cp_mdprice,@discount=cp_mddiscount FROM   companyinfo WHERE  cp_id = @to_cp_id AND cp_mdprice > 0
--			END
		    
--		    --得到价格
--		    SELECT @ghj = gd_price
--		    FROM   b_goods_discount
--		    WHERE  gd_gi_id = @gi_id
--		           AND gd_class = 2
--		           AND gd_type = @ghj_type
		           
--		            SELECT @lsj = gi_retailprice
--		    FROM   b_goodsinfo
--		    WHERE   gi_id = @gi_id

--    IF @ghj > 0.00
--    BEGIN
--		set @ghj=@ghj*@discount
--        UPDATE #p
--        SET    gs_purchase = @ghj
--               , gs_salesprice = @ghj
--           UPDATE #p
--		        SET    gs_marketprice = @lsj
--		        --更新折扣价
--		        UPDATE #p
--		        SET    gs_discount = (
--		                   CASE 
--		                        WHEN gs_marketprice = 0.00 THEN 0.00
--		                        ELSE gs_purchase / gs_marketprice
--		                   END
--		        )
		        
--		    END
--		    ELSE
--		    BEGIN
		    	
		    	
--		        UPDATE #p
--		        SET    gs_purchase = gs_marketprice
		        
--		        UPDATE #p
--		        SET    gs_discount = (
--		                   CASE 
--		                        WHEN gs_marketprice = 0.00 THEN 0.00
--		                        ELSE gs_purchase / gs_marketprice
--		                   END
--		        )
		        
		        
--			END
--	END	      
--	ELSE
--	BEGIN
--	IF (@ci_id>0 OR @sh_id>0 OR @to_cp_id>0) AND @type=0
--	BEGIN
		
--	UPDATE #p
--	SET    gs_purchase = gs_marketprice
    
--    UPDATE #p
--    SET    gs_discount = (
--               CASE 
--                    WHEN gs_marketprice = 0.00 THEN 0.00
--                    ELSE gs_purchase / gs_marketprice
--               END
--    )
--    WHERE gs_purchase>0
		
		
--	END
--	END


	
	
END








IF @do_type=0
BEGIN
	
SELECT * FROM   #p

END ELSE 
IF @do_type=1
BEGIN
select * from #p3
END ELSE IF @do_type=2
BEGIN
	select * from #p2
END
else if @do_type=4--配货数量
begin
  select * from #p4;
end

else if @do_type=5--采购数量
begin
  	--订单采购
	select * from #p5;
end
else if @do_type=6--配货终止数量
begin
  	--订单采购
	select * from #p6;
end
else if @do_type=7--采购终止数量
begin
  	--订单采购
	select * from #p7;
end
else if @do_type=8--发货数量
begin
  	--订单发货
	select * from #p8;
end
else if @do_type=9--未发数量
begin
  	--订单发货
	select * from #p9;
end



END
go

