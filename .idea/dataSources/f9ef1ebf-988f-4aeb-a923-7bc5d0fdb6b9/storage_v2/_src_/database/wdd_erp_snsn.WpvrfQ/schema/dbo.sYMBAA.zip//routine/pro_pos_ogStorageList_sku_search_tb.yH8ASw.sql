





CREATE PROC [dbo].[pro_pos_ogStorageList_sku_search_tb]
@ogl_og_id INT = 0,
@ogl_add_time DATETIME = '2004-10-17',
@date VARCHAR(30) ='',
@gi_id INT,
@ci_id INT,
@sh_id INT,
@to_cp_id INT,
@type INT,
@do_type INT=0,
@cpzorf_id int=0,
@cp_id INT = 0 ,
@ogl_pm varchar(500) ='',
@colorid INT=0
AS

DECLARE @ghj DECIMAL(9, 2) = 0;
DECLARE @ghj_type INT = 0;
DECLARE @lsj       DECIMAL(9, 2) = 0;
BEGIN

declare @og table(
 ogl_id INT,
 ogl_og_id int,
 ogl_gi_id int,
 ogl_sku_id int,
 ogl_num varchar(500),
 ogl_retail_price decimal(10,2),
 ogl_stock_price decimal(10,2),
 ogl_money decimal(10,2),
 ogl_retail_money decimal(10,2),
 ogl_remark varchar(50),
 ogl_status int,
 ogl_add_time datetime,--主要用去区别箱数
 ogl_discount decimal(10,2),
 ogl_box_num  int,
 ogl_pm varchar(500),
 isbox int  --
)

IF @do_type=0 --订货数量
begin
    
	INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
	ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
	 SELECT    ogl_id, 
			   ogl_og_id, 
			   ogl_gi_id, 
			   ogl_sku_id, 
               ogl_num, 
               ogl_retail_price, 
			   ogl_stock_price, 
			   ogl_money, 
               ogl_retail_money, 
			   ogl_remark, 
			   ogl_status, 
               ogl_add_time,
			   ogl_discount, 
			   ogl_box_num,
               ogl_pm
    FROM   pos_ogStorageList AS jisl     
    WHERE  jisl.ogl_og_id = @ogl_og_id
    AND jisl.ogl_status = 1 
	and isnull(jisl.ogl_pm,'')=@ogl_pm

end
else IF @do_type=2  --未采购数量
begin
		 INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
		 ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
		 SELECT 
               ogl_id, 
			   ogl_og_id, 
			   ogl_gi_id, 
			   ogl_sku_id, 
               (isnull(ogl_num,0)-ISNULL(fd.pll_num,0)-ISNULL(jisl.ogl_pause_num_pll,0)) AS ogl_num, 
               ogl_retail_price, 
			   ogl_stock_price, 
			   ogl_money, 
               ogl_retail_money, 
			   ogl_remark, 
			   ogl_status, 
               ogl_add_time,
			   ogl_discount, 
			   (isnull(ogl_box_num,0)-isnull(fd.pll_box_num,0)-isnull(jisl.ogl_pause_box_num_pll,0)) as ogl_box_num,
               ogl_pm
               FROM pos_ogStorageList AS jisl
               LEFT JOIN
                (
					SELECT 
							SUM(pll_num) AS pll_num,
							sum(pll_box_num) as pll_box_num,
							pll_source_id
					FROM   vi_ogstorage_puchased
					GROUP BY pll_source_id
                ) fd ON  
                fd.pll_source_id = jisl.ogl_id
              WHERE jisl.ogl_og_id = @ogl_og_id
                 AND jisl.ogl_add_time = @ogl_add_time 
				 AND jisl.ogl_status = 1
				 and isnull(jisl.ogl_pm,'')=@ogl_pm

end
ELSE IF @do_type=1 --未配货数量
BEGIN
		INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
		 ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
			SELECT 
               ogl_id, 
			   ogl_og_id, 
			   ogl_gi_id, 
			   ogl_sku_id, 
               (isnull(ogl_num,0)-ISNULL(fd.all_num,0)-ISNULL(jisl.ogl_pause_num,0)) AS ogl_num, 
			   ogl_retail_price, 
			   ogl_stock_price, 
			   ogl_money, 
			   ogl_retail_money, 
			   ogl_remark, 
			   ogl_status, 
			   ogl_add_time, 
			   ogl_discount, 
			   (isnull(ogl_box_num,0)-isnull(fd.all_box_num,0)-isnull(jisl.ogl_pause_box_num,0)) as ogl_box_num,
			   ISNULL(ogl_pm,'') as ogl_pm
               FROM   pos_ogStorageList AS jisl
                LEFT JOIN
                (
					SELECT SUM(all_num) AS all_num,
						sum(all_box_num) as all_box_num,
						all_source_id
					FROM  vi_ogstorage_allocationed
					GROUP BY all_source_id
                ) fd  ON  fd.all_source_id = jisl.ogl_id          
                    WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1 
					   and isnull(jisl.ogl_pm,'')=@ogl_pm
					   

end
else if @do_type=4--配货数量
begin

	INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
		 ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
    SELECT 
                ogl_id, 
				ogl_og_id, 
				ogl_gi_id, 
				ogl_sku_id, 
                fd.all_num AS ogl_num, 
				ogl_retail_price, 
				ogl_stock_price, 
				ogl_money, 
				ogl_retail_money, 
				ogl_remark, 
				ogl_status, 
				ogl_add_time, 
				ogl_discount, 
				fd.all_box_num as ogl_box_num, 
				ogl_pm
                FROM   pos_ogStorageList AS jisl
                LEFT JOIN
                (
                    SELECT SUM(all_num) AS all_num,
						sum(all_box_num) as all_box_num,
						all_source_id
					FROM  vi_ogstorage_allocationed
					GROUP BY all_source_id
                ) fd  ON  fd.all_source_id = jisl.ogl_id  
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1 and isnull(jisl.ogl_pm,'')=@ogl_pm

end
else if @do_type=5--采购数量
begin
		INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
		 ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
         SELECT 
                ogl_id, 
				ogl_og_id, 
				ogl_gi_id, 
				ogl_sku_id, 
                fd.pll_num AS ogl_num, 
                ogl_retail_price, 
				ogl_stock_price, 
				ogl_money, 
                ogl_retail_money, 
				ogl_remark, 
				ogl_status, 
                ogl_add_time, 
				ogl_discount, 
				(fd.pll_box_num) as ogl_box_num,
                ogl_pm
                FROM   pos_ogStorageList AS jisl
                 LEFT JOIN
                (
                  SELECT 
							SUM(pll_num) AS pll_num,
							sum(pll_box_num) as pll_box_num,
							pll_source_id
					FROM   vi_ogstorage_puchased
					GROUP BY pll_source_id
                ) fd ON  
				fd.pll_source_id = jisl.ogl_id
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1 and isnull(jisl.ogl_pm,'')=@ogl_pm

end
else if @do_type=6 --配货终止数量
begin
          INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
		 ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
		   SELECT 
                jisl.ogl_id, 
				jisl.ogl_og_id, 
				jisl.ogl_gi_id, 
				jisl.ogl_sku_id, 
                jisl.ogl_pause_num AS ogl_num, 
				jisl.ogl_retail_price, 
				jisl.ogl_stock_price, 
				jisl.ogl_money, 
				jisl.ogl_retail_money, 
				jisl.ogl_remark, 
				jisl.ogl_status, 
				jisl.ogl_add_time, 
				jisl.ogl_discount, 
				jisl.ogl_pause_box_num as ogl_box_num, 
				jisl.ogl_pm
                FROM   pos_ogStorageList AS jisl  
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1 and isnull(jisl.ogl_pm,'')=@ogl_pm

end
else if @do_type=7--采购终止数量
begin
    INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
		 ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
    SELECT 
                 jisl.ogl_id,
				 jisl.ogl_og_id, 
				 jisl.ogl_gi_id,
				 jisl.ogl_sku_id, 
                 jisl.ogl_pause_num_pll AS ogl_num, 
				 jisl.ogl_retail_price,
				 jisl.ogl_stock_price, 
				 jisl.ogl_money, 
				 jisl.ogl_retail_money, 
				 jisl.ogl_remark, 
				 jisl.ogl_status, 
				 jisl.ogl_add_time, 
				 jisl.ogl_discount, 
				 jisl.ogl_pause_box_num_pll as ogl_box_num, 
				 jisl.ogl_pm
                FROM   pos_ogStorageList AS jisl
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1 and isnull(jisl.ogl_pm,'')=@ogl_pm
end
else if @do_type=8--发货数量
begin 

      INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
		 ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
         SELECT 
               ogl_id, 
			   ogl_og_id, 
			   ogl_gi_id, 
			   ogl_sku_id, 
               fd.ol_number AS ogl_num, 
               ogl_retail_price, 
			   ogl_stock_price, 
			   ogl_money, 
               ogl_retail_money, 
			   ogl_remark, 
			   ogl_status, 
               ogl_add_time, 
			   ogl_discount, 
			   fd.ol_box_num as ogl_box_num,
               ogl_pm
               FROM  pos_ogStorageList AS jisl
                LEFT JOIN
                (

                SELECT  ol_topsource_id,
					   sum(ol_box_num) as ol_box_num,
                       SUM(ol_number) AS ol_number
                FROM  vi_ogstorage_outed
                GROUP BY ol_topsource_id

                ) fd ON fd.ol_topsource_id=jisl.ogl_id  
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1 and isnull(jisl.ogl_pm,'')=@ogl_pm

end
else if @do_type=9--未发数量
begin

    INSERT INTO @og(ogl_id,ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_num,ogl_retail_price,ogl_stock_price,ogl_money,ogl_retail_money,ogl_remark,
		 ogl_status,ogl_add_time,ogl_discount,ogl_box_num,ogl_pm)
   SELECT 
               ogl_id, 
			   ogl_og_id, 
			   ogl_gi_id, 
			   ogl_sku_id, 
               (isnull(ogl_num,0)-isnull(fd.ol_number,0)) AS ogl_num, 
               ogl_retail_price, 
			   ogl_stock_price, 
			   ogl_money, 
               ogl_retail_money, 
			   ogl_remark, 
			   ogl_status, 
               ogl_add_time, 
			   ogl_discount, 
			   (isnull(ogl_box_num,0)-isnull(fd.ol_box_num,0)) as ogl_box_num,
               ogl_pm
               FROM  pos_ogStorageList AS jisl
                 LEFT JOIN
                (
                      SELECT  ol_topsource_id,
					   sum(ol_box_num) as ol_box_num,
                       SUM(ol_number) AS ol_number
					FROM  vi_ogstorage_outed
					GROUP BY ol_topsource_id
                ) fd ON fd.ol_topsource_id=jisl.ogl_id  
                WHERE  jisl.ogl_og_id = @ogl_og_id
                       AND jisl.ogl_add_time = @ogl_add_time
                       AND jisl.ogl_status = 1 and isnull(jisl.ogl_pm,'')=@ogl_pm
end


SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p
FROM   b_goodsruleset  AS bg
       LEFT JOIN @og  AS p1
            ON  bg.gi_id = p1.ogl_gi_id
            AND bg.gss_id = p1.ogl_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;


IF @cpzorf_id != 0
BEGIN
if EXISTS(SELECT c.cp_goods_type FROM  companyinfo c WHERE  c.cp_id = @cpzorf_id and cp_goods_type!=0)
		BEGIN
    SELECT @lsj = gd_price
    FROM   b_goods_discount
    WHERE  gd_gi_id = @gi_id
           AND gd_type IN (SELECT c.cp_goods_type
                           FROM   companyinfo c
                           WHERE  c.cp_id = @cpzorf_id)
           AND gd_class = 1
    
    IF @do_type = 0
    BEGIN
        UPDATE #p
        SET    gs_marketprice = @lsj
        
        UPDATE #p
        SET    gs_purchase = gs_marketprice * gs_discount
    END
    ELSE 
    IF @do_type = 1
    BEGIN
        UPDATE #p
        SET    gs_marketprice = @lsj
        
        UPDATE #p
        SET    gs_purchase = gs_marketprice * gs_discount
    END
    ELSE 
    IF @do_type = 2
    BEGIN
        UPDATE #p
        SET    gs_marketprice = @lsj
        
        UPDATE #p
        SET    gs_purchase = gs_marketprice * gs_discount
    END
	END
END



DECLARE @discount  DECIMAL(9, 2) = 1
IF @do_type=0
BEGIN

declare @returntable table(
		cspid int,
		gi_id int,
		sku_id int,
		retailprice DECIMAL(9, 2),--零售价
		discount DECIMAL(9, 2),
		importprices DECIMAL(9, 2)    --供货价
)
IF @date !=''
BEGIN
	INSERT @returntable
	SELECT 
	cspid,gi_id,sku_id,retailprice,discount,importprices 
	FROM dbo.FnGoodsCustomPrice(@ci_id,@sh_id,@to_cp_id,@date,@gi_id,0,@cp_id)
END

if exists (select * from @returntable)  
begin

	update #p set
		  gs_marketprice=l.retailprice,
		  gs_salesprice= l.importprices,
		  gs_purchase = l.importprices,
		  gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id

end
else
begin
	INSERT @returntable
	SELECT
				0,
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
	FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,@ci_id,@sh_id,@to_cp_id,@type)
	 
	 update #p set
		        gs_salesprice= l.importprices,
				gs_purchase = l.importprices,
				gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id
end

END




SELECT * FROM   #p


END
go

