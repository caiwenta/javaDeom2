
CREATE PROC [dbo].[pro_pos_salelist_sku_search_tb]
@sal_sa_id INT = 0,
@sal_add_time DATETIME = '2004-10-17',
@gi_id INT,
@sh_id INT = 0
AS
BEGIN
 IF @sal_sa_id != 0
 BEGIN
     SELECT bg.*,
            p1.*,
            bg2.gi_name,
            bg2.gi_code INTO #p
     FROM   b_goodsruleset AS bg
            LEFT JOIN (
                     SELECT *
                     FROM   pos_saleList AS jisl
                     WHERE  jisl.sal_sa_id = @sal_sa_id
                            AND jisl.sal_add_time = @sal_add_time
                            AND jisl.sal_status = 1
                            AND jisl.sal_gi_id = @gi_id
                 ) AS p1
                 ON  bg.gi_id = p1.sal_gi_id
                 AND bg.gss_id = p1.sal_sku_id
            LEFT JOIN b_goodsinfo bg2
                 ON  bg.gi_id = bg2.gi_id
     WHERE  bg.gi_id = @gi_id;
     
     SELECT *
     FROM   #p
 END
 ELSE
 BEGIN
     IF @sh_id != 0
     BEGIN
         SELECT SUM(pl.sal_num) AS sal_num,
                bg.gss_id,
                bg.gs_name,
                bg.gs_marketprice,
                bg.gs_costprice,
                bg.gs_purchase,
                bg.gi_id,
                bg.gs_id,
                bg.gs_is_custom,
                bg.gs_discount,
                bg.gss_no,
                SUM(pl.sal_money) AS sal_money,
                pl.sal_gi_id,
                --pl.sal_add_time,
                --pl.sal_sa_id,
                pl.sal_sku_id,
                pl.sal_retail_price,
                pl.sal_real_price,
                pl.sal_discount,
                MAX(ps.sa_sh_id)
         FROM   b_goodsruleset bg
                LEFT JOIN pos_saleList pl
                     ON  bg.gi_id = pl.sal_gi_id
                     AND bg.gss_id = pl.sal_sku_id
                LEFT JOIN pos_sale ps
                     ON  ps.sa_id = pl.sal_sa_id
         WHERE  bg.gi_id = @gi_id
                AND ps.sa_sh_id = @sh_id
         GROUP BY
                bg.gss_id,
                pl.sal_num,
                bg.gi_id,
                bg.gs_id,
                bg.gss_no,
                --pl.sal_sa_id,
                pl.sal_gi_id,
                pl.sal_money,
                pl.sal_retail_price,
                pl.sal_real_price,
                pl.sal_discount,
                --pl.sal_add_time,
                pl.sal_sku_id,
                bg.gs_name,
                bg.gs_marketprice,
                bg.gs_costprice,
                bg.gs_purchase,
                bg.gs_is_custom,
                bg.gs_discount,
                ps.sa_sh_id
     END
     ELSE
     BEGIN
         SELECT SUM(pl.sal_num) AS sal_num,
                bg.gss_id,
                bg.gs_name,
                bg.gs_marketprice,
                bg.gs_costprice,
                bg.gs_purchase,
                bg.gi_id,
                bg.gs_id,
                bg.gs_is_custom,
                bg.gs_discount,
                bg.gss_no,
                SUM(pl.sal_money) AS sal_money,
                pl.sal_gi_id,
                --pl.sal_add_time,
                --pl.sal_sa_id,
                pl.sal_sku_id,
                pl.sal_retail_price,
                pl.sal_real_price,
                pl.sal_discount
         FROM   b_goodsruleset bg
                LEFT JOIN pos_saleList pl
                     ON  bg.gi_id = pl.sal_gi_id
                     AND bg.gss_id = pl.sal_sku_id
         WHERE  bg.gi_id = @gi_id
         GROUP BY
                bg.gss_id,
                pl.sal_num,
                bg.gi_id,
                bg.gs_id,
                bg.gss_no,
                --pl.sal_sa_id,
                pl.sal_gi_id,
                pl.sal_money,
                pl.sal_retail_price,
                pl.sal_real_price,
                pl.sal_discount,
                --pl.sal_add_time,
                pl.sal_sku_id,
                bg.gs_name,
                bg.gs_marketprice,
                bg.gs_costprice,
                bg.gs_purchase,
                bg.gs_is_custom,
                bg.gs_discount
     END
 END
END
go

