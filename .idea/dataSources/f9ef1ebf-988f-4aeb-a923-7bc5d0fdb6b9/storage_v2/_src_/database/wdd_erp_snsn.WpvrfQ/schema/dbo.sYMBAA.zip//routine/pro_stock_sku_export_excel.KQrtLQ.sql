CREATE  Proc [dbo].[pro_stock_sku_export_excel]
@sql VARCHAR(MAX)='',
@order VARCHAR(MAX)='',
@where VARCHAR(MAX)=''
AS
SET @sql=@sql+' order by '+@order;

DECLARE @n_sql NVARCHAR(MAX)='';
SET @n_sql=CONVERT(NVARCHAR(MAX),@sql);




--得到最大的规格明细数量
DECLARE @max_s_goodsruledetail_count INT=0;
SELECT TOP 1 @max_s_goodsruledetail_count=fd.[count] FROM (
SELECT fd.gs_id,count(1) as count FROM s_goodsrule fd 
INNER JOIN s_goodsruledetail fd2 ON fd.gs_id=fd2.gs_id
WHERE fd.gs_status=1 
GROUP BY fd.gs_id
) AS fd ORDER BY fd.[count] desc



exec sp_executesql @n_sql


go

