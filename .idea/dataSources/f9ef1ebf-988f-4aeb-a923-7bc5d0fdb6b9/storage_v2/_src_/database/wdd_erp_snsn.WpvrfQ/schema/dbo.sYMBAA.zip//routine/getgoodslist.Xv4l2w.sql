CREATE function [dbo].[getgoodslist](@no varchar(50),@i int)
returns varchar(300)
as
begin
	declare @rest varchar(300),@gsname varchar(300)
	select top 1 @gsname=gs_name from b_goodsruleset where gss_no=@no--,gs_salesprice,gs_marketprice,gs_costprice,gs_weight
	if @i=0 begin
		set @rest=@gsname
	end
	return @rest
end
go

