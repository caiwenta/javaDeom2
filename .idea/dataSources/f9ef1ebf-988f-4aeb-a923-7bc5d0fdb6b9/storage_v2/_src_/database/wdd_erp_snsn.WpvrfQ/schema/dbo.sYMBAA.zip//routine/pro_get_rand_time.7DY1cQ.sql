


CREATE Proc [dbo].[pro_get_rand_time]
@t1 DATETIME,
@t2out DATETIME OUT
AS
DECLARE @t2 DATETIME;
WHILE 1=1
BEGIN
 SET @t2=GETDATE();
 IF @t1!=@t2
 BEGIN
  SET @t2out=@t2;
  RETURN; 
 END
END
go

