CREATE PROCEDURE [dbo].[pro_restorag_no_ruleset_puruchse]
	@gi_id INT=0,
	@cp_id INT=0,
	@ci_id int=0
AS

	DECLARE @ghj DECIMAL(9, 2) = 0;
	DECLARE @lsj DECIMAL(9, 2) = 0;
	DECLARE @ghj_type INT = 0
	DECLARE @discount  DECIMAL(9, 2) = 1

	  SELECT * INTO #p FROM   b_goodsinfo  AS bg WHERE  bg.gi_id= @gi_id;

	if @ci_id>0
	 begin
			
			if EXISTS(SELECT 1 FROM b_supplierinfo bs WHERE si_id=@ci_id and si_company>0)
		 begin

		 SELECT @ghj_type = cp_bhprice, @discount=cp_bhdiscount FROM   companyinfo WHERE  cp_id = @cp_id AND cp_bhprice > 0

		 SELECT @ghj = gd_price FROM   b_goods_discount WHERE  gd_gi_id = @gi_id AND gd_class = 2 AND gd_type = @ghj_type

	     SELECT @lsj = bg.gi_importprices FROM   b_goodsinfo bg WHERE  bg.gi_id = @gi_id

	     IF @ghj > 0.00
		    BEGIN
		    	
		        set @ghj=@ghj*@discount

		        UPDATE #p
		        SET    gi_purchase = @ghj
		            , gi_importprices= @ghj
		  
		        UPDATE #p
		        SET    gi_purchase_discount = (
		                   CASE 
		                        WHEN gi_retailprice = 0.00 THEN 0.00
		                        ELSE gi_purchase / gi_retailprice
		                   END
		        )
		        
		   END
		      ELSE
				  BEGIN
				   UPDATE #p SET    gi_purchase = @lsj
				  END

         select * from #p

		END

	 end
	 else
	 begin

		 SELECT @ghj_type = cp_bhprice, @discount=cp_bhdiscount FROM   companyinfo WHERE  cp_id = @cp_id AND cp_bhprice > 0

		 SELECT @ghj = gd_price FROM   b_goods_discount WHERE  gd_gi_id = @gi_id AND gd_class = 2 AND gd_type = @ghj_type

	     SELECT @lsj = bg.gi_importprices FROM   b_goodsinfo bg WHERE  bg.gi_id = @gi_id

	     IF @ghj > 0.00
		    BEGIN
		    	
		        set @ghj=@ghj*@discount

		        UPDATE #p
		        SET    gi_purchase = @ghj
		            , gi_importprices= @ghj
		  
		        UPDATE #p
		        SET    gi_purchase_discount = (
		                   CASE 
		                        WHEN gi_retailprice = 0.00 THEN 0.00
		                        ELSE gi_purchase / gi_retailprice
		                   END
		        )
		        
		   END
		      ELSE
				  BEGIN
				   UPDATE #p SET    gi_purchase = @lsj
			 END
	 end
	  
	  
	  select * from #p
go

