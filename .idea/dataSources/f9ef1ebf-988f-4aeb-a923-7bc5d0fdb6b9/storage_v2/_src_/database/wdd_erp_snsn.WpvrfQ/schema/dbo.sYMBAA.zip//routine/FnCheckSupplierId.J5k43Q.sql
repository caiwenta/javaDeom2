CREATE FUNCTION [dbo].[FnCheckSupplierId] ( @si_id INT, @erp_id INT ,@cp_id INT,@status INT)
RETURNS INT
AS
BEGIN
	--用途：验证供应商与erpid是否匹配
    DECLARE @re INT;
	
    IF ( ISNULL(@si_id, 0) = 0 or ISNULL(@erp_id,0)=0 or @status=0)
        SET @re = 1;
    ELSE
        IF EXISTS ( SELECT  1
                    FROM    dbo.b_supplierinfo
                    WHERE   si_id = @si_id
                            AND si_erp_id = @erp_id AND si_cp_id=@cp_id)
            SET @re = 1;
        ELSE
            SET @re = 0;
        
    RETURN @re;
END
go

