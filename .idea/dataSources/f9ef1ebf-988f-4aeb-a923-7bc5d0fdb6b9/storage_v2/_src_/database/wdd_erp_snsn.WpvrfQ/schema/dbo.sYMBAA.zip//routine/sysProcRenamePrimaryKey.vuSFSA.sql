
CREATE PROCEDURE [dbo].[sysProcRenamePrimaryKey]
-- =============================================
-- Author:		<重命名Sql Server主键约束名的方法>
-- Create date: <2015-05-03>
-- Description:	<数据库原先是采用PowerDesigner设计的，Sql Server主键约束的命名非常难看，主键约束命名规则不一致>
-- =============================================
AS
    BEGIN
        DECLARE pkcur CURSOR
        FOR
            SELECT  OBJECT_NAME(col.object_id) AS PKConstraintName ,
                    OBJECT_NAME(col.parent_object_id) AS PKTable
            FROM    SYS.objects col
            WHERE   type_desc = 'PRIMARY_KEY_CONSTRAINT'

        OPEN pkcur  
        DECLARE @constraintName NVARCHAR(128)  
        DECLARE @pkTable NVARCHAR(64) 
        DECLARE @newConstraintName NVARCHAR(128)  
 
        FETCH NEXT FROM pkcur INTO @constraintName, @pkTable
        
        WHILE @@FETCH_STATUS = 0
            BEGIN  
                SET @newConstraintName = 'PK_ON_' + @pkTable 
                IF @constraintName != @newConstraintName
                    BEGIN
                        EXEC sp_rename @constraintName, @newConstraintName,
                            'Object'  
                    END
                FETCH NEXT FROM pkcur INTO @constraintName, @pkTable
            END  
            
        CLOSE pkcur  
        DEALLOCATE pkcur 
    END

go

