CREATE  PROCEDURE [dbo].[pro_payoutsum]
@sa_sh_id INT,
@sa_date DATETIME= '2014-7-22'
AS
BEGIN
BEGIN TRAN
merge INTO pos_payoutsum as pp 
USING (

SELECT 
payout.*,
(payout.sal_money+payout.income)-(ABS(payout.sal_change_money)+ABS(payout.payout)+ABS(payout.bspayout)) AS balance
FROM
(
SELECT 
sa_sh_id,
sa_date,
sa_erp_id,
SUM(sal_money) AS sal_money,
SUM(sal_change_money) AS sal_change_money,
SUM(payout) AS payout,
SUM(income) AS income,
SUM(bspayout) AS bspayout
FROM
(

---销售	
SELECT 
ps.sa_sh_id,
ps.sa_erp_id,
CONVERT(VARCHAR(50), ps.sa_date, 23) AS sa_date,
SUM(case when psl.sal_is_gift=0 and psl.sal_is_change=0 and psl.sal_is_in=0 and psl.sal_is_return=0
then (psl.sal_num*psl.sal_real_price)-psl.sal_deduct_money else 0 end)as sal_money,
SUM(case when psl.sal_is_return=1 or psl.sal_is_change=1 then -((ABS(psl.sal_num)*psl.sal_real_price)-sal_deduct_money)else 0 END)as sal_change_money,
0 as payout,
0 AS income,
0 AS bspayout
FROM pos_sale ps WITH (NOLOCK) 
INNER JOIN
pos_salelist psl  WITH (NOLOCK) 
ON psl.sal_sa_id=ps.sa_id AND psl.sal_status<>0 AND ps.sa_status<>0
AND (not EXISTS(SELECT * FROM pos_sale_net psn WHERE psn.sa_net_sa_id=ps.sa_id))
WHERE ps.sa_sh_id=@sa_sh_id AND ps.sa_date=@sa_date
GROUP BY ps.sa_sh_id,ps.sa_date,ps.sa_erp_id


UNION ALL

--网络订单
SELECT 
ps.sa_sh_id,
ps.sa_erp_id,
CONVERT(VARCHAR(50), ps.sa_date, 23) AS sa_date,
SUM(case when psl.sal_is_gift=0 and psl.sal_is_change=0 and psl.sal_is_in=0 and psl.sal_is_return=0
then (psl.sal_num*psl.sal_real_price)-psl.sal_deduct_money else 0 end)as sal_money,
SUM(case when psl.sal_is_return=1 or psl.sal_is_change=1 then -((ABS(psl.sal_num)*psl.sal_real_price)-sal_deduct_money)else 0 END)as sal_change_money,
0 as payout,
0 AS income,
0 AS bspayout
FROM pos_sale ps WITH (NOLOCK) 
INNER JOIN
pos_salelist psl  WITH (NOLOCK) 
ON psl.sal_sa_id=ps.sa_id AND psl.sal_status<>0 AND ps.sa_status<>0
AND (EXISTS(SELECT * FROM pos_sale_net psn WHERE psn.sa_net_sa_id=ps.sa_id)) AND ps.sa_paytype='现金支付'
WHERE ps.sa_sh_id=@sa_sh_id AND ps.sa_date=@sa_date
GROUP BY ps.sa_sh_id,ps.sa_date,ps.sa_erp_id

UNION ALL	

--刷卡支付 消费代金券 积分抵扣额
SELECT
ps.sa_sh_id,
ps.sa_erp_id,
CONVERT(VARCHAR(50), ps.sa_date, 23) AS sa_date, 
-ps.sa_card_money-ps.sa_in_money-ps.sa_sa_vo as sal_money,
0 as sal_change_money,
0 as payout,
0 AS income,
0 AS bspayout
FROM pos_sale ps
WHERE (ps.sa_card_money<>0 OR ps.sa_in_money<>0 OR sa_sa_vo<>0)  AND ps.sa_status<>0
AND ps.sa_sh_id=@sa_sh_id AND ps.sa_date=@sa_date

UNION ALL		

--钱箱
SELECT 
psp.p_sh_id,
psp.po_erp_id,
psp.add_time,
0 AS sal_money,
0 AS sal_change_money,
isnull(SUM(CASE WHEN p_type=0 THEN p_money ELSE 0 END),0) AS payout,
isnull(SUM (CASE WHEN p_type=1 THEN p_money ELSE 0	END),0)  AS income,
isnull(SUM (CASE WHEN p_type=2 THEN p_money ELSE 0 END),0)  AS bspayout
FROM
(
SELECT 
p_sh_id,po_erp_id,p_type,convert(varchar(50),p_add_time,23) AS add_time,
CASE WHEN pp.p_counttype=1 THEN  pp.p_money ELSE - pp.p_money END AS p_money
FROM
pos_payout pp  WITH (NOLOCK)  WHERE pp.p_status<>0
and pp.p_sh_id=@sa_sh_id AND convert(varchar(50),p_add_time,23)=@sa_date
) AS psp
GROUP BY psp.p_sh_id, psp.add_time,psp.po_erp_id


) AS paut
GROUP BY sa_sh_id,sa_date,paut.sa_erp_id
) AS payout

) as vp
ON vp.sa_sh_id=pp.sa_sh_id AND vp.sa_date=pp.sa_date 
when matched THEN
UPDATE SET 
       pp.sal_money = vp.sal_money
      ,pp.sal_change_money = vp.sal_change_money
      ,pp.payout =  vp.payout
      ,pp.income = vp.income
      ,pp.bspayout =vp.bspayout
      ,pp.balance = vp.balance
      ,pp.opttime = GETDATE()
      ,pp.num +=1 
when not matched then
      INSERT(sa_sh_id ,sa_date ,sa_erp_id ,sal_money ,sal_change_money ,payout ,income ,bspayout ,balance ,opttime ,num )
      VALUES
           (vp.sa_sh_id
           ,vp.sa_date
           ,vp.sa_erp_id
           ,vp.sal_money
           ,vp.sal_change_money
           ,vp.payout
           ,vp.income
           ,vp.bspayout
           ,vp.balance
           ,GETDATE() ,1)
WHEN NOT MATCHED BY SOURCE AND pp.sa_sh_id=@sa_sh_id THEN 
DELETE;
END


	IF @@ERROR <> 0
	BEGIN
	    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    IF @@TRANCOUNT > 0 COMMIT TRAN
END


go

