CREATE VIEW [dbo].[v_instruction_goods_progress]
	AS 
--此视图用于报表【商品发货进度查询】
SELECT  
'' AS  specname,--暂时为空  
(CASE WHEN rulenum.gd_row_number is null THEN '无' ELSE 'spec'+convert(VARCHAR,rulenum.gd_row_number) END) AS spec2,
rulenum.gd_row_number,
TList.*
FROM  
(
	
SELECT 
isnull(grl.gss_no,'') AS gss_no,--规格编码,
isnull(grl.colorname,'无') AS color,
isnull(grl.specname,'无') AS spec,
isnull(grl.specid,0) AS size,
isnull(grl.specngroupid,0) AS specid,
T.*
	
FROM
(	
	
SELECT CONVERT(VARCHAR,in_date,23)in_date,  --单据时间
	   in_vo,  --指令凭证号
	   in_id,
	   in_level, --指令级别
	   (CASE WHEN io_level=1 THEN '一级' WHEN io_level=2 THEN '二级' END)io_level, --对象级别
	   in_type,(CASE WHEN in_type=0 THEN '配货单' WHEN in_type=1 THEN '调拨单' END)in_type_txt,  --单据类型
	   in_addman,(SELECT si_name FROM b_stafftinfo WHERE si_id=in_addman)in_addman_txt,
	   io_send_vo,
	   io_sender,(CASE WHEN io_sendertype=0 THEN (SELECT sei_name FROM b_storageinfo WHERE sei_id=io_sender)
					   WHEN io_sendertype=1 THEN (SELECT ps.sei_name FROM pos_storageinfo AS ps WHERE ps.sei_id=io_sender) END)io_sender_txt,
	   io_sys_senderdate,io_senderdate,
	   io_logistics,io_logistics_no,
	   io_status,(CASE WHEN io_status=0 THEN '' WHEN io_status=1 THEN '异常' else '正常' END)io_status_txt,
	   io_upstatus,(CASE WHEN io_upstatus=0 THEN '未发货' WHEN io_upstatus=1 THEN '已发货' END)io_upstatus_txt,
	   io_receiver,(CASE WHEN in_level=1 THEN (CASE WHEN io_receivertype=0 THEN (SELECT cp_name FROM companyinfo WHERE cp_id=io_receiver)
													WHEN io_receivertype=1 THEN (SELECT sh_name FROM pos_shop WHERE sh_id=io_receiver) END)
						 WHEN in_level=2 THEN (CASE WHEN io_level=1 THEN (SELECT sei_name FROM b_storageinfo WHERE sei_id=io_receiver)
													WHEN io_level=2 THEN 
                                    							 (CASE WHEN io_receivertype=0 THEN (SELECT cp_name FROM companyinfo WHERE cp_id=io_receiver)
																	   WHEN io_receivertype=1 THEN (SELECT sh_name FROM pos_shop WHERE sh_id=io_receiver) END)END)END)io_receiver_txt,
	   io_sys_receicedate,
	   io_downstatus,(CASE WHEN io_downstatus=0 THEN '未收货' WHEN io_downstatus=1 THEN '已收货' END)io_downstatus_txt,
	   inl_gi_id gi_id,
	   inl_sku_id,
	   inl_num,
	   gi_code,
	   gi_name,
	   gi_barcode,
	   in_erp_id,
	   (SELECT MAX(sal_add_time) 
	    FROM pos_sale 
	    LEFT JOIN  pos_saleList ON sa_id=sal_sa_id 
	    WHERE sa_erp_id=in_erp_id AND 
	          sal_gi_id=gi_id AND 
	          sal_sku_id=inl_sku_id AND 
	          sal_add_time>in_date)saledate --最近销售时间（指此款最近销售时间，终端店铺入库时间之后的销售时间）
FROM erp_instructionNotice WITH (NOLOCK) 
LEFT JOIN erp_instructionObject WITH (NOLOCK) ON in_id=io_in_id
LEFT JOIN erp_instructionNoticeList WITH (NOLOCK) ON in_id=inl_in_id
INNER JOIN b_goodsinfo WITH (NOLOCK) ON inl_gi_id=gi_id
WHERE in_status>0 AND inl_status>0

) AS T
left join b_goodsruleset  AS grl ON  grl.gss_id=T.inl_sku_id
) AS TList
left join s_goodsruledetail rulenum ON gd_id=TList.size
go

