CREATE VIEW [dbo].[vi_pos_sale_model] AS 
select ps.*,pmi.me_card,pmi.me_name,pmi.me_id,
(CASE WHEN ps.sa_paytype='储值卡支付' then pmi.me_balance+sa_card_money else pmi.me_balance end) as me_balance,
pg.gr_rank,pg.gr_discount,pg.gr_id
from pos_sale as ps left join pos_memberInfo as pmi
on ps.sa_me_id=pmi.me_id left join pos_grade as pg
on pmi.me_gr_id=pg.gr_id
go

