

CREATE PROCEDURE [dbo].[pro_pos_supplierinfo_op]
	@si_id INT,
	@si_ctname VARCHAR(50),
	@si_ctid INT,
	@si_name VARCHAR(50),
	@si_code VARCHAR(50),
	@si_linkman VARCHAR(50),
	@si_address VARCHAR(250),
	@si_bank VARCHAR(50),
	@si_bankaccount VARCHAR(50),
	@si_tfn VARCHAR(50),
	@si_fax VARCHAR(50),
	@si_phone VARCHAR(50),
	@si_mobile VARCHAR(50),
	@si_status INT,
	@si_remark VARCHAR(250),
	@si_postcode VARCHAR(50),
	@si_email VARCHAR(50),
	@si_referee VARCHAR(50),
	@si_mainproject VARCHAR(50),
	@si_site VARCHAR(50),
	@si_creditline VARCHAR(50),
	@si_province VARCHAR(50),
	@si_city VARCHAR(50),
	@si_county VARCHAR(50),
	@si_qcje DECIMAL(15, 2),
	@si_flid INT,
	@si_isdel INT,
	@si_add_time DATETIME,
	@si_add_man INT,
	@si_update_man INT,
	@si_update_time DATETIME,
	 --操作类型(1:添加 2:修改 3:删除)
	@op_type INT = 0,
	@outResult INT OUTPUT,
	@si_sh_id INT = 0,
	@si_erp_id INT = 0
AS
BEGIN
	IF @op_type = 1
	BEGIN
	    INSERT INTO [pos_supplierinfo]
	      (
	        [si_ctname],
	        [si_ctid],
	        [si_name],
	        [si_code],
	        [si_linkman],
	        [si_address],
	        [si_bank],
	        [si_bankaccount],
	        [si_tfn],
	        [si_fax],
	        [si_phone],
	        [si_mobile],
	        [si_status],
	        [si_remark],
	        [si_postcode],
	        [si_email],
	        [si_referee],
	        [si_mainproject],
	        [si_site],
	        [si_creditline],
	        [si_province],
	        [si_city],
	        [si_county],
	        [si_qcje],
	        [si_flid],
	        [si_isdel],
	        [si_add_time],
	        [si_add_man],
	        [si_sh_id],si_erp_id
	      )
	    VALUES
	      (
	        @si_ctname,
	        @si_ctid,
	        @si_name,
	        @si_code,
	        @si_linkman,
	        @si_address,
	        @si_bank,
	        @si_bankaccount,
	        @si_tfn,
	        @si_fax,
	        @si_phone,
	        @si_mobile,
	        @si_status,
	        @si_remark,
	        @si_postcode,
	        @si_email,
	        @si_referee,
	        @si_mainproject,
	        @si_site,
	        @si_creditline,
	        @si_province,
	        @si_city,
	        @si_county,
	        @si_qcje,
	        @si_flid,
	        @si_isdel,
	        @si_add_time,
	        @si_add_man,
	        @si_sh_id,@si_erp_id
	      )
	    SET @si_id = SCOPE_IDENTITY()
	END
	
	IF @op_type = 2
	   AND @si_id > 0
	BEGIN
	    UPDATE [pos_supplierinfo]
	    SET    [si_ctname]          = @si_ctname,
	           [si_ctid]            = @si_ctid,
	           [si_name]            = @si_name,
	           [si_code]            = @si_code,
	           [si_linkman]         = @si_linkman,
	           [si_address]         = @si_address,
	           [si_bank]            = @si_bank,
	           [si_bankaccount]     = @si_bankaccount,
	           [si_tfn]             = @si_tfn,
	           [si_fax]             = @si_fax,
	           [si_phone]           = @si_phone,
	           [si_mobile]          = @si_mobile,
	           [si_status]          = @si_status,
	           [si_remark]          = @si_remark,
	           [si_postcode]        = @si_postcode,
	           [si_email]           = @si_email,
	           [si_referee]         = @si_referee,
	           [si_mainproject]     = @si_mainproject,
	           [si_site]            = @si_site,
	           [si_creditline]      = @si_creditline,
	           [si_province]        = @si_province,
	           [si_city]            = @si_city,
	           [si_county]          = @si_county,
	           [si_qcje]            = @si_qcje,
	           [si_flid]            = @si_flid,
	           [si_isdel]           = @si_isdel,
	           [si_update_man]      = @si_update_man,
	           [si_update_time]     = @si_update_time
	    WHERE  si_id                = @si_id
	    AND si_sh_id=@si_sh_id
	END
	
	IF @op_type = 3
	   AND @si_id > 0
	BEGIN
	    UPDATE [pos_supplierinfo]
	    SET    [si_isdel]     = @si_isdel
	    WHERE  si_id          = @si_id
	    AND si_sh_id=@si_sh_id
	END
	
	IF @@error <> 0
	BEGIN
	    SET @outResult = 0;
	END
	ELSE
	BEGIN
	    SET @outResult = @si_id;
	END
	RETURN @outResult;
END
go

