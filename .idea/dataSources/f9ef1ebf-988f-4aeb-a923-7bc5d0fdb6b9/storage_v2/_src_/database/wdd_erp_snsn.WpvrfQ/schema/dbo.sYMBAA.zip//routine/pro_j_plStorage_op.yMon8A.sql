


CREATE PROC [dbo].[pro_j_plStorage_op]
@ppl_box_num INT = 0,
@ppl_pm VARCHAR(500) = '',
--主键  
@pl_id INT = 0,  
@pl_erp_id INT = 0, 
@ppl_erp_id INT = 0,   
--仓库主键  
@pl_st_id INT = 0,  
--盈亏数量  
@pl_num INT = 0,  
--单据号  
@pl_no VARCHAR(50) = '',  
--单据日期  
@pl_date DATETIME = '2014-10-31',  
--添加人主键  
@pl_add_man INT = 0,  
--添加时间  
@pl_add_time DATETIME = '2014-10-31',  
--修改人主键  
@pl_update_man INT = 0,  
--修改时间  
@pl_update_time DATETIME = '2014-10-31',  
--审核人主键  
@pl_audit_man INT = 0,  
--审核时间  
@pl_audit_time DATETIME = '2014-10-31',  
--制单人主键  
@pl_order_man INT = 0,  
--备注  
@pl_remark VARCHAR(50) = '',  
--主键  
@ppl_id INT = 0,  
--盈亏主键  
@ppl_pl_id INT = 0,  
--商品主键  
@ppl_gi_id INT = 0,  
--商品sku主键  
@ppl_sku_id INT = 0,  
--日期库存数量  
@ppl_stock_num INT = 0,  
--盈亏数量  
@ppl_num INT = 0,  
--备注  
@ppl_remark VARCHAR(50) = '',  
--零售价
@ppl_retail_price DECIMAL(18, 2) = 0,
--进货价
@ppl_stock_price DECIMAL(18, 2) = 0,
--折扣
@ppl_discount DECIMAL(18, 2) = 0,
--金额
@ppl_money DECIMAL(18, 2) = 0,
--添加时间  
@ppl_add_time DATETIME = '2014-10-31',  
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细', 
--产生了负库存是否提示
@negative_inventory INT = 0, 
--结果  
@result VARCHAR(100) = '' OUT,
--公司主键
@pl_cp_id INT = 0,
--部门主键
@pl_di_id INT = 0,
--保存字符串
@savestr VARCHAR(MAX) = '',
@goodscode VARCHAR(MAX) = '',
@pl_locationid int=0,   --仓位id
@ppl_pddate  VARCHAR(80) = null, --生产日期
@ppl_expirationdate VARCHAR(80) = null,--过期时间
@ppl_shelflife int=0,                   --保质期
@orderguid VARCHAR(500)='' --唯一guid
AS
BEGIN
	DECLARE @old_sei_id INT = 0;
	DECLARE @new_sei_id INT = 0;
	SET @new_sei_id = @pl_st_id;
	
	
	--是否添加单据
	DECLARE @isInsert INT = 0;
	--是否需要更新单据
	DECLARE @need_update INT = 0;
	--旧的单据日期
	DECLARE @old_order_date DATETIME;
	--单据日期是否更改
	DECLARE @old_order_date_is_changed INT = 0;
	--凭证号前缀
	DECLARE @myprevTxt VARCHAR(50) = 'YK';
	BEGIN TRAN
	IF @op_type = '添加修改单据,明细'
	BEGIN
	    IF @pl_id = 0
	    BEGIN
	        --添加单据
	        INSERT INTO j_plStorage
	          (
	            pl_st_id,
	            pl_num,
	            pl_vo,
	            pl_no,
	            pl_date,
	            pl_add_man,
	            pl_add_time,
	            pl_update_man,
	            pl_update_time,
	            pl_order_man,
	            pl_status,
	            pl_remark,
	            pl_cp_id,
	            pl_di_id,pl_erp_id
	          )
	        VALUES
	          (
	            @pl_st_id,
	            @pl_num,
	            NEWID(),
	            @pl_no,
	            @pl_date,
	            @pl_add_man,
	            @pl_add_time,
	            @pl_update_man,
	            @pl_update_time,
	            @pl_order_man,
	            1,
	            @pl_remark,
	            @pl_cp_id,
	            @pl_di_id,@pl_erp_id
	          );
	        SET @pl_id = SCOPE_IDENTITY();
	        
	        SET @ppl_pl_id = @pl_id;
	        SET @isInsert = 1;
	    END
	    ELSE
	    BEGIN
	        SET @need_update = 1;
	    END
	    IF EXISTS(
	           SELECT *
	           FROM   j_plStorageList AS jt
	           WHERE  jt.ppl_pl_id = @pl_id
	                  AND jt.ppl_status = 1
	                  AND jt.ppl_add_time = @ppl_add_time
	                  AND jt.ppl_gi_id != @ppl_gi_id
	       )
	    BEGIN
	        UPDATE j_plStorageList
	        SET    ppl_status = 0
	        WHERE  ppl_pl_id = @pl_id
	               AND ppl_add_time = @ppl_add_time
	               AND ppl_status = 1
	               AND ppl_gi_id != @ppl_gi_id;
	        SET @ppl_id = 0;
	    END
	    
	    
	    
	    


	    SELECT @ppl_stock_num = ISNULL(
	               SUM(
	                   CASE 
	                        WHEN js.sl_counttype = 1 THEN js.sl_number
	                        ELSE -js.sl_number
	                   END
	               ),
	               0
	           )
	    FROM   j_stocklog AS js
	    WHERE  js.sl_seiid = @pl_st_id
	           AND js.sl_location = @pl_locationid
	           AND (
	                   (
	                       --CONVERT(VARCHAR(50), js.sl_addtime, 23) <= @pl_date AND 
	                       CONVERT(VARCHAR(50), js.sl_order_date, 23) <= @pl_date
	                   )
	                   OR js.sl_type = 3
	               )
	           AND js.sl_status != 0
	           AND js.sl_giid = @ppl_gi_id
	    GROUP BY
	           js.sl_giid
	    
	    
	    if @orderguid=''
		begin
	    --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
	    DECLARE @savestr_item VARCHAR(MAX) = '';
	    --起始数值,每次循环后递增
	    DECLARE @start_int INT = 1;
	    --终止数值
	    DECLARE @end_int INT = 1;
	    IF @savestr != '' 
	       --AND 1=2
	    BEGIN
	        --得到明细数量
	        --即要循环的次数
	        SELECT @end_int = (LEN(@savestr) -LEN(REPLACE(@savestr, '|', '')))
	    END
	    
	    WHILE @start_int <= @end_int
	    BEGIN
	        --动态赋值
	        IF @savestr != ''
	        BEGIN
	            SET @savestr_item = dbo.Get_StrArrayStrOfIndex(@savestr, '|', @start_int);
	            IF (RTRIM(LTRIM(@savestr_item)) = '')
	            BEGIN
	                BREAK;
	            END
	            ELSE
	            BEGIN
	                SET @ppl_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
	                
	                SET @ppl_gi_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
	                
	                SET @ppl_sku_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));
	                
	                SET @ppl_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
	                
	                SET @ppl_retail_price = CONVERT(
	                        DECIMAL(10, 2),
	                        dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5)
	                    );
	                
	                SET @ppl_stock_price = CONVERT(
	                        DECIMAL(10, 2),
	                        dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6)
	                    );
	                
	                SET @ppl_discount = CONVERT(
	                        DECIMAL(10, 2),
	                        dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7)
	                    );
	                
	                
	                SET @ppl_box_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 8));
	                
	                SET @ppl_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9);
	            END
	        END
	        
	        IF @ppl_id = 0
	        BEGIN
	            INSERT INTO j_plStorageList
	              (
	                ppl_pl_id,
	                ppl_gi_id,
	                ppl_sku_id,
	                ppl_stock_num,
	                ppl_num,
	                ppl_remark,
	                ppl_status,
	                ppl_add_time,
	                ppl_retail_price,
	                ppl_discount,
	                ppl_stock_price,
	                ppl_money,
	                ppl_box_num,
	                ppl_pm,ppl_erp_id,
					ppl_pddate,ppl_shelflife,ppl_expirationdate,
					ppl_locationid
	              )
	            VALUES
	              (
	                @ppl_pl_id,
	                @ppl_gi_id,
	                @ppl_sku_id,
	                @ppl_stock_num,
	                @ppl_num,
	                @ppl_remark,
	                1,
	                @ppl_add_time,
	                @ppl_retail_price,
	                @ppl_discount,
	                @ppl_stock_price,
	                @ppl_num * @ppl_stock_price,
	                @ppl_box_num,
	                @ppl_pm,@ppl_erp_id,
					@ppl_pddate,@ppl_shelflife,@ppl_expirationdate,
					@pl_locationid
	              );
	            SET @ppl_id = SCOPE_IDENTITY();
	        END
	        ELSE
	        BEGIN
	            UPDATE j_plStorageList
	            SET    ppl_pl_id = @ppl_pl_id,
	                   ppl_gi_id = @ppl_gi_id,
	                   ppl_sku_id = @ppl_sku_id,
	                   ppl_stock_num = @ppl_stock_num,
	                   ppl_num = @ppl_num,
	                   ppl_remark = @ppl_remark,
	                   ppl_discount = @ppl_discount,
	                   ppl_retail_price = @ppl_retail_price,
	                   ppl_stock_price = ppl_stock_price,
	                   ppl_money = @ppl_num * @ppl_stock_price,
	                   ppl_box_num = @ppl_box_num,
	                   ppl_pm = @ppl_pm,
					   ppl_pddate=@ppl_pddate,ppl_shelflife=@ppl_shelflife,ppl_expirationdate=@ppl_expirationdate,ppl_locationid=@pl_locationid
	            WHERE  ppl_id = @ppl_id;
	        END
	        
	        SET @start_int = @start_int + 1;
	    END
		END
		ELSE
		BEGIN

			MERGE INTO j_plStorageList AS ta
					USING
					(
				  		SELECT  @ppl_pl_id as el_eoid, gi_id, sku_id,pm,gift,erp_id,
                        number,
						discount,--折扣
						retailprice,--零售价
                        purchase,--进货价
						orderstatus,
						box_num,slt_id
						FROM  erp_goodslisttemp WHERE orderguid = @orderguid 
					  ) as so on ta.ppl_gi_id=so.gi_id AND  ta.ppl_sku_id=so.sku_id and  ta.ppl_pl_id=so.el_eoid and ta.ppl_status=1
					  WHEN MATCHED THEN  UPDATE
                           SET  
						   ta.ppl_num += so.number,
						   ta.ppl_money=((ta.ppl_num+so.number)*so.purchase)
					  WHEN NOT MATCHED THEN
							INSERT 
							(ppl_pl_id , ppl_gi_id , ppl_sku_id ,ppl_pm ,ppl_erp_id ,
							ppl_num , 
							ppl_discount , --折扣
							ppl_retail_price , --零售价
							ppl_stock_price, --进货价
							ppl_money,--进货价金额
							ppl_status ,
							ppl_box_num,
							ppl_add_time,
							ppl_locationid,
							ppl_stock_num
							)
							VALUES
							( 
							 so.el_eoid, so.gi_id, so.sku_id,so.pm,so.erp_id,
							 so.number,
							 so.discount,--折扣
							 so.retailprice,--销售价
							 so.purchase,--进货价
							 so.number* so.purchase,--进货价金额
							 so.orderstatus,
							 so.box_num,
							 (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
							 SELECT GETDATE() as nows,
                             (SELECT TOP 1 ppl_add_time FROM j_plStorageList WHERE ppl_gi_id=so.gi_id AND el_eoid=so.el_eoid) AS addtime) AS TT),
							 so.slt_id,
							(select [dbo].[FnErpStocklog](@pl_date,@pl_st_id,so.gi_id,so.sku_id)as stocknum)--
							);

			EXEC pro_update_unique_time @id=@pl_id,@type='盈亏';

		END

		exec dbo.pro_setPmNumberSum @orderid=@pl_id,@erp_id=@pl_erp_id ,@stockType=6;
	END
	
	IF @op_type = '审核单据'
	BEGIN
	    --审核单据
	    UPDATE j_plStorage
	    SET    pl_status = 2,
	           pl_audit_man = @pl_update_man,
	           pl_audit_time = GETDATE()
	    WHERE  pl_id = @pl_id;
	END
	
	IF @op_type = '取消审核单据'
	BEGIN
	    --取消审核单据
	    UPDATE j_plStorage
	    SET    pl_status = 1
	    WHERE  pl_id = @pl_id;
	END
	
	IF @op_type = '删除单据'
	BEGIN
	    --删除单据
	    UPDATE j_plStorage
	    SET    pl_status = 0
	    WHERE  pl_id = @pl_id;
	END
	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE j_plStorageList
	    SET    ppl_status = 0
	    WHERE  ppl_id = @ppl_id;
	END
	
	IF @op_type = '批量删除明细'
	BEGIN
	    UPDATE j_plStorageList
	    SET    ppl_status = 0
	    WHERE  ppl_pl_id = @ppl_pl_id
	           AND ppl_add_time = @ppl_add_time
	           AND ppl_gi_id = @ppl_gi_id;
	    
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   j_plStorageList AS jt
	           WHERE  jt.ppl_pl_id = @ppl_pl_id
	                  AND jt.ppl_status = 1
	       )
	    BEGIN
	        UPDATE j_plStorage
	        SET    pl_status = 0
	        WHERE  pl_id = @ppl_pl_id;
	    END
	END
	
	IF @op_type = '添加修改单据,明细'
	   OR @need_update = 1
	   OR @op_type = '修改单据'
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.pl_date
	    FROM   j_plStorage AS jt
	    WHERE  jt.pl_id = @pl_id;
	    IF @old_order_date != @pl_date
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	    --SELECT @old_sei_id = fd.pl_st_id
	    --FROM   j_plStorage fd
	    --WHERE  fd.pl_st_id = @pl_id;
	    
	    UPDATE j_plStorage
	    SET    pl_st_id = @pl_st_id,
	           pl_num = vj.ppl_num,
	           pl_no = @pl_no,
			   pl_totalboxnum=vj.ppl_boxnum,
	           pl_date = @pl_date,
	           pl_update_man = @pl_update_man,
	           pl_update_time = @pl_update_time,
	           pl_order_man = @pl_order_man,
	           pl_remark = @pl_remark
		from j_plStorage je,vi_j_plStorageList_sum vj
	    WHERE  pl_id = @pl_id and je.pl_id=vj.ppl_pl_id;
	END
	
	IF @isInsert = 1
	   --OR @old_order_date_is_changed = 1
	BEGIN
	    --凭证号生成
	    --更新凭证号 
	    DECLARE @tableName VARCHAR(50) = 'j_plStorage'
	    DECLARE @idField VARCHAR(50) = 'pl_id'
	    DECLARE @idValue INT = @pl_id;
	    
	    DECLARE @dateField VARCHAR(50) = 'pl_date'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @pl_date, 23)
	    
	    DECLARE @noField VARCHAR(50) = 'pl_vo'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN
	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	        @idField,
	        @idValue,
	        @dateField,
	        @dateValue,
	        @noField,
	        @prevTxt,
	        @outno OUTPUT,
	        0,
	        @pl_cp_id
	        
	        BEGIN TRY
	        	--更新
	        	UPDATE j_plStorage
	        	SET    pl_vo = @outno
					,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)

	        	WHERE  pl_id = @pl_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
	        	--发生错误,判断错误类型
	        	IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	BEGIN
	        	    --不是发生重复的错误
	        	    --赋值,结束循环
	        	    SET @while = 1;
	        	END
	        END CATCH
	    END
	END
	
	exec pro_mergebyErpStocklog @op_type=@op_type,@stockType=6,@orderid=@pl_id;

	exec dbo.pro_mergesingleSums @orderid=@pl_id ,@stockType=6;

	IF @@error <> 0
	BEGIN
		GOTO theRollback;
	END


	IF @@ERROR <> 0
	BEGIN
		theRollback:
	    SET @result = '0';
		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @pl_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细' 
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @ppl_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END
END
go

