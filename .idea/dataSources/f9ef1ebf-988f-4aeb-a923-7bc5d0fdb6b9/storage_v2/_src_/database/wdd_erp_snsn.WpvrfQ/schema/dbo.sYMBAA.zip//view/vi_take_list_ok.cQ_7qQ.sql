


CREATE VIEW [dbo].[vi_take_list_ok] AS 
SELECT *
--盈亏数量
,
tsl_logno=tsl_newno-tsl_oldno
 FROM (
select * from (
select 
		
	   jt.tsl_id,
		--盘点类型
	   jt.tsl_type,
	   --盘点仓库
       jtso.ts_st_id,
	    --盘点仓位
	   isnull(jtsl.tsl_location,0) as tsl_location,
       --盘点日期
       jtso.ts_take_date,
       --商品主键
       jtsl.tsl_gi_id,
       --规格主键
       jtsl.tsl_sku_id,
       max(jtso.ts_vo) as ts_vo,
       --日期库存数量
       MAX(jtsl.tsl_old_num)           as tsl_oldno,
	   MAX(isnull(jtsl.tsl_pm,''))     as tsl_pm,
       --盘点数量
       sum(jtsl.tsl_new_num)           as tsl_newno,
       max(jt.tsl_update_time) as tsl_add_time
from j_takeStorageLog              as jt
       left join j_takeStorage   as jtso
            on  jt.tsl_id = jtso.ts_tsl_id
       left join j_takeStorageList    as jtsl
            on  jtso.ts_id = jtsl.tsl_ts_id
            --盘点记录处于盘点完成状态
            --单据处于审核状态
            --明细处于可用状态
            --0,删除状态
where  jt.tsl_status = 2
       and jtso.ts_status = 2
       AND jtsl.tsl_status=1
group by
	   jt.tsl_id,
       jt.tsl_type,
       jtso.ts_st_id,
       jtso.ts_take_date,
       jtsl.tsl_gi_id,
       jtsl.tsl_sku_id,
	   isnull(jtsl.tsl_pm,''),
	   jtsl.tsl_location
) as fd 
--where fd.tsl_logno!=0
) AS fd
go

