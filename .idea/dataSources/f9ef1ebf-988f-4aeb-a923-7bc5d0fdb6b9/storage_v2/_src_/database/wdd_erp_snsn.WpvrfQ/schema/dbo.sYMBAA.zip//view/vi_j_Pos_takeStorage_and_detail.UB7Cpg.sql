CREATE VIEW [dbo].[vi_j_Pos_takeStorage_and_detail] AS 
SELECT jt.ts_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.pos_takeStorage              AS jt
       INNER JOIN dbo.pos_takeStorageList AS jt1
            ON  jt.ts_id = jt1.tsl_ts_id
       INNER JOIN dbo.b_goodsinfo  AS bg
            ON  jt1.tsl_gi_id = bg.gi_id
WHERE  (jt.ts_status <> 0)
       AND (jt1.tsl_status = 1)
go

