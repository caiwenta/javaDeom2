CREATE VIEW [dbo].[vi_stockList_goods_weishop] AS 
SELECT bg.*,
       bg2.gs_name,
       vi_stockList_weishop.gnum,
       bg2.gss_id,
       bg2.gss_no,
       bg2.gs_type_id,
       bg2.gs_type_id_parentid
FROM   vi_stockList_weishop
       INNER JOIN b_goodsinfo     AS bg
            ON  gid = bg.gi_id
       INNER JOIN b_goodsruleset  AS bg2
            ON  skuid = bg2.gss_id
go

