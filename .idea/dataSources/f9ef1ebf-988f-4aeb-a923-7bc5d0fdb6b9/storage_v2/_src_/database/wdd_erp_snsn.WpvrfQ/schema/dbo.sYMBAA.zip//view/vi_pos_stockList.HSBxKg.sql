
 
CREATE VIEW [dbo].[vi_pos_stockList]
AS
SELECT 
       je.in_st_id           AS SID,
       je.in_sh_id           AS shid,
       cid = 0,
       je2.inl_gi_id         AS gid,
       je2.inl_sku_id        AS skuid,
       je2.inl_num           AS gnum,
	   isnull(je2.inl_pm,'')        As pm ,
       countType = CASE WHEN je.in_type = 0 THEN 1 ELSE 0 END,
       myremark = CASE WHEN je.in_type = 0 THEN  (CASE WHEN in_source!=2  THEN  '入库' else  '调拨入库' end ) ELSE     '入库退货' END,
       addtime = je2.inl_add_time,
       orderno = je.in_vo,
       eoid = je.in_id,
       elid = je2.inl_id,
       mytype = 1,
       order_add_time = je.in_add_time,
       order_date = je.in_date,
       je.in_erp_id AS erp_id
FROM   pos_inStorage je
       INNER JOIN pos_inStorageList je2
            ON  je.in_id = je2.inl_in_id
WHERE  je.in_status > 0
       AND je2.inl_status = 1
       AND je2.inl_gi_id > 0
       AND je.in_st_id > 0
       AND je.in_sh_id>0
UNION ALL
SELECT 
--'' AS                              ord_no,
       jt.in_st_id                     AS [sid],
       jt.in_sh_id                     AS shid,
       cid = 0,
       ji.inl_gi_id                    AS gid,
       ji.inl_sku_id                   AS skuid,
       ji.inl_num                      AS gnum,
	   isnull(ji.inl_pm,'')        As pm ,
       countType = 1,
       myremark = '期初',
       ji.inl_add_time                 AS addtime,
       jt.in_vo                        AS orderno,
       jt.in_id                        AS eoid,
       ji.inl_id                       AS elid,
       mytype = 11,
       order_add_time = jt.in_add_time,
       order_date = jt.in_date,
       jt.in_erp_id AS erp_id
FROM   pos_initStorage                 AS jt
       INNER JOIN pos_initStorageList  AS ji
            ON  jt.in_id = ji.inl_in_id
WHERE  jt.in_status > 0
       AND ji.inl_status = 1
       AND ji.inl_gi_id > 0
       AND jt.in_st_id > 0
       AND jt.in_sh_id>0
UNION ALL
SELECT 
--'' AS                            ord_no,
       jms.mo_out_st_id              AS SID,
       jms.mo_sh_id                  AS shid,
       cid = 0,
       jmsl.mol_gi_id                AS gid,
       jmsl.mol_sku_id               AS skuid,
       jmsl.mol_num                  AS gnum,
	   isnull(jmsl.mol_pm,'')        As pm ,
       countType = 0,
       myremark = '移出仓库',
       addtime = jmsl.mol_add_time,
       orderno = mo_vo,
       eoid = mo_id,
       elid = mol_id,
       mytype = 2,
       order_add_time = jms.mo_add_time,
       order_date = jms.mo_date,
       mo_erp_id AS erp_id
FROM   pos_moStorage                 AS jms
       INNER JOIN pos_moStorageList  AS jmsl
            ON  jms.mo_id = jmsl.mol_mo_id
WHERE  jms.mo_status > 0
       AND jmsl.mol_status = 1 
       AND jmsl.mol_gi_id > 0
       AND jms.mo_out_st_id > 0
       AND jms.mo_sh_id>0
UNION ALL
SELECT 
--'' AS                            ord_no,
       jms.mo_in_st_id               AS SID,
       jms.mo_sh_id                  AS shid,
       cid = 0,
       jmsl.mol_gi_id                AS gid,
       jmsl.mol_sku_id               AS skuid,
       jmsl.mol_num                  AS gnum,
	   isnull(jmsl.mol_pm,'')        As pm ,
       countType = 1,
       myremark = '移入仓库',
       addtime = jmsl.mol_add_time,
       orderno = mo_vo,
       eoid = mo_id,
       elid = mol_id,
       mytype = 3,
       order_add_time = jms.mo_add_time,
       order_date = jms.mo_date,
       mo_erp_id AS erp_id
FROM   pos_moStorage                 AS jms
       INNER JOIN pos_moStorageList  AS jmsl
            ON  jms.mo_id = jmsl.mol_mo_id
WHERE  jms.mo_status > 0
       AND jmsl.mol_status = 1
       AND jmsl.mol_gi_id > 0
       AND jms.mo_in_st_id > 0
       AND jms.mo_sh_id>0
UNION ALL
SELECT 
--'' AS                            ord_no,
       jps.pl_st_id                  AS SID,
       jps.pl_sh_id                  AS shid,
       cid = 0,
       jpsl.ppl_gi_id                AS gid,
       jpsl.ppl_sku_id               AS skuid,
       ABS(jpsl.ppl_num)             AS gnum,
	   isnull(jpsl.ppl_pm,'')        As pm ,
       countType = (CASE WHEN jpsl.ppl_num >= 0 THEN 1 ELSE 0 END),
       myremark = '盈亏',
       addtime = jpsl.ppl_add_time,
       orderno = jps.pl_vo,
       eoid = jps.pl_id,
       elid = jpsl.ppl_id,
       mytype = 4,
       order_add_time = jps.pl_add_time,
       order_date = jps.pl_date,
       pl_erp_id AS erp_id
FROM   pos_plStorage                 AS jps
       INNER JOIN pos_plStorageList  AS jpsl
            ON  jps.pl_id = jpsl.ppl_pl_id
WHERE  jps.pl_status=2  
       AND jpsl.ppl_status = 1
       AND jpsl.ppl_gi_id > 0
       AND jps.pl_st_id > 0
       AND jps.pl_sh_id>0
UNION ALL
SELECT 
--jps.ord_sn,
       jps.al_st_id                  AS SID,
       jps.al_sh_id                  AS shid,
       cid = 0,
       jpsl.all_gi_id                AS gid,
       jpsl.all_sku_id               AS skuid,
       ABS(jpsl.all_num)             AS gnum,
	   isnull(jpsl.all_pm,'')        As pm ,
       countType = 0,
       myremark = '调拨出库',
       addtime = jpsl.all_add_time,
       orderno = jps.al_vo,
       eoid = jps.al_id,
       elid = jpsl.all_id,
       mytype = 5,
       order_add_time = jps.al_add_time,
       order_date = jps.al_date,
       jps.al_erp_id AS erp_id
FROM   pos_alStorage                 AS jps
       INNER JOIN pos_alStorageList  AS jpsl
            ON  jps.al_id = jpsl.all_al_id
WHERE  jps.al_status > 0
       AND jpsl.all_status = 1
       AND jpsl.all_gi_id > 0
       AND jps.al_st_id > 0
       AND jps.al_sh_id>0
UNION ALL
SELECT 
       jps.sa_st_id             AS SID,
       jps.sa_sh_id             AS shid,
       cid = 0,
       jpsl.sal_gi_id           AS gid,
       jpsl.sal_sku_id          AS skuid,
       ABS(CASE WHEN batch.sal_id IS NULL THEN 
         jpsl.sal_num 
       ELSE 
         cast(isnull(batch.applyqty,0) as int) 
       END ) AS gnum ,
	   isnull(batch.batchno,'')                  as pm,
       countType = (CASE WHEN jpsl.sal_is_return=1 OR jpsl.sal_is_change=1 THEN 1 WHEN jpsl.sal_num >= 0 THEN 0 ELSE 1 END),
       myremark =CASE WHEN jpsl.sal_is_return=1 THEN '销售退货' when jpsl.sal_is_change=1 then '销售换货' else '销售出库' end,
       addtime = jpsl.sal_add_time,
       orderno = jps.sa_vo,
       eoid = jps.sa_id,
       elid = jpsl.sal_id,
       mytype = 6,
       order_add_time = jps.sa_add_time,
       order_date = jps.sa_date,
       sa_erp_id AS erp_id
FROM   pos_sale                 AS jps
        INNER JOIN pos_saleList AS jpsl
		                ON  jps.sa_id = jpsl.sal_sa_id
		left JOIN pos_batchdistribution AS batch
		   ON batch.sal_id=jpsl.sal_id
WHERE  jps.sa_status > 0
       AND jpsl.sal_status = 1
       AND jpsl.sal_gi_id > 0
       AND jps.sa_st_id > 0
       AND jps.sa_sh_id>0
UNION ALL
SELECT 
--'' AS                ord_no,
       js.sl_seiid       AS SID,
       js.sl_shid        AS shid,
       cid = 0,
       js.sl_giid        AS gid,
       js.sl_skuid       AS skuid,
       sl_number=abs(SUM(CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE -js.sl_number END)),
	   isnull(js.sl_pm,'') as pm,
       sl_counttype=case when SUM(CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE -js.sl_number END)>0 THEN 1 ELSE 0 END,
       js.sl_remark,
       js.sl_addtime,
       js.sl_order_no,
       js.sl_eoid,
       js.sl_elid,
       mytype = 7,
       order_add_time = js.sl_order_add_time,
       order_date = js.sl_order_date,
       sl_erp_id AS erp_id
FROM   pos_stocklog_pal  AS js
WHERE  js.sl_status = 2
       AND js.sl_giid > 0
       AND js.sl_seiid > 0
       AND js.sl_shid>0
GROUP BY js.sl_seiid      ,
       js.sl_shid       ,
       js.sl_giid       ,
       js.sl_skuid      ,
       js.sl_remark,
       js.sl_addtime,
       js.sl_order_no,
       js.sl_eoid,
       js.sl_elid,
       js.sl_order_add_time,
       js.sl_order_date,
       sl_erp_id,
	   isnull(js.sl_pm,'')
UNION ALL
--SELECT 
----'' AS                ord_no,
--       vt.sl_seiid,
--       vt.sl_shid,
--       cid = 0,
--       vt.sl_giid,
--       vt.sl_skuid,
--       vt.sl_number,
--       vt.sl_counttype,
--       vt.sl_remark,
--       vt.sl_addtime,
--       vt.sl_order_no,
--       vt.sl_eoid,
--       vt.sl_elid,
--       vt.sl_type,
--       vt.sl_order_add_time,
--       vt.sl_order_date,
--       sl_erp_id
--FROM   pos_stocklog_pal  AS vt
--WHERE  vt.sl_status = 1
--       AND vt.sl_seiid > 0
--       AND vt.sl_giid > 0
--       AND vt.sl_shid>0
SELECT 
--'' AS                ord_no,
       js.sl_seiid       AS SID,
       js.sl_shid        AS shid,
       cid = 0,
       js.sl_giid        AS gid,
       js.sl_skuid       AS skuid,
       sl_number=abs(SUM(CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE -js.sl_number END)),
	   isnull(js.sl_pm,'') as pm,
       sl_counttype=case when SUM(CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE -js.sl_number END)>0 THEN 1 ELSE 0 END,
       js.sl_remark,
       js.sl_addtime,
       js.sl_order_no,
       js.sl_eoid,
       js.sl_elid,
       js.sl_type,
       order_add_time = js.sl_order_add_time,
       order_date = js.sl_order_date,
       sl_erp_id AS erp_id
FROM   pos_stocklog_pal  AS js
WHERE  js.sl_status = 1
       AND js.sl_giid > 0
       AND js.sl_seiid > 0
       AND js.sl_shid>0
GROUP BY js.sl_seiid      ,
       js.sl_shid       ,
       js.sl_giid       ,
       js.sl_skuid      ,
       js.sl_remark,
       js.sl_addtime,
       js.sl_order_no,
       js.sl_eoid,
       js.sl_elid,
       js.sl_order_add_time,
       js.sl_order_date,
       sl_erp_id,
       js.sl_type,
	   isnull(js.sl_pm,'')
go

