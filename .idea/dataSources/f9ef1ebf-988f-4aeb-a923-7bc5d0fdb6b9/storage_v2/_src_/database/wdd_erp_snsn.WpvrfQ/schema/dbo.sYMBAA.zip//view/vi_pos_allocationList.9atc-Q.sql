CREATE VIEW [dbo].[vi_pos_allocationList] AS 
SELECT pal.all_id,
       pal.all_al_id,
       pal.all_gi_id,
       pal.all_sku_id,
       pal.all_num,
       pal.all_retail_price,
       pal.all_retail_money,
       pal.all_discount,
       pal.all_stock_price,
       pal.all_money,
       bg.gi_name,
       bg.gi_addtime,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_brandsid,
       bg.gi_id,
       bg.gi_code,
       bg2.gss_id,
       bg2.gss_no,
       bg2.gs_name,
       bg2.gs_stock,
       bg2.gs_salesprice,
       bg2.gs_marketprice,
       bg2.gs_costprice,
       bu.ut_name                       AS gi_unit,
       ol.all_outed_num
FROM   dbo.vi_pos_allocationList_sum    AS pal
       INNER JOIN dbo.b_goodsinfo  AS bg
            ON  pal.all_gi_id = bg.gi_id
       INNER JOIN dbo.b_goodsruleset AS bg2
            ON  bg2.gss_id = pal.all_sku_id
       INNER JOIN dbo.b_unit       AS bu
            ON  bg.gi_unit = bu.ut_id
       LEFT OUTER JOIN (
                SELECT SUM(ol_number)     AS all_outed_num,
                       MIN(ol_source_id)  AS ol_source_id
                FROM   dbo.j_outStorageList AS ol
                GROUP BY
                       ol_eoid
            )                           AS ol
            ON  ol.ol_source_id = pal.all_id
--WHERE     (pal.all_status = 1)
go

