CREATE VIEW [dbo].[vi_j_Pos_ReStorage_and_detail] AS 
SELECT jt.re_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.pos_reStorage                 AS jt
       INNER JOIN dbo.pos_reStorageList  AS jt1
            ON  jt.re_id = jt1.rel_re_id
       INNER JOIN dbo.b_goodsinfo   AS bg
            ON  jt1.rel_gi_id = bg.gi_id
WHERE  (jt1.rel_status = 1)
       AND (jt.re_status <> 0)
go

