CREATE VIEW dbo.vi_DeskSum
AS
SELECT     Count(1) AS Count, bs = 'goods'
FROM         b_goodsinfo bg
WHERE     bg.gi_status = 1  
UNION ALL
SELECT     Count(1) AS Count, bs = 'client'
FROM         b_clientinfo bc
WHERE     bc.ci_status = 1 and ci_isdel>0
UNION ALL
SELECT     Count(1) AS Count, bs = 'supplier'
FROM         b_supplierinfo bs
WHERE     bs.si_status = 1 and si_isdel>0
go

