


CREATE VIEW [dbo].[vi_pos_funds_detail_list]
AS
SELECT     f.fu_id,fu_ci_id as ci_id, f.fu_sh_id, f.fu_vo, f.fu_date, f.fu_source_type, f.fu_source_vo,
                          (SELECT     si_name
                            FROM          dbo.pos_supplierinfo AS bs
                            WHERE      (si_id = f.fu_ci_id)) AS fu_ci_id,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = f.fu_order_man)) AS fu_order_man,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = f.fu_add_man)) AS fu_add_man, f.fu_add_time,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = f.fu_update_man)) AS fu_update_man, f.fu_update_time,
                          (SELECT     si_name
                            FROM          dbo.b_stafftinfo AS bs
                            WHERE      (si_id = f.fu_audit_man)) AS fu_audit_man, f.fu_audit_time, f.fu_remark, f.fu_dateint, f.fu_orderint, f.fu_type, f.fu_status, fl.ful_fu_id, 
                      fl.ful_ensure_money, fl.ful_handsel_money, fl.ful_start_money, fl.ful_money, fl.ful_freight, fl.ful_other_in_money, fl.ful_in_money, fl.ful_out_money, 
                      fl.ful_end_money
FROM         dbo.pos_funds AS f LEFT OUTER JOIN
                          (SELECT     ful_fu_id, SUM(ful_ensure_money) AS ful_ensure_money, SUM(ful_handsel_money) AS ful_handsel_money, SUM(ful_start_money) 
                                                   AS ful_start_money, SUM(ful_money) AS ful_money, SUM(ful_freight) AS ful_freight, SUM(ful_other_in_money) AS ful_other_in_money, 
                                                   SUM(ful_in_money) AS ful_in_money, SUM(ful_out_money) AS ful_out_money, SUM(ful_end_money) AS ful_end_money
                            FROM          dbo.pos_fundsList
                            WHERE      (ful_status > 0)
                            GROUP BY ful_fu_id) AS fl ON f.fu_id = fl.ful_fu_id
WHERE     (f.fu_status > 0)


go

