
CREATE VIEW [dbo].[vi_j_Pos_AlStorageList] AS 
SELECT     all_al_id, all_gi_id, all_add_time, SUM(all_num) AS all_num, MIN(all_id) AS all_id, MAX(all_sku_id) AS all_sku_id, SUM(all_money) AS all_money, 
                      CONVERT(decimal(10, 2), AVG(all_retail_price)) AS all_retail_price, CONVERT(decimal(10, 2), AVG(all_stock_price)) AS all_stock_price, MAX(all_gift) 
                      AS all_gift, CONVERT(decimal(10,2), avg(all_discount)) AS all_discount
                      ,max(replace(all_pm,'*',',')) as all_pm,max(all_box_num) as  all_box_num
FROM         dbo.pos_alStorageList AS jt
WHERE     (all_status = 1)
GROUP BY all_al_id, all_gi_id, all_add_time
go

