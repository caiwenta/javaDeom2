CREATE VIEW [dbo].[v_z_importbyfile]
	AS 
SELECT  
(CASE WHEN T.elapsed>100 THEN 100 ELSE (CASE WHEN T.elapsed<0 THEN 0 ELSE T.elapsed end) END) AS elapsedpercent, 
(case WHEN if_total<>0 and if_elapsed>=if_total then 1 else 0 end ) as finished,
T.*  
FROM (  
SELECT  
(CASE WHEN if_elapsed>=if_total THEN 100  
ELSE  
(CASE WHEN if_elapsed=0 THEN 0  
    ELSE   
ceiling((if_elapsed*0.01)/(if_total*0.01)*100) 
END) 
end) AS elapsed, 
* 
FROM [dbo].[erp_importbyfile] 
) AS T
go

