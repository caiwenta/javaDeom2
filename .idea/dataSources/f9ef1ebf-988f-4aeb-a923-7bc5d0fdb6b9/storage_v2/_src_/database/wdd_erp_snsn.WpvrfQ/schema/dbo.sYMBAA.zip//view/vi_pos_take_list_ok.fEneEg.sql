

CREATE VIEW [dbo].[vi_pos_take_list_ok] AS 

SELECT *
--盈亏数量
,
tsl_logno=tsl_newno-tsl_oldno
 FROM (
select * from (
select jt.tsl_id,
       jt.tsl_type,
       jtso.ts_st_id,
       jtso.ts_sh_id,
       jtso.ts_take_date as tso_take_time,
       jtsl.tsl_gi_id,
       jtsl.tsl_sku_id,
       max(jtso.ts_vo) as ts_vo,
       --日期库存数量
       MAX(jtsl.tsl_old_num)           as tsl_oldno,
	    MAX(isnull(jtsl.tsl_pm,''))     as tsl_pm,
       --盘点数量
       sum(jtsl.tsl_new_num)           as tsl_newno,
       max(jt.tsl_update_time) as tsl_add_time
from pos_takeStorageLog              as jt
       left join pos_takeStorage   as jtso
            on  jt.tsl_id = jtso.ts_tsl_id
       left join pos_takeStorageList    as jtsl
            on  jtso.ts_id = jtsl.tsl_ts_id
where  jt.tsl_status = 2
       and jtso.ts_status = 2
        AND jtsl.tsl_status=1
group by
       jt.tsl_id,
       jt.tsl_type,
       jtso.ts_st_id,
       jtso.ts_sh_id,
       jtso.ts_take_date,
       jtsl.tsl_gi_id,
       jtsl.tsl_sku_id,
	   isnull(jtsl.tsl_pm,'')
) as fd 
--where fd.tsl_logno!=0
) AS fd
go

