--还没完成
CREATE PROCEDURE [dbo].[pro_mergeStockLog_j_takeStorage]
@cp_id INT = 0,   
@negative_inventory INT=0,--产生了负库存是否提示
@old_sei_id INT=0,  
@new_sei_id INT=0,
@id INT=0
AS
EXEC pro_mergeStockLog_check
	@cp_id = @cp_id,
	@negative_inventory = @negative_inventory,
	@old_sei_id = @old_sei_id,
	@new_sei_id = @new_sei_id

IF @@ERROR!=0
BEGIN
	DECLARE @ERROR_MESSAGE VARCHAR(100)='';
	select @ERROR_MESSAGE=ERROR_MESSAGE();
	RAISERROR ( @ERROR_MESSAGE, 16, 1, N'number', 5 );
	RETURN;
END

BEGIN
    BEGIN TRAN
    DECLARE @now DATETIME = GETDATE();

	update j_stocklog set sl_status = 0 where sl_cp_id = @cp_id and sl_eoid = @id 
	and sl_type between 7 and 10

	INSERT j_stocklog
	 (
        sl_eoid,
        sl_elid,
        sl_seiid,
        sl_ciid,
        sl_giid,
        sl_skuid,
        sl_type,
        sl_counttype,
        sl_number,
        sl_addtime,
        sl_updatetime,
        sl_remark,
        sl_status,
        sl_order_no,
        sl_order_date,
        sl_order_add_time,
        sl_cp_id,
		sl_erp_id,
		sl_pm,
		sl_location
      )
select 
        so.eoid,
        so.elid,
        so.[sid],
        so.cid,
        so.gid,
        so.skuid,
        so.mytype,
        so.countType,
        so.gnum,
        so.addtime,
        @now,
        so.myremark,
        1,
        so.orderno,
        so.order_date,
        so.order_add_time,
        so.cp_id
		,so.erp_id,
		isnull(so.pm,''),
		locationid
from (
--盘点,整仓盘点库存抵消  7,8,9,10都是属于盘点
SELECT js.sl_seiid     AS SID,
       isnull(js.sl_location,0) as locationid,
       cid = 0,
       js.sl_giid      AS gid,
       js.sl_skuid     AS skuid,
       js.sl_number	   AS gnum,
	   isnull(js.sl_pm,'') as pm,
       countType=js.sl_counttype,
       myremark=js.sl_remark,
       addtime=js.sl_addtime,
       orderno=js.sl_order_no,
       eoid=js.sl_eoid,
       elid=js.sl_elid,
       mytype = 7,--前台可以此为条件,不显示
       order_add_time = js.sl_order_add_time,
       order_date = js.sl_order_date
       ,js.sl_cp_id as cp_id,
       js.sl_erp_id AS erp_id
FROM   j_stocklog_pal  AS js
WHERE  js.sl_eoid = @id 
       and js.sl_status = 2
       AND js.sl_giid>0
       AND js.sl_seiid>0
UNION ALL
--整仓盘点,盘点明细
SELECT vt.sl_seiid,
       isnull(vt.sl_location,0) as locationid,
       cid = 0,
       vt.sl_giid,
       vt.sl_skuid,
       vt.sl_number,
	   isnull(vt.sl_pm,''),
       vt.sl_counttype,
       vt.sl_remark,
       vt.sl_addtime,
       vt.sl_order_no,
       vt.sl_eoid,
       vt.sl_elid,
       vt.sl_type,
       vt.sl_order_add_time,
       vt.sl_order_date,
       vt.sl_cp_id,
       vt.sl_erp_id
FROM   j_stocklog_pal AS vt
WHERE  vt.sl_eoid = @id
       and vt.sl_status = 1
       AND vt.sl_giid>0
       AND vt.sl_seiid>0
) as so

    --7,8,9,10都是属于盘点
   
    --计算汇总库存
    EXEC pro_mergeStockSum_new @cp_id=@cp_id,@id=@id,@type=7

	--计算汇总仓位库存
	EXEC pro_mergeStocklocationSum_new @cp_id=@cp_id,@id=@id,@type=7


	  --计算汇总库存
    EXEC pro_mergeStockSum_new @cp_id=@cp_id,@id=@id,@type=8

	--计算汇总仓位库存
	EXEC pro_mergeStocklocationSum_new @cp_id=@cp_id,@id=@id,@type=8


	  --计算汇总库存
    EXEC pro_mergeStockSum_new @cp_id=@cp_id,@id=@id,@type=9

	--计算汇总仓位库存
	EXEC pro_mergeStocklocationSum_new @cp_id=@cp_id,@id=@id,@type=9


	--计算汇总库存
    EXEC pro_mergeStockSum_new @cp_id=@cp_id,@id=@id,@type=10

	--计算汇总仓位库存
	EXEC pro_mergeStocklocationSum_new @cp_id=@cp_id,@id=@id,@type=10



	exec pro_mergeStockBatchSum @id=@id,@stockType=7;
	exec pro_mergeStockBatchSum @id=@id,@stockType=8;
	exec pro_mergeStockBatchSum @id=@id,@stockType=9;
	exec pro_mergeStockBatchSum @id=@id,@stockType=10;


	delete j_stocklog where  sl_status = 0 and sl_cp_id = @cp_id and sl_eoid = @id and sl_type between 7 and 10

	IF @@ERROR <> 0
    BEGIN
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0 COMMIT TRAN
    END

END
go

