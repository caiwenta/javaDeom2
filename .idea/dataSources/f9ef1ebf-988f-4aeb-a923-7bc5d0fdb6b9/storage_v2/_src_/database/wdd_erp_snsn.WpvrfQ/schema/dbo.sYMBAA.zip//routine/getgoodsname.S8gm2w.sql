
CREATE function [dbo].[getgoodsname](@id int,@i int)
returns varchar(300)
as 
begin
	declare @sharename varchar(300) ,@name varchar(300) ,@gi_code varchar(300),@rest varchar(300),
	@grade varchar(300)
	
	set @sharename=''
	set @name=''
	select top 1 @sharename=gi_shortname,@name=gi_name,@gi_code=gi_code,@grade=gi_grade from b_goodsinfo where gi_id=@id
	if @i=0 begin
		set @rest=@sharename
	end else if(@i=1) begin
		set @rest=@name
	end else if(@i=2) begin
		set @rest=@gi_code
	end else if(@i=3) begin
		set @rest=@grade
	end
	return @rest
end

go

