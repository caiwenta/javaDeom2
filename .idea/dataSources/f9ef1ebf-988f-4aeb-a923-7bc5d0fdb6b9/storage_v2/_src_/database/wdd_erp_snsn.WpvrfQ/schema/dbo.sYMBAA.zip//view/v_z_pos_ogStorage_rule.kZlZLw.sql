CREATE VIEW [dbo].[v_z_pos_ogStorage_rule]
AS

SELECT rs.ogl_og_id order_id, --主订单id
       rs.cs_id color_order_id, -- 颜色汇总表id
       rs.num sku_num, --数量
       rs.ruleid, --规格id
       gr.gd_row_number spec,--规格排序，占位号
       rs.colorid, --颜色id
       rs.pause_num,--配货中止数量
       rs.pause_num_pll,--采购中止数量
       rs.num_ed,--配货数量
       rs.num_ed_pll,--采购数量
       rs.num_ed_ol--发货数量
FROM pos_ogStorageListMergeRuleSum AS rs
LEFT JOIN s_goodsruledetail AS gr
ON rs.ruleid = gr.gd_id
go

