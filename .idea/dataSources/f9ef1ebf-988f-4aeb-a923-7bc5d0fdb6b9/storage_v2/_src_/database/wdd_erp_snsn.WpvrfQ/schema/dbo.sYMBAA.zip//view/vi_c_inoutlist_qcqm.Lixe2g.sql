CREATE VIEW [dbo].[vi_c_inoutlist_qcqm]
AS 

SELECT * FROM c_bankinfo cb where cb.bk_no='XJ' AND cb.bk_name='现金' and bk_add_time='2014-07-01'
go

