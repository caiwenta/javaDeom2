CREATE VIEW dbo.vi_Pos_Replenishment_Gist
AS
SELECT     '' AS sa_date, '' AS sa_vo, eosa_sh_id, gi_name, gi_code, gi_unit, sh_company AS sa_st_id_txt, sa_order_man_txt, SUM(sal_num) AS sal_num, SUM(sa_get_in_num) AS sa_get_in_num, 
                      SUM(sa_deduct_money) AS sa_deduct_money, SUM(sa_in_money) AS sa_in_money, SUM(sa_shop_money) AS sa_shop_money, SUM(sa_money) AS sa_money, SUM(sa_real_money) 
                      AS sa_real_money, SUM(sa_charge_money) AS sa_charge_money, SUM(sa_surplus_money) AS sa_surplus_money, SUM(sal_money) AS sal_money, SUM(sa_sa_vo) AS sa_sa_vo, 
                      SUM(sa_gift_vo) AS sa_gift_vo, SUM(sa_select) AS sa_select, SUM(sa_audit_man) AS sa_audit_man, SUM(sa_card_money) AS sa_card_money
FROM         dbo.vi_pos_sale_search AS ch
GROUP BY gi_name, gi_code, gi_unit, sh_company, sa_order_man_txt, eosa_sh_id
go

