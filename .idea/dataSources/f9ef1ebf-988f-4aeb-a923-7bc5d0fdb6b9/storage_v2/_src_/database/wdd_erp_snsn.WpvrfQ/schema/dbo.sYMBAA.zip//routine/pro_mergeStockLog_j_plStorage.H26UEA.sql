CREATE PROCEDURE [dbo].[pro_mergeStockLog_j_plStorage]
@cp_id INT = 0,   
@negative_inventory INT=0,--产生了负库存是否提示
@old_sei_id INT=0,  
@new_sei_id INT=0,
@id INT=0
AS

EXEC pro_mergeStockLog_check
	@cp_id = @cp_id,
	@negative_inventory = @negative_inventory,
	@old_sei_id = @old_sei_id,
	@new_sei_id = @new_sei_id
IF @@ERROR!=0
BEGIN
	DECLARE @ERROR_MESSAGE VARCHAR(100)='';
	select @ERROR_MESSAGE=ERROR_MESSAGE();
	RAISERROR ( @ERROR_MESSAGE, 16, 1, N'number', 5 );
	RETURN;
END

BEGIN
    BEGIN TRAN
    DECLARE @now DATETIME = GETDATE();
    MERGE INTO j_stocklog AS ta
    USING (

	SELECT jps.pl_st_id                AS SID,
       cid = 0,
       jpsl.ppl_gi_id              AS gid,
	   jpsl.ppl_locationid		 as lid,
       jpsl.ppl_sku_id             AS skuid,
       ABS(jpsl.ppl_num)           AS gnum,
	   isnull(jpsl.ppl_pm,'')                  as pm,
       countType = (CASE WHEN jpsl.ppl_num >= 0 THEN 1 ELSE 0 END),
       myremark = '盈亏',
       addtime = jpsl.ppl_add_time,
       orderno = jps.pl_vo,
       eoid = jps.pl_id,
       elid = jpsl.ppl_id,
       mytype = 6,
       order_add_time = jps.pl_add_time,
       order_date = jps.pl_date
       ,jps.pl_cp_id AS cp_id,
       jps.pl_erp_id AS erp_id
FROM   j_plStorage                 AS jps
       INNER JOIN j_plStorageList  AS jpsl
            ON  jps.pl_id = jpsl.ppl_pl_id
WHERE  
       jps.pl_id=@id and
	   jps.pl_status =2
       AND jpsl.ppl_status = 1
       AND jpsl.ppl_gi_id>0
       AND jps.pl_st_id>0

        --SELECT *
        --FROM   vi_stockList AS so 
        --WHERE  so.cp_id=@cp_id
               --where so.mytype!=7
   
   
    ) AS so
    ON 
    ta.sl_eoid = so.eoid AND 
    ta.sl_elid = so.elid AND 
    ta.sl_giid = so.gid AND
	ta.sl_location=so.lid and
    ta.sl_skuid = so.skuid AND 
    ta.sl_type = so.mytype AND 
    ta.sl_cp_id = so.cp_id
    
    --AND ta.sl_counttype=so.countType
    --and ta.sl_status=1 
    AND ta.sl_pm=so.pm
    AND ta.sl_seiid = so.[sid] 
    AND ta.sl_addtime = so.addtime 
    AND ta.sl_order_add_time = so.order_add_time 
    WHEN matched THEN 
    UPDATE 
    SET    ta.sl_number = so.gnum,ta.sl_counttype=so.countType,
           ta.sl_updatetime = @now,
		   ta.sl_status=CASE WHEN ta.sl_status=0 THEN 1 ELSE ta.sl_status END, --用于控件审核
		   ta.sl_location=so.lid,
		   ta.sl_ciid=so.cid,
		   ta.sl_pm=so.pm,
		   ta.sl_order_date=so.order_date,
		   ta.sl_order_no=so.orderno
    WHEN NOT matched THEN
    INSERT 
      (
        sl_eoid,
        sl_elid,
        sl_seiid,
        sl_ciid,
        sl_giid,
        sl_skuid,
        sl_type,
        sl_counttype,
        sl_number,
        sl_addtime,
        sl_updatetime,
        sl_remark,
        sl_status,
        sl_order_no,
        sl_order_date,
        sl_order_add_time,
        sl_cp_id,
		sl_erp_id,
		sl_pm,
		sl_location
      )
    VALUES
      (
        so.eoid,
        so.elid,
        so.[sid],
        so.cid,
        so.gid,
        so.skuid,
        so.mytype,
        so.countType,
        so.gnum,
        so.addtime,
        @now,
        so.myremark,
        1,
        so.orderno,
        so.order_date,
        so.order_add_time,
        so.cp_id,
		so.erp_id,
		isnull(so.pm,''),
		so.lid
      )
    WHEN NOT matched BY source AND 
    ta.sl_status = 1 AND ta.sl_cp_id=@cp_id AND ta.sl_type=6 AND ta.sl_eoid = @id
    THEN UPDATE SET ta.sl_status = 0,sl_deltime = @now;
    
    --计算汇总库存
    EXEC pro_mergeStockSum_new @cp_id=@cp_id,@id=@id,@type=6

	 --计算汇总仓位库存
	EXEC pro_mergeStocklocationSum_new @cp_id=@cp_id,@id=@id,@type=6

	--计算汇总批次库存
	--exec pro_mergeBatchStockSum @cp_id=@cp_id,@id=@id,@type=6,
	--@negative_inventory=@negative_inventory,@old_sei_id=@old_sei_id,@new_sei_id=@new_sei_id
    exec pro_mergeStockBatchSum @id=@id,@stockType=6;

    IF @@ERROR <> 0
    BEGIN
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0 COMMIT TRAN
    END
END
go

