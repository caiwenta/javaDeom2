CREATE PROCEDURE [dbo].[pro_mergeBatchStockSum]
@cp_id INT=0,
@id INT=0,
@type INT=0,

@negative_inventory INT=0,--产生了负库存是否提示
@old_sei_id INT=0,  
@new_sei_id INT=0
AS
	 --批次计算库存	
DECLARE @tdoc_xml VARCHAR(max)= '';
declare @erpid int=0;
select @erpid=cp_erp_id from companyinfo where cp_id=@cp_id;       

SET @tdoc_xml = '{ 
"type":"' + CONVERT(VARCHAR(50), @type) + '",
"id":"' + CONVERT(VARCHAR(50), @id) + '",
"cp_id":"' + CONVERT(VARCHAR(50), @cp_id) + '", 
"negative_inventory":"' + CONVERT(VARCHAR(50), @negative_inventory) + '", 
"old_sei_id":"' + CONVERT(VARCHAR(50), @old_sei_id) + '",
"new_sei_id":"' + CONVERT(VARCHAR(50), @new_sei_id) + '" }';

			EXEC pro_apiqueue_op 
			@tdoc_target='storage',
			@tdoc_action='batchnumber',
			@tdoc_method = 'storage', 
			@tdoc_xml = @tdoc_xml, 
			@tdoc_erp_id =@erpid, 
			@tdoc_state = 0;	

			EXEC pro_apiqueue_op 
			@tdoc_target='storage',
			@tdoc_action='mergeStockSumBatchNumber',
			@tdoc_method = 'storage', 
			@tdoc_xml = @tdoc_xml, 
			@tdoc_erp_id =@erpid, 
			@tdoc_state = 0;
go

