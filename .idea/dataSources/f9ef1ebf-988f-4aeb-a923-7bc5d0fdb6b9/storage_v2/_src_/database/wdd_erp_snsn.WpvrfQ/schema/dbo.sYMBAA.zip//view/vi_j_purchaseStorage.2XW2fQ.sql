


CREATE VIEW [dbo].[vi_j_purchaseStorage] AS 
SELECT
    pl_enddate,--预计交货日期
	pl_id,
	pl_vo,
	pl_date,
	pl_no,
	pl_st_id,
	pl_ci_id,
	pl_pltype,
	pl_order_man,
	pl_freight_no,
	pl_express,
	pl_money,
	pl_num,
	pl_cost,
	pl_fright,
	pl_source,
	pl_source_id,
	pl_cp_id,
	pl_di_id,
	pl_type,
	pl_st_id_txt,
	pl_ci_id_txt,
	pl_erp_id,
	cp_name,
	cp_code,
	si_province,
	si_city,
	si_county,
	si_flid,
	si_plid,
	si_code,
	pl_order_man_txt,
	pl_add_man_txt,
	pl_add_man,
	pl_add_time,
	pl_update_man_txt,
	pl_update_man,
	pl_update_time,
	pl_audit_man_txt,
	pl_audit_man,
	pl_audit_time,
	pl_remark,
	pl_status,
	eo_status,
	pl_source_vo,
	sum_num,
	sum_money,
	rk_el_number,
	rkth_el_number,
	sum_num - rk_el_number - ISNULL(pll_pause_num, 0) AS rk_el_number_do,
	sum_num - rkth_el_number - ISNULL(pll_pause_num, 0) AS rkth_el_number_do,
	pll_pause_num,
	pl_totalboxnum,
    pll_totalintegral,
	og_ci_id_txt,
    og_ci_code_txt
FROM
	(
		SELECT
            CONVERT (VARCHAR(10), pl_enddate, 120) AS pl_enddate,--预计交货日期
			pl_id,
			pl_vo,
			CONVERT (VARCHAR(10), pl_date, 120) AS pl_date,
			pl_no,
			pl_st_id,
			pl_ci_id,
			pl_pltype,
			pl_order_man,
			pl_freight_no,
			pl_express,
			pl_money,
			pl_num,
			pl_cost,
			pl_fright,
			pl_source,
			pl_source_id,
			pl_cp_id,
			pl_di_id,
			pl_type,
				pl_erp_id,
			(
				SELECT
					sei_name
				FROM
					dbo.b_storageinfo AS bs WITH (NOLOCK) 
				WHERE
					(sei_id = jis.pl_st_id)
			) AS pl_st_id_txt,
			(
				SELECT
					si_name
				FROM
					dbo.b_supplierinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_ci_id)
			) AS pl_ci_id_txt,
			(
				SELECT
					cp_name
				FROM
					dbo.companyinfo AS c WITH (NOLOCK) 
				WHERE
					(cp_id = jis.pl_ci_id)
			) AS cp_name,
			(
				SELECT
					cp_code
				FROM
					dbo.companyinfo AS c WITH (NOLOCK) 
				WHERE
					(cp_id = jis.pl_ci_id)
			) AS cp_code,
			(
				SELECT
					si_province
				FROM
					dbo.b_supplierinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_ci_id)
			) AS si_province,
			(
				SELECT
					si_city
				FROM
					dbo.b_supplierinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_ci_id)
			) AS si_city,
			(
				SELECT
					si_county
				FROM
					dbo.b_supplierinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_ci_id)
			) AS si_county,
			(
				SELECT
					si_flid
				FROM
					dbo.b_supplierinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_ci_id)
			) AS si_flid,
			(
				SELECT
					TOP (1) type_fid
				FROM
					(
						SELECT
							dbo.b_supplierinfo.si_id,
							dbo.b_supplierinfo.si_ctname,
							dbo.b_supplierinfo.si_ctid,
							dbo.b_supplierinfo.si_name,
							dbo.b_supplierinfo.si_code,
							dbo.b_supplierinfo.si_linkman,
							dbo.b_supplierinfo.si_address,
							dbo.b_supplierinfo.si_bank,
							dbo.b_supplierinfo.si_bankaccount,
							dbo.b_supplierinfo.si_tfn,
							dbo.b_supplierinfo.si_fax,
							dbo.b_supplierinfo.si_phone,
							dbo.b_supplierinfo.si_mobile,
							dbo.b_supplierinfo.si_status,
							dbo.b_supplierinfo.si_remark,
							dbo.b_supplierinfo.si_postcode,
							dbo.b_supplierinfo.si_email,
							dbo.b_supplierinfo.si_referee,
							dbo.b_supplierinfo.si_mainproject,
							dbo.b_supplierinfo.si_site,
							dbo.b_supplierinfo.si_creditline,
							dbo.b_supplierinfo.si_province,
							dbo.b_supplierinfo.si_city,
							dbo.b_supplierinfo.si_county,
							dbo.b_supplierinfo.si_qcje,
							dbo.b_supplierinfo.si_flid,
							dbo.b_supplierinfo.si_isdel,
							dbo.b_supplierinfo.si_add_time,
							dbo.b_supplierinfo.si_add_man,
							dbo.b_supplierinfo.si_update_man,
							dbo.b_supplierinfo.si_update_time,
							dbo.b_supplierinfo.si_cp_id,
							dbo.b_supplierinfo.si_di_id,
							dbo.b_supplierinfo.si_attribute_ids,
							dbo.b_supplierinfo.si_attribute_parentids,
							dbo.cors_type.type_id,
							dbo.cors_type.type_name,
							dbo.cors_type.type_cors,
							dbo.cors_type.addtime,
							dbo.cors_type.remark,
							dbo.cors_type.type_fid,
							dbo.cors_type.type_status,
							dbo.cors_type.type_cp_id,
							dbo.cors_type.type_di_id
						FROM
							dbo.b_supplierinfo WITH (NOLOCK) 
						INNER JOIN dbo.cors_type  WITH (NOLOCK) ON dbo.cors_type.type_fid = dbo.b_supplierinfo.si_flid
					) AS bs_1
				WHERE
					(si_id = jis.pl_ci_id)
			) AS si_plid,
			(
				SELECT
					si_code
				FROM
					dbo.b_supplierinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_ci_id)
			) AS si_code,
			(
				SELECT
					si_name
				FROM
					dbo.b_stafftinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_order_man) --          )
					--END
			) AS pl_order_man_txt,
			(
				SELECT
					si_name
				FROM
					dbo.b_stafftinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_add_man)
			) AS pl_add_man_txt,
			pl_add_man,
			pl_add_time,
			(
				SELECT
					si_name
				FROM
					dbo.b_stafftinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_update_man)
			) AS pl_update_man_txt,
			pl_update_man,
			pl_update_time,
			(
				SELECT
					si_name
				FROM
					dbo.b_stafftinfo AS bs WITH (NOLOCK) 
				WHERE
					(si_id = jis.pl_audit_man)
			) AS pl_audit_man_txt,
			pl_audit_man,
			pl_audit_time,
			pl_remark,
			pl_status,
			pl_totalboxnum,
			(
				SELECT
					MAX (eo_status) AS Expr1
				FROM
					dbo.j_enterStorage AS bs WITH (NOLOCK) 
				WHERE
					(eo_source_id = jis.pl_id)
				AND (eo_source_type = 1)
			) AS eo_status,
			(
				SELECT
					og_vo
				FROM
					dbo.pos_ogStorage AS bs WITH (NOLOCK) 
				WHERE
					(og_id = jis.pl_source_id)
				AND (jis.pl_source = 1)
			) AS pl_source_vo,
			(
				SELECT
					SUM (pll_num) AS Expr1
				FROM
					dbo.j_purchaseStorageList AS bs WITH (NOLOCK) 
				WHERE
					(pll_pl_id = jis.pl_id)
				AND (pll_status = 1)
			) AS sum_num,
			(
				SELECT
					SUM (pll_pause_num) AS Expr1
				FROM
					dbo.j_purchaseStorageList AS bs WITH (NOLOCK) 
				WHERE
					(pll_pl_id = jis.pl_id)
				AND (pll_status = 1)
			) AS pll_pause_num,

				(
				SELECT
					SUM (pll_totalintegral) AS Expr1
				FROM
					dbo.j_purchaseStorageList AS bs WITH (NOLOCK) 
				WHERE
					(pll_pl_id = jis.pl_id)
				AND (pll_status = 1)
			) AS pll_totalintegral,
			(
				SELECT
					SUM (pll_money) AS Expr1
				FROM
					dbo.j_purchaseStorageList AS bs WITH (NOLOCK) 
				WHERE
					(pll_pl_id = jis.pl_id)
				AND (pll_status = 1)
			) AS sum_money,
			ISNULL(
				(
					SELECT
						SUM (fd2.el_number) AS el_number
					FROM
						dbo.j_enterStorage AS fd WITH (NOLOCK) 
					INNER JOIN dbo.j_enterStorageList AS fd2  WITH (NOLOCK) ON fd.eo_id = fd2.el_eoid
					AND fd.eo_source_type = 1 --AND fd.eo_source_id = 
					AND fd2.el_status = 1
					AND fd.eo_status <> 0
					AND fd.eo_type = 0
					AND fd2.el_source_id IN (
						SELECT
							jpsl.pll_id
						FROM
							j_purchaseStorageList jpsl WITH (NOLOCK) 
						WHERE
							jpsl.pll_pl_id = jis.pl_id
					)
				),
				0
			) AS rk_el_number,
			ISNULL(
				(
					SELECT
						SUM (fd2.el_number) AS el_number
					FROM
						dbo.j_enterStorage AS fd WITH (NOLOCK) 
					INNER JOIN dbo.j_enterStorageList AS fd2  WITH (NOLOCK) ON fd.eo_id = fd2.el_eoid
					AND fd.eo_source_type = 1
					AND fd.eo_source_id = jis.pl_id
					AND fd2.el_status = 1
					AND fd.eo_status <> 0
					AND fd.eo_type = 1
				),
				0
			) AS rkth_el_number,
			isnull((
	 SELECT ci_name FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = (select og_ci_id from pos_ogStorage where og_id= jis.pl_source_id))
	 ) ,'')AS og_ci_id_txt,--客户名称

	 isnull((  SELECT ci_code FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = (select og_ci_id from pos_ogStorage where og_id=  jis.pl_source_id )) 
	  ),'')AS og_ci_code_txt--客户代号
		FROM
			dbo.j_purchaseStorage AS jis WITH (NOLOCK)
		WHERE jis.pl_status>0 
	) AS fd_1
go

