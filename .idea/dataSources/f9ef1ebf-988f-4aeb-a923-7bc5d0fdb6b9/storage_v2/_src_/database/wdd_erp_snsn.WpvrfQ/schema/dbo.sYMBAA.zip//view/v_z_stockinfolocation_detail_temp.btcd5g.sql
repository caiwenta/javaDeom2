CREATE VIEW [dbo].[v_z_stockinfolocation_detail_temp] AS
select
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
locationlist.*
from 
(

select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
grl.gs_name,
grl.colorname color,
grl.specname as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
isnull(grl.gs_sampleno,gi_sampleno)gs_sampleno,--规格样品号
ln.* 
from
(

SELECT
bsil.*,
isnull(bsil.si_occupy_num,0)occupy_num,--占用库存
(bsil.si_number-isnull(bsil.si_occupy_num,0))enable_stock_num,--可用库存
bsil.si_indate AS order_add_time,
CONVERT(varchar(100),bsil.si_indate, 23)  AS order_date,
bsil.si_number AS  gnum,
bsil.si_seiid sid,
bsil.si_erp_id as erp_id,
bsil.si_cp_id as cp_id,
esl.slt_no,
esl.slt_id,
esl.slt_pickingpath,
ug.sei_name,--仓库
gi.gi_id,
gi_skuid,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_sampleno,--样品号
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
ui.ut_name --单位
FROM b_stockinfolocation AS bsil
inner join b_storageinfo ug on ug.sei_id=bsil.si_seiid
left JOIN erp_storagelocation AS esl ON esl.slt_id=bsil.si_location AND esl.sei_id=bsil.si_seiid AND esl.slt_status=1
left join b_goodsinfo gi on gi.gi_id=bsil.si_giid and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 

WHERE bsil.si_status=1
) as ln
left join b_goodsruleset  as grl on  grl.gss_id=ln.si_skuid

) as locationlist
left join s_goodsruledetail rulenum on gd_id=locationlist.size
go

