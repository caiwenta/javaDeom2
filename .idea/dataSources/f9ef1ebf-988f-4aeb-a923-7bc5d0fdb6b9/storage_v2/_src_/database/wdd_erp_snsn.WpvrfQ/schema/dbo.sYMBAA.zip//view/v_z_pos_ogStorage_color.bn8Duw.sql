CREATE VIEW [dbo].[v_z_pos_ogStorage_color]
	AS 

SELECT posl.oglmcs_id color_order_id,
       pos.og_id, 
       posl.ogl_og_id,
	   pos.og_vo, 
	   pos.og_no, 
	   CONVERT (VARCHAR(100), pos.og_date, 23) AS og_date,  --订货日期
	   CONVERT (VARCHAR(100), pos.og_out_date, 23) AS og_out_date, --交货日期
	   pos.og_type,  --交易方式(1,订货:2,补货:3,铺货:4,买断)
	   pos.og_ci_id,
	   (SELECT ci_name FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS og_ci_id_txt,--客户名称
	   (SELECT ci_code FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS og_ci_code_txt,--客户代号
	   (SELECT ci_province FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS ci_province,
	   (SELECT ci_city FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS ci_city,
	   pos.og_sh_id,
	   (SELECT sh_name FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS og_sh_id_txt,--店铺名称
	   (SELECT sh_no FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS sh_no,
	   (SELECT province FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS sh_province,
	   (SELECT city FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS sh_city,
	   pos.og_to_cp_id,
	   (SELECT cp_name FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS og_to_cp_id_txt,--分公司名称
	   (SELECT cp_code FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS cp_code,
	   (SELECT cp_province FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS cp_province,
	   (SELECT cp_city FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS cp_city,
	   
	   pos.og_trans, --运输方式
	   pos.og_business, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_business)) AS og_business_txt,--业务员名称
	   pos.og_add_man, 
	   pos.og_add_time, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_add_man)) AS og_add_man_txt,
	   pos.og_update_man,
	   pos.og_update_time, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_update_man)) AS og_update_man_txt,
	   pos.og_audit_man, 
	   pos.og_audit_time, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_audit_man)) AS og_audit_man_txt,
	   pos.og_refe_no,  --参考单号
	   pos.og_order_man,
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_order_man)) AS og_order_man_txt,
	   pos.og_is_lock, --是否锁定折率与供应价不能修改
	   pos.og_status, --状态(0,删除:1,可用:2,审核)
	   pos.og_remark, 
	   pos.og_cp_id,
	   pos.og_di_id,  
	   pos.og_erp_id, 
	   pos.og_source_id,
	   pos.og_source_type,
	   (SELECT re_vo FROM pos_reStorage prs WHERE prs.re_cp_id>0 AND re_id=pos.og_source_id) as re_vo,--来源凭证号
	   (SELECT TOP 1 al_id FROM pos_allocation WITH (NOLOCK) 
	    WHERE al_source_id = pos.og_id AND al_status > 0 AND al_source = 5
	    ORDER BY al_id) AS is_al_audited,--配货来源主键	                                            
	   (SELECT TOP 1 pl_id FROM j_purchaseStorage WITH (NOLOCK) 
	    WHERE pl_source_id = pos.og_id AND pl_status > 0 AND pl_source = 1
	    ORDER BY pl_id) AS is_pl_audited,--采购来源主键
	   pos.og_ph_audit,
	   pos.og_cg_audit,
	   
       '' AS specname,

	   posl.ogl_gi_id,
	   posl.ogl_color_id,
	   ISNULL((SELECT TOP 1 colorname FROM b_goodsruleset b WHERE b.gi_id=posl.ogl_gi_id AND colorid=posl.ogl_color_id ),'无') AS color,   
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_cratebox,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
       bg.gi_retailprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bg.gi_attribute_ids,
       bg.gi_attribute_parentids,
       bg.gi_sampleno,--样品号
       ISNULL((SELECT TOP 1 b.gs_sampleno 
			   FROM b_goodsruleset b 
			   WHERE b.gi_id=posl.ogl_gi_id AND colorid=posl.ogl_color_id),bg.gi_sampleno) AS gs_sampleno,--规格样品号
       gi_unit gi_unit_id,
       (SELECT ut_name FROM b_unit WHERE ut_id=bg.gi_unit)gi_unit,
       ISNULL(posl.ogl_retail_price,0) AS ogl_retail_price,--零售价
       ISNULL(posl.ogl_stock_price,0) AS ogl_stock_price,--供货价
       ISNULL(posl.ogl_money,0) AS ogl_money,--金额
       ISNULL(posl.ogl_money,0) AS summoney,--金额
       ISNULL(posl.ogl_retail_money,0) AS ogl_retail_money,--零售金额
       ISNULL(posl.ogl_discount,0) AS ogl_discount,--折率
       posl.ogl_add_time,--商品添加时间
       
       ISNULL(posl.ogl_num,0) AS ogl_num,--订货数量
	   ISNULL(posl.ogl_num,0) AS sumnum,
       ISNULL(posl.ogl_num_ed,0) AS al_num,--已配货数量
       ISNULL(posl.ogl_num_ed_pll,0) AS pl_num,--已采购数量
       ISNULL(posl.ogl_num_ed_ol,0) AS ol_num,--已发货数量
       ISNULL(posl.ogl_pause_num,0) AS ogl_pause_num,--配货终止数量
       ISNULL(posl.ogl_pause_num_pll,0) AS ogl_pause_num_pll,--采购终止数量
       (ISNULL(posl.ogl_num,0)-ISNULL(posl.ogl_num_ed,0)-ISNULL(posl.ogl_pause_num,0)) AS al_num_do,--未配货数量=订货数量-已配货数量-配货终止数量
	   (ISNULL(posl.ogl_num,0)-ISNULL(posl.ogl_num_ed_pll,0) -ISNULL(posl.ogl_pause_num_pll,0)) AS pl_num_do,--未采购数量=订货数量-已采购数量-采购终止数量
       (ISNULL(posl.ogl_num,0)-ISNULL(posl.ogl_num_ed_ol,0)) AS ol_num_nodo,--未发数量=订货数量-已发货数量
       
       posl.ogl_pm,--配码
       ISNULL(posl.ogl_boxbynum,0) AS ogl_boxbynum,--箱/数量
       ISNULL(posl.ogl_box_num,0) AS ogl_box_num,--箱数
       ISNULL(posl.ogl_box_num_ed,0) AS al_box_num,--已配货箱数
       ISNULL(posl.ogl_box_num_ed_pll,0) AS pl_box_num,--已采购箱数
       ISNULL(posl.ogl_box_num_ed_ol,0) AS ol_box_num,--已发货箱数
       ISNULL(posl.ogl_pause_box_num,0) AS ogl_pause_box_num,--配货终止箱数
       ISNULL(posl.ogl_pause_box_num_pll,0) AS ogl_pause_box_num_pll,--采购终止箱数
       (ISNULL(posl.ogl_box_num,0)-ISNULL(posl.ogl_box_num_ed,0)-ISNULL(posl.ogl_pause_box_num,0)) AS al_box_num_do,--未配货箱数=订货箱数-已配货箱数-配货终止箱数
	   (ISNULL(posl.ogl_box_num,0)-ISNULL(posl.ogl_box_num_ed_pll,0) -ISNULL(posl.ogl_pause_box_num_pll,0)) AS pl_box_num_do,--未采购箱数=订货箱数-已采购箱数-采购终止箱数
       (ISNULL(posl.ogl_box_num,0)-ISNULL(posl.ogl_box_num_ed_ol,0)) AS ol_box_num_nodo--未发箱数=订货箱数-已发货箱数

FROM pos_ogStorage AS pos
LEFT JOIN pos_ogStorageListMergeColorSum AS posl ON pos.og_id=posl.ogl_og_id
INNER JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON posl.ogl_gi_id = bg.gi_id
go

