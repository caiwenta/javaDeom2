
CREATE TRIGGER [dbo].[trg_c_fundorder_update] ON [dbo].[c_fundorder]
       AFTER UPDATE
AS
       BEGIN
             IF ( UPDATE(shname)
                  OR UPDATE(Count) )
                RETURN;

             IF UPDATE(fo_rowNum)
                AND UPDATE(fo_status)
                PRINT '';	
             ELSE
                IF UPDATE(fo_rowNum)
                   RETURN;

             DECLARE @old_ciid INT = 0;
             DECLARE @old_bs VARCHAR(50) = '';
             DECLARE @old_date DATETIME;
             DECLARE @ciid INT = 0;
             DECLARE @bs VARCHAR(50) = '';
             DECLARE @date DATETIME;
             DECLARE @status INT = 0;
             DECLARE @old_status INT = 0;
             DECLARE @fo_type INT= 0;
             DECLARE @fo_to_cpid INT= 0;
             DECLARE @fo_cp_id INT= 0;
             DECLARE @fo_shid INT= 0;
             DECLARE @fo_orderid VARCHAR(50) = '';
             DECLARE @fo_source_id INT = 0;

			 DECLARE @fo_id INT = 0;
			 DECLARE @fo_erp_id INT = 0;

             SELECT @fo_type = fo_type ,
                    @date = fo_ofdate ,
                    @ciid = fo_ciid ,
                    @fo_to_cpid = fo_to_cpid ,
                    @fo_shid = fo_shid ,
                    @bs = fo_bs ,
                    @status = fo_status ,
                    @fo_cp_id = fo_cp_id ,
                    @fo_orderid = fo_orderid ,
                    @fo_source_id = fo_source_id,
					@fo_id=fo_id,
					@fo_erp_id = fo_erp_id,
					@fo_type= @fo_type
             FROM   INSERTED

             DECLARE @ol_status INT= 0;

             SELECT @old_ciid = fo_ciid ,
                    @old_bs = fo_bs ,
                    @old_date = fo_ofdate ,
                    @ol_status = fo_status
             FROM   DELETED;
             
             IF ( @status = 2
                  AND @ol_status = 1
                )
                OR ( @status = 1
                     AND @ol_status = 2
                   )
                PRINT '';	
             ELSE
                RETURN;

             IF UPDATE(fo_status)
                BEGIN
                      IF ( @status = 2 )
                         BEGIN
                               IF ( @fo_source_id > 0 )
                                  BEGIN
                                        UPDATE  c_inoutlist
                                        SET     iol_audit_ed = 1
                                        WHERE   iol_id = @fo_source_id
                                  END
                               ELSE
                                  BEGIN
                                        IF ( @fo_type = 1 )
                                           BEGIN
                                                 UPDATE j_enterStorage
                                                 SET    eo_fo_audit_ed = 1
                                                 WHERE  eo_no = @fo_orderid
                                                        AND eo_cp_id = @fo_cp_id
                                           END
                                        ELSE
                                           BEGIN
                                                 UPDATE j_outStorage
                                                 SET    oo_fo_audit_ed = 1
                                                 WHERE  oo_no = @fo_orderid
                                                        AND oo_cp_id = @fo_cp_id
                                           END
                                  END
                         END
                      ELSE
                         IF ( @status = 1 )
                            BEGIN
                                  IF ( @fo_source_id > 0 )
                                     BEGIN
                                           UPDATE   c_inoutlist
                                           SET      iol_audit_ed = 0
                                           WHERE    iol_id = @fo_source_id
                                     END
                                  ELSE
                                     BEGIN	
                                           IF ( @fo_type = 1 )
                                              BEGIN
                                                    UPDATE  j_enterStorage
                                                    SET     eo_fo_audit_ed = 0
                                                    WHERE   eo_no = @fo_orderid
                                                            AND eo_cp_id = @fo_cp_id
                                              END
                                           ELSE
                                              BEGIN
                                                    UPDATE  j_outStorage
                                                    SET     oo_fo_audit_ed = 0
                                                    WHERE   oo_no = @fo_orderid
                                                            AND oo_cp_id = @fo_cp_id
                                              END
                                     END
                            END
                END

             IF ( UPDATE(fo_status) )
                BEGIN
                      UPDATE    c_fundorder
                      SET       fo_rowNum = cfu.rowNum
                      FROM      c_fundorder cfo ,
                                ( SELECT    ROW_NUMBER() OVER ( ORDER BY cf.fo_ciid, cf.fo_shid, cf.fo_to_cpid, cf.fo_bs, fo_ofdate, cf.fo_id ) AS rowNum ,
                                            cf.fo_id
                                  FROM      c_fundorder cf WITH ( NOLOCK )
                                  WHERE     cf.fo_status = 2
                                            AND cf.fo_ciid = @ciid
                                            AND cf.fo_shid = @fo_shid
                                            AND cf.fo_to_cpid = @fo_to_cpid
                                            AND cf.fo_bs = @bs
                                ) cfu
                      WHERE     cfo.fo_id = cfu.fo_id
                     
					 ----2017-6-29 BJW
					 -- EXEC [pro_merge_c_fundorder_reconciliation] @fo_bs = @bs, @fo_ciid = @ciid, @fo_id =@fo_id,@fo_erp_id=@fo_erp_id,@fo_status=@status,@fo_cp_id=@fo_cp_id; 
                      
					  INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'款项生成',20 ,'开始触发器计算客户供应商固化数据'+@fo_orderid,@fo_id);

					           

                      --EXEC pro_merge_c_fundorder @fo_bs = @bs, @fo_ciid = @ciid, @fo_id = @fo_id, @fo_shid = @fo_shid, @fo_to_cpid = @fo_to_cpid,
                      -- @operate_type = '计算客户供应商固化数据';
				     
					 if (@status=1)
					 BEGIN
					 update c_fundorder set fo_queue_status=0 where fo_status=1 and fo_id=@fo_id
					 end

				     INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'款项生成',20 ,'触发器计算客户供应商固化数据成功'+@fo_orderid,@fo_id);

                END
       END
go

