CREATE  PROC [dbo].[pro_vi_pos_inStorageList_audit_sku_search_tb]
@inl_in_id INT = 0,
@inl_add_time DATETIME = '2004-10-17',
@gi_id INT,
@inl_type INT,
@do_type INT=0
AS

IF @do_type=0
begin

SELECT *,
	   (inl_num -ISNULL(inl_var_num,0)) AS optnum,
       (inl_num -ISNULL(inl_num_ed, 0))  AS inl_num_ding,
       (inl_num -ISNULL(inl_num_ed, 0))  AS inl_num_do
       INTO #p
FROM   b_goodsruleset AS bg
       LEFT JOIN (
SELECT 
pit.*,

( 
SELECT  SUM(pisl.inl_num)  AS inl_num 
FROM   pos_inStorage  AS pis 
INNER JOIN pos_inStorageList  AS pisl ON  pis.in_id = pisl.inl_in_id WHERE  pis.in_status > 0 
AND pisl.inl_status > 0 AND 
pis.in_source_id=pit.inl_in_id  AND 
pisl.inl_gi_id=pit.inl_gi_id AND
pisl.inl_sku_id=pit.inl_sku_id and
pis.in_source=pit.inl_type 
 ) AS inl_num_ed, 

(SELECT SUM(inl_var_num) AS inl_var_num 
FROM pos_inStorageList_audit 
WHERE inl_in_id=pit.inl_in_id AND 
inl_gi_id=pit.inl_gi_id AND 
inl_sku_id=pit.inl_sku_id and
inl_type=pit.inl_type
) as inl_var_num


FROM   (
SELECT
	inl_in_id,
	inl_gi_id,
	inl_type,
	SUM (inl_num) AS inl_num,
	MIN (inl_id) AS inl_id,
	 inl_sku_id,
	SUM (inl_money) AS inl_money,
	CONVERT (DECIMAL (10, 2),AVG (inl_retail_price)) AS inl_retail_price,
	CONVERT (DECIMAL (10, 2),AVG (inl_stock_price)) AS inl_stock_price,
	CONVERT (DECIMAL (10, 2),AVG (inl_discount)) AS inl_discount,
	--inl_pm,
	inl_box_num
FROM
	dbo.vi_pos_inStorageList_audit AS jt WITH (NOLOCK)
WHERE jt.inl_in_id = @inl_in_id AND jt.inl_type = @inl_type  AND jt.inl_gi_id = @gi_id
GROUP BY
	inl_in_id,
	inl_gi_id,
	inl_type,
	--inl_pm,
	inl_sku_id,
	inl_box_num
) AS pit
            )AS p1
            ON  bg.gi_id = p1.inl_gi_id
            AND bg.gss_id = p1.inl_sku_id
WHERE  bg.gi_id = @gi_id;
end
else if @do_type=1  --已入库
begin
SELECT *,
       (inl_num -ISNULL(inl_num_ed, 0))  AS inl_num_ding,
       (inl_num -ISNULL(inl_num_ed, 0))  AS inl_num_do
       INTO #p1
FROM   b_goodsruleset AS bg
       LEFT JOIN (
SELECT 
pit.*,

( 
SELECT  SUM(pisl.inl_num)  AS inl_num 
FROM   pos_inStorage  AS pis 
INNER JOIN pos_inStorageList  AS pisl ON  pis.in_id = pisl.inl_in_id WHERE  pis.in_status > 0 
AND pisl.inl_status > 0 AND 
pis.in_source_id=pit.inl_in_id  AND 
pisl.inl_gi_id=pit.inl_gi_id AND
pisl.inl_sku_id=pit.inl_sku_id and
pis.in_source=pit.inl_type 
 ) AS inl_num_ed, 

(SELECT SUM(inl_var_num) AS inl_var_num 
FROM pos_inStorageList_audit 
WHERE inl_in_id=pit.inl_in_id AND 
inl_gi_id=pit.inl_gi_id AND 
inl_sku_id=pit.inl_sku_id and
inl_type=pit.inl_type
) as inl_var_num


FROM   (
SELECT
	inl_in_id,
	inl_gi_id,
	inl_type,
	SUM (inl_num) AS inl_num,
	MIN (inl_id) AS inl_id,
	 inl_sku_id,
	SUM (inl_money) AS inl_money,
	CONVERT (DECIMAL (10, 2),AVG (inl_retail_price)) AS inl_retail_price,
	CONVERT (DECIMAL (10, 2),AVG (inl_stock_price)) AS inl_stock_price,
	CONVERT (DECIMAL (10, 2),AVG (inl_discount)) AS inl_discount,
	--inl_pm,
	inl_box_num
FROM
	dbo.vi_pos_inStorageList_audit AS jt WITH (NOLOCK)
WHERE jt.inl_in_id = @inl_in_id AND jt.inl_type = @inl_type  AND jt.inl_gi_id = @gi_id
GROUP BY
	inl_in_id,
	inl_gi_id,
	inl_type,
	--inl_pm,
	inl_sku_id,
	inl_box_num
) AS pit
            )AS p1
            ON  bg.gi_id = p1.inl_gi_id
            AND bg.gss_id = p1.inl_sku_id
WHERE  bg.gi_id = @gi_id;


end
else if @do_type=2--未入库
begin
 
SELECT gss_id,gi_id	,gss_no,	gs_id	,gs_name	,gs_stock	,gs_salesprice	,gs_marketprice	,
gs_costprice	,gs_weight,	gs_upstock	,gs_downstork	,gs_alarmstock	,gs_columnid,
	gs_purchase,	gs_oc_id,	gs_addtime,	gs_updatetime,	gs_type_id,	gs_type_id_parentid,
		gs_taobao_id,	gs_is_custom,	gs_discount,	gss_cp_id,	gss_di_id,	inl_type,
			inl_id,	inl_in_id,	inl_gi_id,	inl_sku_id,(inl_num -ISNULL(inl_num_ed, 0)) as inl_num,	inl_retail_price,
				inl_discount,	inl_stock_price,	inl_money	,inl_remark,	inl_pm,
					inl_box_num,	inl_add_time,	inl_source_id,	inl_num_ed,
						
       (inl_num -ISNULL(inl_num_ed, 0))  AS inl_num_ding,
       (inl_num -ISNULL(inl_num_ed, 0))  AS inl_num_do
        INTO #p2
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT *
                FROM   (
                           SELECT *
                           FROM   vi_pos_inStorageList_audit AS fd
                           WHERE  fd.inl_add_time = @inl_add_time
                                  AND fd.inl_in_id = @inl_in_id
                                  AND fd.inl_type = @inl_type
                                  AND fd.inl_gi_id = @gi_id
                       )       AS p1
                       LEFT JOIN (
                                SELECT pisl.inl_source_id,
                                       ISNULL(SUM(pisl.inl_num), 0) AS 
                                       inl_num_ed
                                FROM   pos_inStorage AS pis
                                       INNER JOIN pos_inStorageList AS pisl
                                            ON  pis.in_id = pisl.inl_in_id
                                WHERE  pis.in_status > 0
                                       AND pisl.inl_status > 0
                                       AND pis.in_source > 0
                                       AND pis.in_source = @inl_type
                                GROUP BY
                                       pisl.inl_source_id
                            )  AS p2
                            ON  p1.inl_id = p2.inl_source_id
            )AS p1
            ON  bg.gi_id = p1.inl_gi_id
            AND bg.gss_id = p1.inl_sku_id
WHERE  bg.gi_id = @gi_id;
end

IF @do_type=0
begin
SELECT * FROM #p
end
else if @do_type=1
begin
SELECT * FROM #p1
end
else if @do_type=2
begin
SELECT * FROM #p2
end
go

