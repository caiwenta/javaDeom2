CREATE View [dbo].[vi_kh_yf_sum]
As  
--得到每个客户,每月第一次和最后一次款项的期末,期初
Select p1.*,cf1.qm,cf1.qc,cf2.qm As first_qm,cf2.qc As first_qc
From(Select Convert(Varchar(7),cf.fo_ofdate,23)As yf,
--最后一次
Max(cf.fo_rowNum)As fo_rowNum,
--第一次
Min(cf.fo_rowNum) As fo_rowNum1,
cf.fo_ciid,cf.fo_bs From vi_c_fundorder_list cf 
Group By Convert(Varchar(7),cf.fo_ofdate,23),cf.fo_ciid,cf.fo_bs)As p1 Left Join vi_c_fundorder_list cf1 On p1.fo_ciid=cf1.fo_ciid And p1.fo_bs=cf1.fo_bs And p1.fo_rowNum=cf1.fo_rowNum Left Join vi_c_fundorder_list cf2 On p1.fo_ciid=cf2.fo_ciid And p1.fo_bs=cf2.fo_bs And p1.fo_rowNum1=cf2.fo_rowNum
go

