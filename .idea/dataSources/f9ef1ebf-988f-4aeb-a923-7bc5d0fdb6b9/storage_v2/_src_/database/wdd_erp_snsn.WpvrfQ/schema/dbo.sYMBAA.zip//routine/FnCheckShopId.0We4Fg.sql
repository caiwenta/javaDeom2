CREATE FUNCTION [dbo].[FnCheckShopId] ( @sh_id INT, @erp_id INT )
RETURNS INT
AS
BEGIN
	--用途：验证店铺与erpid是否匹配
    DECLARE @re INT;
	
    IF ( ISNULL(@sh_id, 0) = 0 )
        SET @re = 1;
    ELSE
        IF EXISTS ( SELECT  1
                    FROM    dbo.pos_shop
                    WHERE   sh_id = @sh_id
                            AND sh_erp_id = @erp_id )
            SET @re = 1;
        ELSE
            SET @re = 0;
        
    RETURN @re;
END
go

