CREATE VIEW [dbo].[vi_stockList_sku] AS 
SELECT *
FROM   (
           SELECT fd.[sid],
                  fd.cid,
                  fd.gid,
                  fd.skuid,
                  fd.orderno,
                  fd.order_date,
                  fd.order_add_time,
                  fd.myremark,
                  CASE 
                       WHEN countType = 1 THEN gnum
                       ELSE -gnum
                  END           AS gnum,
                  fd.addtime,
                  fd.cp_id
           FROM   vi_stockList  AS fd
       )                         AS fd
       INNER JOIN b_goodsruleset  AS bg
            ON  fd.skuid = bg.gss_id
       INNER JOIN b_storageinfo   AS bs
            ON  fd.[sid] = bs.sei_id
go

