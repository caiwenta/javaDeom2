

CREATE PROC [dbo].[pro_pos_takeStorageList_skuid_search_tb]
@tsl_box_num INT = 0,
@tsl_pm VARCHAR(500) = '',
@gss_no VARCHAR(500) = '',
--主键  
@tsl_id INT = 0,  
--盘点单主键  
@tsl_ts_id INT = 0,  
--商品主键  
@tsl_gi_id INT = 0,  
--商品sku主键  
@tsl_sku_id INT = 0,  
--日期库存数量  
@tsl_old_num INT = 0,  
--实盘数量  
@tsl_new_num INT = 0,  
--盈亏数量  
@tsl_log_num INT = 0,  
--日期库存重量  
@tsl_old_weight DECIMAL(9, 2) = 0,  
--实盘重量  
@tsl_new_weight DECIMAL(9, 2) = 0,  
--盈亏重量  
@tsl_log_weight DECIMAL(9, 2) = 0,  
--原金额  
@tsl_old_money DECIMAL(9, 2) = 0,  
--盈亏金额  
@tsl_log_money DECIMAL(9, 2) = 0,  
--实盘金额  
@tsl_new_money DECIMAL(9, 2) = 0,  
--零售价  
@tsl_retail_price DECIMAL(9, 2) = 0,  
--进货价
@tsl_stock_price DECIMAL(9, 2) = 0,
--折扣
@tsl_discount DECIMAL(9, 2) = 0,
--备注  
@tsl_remark VARCHAR(200) = '',  
--添加时间  
@tsl_add_time DATETIME = '2014-11-03',  
--修改时间  
@tsl_update_time DATETIME = '2014-11-03',  
--主键  
@ts_id INT = 0,  
--店铺主键  
@ts_sh_id int=0, 
--仓库主键  
@ts_st_id INT = 0,  
--制单人主键  
@ts_order_man INT = 0,  
--部门主键  
@ts_it_id INT = 0,  
--盘点日期  
@ts_take_date DATETIME = '2014-11-03',  
--备注  
@ts_remark VARCHAR(50) = '',  
--添加人主键  
@ts_add_man INT = 0,  
--添加时间  
@ts_add_time DATETIME = '2014-11-03',  
--修改人主键  
@ts_update_man INT = 0,  
--修改时间  
@ts_update_time DATETIME = '2014-11-03',  
--审核人主键  
@ts_audit_man INT = 0,  
--审核时间  
@ts_audit_time DATETIME = '2014-11-03',  
--单据号  
@ts_no VARCHAR(50) = '',  
--总数量  
@ts_total_num INT = 0,  
--库存确认时间  
@tso_take_time DATETIME = '2014-11-03',  
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  
--产生了负库存是否提示
@negative_inventory INT = 0,
--结果  
@result VARCHAR(100) = '' OUT,
--公司主键
@ts_cp_id INT = 0,
--部门主键
@ts_di_id INT = 0,
--保存字符串
@savestr VARCHAR(MAX) = ''
AS

  
begin

DECLARE @m_gi_id int = 0;
DECLARE @m_skuid int = 0;
DECLARE @m_gss_no VARCHAR(50) = '';
DECLARE @m_gi_add_time DATETIME;
DECLARE @m_gi_purchase DECIMAL(9, 2) = 0;
DECLARE @m_gi_retailprice DECIMAL(9, 2) = 0;

DECLARE @m_tsl_new_num int = 0;
DECLARE @m_tsl_old_num int = 0;
DECLARE @m_tsl_old_numx int = 0;
DECLARE @m_tsl_log_num int = 0;
DECLARE @m_gs_weight DECIMAL(9, 2) = 0;  
DECLARE @m_tsl_add_time DATETIME;  
DECLARE @m_ts_add_time datetime;  
DECLARE @m_tsl_id int = 0;
DECLARE @m_gi_barcode VARCHAR(50) = 0;
DECLARE @mtest VARCHAR(500) = '';
--============  

--修改时
if @ts_id>0 BEGIN
  set  @tsl_ts_id=@ts_id 
end
set  @tsl_id=0

--SELECT 'return='=@tsl_date
--return 

set  @m_tsl_new_num=0;
set @savestr ='';
if EXISTS(SELECT * from b_goodsruleset where gss_no like   '%'+@gss_no+'%')--有规格
BEGIN 
declare cursor1 cursor for
SELECT   bg2.gi_id,  bg.gss_no,  bg.gss_id, bg2.gi_add_time, bg2.gi_retailprice, bg2.gi_purchase
FROM   b_goodsruleset  AS bg  
       LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id  
WHERE  bg2.gi_id=(SELECT top 1 gi_id from b_goodsruleset where gss_no =  @gss_no )
--SELECT top 1 @m_gi_id=gi_id from b_goodsruleset where gss_no =  @gss_no;
--select 'return='=@m_gi_id
--return 
--使用游标的对象(跟据需要填入select文)
 OPEN cursor1 --打开游标
 FETCH NEXT FROM cursor1 INTO  @m_gi_id,@m_gss_no,@m_skuid,@m_gi_add_time,@m_gi_retailprice,@m_gi_purchase --,@m_gs_weight--将游标向下移1行，获取的数据放入之前定义的变量@id,@name中
 if @m_gi_id=0 BEGIN

  set @result='输入错误,当前商品有规格，请输入正确的规格编码！';
 SELECT 'id'=@result ;
return
end
 
WHILE @@fetch_status = 0 --判断是否成功获取数据
BEGIN
    --SELECT 'return='=@m_gss_no 
  --修改数量时得出原单据数量
--set @tsl_new_num= @m_tsl_new_num+3 

  if @ts_id>0 BEGIN
   IF EXISTS(SELECT * from  pos_takeStorageList WHERE  tsl_ts_id = @ts_id  and  tsl_gi_id = @m_gi_id and tsl_sku_id=@m_skuid  and tsl_status>0)
   BEGIN
  SELECT top 1 @m_tsl_id=tsl_id,@m_tsl_add_time=tsl_add_time,@m_tsl_old_num =tsl_new_num,@m_tsl_old_numx =tsl_old_num,@m_tsl_log_num =tsl_log_num from pos_takeStorageList WHERE  tsl_ts_id = @ts_id and  tsl_gi_id = @m_gi_id and tsl_sku_id=@m_skuid  and tsl_status>0
   set @tsl_add_time=@m_tsl_add_time
      SELECT top 1 @m_ts_add_time=ts_add_time from pos_takeStorage where ts_id=@ts_id and ts_status>0
   set @ts_add_time=@m_ts_add_time
     set @m_tsl_id=@m_tsl_id
   set @tsl_id=@m_tsl_id
   --set @tsl_new_num=@m_tsl_old_num --旧数量
   --if @ts_id>0 BEGIN
   --set @tsl_new_num=999
  --end
  end
  end
  --根据公司获得进货价 s
  if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE   b.cp_id=@ts_cp_id and b.cp_dhprice=15 and a.gd_gi_id=@m_gi_id)  --进货价为 15-订货
   BEGIN
  SELECT top 1 @m_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE   b.cp_id=@ts_cp_id and b.cp_dhprice=15 and a.gd_gi_id=@m_gi_id

  end 
  --根据公司获得进货价 e
  set @tsl_sku_id=@m_skuid
  set @tsl_stock_price=@m_gi_purchase
  set @tsl_retail_price=@m_gi_retailprice
  set @tsl_gi_id=@m_gi_id
  set @mtest=@mtest+cast(@m_skuid as varchar(10)) +'|'
    if @m_gss_no!=@gss_no BEGIN --使用旧数量
    set @savestr =@savestr +cast(@tsl_id as varchar(10))+',' + cast(@tsl_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+ cast(@m_tsl_old_numx as varchar(10))+','+ cast(@m_tsl_old_num as varchar(10))+','+ cast(@m_tsl_log_num as varchar(10))+','+ cast(@m_gi_retailprice as varchar(10)) +','+ cast(@tsl_stock_price as varchar(10))+'|' 
  END
  else
  BEGIN--使用新数量 
   set @tsl_new_num=@tsl_new_num+@m_tsl_old_num
   set @tsl_log_num=@tsl_new_num-@m_tsl_old_numx
   set @savestr =@savestr +cast(@tsl_id as varchar(10))+',' + cast(@tsl_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+ cast(@m_tsl_old_numx as varchar(10))+','+ cast(@tsl_new_num as varchar(10))+','+ cast(@tsl_log_num as varchar(10))+','+ cast(@m_gi_retailprice as varchar(10)) +','+ cast(@tsl_stock_price as varchar(10))+'|' 
  end
 
    --进行相应处理(跟据需要填入SQL文)

 FETCH NEXT

FROM
 cursor1 INTO  @m_gi_id,@m_gss_no,@m_skuid,@m_gi_add_time,@m_gi_retailprice,@m_gi_purchase--,@m_gs_weight --将游标向下移1行
END
CLOSE cursor1 --关闭游标
DEALLOCATE cursor1
end
ELSE
BEGIN
--无规格
if EXISTS(SELECT  * from b_goodsinfo bg2  WHERE  bg2.gi_barcode=@gss_no)
BEGIN
 SELECT  top 1 @m_gi_id= bg2.gi_id, @m_gi_barcode=bg2.gi_barcode, @m_gi_add_time=bg2.gi_add_time, @m_gi_retailprice=bg2.gi_retailprice, @m_gi_purchase=bg2.gi_purchase, @m_gi_retailprice=bg2.gi_retailprice  from b_goodsinfo bg2  WHERE  bg2.gi_barcode=@gss_no

     if @ts_id>0 BEGIN
   IF EXISTS(SELECT * from  pos_takeStorageList WHERE  tsl_ts_id = @ts_id  and  tsl_gi_id = @m_gi_id   and tsl_status>0)
   BEGIN
  SELECT top 1 @m_tsl_id=tsl_id,@m_tsl_add_time=tsl_add_time,@m_tsl_old_num =tsl_new_num,@m_tsl_old_numx =tsl_old_num,@m_tsl_log_num =tsl_log_num from pos_takeStorageList WHERE  tsl_ts_id = @ts_id and  tsl_gi_id = @m_gi_id    and tsl_status>0
   set @tsl_add_time=@m_tsl_add_time
      SELECT top 1 @m_ts_add_time=ts_add_time from j_takeStorage where ts_id=@ts_id and ts_status>0
   set @ts_add_time=@m_ts_add_time
     set @m_tsl_id=@m_tsl_id
   set @tsl_id=@m_tsl_id
   --set @tsl_new_num=@m_tsl_old_num --旧数量
   --if @ts_id>0 BEGIN
   --set @tsl_new_num=999
  --end
  end
  end
  --根据公司获得进货价 s
  if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE   b.cp_id=@ts_cp_id and b.cp_dhprice=15 and a.gd_gi_id=@m_gi_id)  --进货价为 15-订货
   BEGIN
  SELECT top 1 @m_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE   b.cp_id=@ts_cp_id and b.cp_dhprice=15 and a.gd_gi_id=@m_gi_id

  end 
  --根据公司获得进货价 e
  set @tsl_sku_id=@m_skuid
  set @tsl_stock_price=@m_gi_purchase
  set @tsl_retail_price=@m_gi_retailprice
  set @tsl_gi_id=@m_gi_id
  set @mtest=@mtest+cast(@m_skuid as varchar(10)) +'|'
    if @m_gi_barcode!=@gss_no BEGIN --使用旧数量
    set @savestr =@savestr +cast(@tsl_id as varchar(10))+',' + cast(@tsl_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+ cast(@m_tsl_old_numx as varchar(10))+','+ cast(@m_tsl_old_num as varchar(10))+','+ cast(@m_tsl_log_num as varchar(10))+','+ cast(@m_gi_retailprice as varchar(10)) +','+ cast(@tsl_stock_price as varchar(10))+'|' 
  END
  else
  BEGIN--使用新数量 
   set @tsl_new_num=@tsl_new_num+@m_tsl_old_num
   set @tsl_log_num=@tsl_new_num-@m_tsl_old_numx
   set @savestr =@savestr +cast(@tsl_id as varchar(10))+',' + cast(@tsl_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+ cast(@m_tsl_old_numx as varchar(10))+','+ cast(@tsl_new_num as varchar(10))+','+ cast(@tsl_log_num as varchar(10))+','+ cast(@m_gi_retailprice as varchar(10)) +','+ cast(@tsl_stock_price as varchar(10))+'|' 
  end

END
ELSE
BEGIN
 set @result=0;
 SELECT 'id'=@result ;
return
end
end



--SELECT 'return='=@mtest
--SELECT 'return='=@savestr
--return 
--==================



 


set @op_type='添加修改单据,明细'
EXECUTE [pro_pos_takeStorage_op]@tsl_box_num,
@tsl_pm,
--主键  
@tsl_id,  
--盘点单主键  
@tsl_ts_id,  
--商品主键  
@tsl_gi_id,  
--商品sku主键  
@tsl_sku_id,  
--日期库存数量  
@tsl_old_num,  
--实盘数量  
@tsl_new_num,  
--盈亏数量  
@tsl_log_num,  
--日期库存重量  
@tsl_old_weight,  
--实盘重量  
@tsl_new_weight,  
--盈亏重量  
@tsl_log_weight,  
--原金额  
@tsl_old_money,  
--盈亏金额  
@tsl_log_money,  
--实盘金额  
@tsl_new_money,  
--零售价  
@tsl_retail_price,  
--进货价
@tsl_stock_price,
--折扣
@tsl_discount,
--备注  
@tsl_remark  ,  
--添加时间  
@tsl_add_time ,  
--修改时间  
@tsl_update_time ,  
--主键  
@ts_id,  
--店铺主键  
@ts_sh_id,  
--仓库主键  
@ts_st_id,  
--制单人主键  
@ts_order_man,  
--部门主键  
@ts_it_id,  
--盘点日期  
@ts_take_date,  
--备注  
@ts_remark ,  
--添加人主键  
@ts_add_man,  
--添加时间  
@ts_add_time,  
--修改人主键  
@ts_update_man,  
--修改时间  
@ts_update_time,  
--审核人主键  
@ts_audit_man,  
--审核时间  
@ts_audit_time,  
--单据号  
@ts_no ,  
--总数量  
@ts_total_num,  
--库存确认时间  
@tso_take_time,  
--操作类型  
@op_type,  

@negative_inventory,
--结果  
@result  OUTPUT,
--保存字符串
@savestr 
 
SELECT 'id'=@result 
--==================
--SELECT   bg2.gi_id, bg.gss_no, bg2.gi_add_time
--FROM   b_goodsruleset  AS bg  
--       LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
--WHERE  bg.gi_id = @gi_id   AND bg.gss_no = @gss_no
 
end


go

