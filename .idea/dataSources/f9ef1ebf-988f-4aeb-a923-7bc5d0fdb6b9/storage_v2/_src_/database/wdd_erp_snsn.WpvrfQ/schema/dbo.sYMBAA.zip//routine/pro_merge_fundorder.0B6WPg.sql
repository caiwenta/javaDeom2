CREATE PROCEDURE [dbo].[pro_merge_fundorder]
	 @fo_id INT = 0
AS
INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'新款项生成',20 ,'开始计算客户供应商固化数据',@fo_id);

--对象最开始的期初金额计算期初期末不累加上去，所以每次查询期初期末都要加上对象最开始的期初金额，
DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';

BEGIN TRY

BEGIN

 DECLARE @fo_o_id INT = 0 ;--对象id
 DECLARE @fo_cp_id INT = 0 ;
 DECLARE @fo_ciid INT = 0 ;
 DECLARE @fo_shid INT = 0;
 DECLARE @fo_to_cpid INT = 0;
 
 DECLARE @fo_type int=0;-- 0:应收 1:应付
 DECLARE @cp_is_zorf INT=1;--1:总部 2:分公司
 
SELECT 
 	@fo_ciid=isnull(fo_ciid,0),
 	@fo_shid=isnull(fo_shid,0),
 	@fo_to_cpid=isnull(fo_to_cpid,0),
 	@fo_type=isnull(fo_type,0),
 	@fo_cp_id=isnull(fo_cp_id,0)
FROM c_fundorder cf WHERE fo_id=@fo_id;
SELECT 
	@cp_is_zorf=cp_is_zorf 
FROM companyinfo AS c 
WHERE c.cp_id=@fo_cp_id
 
 
 
 --获取对象的id
 IF @fo_type=0
 BEGIN
 	
	 IF @fo_ciid>0
	 begin
		select @fo_o_id=o_id from a_objectlist WITH (NOLOCK) where o_cp_id=@fo_cp_id and o_objid=@fo_ciid and o_type=1;--客户
	 END
	 

	 IF  @fo_to_cpid>0
	 BEGIN
		select @fo_o_id=o_id from a_objectlist WITH (NOLOCK) where o_cp_id=@fo_cp_id and o_objid=@fo_to_cpid and o_type=3;--公司
	 END
	 

	 IF @fo_shid>0
	 BEGIN
	 	IF @cp_is_zorf=1
	 	BEGIN
			select @fo_o_id=o_id from a_objectlist WITH (NOLOCK) where o_cp_id=@fo_cp_id and o_objid=@fo_shid and o_type=4;--店铺
	 	END
	 	ELSE
	 	BEGIN
	 		select @fo_o_id=o_id from a_objectlist WITH (NOLOCK) where o_cp_id=@fo_cp_id and o_objid=@fo_shid and o_type=5;--店铺
	 	END                                                                                       
	 END
	 
end
IF @fo_type=1
BEGIN	
 	 if @fo_ciid>0
	 BEGIN
		select @fo_o_id=o_id from a_objectlist WITH (NOLOCK) where  o_cp_id=@fo_cp_id and o_objid=@fo_ciid and o_type=2;--供应商
	 END	 
END


 DECLARE @currentQc decimal(10,2)=0;--当前期初金额
 DECLARE @maxrownum INT=0;--最大排序号
 DECLARE @currentRownNum INT=0;--当前排序号
 
 SELECT
	 @currentRownNum=rowNum --获取当前排序序号
 FROM (
 	SELECT 
 		fo_id,
 		ROW_NUMBER() OVER (partition by cf.fo_type,cf.fo_ciid, cf.fo_to_cpid, cf.fo_shid,cf.fo_cp_id order by cf.fo_ofdate asc,cf.fo_id asc ) AS rowNum
 	FROM c_fundorder cf WITH(NOLOCK) 
 	WHERE (fo_status = 2 AND fo_type=@fo_type AND fo_ciid=@fo_ciid AND fo_shid=@fo_shid AND fo_to_cpid=@fo_to_cpid AND fo_cp_id=@fo_cp_id) 
 	OR fo_id=@fo_id
 ) AS bn WHERE bn.fo_id=@fo_id;


DECLARE @PreviousRownNo int=@currentRownNum-1;--上一条的记录

IF @currentRownNum=1
BEGIN
  set @currentQc=0;
END
ELSE 
BEGIN
	--获取上单的期未金额
	SELECT 
	@currentQc=isnull(fo_qm,0) 
	FROM c_fundorderbyorder WHERE fo_o_id=@fo_o_id AND rowNum=@PreviousRownNo
END



--根据当前的排序号获得要计算期初期末订单：fo_ciid, fo_to_cpid,fo_shid,fo_cp_id ,fo_ofdate asc,fo_id asc 
DECLARE @fundorder TABLE(
	fdmoney  DECIMAL(15, 2),
	rowNum INT ,
	fo_id INT ,
	fo_type INT , 
	fo_ciid INT , 
	fo_to_cpid INT , 
	fo_shid INT , 
	fo_orderid INT , 
	fo_order_no VARCHAR(50) ,
	fo_ticketno VARCHAR(50) , 
	fo_thiyetmoney DECIMAL(15, 2) , --本期付款/本期收款
	fo_ofdate DATETIME , 
	fo_remark VARCHAR(200) , 
	fo_realmoney DECIMAL(15, 2) , --出库/入库金额
	fo_outmoney DECIMAL(15, 2) , --退货金额
	fo_admoney DECIMAL(15, 2) , --垫付运费   
	fo_otheronmoney DECIMAL(15, 2) ,--其他应收    
	fo_otheoutmoney DECIMAL(15, 2) , --其他应付
	fo_givemoney DECIMAL(15, 2) ,--赠送金额（不参与计算）
	fo_ensuremoney DECIMAL(15, 2) ,--保证金（不参与计算）
	fo_subscription decimal(10,2) ,--定金（不参与计算）
	fo_finished_money DECIMAL(15, 2) , 
	fo_parts_money DECIMAL(15, 2)  ,
	fo_no VARCHAR(50) ,
	fo_qc DECIMAL(15, 2) , 
	fo_qm DECIMAL(15, 2) ,
	fo_cp_id INT ,
	fo_erp_id INT ,
	fo_custom_remark VARCHAR(220) , 
	fo_addman VARCHAR(100)  DEFAULT '', 
	fo_addtime DATETIME , 
	fo_updatetime DATETIME ,
	fo_lastman VARCHAR(50),
	fo_o_id int 
);
INSERT INTO @fundorder
(
	fdmoney, 
	rowNum ,
	fo_id  ,
	fo_type  , 
	fo_ciid  , 
	fo_to_cpid  , 
	fo_shid  , 
	fo_orderid  , 
	fo_order_no ,
	fo_ticketno  , 
	fo_ofdate  , 
	fo_remark , 
	fo_realmoney  ,
	fo_admoney  , 
	fo_otheronmoney  , 
	fo_otheoutmoney ,
	fo_outmoney, 
	fo_thiyetmoney , 
	fo_givemoney  ,
	fo_ensuremoney ,
	fo_subscription ,
	fo_finished_money  , 
	fo_parts_money   ,
	fo_no  ,
	fo_qc  , 
	fo_qm  ,
	fo_cp_id  ,
	fo_erp_id  ,
	fo_custom_remark  , 
	fo_addman , 
	fo_addtime  , 
	fo_updatetime ,
	fo_lastman,
	fo_o_id
)
SELECT 
	fdmoney,
	rowNum,
	fo_id,
	fo_type,
	isnull(fo_ciid,0), 
	isnull(fo_to_cpid,0), 
	isnull(fo_shid,0) , 
	isnull(fo_order_id,0)  , 
	isnull(fo_orderid,'') ,
	isnull(fo_ticketno,''), 
	fo_ofdate, 
	isnull(fo_remark,''), 
	isnull(fo_realmoney,0),
	isnull(fo_admoney,0), 
	isnull(fo_otheronmoney,0),
	isnull(fo_otheoutmoney,0), 
	isnull(fo_outmoney,0),
	isnull(fo_thiyetmoney,0),
	isnull(fo_givemoney,0),
	isnull(fo_ensuremoney,0),
	isnull(fo_subscription,0),
	isnull(fo_finished_money,0),
	isnull(fo_parts_money,0),
	isnull(fo_no,''),
	isnull(fo_qc,0),
	isnull(fo_qm,0),
	isnull(fo_cp_id,0),
	isnull(fo_erp_id,0),
	isnull(fo_custom_remark,''),
	isnull(fo_addman,''),
	fo_addtime,
	fo_updatetime,
	isnull(fo_lastman,''),
	@fo_o_id
FROM (
		SELECT 
			(CASE WHEN cf.fo_type = 0 THEN isnull(cf.fo_realmoney,0) + isnull(cf.fo_admoney,0) + isnull(cf.fo_otheronmoney,0)-isnull(cf.fo_otheoutmoney,0)-isnull(cf.fo_outmoney,0)-isnull(cf.fo_thiyetmoney,0)
 										ELSE isnull(cf.fo_realmoney,0) + isnull(cf.fo_otheoutmoney,0)-isnull(cf.fo_outmoney,0)-isnull(cf.fo_thiyetmoney,0)-isnull(cf.fo_admoney,0)-isnull(cf.fo_otheronmoney,0) END) 
			as fdmoney,
			ROW_NUMBER() OVER ( partition by cf.fo_type,cf.fo_ciid, cf.fo_to_cpid, cf.fo_shid,cf.fo_cp_id order by cf.fo_ofdate asc,cf.fo_id asc ) AS rowNum,
			fo_id,
			cf.fo_type,
			cf.fo_ciid  , 
			cf.fo_to_cpid  , 
			cf.fo_shid , 
			cf.fo_order_id  , 
			cf.fo_orderid ,
			cf.fo_ticketno, 
			cf.fo_ofdate, 
			cf.fo_remark, 
			cf.fo_realmoney,
			cf.fo_admoney, 
			cf.fo_otheronmoney,
			cf.fo_otheoutmoney, 
			cf.fo_outmoney,
			cf.fo_thiyetmoney,
			cf.fo_givemoney,
			cf.fo_ensuremoney,
			cf.fo_subscription,
			cf.fo_finished_money,
			cf.fo_parts_money,
			cf.fo_no,
			cf.fo_qc,
			cf.fo_qm,
			cf.fo_cp_id,
			cf.fo_erp_id,
			cf.fo_custom_remark,
			cf.fo_addman,
			cf.fo_addtime,
			cf.fo_updatetime,
			cf.fo_lastman
		FROM c_fundorder cf WITH(NOLOCK) 
		WHERE fo_status = 2 
 			and fo_type=@fo_type 
 			AND fo_ciid=@fo_ciid 
 			AND fo_shid=@fo_shid 
 			AND fo_to_cpid=@fo_to_cpid
 			and fo_cp_id=@fo_cp_id 
) AS bn where rowNum>@PreviousRownNo



--计算期初期末 
DECLARE @qc decimal(10,2)=0;
DECLARE @rownum INT=0;
SET @qc=@currentQc;
SET @rownum=@currentRownNum;
SELECT @maxrownum=max(rowNum) from @fundorder; --获得最大的排序号
while @rownum<=@maxrownum  
begin 
	--更新汇总数据
	UPDATE @fundorder SET fo_qc=@qc,fo_qm=@qc+fdmoney WHERE rowNum=@rownum;
	SELECT @qc=fo_qm FROM @fundorder WHERE rowNum=@rownum;
	set @rownum=@rownum+1;
end 

DELETE c_fundorderbyorder FROM c_fundorderbyorder WITH(NOLOCK) WHERE fo_o_id=@fo_o_id AND rowNum>@PreviousRownNo
INSERT INTO dbo.c_fundorderbyorder
		(
		 rowNum
		,fo_id
		,fo_type
		,fo_ciid
		,fo_to_cpid
		,fo_shid
		,fo_orderid
		,fo_order_no
		,fo_ticketno
		,fo_thiyetmoney
		,fo_ofdate
		,fo_remark
		,fo_realmoney
		,fo_outmoney
		,fo_admoney
		,fo_otheronmoney
		,fo_otheoutmoney
		,fo_givemoney
		,fo_ensuremoney
		,fo_subscription
		,fo_finished_money
		,fo_parts_money
		,fo_no
		,fo_qc
		,fo_qm
		,fo_cp_id
		,fo_erp_id
		,fo_custom_remark
		,fo_addman
		,fo_addtime
		,fo_updatetime
		,fo_lastman
		,fdmoney
		,fo_o_id
		,firtday
		,fo_year
		,moon
)
SELECT 
		 rowNum
		,fo_id
		,fo_type
		,fo_ciid
		,fo_to_cpid
		,fo_shid
		,fo_orderid
		,fo_order_no
		,fo_ticketno
		,fo_thiyetmoney
		,fo_ofdate
		,fo_remark
		,fo_realmoney
		,fo_outmoney
		,fo_admoney
		,fo_otheronmoney
		,fo_otheoutmoney
		,fo_givemoney
		,fo_ensuremoney
		,fo_subscription
		,fo_finished_money
		,fo_parts_money
		,fo_no
		,fo_qc
		,fo_qm
		,fo_cp_id
		,fo_erp_id
		,fo_custom_remark
		,fo_addman
		,fo_addtime
		,fo_updatetime
		,fo_lastman
		,fdmoney
		,fo_o_id
		,CONVERT(int,convert(nvarchar(6),fo_ofdate,112)+'1')
		,isnull(DATEPART(year,fo_ofdate),0) AS fo_year
		,isnull(DATEPART(month,fo_ofdate),0) as moon
FROM @fundorder








--计算明细期初期末（排除手工订单）
--partition BY ft.rowNum order by jt.el_addtime asc,jt.elms_id asc  
IF (1=1) 
begin
 
	DECLARE @fundorderbydetail TABLE(
 		fdmoney  DECIMAL(15, 2),
 		rowNum INT ,
 		childrowNum INT,
 		fo_id INT ,
 		fo_type INT , 
 		fo_ciid INT , 
 		fo_to_cpid INT , 
 		fo_shid INT , 
 		fo_orderid INT , 
 		fo_order_no VARCHAR(50) ,
 		fo_ticketno VARCHAR(50) , 
 		fo_thiyetmoney DECIMAL(15, 2) , --本期付款/本期收款
 		fo_ofdate DATETIME , 
 		fo_remark VARCHAR(200) , 
 		fo_realmoney DECIMAL(15, 2) , --出库/入库金额
 		fo_outmoney DECIMAL(15, 2) , --退货金额
 		fo_admoney DECIMAL(15, 2) , --垫付运费   
 		fo_otheronmoney DECIMAL(15, 2) ,--其他应收    
 		fo_otheoutmoney DECIMAL(15, 2) , --其他应付
 		fo_givemoney DECIMAL(15, 2) ,--赠送金额（不参与计算）
 		fo_ensuremoney DECIMAL(15, 2) ,--保证金（不参与计算）
 		fo_subscription decimal(10,2) ,--定金（不参与计算）
 		fo_finished_money DECIMAL(15, 2) , 
 		fo_parts_money DECIMAL(15, 2)  ,
 		fo_no VARCHAR(50) ,
 		fo_qc DECIMAL(15, 2) , 
 		fo_qm DECIMAL(15, 2) ,
 		fo_cp_id INT ,
 		fo_erp_id INT ,
 		fo_custom_remark VARCHAR(220) , 
 		fo_addman VARCHAR(100)  DEFAULT '', 
 		fo_addtime DATETIME , 
 		fo_updatetime DATETIME ,
 		fo_lastman VARCHAR(50),
 		gi_id INT NOT NULL DEFAULT 0,
		gi_code VARCHAR(50) , 
		gi_name VARCHAR(50) , 
		gi_unit VARCHAR(50) , 
		f_number INT, 
		f_costprice DECIMAL(15, 2),
		fo_o_id int 
	 );
	INSERT INTO @fundorderbydetail
			   (
           		fdmoney
			   ,rowNum
			   ,childrowNum
			   ,fo_id
			   ,fo_type
			   ,fo_ciid
			   ,fo_to_cpid
			   ,fo_shid
			   ,fo_orderid
			   ,fo_order_no
			   ,fo_ticketno
			   ,fo_ofdate
			   ,fo_remark
			   ,fo_realmoney
			   ,fo_admoney
			   ,fo_otheronmoney
			   ,fo_otheoutmoney
			   ,fo_outmoney
			   ,fo_thiyetmoney
			   ,fo_givemoney
			   ,fo_ensuremoney
			   ,fo_subscription
			   ,fo_finished_money
			   ,fo_parts_money
			   ,fo_no
			   ,fo_qc
			   ,fo_qm
			   ,fo_cp_id
			   ,fo_erp_id
			   ,fo_custom_remark
			   ,fo_addman
			   ,fo_addtime
			   ,fo_updatetime
			   ,fo_lastman
			   ,gi_id
			   ,gi_code
			   ,gi_name
			   ,gi_unit
			   ,f_number
			   ,f_costprice
			   ,fo_o_id
	 )
	 SELECT 
		 fmoney=(CASE WHEN t.fo_type=0 then
 						(t.fo_realmoney + isnull(t.fo_admoney,0) + t.fo_otheronmoney -isnull(t.fo_otheoutmoney,0) - t.fo_outmoney- t.fo_thiyetmoney)
 				ELSE
 						(t.fo_realmoney + t.fo_otheoutmoney - t.fo_outmoney - t.fo_thiyetmoney -isnull(t.fo_admoney,0) -isnull(t.fo_otheronmoney,0))
 		END),
 		t.rowNum,
 		t.childrowNum,
 		t.fo_id,
 		t.fo_type,
 		t.fo_ciid,
		t.fo_to_cpid,
 		t.fo_shid,
 		t.fo_orderid,
 		t.fo_order_no,
 		t.fo_ticketno,
 		t.fo_ofdate,
 		t.fo_remark,
 		t.fo_realmoney,
 		t.fo_admoney,
 		t.fo_otheronmoney,
 		t.fo_otheoutmoney,
 		t.fo_outmoney,
 		t.fo_thiyetmoney,
 		t.fo_givemoney,
 		0 fo_ensuremoney,--保证金
 		0 fo_subscription,--定金
 		fo_finished_money=(CASE WHEN t.gi_id>0 THEN (case when gi_ownership=0 then case when t.fo_outmoney>0 then t.fo_outmoney else t.fo_realmoney end else 0 end) ELSE 0 end),--成品金额
 		fo_parts_money=(CASE WHEN t.gi_id>0 THEN (case when gi_ownership =1 then case when t.fo_outmoney>0 then t.fo_outmoney else t.fo_realmoney end else 0 end)ELSE 0 end),--辅品金额
 		t.fo_no,
 		t.fo_qc,
 		t.fo_qm,
 		ISNULL(t.fo_cp_id,0),
 		ISNULL(t.fo_erp_id,0),
 		t.fo_custom_remark,
 		t.fo_addman,
 		t.fo_addtime,
 		t.fo_updatetime,
 		t.fo_lastman,
 		t.gi_id,
 		t.gi_code,
 		t.gi_name,
 		t.gi_unit,
 		f_number,
 		f_costprice,
		fo_o_id
	 FROM (
 		--其它应收应付
 		SELECT 
 			ft.fo_id,
 			ft.fo_orderid,
 			ft.rowNum,
 			0 AS childrowNum,
 			ft.fo_qc,
 			0 AS fo_realmoney,
 			ft.fo_admoney,
 			ft.fo_otheronmoney,
 			ft.fo_otheoutmoney,
 			0 fo_thiyetmoney,
 			0 fo_outmoney,
 			0 fo_givemoney,
 			ft.fo_qm,
 			ft.fo_type,
 			0 gi_id,
 			0 f_number,
 			0 f_costprice,
 		
 			isnull(ft.fo_ciid,0) AS fo_ciid,
 			ISNULL(ft.fo_to_cpid,0) AS fo_to_cpid,
 			ISNULL(ft.fo_shid,0) AS fo_shid,
 			ISNULL(ft.fo_order_no,'') AS fo_order_no,
 			ISNULL(ft.fo_ticketno,'') AS fo_ticketno,
 			ft.fo_ofdate,
 			ISNULL(ft.fo_no,'') AS fo_no,
 			ISNULL(ft.fo_remark,'') AS fo_remark,
 			ft.fo_cp_id,
 			ft.fo_erp_id,
 			ISNULL(ft.fo_custom_remark,'') AS fo_custom_remark,
 			ISNULL(ft.fo_addman,'') AS fo_addman, 
 			ft.fo_addtime,
 			ft.fo_updatetime,
 			ISNULL(ft.fo_lastman,'') AS fo_lastman,
 			'' AS gi_code,
 			'' AS gi_name,
 			'' AS gi_unit,
 			0 AS gi_ownership,
			fo_o_id
 		FROM @fundorder ft
 		WHERE (fo_admoney != 0 OR fo_otheronmoney != 0 OR fo_otheoutmoney != 0 ) AND fo_orderid>0
 
 		UNION ALL 
 	
 		--应收
 		SELECT 
 			ft.fo_id,
 			ft.fo_orderid,
 			ft.rowNum,
 			ROW_NUMBER() OVER (partition BY ft.rowNum order by jt.ol_addtime asc,jt.olms_id asc ) AS childrowNum,
 			ft.fo_qc,
 			(CASE WHEN jo.oo_type = 0 OR isnull(jt.ol_gift, 0) = 1 THEN 0 
 				  WHEN jo.oo_type = 1 AND isnull(jt.ol_gift, 0)= 0 THEN abs(jt.ol_realmoney)
 				  ELSE 0 end
 			) AS fo_realmoney,
 		
 			0 AS fo_admoney, --垫付运费  
 			0 AS fo_otheronmoney,--其他应收
 			0 AS fo_otheoutmoney,--其他应付
 			isnull((CASE WHEN jo.oo_cash = 1 AND isnull(jt.ol_gift, 0) = 0 THEN 
			isnull((CASE WHEN jo.oo_type = 0 THEN -abs(jt.ol_realmoney)  ELSE abs(jt.ol_realmoney)  end),0) ELSE fo_thiyetmoney END ),0) fo_thiyetmoney,--本期付款/本期收款
 			
			isnull((CASE WHEN jo.oo_type = 0 THEN abs(jt.ol_realmoney) ELSE fo_outmoney end),0) AS fo_outmoney, --退货金额
 			isnull((CASE WHEN isnull(jt.ol_gift, 0) = 1 THEN abs(jt.ol_realmoney) ELSE 0 end),0) AS fo_givemoney,--赠送金额（不参与计算）
 			ft.fo_qm,
 			ft.fo_type,
 			jt.ol_siid,
			isnull((CASE WHEN jo.oo_type = 0 THEN -abs(jt.ol_number) ELSE abs(jt.ol_number) end),0) AS ol_number,
 			jt.ol_costprice,
 		
 			isnull(ft.fo_ciid,0) AS fo_ciid,
 			ISNULL(ft.fo_to_cpid,0) AS fo_to_cpid,
 			ISNULL(ft.fo_shid,0) AS fo_shid,
 			ISNULL(ft.fo_order_no,'') AS fo_order_no,
 			ISNULL(ft.fo_ticketno,'') AS fo_ticketno,
 			ft.fo_ofdate,
 			ISNULL(ft.fo_no,'') AS fo_no,
 			ISNULL(ft.fo_remark,'') AS fo_remark,
 			ft.fo_cp_id,
 			ft.fo_erp_id,
 			ISNULL(ft.fo_custom_remark,'') AS fo_custom_remark,
 			ISNULL(ft.fo_addman,'') AS fo_addman, 
 			ft.fo_addtime,
 			ft.fo_updatetime,
 			ISNULL(ft.fo_lastman,'') AS fo_lastman,
 			bg.gi_code,
 			bg.gi_name,
 			bg.gi_unit_name,
 			bg.gi_ownership,
			fo_o_id
 		FROM  j_outStorageListMergeSum jt WITH(NOLOCK) 
 		INNER join j_outStorage as jo WITH(NOLOCK) on jo.oo_id=jt.ol_eoid and jt.ol_status>0
 		INNER JOIN @fundorder AS ft ON ft.fo_orderid=jt.ol_eoid
 		LEFT JOIN b_goodsinfo AS bg ON bg.gi_id=jt.ol_siid AND bg.gi_status>0
 		WHERE ft.fo_type=0 AND ft.fo_orderid>0
 
 		UNION ALL 
 	
 		--应付
 		SELECT
 			ft.fo_id,
 			ft.fo_orderid,
 			ft.rowNum,
 			ROW_NUMBER() OVER (partition BY ft.rowNum order by jt.el_addtime asc,jt.elms_id asc ) AS childrowNum,
 			ft.fo_qc,
 			(CASE WHEN je.eo_type = 1 OR isnull(jt.el_gift, 0) = 1 THEN 0 
 				  WHEN je.eo_type = 0 AND isnull(jt.el_gift, 0) = 0 THEN abs(jt.el_realmoney)
 				  ELSE 0 end
 			) AS fo_realmoney,
 			0 AS fo_admoney, --垫付运费  
 			0 AS fo_otheronmoney,--其他应收
 			0 AS fo_otheoutmoney,--其他应付
 			0 fo_thiyetmoney,--本期付款/本期收款
 			isnull((CASE WHEN je.eo_type = 1 THEN abs(jt.el_realmoney) ELSE fo_outmoney end),0) AS fo_outmoney, --退货金额
 			(CASE WHEN isnull(el_gift, 0) = 1 THEN abs(jt.el_realmoney) ELSE 0 end) AS fo_givemoney,--赠送金额（不参与计算）
 			ft.fo_qm,
 			ft.fo_type,
 			jt.el_siid, 
			isnull((CASE WHEN je.eo_type = 1 THEN -abs(jt.el_number) ELSE abs(jt.el_number) end),0) AS el_number,
 			jt.el_costprice,
 		
 			isnull(ft.fo_ciid,0) AS fo_ciid,
 			ISNULL(ft.fo_to_cpid,0) AS fo_to_cpid,
 			ISNULL(ft.fo_shid,0) AS fo_shid,
 			ISNULL(ft.fo_order_no,'') AS fo_order_no,
 			ISNULL(ft.fo_ticketno,'') AS fo_ticketno,
 			ft.fo_ofdate,
 			ISNULL(ft.fo_no,'') AS fo_no,
 			ISNULL(ft.fo_remark,'') AS fo_remark,
 			ft.fo_cp_id,
 			ft.fo_erp_id,
 			ISNULL(ft.fo_custom_remark,'') AS fo_custom_remark,
 			ISNULL(ft.fo_addman,'') AS fo_addman, 
 			ft.fo_addtime,
 			ft.fo_updatetime,
 			ISNULL(ft.fo_lastman,'') AS fo_lastman,
 			bg.gi_code,
 			bg.gi_name,
 			bg.gi_unit_name,
 			bg.gi_ownership,
			fo_o_id
		FROM j_enterStorageListMergeSum jt WITH(NOLOCK) 
		INNER join j_enterStorage as je WITH(NOLOCK) on je.eo_id=jt.el_eoid and jt.el_status>0
		INNER JOIN @fundorder AS ft ON ft.fo_orderid=jt.el_eoid
		LEFT JOIN b_goodsinfo AS bg ON bg.gi_id=jt.el_siid AND bg.gi_status>0
		WHERE fo_type=1 and fo_orderid>0

	) AS t


	DECLARE @DetailMaxRowNum INT=0; --明细的最大行数
	DECLARE @currentDetailRownNum INT=0;--明细的行数
	DECLARE @currentchildrowNum INT=0;--明细的子行数
	DECLARE @currentDetailQc decimal(10,2)=0;--当前行的期初金额

	--计算期初期末
	DECLARE @temp TABLE(rowNum INT);
	--插入要计算的数据（注意订单只有一个商品就不算期初期末）
	INSERT INTO @temp(rowNum)
	SELECT RowNum FROM @fundorderbydetail GROUP BY RowNum HAVING COUNT(1)>1

	--根据rowNum 和childrowNum区分商品顺序
	WHILE EXISTS(SELECT rowNum FROM @temp)
	BEGIN
	
		SELECT TOP 1 @currentDetailRownNum= rowNum FROM @temp;

		SET @currentchildrowNum =0;
		SELECT @currentDetailQc=fo_qc FROM @fundorder WHERE rowNum=@currentDetailRownNum
		SELECT @DetailMaxRowNum=COUNT(1) FROM @fundorderbydetail WHERE rowNum=@currentDetailRownNum;
		WHILE (@currentchildrowNum<=@DetailMaxRowNum) 
		BEGIN 
	
			UPDATE @fundorderbydetail SET fo_qc=@currentDetailQc, fo_qm=@currentDetailQc+fdmoney WHERE rowNum=@currentDetailRownNum AND childrowNum=@currentchildrowNum;
			SELECT @currentDetailQc=fo_qm FROM @fundorderbydetail WHERE rowNum=@currentDetailRownNum AND childrowNum=@currentchildrowNum;
			set @currentchildrowNum=@currentchildrowNum+1;

		END 

		DELETE FROM @temp WHERE rowNum=@currentDetailRownNum;
	END


	DELETE c_fundorderbydetail FROM c_fundorderbydetail WITH(NOLOCK) WHERE fo_o_id=@fo_o_id AND rowNum>@PreviousRownNo
	INSERT INTO c_fundorderbydetail
			   (rowNum
			   ,childrowNum
			   ,fo_id
			   ,fo_type
			   ,fo_ciid
			   ,fo_to_cpid
			   ,fo_shid
			   ,fo_orderid
			   ,fo_order_no
			   ,fo_ticketno
			   ,fo_ofdate
			   ,fo_remark
			   ,fo_realmoney
			   ,fo_admoney
			   ,fo_otheronmoney
			   ,fo_otheoutmoney
			   ,fo_outmoney
			   ,fo_thiyetmoney
			   ,fo_givemoney
			   ,fo_ensuremoney
			   ,fo_subscription
			   ,fo_finished_money
			   ,fo_parts_money
			   ,fo_no
			   ,fo_qc
			   ,fo_qm
			   ,fo_cp_id
			   ,fo_erp_id
			   ,fo_custom_remark
			   ,fo_addman
			   ,fo_addtime
			   ,fo_updatetime
			   ,fo_lastman
			   ,gi_id
			   ,gi_code
			   ,gi_name
			   ,gi_unit
			   ,f_number
			   ,f_costprice
			   ,fdmoney
			   ,fo_o_id
	)
	SELECT 
				rowNum
			   ,childrowNum
			   ,fo_id
			   ,fo_type
			   ,fo_ciid
			   ,fo_to_cpid
			   ,fo_shid
			   ,fo_orderid
			   ,fo_order_no
			   ,fo_ticketno
			   ,fo_ofdate
			   ,fo_remark
			   ,fo_realmoney
			   ,fo_admoney
			   ,fo_otheronmoney
			   ,fo_otheoutmoney
			   ,fo_outmoney
			   ,fo_thiyetmoney
			   ,fo_givemoney
			   ,fo_ensuremoney
			   ,fo_subscription
			   ,fo_finished_money
			   ,fo_parts_money
			   ,fo_no
			   ,fo_qc
			   ,fo_qm
			   ,fo_cp_id
			   ,fo_erp_id
			   ,fo_custom_remark
			   ,fo_addman
			   ,fo_addtime
			   ,fo_updatetime
			   ,fo_lastman
			   ,gi_id
			   ,gi_code
			   ,gi_name
			   ,gi_unit
			   ,f_number
			   ,f_costprice
			   ,fdmoney
			   ,fo_o_id
	FROM (
		SELECT 
				rowNum
			   ,childrowNum
			   ,fo_id
			   ,fo_type
			   ,fo_ciid
			   ,fo_to_cpid
			   ,fo_shid
			   ,fo_orderid
			   ,fo_order_no
			   ,fo_ticketno
			   ,fo_ofdate
			   ,fo_remark
			   ,fo_realmoney
			   ,fo_admoney
			   ,fo_otheronmoney
			   ,fo_otheoutmoney
			   ,fo_outmoney
			   ,fo_thiyetmoney
			   ,fo_givemoney
			   ,fo_ensuremoney
			   ,fo_subscription
			   ,fo_finished_money
			   ,fo_parts_money
			   ,fo_no
			   ,fo_qc
			   ,fo_qm
			   ,fo_cp_id
			   ,fo_erp_id
			   ,fo_custom_remark
			   ,fo_addman
			   ,fo_addtime
			   ,fo_updatetime
			   ,fo_lastman
			   ,gi_id
			   ,gi_code
			   ,gi_name
			   ,gi_unit
			   ,f_number
			   ,f_costprice
			   ,fdmoney
			   ,fo_o_id
		FROM @fundorderbydetail
		UNION ALL
		SELECT 
			rowNum ,
			0 AS childrowNum,
 			fo_id  ,
 			fo_type  , 
 			fo_ciid  , 
 			fo_to_cpid  , 
 			fo_shid  , 
 			fo_orderid  , 
 			fo_order_no ,
 			fo_ticketno  , 
 			fo_ofdate  , 
 			fo_remark , 
 			fo_realmoney  ,
 			fo_admoney  , 
 			fo_otheronmoney  , 
 			fo_otheoutmoney ,
 			fo_outmoney, 
 			fo_thiyetmoney , 
 			fo_givemoney  ,
 			fo_ensuremoney ,
 			fo_subscription ,
 			fo_finished_money  , 
 			fo_parts_money   ,
 			fo_no  ,
 			fo_qc  , 
 			fo_qm  ,
 			fo_cp_id  ,
 			fo_erp_id  ,
 			fo_custom_remark  , 
 			fo_addman , 
 			fo_addtime  , 
 			fo_updatetime ,
 			fo_lastman,
 			0 gi_id,
 			'' gi_code,
 			'' gi_name ,
 			'' gi_unit,
 			0 f_number,
 			0 f_costprice
 			,fdmoney
			,fo_o_id
		FROM @fundorder ft WHERE fo_orderid=0
	) AS TT

end


--计算月汇总
if (1=1)
begin

delete c_fundorderbymoon from c_fundorderbymoon where fo_o_id=@fo_o_id
INSERT INTO dbo.c_fundorderbymoon
           (fo_type
           ,fo_ciid
           ,fo_to_cpid
           ,fo_shid
           ,fo_realmoney
           ,fo_admoney
           ,fo_otheronmoney
           ,fo_otheoutmoney
           ,fo_outmoney
           ,fo_thiyetmoney
           ,fo_givemoney
           ,fo_ensuremoney
           ,fo_subscription
           ,fo_finished_money
           ,fo_parts_money
           ,fo_qc
           ,fo_qm
           ,fo_cp_id
           ,fo_erp_id
           ,fdmoney
           ,fo_o_id
           ,firtday
           ,fo_year
           ,moon)
SELECT 
    fo_type,
	fo_ciid,
	fo_to_cpid,
	fo_shid,
	SUM(fo_realmoney)as fo_realmoney, 
	SUM(fo_admoney)as fo_admoney, 
	sum(fo_otheronmoney) as fo_otheronmoney,
	sum(fo_otheoutmoney) as fo_otheoutmoney,
	SUM(fo_outmoney)as fo_outmoney, 
	SUM(fo_thiyetmoney)as fo_thiyetmoney,  
	SUM(fo_givemoney)as fo_givemoney,  
	SUM(fo_ensuremoney)as fo_ensuremoney,  
    SUM(fo_subscription)as fo_subscription,  
	SUM(fo_finished_money)as fo_finished_money,  
	SUM(fo_parts_money)as fo_parts_money ,  
	0 as fo_qc,
	0 as fo_qm,
	fo_cp_id,
	fo_erp_id,
	SUM(fdmoney) AS fdmoney,
	fo_o_id,
	firtday,
	fo_year,
	moon
FROM c_fundorderbyorder
where fo_o_id=@fo_o_id
group by fo_o_id,
	fo_ciid,
	fo_to_cpid,
	fo_shid,
	firtday,
	fo_type,
	fo_year,
	moon,
	fo_cp_id,
	fo_erp_id

end


END

INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'款项生成',20 ,'计算客户供应商固化数据成功',@fo_id);
END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
	INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'款项生成',20 ,@ERROR_MESSAGE,@fo_id);
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

