CREATE VIEW [v_fundorder_c]

AS
select fun.*,
		(CASE WHEN fo_order_id>0 THEN (
			(CASE  WHEN fo_type=0 THEN
			     jis.oo_status
			 ELSE
				(SELECT jes.eo_status FROM j_enterStorage AS jes WHERE jes.eo_id=fo_order_id)
			END)
		) ELSE 1 END) as orderstatus,
       (case when fo_order_id >0 then oo_addman_txt else fo_addman end)as addman,  --制单人
	   (case when fo_order_id >0 then oo_remark else fo_custom_remark end)as remark --自定义备注
from (
SELECT --b_clientinfo.ci_id,
       (select cp_name from companyinfo where cp_id=fo_cp_id)set_cpname,
       (CASE WHEN fo_ciid<>0 THEN b_clientinfo.ci_name ELSE '' END)objectname,
       (CASE WHEN fo_ciid<>0 THEN b_clientinfo.ci_code ELSE '' END)objectcode,
       c_fundorder.fo_erp_id,
       c_fundorder.fo_id,
       c_fundorder.fo_type,
       c_fundorder.fo_ciid,
       c_fundorder.fo_shid,
       c_fundorder.fo_to_cpid,
       c_fundorder.fo_bs,
       c_fundorder.fo_orderid,
       c_fundorder.fo_takeman,
       c_fundorder.fo_ticketno,
       c_fundorder.fo_realmoney,
       c_fundorder.fo_thiyetmoney,
       c_fundorder.fo_ofdate,
       c_fundorder.fo_remark,
       c_fundorder.fo_lastman,
       c_fundorder.fo_status,
       c_fundorder.fo_outmoney,
       c_fundorder.fo_admoney,
       c_fundorder.fo_otheronmoney,
       c_fundorder.fo_otheoutmoney,
       c_fundorder.fo_givemoney,
       c_fundorder.fo_ensuremoney,
       c_fundorder.fo_subscription,
       c_fundorder.fo_no,
       c_fundorder.fo_addtime,
       c_fundorder.fo_updatetime,
       c_fundorder.fo_rowNum,
       b_clientinfo.ci_name,
       b_clientinfo.ci_code,
	   (select type_name from cors_type where type_id= b_clientinfo.ci_flid) as ci_type,--客户分类
       '' AS sh_name,
       '' AS sh_no,
       '' AS cp_name,
       '' AS cp_code,
       c_fundorder.fo_cp_id,
	   fo_qc_integral, fo_realmoney_integral, fo_thiyetmoney_integral, fo_outmoney_integral, fo_otheronmoney_integral,fo_otheoutmoney_integral, fo_givemoney_integral, fo_qm_integral
	   ,fo_c_inlist_type --应收登记类型
	   ,fo_customer_balance --客户余额
       ,fo_order_id
	   ,fo_addman
	   ,fo_custom_remark
	   ,(case when fo_outmoney >0 then -fo_finished_money else fo_finished_money end)fo_finished_money
	   ,(case when fo_outmoney >0 then -fo_parts_money else fo_parts_money end)fo_parts_money
	   ,fo_queue_status
FROM   c_fundorder
       INNER JOIN b_clientinfo ON b_clientinfo.ci_id = c_fundorder.fo_ciid
UNION ALL
SELECT 
       (select cp_name from companyinfo where cp_id=fo_cp_id)set_cpname,
       (CASE WHEN fo_shid<>0 THEN pos_shop.sh_name ELSE ''  END)objectname,
       (CASE WHEN fo_shid<>0 THEN pos_shop.sh_no ELSE ''  END)objectcode,
	   c_fundorder.fo_erp_id,
	   c_fundorder.fo_id,
       c_fundorder.fo_type,
       c_fundorder.fo_ciid,
       c_fundorder.fo_shid,
       c_fundorder.fo_to_cpid,
       c_fundorder.fo_bs,
       c_fundorder.fo_orderid,
       c_fundorder.fo_takeman,
       c_fundorder.fo_ticketno,
       c_fundorder.fo_realmoney,
       c_fundorder.fo_thiyetmoney,
       c_fundorder.fo_ofdate,
       c_fundorder.fo_remark,
       c_fundorder.fo_lastman,
       c_fundorder.fo_status,
       c_fundorder.fo_outmoney,
       c_fundorder.fo_admoney,
       c_fundorder.fo_otheronmoney,
       c_fundorder.fo_otheoutmoney,
       c_fundorder.fo_givemoney,
       c_fundorder.fo_ensuremoney,
       c_fundorder.fo_subscription,
       c_fundorder.fo_no,
       c_fundorder.fo_addtime,
       c_fundorder.fo_updatetime,
       c_fundorder.fo_rowNum,
       '' AS ci_name,
       '' AS ci_no,
	   '' as ci_type,--客户分类
       pos_shop.sh_name AS sh_name,
       pos_shop.sh_no AS sh_no,
       '' AS cp_name,
       '' AS cp_code,
       c_fundorder.fo_cp_id,
	   fo_qc_integral, fo_realmoney_integral, fo_thiyetmoney_integral, fo_outmoney_integral, fo_otheronmoney_integral,fo_otheoutmoney_integral, fo_givemoney_integral, fo_qm_integral
	   ,fo_c_inlist_type --应收登记类型
	   ,fo_customer_balance --客户余额
       ,fo_order_id
	   ,fo_addman
	   ,fo_custom_remark
	   ,(case when fo_outmoney >0 then -fo_finished_money else fo_finished_money end)fo_finished_money
	   ,(case when fo_outmoney >0 then -fo_parts_money else fo_parts_money end)fo_parts_money
	   ,fo_queue_status
FROM   c_fundorder
	   INNER JOIN pos_shop ON pos_shop.sh_id =	c_fundorder.fo_shid
UNION ALL
SELECT  
       (select cp_name from companyinfo where cp_id=fo_cp_id)set_cpname,
       (CASE WHEN fo_to_cpid<>0 THEN companyinfo.cp_name ELSE ''  END)objectname,
       (CASE WHEN fo_to_cpid<>0 THEN companyinfo.cp_code ELSE ''  END)objectcode,
  c_fundorder.fo_erp_id,
 c_fundorder.fo_id,
       c_fundorder.fo_type,
       c_fundorder.fo_ciid,
       c_fundorder.fo_shid,
       c_fundorder.fo_to_cpid,
       c_fundorder.fo_bs,
       c_fundorder.fo_orderid,
       c_fundorder.fo_takeman,
       c_fundorder.fo_ticketno,
       c_fundorder.fo_realmoney,
       c_fundorder.fo_thiyetmoney,
       c_fundorder.fo_ofdate,
       c_fundorder.fo_remark,
       c_fundorder.fo_lastman,
       c_fundorder.fo_status,
       c_fundorder.fo_outmoney,
       c_fundorder.fo_admoney,
       c_fundorder.fo_otheronmoney,
       c_fundorder.fo_otheoutmoney,
       c_fundorder.fo_givemoney,
       c_fundorder.fo_ensuremoney,
       c_fundorder.fo_subscription,
       c_fundorder.fo_no,
       c_fundorder.fo_addtime,
       c_fundorder.fo_updatetime,
       c_fundorder.fo_rowNum,
       '' AS ci_name,
       '' AS ci_no,
	   '' as ci_type,--客户分类
       '' AS sh_name,
       '' AS sh_no,
       companyinfo.cp_name AS cp_name,
       companyinfo.cp_code AS cp_code,
       c_fundorder.fo_cp_id,
	  fo_qc_integral, fo_realmoney_integral, fo_thiyetmoney_integral, fo_outmoney_integral, fo_otheronmoney_integral,fo_otheoutmoney_integral, fo_givemoney_integral, fo_qm_integral
	   ,fo_c_inlist_type --应收登记类型
	   ,fo_customer_balance --客户余额
	   ,fo_order_id
	   ,fo_addman
	   ,fo_custom_remark
	   ,(case when fo_outmoney >0 then -fo_finished_money else fo_finished_money end)fo_finished_money
	   ,(case when fo_outmoney >0 then -fo_parts_money else fo_parts_money end)fo_parts_money
	   ,fo_queue_status
FROM   c_fundorder
	   INNER JOIN companyinfo ON companyinfo.cp_id = c_fundorder.fo_to_cpid
) as fun
LEFT JOIN j_outStorage AS jis WITH ( NOLOCK ) ON jis.oo_id =fun.fo_order_id
go

