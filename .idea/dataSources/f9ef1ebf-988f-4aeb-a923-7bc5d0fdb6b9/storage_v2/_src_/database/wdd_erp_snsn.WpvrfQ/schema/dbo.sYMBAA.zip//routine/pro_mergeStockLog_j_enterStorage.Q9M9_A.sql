
CREATE PROC [dbo].[pro_mergeStockLog_j_enterStorage]
@cp_id INT = 0,   
@negative_inventory INT=0,--产生了负库存是否提示
@old_sei_id INT=0,  
@new_sei_id INT=0,
@id INT=0
AS


EXEC pro_mergeStockLog_check 
	@cp_id = @cp_id,
	@negative_inventory = @negative_inventory,
	@old_sei_id = @old_sei_id, 
	@new_sei_id = @new_sei_id
IF @@ERROR!=0
BEGIN
	DECLARE @ERROR_MESSAGE VARCHAR(100)='';
	select @ERROR_MESSAGE=ERROR_MESSAGE();
	RAISERROR ( @ERROR_MESSAGE, 16, 1, N'number', 5 );
	RETURN;
END
ELSE
BEGIN
    BEGIN TRAN
    DECLARE @now DATETIME = GETDATE();
	update j_stocklog set sl_status = 0 where sl_cp_id = @cp_id and sl_eoid = @id and sl_type = 1

	INSERT j_stocklog( 
    sl_eoid,
	sl_elid ,
	sl_seiid ,
	sl_ciid ,
	sl_giid ,
	sl_skuid ,
	sl_type ,
	sl_counttype ,
	sl_number ,
	sl_addtime ,
	sl_updatetime ,
	sl_remark ,
	sl_status ,
	sl_order_no ,
	sl_order_date ,
	sl_order_add_time ,
	sl_cp_id ,
	sl_erp_id,
	sl_pm,
	sl_location
)
select 
	so.eoid ,
	so.elid ,
	so.[sid] ,
	so.cid ,
	so.gid ,
	so.skuid ,
	so.mytype ,
	so.countType ,
	so.gnum ,
	so.addtime ,
	@now ,
	so.myremark ,
	1 ,
	so.orderno ,
	so.order_date ,
	so.order_add_time ,
	so.cp_id ,
	so.erp_id,
	isnull(so.pm,''),
	so.lid 
from (
SELECT 
	je.eo_siid            AS sid,
	je.eo_ciid            AS cid,
	je2.el_locationid		 as lid,
	je2.el_siid           AS gid,
	je2.el_skuid          AS skuid,
	je2.el_number         AS gnum,
	isnull(je2.el_pm,'')             As pm ,
	countType = CASE 
WHEN je.eo_type = 0 THEN 1
ELSE 0
END,
myremark = CASE 
WHEN je.eo_type = 0 THEN '入库'
ELSE     '入库退货'
END,
	addtime = je2.el_addtime,
	orderno = je.eo_no,
	eoid = je.eo_id,
	elid = je2.el_id,
	mytype = 1,
	order_add_time = je.eo_addtime,
	order_date = je.eo_entrydate,
	je.eo_cp_id AS cp_id,
	je.eo_erp_id as erp_id
FROM   j_enterStorage je
INNER JOIN j_enterStorageList je2
ON  je.eo_id = je2.el_eoid
WHERE je.eo_id=@id AND je.eo_status=2
AND je2.el_status = 1
AND je2.el_siid>0
AND je.eo_siid>0

) as so

    --计算汇总库存
    EXEC pro_mergeStockSum_new @cp_id=@cp_id,@id=@id,@type=1
	 
	 --计算汇总仓位库存
	EXEC pro_mergeStocklocationSum_new @cp_id=@cp_id,@id=@id,@type=1

	--计算汇总批次库存
	exec pro_mergeStockBatchSum @id=@id,@stockType=1;

	delete j_stocklog where sl_status = 0 and sl_cp_id = @cp_id and sl_eoid = @id and sl_type = 1

    IF @@ERROR <> 0
    BEGIN
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
    END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0 COMMIT TRAN
    END
END
go

