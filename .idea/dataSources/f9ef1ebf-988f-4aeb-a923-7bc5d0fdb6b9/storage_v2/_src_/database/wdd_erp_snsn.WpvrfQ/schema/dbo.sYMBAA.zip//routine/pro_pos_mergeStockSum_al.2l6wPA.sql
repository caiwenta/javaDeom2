CREATE PROCEDURE [dbo].[pro_pos_mergeStockSum_al]
	@tsl_sh_id INT = 0,
	@id INT=0
AS
	BEGIN TRAN
	DECLARE @now DATETIME = GETDATE();
	MERGE INTO pos_stockInfo AS ta 
	USING (
		
		
	    --SELECT *
	    --FROM   vi_pos_stockSum AS so
	    --WHERE  so.shid = @tsl_sh_id
	    
	    --SELECT *
	    --FROM   vi_pos_stockSum_nolock AS so
	    --WHERE  so.shid = @tsl_sh_id
	    
	    SELECT shid,
       sid,
       gid,
       skuid,
       SUM(CASE WHEN sl.countType = 1 THEN sl.gnum ELSE - sl.gnum END) AS gnum
FROM   dbo.vi_pos_stockList_nolock AS sl WHERE sl.shid=@tsl_sh_id and sl.eoid=@id
GROUP BY
       shid,
       sid,
       gid,
       skuid
	    
	    
	) AS so 
	ON 
	ta.st_sh_id = so.shid AND 
	ta.st_st_id = so.[sid] AND 
	ta.st_gi_id = so.gid AND 
	ta.st_sku_id = so.skuid 

	WHEN matched THEN 
	UPDATE 
	SET ta.st_num = so.gnum,
		add_time=CASE WHEN ta.st_num!=so.gnum THEN
		@now ELSE add_time END
	WHEN NOT matched THEN
	INSERT 
	  (
	    st_sh_id,
	    st_st_id,
	    st_gi_id,
	    st_sku_id,
	    st_num,
	    add_time
	  )
	VALUES
	  (
	    so.shid,
	    so.[sid],
	    so.gid,
	    so.skuid,
	    so.gnum,
	    @now
	  )
	WHEN NOT matched BY source AND ta.st_sh_id=@tsl_sh_id 
	then UPDATE  SET ta.st_num = 0,add_time=CASE WHEN ta.st_num!=0 THEN @now ELSE add_time END;
	IF @@ERROR <> 0
	BEGIN
	    IF @@TRANCOUNT > 0 ROLLBACK TRAN
	END
	ELSE
	BEGIN
	    IF @@TRANCOUNT > 0 COMMIT TRAN
	END
go

