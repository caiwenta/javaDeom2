CREATE VIEW [dbo].[v_goodsinfo]
	AS 
SELECT
(select top 1 gc_name from s_goodsclass where gc_id=T.gi_type1) AS gi_typename1,
(select top 1 gc_name from s_goodsclass where gc_id=T.gi_type2) AS gi_typename2,
(select top 1 gc_name from s_goodsclass where gc_id=T.gi_type3) AS gi_typename3,
(select top 1 gc_name from s_goodsclass where gc_id=T.gi_type4) AS gi_typename4,
(SELECT si_name FROM dbo.b_stafftinfo WHERE si_id = t.gi_add_man) AS gi_add_manc,
(SELECT si_name FROM dbo.b_stafftinfo WHERE si_id = t.gi_update_man) AS gi_update_manc, 

(CASE WHEN (SELECT MIN(in_date)
			FROM pos_initStorage
			INNER JOIN pos_initStorageList 
			ON in_id = inl_in_id
			INNER JOIN pos_shop on sh_id=in_sh_id
			WHERE sh_erp_id=t.gi_erp_id AND inl_gi_id=t.gi_id AND inl_status = 1 and in_status>0) IS NOT NULL
      THEN (SELECT MIN(in_date)
			FROM pos_initStorage
			INNER JOIN pos_initStorageList 
			ON in_id = inl_in_id
			INNER JOIN pos_shop on sh_id=in_sh_id
			WHERE sh_erp_id=t.gi_erp_id AND inl_gi_id=t.gi_id AND inl_status = 1 and in_status>0)
      ELSE (SELECT MIN(in_date) 
			FROM pos_inStorage 
			LEFT JOIN pos_inStorageList 
			ON in_id=inl_in_id 
			WHERE in_erp_id=t.gi_erp_id AND inl_gi_id=t.gi_id AND in_status<>0 AND inl_status<>0)
      END) AS gi_shelvesdate, --上架时间（该商品，如果有期初库存，则算最早的期初日期，否则为，最早的店铺入库时间）

T.*, 
b.ut_name,
(select si_name from b_stafftinfo where si_id=gi_buyingteamid) as gi_buyingteam,
(select si_name from b_supplierinfo where si_id=gi_supplierid) as gi_supplier
FROM 
b_goodsinfo T 
LEFT JOIN b_unit b ON b.ut_id = T.gi_unit
go

