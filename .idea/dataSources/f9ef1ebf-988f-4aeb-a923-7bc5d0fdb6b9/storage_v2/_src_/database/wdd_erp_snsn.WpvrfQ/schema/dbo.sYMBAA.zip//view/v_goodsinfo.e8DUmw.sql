CREATE VIEW [dbo].[v_goodsinfo]
AS
    SELECT  ( SELECT TOP 1 gc_name FROM s_goodsclass WHERE gc_id= T.gi_type1
            ) AS gi_typename1 ,
            ( SELECT TOP 1 gc_name FROM s_goodsclass WHERE gc_id= T.gi_type2
            ) AS gi_typename2 ,
            ( SELECT TOP 1 gc_name FROM s_goodsclass WHERE gc_id= T.gi_type3
            ) AS gi_typename3 ,
            ( SELECT TOP 1 gc_name FROM s_goodsclass WHERE gc_id= T.gi_type4
            ) AS gi_typename4 ,
            ( SELECT si_name FROM dbo.b_stafftinfo WHERE si_id = t.gi_add_man
            ) AS gi_add_manc ,
            ( SELECT si_name FROM dbo.b_stafftinfo WHERE si_id = t.gi_update_man
            ) AS gi_update_manc ,
            ( CASE WHEN gi_status = 2 THEN ( SELECT si_name FROM dbo.b_stafftinfo WHERE si_id = t.gi_audit_man
                                           )
                   ELSE ''
              END ) AS gi_audit_manc ,
            ( CASE WHEN gi_status = 2 THEN gi_audit_time
                   ELSE NULL
              END ) AS gi_audittime ,
            ( CASE WHEN ( SELECT    MIN(inl_add_time)
                          FROM      pos_initStorageList 
                          WHERE     inl_gi_id = t.gi_id
                                    AND inl_status = 1
                        ) IS NOT NULL THEN ( SELECT MIN(inl_add_time)
                                             FROM   pos_initStorageList 
                                             WHERE  inl_gi_id = t.gi_id
                                                    AND inl_status = 1
                                           )
                   ELSE ( SELECT    MIN(inl_add_time)
                          FROM      pos_inStorageList 
                          WHERE     inl_gi_id = t.gi_id
                                    AND inl_status <> 0
                        )
              END ) AS gi_shelvesdate , --上架时间（该商品，如果有期初库存，则算最早的期初日期，否则为，最早的店铺入库时间）
            T.* ,
            b.ut_name ,
            ( SELECT si_name FROM b_stafftinfo WHERE si_id= gi_buyingteamid
            ) AS gi_buyingteam ,
            ( SELECT si_name FROM b_supplierinfo WHERE si_id= gi_supplierid
            ) AS gi_supplier,
			isnull((select SPBM from a_taxclassification where Id=isnull(gi_spbmid,0)),'')as SPBM 
    FROM    b_goodsinfo T
    LEFT JOIN b_unit b ON b.ut_id = T.gi_unit
go

