CREATE VIEW [dbo].[vi_pos_initStorage] AS 
SELECT
	in_id,
	in_sh_id,
	in_vo,
	CONVERT (VARCHAR(10), in_date, 120) AS in_date,
	in_no,
	in_st_id,
	in_st_id_txt = (
		SELECT
			psi.sei_name
		FROM
			pos_storageInfo AS psi WITH (NOLOCK)
		WHERE
			psi.sei_id = jis.in_st_id
	),
	in_sh_id_txt = (
		SELECT
			psi.sh_name
		FROM
			pos_shop AS psi WITH (NOLOCK)
		WHERE
			psi.sh_id = jis.in_sh_id
	),
	(
		SELECT
			bs.si_name
		FROM
			b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			bs.si_id = in_order_man
	) AS in_order_man_txt,
	in_order_man,
	(
		SELECT
			bs.si_name
		FROM
			b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			bs.si_id = in_add_man
	) AS in_add_man_txt,
	in_add_man,
	in_add_time,
	(
		SELECT
			bs.si_name
		FROM
			b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			bs.si_id = in_update_man
	) AS in_update_man_txt,
	in_update_man,
	in_update_time,
	(
		SELECT
			bs.si_name
		FROM
			b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			bs.si_id = in_audit_man
	) AS in_audit_man_txt,
	in_audit_man,
	in_audit_time,
	in_remark,
	in_status,
	(
		SELECT
			SUM (inl_num)
		FROM
			pos_initStorageList WITH (NOLOCK)
		WHERE
			jis.in_id = inl_in_id and inl_status<>0
	) AS sumnum,
	(
		SELECT
			SUM (inl_money)
		FROM
			pos_initStorageList WITH (NOLOCK)
		WHERE
			jis.in_id = inl_in_id and inl_status<>0
	) AS summoney
FROM
	pos_initStorage AS jis WITH (NOLOCK);
go

