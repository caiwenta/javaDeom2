CREATE  VIEW [dbo].[vi_j_outStorageList_group_goods_j_enterStorage] AS 
SELECT jt.ol_eoid,
       jt.ol_siid,
       jt.ol_number,
       jt.ol_id,
       jt.ol_realmoney,
       jt.ol_unit,
       jt.ol_costprice,
       jt.ol_discount,
       jt.ol_skuid,
       CONVERT(VARCHAR(100), jt.ol_addtime, 25) AS ol_addtime,
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
	   bg.gi_factoryprice,
       bg.gi_number,
       bg.gi_retailprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
	   bg.gi_sampleno,--样品号
       bu.ut_name                       AS gi_unit,
       ol_pm,
       ol_box_num,
       ISNULL(fd.el_number, 0)        AS ol_number_ed,
       (jt.ol_number -ISNULL(fd.el_number, 0)) AS ol_number_ding,
       (jt.ol_number -ISNULL(fd.el_number, 0)) AS ol_number_do
FROM   dbo.vi_j_outStorageList          AS jt
       INNER JOIN dbo.b_goodsinfo  AS bg
            ON  jt.ol_siid = bg.gi_id
       INNER JOIN dbo.b_unit       AS bu
            ON  bg.gi_unit = bu.ut_id
		LEFT JOIN (
		SELECT fd.eo_source_id,fd2.el_siid,fd2.el_source_add_time,SUM(fd2.el_number) AS el_number
  FROM j_enterStorage fd INNER JOIN j_enterStorageList fd2
ON fd.eo_id=fd2.el_eoid 
WHERE fd.eo_status>0 AND fd2.el_status>0
AND fd.eo_source_type=2 AND fd2.el_source_add_time>0
GROUP BY fd.eo_source_id,fd2.el_siid,fd2.el_source_add_time	
		) fd
		ON jt.ol_eoid=fd.eo_source_id
		AND jt.ol_siid=fd.el_siid
		AND jt.ol_addtime=fd.el_source_add_time
go

