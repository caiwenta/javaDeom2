


CREATE PROC [dbo].[pro_pos_moStorageList_sku_search_tb]
@mol_mo_id INT = 0,
@mol_add_time DATETIME = '2004-10-17',
@gi_id INT,
@sh_id INT,
@gss_no VARCHAR(30) = ''
AS

BEGIN
	IF @gss_no !='' 
	BEGIN
		SELECT @gi_id = bg.gi_id FROM b_goodsruleset bg WHERE bg.gss_no = @gss_no
	END

	SELECT * INTO #p
	FROM   b_goodsruleset AS bg
	       LEFT JOIN (
	                SELECT *
	                FROM   pos_moStorageList AS jisl
	                WHERE  jisl.mol_mo_id = @mol_mo_id
	                       AND jisl.mol_add_time = @mol_add_time
	                       AND jisl.mol_status = 1
	                       AND jisl.mol_gi_id = @gi_id
	            ) AS p1
	            ON  bg.gi_id = p1.mol_gi_id
	            AND bg.gss_id = p1.mol_sku_id
	WHERE  bg.gi_id = @gi_id ;


	declare @type int=1;--交易方式订货
	declare @returntable table(
			gi_id int,
			sku_id int,
			retailprice DECIMAL(9, 2),--零售价
			discount DECIMAL(9, 2),
			importprices DECIMAL(9, 2)    --供货价
	);

	INSERT @returntable
	SELECT
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
	FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,0,@sh_id,0,@type);


	update #p set
		        gs_salesprice= l.importprices,
				gs_purchase = l.importprices,
				gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id


	--吊牌价设置
	DECLARE @lsj       DECIMAL(9, 2) = 0;--零售价
	DECLARE @dpj_type  INT = 0;--吊牌价类型

	SELECT @dpj_type = ps.sh_goods_type
	FROM   pos_shop ps
	WHERE  ps.sh_id = @sh_id

	IF @dpj_type != 0
	BEGIN
	    SELECT @lsj = gd_price
	    FROM   b_goods_discount
	    WHERE  gd_type = @dpj_type
	           AND gd_class = 1 AND gd_gi_id = @gi_id
		--零售价
		UPDATE #p SET  gs_marketprice = @lsj
	END

	 UPDATE #p
	    SET   gs_discount = (
	               CASE 
	                    WHEN gs_marketprice = 0.00 THEN 0.00
	                    ELSE gs_purchase / gs_marketprice
	               END
	    )


	SELECT * FROM   #p





	--DECLARE @ghj       DECIMAL(9, 2) = 0;
	--DECLARE @lsj       DECIMAL(9, 2) = 0;
	--DECLARE @ghj_type  INT = 0;
	--DECLARE @dpj_type  INT = 0;
	--declare @discount DECIMAL(9, 2) = 1;
	--SELECT @ghj_type = ps.sh_dhprice,@discount=sh_dhdiscount
	--FROM   pos_shop ps
	--WHERE  ps.sh_id = @sh_id
	--AND sh_id=@sh_id
	--SELECT @dpj_type = ps.sh_goods_type
	--FROM   pos_shop ps
	--WHERE  ps.sh_id = @sh_id
	--AND sh_id=@sh_id
	--IF @dpj_type != 0
	--BEGIN
	--    SELECT @lsj = gd_price
	--    FROM   b_goods_discount
	--    WHERE  gd_type = @dpj_type
	--           AND gd_class = 1 AND gd_gi_id = @gi_id
	--END
	--IF @dpj_type = 0 OR @lsj = 0 
	--BEGIN
	--    SELECT @lsj = bg.gi_retailprice
	--    FROM   b_goodsinfo bg
	--    WHERE  bg.gi_id = @gi_id
	    
	--END
	--SELECT @ghj = gd_price
	--FROM   b_goods_discount
	--WHERE  gd_gi_id = @gi_id
	--       AND gd_class = 2
	--       AND gd_type = @ghj_type
	----零售价
	--UPDATE #p
	--SET    gs_marketprice = @lsj
	--IF @ghj > 0.00
	--BEGIN
	--    --更细供货价
	--    UPDATE #p
	--    SET    gs_purchase = @ghj*@discount
	    
	--    --更新折扣价
	--    UPDATE #p
	--    SET    gs_discount = (
	--               CASE 
	--                    WHEN gs_marketprice = 0.00 THEN 0.00
	--                    ELSE gs_purchase / gs_marketprice
	--               END
	--           )
	--END
	--ELSE
	--BEGIN
	--    UPDATE #p
	--    SET    gs_purchase = @lsj
	    
	--    UPDATE #p
	--    SET    gs_discount = 1
	--END
	

END
go

