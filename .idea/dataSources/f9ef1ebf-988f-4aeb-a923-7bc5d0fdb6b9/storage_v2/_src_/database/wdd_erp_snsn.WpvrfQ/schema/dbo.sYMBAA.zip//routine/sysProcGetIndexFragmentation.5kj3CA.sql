CREATE PROCEDURE [dbo].[sysProcGetIndexFragmentation]
    @dbName VARCHAR(50) ,
    @ixName VARCHAR(50)
AS
    BEGIN
		-- =============================================
		-- Author:		如何知道是否发生了索引碎片
		-- Create date: <2015-10-15>
		-- =============================================

		--如何知道是否发生了索引碎片

        SELECT  OBJECT_NAME(dt.object_id) Tablename ,
                si.name IndexName ,
                dt.avg_fragmentation_in_percent AS ExternalFragmentation ,
                dt.avg_page_space_used_in_percent AS InternalFragmentation
        FROM    ( SELECT    object_id ,
                            index_id ,
                            avg_fragmentation_in_percent ,
                            avg_page_space_used_in_percent
                  FROM      sys.dm_db_index_physical_stats(DB_ID(@dbName),
                                                           NULL, NULL, NULL,
                                                           'DETAILED')
                  WHERE     index_id <> 0
                ) AS dt
                INNER JOIN sys.indexes si ON si.object_id = dt.object_id
                                             AND si.index_id = dt.index_id
                                             AND dt.avg_fragmentation_in_percent > 10
                                             AND dt.avg_page_space_used_in_percent < 75
                                             AND name = @ixName
        ORDER BY avg_fragmentation_in_percent DESC

		--索引碎片信息

		--使用下面的规则分析结果 你就可以找出哪里发生了索引碎片

		--1)ExternalFragmentation的值>10表示对应的索引发生了外部碎片;

		--2)InternalFragmentation的值<75表示对应的索引发生了内部碎片

		--如何整理索引碎片

		--有两种整理索引碎片的方法

		--1)重组有碎片的索引执行下面的命令

        --ALTER INDEX ALL ON TableName REORGANIZE

		--2)重建索引执行下面的命令

        --ALTER INDEX ALL ON TableName REBUILD 

		--也可以使用索引名代替这里的ALL关键字重组或重建单个索引  也可以使用SQL Server管理工作台进行索引碎片的整理
    END
go

