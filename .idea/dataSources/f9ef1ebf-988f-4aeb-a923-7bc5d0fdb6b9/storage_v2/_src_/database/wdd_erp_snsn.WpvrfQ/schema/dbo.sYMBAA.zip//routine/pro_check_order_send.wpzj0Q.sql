CREATE  PROC [dbo].[pro_check_order_send]
    @ord_id INT ,
    @operation VARCHAR(50) = 'send' , --'send'发货，'refund'退换货
    @resultInt INT = 0 OUT ,
    @resultVar VARCHAR(50) = '' OUT
AS
    BEGIN
		--验证网络是否可以发货
        DECLARE @erp_id INT= 0; --企业ID
        DECLARE @ord_sn VARCHAR(50)= ''; --ERP订单号
        DECLARE @type VARCHAR(50)= ''; --发货方或销售方类型
        DECLARE @erp_sid INT= 0; --发货方或销售方ID        
        DECLARE @sei_id INT= 0; --仓库ID
        DECLARE @sei_is_negative_inventory INT= 0; --是否允许仓库负库存
        DECLARE @tsl_date VARCHAR(50)= CONVERT(VARCHAR(50), GETDATE(), 23);
        DECLARE @m_year INT= 0;
        DECLARE @m_month INT= 0;
        DECLARE @y INT= 0;
        DECLARE @m INT= 0;
        DECLARE @y_var VARCHAR(50);
        DECLARE @m_var VARCHAR(50);
        DECLARE @y_var_ VARCHAR(50);
        DECLARE @m_var_ VARCHAR(50);
        --订单信息
        SELECT  @type = CASE WHEN @operation = 'refund' AND ord_sendtype = 'store' THEN ord_saletype
                             ELSE ord_sendtype
                        END ,
                @erp_sid = CASE WHEN @operation = 'refund' AND ord_sendtype = 'store' THEN ord_sale_erp_sid
                                ELSE ord_send_erp_sid
                           END ,
                @ord_sn = ord_sn ,
                @erp_id = ord_erp_id
        FROM    netorder_tbl
        WHERE   ord_id = @ord_id;
        --订单商品信息
        SELECT  nog_goodscode ,
                nog_skucode ,
                nog_skuname
        INTO    #tpg
        FROM    netordergoods_tbl WITH ( NOLOCK )
        WHERE   ord_sn = @ord_sn
        --检查商品资料                                            
        IF ( SELECT COUNT(1)
             FROM   b_goodsinfo WITH ( NOLOCK )
             WHERE  gi_erp_id = @erp_id
                    AND gi_status > 0
                    AND gi_code IN ( SELECT DISTINCT
                                            nog_goodscode
                                     FROM   #tpg fd )
           ) <> ( SELECT    COUNT(DISTINCT nog_goodscode) AS COUNT
                  FROM      #tpg
                )
            BEGIN
                SET @resultInt = -4;
                SET @resultVar = '商品资料不全,请检查!'
                SELECT  '商品资料不全,请检查!'
                RETURN;
            END
        --检查规格资料
        IF ( SELECT COUNT(1)
             FROM   b_goodsruleset WITH ( NOLOCK )
             WHERE  gss_erp_id = @erp_id
                    AND gs_status > 0
                    AND gss_no IN ( SELECT DISTINCT
                                            nog_skucode
                                    FROM    #tpg
                                    WHERE   nog_skuname <> '' )
           ) <> ( SELECT    COUNT(DISTINCT nog_skucode)
                  FROM      #tpg
                  WHERE     nog_skuname <> ''
                )
            BEGIN
                SET @resultInt = -5;
                SET @resultVar = '规格资料不全,请检查!'
                SELECT  '规格资料不全,请检查!'
                RETURN;
            END
        --商品编号、条形码不匹配                         
        IF ( SELECT COUNT(1)
             FROM   b_goodsruleset
             WHERE  gi_id IN ( SELECT   gi_id
                               FROM     b_goodsinfo WITH ( NOLOCK )
                               WHERE    gi_erp_id = @erp_id
                                        AND gi_status > 0
                                        AND gi_code IN ( SELECT nog_goodscode
                                                         FROM   #tpg ) )
                    AND gss_no IN ( SELECT DISTINCT
                                            nog_skucode
                                    FROM    #tpg
                                    WHERE   nog_skuname <> '' )
           ) <> ( SELECT    COUNT(DISTINCT nog_skucode)
                  FROM      #tpg
                  WHERE     nog_skuname <> ''
                )
            BEGIN
                SET @resultInt = -6;
                SET @resultVar = '商品编号、条形码不匹配!'
                SELECT  '商品编号、条形码不匹配!'
                RETURN;
            END
		--仓库ID
        IF @type = 'store'
            BEGIN
                SELECT TOP 1
                        @sei_id = sei_id ,
                        @sei_is_negative_inventory = sei_is_negative_inventory
                FROM    pos_storageInfo
                WHERE   sei_sh_id = @erp_sid
                        AND sei_is_net = 1
            END
        ELSE
            BEGIN
                SELECT TOP 1
                        @sei_id = sei_id ,
                        @sei_is_negative_inventory = sei_is_negative_inventory
                FROM    b_storageinfo
                WHERE   sei_cp_id = @erp_sid
                        AND sei_is_net = 1
            END

        IF @sei_id = 0
            BEGIN
                SET @resultInt = -7;
                SET @resultVar = '发货失败,未设置网络仓库!'
                SELECT  '发货失败,未设置网络仓库!'
                RETURN;
            END

        IF @sei_is_negative_inventory = 1
            BEGIN
                PRINT '允许负库存'
            END
        ELSE
            BEGIN
                IF @type = 'store'
                    BEGIN	
                        IF EXISTS ( SELECT  1
                                    FROM    ( SELECT    gi.gi_id ,
                                                        ISNULL(gss.gss_id, 0) gss_id ,
                                                        SUM(CASE WHEN @operation = 'refund' THEN nog.nog_refund_num
                                                                 ELSE nog.nog_buynumber
                                                            END) AS nog_num
                                              FROM      netordergoods_tbl nog
                                                        INNER JOIN b_goodsinfo gi ON nog.nog_goodscode = gi.gi_code and [gi_status] >0
                                                                                     AND gi.gi_erp_id = @erp_id
                                                        LEFT JOIN b_goodsruleset gss ON gi.gi_id = gss.gi_id and gss.gs_status>0
                                                                                        AND nog.nog_skucode = gss.gss_no
                                                                                        AND gss.gss_erp_id = @erp_id
                                              WHERE     nog.ord_sn = @ord_sn
                                              GROUP BY  gi.gi_id ,
                                                        gss.gss_id
                                            ) AS gi
                                            LEFT JOIN pos_stockInfo si ON gi.gi_id = si.st_gi_id
                                                                          AND gi.gss_id = si.st_sku_id
                                                                          AND si.st_st_id = @sei_id
                                    WHERE   ( ISNULL(si.st_num, 0) - gi.nog_num ) < 0 )
                            BEGIN
                                SET @resultInt = -1;
                                SET @resultVar = '发货失败，不允许负库存';
                                SELECT  '发货失败，不允许负库存'
                                RETURN;
                            END
                    END
                ELSE
                    BEGIN	
                        IF EXISTS ( SELECT  1
                                    FROM    ( SELECT    gi.gi_id ,
                                                        ISNULL(gss.gss_id, 0) gss_id ,
                                                        SUM(CASE WHEN @operation = 'refund' THEN nog.nog_refund_num
                                                                 ELSE nog.nog_buynumber
                                                            END) AS nog_num
                                              FROM      netordergoods_tbl nog
                                                        INNER JOIN b_goodsinfo gi ON nog.nog_goodscode = gi.gi_code and [gi_status] >0
                                                                                     AND gi.gi_erp_id = @erp_id
                                                        LEFT JOIN b_goodsruleset gss ON gi.gi_id = gss.gi_id and gss.gs_status>0
                                                                                        AND nog.nog_skucode = gss.gss_no
                                                                                        AND gss.gss_erp_id = @erp_id
                                              WHERE     nog.ord_sn = @ord_sn
                                              GROUP BY  gi.gi_id ,
                                                        gss.gss_id
                                            ) AS gi
                                            LEFT JOIN b_stockinfo si ON gi.gi_id = si.si_giid and si.si_status>0
                                                                        AND gi.gss_id = si.si_skuid
                                                                        AND si.si_seiid = @sei_id
                                    WHERE   ( ISNULL(si.si_number, 0) - gi.nog_num ) < 0 )
                            BEGIN
                                SET @resultInt = -1;
                                SET @resultVar = '发货失败，不允许负库存';
                                SELECT  '发货失败，不允许负库存'
                                RETURN;
                            END	
                    END
            END
		--是否正在盘点，或已生成报表
        IF @type = 'store'
            BEGIN
                IF EXISTS ( SELECT  tsl_st_id ,
                                    tsl_date
                            FROM    vi_pos_takeStorage_record
                            WHERE   tsl_st_id = @sei_id
                                    AND tsl_date >= @tsl_date )
                    BEGIN
                        SET @resultInt = -2;
                        SET @resultVar = '发货失败，盘点库存锁定';
                        SELECT  '发货失败，盘点库存锁定';
                        RETURN;
                    END	

                SELECT  @m_year = MAX(m_year) ,
                        @m_month = MAX(m_month)
                FROM    pos_month_report
                WHERE   shid = @erp_sid;

                IF ISNULL(@m_year, 0) > 0
                    BEGIN
                        SELECT  @y = DATEPART(YEAR, @tsl_date);
                        SELECT  @m = DATEPART(MONTH, @tsl_date);

                        SET @y_var = CONVERT(VARCHAR(50), @y);
                        SET @m_var = CONVERT(VARCHAR(50), @m);
                        
                        IF LEN(@m_var) = 1
                            BEGIN
                                SET @m_var = '0' + @m_var;
                            END

                        SET @y_var_ = CONVERT(VARCHAR(50), @m_year);
                        SET @m_var_ = CONVERT(VARCHAR(50), @m_month);
                        
                        IF LEN(@m_var_) = 1
                            BEGIN
                                SET @m_var_ = '0' + @m_var_;
                            END

                        IF ( CONVERT(INT, CONVERT(VARCHAR(50), @y_var) + CONVERT(VARCHAR(50), @m_var)) ) <= ( CONVERT(INT, CONVERT(VARCHAR(50), @y_var_)
                                                                                                              + CONVERT(VARCHAR(50), @m_var_)) )
                            BEGIN
                                SET @resultInt = -3;
                                SET @resultVar = '发货失败，月报表锁定'
                                SELECT  '发货失败，月报表锁定'
                                RETURN;
                            END
                    END
            END
        ELSE
            BEGIN
                IF EXISTS ( SELECT  tsl_st_id ,
                                    tsl_date
                            FROM    vi_j_takeStorage_record
                            WHERE   tsl_st_id = @sei_id
                                    AND tsl_date >= @tsl_date )
                    BEGIN
                        SET @resultInt = -2;
                        SET @resultVar = '发货失败，盘点库存锁定';
                        SELECT  '发货失败，盘点库存锁定';
                        RETURN;
                    END	

                SELECT  @m_year = MAX(m_year) ,
                        @m_month = MAX(m_month)
                FROM    j_month_report
                WHERE   company_id = @erp_sid
                        AND reporttype = 0;

                IF ISNULL(@m_year, 0) > 0
                    BEGIN
                        SELECT  @y = DATEPART(YEAR, @tsl_date);
                        SELECT  @m = DATEPART(MONTH, @tsl_date);

                        SET @y_var = CONVERT(VARCHAR(50), @y);
                        SET @m_var = CONVERT(VARCHAR(50), @m);
                        
                        IF LEN(@m_var) = 1
                            BEGIN
                                SET @m_var = '0' + @m_var;
                            END

                        SET @y_var_ = CONVERT(VARCHAR(50), @m_year);
                        SET @m_var_ = CONVERT(VARCHAR(50), @m_month);
                        
                        IF LEN(@m_var_) = 1
                            BEGIN
                                SET @m_var_ = '0' + @m_var_;
                            END

                        IF ( CONVERT(INT, CONVERT(VARCHAR(50), @y_var) + CONVERT(VARCHAR(50), @m_var)) ) <= ( CONVERT(INT, CONVERT(VARCHAR(50), @y_var_)
                                                                                                              + CONVERT(VARCHAR(50), @m_var_)) )
                            BEGIN
                                SET @resultInt = -3;
                                SET @resultVar = '发货失败，月报表锁定'
                                SELECT  '发货失败，月报表锁定'
                                RETURN;
                            END
                    END
            END
    END
go

