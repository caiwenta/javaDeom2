
	
CREATE Proc [dbo].[pro_update_unique_time]
@id INT=0,
@type VARCHAR(50)=''
AS
DECLARE @t2out DATETIME=GETDATE();
IF @type='采购'
BEGIN
			--更新统一的添加时间
	    	DECLARE @sopcor_pll_gi_id INT=0;
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.pll_gi_id
				FROM j_purchaseStorageList fd WITH (NOLOCK) WHERE fd.pll_pl_id=@id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @sopcor_pll_gi_id
					WHILE @@FETCH_STATUS =0
					BEGIN
						
					EXEC pro_get_rand_time
	@t1 = @t2out,
	@t2out = @t2out OUT
	
					UPDATE j_purchaseStorageList
					SET pll_add_time =@t2out
					WHERE pll_pl_id=@id 
					AND pll_gi_id=@sopcor_pll_gi_id 
					
		
					 

					FETCH NEXT FROM sopcor_update_add_time 
					INTO @sopcor_pll_gi_id
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time
END
ELSE IF @type='入库'
BEGIN
	
			--更新统一的添加时间
	    	DECLARE @sopcor_el_siid INT=0;	
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.el_siid
				FROM j_enterStorageList fd WITH (NOLOCK)  WHERE fd.el_eoid=@id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @sopcor_el_siid
					WHILE @@FETCH_STATUS =0
					BEGIN
						
						EXEC pro_get_rand_time
	@t1 = @t2out,
	@t2out = @t2out OUT
	
					UPDATE j_enterStorageList
					SET el_addtime = @t2out
					WHERE el_eoid=@id 
					AND el_siid=@sopcor_el_siid 
					
					 
					
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @sopcor_el_siid
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time
			
END
ELSE IF @type='出库'
BEGIN
			--更新统一的添加时间
	    	DECLARE @sopcor_ol_siid INT=0;
			DECLARE @sopcor_ol_source_add_time DATETIME;	
			DECLARE @gift int=0;

			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.ol_siid,fd.ol_source_add_time ,fd.ol_gift
				FROM j_outStorageList  fd WITH (NOLOCK)  WHERE fd.ol_eoid=@id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @sopcor_ol_siid,@sopcor_ol_source_add_time,@gift
					WHILE @@FETCH_STATUS =0
					BEGIN
						
					EXEC pro_get_rand_time
	@t1 = @t2out,
	@t2out = @t2out OUT	
					UPDATE j_outStorageList
					SET ol_addtime =@t2out
					WHERE ol_eoid=@id 
					AND ol_siid=@sopcor_ol_siid 
					AND isnull(ol_source_add_time,'')=isnull(@sopcor_ol_source_add_time,'')
					and ol_gift=@gift
					 
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @sopcor_ol_siid,@sopcor_ol_source_add_time,@gift
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time
	
END
ELSE IF @type='pos盘点'
BEGIN
			--更新统一的添加时间
	    	DECLARE @sopcor_pos_tsl_gi_id INT=0;
	    		
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.tsl_gi_id
				FROM pos_takeStorageList  fd WITH (NOLOCK)  WHERE fd.tsl_ts_id=@id and tsl_sku_id>0
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @sopcor_pos_tsl_gi_id
					WHILE @@FETCH_STATUS =0
					BEGIN
						
					EXEC pro_get_rand_time
	@t1 = @t2out,
	@t2out = @t2out OUT	
					UPDATE pos_takeStorageList
					SET tsl_add_time =@t2out
					WHERE tsl_ts_id=@id and tsl_sku_id>0
					AND tsl_gi_id=@sopcor_pos_tsl_gi_id 
					
					 
					
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @sopcor_pos_tsl_gi_id
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time
	
END
ELSE IF @type='盘点'
BEGIN
			--更新统一的添加时间
	    	DECLARE @sopcor_tsl_gi_id INT=0;
	    		
	    		
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.tsl_gi_id
				FROM j_takeStorageList  fd WITH (NOLOCK)  WHERE fd.tsl_ts_id=@id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @sopcor_tsl_gi_id
					WHILE @@FETCH_STATUS =0
					BEGIN
						
					EXEC pro_get_rand_time
	@t1 = @t2out,
	@t2out = @t2out OUT	
					UPDATE j_takeStorageList
					SET tsl_add_time =@t2out
					WHERE tsl_ts_id=@id 
					AND tsl_gi_id=@sopcor_tsl_gi_id 
					
					 
					
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @sopcor_tsl_gi_id
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time
	
END
ELSE IF @type='期初'
BEGIN
			--更新统一的添加时间
	    	DECLARE @sopcor_inl_gi_id INT=0;
	    		
	    		
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.inl_gi_id
				FROM j_initStorageList  fd WITH (NOLOCK)  WHERE fd.inl_in_id=@id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @sopcor_inl_gi_id
					WHILE @@FETCH_STATUS =0
					BEGIN
						
					EXEC pro_get_rand_time
	@t1 = @t2out,
	@t2out = @t2out OUT	
					UPDATE j_initStorageList
					SET inl_add_time =@t2out
					WHERE inl_in_id=@id 
					AND inl_gi_id=@sopcor_inl_gi_id 
					
					 
					
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @sopcor_inl_gi_id
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time
	
END
else if @type='配货'
begin
			--更新统一的添加时间
	    	DECLARE @sopcor_all_gi_id INT=0;
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.all_gi_id
				FROM pos_allocationList fd WITH (NOLOCK) WHERE fd.all_al_id=@id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @sopcor_all_gi_id
					WHILE @@FETCH_STATUS =0
					BEGIN
						
					EXEC pro_get_rand_time
					@t1 = @t2out,
					@t2out = @t2out OUT
	
					UPDATE pos_allocationList
					SET all_add_time =@t2out
					WHERE all_al_id=@id 
					AND all_gi_id=@sopcor_all_gi_id
					
		
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @sopcor_all_gi_id
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time

end
else if @type='pos入库'
begin

  	--更新统一的添加时间
	    	DECLARE @inl_gi_id INT=0;	
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.inl_gi_id
				FROM pos_inStoragelist fd WITH (NOLOCK)  WHERE fd.inl_in_id=@id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @inl_gi_id
					WHILE @@FETCH_STATUS =0
					BEGIN
					
						
				    EXEC pro_get_rand_time
					@t1 = @t2out,
					@t2out = @t2out OUT
	
					UPDATE pos_inStoragelist
					SET inl_add_time = @t2out
					WHERE inl_in_id=@id 
					AND inl_gi_id=@inl_gi_id 
					
					 
					
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @inl_gi_id
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time


end
else if  @type='盈亏'
begin

  	--更新统一的添加时间
	    	DECLARE @ppl_gi_id INT=0;	
			DECLARE sopcor_update_add_time CURSOR FOR(
				SELECT DISTINCT fd.ppl_gi_id
				FROM j_plStorageList fd WITH (NOLOCK)  WHERE fd.ppl_pl_id=@id
			)
			OPEN sopcor_update_add_time
			FETCH NEXT FROM sopcor_update_add_time 
			INTO @ppl_gi_id
					WHILE @@FETCH_STATUS =0
					BEGIN
					
						
				    EXEC pro_get_rand_time
					@t1 = @t2out,
					@t2out = @t2out OUT
	
					UPDATE j_plStorageList
					SET ppl_add_time = @t2out
					WHERE ppl_pl_id=@id 
					AND ppl_gi_id=@ppl_gi_id
					
					 
					
					FETCH NEXT FROM sopcor_update_add_time 
					INTO @ppl_gi_id
					End
			CLOSE sopcor_update_add_time
			DEALLOCATE sopcor_update_add_time

end
else if @type='pos补货'
begin


UPDATE pos_reStorageList SET rel_add_time=gh.rel_add_time  FROM pos_reStorageList AS prl
INNER JOIN (

SELECT rel_re_id,rel_gi_id,rel_add_time FROM (
SELECT 
ROW_NUMBER() over(partition BY rel_gi_id order by rel_add_time desc) as rn,
prsl.rel_re_id,prsl.rel_gi_id,prsl.rel_add_time
FROM pos_reStorageList AS prsl WHERE prsl.rel_re_id=@id
) th where rn=1

) gh ON prl.rel_re_id=@id and prl.rel_gi_id=gh.rel_gi_id AND prl.rel_add_time<>gh.rel_add_time


end
go

