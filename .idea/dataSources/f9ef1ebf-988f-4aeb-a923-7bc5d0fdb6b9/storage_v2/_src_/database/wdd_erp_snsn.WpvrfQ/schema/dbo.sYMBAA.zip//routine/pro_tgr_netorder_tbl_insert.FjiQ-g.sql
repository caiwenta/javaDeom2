create PROC [dbo].[pro_tgr_netorder_tbl_insert]
@ord_id INT
AS
SET NOCOUNT ON 
/*
插入时，判断一下当前子单号是否已经存在，如果存在，则作废之前相同子单号的订单
*/
--declare @ord_id INT;

declare @ord_sn varchar(255),@ord_no varchar(255),@ord_sno varchar(255)

select @ord_id=ord_id,@ord_sn=ord_sn,@ord_no=ord_no,@ord_sno=ord_sno from netorder_tbl
WHERE ord_id=@ord_id;

UPDATE [netorder_tbl] set ord_status=-2,ord_log='触发器作废相同子单:'+@ord_sno,ord_canceltime=getdate(),ord_updatime=getdate()
WHERE ord_id<>@ord_id and ord_sno=@ord_sno and ord_status in(0,2)


SET NOCOUNT OFF
go

