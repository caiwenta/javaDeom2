


CREATE PROC [dbo].[pro_take_list_sku_search_tb]
  @gi_id INT = 259,
  @sei_id INT = 19,
  @date VARCHAR(50) = '2004-9-10',
  @add_time DATETIME = '2004-9-10 11:56:14',
  @Ikdl varchar(100)='',
  @ts_id INT = 0,
  @tsl_pm varchar(50)=''
AS







if(@Ikdl='' OR @Ikdl IS NULL)
begin


SELECT bg.*,
       jt.*,
       js.stock_num,bg2.gi_name,bg2.gi_code
FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT js.sl_giid,
                       js.sl_skuid,
                       SUM(
                           CASE 
                                WHEN js.sl_counttype = 1 THEN js.sl_number
                                ELSE -js.sl_number
                           END
                       ) AS stock_num,
					   isnull(js.sl_pm,'') as sl_pm
                FROM   j_stocklog AS js
                WHERE  js.sl_seiid = @sei_id
                       AND js.sl_giid = @gi_id
					   AND isnull(js.sl_pm,'')=@tsl_pm
                       AND ((CONVERT(VARCHAR(50), js.sl_order_date, 23)<= @date) OR js.sl_type = 3)
                       AND js.sl_status != 0
                GROUP BY
                       js.sl_giid,
                       js.sl_skuid,
					   isnull(js.sl_pm,'')
            )          AS js
            ON  bg.gi_id = js.sl_giid
            AND bg.gss_id = js.sl_skuid
         LEFT JOIN (

SELECT
min(tsl_id)  as tsl_id,
tsl_ts_id,
tsl_gi_id,
tsl_sku_id,
tsl_add_time,
cast(AVG(tsl_discount) as decimal(9,2)) AS tsl_discount,
cast(AVG(tsl_retail_price) AS  decimal(9,2))AS tsl_retail_price, 
sum(tsl_old_num)       as tsl_old_num,
sum(tsl_new_num)       as tsl_new_num,
sum(tsl_log_num)       as tsl_log_num,
cast(avg(tsl_stock_price) as decimal(9,2)) as tsl_stock_price,
sum(tsl_old_money) as tsl_old_money,
sum(tsl_new_money) as tsl_new_money,
sum(tsl_log_money) as tsl_log_money,
max(ISNULL(tsl_pm,'')) as tsl_pm,
max(tsl_pddate) as tsl_pddate,
max(tsl_shelflife) as tsl_shelflife,
max(tsl_expirationdate) as tsl_expirationdate,
max(tsl_box_num) as  tsl_box_num
FROM   j_takeStorageList AS jt
WHERE  jt.tsl_ts_id = @ts_id
AND jt.tsl_add_time = @add_time
GROUP BY jt.tsl_ts_id,jt.tsl_gi_id,tsl_sku_id,tsl_add_time,ISNULL(tsl_pm,'')

                --SELECT *
                --FROM   j_takeStorageList AS jt
                --WHERE  jt.tsl_ts_id = @ts_id
                --       AND jt.tsl_add_time = @add_time




            )          AS jt ON  bg.gi_id = jt.tsl_gi_id
            AND bg.gss_id = jt.tsl_sku_id 
			LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id 
end
else
begin
select *,(case when kc.gnum=0 then '' else kc.gnum end) as stock_num from b_goodsruleset et left join( select * from j_takeStorageList js inner join 
j_takeStorage ge on ge.ts_id=js.tsl_ts_id where 
js.tsl_status != 0) te on et.gi_id=te.tsl_gi_id and et.gss_id=te.tsl_sku_id left join (
select [sid],sei_name,gid,gi_name,gi_code 
 ,skuid,(CASE WHEN gss_no IS null THEN gi_code ELSE gss_no END) as gss_no
  ,sum(gnum) as gnum from vi_stockSumList where [sid]=@sei_id
  group by sid,sei_name,gid,gi_name,gi_code,gi_costprice,gi_seiid,gi_seiname,gi_skuid,skuid,gss_no
) kc on et.gi_id=kc.gid and et.gss_id=kc.skuid
     where et.gi_id=@gi_id and  te.ts_st_id = @sei_id and te.tsl_ts_id=@ts_id 
	 
	 
	 
	  -- and   te.ts_add_time=@add_time 
end
go

