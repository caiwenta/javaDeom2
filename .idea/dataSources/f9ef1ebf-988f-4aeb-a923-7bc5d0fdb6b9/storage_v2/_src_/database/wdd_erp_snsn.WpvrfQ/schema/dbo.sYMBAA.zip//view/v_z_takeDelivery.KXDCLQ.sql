CREATE VIEW [dbo].[v_z_takeDelivery]
	AS 

--退货收货
SELECT 

oo_entrydate as sourcedate,
oo_id as sourceid , oo_siid,in_id,in_sh_id,si_companyid,in_vo,in_date,intype,(CASE WHEN intype=0 THEN '分公司退货' 
                                 WHEN intype=1 THEN '店铺退货'
                                 WHEN intype=2 THEN '客户退货通知' END)comefrom,
       (CASE WHEN sh_no<>'' THEN sh_no ELSE supplier_ci_no end)objectcode,
       (CASE WHEN in_supplier_sh_id_txt<>'' THEN in_supplier_sh_id_txt ELSE supplier_ci_name END)objectname,
       sumnum,var_num,oo_num,(sumnum-var_num)optnum,
       (CASE WHEN isnull(in_is_audit,0)=0 THEN '未收货' WHEN isnull(in_is_audit,0)=1 THEN '已收货' END)status,
       oo_no,''in_source_id,summoney,
       (CASE WHEN isnull(in_is_audit,0)=0 THEN hq_seiid WHEN isnull(in_is_audit,0)=1 THEN oo_siid END)hq_seiid,
       (CASE WHEN isnull(in_is_audit,0)=0 THEN hq_seiname WHEN isnull(in_is_audit,0)=1 THEN (SELECT sei_name FROM b_storageinfo WHERE sei_id=oo_siid) END)hq_seiname,
       in_remark,0 oo_jytype,in_audit_time,in_add_man
FROM v_z_returngoodsaudit
WHERE in_status=2

 UNION ALL 

--在途收货
SELECT 

eo_entrydate as sourcedate,
in_source_id as sourceid,eo_siid,oo_id,oo_ciid in_sh_id,oo_to_cp_id,oo_no,oo_entrydate,oo_type,(CASE WHEN (SELECT cp_is_zorf
                                         FROM dbo.companyinfo 
                                         WHERE cp_erp_id =oo_erp_id AND cp_id=oo_cp_id)=1 THEN '总公司出库'
                                   WHEN (SELECT cp_is_zorf
                                         FROM dbo.companyinfo 
                                         WHERE cp_erp_id =oo_erp_id AND cp_id=oo_cp_id)=2 THEN '分公司出库' END)comefrom,
       in_supplier_code_txt,in_supplier_id_txt,oo_num,var_num,ennum,(oo_num-var_num)optnum,
       (CASE WHEN ennum='' OR ennum=0 THEN '未收货' ELSE '已收货' END)status,
       in_source_vo,in_source_id,oo_realmoney,
       (CASE WHEN ennum='' OR ennum=0 THEN 0 ELSE eo_siid END) hq_seiid,
       (CASE WHEN ennum='' OR ennum=0 THEN '' ELSE (SELECT sei_name FROM b_storageinfo WHERE sei_id=eo_siid) END)hq_seiname,
       oo_remark,oo_jytype,oo_auditdate,oo_addman_txt
FROM vi_j_outStoragebycompany 
WHERE oo_status = 2 and oo_source_type in(0,1) and oo_status>0

 UNION ALL 

--区域移仓（移入）
SELECT
mo_source_date as sourcedate,
 mo_source_id as sourceid,mo_source_in_st_id,mo_id,0 in_sh_id,mo_cp_id,mo_vo,mo_date,-1 intype,'区域移仓'comefrom,
      (SELECT sei_code FROM dbo.b_storageinfo AS bs WITH (NOLOCK) WHERE (sei_id = mo_out_st_id) ) AS mo_out_st_id_code,
      mo_out_st_id_txt,sumnum,var_num,mo_num,(sumnum-var_num)optnum,
      (CASE WHEN mo_source_id>0 THEN '已收货' ELSE '未收货' END)STATUS,
      mo_source_vo,mo_source_id,summoney,mo_to_st_id,mo_to_st_id_txt,mo_remark,0 oo_jytype,mo_audit_time,mo_add_man_txt
FROM vi_j_moStorageByIn WHERE mo_status=2 and mo_source_type=1
go

