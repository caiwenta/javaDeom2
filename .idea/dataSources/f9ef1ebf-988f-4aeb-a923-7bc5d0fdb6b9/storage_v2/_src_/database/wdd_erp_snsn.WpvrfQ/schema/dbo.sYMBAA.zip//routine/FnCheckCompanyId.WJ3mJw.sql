CREATE FUNCTION [dbo].[FnCheckCompanyId]( @ci_id INT, @erp_id INT,@cp_id INT,@fo_order_id INT,@fo_type INT )

RETURNS INT
AS
BEGIN
	--用途：验证自动生成的单据与公司id 是否匹配 
    DECLARE @re INT;
	
    IF ( ISNULL(@fo_order_id, 0) = 0 or ISNULL(@erp_id,0)=0)
        SET @re = 1;
    ELSE
	--应收
        IF (@fo_type=0 and EXISTS ( SELECT  1
                    FROM    dbo.j_outStorage
                    WHERE   oo_ciid = @ci_id
                            AND oo_id = @fo_order_id and oo_cp_id=@cp_id))
            SET @re = 1;
        ELSE 
		--应付
		 if(@fo_type=1 AND EXISTS ( SELECT  1
                    FROM    dbo.j_enterStorage
                    WHERE   eo_ciid = @ci_id
                            AND eo_id = @fo_order_id and eo_cp_id=@cp_id))
		   SET @re = 1;
		 ELSE 
            SET @re = 0;
        
    RETURN @re;
END
go

