CREATE FUNCTION [dbo].[FnGoodsCustomPrice]
(
@ci_id INT,--0:客户
@sh_id INT, --店铺
@to_cp_id INT , --公司
@date DATETIME = '2018-02-04',
@gi_id INT,
@gi_skuid INT,
@cp_id INT --公司id
)
RETURNS @returntable TABLE
(
    cspid int,
    gi_id int,
	sku_id int,
	retailprice DECIMAL(9, 2),--零售价
	discount DECIMAL(9, 2),
	importprices DECIMAL(9, 2)    --供货价
)
AS
BEGIN


DECLARE @objectid INT=0;
DECLARE @s_type INT=2;--0:客户  1:店铺  2:公司
IF @ci_id>0
BEGIN
	SET @s_type=0;
	SET @objectid=@ci_id;
END 
ELSE IF @sh_id>0
BEGIN
	SET @s_type=1;
	SET @objectid=@sh_id;
END
ELSE IF @to_cp_id>0
BEGIN
	SET @s_type=2;
	SET @objectid=@to_cp_id;
END


DECLARE @isruleprice INT= 0;--是否同步规格价格
DECLARE @cplid INT= 0;--调价商品明细id
DECLARE @cp_update_type INT=0;
declare @temp table(
  cp_id int,
  cpl_gi_id int,
  cpl_skuid int,
  cpl_update_type int,
  cpl_retail_price DECIMAL(10, 2),
  cpl_discount DECIMAL(10, 2),
  cpl_stock_price DECIMAL(10, 2)
)

--'获取对象调价信息'
SELECT 
	@isruleprice=bb.isruleprice,
	@cplid=cpl_id,
	@cp_update_type=cp_update_type
FROM (
	SELECT TOP 1
		plc.isruleprice,
		plc.cpl_id,
		pcp.cp_update_type,
		pcp.cp_name,
		pcp.cp_vo,
		pcp.cp_add_time
	from erp_customPriceList AS plc WITH (NOLOCK)
		INNER JOIN erp_customPrice pcp WITH (NOLOCK) ON plc.cpl_cp_id=pcp.cp_id
	WHERE pcp.cp_status=2 AND pcp.cp_cp_id=@cp_id 
		AND pcp.cp_start <= @date  AND pcp.cp_end >= @date
		AND EXISTS(SELECT * FROM erp_customPriceobject AS pobj WITH (NOLOCK) 
	WHERE pobj.s_object_id=@objectid AND pobj.s_type=@s_type AND pobj.s_cp_id=pcp.cp_id)
		AND plc.cpl_gi_id=@gi_id
	ORDER BY pcp.cp_add_time DESC 
) AS bb

IF @cplid>0
BEGIN

	INSERT @returntable
	SELECT 
	0 AS cspid,
	gds.gi_id,
	gds.sku_id,
	gds.retailprice,
	discount =CAST((CASE WHEN gds.retailprice = 0.00 THEN 0.00 ELSE gds.importprices / gds.retailprice END) AS DECIMAL(10, 2)),
	gds.importprices
	FROM (
		SELECT
			bg.gi_id as gi_id, 
			isnull(bs.gss_id,0) sku_id, 
			(CASE WHEN bs.gss_id IS NULL THEN bg.gi_retailprice ELSE  bs.gs_marketprice END) AS retailprice,--零售价
			(CASE WHEN bs.gss_id IS NULL THEN bg.gi_importprices ELSE  bs.gs_salesprice END) AS importprices --供货价(销售价)
		FROM b_goodsinfo AS bg WITH (NOLOCK)
		LEFT JOIN b_goodsruleset AS bs WITH (NOLOCK) ON bs.gi_id=bg.gi_id AND isnull(bs.gs_status,1)<>0 
		AND bs.gss_id=(CASE WHEN @gi_skuid > 0 THEN  @gi_skuid  ELSE bs.gss_id END)
		WHERE gi_status<>0 and isnull(gi_disable,0)=0 AND bg.gi_id=@gi_id  
	) AS gds



IF @isruleprice=1
BEGIN
--按商品       
		INSERT @temp
		SELECT  pcp.cp_id,
		        pcpl.cpl_gi_id,
				0 as cpl_skuid ,
                pcp.cp_update_type AS cpl_update_type,
                cpl_retail_price,
                cpl_discount,
                cpl_stock_price
        FROM   erp_customPrice AS pcp WITH (NOLOCK)
                INNER JOIN erp_customPriceList AS pcpl WITH (NOLOCK) ON  pcp.cp_id = pcpl.cpl_cp_id
        WHERE  pcpl.cpl_id = @cplid
                AND pcp.cp_status = 2 AND pcpl.cpl_gi_id = @gi_id
			
        IF @cp_update_type=1
        BEGIN
        	
        	-- '零售价';
        	update @returntable SET
        			cspid=cp.cp_id,
        			retailprice=cp.cpl_retail_price,
        			discount=1.00,
        			importprices=cp.cpl_retail_price
			FROM @returntable AS gd
			INNER JOIN @temp AS cp ON gd.gi_id=cp.cpl_gi_id
			
        END 
        ELSE
        IF @cp_update_type = 2
        BEGIN
        	-- '折扣';
        	update @returntable SET
        			cspid=cp.cp_id, 
        			discount=cp.cpl_discount,
        			importprices= CAST((retailprice*cp.cpl_discount)  AS DECIMAL(10, 2))       
			FROM @returntable AS gd
			INNER JOIN @temp AS cp ON gd.gi_id=cp.cpl_gi_id
		END
		ELSE
		IF @cp_update_type = 3
		BEGIN
            -- '供货价';
			update @returntable SET
					cspid=cp.cp_id, 
					importprices=cp.cpl_stock_price,
					discount=CAST((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE cp.cpl_stock_price / retailprice END) AS DECIMAL(10, 2))                 
			FROM @returntable AS gd
			INNER JOIN @temp AS cp ON gd.gi_id=cp.cpl_gi_id
		END
	
END
ELSE
BEGIN
--按规格
		INSERT @temp
		SELECT  pcp.cp_id,
		        pcpl.cpl_gi_id,
                pcpl.cpl_skuid,
                pcp.cp_update_type  AS cpl_update_type,
                cpl_retail_price,
                cpl_discount,
                cpl_stock_price
        FROM   erp_customPrice  AS pcp WITH (NOLOCK)
               INNER JOIN erp_customPriceSkuList AS pcpl WITH (NOLOCK)
                    ON  pcp.cp_id = pcpl.cpl_cp_id
        WHERE  pcpl.cpl_cpl_id = @cplid
                AND pcp.cp_status = 2 AND pcpl.cpl_gi_id = @gi_id
        
		IF @cp_update_type=1
        BEGIN

			update @returntable SET
        			cspid=cp.cp_id,
        			retailprice=cp.cpl_retail_price,
        			discount=1.00,
        			importprices=cp.cpl_retail_price
			FROM @returntable AS gd
			INNER JOIN @temp AS cp ON gd.gi_id=cp.cpl_gi_id and gd.sku_id=cp.cpl_skuid

		END
		  ELSE
        IF @cp_update_type = 2
        BEGIN
        	-- '折扣';
        	update @returntable SET
        			cspid=cp.cp_id, 
        			discount=cp.cpl_discount,
        			importprices= CAST((retailprice*cp.cpl_discount)  AS DECIMAL(10, 2))       
			FROM @returntable AS gd
			INNER JOIN @temp AS cp ON gd.gi_id=cp.cpl_gi_id and gd.sku_id=cp.cpl_skuid
		END
		ELSE
		IF @cp_update_type = 3
		BEGIN
            -- '供货价';
			update @returntable SET
					cspid=cp.cp_id, 
					importprices=cp.cpl_stock_price,
					discount=CAST((CASE WHEN retailprice = 0.00 THEN 0.00 ELSE cp.cpl_stock_price / retailprice END) AS DECIMAL(10, 2))                 
			FROM @returntable AS gd
			INNER JOIN @temp AS cp ON gd.gi_id=cp.cpl_gi_id and gd.sku_id=cp.cpl_skuid
		END
END	


END

	RETURN
END
go

