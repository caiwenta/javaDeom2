CREATE PROCEDURE [dbo].[pro_merge_c_fundorder_queue]
       @fo_bs VARCHAR(50) = '' ,
       @fo_ciid INT = 0 ,
       @fo_shid INT = 0 ,
       @fo_to_cpid INT = 0 ,
       @fo_id INT = 0 ,
       @operate_type VARCHAR(50) = ''
AS
       BEGIN
	       
INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'款项生成',20 ,'队列开始计算客户供应商固化数据',@fo_id);

             IF ISNULL(@fo_id, 0) != 0
                BEGIN
                      UPDATE    c_fundorder
                      SET       fo_shid = 0
                      WHERE     fo_id = @fo_id
                                AND fo_shid IS NULL

                      UPDATE    c_fundorder
                      SET       fo_to_cpid = 0
                      WHERE     fo_id = @fo_id
                                AND fo_to_cpid IS NULL

                      UPDATE    c_fundorder
                      SET       fo_ciid = 0
                      WHERE     fo_id = @fo_id
                                AND fo_ciid IS NULL
                END

             SET @fo_ciid = ISNULL(@fo_ciid, 0);
             SET @fo_shid = ISNULL(@fo_shid, 0);
             SET @fo_to_cpid = ISNULL(@fo_to_cpid, 0);

             DECLARE @sql NVARCHAR(MAX)= '';
             DECLARE @sql_where NVARCHAR(1000)= '';
			 --期初记录
             MERGE INTO c_fundorder_vi_client_qcqm ta
                USING
                    ( SELECT    *
                      FROM      vi_client_qcqm
                      WHERE     fo_ciid = @fo_ciid
                                AND fo_shid = @fo_shid
                                AND fo_to_cpid = @fo_to_cpid
                                AND fo_bs = @fo_bs
                    ) AS so
                ON ta.fo_ciid = so.fo_ciid
                    AND ta.fo_shid = so.fo_shid
                    AND ta.fo_to_cpid = so.fo_to_cpid
                    AND ta.fo_bs = so.fo_bs
                WHEN MATCHED
                    THEN UPDATE
                         SET    ta.qcje = so.qcje ,
                                ta.qm = so.qm ,
                                ta.qc = so.qc ,
                                ta.cicode = so.cicode ,
                                ta.ciname = so.ciname ,
                                ta.shname = so.shname ,
                                ta.cpname = so.cpname
                WHEN NOT MATCHED
                    THEN INSERT (
                                  qm ,
                                  [COUNT] ,
                                  qc ,
                                  fo_id ,
                                  fo_erp_id ,
                                  fo_type ,
                                  fo_ciid ,
                                  fo_shid ,
                                  fo_to_cpid ,
                                  fo_bs ,
                                  fo_orderid ,
                                  fo_takeman ,
                                  fo_ticketno ,
                                  fo_realmoney ,
                                  fo_thiyetmoney ,
                                  fo_ofdate ,
                                  fo_remark ,
                                  fo_lastman ,
                                  fo_status ,
                                  fo_outmoney ,
                                  fo_admoney ,
                                  fo_otheronmoney ,
                                  fo_otheoutmoney ,
                                  fo_givemoney ,
                                  fo_ensuremoney ,
                                  fo_subscription ,
                                  fo_no ,
                                  fo_addtime ,
                                  fo_updatetime ,
                                  fo_rowNum ,
                                  ciname ,
                                  shname ,
                                  cpname ,
                                  qcje ,
                                  fo_userorderno ,
                                  cicode ,
                                  ci_cp_id ,
                                  qc_integral ,
                                  fo_realmoney_integral ,
                                  fo_thiyetmoney_integral ,
                                  fo_outmoney_integral ,
                                  fo_otheronmoney_integral ,
                                  fo_otheoutmoney_integral ,
                                  fo_givemoney_integral ,
                                  qm_integral
                                )
                         VALUES ( so.qm ,
                                  so.[COUNT] ,
                                  so.qc ,
                                  so.fo_id ,
                                  so.fo_erp_id ,
                                  so.fo_type ,
                                  so.fo_ciid ,
                                  so.fo_shid ,
                                  so.fo_to_cpid ,
                                  so.fo_bs ,
                                  so.fo_orderid ,
                                  so.fo_takeman ,
                                  so.fo_ticketno ,
                                  so.fo_realmoney ,
                                  so.fo_thiyetmoney ,
                                  so.fo_ofdate ,
                                  so.fo_remark ,
                                  so.fo_lastman ,
                                  so.fo_status ,
                                  so.fo_outmoney ,
                                  so.fo_admoney ,
                                  so.fo_otheronmoney ,
                                  so.fo_otheoutmoney ,
                                  so.fo_givemoney ,
                                  so.fo_ensuremoney ,
                                  so.fo_subscription ,
                                  so.fo_no ,
                                  so.fo_addtime ,
                                  so.fo_updatetime ,
                                  so.fo_rowNum ,
                                  so.ciname ,
                                  so.shname ,
                                  so.cpname ,
                                  so.qcje ,
                                  so.fo_userorderno ,
                                  so.cicode ,
                                  so.ci_cp_id ,
                                  so.qc_integral ,
                                  so.fo_realmoney_integral ,
                                  so.fo_thiyetmoney_integral ,
                                  so.fo_outmoney_integral ,
                                  so.fo_otheronmoney_integral ,
                                  so.fo_otheoutmoney_integral ,
                                  so.fo_givemoney_integral ,
                                  so.qm_integral
                                )
                WHEN NOT MATCHED  BY SOURCE AND ta.fo_ciid = @fo_ciid
                    AND ta.fo_shid = @fo_shid
                    AND ta.fo_to_cpid = @fo_to_cpid
                    AND ta.fo_bs = @fo_bs
                    THEN DELETE;

             IF @operate_type = '计算客户供应商固化数据'
                BEGIN
				--计算期初金额
                      SET @sql = 'SELECT cf.fo_id,ciname = CASE 
								WHEN bcinfo.ci_bs IS NULL THEN 
									ISNULL(bsinfo.si_name, '''')
								ELSE ISNULL(bcinfo.ci_name, '''')
								END,
								shname = ISNULL(psinfo.sh_name, ''''),
								cpname = ISNULL(cpinfo.cp_name, ''''),
							    qcje = CASE 
										   WHEN (bcinfo.ci_bs IS NULL AND psinfo.sh_bs IS NULL AND cpinfo.cp_bs IS NULL) THEN  bsinfo.si_qcje
										   WHEN (bcinfo.ci_bs IS NULL AND bsinfo.si_bs IS NULL AND cpinfo.cp_bs IS NULL) THEN  psinfo.sh_qcje
										   WHEN (bcinfo.ci_bs IS NULL AND psinfo.sh_bs IS NULL AND bsinfo.si_bs IS NULL) THEN  cpinfo.cp_qcje
										   ELSE bcinfo.ci_qcje
									  END,
								qc_integral=ISNULL(bsinfo.si_initial_integral,0),
							    cicode = CASE 
											 WHEN (bcinfo.ci_bs IS NULL AND psinfo.sh_bs IS NULL AND cpinfo.cp_bs IS NULL) THEN bsinfo.si_code
											 WHEN (bcinfo.ci_bs IS NULL AND bsinfo.si_bs IS NULL AND cpinfo.cp_bs IS NULL) THEN ''''
											 WHEN (bcinfo.ci_bs IS NULL AND psinfo.sh_bs IS NULL AND bsinfo.si_bs IS NULL) THEN ''''
											 ELSE bcinfo.ci_code
										END,
								CASE WHEN cf.fo_realmoney_integral=0
									AND cf.fo_thiyetmoney_integral=0
									AND cf.fo_outmoney_integral=0
									AND cf.fo_otheronmoney_integral=0
									AND cf.fo_otheoutmoney_integral=0
									AND cf.fo_givemoney_integral=0
								THEN 1 ELSE 0 
								END AS integral_status,
								CASE WHEN cf.fo_realmoney=0
									AND cf.fo_thiyetmoney=0
									AND cf.fo_outmoney=0
									AND cf.fo_otheronmoney=0
									AND cf.fo_otheoutmoney=0
									AND cf.fo_givemoney=0
									AND fo_admoney=0
									AND fo_ensuremoney=0
									AND fo_subscription=0
								THEN 1 ELSE 0 
								END AS fun_status
							INTO ##qc
							FROM (
								SELECT  * FROM   c_fundorder cf WITH (NOLOCK) WHERE 
									{0}
							) AS cf
							LEFT JOIN (
								SELECT ci_bs = ''X'',
									   bc.ci_id,
									   bc.ci_name,
									   ISNULL(bc.ci_qcje, 0) AS ci_qcje,
									   bc.ci_code
								FROM   b_clientinfo bc WITH (NOLOCK) 
							) AS bcinfo
							ON  cf.fo_ciid = bcinfo.ci_id
							AND cf.fo_bs = bcinfo.ci_bs
						   LEFT JOIN (
									SELECT sh_bs = ''X'',
										   ps.sh_id,
										   ps.sh_name,
										   ISNULL(ps.sh_qcje, 0) AS sh_qcje,
										   ps.sh_no
									FROM   pos_shop ps WITH (NOLOCK) 
									WHERE  ps.[status] != 0
								) AS psinfo
								ON  cf.fo_shid = psinfo.sh_id
								AND cf.fo_bs = psinfo.sh_bs
						   LEFT JOIN (
										 SELECT cp_bs = ''X'',
												cp.cp_id,
												cp.cp_name,
												ISNULL(cp.cp_qcje, 0) AS cp_qcje,
												cp.cp_code
										 FROM   companyinfo cp WITH (NOLOCK) 
									 ) AS cpinfo 
									 ON cf.fo_to_cpid = cpinfo.cp_id 
									 AND cf.fo_bs = cpinfo.cp_bs
						   LEFT JOIN (
									SELECT si_bs = ''G'',
										   bs.si_id,
										   bs.si_name,
										   ISNULL(bs.si_qcje, 0) AS si_qcje,
										   ISNULL(bs.si_initial_integral,0) AS si_initial_integral,
										   bs.si_code
									FROM   b_supplierinfo bs WITH (NOLOCK) 
								) AS bsinfo
								ON  cf.fo_ciid = bsinfo.si_id
								AND cf.fo_bs = bsinfo.si_bs;'
								
                      IF @fo_id != 0
                         BEGIN
                               SET @sql_where = ' cf.fo_status=2 AND cf.fo_id=' + CONVERT(VARCHAR(50), @fo_id);
                         END
                      ELSE
                         BEGIN
                               SET @sql_where = ' cf.fo_status=2 AND cf.fo_ciid=' + CONVERT(VARCHAR(50), @fo_ciid) + ' AND cf.fo_bs=''' + @fo_bs + ''''
                                   + ' AND cf.fo_shid=' + CONVERT(VARCHAR(50), @fo_shid) + ' AND cf.fo_to_cpid=' + CONVERT(VARCHAR(50), @fo_to_cpid)
                         END

                      SET @sql = REPLACE(@sql, '{0}', @sql_where);

                      EXEC sp_executesql @sql;
  
                      UPDATE    c_fundorder
                      SET       ciname = qc.ciname ,
                                shname = qc.shname ,
                                cpname = qc.cpname ,
                                qcje = qc.qcje ,
                                qc_integral = qc.qc_integral ,
                                cicode = qc.cicode ,
                                integral_status = qc.integral_status ,
                                fun_status = qc.fun_status
                      FROM      c_fundorder cfo ,
                                ##qc qc
                      WHERE     cfo.fo_id = qc.fo_id

                      DROP TABLE ##qc;
				--计算期未金额
                      SET @sql = 'SELECT  qm_integral = ISNULL(fd.qc_integral, 0) + qm_user_integral ,
									*
							INTO    ##qm
							FROM    ( SELECT    qm = ISNULL(cqm.qc, 0) + ( CASE WHEN cqm.fo_type = 0
																			   THEN cqm.fo_realmoney + cqm.fo_admoney + cqm.fo_otheronmoney - cqm.fo_otheoutmoney - cqm.fo_outmoney
																					- cqm.fo_thiyetmoney
																			   ELSE cqm.fo_realmoney + cqm.fo_otheoutmoney - cqm.fo_outmoney - cqm.fo_thiyetmoney - cqm.fo_admoney
																					- cqm.fo_otheronmoney
																		  END ) ,
												qm_user_integral = ISNULL(( CASE WHEN cqm.fo_type = 0
																				 THEN cqm.fo_realmoney_integral + cqm.fo_otheronmoney_integral - cqm.fo_otheoutmoney_integral
																					  - cqm.fo_outmoney_integral - cqm.fo_thiyetmoney_integral
																				 ELSE cqm.fo_realmoney_integral + cqm.fo_otheoutmoney_integral - cqm.fo_outmoney_integral
																					  - cqm.fo_thiyetmoney_integral - cqm.fo_otheronmoney_integral
																			END ), 0) ,
												*
									  FROM      ( SELECT    SUM(CASE WHEN cfs.fo_id IS NOT NULL THEN 1
																	 ELSE 0
																END) AS Count ,
															SUM(CASE WHEN cf.fo_rowNum = 1 THEN cf.qcje
																	 ELSE CASE WHEN cf.fo_type = 0
																			   THEN cfs.fo_realmoney + cfs.fo_admoney + cfs.fo_otheronmoney - cfs.fo_otheoutmoney - cfs.fo_outmoney
																					- cfs.fo_thiyetmoney
																			   ELSE cfs.fo_realmoney + cfs.fo_otheoutmoney - cfs.fo_outmoney - cfs.fo_thiyetmoney - cfs.fo_admoney
																					- cfs.fo_otheronmoney
																		  END
																END) + CASE WHEN cf.fo_rowNum != 1 THEN cf.qcje
																			ELSE 0
																	   END AS qc ,
															SUM(CASE WHEN cf.fo_rowNum = 1 THEN cf.qc_integral
																	 ELSE CASE WHEN cf.fo_type = 0
																			   THEN cfs.fo_realmoney_integral + cfs.fo_otheronmoney_integral - cfs.fo_otheoutmoney_integral
																					- cfs.fo_outmoney_integral - cfs.fo_thiyetmoney_integral
																			   ELSE cfs.fo_realmoney_integral + cfs.fo_otheoutmoney_integral - cfs.fo_outmoney_integral
																					- cfs.fo_thiyetmoney_integral - cfs.fo_otheronmoney_integral
																		  END
																END) + CASE WHEN cf.fo_rowNum != 1 THEN cf.qc_integral
																			ELSE 0
																	   END AS qc_integral ,
															cf.fo_id ,
															cf.fo_type ,
															cf.fo_realmoney ,
															cf.fo_admoney ,
															cf.fo_otheronmoney ,
															cf.fo_otheoutmoney ,
															cf.fo_outmoney ,
															cf.fo_thiyetmoney ,
															cf.fo_realmoney_integral ,
															cf.fo_otheronmoney_integral ,
															cf.fo_outmoney_integral ,
															cf.fo_thiyetmoney_integral ,
															cf.fo_otheoutmoney_integral
												  FROM      c_fundorder cf
												  LEFT JOIN c_fundorder cfs
															ON cf.fo_status = 2
															   AND cfs.fo_status = 2
															   AND cf.fo_type = cfs.fo_type
															   AND cf.fo_ciid = cfs.fo_ciid
															   AND cf.fo_shid = cfs.fo_shid
															   AND cf.fo_to_cpid = cfs.fo_to_cpid
															   AND cf.fo_bs = cfs.fo_bs
															   AND cfs.fo_rowNum < cf.fo_rowNum
												  WHERE     {0}
												  GROUP BY  cf.fo_id ,
															cf.fo_erp_id ,
															cf.fo_type ,
															cf.fo_ciid ,
															cf.fo_bs ,
															cf.fo_orderid ,
															cf.fo_takeman ,
															cf.fo_ticketno ,
															cf.fo_realmoney ,
															cf.fo_thiyetmoney ,
															cf.fo_ofdate ,
															cf.fo_remark ,
															cf.fo_lastman ,
															cf.fo_status ,
															cf.fo_outmoney ,
															cf.fo_admoney ,
															cf.fo_otheronmoney ,
															cf.fo_otheoutmoney ,
															cf.fo_givemoney ,
															cf.fo_ensuremoney ,
															cf.fo_subscription ,
															cf.fo_no ,
															cf.fo_addtime ,
															cf.fo_updatetime ,
															cf.fo_rowNum ,
															cf.ciname ,
															cf.qcje ,
															cf.fo_userorderno ,
															cf.cicode ,
															cf.fo_cp_id ,
															cf.shname ,
															cf.cpname ,
															cf.qc_integral ,
															cf.fo_realmoney_integral ,
															cf.fo_thiyetmoney_integral ,
															cf.fo_outmoney_integral ,
															cf.fo_otheronmoney_integral ,
															cf.fo_otheoutmoney_integral ,
															cf.fo_givemoney_integral ,
															cf.fun_status ,
															cf.integral_status ,
															cf.fo_shid ,
															cf.fo_to_cpid
												) AS cqm
									) AS fd';

                      SET @sql = REPLACE(@sql, '{0}', @sql_where);

                      EXEC sp_executesql @sql;

                      UPDATE    c_fundorder
                      SET       qm_integral = qm.qm_integral ,
                                qm = qm.qm ,
                                qm_user_integral = qm.qm_user_integral ,
                                Count = qm.Count ,
                                qc = qm.qc ,
                                qc_integral = qm.qc_integral
                      FROM      c_fundorder cfo ,
                                ##qm qm
                      WHERE     cfo.fo_id = qm.fo_id

                      DROP TABLE ##qm;
                END

INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'款项生成',20 ,'队列计算客户供应商固化数据成功',@fo_id);
       END
go

