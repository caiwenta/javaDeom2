CREATE VIEW [dbo].[vi_pos_ogStorageList_sum]
	AS 
SELECT 
jmsl.ogl_og_id,
(SELECT SUM(isnull(ogl_box_num,0)) FROM (
Select (case when fd.ogl_boxbynum=0 then 0 else ceiling(sum(fd.ogl_num)/fd.ogl_boxbynum) end) as ogl_box_num
From pos_ogStorageList fd where fd.ogl_status=1 AND fd.ogl_og_id=jmsl.ogl_og_id
GROUP BY fd.ogl_gi_id,isnull(fd.ogl_pm,''),fd.ogl_boxbynum
) AS BB
) AS ogl_boxnum,
SUM(ogl_num) AS ogl_num,
SUM(ogl_money) AS ogl_money
FROM pos_ogStorageList AS jmsl WHERE jmsl.ogl_status=1 
GROUP BY jmsl.ogl_og_id
go

