CREATE VIEW [dbo].[vi_j_enterStorageList] AS 

SELECT     jt.el_eoid, jt.el_siid, jt.el_addtime, SUM(el_number) AS el_number, MIN(el_id) AS el_id, MAX(el_skuid) AS el_skuid, SUM(el_realmoney) AS el_realmoney, 
                      CONVERT(decimal(10, 2), AVG(el_unit)) AS el_unit, CONVERT(decimal(10, 2), AVG(el_costprice)) AS el_costprice,  
                      CONVERT(decimal(10, 2), AVG(el_discount)) AS el_discount,max(replace( jt.el_pm,'*',',')) as el_pm
    ,max(fd.el_box_num) as  el_box_num,jt.el_gift,MAX(jt.el_source_add_time) AS     el_source_add_time            
     ,
	 max(jt.el_pdgddate) AS el_pdgddate,
	  MAX(jt.el_expirationdate) AS el_expirationdate,
	 MAX(jt.el_shelflife) AS el_shelflife,
     max(jt.el_pddate) AS el_pddate,
	 sum(jt.el_integral) as el_integral,
	 sum(jt.el_totalintegral) as el_totalintegral
FROM         dbo.j_enterStorageList AS jt
inner join (
	
	select fd.el_eoid,fd.el_siid,fd.el_addtime,
	
	sum(fd.el_box_num) as el_box_num  
	from (
select 
fd.el_eoid,
fd.el_siid,
fd.el_addtime,
fd.el_box_num,
fd.el_costprice, 
fd.el_unit,
fd.el_discount,
fd.el_gift,
fd.el_pm,
max(fd.el_id)
as el_id from j_enterStorageList as fd
group by fd.el_eoid,fd.el_siid,fd.el_addtime,fd.el_box_num,fd.el_costprice, 
fd.el_unit,
fd.el_discount,fd.el_gift,fd.el_pm
	) as fd
	group by fd.el_eoid,fd.el_siid,fd.el_addtime,fd.el_gift
) as fd on jt.el_eoid=fd.el_eoid and jt.el_siid=fd.el_siid
and jt.el_addtime=fd.el_addtime
WHERE     (el_status = 1)
GROUP BY jt.el_eoid, jt.el_siid, jt.el_addtime,jt.el_gift,el_pm
go

