

CREATE PROCEDURE [dbo].[sysProcGetTableIndex]
    @tableName VARCHAR(50) = '' ,
    @type VARCHAR(50) = ''
AS
    BEGIN
    -- =============================================
	-- Author:		<获取表的索引情况L>
	-- Create date: <2015-06-30>
	-- =============================================
        IF @type = 'UQ'
            BEGIN
                SELECT TOP 1000
                        DB_NAME(dm_ius.database_id) AS "Database_Name" ,
                        o.name AS "Table_Name" ,
                        i.name AS "Index_Name" ,
                        i.is_unique AS "Unique" ,
                        i.index_id AS "Index_ID" ,
                        dm_ius.user_seeks AS "User_Seeks" ,
                        dm_ius.user_scans AS "User_Scans" ,
                        dm_ius.user_lookups AS "User_Lookups" ,
                        dm_ius.user_updates AS "User_Updates" ,
                        p.TableRows AS "TableRows" ,
                        dm_ius.last_user_seek AS "Last_User_Seek" ,
                        dm_ius.last_user_scan AS "Last_User_Scan" ,
                        CASE i.is_unique
                          WHEN 0
                          THEN 'DROP INDEX ' + QUOTENAME(i.name) + ' ON '
                               + QUOTENAME(s.name) + '.'
                               + QUOTENAME(OBJECT_NAME(dm_ius.OBJECT_ID))
                          ELSE ''
                        END AS 'Delete_SQL'
                FROM    sys.dm_db_index_usage_stats dm_ius
                        INNER JOIN sys.indexes i ON i.index_id = dm_ius.index_id
                                                    AND dm_ius.OBJECT_ID = i.OBJECT_ID
                                                    AND i.is_unique = 1
                        INNER JOIN sys.objects o ON dm_ius.OBJECT_ID = o.OBJECT_ID
                        INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
                        INNER JOIN ( SELECT SUM(p.rows) TableRows ,
                                            p.index_id ,
                                            p.OBJECT_ID
                                     FROM   sys.partitions p
                                     GROUP BY p.index_id ,
                                            p.OBJECT_ID
                                   ) p ON p.index_id = dm_ius.index_id
                                          AND dm_ius.OBJECT_ID = p.OBJECT_ID
                WHERE   OBJECTPROPERTY(dm_ius.OBJECT_ID, 'IsUserTable') = 1
                        AND dm_ius.database_id = DB_ID()
                        AND i.type_desc = 'nonclustered'
                        AND i.is_primary_key = 0
                        AND i.is_unique_constraint = 0
                ORDER BY ( dm_ius.user_seeks + dm_ius.user_scans
                           + dm_ius.user_lookups ) ASC
            END
        ELSE
            BEGIN
                IF @tableName = ''
                    BEGIN
                        SELECT TOP 1000
                                DB_NAME(dm_ius.database_id) AS "Database_Name" ,
                                o.name AS "Table_Name" ,
                                i.name AS "Index_Name" ,
                                i.is_unique AS "Unique" ,
                                i.index_id AS "Index_ID" ,
                                dm_ius.user_seeks AS "User_Seeks" ,
                                dm_ius.user_scans AS "User_Scans" ,
                                dm_ius.user_lookups AS "User_Lookups" ,
                                dm_ius.user_updates AS "User_Updates" ,
                                p.TableRows AS "TableRows" ,
                                dm_ius.last_user_seek AS "Last_User_Seek" ,
                                dm_ius.last_user_scan AS "Last_User_Scan" ,
                                CASE i.is_unique
                                  WHEN 0
                                  THEN 'DROP INDEX ' + QUOTENAME(i.name)
                                       + ' ON ' + QUOTENAME(s.name) + '.'
                                       + QUOTENAME(OBJECT_NAME(dm_ius.OBJECT_ID))
                                  ELSE ''
                                END AS 'Delete_SQL'
                        FROM    sys.dm_db_index_usage_stats dm_ius
                                INNER JOIN sys.indexes i ON i.index_id = dm_ius.index_id
                                                            AND dm_ius.OBJECT_ID = i.OBJECT_ID
                                INNER JOIN sys.objects o ON dm_ius.OBJECT_ID = o.OBJECT_ID
                                INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
                                INNER JOIN ( SELECT SUM(p.rows) TableRows ,
                                                    p.index_id ,
                                                    p.OBJECT_ID
                                             FROM   sys.partitions p
                                             GROUP BY p.index_id ,
                                                    p.OBJECT_ID
                                           ) p ON p.index_id = dm_ius.index_id
                                                  AND dm_ius.OBJECT_ID = p.OBJECT_ID
                        WHERE   OBJECTPROPERTY(dm_ius.OBJECT_ID, 'IsUserTable') = 1
                                AND dm_ius.database_id = DB_ID()
                                AND i.type_desc = 'nonclustered'
                                AND i.is_primary_key = 0
                                AND i.is_unique_constraint = 0
                        ORDER BY ( dm_ius.user_seeks + dm_ius.user_scans
                                   + dm_ius.user_lookups ) ASC
                    END
                ELSE
                    BEGIN 
                        SELECT TOP 1000
                                DB_NAME(dm_ius.database_id) AS "Database_Name" ,
                                o.name AS "Table_Name" ,
                                i.name AS "Index_Name" ,
                                i.is_unique AS "Unique" ,
                                i.index_id AS "Index_ID" ,
                                dm_ius.user_seeks AS "User_Seeks" ,
                                dm_ius.user_scans AS "User_Scans" ,
                                dm_ius.user_lookups AS "User_Lookups" ,
                                dm_ius.user_updates AS "User_Updates" ,
                                p.TableRows AS "TableRows" ,
                                dm_ius.last_user_seek AS "Last_User_Seek" ,
                                dm_ius.last_user_scan AS "Last_User_Scan" ,
                                CASE i.is_unique
                                  WHEN 0
                                  THEN 'DROP INDEX ' + QUOTENAME(i.name)
                                       + ' ON ' + QUOTENAME(s.name) + '.'
                                       + QUOTENAME(OBJECT_NAME(dm_ius.OBJECT_ID))
                                  ELSE ''
                                END AS 'Delete_SQL'
                        FROM    sys.dm_db_index_usage_stats dm_ius
                                INNER JOIN sys.indexes i ON i.index_id = dm_ius.index_id
                                                            AND dm_ius.OBJECT_ID = i.OBJECT_ID
                                INNER JOIN sys.objects o ON dm_ius.OBJECT_ID = o.OBJECT_ID
                                INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
                                INNER JOIN ( SELECT SUM(p.rows) TableRows ,
                                                    p.index_id ,
                                                    p.OBJECT_ID
                                             FROM   sys.partitions p
                                             GROUP BY p.index_id ,
                                                    p.OBJECT_ID
                                           ) p ON p.index_id = dm_ius.index_id
                                                  AND dm_ius.OBJECT_ID = p.OBJECT_ID
                        WHERE   OBJECTPROPERTY(dm_ius.OBJECT_ID, 'IsUserTable') = 1
                                AND dm_ius.database_id = DB_ID()
                                AND i.type_desc = 'nonclustered'
                                AND i.is_primary_key = 0
                                AND i.is_unique_constraint = 0
                                AND o.name = @tableName
                        ORDER BY ( dm_ius.user_seeks + dm_ius.user_scans
                                   + dm_ius.user_lookups ) ASC
                    END
            END
    END
go

