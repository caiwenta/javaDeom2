CREATE VIEW [dbo].[v_z_stocklog_rule]
AS

SELECT rs.sl_eoid order_id, --主订单id
       rs.sl_type sl_type, --主订单类型
       rs.sl_cp_id sl_cp_id, --主订单公司
       rs.cs_id color_order_id, -- 颜色汇总表id
       rs.num sku_num, --数量
       rs.ruleid, --规格id
       gr.gd_row_number spec,--规格排序，占位号
       rs.colorid --颜色id
FROM j_stocklog_MergeRuleSum AS rs
LEFT JOIN s_goodsruledetail AS gr
ON rs.ruleid = gr.gd_id
go

