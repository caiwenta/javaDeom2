CREATE VIEW [dbo].[v_z_pos_inStorage_detail] AS 
select 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
posinlist.*
from 
(

select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
posin.* 
from
(



SELECT 
--其它名称字段
CONVERT (VARCHAR (10),(CASE WHEN in_source = 1 THEN ( SELECT oo_entrydate FROM j_outStorage WITH (NOLOCK) WHERE oo_id = in_source_id ) ELSE ( SELECT al_date FROM pos_alStorage WITH (NOLOCK) WHERE al_id = in_source_id ) END),120) AS in_source_date,
pis.sh_name AS in_sh_id_txt, ( CASE WHEN in_source = 1 THEN ( SELECT oo_no FROM j_outStorage WITH (NOLOCK) WHERE oo_id =in_source_id ) ELSE ( SELECT al_vo FROM pos_alStorage WITH (NOLOCK) WHERE al_id = in_source_id ) END ) AS in_source_no,--来源凭证号
pis.cp_name AS in_supplier_sh_id_txt,--供方
pis.ut_name AS gi_unit_name,--单位
pis.sei_name AS in_st_id_txt,--仓库
pis.*,
inl_num as num--规格数量

FROM
(
SELECT
st.inl_id,
ps.sh_company,
ps.sh_erp_id  as erp_id,
ge.in_sh_id as sh_id,


ge.in_status,
ge.in_sh_id,
ge.in_id,  
ge.in_vo,--凭证号
ge.in_no,--单据号
CONVERT(VARCHAR(100),ge.in_date,23) as in_date ,--入库日期
isnull(ge.in_is_audit,0) AS in_is_audit,  
ge.in_type,
ge.in_source,

sg.sei_id,
sg.sei_name,--仓库
   

ISNULL(ps.sh_name,'') as sh_name,--店铺
ISNULL(ps.sh_no,'') as sh_no,--店铺代号

--ISNULL(spi.si_name,'') as cp_name,--供方
--ISNULL(spi.si_code,'') as cp_code,--供方代号


(
		CASE 
		     WHEN in_source=0 THEN --公司
		         (SELECT    bs.si_name FROM       pos_supplierinfo AS bs WHERE    bs.si_id = in_supplier_sh_id)
		     WHEN  in_source =1 THEN --公司
				(SELECT cp_name FROM    dbo.companyinfo WHERE   cp_id =(select top 1 oo_cp_id from j_outStorage where oo_id= in_source_id))
		      WHEN in_source = 2  AND in_remark<>'网络订单'  then   
				(SELECT sh_name FROM pos_shop WHERE sh_id=(SELECT al_sh_id FROM pos_alStorage WITH (NOLOCK) WHERE al_id = in_source_id))
	          WHEN in_source = 2 AND in_remark='网络订单' THEN (SELECT sh_no FROM pos_shop WITH (NOLOCK) WHERE sh_id= in_supplier_sh_id)
				ELSE 
		     (SELECT sh_name FROM pos_shop WHERE sh_id=(SELECT al_sh_id FROM pos_alStorage WITH (NOLOCK) WHERE al_id = in_source_id))
		END
		
	) AS cp_name,
	(
		CASE 
		     WHEN in_source=0 THEN --公司
		         (SELECT  bs.si_code FROM       pos_supplierinfo AS bs WHERE    bs.si_id = in_supplier_sh_id)
		     WHEN  in_source =1 THEN --公司
				(SELECT  cp_code FROM    dbo.companyinfo WHERE   cp_id =(select top 1 oo_cp_id from j_outStorage where oo_id= in_source_id))
		      WHEN in_source = 2  AND in_remark<>'网络订单'  then   
				(SELECT sh_no FROM pos_shop WHERE sh_id=(SELECT al_sh_id FROM pos_alStorage WITH (NOLOCK) WHERE al_id = in_source_id))
	          WHEN in_source = 2 AND in_remark='网络订单' THEN (SELECT sh_no FROM pos_shop WITH (NOLOCK) WHERE sh_id= in_supplier_sh_id)
				ELSE 
		     (SELECT sh_no FROM pos_shop WHERE sh_id=(SELECT al_sh_id FROM pos_alStorage WITH (NOLOCK) WHERE al_id = in_source_id))
		END
		
	) AS cp_code,




gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_id,
st.inl_gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_skuid,


ui.ut_name,--单位
isnull((case WHEN ge.in_type=0 then  inl_num ELSE -inl_num END ),0) AS inl_num,--数量

st.inl_in_id,
isnull(st.inl_retail_price,0) as inl_retail_price,--零售价
isnull(st.inl_discount,0) as inl_discount,--折率
isnull(st.inl_stock_price,0) as inl_stock_price,--进货价
isnull((case when  ge.in_type=0 then  inl_money ELSE -inl_money END ),0) AS inl_money,--金额
isnull(st.inl_box_num,0) as inl_box_num,--箱数

st.inl_add_time,   
case WHEN ge.in_type=0 then '入库' else '入库退货'end as intype, --类型

(CASE WHEN ge.in_source = 0 and ge.in_source = 1 THEN '总部' WHEN ge.in_source = 2 AND ge.in_remark='网络订单' THEN '网络订单' ELSE '调拨' end) as insource, --来源类型

ge.in_source_id,
st.inl_sku_id,
ge.ord_no,
ge.in_add_time,
b4.si_name as in_add_manc,
ge.in_update_time,
b5.si_name as in_update_manc,
ge.in_audit_time,
b6.si_name as in_audit_manc,
in_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =in_add_man ),
in_order_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = in_order_man ),
in_update_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = in_update_man),
in_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = in_audit_man ),
in_remark,
( SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id where eio.io_id=in_io_id)instru_vo --指令单凭证号

FROM   pos_inStorage ge WITH (NOLOCK)
inner join  pos_inStorageList st WITH (NOLOCK) ON ge.in_id = inl_in_id AND st.inl_status = 1 and st.inl_num<>0 and ge.in_status>0
inner join b_goodsinfo gi WITH (NOLOCK) on gi.gi_id=st.inl_gi_id and gi_status=1
inner join b_unit ui on ui.ut_id=gi.gi_unit 
inner join pos_storageInfo sg on sg.sei_id=ge.in_st_id
inner join pos_shop ps on ps.sh_id=ge.in_sh_id
left join b_stafftinfo b4 on ge.in_add_man=b4.si_id
left join b_stafftinfo b5 on ge.in_update_man=b5.si_id
left join b_stafftinfo b6 on ge.in_audit_man=b6.si_id 

) AS pis



) as posin
left join b_goodsruleset  as grl on  grl.gss_id=posin.inl_sku_id

) as posinlist
left join s_goodsruledetail rulenum WITH (NOLOCK) on gd_id=posinlist.size
go

