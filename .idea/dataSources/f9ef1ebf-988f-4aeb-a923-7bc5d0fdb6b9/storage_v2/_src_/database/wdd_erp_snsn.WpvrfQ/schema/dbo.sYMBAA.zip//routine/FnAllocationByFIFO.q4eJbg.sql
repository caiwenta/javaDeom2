CREATE FUNCTION [dbo].[FnAllocationByFIFO]
(
	@pid UDTypeOrderId READONLY,
	@orderguid VARCHAR(5000),
	@erp_id int
)
RETURNS @pl TABLE (
	  all_id INT,
      all_pl_id INT,
      all_gi_id INT,
      all_sku_id INT,
      all_add_time DATETIME,
      all_num INT,
	  qty int,
	  all_retail_price decimal(10,2),
	  all_discount decimal(10,2),
	  all_stock_price decimal(10,2)
)
AS
BEGIN

---控制允许超百分比
declare @maxinput float=0;
SELECT @maxinput=(case when s_value=1 then
case when s_othervalue<>'' then CAST(s_othervalue AS float) else 0 end
else 0
end)
FROM s_system_set AS sss 
WHERE sss.s_erp_id=@erp_id AND sss.s_key='AllowOverPurchasePer'

if @maxinput>0
	set @maxinput=@maxinput/100;


--获取要入库商品数量
DECLARE @in TABLE (
	gi_id INT, 
	sku_id INT,
	num INT,
	retailprice decimal(10,2),
	discount decimal(10,2),
	realprice decimal(10,2)
)
INSERT INTO @in	
SELECT 
gi_id,
sku_id,
SUM(number),
max(retailprice),
max(discount),
max(purchase) FROM erp_goodslisttemp AS eg 
WHERE eg.orderguid=@orderguid 
GROUP BY gi_id,sku_id
 


INSERT INTO @pl
SELECT 
all_id,
all_al_id,
all_gi_id,
all_sku_id,
all_add_time,
(
floor(isnull(all_num,0)*@maxinput+ isnull(all_num,0))
-
ISNULL((
SELECT sum(josl.ol_number) AS ol_number FROM j_outStorage AS jos WITH (NOLOCK) INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) 
ON jos.oo_id = josl.ol_eoid WHERE  jos.oo_source_type=1 and jos.oo_status<>0 AND josl.ol_source_id=st.all_id AND josl.ol_status<>0 AND josl.ol_status = 1	
), 0)
-isnull(st.all_pause_num,0)
) AS all_num,
0,
all_retail_price,
all_discount,
all_stock_price
FROM pos_allocationList AS st 
INNER JOIN @pid p ON st.all_al_id=p.id
WHERE  st.all_status>0


--先进先出
update @pl set qty=(
CASE WHEN 
   (select i.num-isnull(sum(pt.all_num),0) FROM @pl pt WHERE pt.all_id<=ps.all_id AND pt.all_gi_id=ps.all_gi_id AND pt.all_sku_id=ps.all_sku_id )>=0 THEN ps.all_num
ELSE( 
CASE WHEN 
   (SELECT i.num-isnull(sum(pt.all_num),0) FROM @pl pt WHERE pt.all_id<ps.all_id AND pt.all_gi_id=ps.all_gi_id AND pt.all_sku_id=ps.all_sku_id )<0
 then 0
 ELSE
   (SELECT i.num-isnull(sum(pt.all_num),0) FROM @pl pt WHERE pt.all_id<ps.all_id AND pt.all_gi_id=ps.all_gi_id AND pt.all_sku_id=ps.all_sku_id )
 END)
END
)
FROM @pl AS ps
INNER JOIN @in AS i ON ps.all_gi_id=i.gi_id AND ps.all_sku_id=i.sku_id

--删除没分配到的采购
delete @pl where qty=0;



	RETURN
END
go

