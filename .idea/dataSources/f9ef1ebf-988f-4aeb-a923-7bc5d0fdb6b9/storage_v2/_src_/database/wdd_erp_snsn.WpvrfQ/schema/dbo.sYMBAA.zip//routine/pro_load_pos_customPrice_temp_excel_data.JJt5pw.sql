CREATE Proc [dbo].[pro_load_pos_customPrice_temp_excel_data]
@add_time DATETIME,
@check INT=0
AS

IF @check=1
BEGIN

IF EXISTS(SELECT fd2.* FROM pos_customPrice_temp_excel_data fd 
INNER JOIN b_goodsinfo fd2 ON fd.[商品编码]=fd2.gi_code and 商品名称!=fd2.gi_name
WHERE fd.add_time=@add_time)
BEGIN
 DECLARE @result VARCHAR(MAX)='';
 SELECT @result=@result+','+CASE WHEN 商品名称!=fd2.gi_name then  
 [商品编码] else '' end
 FROM pos_customPrice_temp_excel_data fd 
 INNER JOIN b_goodsinfo fd2 ON fd.[商品编码]=fd2.gi_code 
 WHERE fd.add_time=@add_time
 SELECT '异常,存在商品名称错误的记录,是否继续?'+'<br/>'+@result as info
 RETURN;
END
 
END


SELECT  gi_id,
       gi_shortname,
       gi_name,
       gi_type,
       gi_code,
       gi_grade,
       gi_norm,
       gi_status,
       gi_remark,
       gi_entrydate,
       gi_unit,
       si_img,
       gi_skus,
       gi_alarmstock,
       gi_barcode,
       gi_brands,
       gi_category,
       gi_costprice,
       gi_downstork,
       gi_importprices,
       gi_number,
 
       gi_seiid,
       gi_seiname,
       gi_typeone,
       gi_types,
       gi_typesid,
       gi_upstock,
       gi_virtual,
       gi_weight,
       gi_simplecode,
       gi_brandsid,
       gi_skuid,
cpl_discount,       
gi_retailprice_1,
gi_retailprice,

cpl_stock_price,

       gi_class,
       gi_class_id,
       gi_addtime,
       gi_updatetime,
       gi_oc_id,
       gi_tid,
       gi_taobao_id,
       gi_add_man,
       gi_add_time,
       gi_update_man,
       gi_update_time,
       gi_cp_id,
       gi_di_id,
       gi_attribute_ids,
       gi_is_tb,
       gi_attribute_parentids,
       gi_purchase_discount,
       ut_name 
,MAX(id) AS id
FROM (
SELECT gi_id,
       gi_shortname,
       gi_name,
       gi_type,
       gi_code,
       gi_grade,
       gi_norm,
       gi_status,
       gi_remark,
       gi_entrydate,
       gi_unit,
       si_img,
       gi_skus,
       gi_alarmstock,
       gi_barcode,
       gi_brands,
       gi_category,
       gi_costprice,
       gi_downstork,
       gi_importprices,
       gi_number,

       gi_seiid,
       gi_seiname,
       gi_typeone,
       gi_types,
       gi_typesid,
       gi_upstock,
       gi_virtual,
       gi_weight,
       gi_simplecode,
       gi_brandsid,
       gi_skuid,
fd.[折扣] as cpl_discount,  
     
gi_retailprice AS gi_retailprice_1,

fd.[零售价] as gi_retailprice,
fd.[销售价] as cpl_stock_price,
       gi_class,
       gi_class_id,
       gi_addtime,
       gi_updatetime,
       gi_oc_id,
       gi_tid,
       gi_taobao_id,
       gi_add_man,
       gi_add_time,
       gi_update_man,
       gi_update_time,
       gi_cp_id,
       gi_di_id,
       gi_attribute_ids,
       gi_is_tb,
       gi_attribute_parentids,
       gi_purchase_discount,
       fd3.ut_name
       ,fd.id
FROM   pos_customPrice_temp_excel_data fd
       INNER JOIN b_goodsinfo fd2
            ON  fd.[商品编码] = fd2.gi_code
       INNER JOIN b_unit fd3
            ON  fd2.gi_unit = fd3.ut_id
WHERE  fd.add_time = @add_time

)  AS fd
GROUP BY  gi_id,
       gi_shortname,
       gi_name,
       gi_type,
       gi_code,
       gi_grade,
       gi_norm,
       gi_status,
       gi_remark,
       gi_entrydate,
       gi_unit,
       si_img,
       gi_skus,
       gi_alarmstock,
       gi_barcode,
       gi_brands,
       gi_category,
       gi_costprice,
       gi_downstork,
       gi_importprices,
       gi_number,
 
       gi_seiid,
       gi_seiname,
       gi_typeone,
       gi_types,
       gi_typesid,
       gi_upstock,
       gi_virtual,
       gi_weight,
       gi_simplecode,
       gi_brandsid,
       gi_skuid,
cpl_discount,       
gi_retailprice_1,       
gi_retailprice,

cpl_stock_price,

       gi_class,
       gi_class_id,
       gi_addtime,
       gi_updatetime,
       gi_oc_id,
       gi_tid,
       gi_taobao_id,
       gi_add_man,
       gi_add_time,
       gi_update_man,
       gi_update_time,
       gi_cp_id,
       gi_di_id,
       gi_attribute_ids,
       gi_is_tb,
       gi_attribute_parentids,
       gi_purchase_discount,
       ut_name 
ORDER BY MAX(id)


go

