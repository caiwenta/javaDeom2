CREATE VIEW [dbo].[v_z_enterStorage_good]
	AS 

SELECT
ge.eo_no,--凭证号
ge.eo_manual,--单据号
(CONVERT(VARCHAR(10),YEAR(eo_entrydate))+'年'+CONVERT(VARCHAR(10),MONTH(eo_entrydate))+'月') AS eo_month , --月份
CONVERT(varchar(100), ge.eo_entrydate, 23) AS eo_entrydate,--入库日期
ge.eo_id, 
st.el_eoid,
ge.eo_type,
(CASE WHEN ge.eo_type=0 THEN '入库' ELSE '退货' END)eotype,  --单据类型
ge.eo_cp_id,
cp.cp_name AS eo_cp_name,
cp.cp_code AS eo_cp_code,
ge.eo_erp_id AS erp_id,
(CASE WHEN eo_source_type=1 THEN (SELECT pl_vo FROM j_purchaseStorage WHERE  pl_id=st.el_source_id)
      WHEN eo_source_type=2 THEN (SELECT TOP 1 oo_no FROM j_outStorage WHERE oo_id=eo_source_id AND oo_status<>0)
END) AS pl_vo,
st.el_source_id AS source_id,

st.el_di_id,
st.el_cp_id,
st.el_erp_id,
st.el_gift,

ge.eo_siid,
sg.sei_name,--仓库名称
sg.sei_code,--仓库编号
spi.si_name,--供应商
spi.si_code,--供应商代号
      
takeman=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = eo_takemanid) ,   --经手人
eo_addman_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs  WITH (NOLOCK) WHERE si_id = eo_addman ) , --单据添加人
eo_addtime, --单据添加时间
eo_update_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = eo_updateman ), --单据修改人
eo_updatetime,  --单据修改时间
eo_lastman=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = eo_lastmanid), --单据审核人
eo_auditdate, --单据审核时间
eo_remark,  --备注
eo_status,  --单据状态
(SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) 
         LEFT JOIN dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id  
 WHERE eio.io_id=eo_io_id)instru_vo, --指令单凭证号   
                                    
st.el_siid,   
gi.gi_id,
gi.gi_skuid,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi_factoryprice,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_retailprice,--零售价
gi.gi_costprice,--成本价
gi.gi_sampleno,--样品号
ui.ut_name,--单位
ui.ut_name AS gi_unit, --单位
el_addtime, --商品添加时间

ISNULL(st.el_unit,0) AS el_unit,--零售价
ISNULL(st.el_costprice,0) AS el_costprice,--进货价
ISNULL(st.el_discount,0) AS el_discount,--折率
ISNULL(st.el_realmoney,0) AS el_realmoney,--入库金额（合计金额）
ISNULL((CASE WHEN ge.eo_type=1 THEN st.el_realmoney ELSE 0 END),0) AS eo_returnrealmoney,--退货金额
ISNULL((CASE WHEN ge.eo_type=0 THEN st.el_realmoney ELSE 0 END),0) AS eo_realmoney ,--入库金额(不含退货)
ISNULL((ISNULL(st.el_number,0)*st.el_unit),0) AS el_unit_money,--零售金额

ISNULL(st.el_number,0) AS el_number,--数量
ISNULL((CASE WHEN eo_type=0 THEN  ISNULL(st.el_number,0) ELSE 0 END),0) AS eo_number,--入库数量
ISNULL((CASE WHEN eo_type=1 THEN  ISNULL(st.el_number,0) ELSE 0 END),0) AS eo_returnnum,--退货数量
                                                                            
st.el_pm,--配码
ISNULL(st.el_boxbynum,0)el_boxbynum,--数量/箱
ISNULL(st.el_box_num,0) AS el_box_num,--箱数
ISNULL((CASE WHEN eo_type=0 THEN  st.el_box_num ELSE 0 END),0) AS eo_box_number,--入库箱数
ISNULL((CASE WHEN eo_type=1 THEN  st.el_box_num ELSE 0 END),0) AS eo_box_returnnum--退货箱数


FROM   j_enterStorage ge WITH (NOLOCK)
INNER JOIN j_enterStorageListMergeSum st WITH (NOLOCK) ON ge.eo_id = el_eoid AND st.el_status = 1 AND ge.eo_status>0
LEFT JOIN companyinfo cp WITH (NOLOCK) ON cp.cp_id = ge.eo_cp_id
LEFT JOIN b_goodsinfo gi WITH (NOLOCK) ON gi.gi_id=st.el_siid AND gi_status=1
LEFT JOIN b_unit ui WITH (NOLOCK) ON ui.ut_id=gi.gi_unit 
INNER JOIN b_supplierinfo spi WITH (NOLOCK) ON spi.si_id= ge.eo_ciid --and spi.si_status=1
LEFT JOIN b_storageinfo sg WITH (NOLOCK) ON ge.eo_siid=sg.sei_id
go

