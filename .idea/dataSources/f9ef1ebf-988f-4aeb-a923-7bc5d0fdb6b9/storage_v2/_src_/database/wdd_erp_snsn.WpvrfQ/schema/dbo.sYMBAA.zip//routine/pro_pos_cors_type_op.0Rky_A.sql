CREATE PROCEDURE [dbo].[pro_pos_cors_type_op]
	@type_id INT ,
	@type_name VARCHAR(50),
	@type_cors INT,
	@addtime DATETIME,
	@remark VARCHAR(250),
	@type_fid INT,
	@type_status INT,
	 --操作类型(1:添加 2:修改 3:删除)
	@op_type INT = 0,
	@outResult INT OUTPUT,
	@type_sh_id INT = 0,
		@type_erp_id INT = 0
AS
BEGIN
	IF @op_type = 1
	BEGIN
	    INSERT INTO [pos_cors_type]
	      (
	        [type_name],
	        [type_cors],
	        [addtime],
	        [remark],
	        [type_fid],
	        [type_status],
	        [type_sh_id],type_erp_id
	      )
	    VALUES
	      (
	        @type_name,
	        @type_cors,
	        @addtime,
	        @remark,
	        @type_fid,
	        @type_status,
	        @type_sh_id,@type_erp_id
	      )
	    SET @type_id = SCOPE_IDENTITY()
	END
	
	IF @op_type = 2
	   AND @type_id > 0
	BEGIN
	    UPDATE [pos_cors_type]
	    SET    [type_name]       = @type_name,
	           [type_cors]       = @type_cors,
	           [addtime]         = @addtime,
	           [remark]          = @remark,
	           [type_fid]        = @type_fid,
	           [type_status]     = @type_status
	    WHERE  [type_id]         = @type_id
	    AND type_sh_id=@type_sh_id
	END
	
	IF @op_type = 3
	   AND @type_id > 0
	BEGIN
	    UPDATE [pos_cors_type]
	    SET    [type_status]     = @type_status
	    WHERE  [type_id]         = @type_id
	    AND type_sh_id=@type_sh_id
	END
	
	IF @@error <> 0
	BEGIN
	    SET @outResult = 0;
	END
	ELSE
	BEGIN
	    SET @outResult = @type_id;
	END
	RETURN @outResult;
END
go

