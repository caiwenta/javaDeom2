CREATE FUNCTION [dbo].[Get_goods_discount](@gi_id int,@gd_class int,@Tel int,@gd_type int)
RETURNS VARCHAR(12)
AS
BEGIN

DECLARE @CountStr VARCHAR(12),@Sql varchar(500)

SET @CountStr=''
if(@Tel=0)
begin
     select @CountStr= CONVERT(varchar,gd_discount) from b_goods_discount where gd_gi_id=@gi_id and gd_class=@gd_class and gd_type=@gd_type
end
else
begin
     select @CountStr=CONVERT(varchar,gd_price) from b_goods_discount where gd_gi_id=@gi_id and gd_class=@gd_class and gd_type=@gd_type
end



RETURN @CountStr
END
go

