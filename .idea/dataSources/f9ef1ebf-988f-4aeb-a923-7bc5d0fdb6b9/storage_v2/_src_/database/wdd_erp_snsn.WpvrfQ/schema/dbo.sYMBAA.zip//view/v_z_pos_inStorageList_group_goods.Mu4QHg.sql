CREATE VIEW [dbo].[v_z_pos_inStorageList_group_goods]
	AS 
SELECT

(SELECT SUM(var_num) FROM erp_inspectionofgoods WHERE orderid=inl_in_id and gi_id=inl_gi_id AND warehousingtype=8 and iog_status=1) as var_num ,--验货数
(SELECT SUM(ol_number) FROM j_outStorage fd INNER JOIN j_outStoragelist AS fdl ON fd.oo_id=fdl.ol_eoid  AND fd.oo_source_type=3 AND fd.oo_status>0 AND fdl.ol_status<>0 AND fd.oo_source_id=inl_in_id AND fdl.ol_siid=inl_gi_id) AS oo_num, --收货数


	jt.inl_in_id,
	jt.inl_gi_id,
	jt.inl_num,
	jt.inl_id,
	jt.inl_money,
	jt.inl_retail_price,
	jt.inl_stock_price,
	jt.inl_discount,
	jt.inl_sample_no,
	jt.inl_gift,
	jt.inl_sku_id,
	jt.inl_pddate,
	jt.inl_pdgddate,
	CONVERT (
		VARCHAR (100),
		jt.inl_add_time,
		25
	) AS inl_add_time,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bg.gi_sampleno,--样品号
	bu.ut_name AS gi_unit_name,
	bu.ut_id AS gi_unit,
	bu.ut_id AS gi_unit_id,
	inl_box_num,
	inl_pm
	
FROM
	(

SELECT
	inl_in_id,
	inl_gi_id,
	MAX (inl_add_time) as inl_add_time,
	SUM (inl_num) AS inl_num,
	MIN (inl_id) AS inl_id,
	MAX (inl_sku_id) AS inl_sku_id,
	SUM (inl_money) AS inl_money,
	CONVERT ( DECIMAL (10, 2), AVG (inl_retail_price) ) AS inl_retail_price,
	CONVERT ( DECIMAL (10, 2), AVG (inl_stock_price) ) AS inl_stock_price,
	MAX (inl_gift) AS inl_gift,
	MAX (inl_sample_no) AS inl_sample_no,
	CONVERT ( DECIMAL (10, 2), AVG (inl_discount) ) AS inl_discount,
	MAX (replace(inl_pm, '*', ',')) AS inl_pm,
	MAX (inl_box_num) AS inl_box_num,
	max(inl_pddate) as inl_pddate,
	max(inl_pdgddate) as inl_pdgddate
FROM dbo.pos_inStorageList AS jt WITH (NOLOCK) 
WHERE (inl_status = 1)
GROUP BY inl_in_id,inl_gi_id

) AS jt
INNER JOIN dbo.b_goodsinfo AS bg WITH (NOLOCK) ON jt.inl_gi_id = bg.gi_id
INNER JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
go

