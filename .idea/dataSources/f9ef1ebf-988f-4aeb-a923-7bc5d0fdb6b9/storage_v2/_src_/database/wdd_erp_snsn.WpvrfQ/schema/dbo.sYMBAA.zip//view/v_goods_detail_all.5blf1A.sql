CREATE VIEW [dbo].[v_goods_detail_all]
AS 
select 
vbg.gi_id,gi_name,gi_code,gi_buyingteamid,gi_buyingteam,gi_typename1,gi_typename2,gi_typename3,gi_typename4,gi_erp_id,gi_status,
isnull(gss_id,0)gss_id,
isnull(gss_no,0)gss_no,
isnull(specid,0)specid,
isnull(specname,'')specname,
isnull(colorid,0)colorid,
isnull(colorname,'')colorname
from v_goodsinfo vbg left join b_goodsruleset bgs  on vbg.gi_id=bgs.gi_id and vbg.gi_status>0 and bgs.gs_status>0
go

