


CREATE PROCEDURE [dbo].[pro_pos_memberInfo_op]
@me_id int,
@me_erp_id INT =0,
@me_card varchar(50),
@me_name varchar(50),
@me_sh_id int,
@me_status int,
@me_cu_status int,
@me_type int,
@me_gr_id int,
@me_man int,
@me_phone varchar(50),
@me_number varchar(50),
@me_qq varchar(50),
@me_sex varchar(50),
@me_car varchar(50),
@me_identity_card varchar(50),
@me_profession varchar(50),
@me_intro_man varchar(50),
@me_car_no varchar(50),
@me_address varchar(100),
@me_work_unit varchar(50),
@me_birthday datetime,
@me_in_num int=0,
@me_init_in_num int=0,
@me_init_money decimal(10,2),
@me_cu_in_num int=0,
@me_cu_add_num int=0,
@me_init_get int=0,
@me_add_date datetime,
@me_eff_date datetime,
@me_add_man int,
@me_add_time datetime,
@me_update_man int,
@me_update_time datetime,
@me_audit_man int,
@me_audit_time datetime,
@me_is_shop_add INT,
@me_cp_id int=0,
@me_di_id int=0,
@me_category_id int=0,
--操作类型(1:添加 2:修改 3:删除 4:审核或取消审核)
@op_type Int=0,
@dzd_miid int=0,
@me_storevaluecard int=0,--储值卡判断是否直接扣款（0：否，1：是）
@birthday_discount decimal(10,2) =0.00,--会员生日折扣率
@islunar Int=0,--是否农历
@me_pwd varchar(200)='',
@outResult int Output
AS
BEGIN
	IF @op_type=1
    BEGIN
    	
    SET @me_cu_in_num=@me_in_num;
	INSERT INTO    [pos_memberInfo](
	[me_card],[me_name],[me_sh_id],[me_status],[me_cu_status],[me_type],[me_gr_id],[me_man],[me_phone],[me_number],[me_qq],[me_sex],[me_car],[me_identity_card],[me_profession],[me_intro_man],[me_car_no],[me_address],[me_work_unit],[me_birthday],[me_in_num],[me_init_in_num],[me_init_money],[me_cu_add_num],[me_add_date],[me_eff_date],[me_add_man],[me_add_time],[me_update_man],[me_update_time],[me_audit_man],[me_audit_time],[me_is_shop_add],[me_init_get],[me_cu_in_num],[me_cp_id],[me_di_id],[me_category_id]
	,me_erp_id,dzd_miid,me_storevaluecard,birthday_discount,islunar,me_pwd)VALUES(
	@me_card,@me_name,@me_sh_id,@me_status,@me_cu_status,@me_type,@me_gr_id,@me_man,@me_phone,@me_number,@me_qq,@me_sex,@me_car,@me_identity_card,@me_profession,@me_intro_man,@me_car_no,@me_address,@me_work_unit,@me_birthday,@me_in_num,@me_init_in_num,@me_init_money,@me_cu_add_num,@me_add_date,@me_eff_date,@me_add_man,@me_add_time,@me_update_man,@me_update_time,@me_audit_man,@me_audit_time,@me_is_shop_add,@me_init_get,isnull(@me_in_num,0)+isnull(@me_init_get,0)-isnull(@me_cu_add_num,0),@me_cp_id,@me_di_id,@me_category_id
	,@me_erp_id,@dzd_miid,@me_storevaluecard,@birthday_discount,@islunar,@me_pwd)
	SET @me_id = SCOPE_IDENTITY()

	update [pos_memberInfo] set  me_init_money=0.0,me_cu_in_num=ISNULL(me_cu_in_num,0),me_cu_add_num=0 where me_id=@me_id;

    if @dzd_miid>0
	begin
	INSERT INTO [api_docking_tbl]([dock_type],[dock_typeid],[dock_updats],[dock_kind],[dock_platform],[dock_formtbl],[dock_formkey],[dock_erptbl],[dock_erpkey])
	                       VALUES(0,0,1,1,'dzd','',@dzd_miid,'pos_memberInfo',@me_id)
	end



	END
  
    
	IF @op_type=2 AND @me_id>0
    Begin
    select @me_init_get=me_init_get,@me_cu_add_num=me_cu_add_num  from pos_memberInfo WHERE me_id=@me_id 
    UPDATE [pos_memberInfo] SET 
	[me_is_shop_add] = @me_is_shop_add,[me_card] = @me_card,[me_name] = @me_name,[me_sh_id] = @me_sh_id,[me_cu_status]=@me_cu_status,[me_status] = @me_status,[me_type] = @me_type,[me_gr_id] = @me_gr_id,[me_man] = @me_man,[me_phone] = @me_phone,[me_number] = @me_number,[me_qq] = @me_qq,[me_sex] = @me_sex,[me_car] = @me_car,[me_identity_card] = @me_identity_card,[me_profession] = @me_profession,[me_intro_man] = @me_intro_man,[me_car_no] = @me_car_no,[me_address] = @me_address,[me_work_unit] = @me_work_unit,[me_birthday] = @me_birthday,[me_in_num] = @me_in_num,[me_init_in_num] = @me_init_in_num,[me_init_money] = @me_init_money,[me_cu_add_num] = @me_cu_add_num,[me_eff_date] = @me_eff_date,[me_update_man] = @me_update_man,[me_update_time] = @me_update_time,[me_cu_in_num]=isnull(@me_in_num,0)+isnull(@me_init_get,0)-isnull(@me_cu_add_num,0),[me_category_id]=@me_category_id,[me_storevaluecard]=@me_storevaluecard,[birthday_discount]=@birthday_discount,[islunar]=@islunar
	WHERE me_id=@me_id 
    END
    
    IF @op_type=3 AND @me_id>0
    Begin
    UPDATE [pos_memberInfo] SET 
	[me_update_man] = @me_update_man,[me_update_time] = @me_update_time,[me_status] = @me_status
	WHERE me_id=@me_id AND me_sh_id=@me_sh_id
    END
    
    IF @op_type=4 AND @me_id>0
    Begin
    UPDATE [pos_memberInfo] SET 
	[me_audit_man] = @me_audit_man,[me_audit_time] = @me_audit_time,[me_status] = @me_status
	WHERE me_id=@me_id AND me_sh_id=@me_sh_id
    END
    
    if @@error<>0 
begin 
	set @outResult=0;
end
else 
begin
   set @outResult=@me_id;
end
  Return @outResult;

END
go

