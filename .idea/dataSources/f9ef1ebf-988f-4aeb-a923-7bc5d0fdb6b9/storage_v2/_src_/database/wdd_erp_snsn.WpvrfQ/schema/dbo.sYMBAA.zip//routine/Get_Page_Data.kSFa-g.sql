CREATE proc [dbo].[Get_Page_Data]
@MainTableName varchar(500),--主表，固定为：表名 M
@NextTableName varchar(max),--次表联接  ' inner   join j_outStorage ge on M.ol_eoid=ge.oo_id inner  join b_goodsinfo fo on M.ol_siid=fo.gi_id'
@MainWhere varchar(max),--主表查询条件  M.ol_eoid in(select gi_id from b_goodsinfo where gi_name like 'Q%')
@page int,@pageSize int,--当前页，页大小
@Order varchar(500),--排序条件
@MainTel varchar(max),--主表输出的列
@Tel varchar(max),--总输出的列
@tal int=0,
@finallyTel varchar(max)='',
@SumTel varchar(8000)
as
declare @Sql Nvarchar(max);
if(@tal=0)
begin
 set @Sql='select '+@Tel+' from '--多联表显示列
 +'(SELECT '+@MainTel+' FROM (SELECT ROW_NUMBER() OVER(order by '+@Order +')AS Row,'+@MainTel
 +' from '+@MainTableName+' WHERE '+@MainWhere+') M '
 +'WHERE M.Row between '+convert(varchar,((@page-1)*@pageSize+1))+'  and '+CONVERT(varchar,((@page-1)*@pageSize+@pageSize))+')  as M '
 +@NextTableName

 if(@finallyTel!='')
 begin
   set @Sql='select '+@finallyTel+' from ('+@Sql+') as fd'
 end

 set @Sql=@Sql+'  select count(1) from '+@MainTableName+' where '+@MainWhere

end
else if(@tal=1)
begin
 set @Sql='select '+ @Tel+ ' from '+@MainTableName+' where '+@MainWhere ;
end
else if(@tal=2)
begin
  if(@finallyTel='')
  begin
  set @Sql='select '+ @SumTel+ ' from '+@MainTableName+' '+@NextTableName+' where '+@MainWhere
  end
  else
  begin
  set @Sql='select '+ @Tel+ ' from '+@MainTableName+' '+@NextTableName+' where '+@MainWhere
  set @Sql='select '+@finallyTel+' from ('+@Sql+') fc'
  set @Sql='select '+ @SumTel+ ' from ('+@Sql+') fd';
  end
end
exec sp_executesql  @Sql;
go

