CREATE PROCEDURE [dbo].[pro_updatePrice]
	@up_erp_id INT = 0,
	@up_cp_id INT =0,
	@gi_id INT=0,
	@add_man INT=0,
	--类型
	@updateType VARCHAR(50)='',
	--要修改的供货价类型
	@supplytype VARCHAR(50)='',
	--结果  
	@result VARCHAR(100) = '' OUT
AS

BEGIN TRAN

DECLARE @updateTime DATETIME=GETDATE()  --更新时间
	
IF @updateType='更新进货价'  --ph_type=0
BEGIN
	/*****************************采购单、供应商退货通知单******************************/
	BEGIN
		
	--更新前，将未审核单据的原价格存到"erp_priceHistory"
	INSERT INTO  erp_priceHistory(ph_order_vo,ph_order_id,ph_detail_id,ph_gi_id,ph_sku_id,ph_price,ph_type,ph_addtime,ph_addman,ph_erp_id)
	SELECT pl_vo,pl_id,pll_id,pll_gi_id,pll_sku_id,pll_stock_price,0,@updateTime,@add_man,@up_erp_id 
	FROM j_purchaseStorage 
	LEFT JOIN j_purchaseStorageList ON pl_id=pll_pl_id
	WHERE pl_status=1 AND pll_status>0 AND pl_pltype IN (0,1) AND pl_erp_id=@up_erp_id AND pl_cp_id=@up_cp_id AND pll_gi_id=@gi_id
	
	--更新未审核单据的进货价
	UPDATE j_purchaseStorageList
	SET pll_stock_price=ISNULL((SELECT gs_purchase 
								FROM b_goodsruleset 
								WHERE gi_id=pll_gi_id AND gss_id=pll_sku_id),(SELECT gi_purchase 
								                                              FROM b_goodsinfo 
								                                              WHERE gi_id=pll_gi_id)),
		pll_money=(ISNULL((SELECT gs_purchase 
						   FROM b_goodsruleset 
						   WHERE gi_id=pll_gi_id AND gss_id=pll_sku_id),(SELECT gi_purchase 
																		 FROM b_goodsinfo 
																		 WHERE gi_id=pll_gi_id))*pll_num)
	WHERE pll_status>0 AND 
		  pll_gi_id=@gi_id AND 
		  pll_pl_id IN (SELECT pl_id 
						FROM j_purchaseStorage 
						WHERE pl_status=1 AND pl_erp_id=@up_erp_id AND pl_cp_id=@up_cp_id AND pl_pltype IN (0,1))
	
	--更新主表的金额				
	UPDATE j_purchaseStorage
	SET pl_money = fd.pl_money
	FROM j_purchaseStorage AS jps,
       (
           SELECT jpsl.pll_pl_id,
                  SUM(jpsl.pll_num * jpsl.pll_stock_price) AS pl_money
           FROM   j_purchaseStorageList AS jpsl
           WHERE  jpsl.pll_pl_id IN (SELECT DISTINCT pl_id 
                                     FROM j_purchaseStorage 
                                     LEFT JOIN j_purchaseStorageList ON pl_id=pll_pl_id
                                     WHERE pl_status=1 AND pl_pltype IN (0,1) AND pl_erp_id=@up_erp_id AND pl_cp_id=@up_cp_id AND pll_gi_id=@gi_id)
                  AND jpsl.pll_status = 1
           GROUP BY
                  jpsl.pll_pl_id
       ) AS fd
	WHERE  fd.pll_pl_id = jps.pl_id

	END
	/*****************************采购单、供应商退货通知单******************************/
	
	
    /*********************************商品入库、入库退货********************************/
    BEGIN	
	--更新前，将未审核单据的原价格存到"erp_priceHistory"
	INSERT INTO  erp_priceHistory(ph_order_vo,ph_order_id,ph_detail_id,ph_gi_id,ph_sku_id,ph_price,ph_type,ph_addtime,ph_addman,ph_erp_id)
	SELECT eo_no,eo_id,el_id,el_siid,el_skuid,el_costprice,0,@updateTime,@add_man,@up_erp_id 
	FROM j_enterStorage 
	LEFT JOIN j_enterStorageList ON eo_id=el_eoid 
	WHERE eo_status=1 AND el_status>0 AND eo_erp_id=@up_erp_id AND eo_cp_id=@up_cp_id AND el_siid=@gi_id
	
	--更新未审核单据的进货价
	UPDATE j_enterStorageList
	SET el_costprice=ISNULL((SELECT gs_purchase 
							 FROM b_goodsruleset 
						  	 WHERE gi_id=el_siid AND gss_id=el_skuid),(SELECT gi_purchase 
																	   FROM b_goodsinfo 
																	   WHERE gi_id=el_siid)),
		el_realmoney=(ISNULL((SELECT gs_purchase 
						      FROM b_goodsruleset 
						      WHERE gi_id=el_siid AND gss_id=el_skuid),(SELECT gi_purchase 
															            FROM b_goodsinfo 
															            WHERE gi_id=el_siid))*el_number)
	WHERE el_status>0 AND 
		  el_siid=@gi_id AND 
		  el_eoid IN (SELECT eo_id 
					  FROM j_enterStorage 
					  WHERE eo_status=1 AND eo_erp_id=@up_erp_id AND eo_cp_id=@up_cp_id)
	
	--更新主表的金额				
	UPDATE j_enterStorage
	SET eo_realmoney = fd.el_realmoney
	FROM j_enterStorage AS je,
       (
           SELECT jel.el_eoid,
                  SUM(jel.el_number * jel.el_costprice) AS el_realmoney
           FROM   j_enterStorageList AS jel
           WHERE  jel.el_eoid IN (SELECT DISTINCT eo_id 
                                  FROM j_enterStorage 
                                  LEFT JOIN j_enterStorageList ON eo_id=el_eoid
                                  WHERE eo_status=1 AND eo_erp_id=@up_erp_id AND eo_cp_id=@up_cp_id AND el_siid=@gi_id)
                  AND jel.el_status = 1
           GROUP BY
                  jel.el_eoid
       ) AS fd
	WHERE  fd.el_eoid = je.eo_id
    END
    /*********************************商品入库、入库退货********************************/

END

IF @updateType='更新供货价'  --ph_type=1
BEGIN
	--临时表（用于存放要更新供货价的单据信息）
	DECLARE @updateTable TABLE 
	(
		supplytype VARCHAR(50), --供货价类型
		supply DECIMAL(9, 2), --供货价
		order_vo VARCHAR(50), --凭证号
		order_id INT, --主表id
		detail_id INT, --明细id
		gi_id INT, --商品id
		sku_id INT, --规格id
		stock_price DECIMAL(9, 2) --单据原供货价
	)
	
	DELETE FROM @updateTable
	
	/********************************** 订单管理 ***********************************/
	BEGIN	
	--将指定商品的未审核单据的信息存到临时表中
	INSERT INTO @updateTable
	(
		supplytype,
		supply,
		order_vo,
		order_id,
		detail_id,
		gi_id,
		sku_id,
		stock_price
	)
	SELECT (CASE WHEN og_ci_id>0 THEN (CASE WHEN og_type=1 THEN (SELECT ci_dhprice FROM b_clientinfo WHERE ci_id=og_ci_id)
											WHEN og_type=2 THEN (SELECT ci_bhprice FROM b_clientinfo WHERE ci_id=og_ci_id)
											WHEN og_type=3 THEN (SELECT ci_phprice FROM b_clientinfo WHERE ci_id=og_ci_id)
											WHEN og_type=4 THEN (SELECT ci_mdprice FROM b_clientinfo WHERE ci_id=og_ci_id) END)
				 WHEN og_sh_id>0 THEN (CASE WHEN og_type=1 THEN (SELECT sh_dhprice FROM pos_shop WHERE sh_id=og_sh_id)
											WHEN og_type=2 THEN (SELECT sh_bhprice FROM pos_shop WHERE sh_id=og_sh_id)
											WHEN og_type=3 THEN (SELECT sh_phprice FROM pos_shop WHERE sh_id=og_sh_id)
											WHEN og_type=4 THEN (SELECT sh_mdprice FROM pos_shop WHERE sh_id=og_sh_id) END)
				 WHEN og_to_cp_id>0 THEN (CASE WHEN og_type=1 THEN (SELECT cp_dhprice FROM companyinfo WHERE cp_id=og_to_cp_id)
											   WHEN og_type=2 THEN (SELECT cp_bhprice FROM companyinfo WHERE cp_id=og_to_cp_id)
											   WHEN og_type=3 THEN (SELECT cp_phprice FROM companyinfo WHERE cp_id=og_to_cp_id)
											   WHEN og_type=4 THEN (SELECT cp_mdprice FROM companyinfo WHERE cp_id=og_to_cp_id) END) END)supplytype,
		   (CASE WHEN og_ci_id>0 THEN (CASE WHEN og_type=1 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ogl_gi_id AND 
																			   gd_type=ci_dhprice) FROM b_clientinfo WHERE ci_id=og_ci_id)
											WHEN og_type=2 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ogl_gi_id AND 
																			   gd_type=ci_bhprice) FROM b_clientinfo WHERE ci_id=og_ci_id)
											WHEN og_type=3 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ogl_gi_id AND 
																			   gd_type=ci_phprice) FROM b_clientinfo WHERE ci_id=og_ci_id)
											WHEN og_type=4 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ogl_gi_id AND 
																			   gd_type=ci_mdprice) FROM b_clientinfo WHERE ci_id=og_ci_id) END)
				 WHEN og_sh_id>0 THEN (CASE WHEN og_type=1 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ogl_gi_id AND 
																			   gd_type=sh_dhprice) FROM pos_shop WHERE sh_id=og_sh_id)
											WHEN og_type=2 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ogl_gi_id AND 
																			   gd_type=sh_bhprice) FROM pos_shop WHERE sh_id=og_sh_id)
											WHEN og_type=3 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ogl_gi_id AND 
																			   gd_type=sh_phprice) FROM pos_shop WHERE sh_id=og_sh_id)
											WHEN og_type=4 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ogl_gi_id AND 
																			   gd_type=sh_mdprice) FROM pos_shop WHERE sh_id=og_sh_id) END)
				 WHEN og_to_cp_id>0 THEN (CASE WHEN og_type=1 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=ogl_gi_id AND 
																				  gd_type=cp_dhprice) FROM companyinfo WHERE cp_id=og_to_cp_id)
											   WHEN og_type=2 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=ogl_gi_id AND 
																				  gd_type=cp_bhprice) FROM companyinfo WHERE cp_id=og_to_cp_id)
											   WHEN og_type=3 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=ogl_gi_id AND 
																				  gd_type=cp_phprice) FROM companyinfo WHERE cp_id=og_to_cp_id)
											   WHEN og_type=4 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=ogl_gi_id AND 
																				  gd_type=cp_mdprice) FROM companyinfo WHERE cp_id=og_to_cp_id) END) END)supply,
		   og_vo,og_id,ogl_id,ogl_gi_id,ogl_sku_id,ogl_stock_price
	FROM pos_ogStorage 
	LEFT JOIN pos_ogStorageList ON og_id=ogl_og_id
	WHERE og_status=1 AND ogl_status>0 AND og_erp_id=@up_erp_id AND og_cp_id=@up_cp_id AND ogl_gi_id=@gi_id
	
	--更新前，将要修改的指定供货价类型的未审核单据的原价格存到"erp_priceHistory"
	INSERT INTO  erp_priceHistory(ph_order_vo,ph_order_id,ph_detail_id,ph_gi_id,ph_sku_id,ph_price,ph_type,ph_addtime,ph_addman,ph_erp_id)
	SELECT order_vo,order_id,detail_id,gi_id,sku_id,stock_price,1,@updateTime,@add_man,@up_erp_id 
	FROM @updateTable 
	WHERE @supplytype LIKE '%,'+supplytype+',%'
	
	--更新未审核单据的供货价
	UPDATE pos_ogStorageList
	SET ogl_stock_price=ut.supply,
		ogl_money=(ut.supply*ogl_num)
	FROM pos_ogStorageList AS pol, 
	    (SELECT * FROM @updateTable WHERE @supplytype LIKE '%,'+supplytype+',%') AS ut
	WHERE pol.ogl_id=ut.detail_id
	
	END
	/********************************** 订单管理 ***********************************/
	
	DELETE FROM @updateTable
		
	/***************************** 配货单、客户退货通知单 *******************************/
	BEGIN	
	--将指定商品的未审核单据的信息存到临时表中
	INSERT INTO @updateTable
	(
		supplytype,
		supply,
		order_vo,
		order_id,
		detail_id,
		gi_id,
		sku_id,
		stock_price
	)
	SELECT (CASE WHEN al_ci_id>0 THEN (CASE WHEN al_type=1 THEN (SELECT ci_dhprice FROM b_clientinfo WHERE ci_id=al_ci_id)
											WHEN al_type=2 THEN (SELECT ci_bhprice FROM b_clientinfo WHERE ci_id=al_ci_id)
											WHEN al_type=3 THEN (SELECT ci_phprice FROM b_clientinfo WHERE ci_id=al_ci_id)
											WHEN al_type=4 THEN (SELECT ci_mdprice FROM b_clientinfo WHERE ci_id=al_ci_id) END)
				 WHEN al_sh_id>0 THEN (CASE WHEN al_type=1 THEN (SELECT sh_dhprice FROM pos_shop WHERE sh_id=al_sh_id)
											WHEN al_type=2 THEN (SELECT sh_bhprice FROM pos_shop WHERE sh_id=al_sh_id)
											WHEN al_type=3 THEN (SELECT sh_phprice FROM pos_shop WHERE sh_id=al_sh_id)
											WHEN al_type=4 THEN (SELECT sh_mdprice FROM pos_shop WHERE sh_id=al_sh_id) END)
				 WHEN al_to_cp_id>0 THEN (CASE WHEN al_type=1 THEN (SELECT cp_dhprice FROM companyinfo WHERE cp_id=al_to_cp_id)
											   WHEN al_type=2 THEN (SELECT cp_bhprice FROM companyinfo WHERE cp_id=al_to_cp_id)
											   WHEN al_type=3 THEN (SELECT cp_phprice FROM companyinfo WHERE cp_id=al_to_cp_id)
											   WHEN al_type=4 THEN (SELECT cp_mdprice FROM companyinfo WHERE cp_id=al_to_cp_id) END) END)supplytype,
		   (CASE WHEN al_ci_id>0 THEN (CASE WHEN al_type=1 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=all_gi_id AND 
																			   gd_type=ci_dhprice) FROM b_clientinfo WHERE ci_id=al_ci_id)
											WHEN al_type=2 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=all_gi_id AND 
																			   gd_type=ci_bhprice) FROM b_clientinfo WHERE ci_id=al_ci_id)
											WHEN al_type=3 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=all_gi_id AND 
																			   gd_type=ci_phprice) FROM b_clientinfo WHERE ci_id=al_ci_id)
											WHEN al_type=4 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=all_gi_id AND 
																			   gd_type=ci_mdprice) FROM b_clientinfo WHERE ci_id=al_ci_id) END)
				 WHEN al_sh_id>0 THEN (CASE WHEN al_type=1 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=all_gi_id AND 
																			   gd_type=sh_dhprice) FROM pos_shop WHERE sh_id=al_sh_id)
											WHEN al_type=2 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=all_gi_id AND 
																			   gd_type=sh_bhprice) FROM pos_shop WHERE sh_id=al_sh_id)
											WHEN al_type=3 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=all_gi_id AND 
																			   gd_type=sh_phprice) FROM pos_shop WHERE sh_id=al_sh_id)
											WHEN al_type=4 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=all_gi_id AND 
																			   gd_type=sh_mdprice) FROM pos_shop WHERE sh_id=al_sh_id) END)
				 WHEN al_to_cp_id>0 THEN (CASE WHEN al_type=1 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=all_gi_id AND 
																				  gd_type=cp_dhprice) FROM companyinfo WHERE cp_id=al_to_cp_id)
											   WHEN al_type=2 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=all_gi_id AND 
																				  gd_type=cp_bhprice) FROM companyinfo WHERE cp_id=al_to_cp_id)
											   WHEN al_type=3 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=all_gi_id AND 
																				  gd_type=cp_phprice) FROM companyinfo WHERE cp_id=al_to_cp_id)
											   WHEN al_type=4 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=all_gi_id AND 
																				  gd_type=cp_mdprice) FROM companyinfo WHERE cp_id=al_to_cp_id) END) END)supply,
		   al_vo,al_id,all_id,all_gi_id,all_sku_id,all_stock_price
	FROM pos_allocation 
	LEFT JOIN pos_allocationList ON al_id=all_al_id
	WHERE al_status=1 AND all_status>0 AND al_erp_id=@up_erp_id AND al_cp_id=@up_cp_id AND all_gi_id=@gi_id
	
	--更新前，将要修改的指定供货价类型的未审核单据的原价格存到"erp_priceHistory"
	INSERT INTO  erp_priceHistory(ph_order_vo,ph_order_id,ph_detail_id,ph_gi_id,ph_sku_id,ph_price,ph_type,ph_addtime,ph_addman,ph_erp_id)
	SELECT order_vo,order_id,detail_id,gi_id,sku_id,stock_price,1,@updateTime,@add_man,@up_erp_id 
	FROM @updateTable 
	WHERE @supplytype LIKE '%,'+supplytype+',%'
	
	--更新未审核单据的供货价
	UPDATE pos_allocationList
	SET all_stock_price=ut.supply,
		all_money=(ut.supply*all_num)
	FROM pos_allocationList AS pol, 
	    (SELECT * FROM @updateTable WHERE @supplytype LIKE '%,'+supplytype+',%') AS ut
	WHERE pol.all_id=ut.detail_id
	
	--更新主表的金额				
	UPDATE pos_allocation
	SET PHmoney = (SELECT SUM (all_money) FROM pos_allocationList  WITH (NOLOCK) WHERE all_al_id = al.al_id AND all_status > 0 )
	FROM pos_allocation AS al
	WHERE  al.al_id IN(SELECT order_id FROM @updateTable AS ut WHERE @supplytype LIKE '%,'+supplytype+',%')

	END
	/***************************** 配货单、客户退货通知单 *******************************/
	
	DELETE FROM @updateTable
		
	/******************************* 商品出库、出库退货 *********************************/
	BEGIN	
	--将指定商品的未审核单据的信息存到临时表中
	INSERT INTO @updateTable
	(
		supplytype,
		supply,
		order_vo,
		order_id,
		detail_id,
		gi_id,
		sku_id,
		stock_price
	)
	SELECT (CASE WHEN oo_ciid>0 THEN (CASE WHEN oo_jytype=1 THEN (SELECT ci_dhprice FROM b_clientinfo WHERE ci_id=oo_ciid)
											WHEN oo_jytype=2 THEN (SELECT ci_bhprice FROM b_clientinfo WHERE ci_id=oo_ciid)
											WHEN oo_jytype=3 THEN (SELECT ci_phprice FROM b_clientinfo WHERE ci_id=oo_ciid)
											WHEN oo_jytype=4 THEN (SELECT ci_mdprice FROM b_clientinfo WHERE ci_id=oo_ciid) END)
				 WHEN oo_sh_id>0 THEN (CASE WHEN oo_jytype=1 THEN (SELECT sh_dhprice FROM pos_shop WHERE sh_id=oo_sh_id)
											WHEN oo_jytype=2 THEN (SELECT sh_bhprice FROM pos_shop WHERE sh_id=oo_sh_id)
											WHEN oo_jytype=3 THEN (SELECT sh_phprice FROM pos_shop WHERE sh_id=oo_sh_id)
											WHEN oo_jytype=4 THEN (SELECT sh_mdprice FROM pos_shop WHERE sh_id=oo_sh_id) END)
				 WHEN oo_to_cp_id>0 THEN (CASE WHEN oo_jytype=1 THEN (SELECT cp_dhprice FROM companyinfo WHERE cp_id=oo_to_cp_id)
											   WHEN oo_jytype=2 THEN (SELECT cp_bhprice FROM companyinfo WHERE cp_id=oo_to_cp_id)
											   WHEN oo_jytype=3 THEN (SELECT cp_phprice FROM companyinfo WHERE cp_id=oo_to_cp_id)
											   WHEN oo_jytype=4 THEN (SELECT cp_mdprice FROM companyinfo WHERE cp_id=oo_to_cp_id) END) END)supplytype,
		   (CASE WHEN oo_ciid>0 THEN (CASE WHEN oo_jytype=1 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ol_siid AND 
																			   gd_type=ci_dhprice) FROM b_clientinfo WHERE ci_id=oo_ciid)
											WHEN oo_jytype=2 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ol_siid AND 
																			   gd_type=ci_bhprice) FROM b_clientinfo WHERE ci_id=oo_ciid)
											WHEN oo_jytype=3 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ol_siid AND 
																			   gd_type=ci_phprice) FROM b_clientinfo WHERE ci_id=oo_ciid)
											WHEN oo_jytype=4 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ol_siid AND 
																			   gd_type=ci_mdprice) FROM b_clientinfo WHERE ci_id=oo_ciid) END)
				 WHEN oo_sh_id>0 THEN (CASE WHEN oo_jytype=1 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ol_siid AND 
																			   gd_type=sh_dhprice) FROM pos_shop WHERE sh_id=oo_sh_id)
											WHEN oo_jytype=2 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ol_siid AND 
																			   gd_type=sh_bhprice) FROM pos_shop WHERE sh_id=oo_sh_id)
											WHEN oo_jytype=3 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ol_siid AND 
																			   gd_type=sh_phprice) FROM pos_shop WHERE sh_id=oo_sh_id)
											WHEN oo_jytype=4 THEN (SELECT (SELECT gd_price 
																		 FROM b_goods_discount 
																		 WHERE gd_class=2 AND 
																			   gd_gi_id=ol_siid AND 
																			   gd_type=sh_mdprice) FROM pos_shop WHERE sh_id=oo_sh_id) END)
				 WHEN oo_to_cp_id>0 THEN (CASE WHEN oo_jytype=1 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=ol_siid AND 
																				  gd_type=cp_dhprice) FROM companyinfo WHERE cp_id=oo_to_cp_id)
											   WHEN oo_jytype=2 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=ol_siid AND 
																				  gd_type=cp_bhprice) FROM companyinfo WHERE cp_id=oo_to_cp_id)
											   WHEN oo_jytype=3 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=ol_siid AND 
																				  gd_type=cp_phprice) FROM companyinfo WHERE cp_id=oo_to_cp_id)
											   WHEN oo_jytype=4 THEN (SELECT (SELECT gd_price 
																			FROM b_goods_discount 
																			WHERE gd_class=2 AND 
																				  gd_gi_id=ol_siid AND 
																				  gd_type=cp_mdprice) FROM companyinfo WHERE cp_id=oo_to_cp_id) END) END)supply,
		   oo_no,oo_id,ol_id,ol_siid,ol_skuid,ol_costprice
	FROM j_outStorage 
	LEFT JOIN j_outStorageList ON oo_id=ol_eoid
	WHERE oo_status=1 AND ol_status>0 AND oo_erp_id=@up_erp_id AND oo_cp_id=@up_cp_id AND ol_siid=@gi_id
	
	--更新前，将要修改的指定供货价类型的未审核单据的原价格存到"erp_priceHistory"
	INSERT INTO  erp_priceHistory(ph_order_vo,ph_order_id,ph_detail_id,ph_gi_id,ph_sku_id,ph_price,ph_type,ph_addtime,ph_addman,ph_erp_id)
	SELECT order_vo,order_id,detail_id,gi_id,sku_id,stock_price,1,@updateTime,@add_man,@up_erp_id 
	FROM @updateTable 
	WHERE @supplytype LIKE '%,'+supplytype+',%'
	
	--更新未审核单据的供货价
	UPDATE j_outStorageList
	SET ol_costprice=ut.supply,
		ol_realmoney=(ut.supply*ol_number)
	FROM j_outStorageList AS pol, 
	    (SELECT * FROM @updateTable WHERE @supplytype LIKE '%,'+supplytype+',%') AS ut
	WHERE pol.ol_id=ut.detail_id
	
	--更新主表的金额				
	UPDATE j_outStorage
	SET oo_realmoney = (SELECT SUM (ol_realmoney) FROM j_outStorageList  WITH (NOLOCK) WHERE ol_eoid = oo.oo_id AND ol_status > 0 )
	FROM j_outStorage AS oo
	WHERE  oo.oo_id IN(SELECT order_id FROM @updateTable AS ut WHERE @supplytype LIKE '%,'+supplytype+',%')

	END
	/******************************* 商品出库、出库退货 *********************************/
END

IF @@ERROR <> 0
	BEGIN
	    SET @result = 'false';

		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    SET @result = 'true';
	    
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END
go

