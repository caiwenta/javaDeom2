CREATE PROCEDURE [dbo].[pro_mergeStockBatchSum]
@id INT=0,
@stockType INT=0

AS

declare @erp_id int=0
declare @cp_id int=0;--公司id
declare @sei_id int=0;--仓库id
DECLARE @date DATETIME='1988-7-30';
DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
DECLARE @new_sei_id int=0;
DECLARE	@old_sei_id int=0;

BEGIN TRY

--入库
IF @stockType=1
BEGIN

 select 
 @erp_id=eo_erp_id, 
 @cp_id=eo_cp_id,
 @sei_id=eo_siid,
 @date=eo_entrydate
 from j_enterStorage where eo_id=@id;

  if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end


END

--出库
IF @stockType=2
BEGIN
 select 
 @erp_id=oo_erp_id, 
 @cp_id=oo_cp_id,
 @sei_id=oo_siid,
 @date=oo_entrydate
 from j_outStorage where oo_id=@id;

 if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end

END

--期初
IF @stockType=3
BEGIN
 select 
 @erp_id=in_erp_id, 
 @cp_id=in_cp_id,
 @sei_id=in_st_id,
 @date=in_date
 from j_initStorage where in_id=@id;

  if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end

END

--移仓
IF @stockType=4 OR @stockType=5
BEGIN

 select 
 @erp_id=mo_erp_id, 
 @cp_id=mo_cp_id,
 @old_sei_id=mo_out_st_id,
 @new_sei_id=mo_in_st_id,
 @date=mo_date
 from j_moStorage where mo_id=@id;

END

--盈亏
if @stockType=6
begin

 select 
 @erp_id=pl_erp_id, @cp_id=pl_cp_id,
 @sei_id=pl_st_id,
 @date=pl_date
 from j_plStorage where pl_id=@id;

  if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end

end


if @stockType=7 or  @stockType=8 or  @stockType=9 or  @stockType=10
begin

SELECT 
@erp_id=ts_erp_id,
@cp_id=ts_cp_id,
@sei_id=ts_st_id,
@date=ts_take_date
FROM j_takeStorage AS jts

end



DECLARE @now DATETIME = GETDATE();

SELECT DISTINCT js.sl_giid INTO #g FROM j_stocklog js WHERE js.sl_type=@stockType AND js.sl_eoid=@id;

MERGE INTO b_stockinfobatch AS ta 
USING 
(

SELECT 
js.sl_seiid AS [sid],
js.sl_giid AS gid,
isnull(js.sl_pm,'')   as pm,
js.sl_skuid AS skuid,
js.sl_cp_id AS  cp_id,
js.sl_boxbynum as boxbynum,
SUM(
	CASE WHEN sl_status>0 THEN 
	CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE - js.sl_number END
	ELSE 
	0
	END	
) AS gnum,
SUM(
	CASE WHEN sl_status>0 THEN 
	CASE WHEN js.sl_counttype=1 THEN js.sl_box_num ELSE - js.sl_box_num END
	ELSE 
	0
	END	
) AS sl_box_num
FROM j_stocklog js WHERE  js.sl_cp_id=@cp_id AND js.sl_giid
IN(SELECT sl_giid FROM #g)
Group By 
js.sl_seiid,
js.sl_giid,
js.sl_skuid,
js.sl_cp_id,
isnull(js.sl_pm,''),
js.sl_boxbynum

) AS so ON 
ta.si_seiid = so.[sid]  
AND ta.si_giid = so.gid 
AND ta.si_skuid = so.skuid 
AND ta.si_cp_id=so.cp_id 
AND ta.si_pm=so.pm
and ta.sl_boxbynum=so.boxbynum
WHEN matched THEN 
UPDATE SET 
ta.sl_box_num=so.sl_box_num,
ta.si_number = so.gnum,
ta.si_status=1,
ta.si_indate=case when  ta.si_number!=so.gnum then @now else ta.si_indate END
WHEN NOT matched THEN
INSERT 
  (
    si_seiid,
    si_giid,
    si_skuid,
    si_number,
    si_status,
    si_indate,
    si_cp_id,
	si_pm,
	sl_boxbynum,
	sl_box_num
  )
VALUES
  (
    so.[sid],
    so.gid,
    so.skuid,
    so.gnum,
    1,
    @now,
    so.cp_id,
	isnull(so.pm,''),
	so.boxbynum,
	sl_box_num
  );



delete b_stockinfobatchMergeColorSum where si_cp_id=@cp_id AND si_giid IN(SELECT sl_giid FROM #g)
INSERT INTO b_stockinfobatchMergeColorSum
           (si_seiid
           ,si_status
           ,si_number
           ,si_indate
           ,si_giid
           ,si_cp_id
           ,si_pm
           ,sl_boxbynum
           ,sl_box_num
           ,sl_color_id)
SELECT 
		sl.si_seiid,
		1,
		Sum(si_number)As gnum,
		MAX(sl.si_indate) AS addtime,
		sl.si_giid,
		sl.si_cp_id,
		isnull(si_pm,'') AS si_pm,
		sl.sl_boxbynum, 
		(CASE WHEN ISNULL(sl.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(Sum(si_number)/sl.sl_boxbynum) END)ol_box_num,
		isnull(bg.colorid,0) AS sl_colorid
FROM b_stockinfobatch AS sl
LEFT JOIN b_goodsruleset AS bg ON sl.si_skuid=bg.gss_id
where sl.si_cp_id=@cp_id AND si_giid IN(SELECT sl_giid FROM #g)
GROUP BY 
sl.si_seiid,
sl.si_giid,
sl.si_cp_id,
sl.sl_boxbynum,
isnull(si_pm,''),
isnull(bg.colorid,0)


delete b_stockinfobatchMergeSum where si_cp_id=@cp_id AND si_giid IN(SELECT sl_giid FROM #g)
INSERT INTO b_stockinfobatchMergeSum
           (si_seiid
           ,si_status
           ,si_number
           ,si_indate
           ,si_giid
           ,si_cp_id
           ,si_pm
           ,sl_boxbynum
           ,sl_box_num
           )
SELECT 
		sl.si_seiid,
		1,
		Sum(si_number)As gnum,
		MAX(sl.si_indate) AS addtime,
		sl.si_giid,
		sl.si_cp_id,
		isnull(si_pm,'') AS si_pm,
		sl.sl_boxbynum, 
		(CASE WHEN ISNULL(sl.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(Sum(si_number)/sl.sl_boxbynum) END)ol_box_num
FROM b_stockinfobatchMergeColorSum AS sl
where sl.si_cp_id=@cp_id AND si_giid IN(SELECT sl_giid FROM #g)
GROUP BY 
sl.si_seiid,
sl.si_giid,
sl.si_cp_id,
sl.sl_boxbynum,
isnull(si_pm,'')


DELETE b_stockinfobatchMergeRuleSum where si_cp_id=@cp_id AND si_giid IN(SELECT sl_giid FROM #g)
INSERT INTO b_stockinfobatchMergeRuleSum
(
cs_id,
num,
colorid,
ruleid,
si_cp_id,
si_giid
)
SELECT 
	ems.si_id,
	isnull(vi.gnum,0) as gnum,
	vi.sl_colorid AS colorid,
	vi.size AS gd_id,
	vi.si_cp_id AS si_cp_id,
	vi.si_giid
FROM (
	SELECT 
			sl.si_seiid,
			Sum(si_number)As gnum,
			MAX(sl.si_indate) AS addtime,
			sl.si_giid,
			sl.si_cp_id,
			isnull(si_pm,'') AS si_pm,
			sl.sl_boxbynum, 
			(CASE WHEN ISNULL(sl.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(Sum(si_number)/sl.sl_boxbynum) END)ol_box_num,
			isnull(bg.colorid,0) AS sl_colorid,
			ISNULL(bg.specid,0) AS size
		FROM b_stockinfobatch AS sl
		LEFT JOIN b_goodsruleset AS bg ON sl.si_skuid=bg.gss_id
		where sl.si_cp_id=@cp_id AND si_giid IN(SELECT sl_giid FROM #g)
		GROUP BY 
			sl.si_seiid,
			sl.si_giid,
			sl.si_cp_id,
			sl.sl_boxbynum,
			isnull(si_pm,''),
			isnull(bg.colorid,0),
			ISNULL(bg.specid,0)
) AS vi
INNER JOIN b_stockinfobatchMergeColorSum AS ems on 
vi.si_seiid=ems.si_seiid and vi.si_giid=ems.si_giid 
and vi.si_cp_id=ems.si_cp_id 
and vi.sl_colorid=ems.sl_color_id
and vi.si_pm=ems.si_pm
WHERE ems.si_cp_id=@cp_id AND ems.si_giid IN(SELECT sl_giid FROM #g)








DECLARE @tdoc_xml VARCHAR(max)= '';
SET @tdoc_xml = '{ 
"type":"' + CONVERT(VARCHAR(50), @stockType) + '",
"id":"' + CONVERT(VARCHAR(50), @id) + '",
"cp_id":"' + CONVERT(VARCHAR(50), @cp_id) + '", 
"negative_inventory":"' + CONVERT(VARCHAR(50), 0) + '", 
"old_sei_id":"' + CONVERT(VARCHAR(50), @old_sei_id) + '",
"new_sei_id":"' + CONVERT(VARCHAR(50), @new_sei_id) + '" }';

EXEC pro_apiqueue_op 
			@tdoc_target='storage',
			@tdoc_action='batchnumber',
			@tdoc_method = 'storage', 
			@tdoc_xml = @tdoc_xml, 
			@tdoc_erp_id =@erp_id, 
			@tdoc_state = 0;	


END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

