CREATE PROCEDURE [dbo].[pro_mergeStockBatchSum]
@id INT=0,
@stockType INT=0

AS

declare @erp_id int=0
declare @cp_id int=0;--公司id
declare @sei_id int=0;--仓库id
DECLARE @date DATETIME='1988-7-30';
DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
DECLARE @new_sei_id int=0;
DECLARE	@old_sei_id int=0;

BEGIN TRY

--入库
IF @stockType=1
BEGIN

 select 
 @erp_id=eo_erp_id, 
 @cp_id=eo_cp_id,
 @sei_id=eo_siid,
 @date=eo_entrydate
 from j_enterStorage where eo_id=@id;

  if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end


END

--出库
IF @stockType=2
BEGIN
 select 
 @erp_id=oo_erp_id, 
 @cp_id=oo_cp_id,
 @sei_id=oo_siid,
 @date=oo_entrydate
 from j_outStorage where oo_id=@id;

 if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end

END

--期初
IF @stockType=3
BEGIN
 select 
 @erp_id=in_erp_id, 
 @cp_id=in_cp_id,
 @sei_id=in_st_id,
 @date=in_date
 from j_initStorage where in_id=@id;

  if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end

END

--移仓
IF @stockType=4 OR @stockType=5
BEGIN

 select 
 @erp_id=mo_erp_id, 
 @cp_id=mo_cp_id,
 @old_sei_id=mo_out_st_id,
 @new_sei_id=mo_in_st_id,
 @date=mo_date
 from j_moStorage where mo_id=@id;

END

--盈亏
if @stockType=6
begin

 select 
 @erp_id=pl_erp_id, @cp_id=pl_cp_id,
 @sei_id=pl_st_id,
 @date=pl_date
 from j_plStorage where pl_id=@id;

  if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end

end


if @stockType=7 or  @stockType=8 or  @stockType=9 or  @stockType=10
begin

SELECT 
@erp_id=ts_erp_id,
@cp_id=ts_cp_id,
@sei_id=ts_st_id,
@date=ts_take_date
FROM j_takeStorage AS jts

end



DECLARE @now DATETIME = GETDATE();

SELECT DISTINCT js.sl_giid INTO #g FROM j_stocklog js WHERE js.sl_type=@stockType AND js.sl_eoid=@id;

MERGE INTO b_stockinfobatch AS ta 
USING 
(

SELECT 
js.sl_seiid AS [sid],
js.sl_giid AS gid,
isnull(js.sl_pm,'')   as pm,
js.sl_skuid AS skuid,
js.sl_cp_id AS  cp_id,
SUM(
	CASE WHEN sl_status>0 THEN 
	CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE - js.sl_number END
	ELSE 
	0
	END	
) AS gnum
FROM j_stocklog js WHERE  js.sl_cp_id=@cp_id AND js.sl_giid
IN(SELECT sl_giid FROM #g)
Group By 
js.sl_seiid,
js.sl_giid,
js.sl_skuid,
js.sl_cp_id,
isnull(js.sl_pm,'')

) AS so ON 
ta.si_seiid = so.[sid]  
AND ta.si_giid = so.gid 
AND ta.si_skuid = so.skuid 
AND ta.si_cp_id=so.cp_id 
AND ta.si_pm=so.pm
WHEN matched THEN 
UPDATE SET 
ta.si_number = so.gnum,
ta.si_status=1,
ta.si_indate=case when  ta.si_number!=so.gnum then @now else ta.si_indate END
WHEN NOT matched THEN
INSERT 
  (
    si_seiid,
    si_giid,
    si_skuid,
    si_number,
    si_status,
    si_indate,
    si_cp_id,
	si_pm
  )
VALUES
  (
    so.[sid],
    so.gid,
    so.skuid,
    so.gnum,
    1,
    @now,
    so.cp_id,
	isnull(so.pm,'')
  );



DECLARE @tdoc_xml VARCHAR(max)= '';
SET @tdoc_xml = '{ 
"type":"' + CONVERT(VARCHAR(50), @stockType) + '",
"id":"' + CONVERT(VARCHAR(50), @id) + '",
"cp_id":"' + CONVERT(VARCHAR(50), @cp_id) + '", 
"negative_inventory":"' + CONVERT(VARCHAR(50), 0) + '", 
"old_sei_id":"' + CONVERT(VARCHAR(50), @old_sei_id) + '",
"new_sei_id":"' + CONVERT(VARCHAR(50), @new_sei_id) + '" }';

EXEC pro_apiqueue_op 
			@tdoc_target='storage',
			@tdoc_action='batchnumber',
			@tdoc_method = 'storage', 
			@tdoc_xml = @tdoc_xml, 
			@tdoc_erp_id =@erp_id, 
			@tdoc_state = 0;	


END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

