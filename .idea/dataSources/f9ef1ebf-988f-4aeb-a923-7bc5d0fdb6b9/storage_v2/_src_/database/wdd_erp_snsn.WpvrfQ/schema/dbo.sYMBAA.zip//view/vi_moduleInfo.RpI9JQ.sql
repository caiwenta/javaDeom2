CREATE VIEW [dbo].[vi_moduleInfo] AS 
select * from s_pageInfo as spi where spi.pi_parentid=0 and spi.pi_status=1
go

