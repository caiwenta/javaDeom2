CREATE PROCEDURE [dbo].[pro_mergeStockLogSum]
    @cp_id INT=0,
	@orderid INT=0,
	@stockType INT=0
AS

BEGIN

INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'汇总变动明细',20 ,'开始生成汇总变动明细',@orderid);

print N'开始生成库存变动明细';

DELETE j_stocklog_MergeColorSum WHERE sl_eoid=(CASE WHEN @orderid>0 THEN @orderid ELSE sl_eoid END) 
                                  AND sl_cp_id=(CASE WHEN @cp_id>0 THEN @cp_id ELSE sl_cp_id END) 
                                  AND sl_type=(CASE WHEN @stockType>0 THEN @stockType ELSE sl_type END)

INSERT INTO j_stocklog_MergeColorSum
(
	sl_eoid,
	sl_seiid, 
	sl_ciid, 
	sl_giid, 
	sl_color_id, 
	
	sl_addtime, 
	sl_updatetime, 
	sl_deltime, 
	sl_order_no, 
	sl_order_date, 
	sl_order_add_time, 
	sl_remark, 
	sl_status,
	sl_cp_id, 
	sl_erp_id,
	
	sl_type,
	sl_counttype, 
	sl_number, 
	sl_pm, 
	sl_boxbynum, 
	sl_box_num
)
SELECT jsl.sl_eoid, 
       jsl.sl_seiid, 
       jsl.sl_ciid, 
       jsl.sl_giid,
       jsl.colorid, 
       
       MAX(jsl.sl_addtime)sl_addtime, 
       MAX(jsl.sl_updatetime)sl_updatetime, 
       MAX(jsl.sl_deltime)sl_deltime,
       jsl.sl_order_no, 
       MAX(jsl.sl_order_date)sl_order_date, 
       MAX(jsl.sl_order_add_time)sl_order_add_time, 
       jsl.sl_remark,
       jsl.sl_status, 
       jsl.sl_cp_id, 
       jsl.sl_erp_id, 
       
       jsl.sl_type, 
       jsl.sl_counttype,
       SUM(jsl.sl_number)sl_number, 
       ISNULL(jsl.sl_pm,'')sl_pm, 
       jsl.sl_boxbynum, 
       (CASE WHEN ISNULL(jsl.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(SUM(jsl.sl_number)/jsl.sl_boxbynum) END)sl_box_num
FROM (
	SELECT sl.sl_eoid, 
	       sl.sl_seiid, 
	       sl.sl_ciid,
	       sl.sl_giid, 
	       ISNULL(grl.colorid,0) as colorid,
	       
	       sl.sl_addtime,
	       sl.sl_updatetime,
	       sl.sl_deltime, 
	       sl.sl_order_no, 
	       sl.sl_order_date, 
	       sl.sl_order_add_time,
	       sl.sl_remark, 
	       sl.sl_status, 
	       sl.sl_cp_id, 
	       sl.sl_erp_id, 
	       
	       sl.sl_type, 
	       sl.sl_counttype, 
	       ISNULL(sl.sl_number,0)sl_number, 
	       ISNULL(sl.sl_pm,'')sl_pm, 
	       sl.sl_boxbynum
	FROM j_stocklog AS sl 
	LEFT JOIN b_goodsruleset as grl on grl.gss_id=sl.sl_skuid AND grl.gs_status>0
	WHERE sl_eoid=(CASE WHEN @orderid>0 THEN @orderid ELSE sl_eoid END) 
      AND sl_cp_id=(CASE WHEN @cp_id>0 THEN @cp_id ELSE sl_cp_id END) 
      AND sl_type=(CASE WHEN @stockType>0 THEN @stockType ELSE sl_type END)
) AS jsl
GROUP BY jsl.sl_eoid, jsl.sl_seiid, jsl.sl_ciid, jsl.sl_giid,
      jsl.colorid, jsl.sl_order_no, jsl.sl_remark, jsl.sl_status, jsl.sl_cp_id,
      jsl.sl_erp_id, jsl.sl_type, jsl.sl_counttype, jsl.sl_pm, jsl.sl_boxbynum

DELETE j_stocklog_MergeSum WHERE sl_eoid=(CASE WHEN @orderid>0 THEN @orderid ELSE sl_eoid END) 
                             AND sl_cp_id=(CASE WHEN @cp_id>0 THEN @cp_id ELSE sl_cp_id END) 
                             AND sl_type=(CASE WHEN @stockType>0 THEN @stockType ELSE sl_type END)

INSERT INTO j_stocklog_MergeSum
(
	sl_eoid,
	sl_elid, 
	sl_seiid, 
	sl_ciid, 
	sl_giid, 
	
	sl_addtime, 
	sl_updatetime, 
	sl_deltime, 
	sl_order_no, 
	sl_order_date, 
	sl_order_add_time, 
	sl_remark, 
	sl_status,
	sl_cp_id, 
	sl_erp_id,
	
	sl_type,
	sl_counttype, 
	sl_number, 
	sl_pm, 
	sl_boxbynum, 
	sl_box_num
)
SELECT jsl.sl_eoid, 
       jsl.sl_elid, 
       jsl.sl_seiid, 
       jsl.sl_ciid, 
       jsl.sl_giid,
       
       MAX(jsl.sl_addtime)sl_addtime, 
       MAX(jsl.sl_updatetime)sl_updatetime, 
       MAX(jsl.sl_deltime)sl_deltime,
       jsl.sl_order_no, 
       MAX(jsl.sl_order_date)sl_order_date, 
       MAX(jsl.sl_order_add_time)sl_order_add_time, 
       jsl.sl_remark,
       jsl.sl_status, 
       jsl.sl_cp_id, 
       jsl.sl_erp_id, 
       
       jsl.sl_type, 
       jsl.sl_counttype,
       SUM(jsl.sl_number)sl_number, 
       ISNULL(jsl.sl_pm,'')sl_pm, 
       jsl.sl_boxbynum, 
       (CASE WHEN ISNULL(jsl.sl_boxbynum,0)=0 THEN 0 ELSE CEILING(SUM(jsl.sl_number)/jsl.sl_boxbynum) END)sl_box_num
FROM (
	SELECT sl.sl_eoid, 
	       sl.sl_elid, 
	       sl.sl_seiid, 
	       sl.sl_ciid,
	       sl.sl_giid, 
	       
	       sl.sl_addtime,
	       sl.sl_updatetime,
	       sl.sl_deltime, 
	       sl.sl_order_no, 
	       sl.sl_order_date, 
	       sl.sl_order_add_time,
	       sl.sl_remark, 
	       sl.sl_status, 
	       sl.sl_cp_id, 
	       sl.sl_erp_id, 
	       
	       sl.sl_type, 
	       sl.sl_counttype, 
	       ISNULL(sl.sl_number,0)sl_number, 
	       sl.sl_pm, 
	       sl.sl_boxbynum
	FROM j_stocklog_MergeColorSum AS sl 
	WHERE sl_eoid=(CASE WHEN @orderid>0 THEN @orderid ELSE sl_eoid END) 
      AND sl_cp_id=(CASE WHEN @cp_id>0 THEN @cp_id ELSE sl_cp_id END) 
      AND sl_type=(CASE WHEN @stockType>0 THEN @stockType ELSE sl_type END)
) AS jsl
GROUP BY jsl.sl_eoid, jsl.sl_elid, jsl.sl_seiid, jsl.sl_ciid, jsl.sl_giid,
      jsl.sl_order_no, jsl.sl_remark, jsl.sl_status, jsl.sl_cp_id,
      jsl.sl_erp_id, jsl.sl_type, jsl.sl_counttype, jsl.sl_pm, jsl.sl_boxbynum

DELETE j_stocklog_MergeRuleSum WHERE sl_eoid=(CASE WHEN @orderid>0 THEN @orderid ELSE sl_eoid END) 
                                 AND sl_cp_id=(CASE WHEN @cp_id>0 THEN @cp_id ELSE sl_cp_id END) 
                                 AND sl_type=(CASE WHEN @stockType>0 THEN @stockType ELSE sl_type END)
                             
INSERT INTO j_stocklog_MergeRuleSum
(
	cs_id,
	num,
	colorid,
	ruleid,
	sl_eoid,
	sl_type,
	sl_cp_id
)
SELECT ems.slmcs_id,
	   vi.sl_number,
	   vi.colorid,
	   vi.ruleid,
	   vi.sl_eoid,
	   vi.sl_type,
	   vi.sl_cp_id
FROM (
	SELECT jsl.sl_eoid, 
           jsl.sl_giid,
           jsl.colorid, 
           jsl.ruleid, 
           jsl.sl_cp_id, 
           jsl.sl_erp_id, 
		   jsl.sl_type, 
           ISNULL(jsl.sl_pm,'')sl_pm, 
           SUM(jsl.sl_number)sl_number
    FROM (
		SELECT sl.sl_eoid, 
			   sl.sl_elid, 
			   sl.sl_seiid, 
			   sl.sl_ciid,
			   sl.sl_giid, 
			   ISNULL(grl.colorid,0) as colorid,
			   ISNULL(grl.specid,0) as ruleid,
		       
			   sl.sl_addtime,
			   sl.sl_updatetime,
			   sl.sl_deltime, 
			   sl.sl_order_no, 
			   sl.sl_order_date, 
			   sl.sl_order_add_time,
			   sl.sl_remark, 
			   sl.sl_status, 
			   sl.sl_cp_id, 
			   sl.sl_erp_id, 
		       
			   sl.sl_type, 
			   sl.sl_counttype, 
			   ISNULL((CASE WHEN sl_counttype=1 THEN sl_number ELSE -sl_number END),0) AS sl_number, 
			   ISNULL(sl.sl_pm,0)sl_pm, 
			   sl.sl_boxbynum
		FROM j_stocklog AS sl 
		LEFT JOIN b_goodsruleset as grl on grl.gss_id=sl.sl_skuid AND grl.gs_status>0
		WHERE sl_eoid=(CASE WHEN @orderid>0 THEN @orderid ELSE sl_eoid END) 
		  AND sl_cp_id=(CASE WHEN @cp_id>0 THEN @cp_id ELSE sl_cp_id END) 
		  AND sl_type=(CASE WHEN @stockType>0 THEN @stockType ELSE sl_type END)
	) AS jsl
    GROUP BY jsl.sl_eoid,jsl.sl_type, jsl.sl_giid,jsl.colorid, jsl.ruleid, jsl.sl_cp_id, jsl.sl_erp_id, jsl.sl_pm
) AS vi
INNER JOIN j_stocklog_MergeColorSum AS ems 
on vi.sl_eoid=ems.sl_eoid AND vi.sl_type=ems.sl_type AND vi.sl_giid=ems.sl_giid AND vi.colorid=ems.sl_color_id AND vi.sl_pm=ems.sl_pm
WHERE vi.sl_number<>0 AND ems.sl_eoid=(CASE WHEN @orderid>0 THEN @orderid ELSE ems.sl_eoid END) 
                      AND ems.sl_cp_id=(CASE WHEN @cp_id>0 THEN @cp_id ELSE ems.sl_cp_id END) 
                      AND ems.sl_type=(CASE WHEN @stockType>0 THEN @stockType ELSE ems.sl_type END)


INSERT INTO dbo.s_operate_log (ol_addtime,ol_remark,ol_operatetype,ol_sys_remark,ol_erp_id) VALUES(GETDATE(),'汇总变动明细',20 ,'生成汇总变动明细成功',@orderid);


END
go

