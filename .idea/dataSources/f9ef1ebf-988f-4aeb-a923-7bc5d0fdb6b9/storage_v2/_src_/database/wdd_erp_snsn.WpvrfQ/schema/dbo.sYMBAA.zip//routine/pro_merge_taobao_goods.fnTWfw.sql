CREATE Proc [dbo].[pro_merge_taobao_goods]
@oc_id int,
@timestamp datetime,
@result int out
as
begin tran
	/*******************************************
	 * 
	 * stuff_status
	 * 
	 * 商品新旧程度(全新:new，闲置:unused，二手：second)
	 * 
	 * approve_status
	 * 商品上传后的状态。onsale出售中，instock库中
	 * 
	 *******************************************/

declare @now datetime=getdate();
--品牌
--
--merge into s_goodsbrand as ta
--using (select * from s_goodsbrand_merge as so where so.gb_oc_id=@oc_id and so.gb_timestamp=@timestamp) as so
--on ta.gb_oc_id=so.gb_oc_id and ta.gb_type_id=so.gb_type_id  
--when matched then update set ta.gb_name=so.gb_name,ta.gb_url=so.gb_url,ta.gb_logo=so.gb_logo,ta.gb_sort=so.gb_sort,ta.gb_txt=so.gb_txt,ta.gb_updatetime=@now
--when not matched then insert (gb_name, gb_url, gb_logo, gb_sort, gb_txt, gb_type_id, gb_addtime, gb_updatetime, gb_oc_id)values(so.gb_name,so.gb_url,so.gb_logo,so.gb_sort,so.gb_txt,so.gb_type_id,@now,@now,so.gb_oc_id);


--商品分类
--父级
--得先添加
--还得判断能不能加
--merge into s_goodsclass as ta
--using (select * from s_goodsclass_merge as so where so.gc_oc_id=@oc_id and so.gc_timestamp=@timestamp) as so
--on ta.gc_oc_id=so.gc_oc_id and ta.gc_type_id=so.gc_type_id  
--when matched then update set ta.gc_name=so.gc_name,ta.gs_name=so.gs_name,ta.gs_id=so.gs_id,ta.gc_img=so.gc_img,ta.gc_priceterm=so.gc_priceterm,ta.gc_sort=so.gc_sort,ta.gc_keys=so.gc_keys,ta.gc_description=so.gc_description,ta.mid=so.mid,ta.gc_status=so.gc_status,ta.gc_type=so.gc_type,ta.gc_type_id=so.gc_type_id,ta.gc_type_id_parentid=so.gc_type_id_parentid,ta.gc_addtime=so.gc_addtime,ta.gc_updatetime=so.gc_updatetime,ta.gc_oc_id=so.gc_oc_id
--when not matched then insert(gc_name,gs_name,gs_id,gc_img,gc_priceterm,gc_sort,gc_keys,gc_description,mid,gc_status,gc_type,gc_type_id,gc_type_id_parentid,gc_addtime,gc_updatetime,gc_oc_id)values(so.gc_name,so.gs_name,so.gs_id,so.gc_img,so.gc_priceterm,so.gc_sort,so.gc_keys,so.gc_description,so.mid,so.gc_status,so.gc_type,so.gc_type_id,so.gc_type_id_parentid,so.gc_addtime,so.gc_updatetime,so.gc_oc_id);
                      	
                    
--父级分类更新
--

--父级id
--select sg.gc_id,sg.gc_type_id from s_goodsclass as sg where sg.gc_oc_id=@oc_id
--and sg.gc_type_id_parentid=0

--update s_goodsclass
--set gc_fid = (
--select sg.gc_id from s_goodsclass as sg	where sg.gc_oc_id=@oc_id and sg.gc_type_id=gc_type_id_parentid
--) where gc_oc_id=@oc_id;

--select * from s_goodsclass as sg

--通过微商城id,店铺id可以确认
--更新父级id
--select sg.gc_id,p1.gc_id as fid from s_goodsclass as sg 
--inner join (
--select sg.gc_id,sg.gc_type_id,sg.gc_type_id_parentid,sg.gc_oc_id
--  from s_goodsclass as sg 
--) as p1 on sg.gc_type_id_parentid=p1.gc_type_id and sg.gc_oc_id=p1.gc_oc_id
--where sg.gc_type_id is not null and sg.gc_type_id_parentid is not null and sg.gc_type_id_parentid>0 






--规格
--
--merge into s_goodsrule as ta
--using (select * from  s_goodsrule_merge as so where so.gs_oc_id=@oc_id and so.gs_timestamp=@timestamp) as so
--on ta.gs_oc_id=so.gs_oc_id and ta.gs_class_id=so.gs_class_id 
--when matched then update set  ta.gs_fid=so.gs_fid,ta.gs_name=so.gs_name,ta.gs_type=so.gs_type,ta.gs_sort=so.gs_sort,ta.gs_remark=so.gs_remark,ta.gs_values=so.gs_values,ta.mid=so.mid,ta.gs_class=so.gs_class,ta.gs_class_id=so.gs_class_id,ta.gs_updatetime=@now,ta.gs_oc_id=so.gs_oc_id
--when not matched then insert(gs_fid,gs_name,gs_type,gs_sort,gs_remark,gs_values,mid,gs_class,gs_class_id,gs_addtime,gs_updatetime,gs_oc_id)values(so.gs_fid,so.gs_name,so.gs_type,so.gs_sort,so.gs_remark,so.gs_values,so.mid,so.gs_class,so.gs_class_id,@now,@now,so.gs_oc_id);
    
      


--规格明细
--
--merge into s_goodsruledetail as ta
--using (select * from s_goodsruledetail_merge as so where so.gd_oc_id=@oc_id and so.gd_timestamp=@timestamp)as so
--on ta.gd_oc_id=so.gd_oc_id and ta.gd_type_id=so.gd_type_id  
--when matched then update set ta.gd_name=so.gd_name,ta.dg_img=so.dg_img,ta.dg_sort=so.dg_sort,ta.gd_code=so.gd_code,ta.gd_type=so.gd_type,ta.gd_type_id_parentid=so.gd_type_id_parentid,ta.gd_type_id=so.gd_type_id,ta.gd_updatetime=@now,ta.gd_oc_id=so.gd_oc_id
--when not matched then insert(gd_name,dg_img,dg_sort,gd_code,gd_type,gd_type_id_parentid,gd_type_id,gd_addtime,gd_updatetime,gd_oc_id)values(so.gd_name,so.dg_img,so.dg_sort,so.gd_code,so.gd_type,so.gd_type_id_parentid,so.gd_type_id,@now,@now,so.gd_oc_id);



--update s_goodsruledetail
--set gs_id = (
--	select sg.gs_id
--	  from s_goodsrule as sg where sg.gs_oc_id=@oc_id and sg.gs_class_id=gd_type_id_parentid
--) where gd_oc_id=@oc_id;

--select * from s_goodsruledetail



--商品
merge into b_goodsinfo as ta
using (select * from taobao_Item as so where so.sys_oc_id=@oc_id and so.sys_timestamp=@timestamp) as so 
on ta.gi_tid=so.num_iid and ta.gi_oc_id=@oc_id
when matched then update set 
ta.gi_taobao_id=so.taobao_id,
ta.gi_updatetime=@now,
-------------------匹配
ta.gi_shortname=so.sub_title,
ta.gi_name=so.title,
--ta.gi_status=so.approve_status,
--ta.gi_barcode=so.barcode,
ta.gi_costprice=so.price,
ta.gi_importprices=so.price,
ta.gi_number=so.num,
ta.gi_retailprice=so.price,
ta.gi_weight=so.item_weight
when not matched then insert(
gi_addtime,
gi_updatetime,
gi_oc_id,
gi_tid,	
gi_code,
gi_taobao_id,
-------------------匹配
gi_shortname,
gi_name,
gi_status,
gi_barcode,
gi_costprice,
gi_importprices,
gi_number,
gi_retailprice,
gi_weight
)values(
@now,
@now,
@oc_id,
so.num_iid,
dbo.fn_getGoodsCode(),
so.taobao_id,
-------------------匹配
so.sub_title,
so.title,
1,--状态		商品上传后的状态。onsale出售中，instock库中
--so.approve_status,
--so.barcode,
dbo.fn_getGoodsCode(),
--newid(),
so.price,
so.price,
so.num,
so.price,
so.item_weight
);



--商品规格
merge into b_goodsruleset as ta
using(select * from taobao_Sku as so where so.sys_oc_id=@oc_id and so.sys_timestamp=@timestamp) as so
on ta.gs_oc_id=@oc_id and ta.gs_type_id=so.sku_id
when matched then update set
ta.gs_updatetime=@now,
ta.gs_taobao_id=so.taobao_id,
-------------------匹配
--ta.gss_no=so.barcode,
ta.gs_id=so.properties,
ta.gs_name=so.properties_name,
ta.gs_stock=so.quantity,
ta.gs_salesprice=so.price,
ta.gs_marketprice=so.price,
ta.gs_costprice=so.price,
ta.gs_purchase=so.price
when not matched then insert (
gs_addtime,
gs_updatetime,
gs_taobao_id,
gs_type_id,
gs_type_id_parentid,
gs_oc_id,
-------------------匹配
gss_no,
gs_id,
gs_name,
gs_stock,
gs_salesprice,
gs_marketprice,
gs_costprice,
gs_purchase
)values(
@now,
@now,
so.taobao_id,
so.sku_id,
so.num_iid,
@oc_id,
-------------------匹配
--so.barcode,
newid(),
so.properties,
so.properties_name,
so.quantity,
so.price,
so.price,
so.price,
so.price	
);




update b_goodsruleset
set gi_id = (
	select bg.gi_id from b_goodsinfo as bg where bg.gi_oc_id=@oc_id and bg.gi_tid=gs_type_id_parentid
) where gs_oc_id=@oc_id;

if @@ERROR<>0
BEGIN
	set @result=0;

	IF @@TRANCOUNT > 0 rollback tran;
end
else
	BEGIN
		set @result=1;
		IF @@TRANCOUNT > 0 commit tran
	END
go

