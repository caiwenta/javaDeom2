


CREATE PROC [dbo].[pro_pos_takeStorageLog_op]
--主键
@tsl_id INT = 0,
--店铺主键
@tsl_erp_id INT = 0,
@tsl_sh_id INT = 0,
--仓库主键
@tsl_st_id INT = 0,
--盘点日期
@tsl_date DATETIME = '2014-11-03',
--盘点类型1,整仓盘点:2,部分盘点
@tsl_type INT = 0,
--添加人主键
@tsl_add_man INT = 0,
--添加时间
@tsl_add_time DATETIME = '2014-11-03',
--修改人主键
@tsl_update_man INT = 0,
--修改时间
@tsl_update_time DATETIME = '2014-11-03',
--删除人主键
@tsl_del_man INT = 0,
--删除时间
@tsl_del_time DATETIME = '2014-11-03',
--备注
@tsl_remark VARCHAR(50) = '',
--操作类型  
@op_type VARCHAR(100) = '添加',  

@negative_inventory INT=0,
--结果  
@result VARCHAR(100) = '' OUT
AS


BEGIN
	BEGIN TRAN
	
	IF @op_type = '添加'
	BEGIN
	    IF EXISTS(
	           SELECT *
	           FROM   pos_takeStorageLog AS jt
	           WHERE  jt.tsl_status = 1
	                  AND jt.tsl_st_id = @tsl_st_id
	                  AND jt.tsl_sh_id = @tsl_sh_id
	                  AND jt.tsl_date = @tsl_date
	       )
	    BEGIN
	        SET @result = '当前日期与仓库已经存在盘点准备记录，不可重复操作！';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN
	        RETURN 1;
	    END
	    
	    IF EXISTS(
	           SELECT *
	           FROM   pos_takeStorageLog AS jt
	           WHERE  jt.tsl_status = 1
	                  AND jt.tsl_st_id = @tsl_st_id
	                  AND jt.tsl_sh_id = @tsl_sh_id
	       )
	    BEGIN
	        SET @result = '当前仓库存在未完成的盘点单，请盘点完成再来进行操作！';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN
	        RETURN 1;
	    END
	    
	    
	    DECLARE @last_tsl_date DATETIME;
	    SELECT TOP 1 @last_tsl_date = jtsl.tsl_date
	    FROM   pos_takeStorageLog AS jtsl
	    WHERE  jtsl.tsl_status = 2
	           AND jtsl.tsl_st_id = @tsl_st_id
	    ORDER BY
	           jtsl.tsl_id DESC
	    
	    DECLARE @last_tsl_date_var VARCHAR(50)
	            = CONVERT(VARCHAR(50), @last_tsl_date, 23);
	    IF @tsl_date <= @last_tsl_date
	    BEGIN
	        SET @result = '盘点准备失败.<br/>最后一次的盘点日期为[' + @last_tsl_date_var
	            + '],在' + @last_tsl_date_var + '之前的库存已锁定!<br/>';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN
	        RETURN 1;
	    END
	    
	    
	    INSERT INTO pos_takeStorageLog
	      (
	        tsl_sh_id,
	        tsl_st_id,
	        tsl_date,
	        tsl_status,
	        tsl_type,
	        tsl_add_man,
	        tsl_add_time,
	        tsl_update_man,
	        tsl_update_time,
	        tsl_remark,tsl_erp_id
	      )
	    VALUES
	      (
	        @tsl_sh_id,
	        @tsl_st_id,
	        @tsl_date,
	        1,
	        @tsl_type,
	        @tsl_add_man,
	        @tsl_add_time,
	        @tsl_update_man,
	        @tsl_update_time,
	        @tsl_remark,@tsl_erp_id
	      );
	    SET @tsl_id = SCOPE_IDENTITY();
	END
	
	IF @op_type = '修改'
	BEGIN
	    IF NOT EXISTS (
	           SELECT *
	           FROM   pos_takeStorage AS jt
	           WHERE  (jt.ts_status = 1 OR jt.ts_status = 2)
	                  AND jt.ts_st_id = @tsl_st_id
	                  AND jt.ts_sh_id = @tsl_sh_id
	                  AND jt.ts_take_date = @tsl_date
	       )
	    BEGIN
	        SET @result = '没有相应的盘点单据!';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN
	        RETURN 1;
	    END
	    
	    
	    IF EXISTS(
	           SELECT *
	           FROM   pos_takeStorage AS jt
	           WHERE  jt.ts_status = 1
	                  AND jt.ts_st_id = @tsl_st_id
	                  AND jt.ts_sh_id = @tsl_sh_id
	                  AND jt.ts_take_date = @tsl_date
	       )
	    BEGIN
	        SET @result = '存在未审核的盘点单据!';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN
	        RETURN 1;
	    END
	    
	    
	    IF NOT EXISTS (
	           SELECT *
	           FROM   pos_takeStorageLog AS jt
	           WHERE  jt.tsl_st_id = @tsl_st_id
	                  AND jt.tsl_sh_id = @tsl_sh_id
	                  AND jt.tsl_date = @tsl_date
	                  AND jt.tsl_status = 1
	       )
	    BEGIN
	        SET @result = 
	            '没有处于盘点准备状态的盘点记录!<br/>1.盘点准备.2.盘点录入.3.库存确认.';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN
	        RETURN 1;
	    END
	    
	    
	    DECLARE @count INT = 0;
	    SELECT @count = COUNT(1)
	    FROM   pos_takeStorageLog AS jt
	    WHERE  jt.tsl_st_id = @tsl_st_id
	           AND jt.tsl_sh_id = @tsl_sh_id
	           AND jt.tsl_date = @tsl_date
	           AND jt.tsl_status = 1;
	    IF @count > 1
	    BEGIN
	        SET @result = '存在多条的盘点准备记录!';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	        RETURN 1;
	    END
	    
	    
	    SELECT @tsl_id = jt.tsl_id
	    FROM   pos_takeStorageLog AS jt
	    WHERE  jt.tsl_st_id = @tsl_st_id
	           AND jt.tsl_sh_id = @tsl_sh_id
	           AND jt.tsl_date = @tsl_date
	           AND jt.tsl_status = 1;
	    
	    
	    UPDATE pos_takeStorage
	    SET    ts_tsl_id = @tsl_id
	    WHERE  ts_st_id = @tsl_st_id
	           AND ts_sh_id = @tsl_sh_id
	           AND ts_take_date = @tsl_date
	           AND ts_status = 2 ;
	    
	    
	    DECLARE @ts_vo VARCHAR(50) = '';
	    SELECT TOP 1 @ts_vo = jts.ts_vo
	    FROM   pos_takeStorage AS jts
	    WHERE  jts.ts_tsl_id = @tsl_id
	           AND jts.ts_status > 0;
	    
	    
	    
	    
	    SET @tsl_update_time = GETDATE();
	    
	    
	    UPDATE pos_takeStorageLog
	    SET    tsl_status = 2,
	           tsl_type = @tsl_type,
	           tsl_update_man = @tsl_update_man,
	           tsl_update_time = @tsl_update_time
	    WHERE  tsl_id = @tsl_id;
	    
	    SELECT @tsl_add_time = jtsl.tsl_add_time
	    FROM   pos_takeStorageLog AS jtsl
	    WHERE  jtsl.tsl_id = @tsl_id;

	   
	

	    IF @tsl_type = 1
	    BEGIN
		   
			

		    --获取当前没有盘点到的商品
	        INSERT INTO pos_stocklog_pal
	          (
	            sl_seiid,
	            sl_shid,
	            sl_giid,
	            sl_skuid,
	            sl_counttype,
	            sl_number,
				sl_takenum,
	            sl_addtime,
	            sl_remark,
	            sl_status,
	            sl_order_date,
	            sl_order_add_time,
	            sl_eoid,
	            sl_elid,
	            sl_ciid,
	            sl_type,
	            sl_order_no,
				sl_erp_id,
				sl_pm
	          )
	        SELECT p1.sl_seiid,
	               p1.sl_shop_id,
	               p1.sl_giid,
	               p1.sl_skuid,
	               count_type = CASE 
	                                 WHEN p1.sl_number > 0 THEN 0
	                                 ELSE 1
	                            END,
	               ABS(p1.sl_number),
				   0,
	               DATEADD(
	                   second,
	                   58,
	                   DATEADD(minute, 59, DATEADD(hour, 23, @tsl_date))
	               ),
	               '整仓盘点盈亏调整',
	               2,
	               @tsl_date,
	               @tsl_add_time,
	               @tsl_id,
	               @tsl_id,
	               0,
	               7,
	               @ts_vo,
				   @tsl_erp_id,
				   p1.sl_pm
	        FROM   (
	                   SELECT js.sl_seiid,
	                          js.sl_shop_id,
	                          js.sl_giid,
	                          js.sl_skuid,
							  isnull(js.sl_pm,'') as sl_pm,
	                          SUM(
	                              CASE 
	                                   WHEN js.sl_counttype = 1 THEN js.sl_number
	                                   ELSE -js.sl_number
	                              END
	                          ) AS sl_number
	                   FROM   pos_stocklog AS js
	                   WHERE  js.sl_seiid = @tsl_st_id
	                          AND js.sl_shop_id = @tsl_sh_id
	                          
	                          AND (CONVERT(VARCHAR(50), js.sl_order_date, 23) <= @tsl_date OR js.sl_type =11 )
	                          AND js.sl_number != 0
	                          AND js.sl_status!=0
	                   GROUP BY
	                          js.sl_seiid,
	                          js.sl_shop_id,
	                          js.sl_giid,
	                          js.sl_skuid,
							  isnull(js.sl_pm,'')
	               ) AS p1 

	        INSERT INTO pos_stocklog
	          (
	            sl_seiid,
	            sl_shop_id,
	            sl_giid,
	            sl_skuid,
	            sl_counttype,
	            sl_number,
	            sl_addtime,
	            sl_remark,
	            sl_status,
	            sl_order_date,
	            sl_order_add_time,
	            sl_eoid,
	            sl_elid,
	            sl_ciid,
	            sl_type,
	            sl_order_no,
				sl_erp_id,
				sl_pm
	          )
	        SELECT p1.sl_seiid,
	               p1.sl_shop_id,
	               p1.sl_giid,
	               p1.sl_skuid,
	               count_type = CASE 
	                                 WHEN p1.sl_number > 0 THEN 0
	                                 ELSE 1
	                            END,
	               ABS(p1.sl_number),
	               DATEADD(
	                   second,
	                   58,
	                   DATEADD(minute, 59, DATEADD(hour, 23, @tsl_date))
	               ),
	               '整仓盘点盈亏调整',
	               2,
	               @tsl_date,
	               @tsl_add_time,
	               @tsl_id,
	               @tsl_id,
	               0,
	               7,
	               @ts_vo,
				   @tsl_erp_id,
				   p1.sl_pm
	        FROM   (
	                   SELECT js.sl_seiid,
	                          js.sl_shop_id,
	                          js.sl_giid,
	                          js.sl_skuid,
							  isnull(js.sl_pm,'') as sl_pm,
	                          SUM(
	                              CASE 
	                                   WHEN js.sl_counttype = 1 THEN js.sl_number
	                                   ELSE -js.sl_number
	                              END
	                          ) AS sl_number
	                   FROM   pos_stocklog AS js
	                   WHERE  js.sl_seiid = @tsl_st_id
	                          AND js.sl_shop_id = @tsl_sh_id
	                          
	                          AND (CONVERT(VARCHAR(50), js.sl_order_date, 23) <=  @tsl_date  OR js.sl_type =11  )
	                          AND js.sl_number != 0
	                          AND js.sl_status!=0
	                   GROUP BY
	                          js.sl_seiid,
	                          js.sl_shop_id,
	                          js.sl_giid,
	                          js.sl_skuid,
							  isnull(js.sl_pm,'')
	               ) AS p1
	               
			
			--去掉当盘点订单商品	
			DELETE FROM pos_stocklog_pal
			FROM pos_stocklog_pal fd,(
			SELECT  vtlo.tsl_gi_id,vtlo.tsl_sku_id,isnull(vtlo.tsl_pm,'') as tsl_pm
	        FROM   vi_pos_take_list_ok AS vtlo
	        WHERE  vtlo.tsl_id = @tsl_id 
			) fd2 WHERE fd.sl_skuid=fd2.tsl_sku_id
			AND fd.sl_giid=fd2.tsl_gi_id
			AND fd.sl_eoid=@tsl_id
			AND fd.sl_elid=@tsl_id
			and isnull(fd.sl_pm,'')=isnull(fd2.tsl_pm,'')
			
			
			DELETE FROM pos_stocklog
			FROM pos_stocklog fd,(
			SELECT  vtlo.tsl_gi_id,vtlo.tsl_sku_id,isnull(vtlo.tsl_pm,'') as tsl_pm
	        FROM   vi_pos_take_list_ok AS vtlo
	        WHERE  vtlo.tsl_id = @tsl_id
			) fd2 WHERE fd.sl_skuid=fd2.tsl_sku_id
			AND fd.sl_giid=fd2.tsl_gi_id
			AND fd.sl_eoid=@tsl_id
			AND fd.sl_elid=@tsl_id
			and isnull(fd.sl_pm,'')=isnull(fd2.tsl_pm,'')
			
	

	    END
	    
		

	    DECLARE @now DATETIME = GETDATE();

		--当前盘点订单实盘数据
	    INSERT INTO pos_stocklog
	      (
	        sl_seiid,
	        sl_shop_id,
	        sl_ciid,
	        sl_giid,
	        sl_skuid,
	        sl_number,
	        sl_counttype,
	        sl_remark,
	        sl_order_no,
	        sl_eoid,
	        sl_elid,
	        sl_type,
	        sl_order_date,
	        sl_order_add_time,
	        sl_addtime,
	        sl_updatetime,
	        sl_status,
			sl_erp_id,
			sl_pm
	      )
	    SELECT vt.ts_st_id,
	           vt.ts_sh_id,
	           cid = 0,
	           vt.tsl_gi_id,
	           vt.tsl_sku_id,
	           num = ABS(vt.tsl_logno),
	           count_type = CASE 
	                             WHEN vt.tsl_logno > 0 THEN 1
	                             ELSE 0
	                        END,
	           remark = CASE 
	                         WHEN vt.tsl_type = 1 THEN '整仓盘点盈亏调整'
	                         ELSE      '部分盘点盈亏调整'
	                    END,
	           orderno = vt.ts_vo,
	           eoid = vt.tsl_id,
	           elid = vt.tsl_id,
	           mytype = CASE 
	                         WHEN vt.tsl_type = 1 THEN 8
	                         WHEN vt.tsl_type = 2 AND vt.tsl_logno > 0 THEN 9
	                         WHEN vt.tsl_type = 2 AND vt.tsl_logno <= 0 THEN 10
	                    END,
	           vt.tso_take_time,
	           vt.tsl_add_time,
	           DATEADD(
	               second,
	               59,
	               DATEADD(minute, 59, DATEADD(hour, 23, @tsl_date))
	           ),
	           @now,
	           1,
			   @tsl_erp_id,
			   vt.tsl_pm
	    FROM   vi_pos_take_list_ok  AS vt
	    WHERE  vt.tsl_id = @tsl_id

	    
	    INSERT INTO pos_stocklog_pal
	      (
	        sl_seiid,
	        sl_shid,
	        sl_ciid,
	        sl_giid,
	        sl_skuid,
	        sl_number,
			sl_takenum,
	        sl_counttype,
	        sl_remark,
	        sl_order_no,
	        sl_eoid,
	        sl_elid,
	        sl_type,
	        sl_order_date,
	        sl_order_add_time,
	        sl_addtime,
	        sl_updatetime,
	        sl_status,sl_erp_id,sl_pm
	      )
	    SELECT vt.ts_st_id,
	           vt.ts_sh_id,
	           cid = 0,
	           vt.tsl_gi_id,
	           vt.tsl_sku_id,
	           num = ABS(vt.tsl_logno),
			   tsl_newno,
	           count_type = CASE 
	                             WHEN vt.tsl_logno > 0 THEN 1
	                             ELSE 0
	                        END,
	           remark = CASE 
	                         WHEN vt.tsl_type = 1 THEN '整仓盘点盈亏调整'
	                         ELSE      '部分盘点盈亏调整'
	                    END,
	           orderno = vt.ts_vo,
	           eoid = vt.tsl_id,
	           elid = vt.tsl_id,
	           mytype = CASE 
	                         WHEN vt.tsl_type = 1 THEN 8
	                         WHEN vt.tsl_type = 2 AND vt.tsl_logno > 0 THEN 9
	                         WHEN vt.tsl_type = 2 AND vt.tsl_logno <= 0 THEN 10
	                    END,
	           vt.tso_take_time,
	           vt.tsl_add_time,
	           DATEADD(
	               second,
	               59,
	               DATEADD(minute, 59, DATEADD(hour, 23, @tsl_date))
	           ),
	           @now,
	           1,@tsl_erp_id,vt.tsl_pm
	    FROM   vi_pos_take_list_ok  AS vt
	    WHERE  vt.tsl_id = @tsl_id

	  
		EXEC pro_pos_mergeStockLog_j_takeStorage
                @tsl_sh_id = @tsl_sh_id ,
                @negative_inventory = @negative_inventory ,
                @old_sei_id = @tsl_st_id,
				@new_sei_id = @tsl_st_id,
				@id=@tsl_id
        IF @@error <> 0
                  BEGIN
                        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION 
                        SET @result = '0';
                        RETURN 0;
                  END

	END
	
	IF @op_type = '修改为盘点准备状态'
	BEGIN
	   

	    DECLARE @tsl_status INT = 0;
	    DECLARE @tsl_date_max DATETIME;
	    SELECT @tsl_status = jtsl.tsl_status,
	           @tsl_date = jtsl.tsl_date,
	           @tsl_st_id = jtsl.tsl_st_id
	    FROM   pos_takeStorageLog AS jtsl
	    WHERE  jtsl.tsl_id = @tsl_id;

	    IF @tsl_status = 2
	    BEGIN
	        SELECT @tsl_date_max = MAX(jtsl.tsl_date)
	        FROM   pos_takeStorageLog AS jtsl
	        WHERE  jtsl.tsl_st_id = @tsl_st_id
	               AND jtsl.tsl_sh_id = @tsl_sh_id
	               AND jtsl.tsl_status = 1;
	        IF @tsl_date_max != @tsl_date
	        BEGIN
	            SET @result = '该仓库，存在多张盘点单，只允许修改末次盘点记录！';
	            IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	            RETURN 0;
	        END
	        
	        SELECT @tsl_date_max = MAX(jtsl.tsl_date)
	        FROM   pos_takeStorageLog AS jtsl
	        WHERE  jtsl.tsl_st_id = @tsl_st_id
	               AND jtsl.tsl_sh_id = @tsl_sh_id
	               AND jtsl.tsl_status = 2;
	        IF @tsl_date_max != @tsl_date
	        BEGIN
	            SET @result = '该仓库，存在多张盘点单，只允许修改末次盘点记录！';
	            IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	            RETURN 0;
	        END
	        
	        DELETE 
	        FROM   pos_stocklog_pal
	        WHERE  sl_eoid = @tsl_id
	               AND sl_elid = @tsl_id;
	               
	        --DELETE 
	        --FROM   pos_stocklog
	        --WHERE  sl_eoid = @tsl_id
	        --       AND sl_elid = @tsl_id;
	        
	        UPDATE pos_takeStorage
	        SET    ts_status = 1,
	               ts_tsl_id = NULL
	        WHERE  ts_tsl_id = @tsl_id;
	        
	        UPDATE pos_takeStorageLog
	        SET    tsl_status = 0
	        WHERE  tsl_id = @tsl_id;
	        

			--EXEC pro_pos_mergeStockLog_j_takeStorage
   --             @tsl_sh_id = @tsl_sh_id ,
   --             @negative_inventory = @negative_inventory ,
   --             @old_sei_id = @tsl_st_id,
			--	@new_sei_id = @tsl_st_id,
			--	@id=@tsl_id
			EXEC pro_pos_mergeStockLog @tsl_sh_id=@tsl_sh_id
               IF @@error <> 0
                  BEGIN
                        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION 
                        SET @result = '0';
                        RETURN 0;
                  END

	        UPDATE pos_takeStorageLog
	        SET    tsl_status = 1
	        WHERE  tsl_id = @tsl_id;
	    END
	END
	
	IF @op_type = '删除'
	BEGIN
	    SELECT @tsl_st_id = jtsl.tsl_st_id,
	           @tsl_sh_id = jtsl.tsl_sh_id,
	           @tsl_date = jtsl.tsl_date
	    FROM   pos_takeStorageLog AS jtsl
	    WHERE  jtsl.tsl_id = @tsl_id;
	    IF EXISTS(
	           SELECT *
	           FROM   pos_takeStorage AS jts WITH (NOLOCK) 
	           INNER JOIN pos_takeStorageList ptsl  WITH (NOLOCK)  ON jts.ts_id=ptsl.tsl_ts_id
	           WHERE  jts.ts_st_id = @tsl_st_id
	                  AND jts.ts_sh_id = @tsl_sh_id
	                  AND jts.ts_take_date = @tsl_date
	                  AND jts.ts_status > 0
	                  AND ptsl.tsl_status>0
	       )
	    BEGIN
	        SET @result = '删除失败,存在对应的盘点数据!';
	        IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	        RETURN 1;
	    END
	    
	    
	    UPDATE pos_takeStorageLog
	    SET    tsl_status = 0,
	           tsl_del_man = @tsl_del_man,
	           tsl_del_time = @tsl_del_time
	    WHERE  tsl_id = @tsl_id;
	END
	
	IF @@ERROR <> 0
	BEGIN
	    SET @result = '0';
	    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	    RETURN 1;
	END
	ELSE
	BEGIN
	    SET @result = CONVERT(VARCHAR(50), @tsl_id);
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	    RETURN 1;
	END
END
go

