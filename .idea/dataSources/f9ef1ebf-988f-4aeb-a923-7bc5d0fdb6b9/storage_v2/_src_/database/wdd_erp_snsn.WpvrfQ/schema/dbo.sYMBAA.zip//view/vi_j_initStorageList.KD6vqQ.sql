CREATE VIEW [dbo].[vi_j_initStorageList] AS 
SELECT
	jt.inl_in_id,
	jt.inl_gi_id,
	jt.inl_add_time,
	jt.inl_boxbynum,
	SUM (jt.inl_num) AS inl_num,
	MIN (jt.inl_id) AS inl_id,
	MAX (jt.inl_sku_id) AS inl_sku_id,
	SUM (jt.inl_money) AS inl_money,
	CONVERT (
		DECIMAL (10, 2),
		AVG (jt.inl_retail_price)
	) AS inl_retail_price,
	CONVERT (
		DECIMAL (10, 2),
		AVG (jt.inl_discount)
	) AS inl_discount,
	CONVERT (
		DECIMAL (10, 2),
		AVG (jt.inl_stock_price)
	) AS inl_stock_price,
	MAX (replace(inl_pm, '*', ',')) AS inl_pm,
	MAX (inl_box_num) AS inl_box_num
FROM
	j_initStorageList AS jt WITH (NOLOCK)
WHERE
	jt.inl_status = 1
GROUP BY
	jt.inl_in_id,
	jt.inl_gi_id,
	jt.inl_add_time,inl_boxbynum
go

