CREATE Proc [dbo].[pro_clearRubbishData]
	@type varchar(50)='盘点'
AS


DELETE FROM table_info
DELETE FROM temp_excel
DELETE FROM temp_excel_stock
DELETE FROM b_goodsinfo_delete_back
DELETE FROM b_goodsruleset_back
DELETE FROM b_goodsruleset_delete_back
DELETE FROM log_time_test

delete from api_docking_tbl
delete from api_dockingconfig_tbl
delete from api_dockinglog_tbl
delete from api_dockingset_tbl
delete from api_tokenlog_tbl
delete from api_tokenset_tbl
delete from b_save_solve
delete from m_order_goods
delete from m_order_info
delete from m_pos_order_goods
delete from m_pos_order_info
delete from netorder_tbl
delete from netordergoods_tbl
delete from pos_cors_type
delete from pos_sale_net
delete from pos_sale_record
delete from pos_stocklog
delete from pos_stocklog_pal
delete from pos_supplierinfo
--delete from s_exportaddress
delete from s_fahuodan_set
delete from s_operate_log

delete from syslog_tbl

delete from temp_10
--delete from y_print_model




delete from b_attribute
delete from b_attribute_back
delete from b_attribute_set
delete from b_unit

 

DELETE FROM j_add_time_record;
DELETE FROM pos_customPrice;
DELETE FROM pos_customPrice_temp_excel_data;
DELETE FROM pos_customPriceList;
DELETE FROM pos_integral_record;
DELETE FROM s_exportlog_tbl;


DELETE FROM b_goods_discount;



if @type='盘点'
BEGIN
--盘点明细
delete from j_takeStorageList
--盘点
delete from j_takeStorage
--盘点记录
delete from j_takeStorageLog
--商品库存
Delete from b_stockinfo
--库存明细
delete from j_stocklog

delete from j_stocklog_pal
END



if @type='其他单据'
BEGIN

--采购明细
delete from j_purchaseStorage
--采购单
delete from j_purchaseStorageList



--款项
ALTER TABLE c_fundorder DISABLE TRIGGER no_del
DELETE FROM c_fundorder
ALTER TABLE c_fundorder ENABLE TRIGGER no_del

--出库
delete from j_outStorage
delete from j_outStorageList


--期初库存
delete from j_initStorageList
delete from j_initStorage

--入库
delete from j_enterStorage
delete from j_enterStorageList

--移仓
delete from j_moStorageList
delete from j_moStorage

--库存调整
delete from j_plStorageList
delete from j_plStorage


END

if @type='pos单据信息'
BEGIN
--pos删除
delete from pos_active
delete from pos_activeGift
delete from pos_activeGoods
delete from pos_activeShop
delete from pos_allocation
delete from pos_allocationList
delete from pos_alStorage
delete from pos_alStorageList
delete from pos_cost
delete from pos_costList
delete from pos_funds
delete from pos_fundsList
delete from pos_initStorage
delete from pos_initStorageList
delete from pos_inStorage
delete from pos_inStorageList
delete from pos_stockInfo

delete from pos_takeStorage
delete from pos_takeStorageList
delete from pos_takeStorageLog
delete from pos_moStorage
delete from pos_moStorageList
delete from pos_ogStorage
delete from pos_ogStorageList
delete from pos_plStorage
delete from pos_plStorageList
delete from pos_reStorage
delete from pos_reStorageList
delete from pos_sale
delete from pos_saleCharge
delete from pos_saleChargeList
delete from pos_saleList

delete from pos_sale_record
delete from pos_sale_record_temp

delete from pos_sale_temp
delete from pos_saleList_temp


end

if @type='pos基础信息'
BEGIN
delete from pos_storageInfo
	
delete from pos_class
delete from pos_classLog
delete from pos_grade
delete from pos_integral
delete from pos_integralRule
delete from pos_memberInfo
delete from pos_shop
delete from pos_staffClassSet
END

if @type='基础信息'
BEGIN
	


--商品规则
DELETE FROM b_goodsruleset
--商品信息
DELETE FROM b_goodsinfo
--规格
DELETE FROM s_goodsrule

--规格明细
DELETE FROM s_goodsruledetail


--仓库
delete from b_storageinfo
--客户
delete from b_clientinfo
--供应商
delete from b_supplierinfo
--客户分类,供应商分类
delete from cors_type

delete from j_SellContrast



delete from s_operate_log
delete from log_c
delete from s_goodsclass
delete from m_ordergoods
delete from s_goodsclass_taobao
delete from m_orderinfo
delete from m_orderinfo_merge
delete from m_ordergoods_merge
delete from b_goodsruleset_merge
delete from s_goodsbrand_merge
delete from b_clientinfo
delete from b_stafftinfo
delete from b_goodsinfo_merge
delete from s_power_button_info
delete from r_report_fileinfo
delete from r_page_info
delete from s_goodsrule_merge
delete from sys_notice

delete from s_goodsruledetail_merge
delete from s_goodsclass_merge
delete from s_goodsattribute
--delete from s_expresscompanyset
delete from s_power_page_info
delete from s_goodsbrand
delete from s_goodsparameter
delete from s_role_info
delete from c_bankinfo

delete from c_infotype
delete from b_positiontinfo
delete from s_goodstype
delete from b_departmentinfo
delete from m_orderchannel
delete from r_printbtn_info
delete from c_inoutlist
delete from companyinfo
delete from s_deliveraddress
delete from j_FareContrast
delete from s_goodsruledetail_back
delete from s_goodsrule_back
delete from s_user_column_info


END


--这些是系统的初始数据,不可删除.
--权限数据
--delete from s_sys_column_info
--delete from s_dg_info
--delete from s_pageInfo
--delete from s_buttoninfo
--delete from s_oper_info
--delete from s_button_oper
--delete from s_page_oper
--delete from s_expresscompany
--delete from s_paymentway
--delete from s_expresstemplate
go

