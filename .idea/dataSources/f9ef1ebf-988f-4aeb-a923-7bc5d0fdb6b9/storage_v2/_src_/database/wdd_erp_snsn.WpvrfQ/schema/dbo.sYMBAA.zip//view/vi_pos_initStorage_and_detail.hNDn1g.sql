CREATE VIEW [dbo].[vi_pos_initStorage_and_detail] AS 
SELECT jt.in_id,
       bg.gi_name,
       bg.gi_code
FROM   pos_initStorage                 AS jt
       INNER JOIN pos_initStorageList  AS jt1
            ON  jt.in_id = jt1.inl_in_id
       INNER JOIN b_goodsinfo           AS bg
            ON  jt1.inl_gi_id = bg.gi_id
WHERE  jt1.inl_status = 1
       AND jt.in_status != 0
go

