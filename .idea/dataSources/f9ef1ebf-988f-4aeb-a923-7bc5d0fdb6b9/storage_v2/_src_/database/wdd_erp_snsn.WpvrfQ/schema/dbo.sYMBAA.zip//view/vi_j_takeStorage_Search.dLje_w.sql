CREATE VIEW [dbo].[vi_j_takeStorage_Search] AS 


select
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
locationlist.*
from 
(	
	
   
select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
grl.colorname as color,   
grl.specname as spec,   
isnull(grl.specid,0) as size,   
isnull(grl.specngroupid,0) as specid,   
ln.* 
from
(	
	


SELECT
	*
FROM
	vi_j_takeStorageList_group_goods_search el
INNER JOIN (
	SELECT
		ts_id,
		ts_vo,
		CONVERT (
			VARCHAR (100),
			ts_take_date,
			23
		) AS ts_take_date,
		ts_no,
		ts_st_id,
		ts_order_man,
		ts_it_id,
		ts_cp_id,
		ts_di_id,
		(
			SELECT
				sei_name
			FROM
				dbo.b_storageinfo AS bs WITH (NOLOCK)
			WHERE
				(sei_id = jis.ts_st_id)
		) AS ts_st_id_txt,
		(
			SELECT
				di_name
			FROM
				dbo.b_departmentinfo AS bs WITH (NOLOCK)
			WHERE
				(di_id = jis.ts_it_id)
		) AS ts_it_id_txt,
		(
			SELECT
				si_name
			FROM
				dbo.b_stafftinfo AS bs WITH (NOLOCK)
			WHERE
				(si_id = jis.ts_order_man)
		) AS ts_order_man_txt,
		(
			SELECT
				si_name
			FROM
				dbo.b_stafftinfo AS bs WITH (NOLOCK)
			WHERE
				(si_id = jis.ts_add_man)
		) AS ts_add_man_txt,
		ts_add_man,
		ts_add_time,
		(
			SELECT
				si_name
			FROM
				dbo.b_stafftinfo AS bs WITH (NOLOCK)
			WHERE
				(si_id = jis.ts_update_man)
		) AS ts_update_man_txt,
		ts_update_man,
		ts_update_time,
		(
			SELECT
				si_name
			FROM
				dbo.b_stafftinfo AS bs WITH (NOLOCK)
			WHERE
				(si_id = jis.ts_audit_man)
		) AS ts_audit_man_txt,
		ts_audit_man,
		ts_audit_time,
		ts_remark,
		ts_status
	FROM
		dbo.j_takeStorage AS jis WITH (NOLOCK)
) AS eo ON el.tsl_ts_id = eo.ts_id
AND eo.ts_status > 0



) as ln
left join b_goodsruleset  as grl on  grl.gss_id=ln.tsl_sku_id

) as locationlist
left join s_goodsruledetail rulenum on gd_id=locationlist.size
go

