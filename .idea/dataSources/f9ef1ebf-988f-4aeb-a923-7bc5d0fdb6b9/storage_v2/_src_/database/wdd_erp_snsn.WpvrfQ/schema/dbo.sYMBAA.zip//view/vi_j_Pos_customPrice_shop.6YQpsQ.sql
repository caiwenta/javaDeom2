CREATE VIEW [dbo].[vi_j_Pos_customPrice_shop] AS 
SELECT DISTINCT(sh_id),
       c.cpl_cp_id,
       sh_name,
       s.sh_no
FROM   pos_customPriceList c
       INNER JOIN pos_shop s
            ON  c.cpl_sh_id = s.sh_id
go

