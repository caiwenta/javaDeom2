CREATE VIEW [dbo].[vi_j_moStorage_Search_copy] AS 
select * from 
(
--vi_j_moStorageList_group_goods el 
SELECT jt.mol_mo_id,
       jt.mol_gi_id,
       jt.mol_num,
       jt.mol_stock_num,
       jt.mol_id,
       jt.mol_sku_id,
       jt.mol_discount,
       jt.mol_retail_price,
       jt.mol_stock_price,
       jt.mol_money,
       CONVERT(VARCHAR(100), jt.mol_add_time, 25) AS mol_add_time,
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
       bg.gi_retailprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bg.gi_attribute_ids,
       bg.gi_attribute_parentids,
       bu.ut_name                       AS gi_unit,
bu.ut_id                       AS gi_unit_id,
       mol_box_num,
       mol_pm,
	    jt.vertical_column_id,
        jt.vertical_column_name
       
FROM  
(
 --dbo.vi_j_moStorageList           AS jt
 SELECT mol_mo_id,
       mol_gi_id,
       mol_add_time,
       SUM(mol_num)                    AS mol_num,
       MIN(mol_id)                     AS mol_id,
       MAX(mol_sku_id)                 AS mol_sku_id,
       SUM(mol_stock_num)              AS mol_stock_num,
       CONVERT(DECIMAL(10, 2), AVG(mol_discount)) AS mol_discount,
       CONVERT(DECIMAL(10, 2), AVG(mol_retail_price)) AS mol_retail_price,
       CONVERT(DECIMAL(10, 2), AVG(mol_stock_price)) AS mol_stock_price,
       SUM(mol_money)                  AS mol_money,
       MAX(REPLACE(mol_pm, '*', ','))  AS mol_pm,
       MAX(mol_box_num)                AS mol_box_num
       
       
       ,
       jt.vertical_column_id,
       jt.vertical_column_name
       
FROM  
(
 --dbo.j_moStorageList AS jt
 
 
 
 
SELECT jt.*
                  --垂直列,颜色列
                  ,
                  vertical_column_id = CASE 
                                            WHEN ISNULL(
                                                     dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1),
                                                     0
                                                 ) = 0 THEN --没规格
                                                 0
                                            ELSE CASE 
                                                      WHEN bg.gs_is_custom > 0 THEN CASE 
                                                                                         WHEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1)
                                                                                              )
                                                                                              = 
                                                                                              bg.gs_is_custom THEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 2), '-', 2)
                                                                                              )
                                                                                         ELSE 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 2)
                                                                                              )
                                                                                    END
                                                      ELSE CONVERT(
                                                               INT,
                                                               dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 2)
                                                           )
                                                 END
                                       END,
                  vertical_column_name = CASE 
                                              WHEN ISNULL(
                                                       dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1),
                                                       0
                                                   ) = 0 THEN --没规格
                                                   ''
                                              ELSE CASE 
                                                        WHEN bg.gs_is_custom > 0 THEN CASE 
                                                                                           WHEN 
                                                                                                CONVERT(
                                                                                                    INT,
                                                                                                    dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id, '/', 1), '-', 1)
                                                                                                )
                                                                                                = 
                                                                                                bg.gs_is_custom THEN 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 2), ':', 2)
                                                                                           ELSE 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 1), ':', 2)
                                                                                      END
                                                        ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_name, '|', 1), ':', 2)
                                                   END
                                         END
           FROM   dbo.j_moStorageList AS jt
                  LEFT JOIN b_goodsruleset bg
                       ON  jt.mol_sku_id = bg.gss_id
           WHERE  (mol_status = 1)
           
           
 
 )AS jt
WHERE  (mol_status = 1)
GROUP BY
       mol_mo_id,
       mol_gi_id,
       mol_add_time,
       jt.vertical_column_id,
       jt.vertical_column_name
       

 
) AS jt
       INNER JOIN dbo.b_goodsinfo  AS bg
            ON  jt.mol_gi_id = bg.gi_id
       INNER JOIN dbo.b_unit       AS bu
            ON  bg.gi_unit = bu.ut_id


) el
left join vi_j_moStorage eo on el.mol_mo_id=eo.mo_id and  eo.mo_status>0
go

