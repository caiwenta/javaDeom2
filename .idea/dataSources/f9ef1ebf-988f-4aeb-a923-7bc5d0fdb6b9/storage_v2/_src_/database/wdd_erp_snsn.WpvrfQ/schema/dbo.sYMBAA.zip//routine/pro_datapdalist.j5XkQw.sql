CREATE PROCEDURE [dbo].[pro_datapdalist]
    @action varchar(50)='',
	@do_source_id int = 0,
	@warehousingtype int,
	@groupby int=1,
	@gi_id int=0,
	@si_id int=0
AS

create table #goodlist --创建临时表#goodlist
(
    warehousingtype int null,   
    do_source_id int null,
	gi_id int null,
	skuid int null,
	applyqty int null,
	num int null
);


if(@action='allocation')--配货
begin

if @gi_id=0
begin
insert #goodlist
SELECT @warehousingtype,
	pal.all_al_id  AS do_source_id,
	pal.all_gi_id AS gi_id,
	pal.all_sku_id AS sku_id,
	SUM(all_num) AS applyqty,
	SUM(all_num) AS num
FROM pos_allocationList pal WHERE pal.all_al_id=@do_source_id AND pal.all_status>0
group by all_al_id,all_gi_id,pal.all_sku_id
end
else
begin
insert #goodlist
SELECT @warehousingtype,
	pal.all_al_id  AS do_source_id,
	--pal.all_id as source_id,
	pal.all_gi_id AS gi_id,
	pal.all_sku_id AS sku_id,
	SUM(all_num) AS applyqty,
	SUM(all_num) AS num
FROM pos_allocationList pal WHERE pal.all_al_id=@do_source_id AND pal.all_status<>0
and pal.all_gi_id=@gi_id
group by all_al_id,all_gi_id,pal.all_sku_id
end

end

if(@action='purchase')--采购
begin

if @gi_id=0
	begin

	insert #goodlist
	SELECT @warehousingtype,
	ps.pll_pl_id  AS do_source_id,
	ps.pll_gi_id AS gi_id,
	ps.pll_sku_id AS sku_id,
	SUM(ps.pll_num) AS applyqty,
	SUM(ps.pll_num) AS num
	FROM j_purchaseStorageList ps WHERE ps.pll_pl_id=@do_source_id AND ps.pll_status>0
	group by ps.pll_pl_id,ps.pll_gi_id,ps.pll_sku_id

	end
else
	begin

	insert #goodlist
	SELECT @warehousingtype,
	ps.pll_pl_id  AS do_source_id,
	ps.pll_gi_id AS gi_id,
	ps.pll_sku_id AS sku_id,
	SUM(ps.pll_num) AS applyqty,
	SUM(ps.pll_num) AS num
	FROM j_purchaseStorageList ps WHERE ps.pll_pl_id=@do_source_id AND ps.pll_status>0
	and ps.pll_gi_id=@gi_id
	group by ps.pll_pl_id,ps.pll_gi_id,ps.pll_sku_id

	end
end

if (@action='orderblank')--草稿箱
begin
if @gi_id=0
	begin

	insert #goodlist
	SELECT
	@warehousingtype,
	inl.mol_mo_id AS do_source_id,
	inl.mol_gi_id,
	inl.mol_sku_id,
	SUM(mol_num) AS applyqty,
	SUM(mol_num) AS num
	FROM j_orderblanklist AS inl
	WHERE inl. mol_status=1 AND  mol_mo_id=@do_source_id 
	GROUP BY mol_mo_id,mol_gi_id,mol_sku_id

	end
else
	begin

	insert #goodlist
	SELECT
	@warehousingtype,
	inl.mol_mo_id AS do_source_id,
	inl.mol_gi_id,
	inl.mol_sku_id,
	SUM(mol_num) AS applyqty,
	SUM(mol_num) AS num
	FROM j_orderblanklist AS inl
	WHERE inl. mol_status=1 AND  mol_mo_id=@do_source_id and mol_gi_id=@gi_id
	GROUP BY mol_mo_id,mol_gi_id,mol_sku_id

	end
end

if(@action='enter')--入库
begin

if @warehousingtype=1 --erp入库
begin

	if @gi_id=0
	begin

		insert #goodlist
		SELECT
		@warehousingtype,
		jel.el_eoid AS do_source_id,
		jel.el_siid,
		jel.el_skuid,
		SUM(jel.el_number) AS applyqty,
		SUM(jel.el_number) AS num
		FROM j_enterStorageList AS jel
		WHERE jel.el_status=1 AND jel.el_eoid=@do_source_id
		GROUP BY jel.el_eoid,jel.el_siid,jel.el_skuid

	end
else
	begin

		insert #goodlist
		SELECT
		@warehousingtype,
		jel.el_eoid AS do_source_id,
		jel.el_siid,
		jel.el_skuid,
		SUM(jel.el_number) AS applyqty,
		SUM(jel.el_number) AS num
		FROM j_enterStorageList AS jel
		WHERE jel.el_status=1 AND jel.el_eoid=@do_source_id and jel.el_siid=@gi_id
		GROUP BY jel.el_eoid,jel.el_siid,jel.el_skuid

	end

end

if @warehousingtype=8 --pos入库
begin
		
	if @gi_id=0
		begin

        insert #goodlist
		SELECT
		@warehousingtype,
		inl.inl_in_id AS do_source_id,
		inl.inl_gi_id,
		inl.inl_sku_id,
		SUM(inl.inl_num) AS applyqty,
		SUM(inl.inl_num) AS num
		FROM pos_inStorageList AS inl
		WHERE inl.inl_status=1 AND inl.inl_in_id=@do_source_id
		GROUP BY inl.inl_in_id,inl.inl_gi_id,inl.inl_sku_id
	end
	else
	begin

		insert #goodlist
		SELECT
		@warehousingtype,
		inl.inl_in_id AS do_source_id,
		inl.inl_gi_id,
		inl.inl_sku_id,
		SUM(inl.inl_num) AS applyqty,
		SUM(inl.inl_num) AS num
		FROM pos_inStorageList AS inl
		WHERE inl.inl_status=1 AND inl.inl_in_id=@do_source_id and inl.inl_gi_id=@gi_id
		GROUP BY inl.inl_in_id,inl.inl_gi_id,inl.inl_sku_id

	end

end

end

if (@action='momostoragebyin')--移动移仓
begin

if @gi_id=0
		begin

        insert #goodlist
		SELECT
		@warehousingtype,
		inl.mol_mo_id AS do_source_id,
		inl.mol_gi_id,
		inl.mol_sku_id,
		SUM(inl.mol_num) AS applyqty,
		SUM(inl.mol_num) AS num
		FROM j_moStoragelist AS inl
		WHERE inl.mol_status=1 AND inl.mol_mo_id=@do_source_id
		GROUP BY inl.mol_mo_id,inl.mol_gi_id,inl.mol_sku_id

	end
	else
	begin

		insert #goodlist
		SELECT
		@warehousingtype,
		inl.mol_mo_id AS do_source_id,
		inl.mol_gi_id,
		inl.mol_sku_id,
		SUM(inl.mol_num) AS applyqty,
		SUM(inl.mol_num) AS num
		FROM j_moStoragelist AS inl
		WHERE inl.mol_status=1 AND inl.mol_mo_id=@do_source_id and inl.mol_gi_id=@gi_id
		GROUP BY inl.mol_mo_id,inl.mol_gi_id,inl.mol_sku_id

	end


end













SELECT 
T4.*,
(CASE WHEN inspection IS NULL THEN doapplyqtydiff --完成数为空：取派单差异
ELSE doapplyqtydiff+inspectiondiff END ) AS surplusnum
into #distributionlist

FROM(
	
SELECT 
T3.*,
(CASE WHEN doapplyqty>0 THEN doapplyqty-inspection ELSE NULL END) AS inspectiondiff --完成差异
                                                                                     --
FROM (
	
SELECT 
T2.*,
(applyqty-doapplyqty) as doapplyqtydiff, --派单差异
(CASE WHEN doapplyqty>0 THEN (
SELECT sum(CASE when dis.dol_gi_id IS NOT NULL THEN isnull(pk.dp_inspectionnum,0) ELSE NULL END) FROM erp_distributionorderlist AS dis
INNER JOIN erp_distributionorder AS ed ON ed.do_id=dis.do_id 
INNER JOIN erp_distributionpdaing AS pda ON pda.do_id=dis.do_id AND pda.si_id=dis.si_id and pda.di_status=2
LEFT JOIN erp_distributionpicking AS pk ON pk.dol_id=dis.dol_id
WHERE ed.warehousingtype=T2.warehousingtype and ed.do_source_id=T2.do_source_id  AND dis.dol_gi_id=T2.gi_id AND dis.dol_sku_id=T2.skuid AND ed.do_status>0)
ELSE NULL end)AS inspection --完成数

FROM (

SELECT
T1.*,
(SELECT  isnull(SUM(dol_applyqty),0) FROM erp_distributionorderlist AS dl INNER JOIN erp_distributionorder AS ed 
ON ed.do_id=dl.do_id AND ed.do_source_id=T1.do_source_id AND dl.dol_gi_id=T1.gi_id AND dl.dol_sku_id=T1.skuid AND ed.do_status>0 AND ed.warehousingtype=T1.warehousingtype
) doapplyqty --派单 

FROM #goodlist AS T1
) AS T2
) AS T3) AS T4










if(@groupby=1)
begin

SELECT
'' AS si_id,--站位字段 
dli.*,
gi.gi_code,
gi.gi_name,
gi.gi_barcode
FROM
(

SELECT 
T5.warehousingtype,
T5.do_source_id,
T5.gi_id,
sum(T5.num) as num,
SUM(T5.applyqty) AS applyqty,
SUM(T5.doapplyqty) AS doapplyqty,
SUM(T5.doapplyqtydiff) AS doapplyqtydiff, 
SUM(t5.inspection) AS inspection,
SUM(t5.inspectiondiff) AS inspectiondiff,
SUM(t5.surplusnum) AS surplusnum
FROM #distributionlist AS T5
where T5.surplusnum>0
GROUP BY T5.warehousingtype,T5.do_source_id,T5.gi_id
) AS dli
INNER join b_goodsinfo gi ON dli.gi_id=gi.gi_id


end
else
begin



select
@si_id as si_id,
dl.*,
gi.gi_code,
gi.gi_barcode,
gi.gi_name
from 
#distributionlist as dl
INNER join b_goodsinfo gi ON dl.gi_id=gi.gi_id
where surplusnum>0




end
go

