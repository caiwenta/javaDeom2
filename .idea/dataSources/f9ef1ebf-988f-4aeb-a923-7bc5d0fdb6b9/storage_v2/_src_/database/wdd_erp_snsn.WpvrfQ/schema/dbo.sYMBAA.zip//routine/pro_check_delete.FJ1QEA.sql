CREATE PROC [dbo].[pro_check_delete]
       @op_type VARCHAR(50) ,
       @erp_id INT = 0 ,
       @id INT
AS
       DECLARE @result VARCHAR(100) = '';
	   --返回1则表示可以删除
       SET @result = '1';
	   -------------------------ERP---------------------------------
       IF @op_type = '仓库'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    j_enterStorage fd
                            WHERE   fd.eo_siid = @id
                                    AND fd.eo_status > 0 )
                   SET @result = '已被入库引用,不可删除!';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     j_outStorage fd
                               WHERE    fd.oo_siid = @id
                                        AND fd.oo_status > 0 )
                      SET @result = '已被出库引用,不可删除!';
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      j_moStorage fd
                                  WHERE     fd.mo_out_st_id = @id
                                            AND fd.mo_status > 0 )
                         OR EXISTS ( SELECT 1
                                     FROM   j_moStorage fd
                                     WHERE  fd.mo_in_st_id = @id
                                            AND fd.mo_status > 0 )
                         SET @result = '已被移仓引用,不可删除!';
                      ELSE
                         IF EXISTS ( SELECT 1
                                     FROM   j_plStorage fd
                                     WHERE  fd.pl_st_id = @id
                                            AND pl_status > 0 )
                            SET @result = '已被盈亏引用,不可删除!';
          END

       IF @op_type = '客户'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    j_outStorage fd
                            WHERE   fd.oo_ciid = @id
                                    AND fd.oo_status > 0 )
                   SET @result = '已被出库引用,不可删除';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     pos_allocation fd
                               WHERE    fd.al_ci_id = @id
                                        AND fd.al_status > 0 )
                      SET @result = '已被配货引用,不可删除';
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      pos_ogStorage fd
                                  WHERE     fd.og_ci_id = @id
                                            AND fd.og_status > 0 )
                         SET @result = '已被订单引用,不可删除';
                      ELSE
                         IF EXISTS ( SELECT 1
                                     FROM   c_fundorder
                                     WHERE  fo_ciid = @id
                                            AND fo_type = 0
                                            AND fo_status > 0 )
                            SET @result = '已被账款引用,不可删除';
          END

       IF @op_type = '供应商'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    j_purchaseStorage fd
                            WHERE   fd.pl_ci_id = @id
                                    AND fd.pl_status > 0 )
                   SET @result = '已被采购引用,不可删除';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     j_enterStorage fd
                               WHERE    fd.eo_ciid = @id
                                        AND fd.eo_status > 0 )
                      SET @result = '已被入库引用,不可删除';
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      c_fundorder
                                  WHERE     fo_ciid = @id
                                            AND fo_type = 1
                                            AND fo_status > 0 )
                         SET @result = '已被账款引用,不可删除';
          END

       IF @op_type = '员工'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    j_purchaseStorage fd
                            WHERE   fd.pl_order_man = @id
                                    AND fd.pl_status > 0 )
                   SET @result = '已被采购引用,不可删除';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     j_enterStorage fd
                               WHERE    fd.eo_takemanid = @id
                                        AND fd.eo_status > 0 )
                      SET @result = '已被入库引用,不可删除';
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      j_outStorage fd
                                  WHERE     fd.oo_takemanid = @id
                                            AND fd.oo_status > 0 )
                         SET @result = '已被出库引用,不可删除!';
                      ELSE
                         IF EXISTS ( SELECT 1
                                     FROM   j_moStorage fd
                                     WHERE  fd.mo_order_man = @id
                                            AND fd.mo_status > 0 )
                            SET @result = '已被移仓引用,不可删除!';
                         ELSE
                            IF EXISTS ( SELECT  1
                                        FROM    j_plStorage fd
                                        WHERE   fd.pl_order_man = @id
                                                AND fd.pl_status > 0 )
                               SET @result = '已被盈亏引用,不可删除!';
                            ELSE
                               IF EXISTS ( SELECT   1
                                           FROM     j_takeStorage fd
                                           WHERE    fd.ts_order_man = @id
                                                    AND fd.ts_status > 0 )
                                  SET @result = '已被盘点引用,不可删除!';
                               ELSE
                                  IF ( SELECT TOP 1
                                                si_id
                                       FROM     b_stafftinfo
                                       WHERE    si_erp_id = @erp_id
                                       ORDER BY si_id ASC
                                     ) = @id
                                     SET @result = '管理员帐户不可修改删除';
          END

       IF @op_type = '部门'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_stafftinfo fd
                            WHERE   fd.si_did = @id
                                    AND fd.si_isdel > 0 )
                   SET @result = '已被员工引用,不可删除!';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     b_departmentinfo fd
                               WHERE    fd.di_parent = @id
                                        AND fd.di_isdel > 0 )
                      SET @result = '该部门有子节点,不可删除!';
          END

       IF @op_type = '类型'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    s_goodsclass fd
                            WHERE   fd.gs_id = @id
                                    AND fd.gc_status > 0 )
                   SET @result = '已被商品引用,不可删除!';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     b_clientinfo fd
                               WHERE    fd.ci_ctid = @id
                                        AND fd.ci_status > 0 )
                      SET @result = '已被客户引用,不可删除!';
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      b_supplierinfo fd
                                  WHERE     fd.si_ctid = @id
                                            AND fd.si_status > 0 )
                         SET @result = '已被供应商引用,不可删除!';
                      ELSE
                         IF EXISTS ( SELECT 1
                                     FROM   pos_shop fd
                                     WHERE  fd.sh_class = @id
                                            AND fd.[status] > 0 )
                            SET @result = '已被店铺引用,不可删除!';
                         ELSE
                            IF EXISTS ( SELECT  1
                                        FROM    b_storageinfo fd
                                        WHERE   fd.sei_itid = @id
                                                AND fd.sei_status > 0 )
                               SET @result = '已被仓库引用,不可删除!';
                            ELSE
                               IF EXISTS ( SELECT   1
                                           FROM     pos_payout fd
                                           WHERE    p_class = @id
                                                    AND p_status > 0 )
                                 SET @result = '已产生数据,不可删除!';
                              ELSE
                                 IF EXISTS ( SELECT   1
                                             FROM     c_fundordermapingtype cft 
                                             left join c_fundorder cf 
                                             on cft.fo_id=cf.fo_id
                                             WHERE    gs_id = @id 
                                                      and fo_status>0)
                                   SET @result = '已产生数据,不可删除!';
          END

       IF @op_type = '属性'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_attribute_set fd
                            WHERE   fd.a_a_id = @id )
                   SET @result = '该属性已被引用,不可删除!';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     b_attribute fd
                               WHERE    a_pid = @id
                                        AND a_status > 0 )
                      SET @result = '该属性已有子节点,不可删除!';
          END

       IF @op_type = '商品'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    j_purchaseStorage fd
                            WHERE   pl_id IN ( SELECT   pll_pl_id
                                               FROM     j_purchaseStorageList fd
                                               WHERE    fd.pll_gi_id = @id
                                                        AND fd.pll_status > 0 )
                                    AND pl_status > 0 )
                   SET @result = '已被采购引用,不可删除!';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     j_enterStorage
                               WHERE    eo_id IN ( SELECT   fd.el_eoid
                                                   FROM     j_enterStorageList fd
                                                   WHERE    fd.el_siid = @id
                                                            AND fd.el_status > 0 )
                                        AND eo_status > 0 )
                      SET @result = '已被入库引用,不可删除!';
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      j_outStorage
                                  WHERE     oo_id IN ( SELECT   fd.ol_eoid
                                                       FROM     j_outStorageList fd
                                                       WHERE    fd.ol_siid = @id
                                                                AND fd.ol_status > 0 )
                                            AND oo_status > 0 )
                         SET @result = '已被出库引用,不可删除!';
                      ELSE
                         IF EXISTS ( SELECT 1
                                     FROM   j_moStorage
                                     WHERE  mo_id IN ( SELECT   fd.mol_mo_id
                                                       FROM     j_moStorageList fd
                                                       WHERE    fd.mol_gi_id = @id
                                                                AND fd.mol_status > 0 )
                                            AND mo_status > 0 )
                            SET @result = '已被移仓引用,不可删除!';
                         ELSE
                            IF EXISTS ( SELECT  1
                                        FROM    j_plStorage
                                        WHERE   pl_id IN ( SELECT   fd.ppl_pl_id
                                                           FROM     j_plStorageList fd
                                                           WHERE    fd.ppl_gi_id = @id
                                                                    AND fd.ppl_status > 0 )
                                                AND pl_status > 0 )
                               SET @result = '已被盈亏引用,不可删除!';
                            ELSE
                               IF EXISTS ( SELECT   1
                                           FROM     j_takeStorage
                                           WHERE    ts_id IN ( SELECT   fd.tsl_ts_id
                                                               FROM     j_takeStorageList fd
                                                               WHERE    fd.tsl_gi_id = @id
                                                                        AND fd.tsl_status > 0 )
                                                    AND ts_status > 0 )
                                  SET @result = '已被盘点引用,不可删除!';
                               ELSE
                                  IF EXISTS ( SELECT    1
                                              FROM      pos_allocation
                                              WHERE     al_id IN ( SELECT   fd.all_al_id
                                                                   FROM     pos_allocationList fd
                                                                   WHERE    fd.all_gi_id = @id
                                                                            AND fd.all_status > 0 )
                                                        AND al_status > 0 )
                                     SET @result = '已被配货引用,不可删除!';
                                  ELSE
                                     IF EXISTS ( SELECT 1
                                                 FROM   pos_ogStorageList fd
                                                 INNER JOIN pos_ogStorage fs
                                                        ON fd.ogl_og_id = fs.og_id
                                                 WHERE  fd.ogl_gi_id = @id
                                                        AND fs.og_status > 0
                                                        AND fd.ogl_status > 0 )
                                        SET @result = '已被订单引用,不可删除!';
                                     ELSE
                                        IF EXISTS ( SELECT  1
                                                    FROM    pos_reStorage fd
                                                    INNER JOIN pos_reStoragelist fs
                                                            ON fd.re_id = fs.rel_re_id
                                                    WHERE   fs.rel_gi_id = @id
                                                            AND fs.rel_status > 0
                                                            AND fd.re_status > 0 )
                                           SET @result = '已被补货引用,不可删除!';
                                        ELSE
                                           IF EXISTS ( SELECT   1
                                                       FROM     pos_activeGoods fd
                                                       INNER JOIN pos_active pa
                                                                ON fd.ac_ac_id = pa.ac_id
                                                       WHERE    fd.ac_gi_id = @id
                                                                AND fd.ac_status > 0
                                                                AND pa.ac_status > 0 )
                                              SET @result = '已被设为活动商品,不可删除!';
                                           ELSE
                                              IF EXISTS ( SELECT    1
                                                          FROM      pos_activeGift fd
                                                          INNER JOIN pos_active pa
                                                                    ON fd.ac_ac_id = pa.ac_id
                                                          WHERE     fd.ac_gi_id = @id
                                                                    AND fd.ac_status > 0
                                                                    AND pa.ac_status > 0 )
                                                 SET @result = '已被设为活动商品,不可删除!';
                                              ELSE
                                                 IF EXISTS ( SELECT 1
                                                             FROM   pos_customPrice fd
                                                             INNER JOIN pos_customPriceList fs
                                                                    ON fd.cp_id = fs.cpl_cp_id
                                                             WHERE  fs.cpl_gi_id = @id
                                                                    AND fd.cp_status > 0 )
                                                    SET @result = '已被总部调整价格,不可删除!';
                                                 ELSE
                                                    IF ( SELECT COUNT (1) AS count FROM vi_stockList fd WITH (NOLOCK) WHERE fd.gid= @id
                                                       ) > 0
                                                       SET @result = '已产生总部库存,不可删除!';
                                                    ELSE
                                                       IF ( SELECT COUNT (1) AS count FROM vi_pos_stockList fd WITH (NOLOCK) WHERE fd.gid= @id
                                                          ) > 0
                                                          SET @result = '已产生店铺库存,不可删除!';
                                                       ELSE
                                                          IF ( SELECT   COUNT(1) AS count
                                                               FROM     j_takeStorageList jtsl
                                                               INNER JOIN j_takeStorage jts
                                                                        ON jtsl.tsl_ts_id = jts.ts_id
                                                               WHERE    jts.ts_status != 0
                                                                        AND jtsl.tsl_status > 0
                                                                        AND jtsl.tsl_gi_id = @id
                                                             ) > 0
                                                             SET @result = '已被总部盘点引用,不可删除!';
                                                          ELSE
                                                             IF ( SELECT    COUNT(1) AS COUNT
                                                                  FROM      pos_takeStorageList ptsl
                                                                  INNER JOIN pos_takeStorage pts
                                                                            ON ptsl.tsl_ts_id = pts.ts_id
                                                                  WHERE     pts.ts_status != 0
                                                                            AND ptsl.tsl_status > 0
                                                                            AND ptsl.tsl_gi_id = @id
                                                                ) > 0
                                                                SET @result = '已被店铺盘点引用,不可删除!';
          END

       IF @op_type = '商品规格'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    j_purchaseStorage fd
                            WHERE   pl_id IN ( SELECT   pll_pl_id
                                               FROM     j_purchaseStorageList fd
                                               WHERE    fd.pll_sku_id = @id
                                                        AND fd.pll_status > 0 )
                                    AND pl_status > 0 )
                   SET @result = '已被采购引用,不可删除!';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     j_enterStorage
                               WHERE    eo_id IN ( SELECT   fd.el_eoid
                                                   FROM     j_enterStorageList fd
                                                   WHERE    fd.el_skuid = @id
                                                            AND fd.el_status > 0 )
                                        AND eo_status > 0 )
                      SET @result = '已被入库引用,不可删除!';
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      j_outStorage
                                  WHERE     oo_id IN ( SELECT   fd.ol_eoid
                                                       FROM     j_outStorageList fd
                                                       WHERE    fd.ol_skuid = @id
                                                                AND fd.ol_status > 0 )
                                            AND oo_status > 0 )
                         SET @result = '已被出库引用,不可删除!';
                      ELSE
                         IF EXISTS ( SELECT 1
                                     FROM   j_moStorage
                                     WHERE  mo_id IN ( SELECT   fd.mol_mo_id
                                                       FROM     j_moStorageList fd
                                                       WHERE    fd.mol_sku_id = @id
                                                                AND fd.mol_status > 0 )
                                            AND mo_status > 0 )
                            SET @result = '已被移仓引用,不可删除!';
                         ELSE
                            IF EXISTS ( SELECT  1
                                        FROM    j_plStorage
                                        WHERE   pl_id IN ( SELECT   fd.ppl_pl_id
                                                           FROM     j_plStorageList fd
                                                           WHERE    fd.ppl_sku_id = @id
                                                                    AND fd.ppl_status > 0 )
                                                AND pl_status > 0 )
                               SET @result = '已被盈亏引用,不可删除!';
                            ELSE
                               IF EXISTS ( SELECT   1
                                           FROM     j_takeStorage
                                           WHERE    ts_id IN ( SELECT   fd.tsl_ts_id
                                                               FROM     j_takeStorageList fd
                                                               WHERE    fd.tsl_sku_id = @id
                                                                        AND fd.tsl_status > 0 )
                                                    AND ts_status > 0 )
                                  SET @result = '已被盘点引用,不可删除!';
                               ELSE
                                  IF EXISTS ( SELECT    1
                                              FROM      pos_allocation
                                              WHERE     al_id IN ( SELECT   fd.all_al_id
                                                                   FROM     pos_allocationList fd
                                                                   WHERE    fd.all_sku_id = @id
                                                                            AND fd.all_status > 0 )
                                                        AND al_status > 0 )
                                     SET @result = '已被配货引用,不可删除!';
                                  ELSE
                                     IF EXISTS ( SELECT 1
                                                 FROM   pos_ogStorageList fd
                                                 INNER JOIN pos_ogStorage fs
                                                        ON fd.ogl_og_id = fs.og_id
                                                 WHERE  fd.ogl_sku_id = @id
                                                        AND fs.og_status > 0
                                                        AND fd.ogl_status > 0 )
                                        SET @result = '已被订单引用,不可删除!';
                                     ELSE
                                        IF ( SELECT COUNT (1) AS count FROM vi_stockList fd WITH (NOLOCK) WHERE fd.skuid= @id
                                           ) > 0
                                           SET @result = '已产生总部库存,不可删除!';
                                        ELSE
                                           IF ( SELECT COUNT (1) AS count FROM vi_pos_stockList fd WITH (NOLOCK) WHERE fd.skuid= @id
                                              ) > 0
                                              SET @result = '已产生店铺库存,不可删除!';
                                           ELSE
                                              IF ( SELECT   COUNT(1) AS count
                                                   FROM     j_takeStorageList jtsl
                                                   INNER JOIN j_takeStorage jts
                                                            ON jtsl.tsl_ts_id = jts.ts_id
                                                   WHERE    jts.ts_status != 0
                                                            AND jtsl.tsl_status > 0
                                                            AND jtsl.tsl_sku_id = @id
                                                 ) > 0
                                                 SET @result = '已被总部盘点引用,不可删除!';
                                              ELSE
                                                 IF ( SELECT    COUNT(1) AS COUNT
                                                      FROM      pos_takeStorageList ptsl
                                                      INNER JOIN pos_takeStorage pts
                                                                ON ptsl.tsl_ts_id = pts.ts_id
                                                      WHERE     pts.ts_status != 0
                                                                AND ptsl.tsl_status > 0
                                                                AND ptsl.tsl_sku_id = @id
                                                    ) > 0
                                                    SET @result = '已被店铺盘点引用,不可删除!';
          END

       IF @op_type = '商品分类'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_goodsinfo
                            WHERE   CHARINDEX(CONVERT(VARCHAR(50), @id), gi_typesid) > 0
                                    AND gi_status > 0 )
                   SET @result = '已被商品引用,不可删除!';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     s_goodsclass bg
                               WHERE    bg.gc_isdel > 0
                                        AND bg.gc_fid = @id
                                        AND bg.gc_status > 0 )
                      SET @result = '该类型已有子节点,不可删除!';
          END

       IF @op_type = '商品规格大类'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    s_goodsruledetail fd
                            WHERE   fd.gs_id = @id )
                   SET @result = '已有规格,不可删除!';
          END

       IF @op_type = '商品规格小类'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_goodsruleset fd
                            WHERE   CHARINDEX('-' + CONVERT(VARCHAR(100), '@id'), fd.gs_id, 0) != 0 )
                   SET @result = '';
          END

       IF @op_type = '品牌'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_goodsinfo fd
                            WHERE   fd.gi_brandsid = @id
                                    AND fd.gi_status > 0 )
                   SET @result = '已被商品引用,不可删除!'
          END

       IF @op_type = '单位'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_goodsinfo fd
                            WHERE   fd.gi_unit = @id
                                    AND fd.gi_status > 0 )
                   SET @result = '已被商品引用,不可删除!'
          END

       IF @op_type = '客户分类'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_clientinfo AS fd
                            WHERE   fd.ci_flid = @id
                                    AND fd.ci_status > 0 )
                   SET @result = '已被客户引用,不可删除!'
    
                IF EXISTS ( SELECT  1
                            FROM    cors_type fd
                            WHERE   fd.type_fid = @id
                                    AND fd.type_status > 0 )
                   SET @result = '已有子节点,不可删除!'
          END

       IF @op_type = '供应商分类'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_supplierinfo AS fd
                            WHERE   fd.si_flid = @id
                                    AND fd.si_status > 0 )
                   SET @result = '已被供应商引用,不可删除!'
    
                IF EXISTS ( SELECT  1
                            FROM    cors_type fd
                            WHERE   fd.type_fid = @id
                                    AND fd.type_status > 0 )
                   SET @result = '已有子节点,不可删除!'
          END

       IF @op_type = '公司'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_stafftinfo AS fd
                            WHERE   fd.si_company = @id
                                    AND fd.si_status > 0 )
                   SET @result = '该公司已有帐号,不可删除!'
          END

       IF @op_type = '店铺'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    b_stafftinfo AS fd
                            WHERE   fd.si_shop_id = @id
                                    AND fd.si_isdel > 0
                                    AND fd.si_status > 0 )
                   SET @result = '该店铺已有帐号,不可删除!'
          END
	   ----------------------------POS--------------------------------
       IF @op_type = 'P仓库'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    vi_pos_stockSum AS fd
                            WHERE   fd.[sid] = @id )
                   SET @result = '已被商品引用,不可删除!'
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     pos_alStorage AS fd
                               WHERE    fd.al_st_id = @id
                                        AND fd.al_status > 0 )
                      SET @result = '已被调拨引用，不可删除!'
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      pos_initStorage AS fd
                                  WHERE     fd.in_st_id = @id
                                            AND fd.in_status > 0 )
                         SET @result = '已被商品期初库存引用，不可删除!'
                      ELSE
                         IF EXISTS ( SELECT 1
                                     FROM   pos_inStorage AS fd
                                     WHERE  fd.in_st_id = @id
                                            AND fd.in_status > 0 )
                            SET @result = '已被入库引用，不可删除!'
                         ELSE
                            IF EXISTS ( SELECT  1
                                        FROM    pos_moStorage AS fd
                                        WHERE   fd.mo_out_st_id = @id
                                                AND fd.mo_status > 0 )
                               OR EXISTS ( SELECT   1
                                           FROM     j_moStorage fd
                                           WHERE    fd.mo_in_st_id = @id
                                                    AND fd.mo_status > 0 )
                               SET @result = '已被移仓引用，不可删除!'
                            ELSE
                               IF EXISTS ( SELECT   1
                                           FROM     pos_alStorage AS fd
                                           WHERE    fd.al_st_id = @id
                                                    AND fd.al_status > 0 )
                                  SET @result = '已被盈亏引用，不可删除!'
                               ELSE
                                  IF EXISTS ( SELECT    1
                                              FROM      pos_takeStorage AS fd
                                              WHERE     fd.ts_st_id = @id
                                                        AND fd.ts_status > 0 )
                                     SET @result = '已被盘点引用，不可删除!'
          END

       IF @op_type = 'P班别'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    pos_staffClassSet AS fd
                            WHERE   fd.st_cl_id = @id )
                   SET @result = '已被员工班别管理引用，不可删除!'
          END

       IF @op_type = 'P会员'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    vi_stockSum AS fd
                            WHERE   fd.[sid] = @id )
                   SET @result = '该会员已有商品入驻，无法删除!'
          END

       IF @op_type = 'P供应商分类'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    pos_supplierinfo AS fd
                            WHERE   fd.si_flid = @id
                                    AND fd.si_status > 0 )
                   SET @result = '已被供应商档案引用，不可删除!'
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     pos_cors_type AS fd
                               WHERE    type_fid = @id
                                        AND fd.type_status > 0 )
                      SET @result = '该分类已有子节点，不可删除!'
          END

       IF @op_type = 'P供应商'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    pos_inStorage AS fd
                            WHERE   fd.in_supplier_sh_id = @id
                                    AND fd.in_source = 0
                                    AND fd.in_status > 0 )
                   SET @result = '已被入库引用,不可删除!'
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     pos_funds AS fd
                               WHERE    fd.fu_ci_id = @id
                                        AND fd.fu_status > 0 )
                      SET @result = '已被应付登记引用，不可删除!'
          END

       SELECT   @result AS info
go

