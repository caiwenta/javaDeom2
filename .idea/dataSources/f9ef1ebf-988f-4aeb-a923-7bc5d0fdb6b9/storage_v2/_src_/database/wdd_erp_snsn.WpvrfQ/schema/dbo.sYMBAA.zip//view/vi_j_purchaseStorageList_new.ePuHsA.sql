



CREATE VIEW [dbo].[vi_j_purchaseStorageList_new]
AS

SELECT pll_pl_id,
       pll_gi_id,
	   pll_boxbynum,
       --pll_source_add_time,
       pll_add_time AS pll_add_time,
       SUM(pll_pause_num)              AS pll_pause_num,
       SUM(pll_num)                    AS pll_num,
       MIN(pll_id)                     AS pll_id,
       MAX(pll_sku_id)                 AS pll_sku_id,
       CONVERT(DECIMAL(10, 2), AVG(pll_stock_price)) AS pll_stock_price,
       MAX(pll_discount)               AS pll_discount,
       SUM(pll_money)                  AS pll_money,
       CONVERT(DECIMAL(10, 2), AVG(pll_retail_price)) AS pll_retail_price,
       MAX(pll_status)                 AS pll_status,
       REPLACE(pll_pm, '*', ',')  AS pll_pm,
       SUM(pll_box_num)                 AS pll_box_num,
	   max(pll_pddate)                 as pll_pddate,
	   max(pll_pdgddate)               as pll_pdgddate,
	   sum(pll_integral) as pll_integral,
	   sum(pll_totalintegral) as pll_totalintegral
FROM   dbo.j_purchaseStorageList AS jt
where jt.pll_status=1
GROUP BY
       pll_pl_id,
       pll_gi_id,
	   pll_boxbynum,
       pll_add_time,
	   pll_pm
       --pll_source_add_time


go

