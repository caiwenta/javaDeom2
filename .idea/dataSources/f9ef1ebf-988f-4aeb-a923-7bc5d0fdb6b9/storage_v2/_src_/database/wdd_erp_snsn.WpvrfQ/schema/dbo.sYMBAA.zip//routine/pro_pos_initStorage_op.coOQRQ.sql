CREATE PROC [dbo].[pro_pos_initStorage_op]
@inl_box_num INT = 0,@inl_pm VARCHAR(500) = '',
--主键  
@in_id INT = 0,  
@inl_erp_id INT = 0,
@in_erp_id INT = 0,
--店铺主键  
--店铺主键  
@in_sh_id INT = 0,  
--期初日期  
@in_date DATETIME = '2014-10-24',  
--单据号  
@in_no VARCHAR(50) = '',  
--仓库主键  
@in_st_id INT = 0,  
--制单人主键  
@in_order_man INT = 0,  
--添加人主键  
@in_add_man INT = 0,  
--添加时间  
@in_add_time DATETIME = '2014-10-24',  
--修改人主键  
@in_update_man INT = 0,  
--修改时间  
@in_update_time DATETIME = '2014-10-24',  
--审核人主键  
@in_audit_man INT = 0,  
--审核时间  
@in_audit_time DATETIME = '2014-10-24',  
--备注  
@in_remark VARCHAR(50) = '',  
--主键  
@inl_id INT = 0,  
--产品期初库存主键  
@inl_in_id INT = 0,  
--商品主键  
@inl_gi_id INT = 0,  
--商品sku主键  
@inl_sku_id INT = 0,  
--数量  
@inl_num INT = 0,  
--零售价  
@inl_retail_price DECIMAL(9, 2) = 0,  
--折扣
@inl_discount DECIMAL(9, 2) = 0,
--进货价  
@inl_stock_price DECIMAL(9, 2) = 0,  
--进货金额  
@inl_money DECIMAL(9, 2) = 0,  
--添加时间  
@inl_add_time DATETIME = '2014-10-24',  
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',

@negative_inventory INT=0,  
--结果  
@result VARCHAR(100) = '' OUT,
--保存字符串
@savestr VARCHAR(MAX)='',
@orderguid VARCHAR(500) = '' --唯一guid
AS
BEGIN
	
	DECLARE @old_sei_id INT=0;
	DECLARE @new_sei_id INT=0;
	SET @new_sei_id=@in_st_id;
	
	--是否添加单据
	DECLARE @isInsert INT = 0;
	--是否需要更新单据
	DECLARE @need_update INT = 0;
	--旧的单据日期
	DECLARE @old_order_date DATETIME;
	--单据日期是否更改
	DECLARE @old_order_date_is_changed INT = 0;
	--凭证号前缀
	DECLARE @myprevTxt VARCHAR(50) = 'QC';
	BEGIN TRAN
	IF @op_type = '添加修改单据,明细'
	BEGIN
	    IF @in_id = 0
	    BEGIN
	        --添加单据
	        INSERT INTO pos_initStorage
	          (
	            in_sh_id,
	            in_vo,
	            in_date,
	            in_no,
	            in_st_id,
	            in_order_man,
	            in_add_man,
	            in_add_time,
	            in_update_man,
	            in_update_time,
	            in_remark,
	            in_status,in_erp_id
	          )
	        VALUES
	          (
	            @in_sh_id,
	            NEWID(),
	            @in_date,
	            @in_no,
	            @in_st_id,
	            @in_order_man,
	            @in_add_man,
	            @in_add_time,
	            @in_update_man,
	            @in_update_time,
	            @in_remark,
	            1,@in_erp_id
	          );
	        SET @in_id = SCOPE_IDENTITY();
	        
	        SET @inl_in_id = @in_id;
	        SET @isInsert = 1;
	    END
	    ELSE
	    BEGIN
	        SET @need_update = 1;
	    END
	    IF EXISTS(
	           SELECT *
	           FROM   pos_initStorageList AS jt
	           WHERE  jt.inl_in_id = @in_id
	                  AND jt.inl_status = 1
	                  AND jt.inl_add_time = @inl_add_time
	                  AND jt.inl_gi_id != @inl_gi_id
	       )
	    BEGIN
	        UPDATE pos_initStorageList
	        SET    inl_status           = 0
	        WHERE  inl_in_id            = @in_id
	               AND inl_add_time     = @inl_add_time
	               AND inl_status       = 1
	               AND inl_gi_id != @inl_gi_id;
	        SET @inl_id = 0;
	    END
	    
	    --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
	    DECLARE @savestr_item VARCHAR(MAX)='';
	    --起始数值,每次循环后递增
	    DECLARE @start_int INT=1;
	    --终止数值
		DECLARE @end_int INT=1;

		IF @orderguid = ''
		BEGIN

			IF @savestr!='' 
			--AND 1=2
			BEGIN
	    		--得到明细数量
	    		--即要循环的次数
	    		SELECT @end_int=(LEN(@savestr)-LEN(REPLACE(@savestr,'|','')))
			END
			WHILE @start_int<=@end_int
			BEGIN
	           
	           
			--动态赋值
			IF @savestr!='' 

			BEGIN
	    		SET @savestr_item=dbo.Get_StrArrayStrOfIndex(@savestr,'|',@start_int);
	    		IF(RTRIM(LTRIM(@savestr_item))='')
				BEGIN
					BREAK;
				END
				ELSE
				BEGIN

					SET @inl_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));
				
					SET @inl_gi_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));
				
					SET @inl_sku_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3));
				
					SET @inl_num=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));
				
					SET @inl_retail_price=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5));
				
					SET @inl_stock_price=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',6));
				
					SET @inl_discount=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',7));
				

				END
			END	
	    
			IF @inl_id = 0
			BEGIN
				INSERT INTO pos_initStorageList
					(
					inl_in_id,
					inl_gi_id,
					inl_sku_id,
					inl_num,
					inl_retail_price,
					inl_stock_price,
					inl_money,
					inl_status,
					inl_add_time,
					inl_discount,
					inl_box_num,
					inl_pm,inl_erp_id
					)
				VALUES
					(
					@inl_in_id,
					@inl_gi_id,
					@inl_sku_id,
					@inl_num,
					@inl_retail_price,
					@inl_stock_price,
					@inl_money,
					1,
					@inl_add_time,
					@inl_discount,
					@inl_box_num,
					@inl_pm,@inl_erp_id
					);
				SET @inl_id = SCOPE_IDENTITY();
			END
			ELSE
			BEGIN
				UPDATE pos_initStorageList
				SET    inl_in_id            = @inl_in_id,
						inl_gi_id            = @inl_gi_id,
						inl_sku_id           = @inl_sku_id,
						inl_num              = @inl_num,
						inl_retail_price     = @inl_retail_price,
						inl_stock_price      = @inl_stock_price,
						inl_money            = @inl_money,
						inl_discount         = @inl_discount,
						inl_box_num          = @inl_box_num,
						inl_pm               = @inl_pm
				WHERE  inl_id               = @inl_id;
			END
			SET @start_int=@start_int+1;
		END

	    END
		
		ELSE
		   
		   BEGIN

				MERGE INTO pos_initStorageList AS ta
					USING
					(
						    SELECT   @in_id as inl_in_id,
                                    gi_id ,
                                    sku_id ,
                                    pm ,
                                    erp_id ,
                                    number ,
                                    discount ,--折扣
                                    retailprice ,--销售价
                                    purchase ,--进货价
                                    number * purchase as [money],--进货金额
                                    orderstatus ,
                                    box_num 
                            FROM    erp_goodslisttemp
                            WHERE   orderguid = @orderguid 
					) AS so on  ta.inl_gi_id=so.gi_id AND ta.inl_sku_id=so.sku_id and  ta.inl_in_id=so.inl_in_id and ta.inl_status=1
						WHEN MATCHED THEN  UPDATE
                        SET  
						ta.inl_num += so.number,
						ta.inl_money=((ta.inl_num+so.number)*so.purchase)
						WHEN NOT MATCHED THEN
                            INSERT
                            (inl_in_id ,
                                inl_gi_id ,
                                inl_sku_id ,
                                inl_pm ,
                                inl_erp_id ,
                                inl_num ,
                                inl_discount , --折扣
                                inl_retail_price , --零售价
                                inl_stock_price , --供货价
                                inl_money ,--进货金额
                                inl_status ,
                                inl_box_num ,
                                inl_add_time)
								VALUES
							(
                                so.inl_in_id ,
                                so.gi_id ,
                                so.sku_id ,
                                so.pm ,
                                so.erp_id ,
                                so.number ,
                                so.discount ,--折扣
                                so.retailprice ,--销售价
                                so.purchase ,--进货价
                                so.[money] ,--进货金额
                                so.orderstatus ,
                                so.box_num ,
                                    (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
							        SELECT GETDATE() as nows,
                                    (SELECT TOP 1 inl_add_time FROM pos_initStorageList WHERE inl_gi_id=so.gi_id AND inl_in_id=so.inl_in_id) AS addtime) AS TT)
									);

				exec pro_setGoodsPurchasePrice @oo_id=@in_id,@wt=7;

           END   


	END
	IF @op_type = '审核单据'
	BEGIN
	    --审核单据
	    select  @in_st_id=in_st_id from pos_initStorage where in_id=@in_id;--得到仓库id
	    UPDATE pos_initStorage
	    SET    in_status         = 2,
	           in_audit_man      = @in_update_man,
	           in_audit_time     = GETDATE()
	    WHERE  in_id             = @in_id;
	END
	
	IF @op_type = '取消审核单据'
	BEGIN
	    --取消审核单据
	    select  @in_st_id=in_st_id from pos_initStorage where in_id=@in_id;--得到仓库id
	    UPDATE pos_initStorage
	    SET    in_status     = 1
	    WHERE  in_id         = @in_id;
	END
	
	IF @op_type = '删除单据'
	BEGIN
		
		SELECT @old_sei_id=fd.in_st_id
	      FROM pos_initStorage fd WHERE fd.in_id=@in_id;
	      
	      
	    --删除单据
	    select  @in_st_id=in_st_id from pos_initStorage where in_id=@in_id;--得到仓库id
	    UPDATE pos_initStorage
	    SET    in_status     = 0
	    WHERE  in_id         = @in_id;
	END
	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE pos_initStorageList
	    SET    inl_status     = 0
	    WHERE  inl_id         = @inl_id;
	END
	
	IF @op_type = '批量删除明细'
	BEGIN
		
		SELECT @old_sei_id=fd.in_st_id
		FROM pos_initStorage  fd WHERE fd.in_id=@in_id;
	      
		
	    UPDATE pos_initStorageList
	    SET    inl_status           = 0
	    WHERE  inl_in_id            = @inl_in_id
	           AND inl_add_time     = @inl_add_time
	           AND inl_gi_id        = @inl_gi_id;
	    
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   pos_initStorageList AS jt
	           WHERE  jt.inl_in_id = @inl_in_id
	                  AND jt.inl_status = 1
	       )
	    BEGIN
	        UPDATE pos_initStorage
	        SET    in_status     = 0
	        WHERE  in_id         = @inl_in_id;
	    END
	END
	
	IF (@op_type = '添加修改单据,明细'
	   OR @need_update = 1
	   OR @op_type = '修改单据')
	   AND @isInsert !=1
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.in_date
	    FROM   pos_initStorage AS jt
	    WHERE  jt.in_id = @in_id;
	    IF @old_order_date != @in_date
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	     SELECT @old_sei_id=fd.in_st_id
	      FROM pos_initStorage fd WHERE fd.in_id=@in_id;
	      
	    
	    UPDATE pos_initStorage
	    SET    in_sh_id           = @in_sh_id,
	           in_date            = @in_date,
	           in_no              = @in_no,
	           in_st_id           = @in_st_id,
	           in_order_man       = @in_order_man,
	           in_update_man      = @in_update_man,
	           in_update_time     = @in_update_time,
	           in_remark          = @in_remark
	    WHERE  in_id              = @in_id;
	    
	    IF(SELECT fd.in_status FROM pos_initStorage  fd 
	       WHERE fd.in_id =@in_id )=0
	    BEGIN
	    	UPDATE pos_initStorage
	        SET    in_status = 1
	        WHERE  in_id = @in_id ;
	    END
	END
	
	
	IF @isInsert = 1
	   --OR @old_order_date_is_changed = 1
	BEGIN
	    --凭证号生成
	    --更新凭证号 
	    DECLARE @tableName VARCHAR(50) = 'pos_initStorage'
	    DECLARE @idField VARCHAR(50) = 'in_id'
	    DECLARE @idValue INT = @in_id;
	    
	    DECLARE @dateField VARCHAR(50) = 'in_date'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @in_date, 23)
	    
	    DECLARE @noField VARCHAR(50) = 'in_vo'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN
	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	             @idField,
	             @idValue,
	             @dateField,
	             @dateValue,
	             @noField,
	             @prevTxt,
	             @outno OUTPUT,
	             @in_sh_id
	        
	        BEGIN TRY
	        	--更新
	        	UPDATE pos_initStorage
	        	SET    in_vo     = @outno
				,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)

	        	WHERE  in_id     = @in_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
			PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
	        END CATCH
	    END
	END
	
	IF @op_type!='审核单据' and @op_type!='取消审核单据'
	BEGIN
	EXECUTE [dbo].[pro_pos_mergeStockLog] 
	        @tsl_sh_id = @in_sh_id,
	        @negative_inventory=@negative_inventory,
            @old_sei_id =@old_sei_id, 
            @new_sei_id =@new_sei_id  
	IF @@ERROR <> 0
	BEGIN
	    SET @result = '0';

	    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	    RETURN 0;
	END
	END
	
	
	
	IF @@ERROR <> 0
	BEGIN
	    SET @result = '0';

	    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @in_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细'
                           AND @orderguid = ''
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @inl_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END
END
go

