
CREATE TRIGGER [dbo].[trg_c_fundorder_insert] ON [dbo].[c_fundorder]
       AFTER INSERT
AS
BEGIN
       DECLARE @id INT= 0;
       DECLARE @old_ciid INT= 0;
       DECLARE @old_bs VARCHAR(50)= '';
       DECLARE @fo_type INT= 0;
       DECLARE @fo_to_cpid INT= 0;
       DECLARE @fo_shid INT= 0;

       SELECT   @id = fo_id ,
                @old_bs = fo_bs ,
                @old_ciid = fo_ciid ,
                @fo_to_cpid = fo_to_cpid ,
                @fo_shid = fo_shid ,
                @fo_type = fo_type
       FROM     INSERTED

       UPDATE   c_fundorder
       SET      fo_rowNum = cfu.rowNum
       FROM     c_fundorder cfo ,
                ( SELECT    ROW_NUMBER() OVER ( ORDER BY cf.fo_ciid, cf.fo_bs, fo_ofdate, cf.fo_id ) AS rowNum ,
                            cf.fo_id
                  FROM      c_fundorder cf WITH ( NOLOCK )
                  WHERE     cf.fo_status = 2
                            AND cf.fo_bs = @old_bs
                            AND cf.fo_ciid = @old_ciid
                ) cfu
       WHERE    cfo.fo_id = cfu.fo_id
END
go

disable trigger trg_c_fundorder_insert on c_fundorder
go

