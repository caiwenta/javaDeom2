CREATE proc pro_ordergoods_edit
@oi_id int,
@og_serialid varchar(50),
@el_id int,
@gs_id int,
@gs_name varchar(50),
@og_buynum int,
@gs_weight decimal(16,2),
@og_actualprice decimal(16,2),
@og_id int,
@outResult int output
as
begin transaction
--获取商品货号,商品id,商品标题,商品图片,市场价
declare @og_goodsno varchar(50),@og_title varchar(500),@og_picurl varchar(500),@og_marketprice decimal(10,2),@og_buyprice decimal(10,2)
select @og_goodsno=gi_code,@og_title=gi_name,@og_picurl=si_img,@og_marketprice=gi_importprices,@og_buyprice=gi_costprice from b_goodsinfo where gi_id=@el_id
if(@og_id=0)begin--添加
INSERT INTO m_ordergoods
           ([oi_id]
           ,[og_serialid]
           ,[og_goodsno]
           ,[og_goodsid]
           ,[og_title]
           ,[og_picurl]
           ,[og_buynum]
           ,[og_marketprice]
           ,[og_buyprice]
           ,[og_actualprice]
           ,[gs_id]
           ,[gs_name]
           ,[gs_weight])
     VALUES
           (@oi_id
           ,@og_serialid
           ,@og_goodsno
           ,@el_id
           ,@og_title
           ,@og_picurl
           ,@og_buynum
           ,@og_marketprice
           ,@og_buyprice
           ,@og_actualprice
           ,@gs_id
           ,@gs_name
           ,@gs_weight)
    UPDATE m_OrderInfo SET oi_number=oi_number+@og_buynum,oi_totalmoney=oi_totalmoney+@og_buyprice*@og_buynum,oi_realmoney=oi_realmoney+@og_actualprice*@og_buynum WHERE oi_no=@og_serialid
    --select * from m_OrderInfo
end else begin--修改
	UPDATE m_ordergoods SET 
	[oi_id]=@oi_id
   ,[og_serialid]=@og_serialid
   ,[og_goodsno]=@og_goodsno
   ,[og_goodsid]=@el_id
   ,[og_title]=@og_title
   ,[og_picurl]=@og_picurl
   ,[og_buynum]=@og_buynum
   ,[og_marketprice]=@og_marketprice
   ,[og_buyprice]=@og_buyprice
   ,[og_actualprice]=@og_actualprice
   ,[gs_id]=@gs_id
   ,[gs_name]=@gs_name
   ,[gs_weight]=@gs_weight 
   WHERE og_id=@og_id
   UPDATE m_OrderInfo SET oi_number=oi_number-@og_buynum,oi_totalmoney=oi_totalmoney-@og_buyprice*@og_buynum,oi_realmoney=oi_realmoney-@og_actualprice*@og_buynum WHERE oi_no=@og_serialid
end
if @@error <> 0
begin 
   IF @@TRANCOUNT > 0 rollback transAction
   set @outResult=0
end
else
begin
    IF @@TRANCOUNT > 0 commit transaction
    set @outResult=1
end
go

