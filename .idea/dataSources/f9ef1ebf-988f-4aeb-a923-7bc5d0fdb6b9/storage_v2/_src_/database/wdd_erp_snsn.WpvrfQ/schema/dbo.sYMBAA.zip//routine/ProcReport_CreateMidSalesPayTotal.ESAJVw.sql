
CREATE PROCEDURE ProcReport_CreateMidSalesPayTotal
@outerr   int output,
@mid   int,
@today   datetime=null --默认当前月时间，统计上一个月的数据
AS
------------------------------------
--用途：统计商户月份支付情况 
--时间：2015-6-26
------------------------------------
SET NOCOUNT ON 
SET @outerr=0
DECLARE @now  DATETIME; SET @now=GETDATE();
DECLARE @moneth  INT   
DECLARE @date  INT
DECLARE @begintime DATETIME
DECLARE @endtime   DATETIME 
IF(@today IS NULL) SET @today=@now

set @today=convert(varchar(20),dateadd(MONTH,-1,@today),120)

SET @date=CAST(REPLACE(CONVERT(VARCHAR(8),@today,120),'-','') AS INT)*100

IF((SELECT COUNT(1) FROM rep_midpaytotal WHERE mpt_mid=@mid AND mpt_date=@date)>0)BEGIN SET @outerr=-2 RETURN END--已经生成过的数据不在生成

SET @moneth=MONTH(@today)
SET @begintime=CAST(CONVERT(VARCHAR(10),CONVERT(datetime,CONVERT(char(8),@today,120)+'1')-1,120)+' 23:59:59:998' AS DATETIME);
SET @endtime=DATEADD(Day,-1,CONVERT(char(8),DATEADD(Month,1,@today),120)+'1')+1
--select @date,@moneth,@begintime,@endtime
DECLARE @mpt_unionpayorders  int    
DECLARE @mpt_unionpayamt  decimal(10,2)
 SELECT @mpt_unionpayorders=COUNT(1),@mpt_unionpayamt=ISNULL(SUM(vo_total),0) FROM v_order vo inner join m_paymenttype pt on pt.pt_id=vo.pt_id  
  WHERE pt_name like '%银联%' AND vo_state>0 AND (vo_paydate>@begintime AND vo_paydate<@endtime) AND vo_mid=@mid
DECLARE @mpt_shoporder   int
DECLARE @mpt_shopunionpay  decimal(10,2)
 SELECT @mpt_shoporder=COUNT(1),@mpt_shopunionpay=ISNULL(SUM(ap_cost),0) FROM v_agent_pay ap inner join m_paymentway pw on pw.pw_id=ap.pw_id inner join m_paymenttype pt on pt.pt_id=pw.pt_id  
  WHERE pt_name like '%银联%' AND ap_state>0 and ISNULL(ap_refund,0)=0 AND (ap_paydate>@begintime AND ap_paydate<@endtime) AND ap.mid=@mid
  

INSERT INTO [rep_midpaytotal]([mpt_mid],[mpt_date],[mpt_addtime],[mpt_month],[mpt_unionpayorders],[mpt_unionpayamt],[mpt_shoporder],[mpt_shopunionpay])
VALUES(@mid,@date,GETDATE(),@moneth,@mpt_unionpayorders,@mpt_unionpayamt,@mpt_shoporder,@mpt_shopunionpay)
IF(@@ROWCOUNT>0)
BEGIN
 SET @outerr=1
END
 
SET NOCOUNT OFF
go

