CREATE TRIGGER [dbo].[trg_b_goodsruleset_after_delete] ON [dbo].[b_goodsruleset]
    AFTER DELETE
AS
BEGIN
    INSERT  INTO b_goodsruleset_delete_back
            ( gss_id ,
              gi_id ,
              gss_no ,
              gs_id ,
              gs_name ,
              gs_stock ,
              gs_salesprice ,
              gs_marketprice ,
              gs_costprice ,
              gs_weight ,
              gs_upstock ,
              gs_downstork ,
              gs_alarmstock ,
              gs_columnid ,
              gs_purchase ,
              gs_oc_id ,
              gs_addtime ,
              gs_updatetime ,
              gs_type_id ,
              gs_type_id_parentid ,
              gs_taobao_id ,
              gs_is_custom ,
              gs_discount ,
              gss_cp_id ,
              gss_di_id ,
              gs_status
            )
            SELECT  gss_id ,
                    gi_id ,
                    gss_no ,
                    gs_id ,
                    gs_name ,
                    gs_stock ,
                    gs_salesprice ,
                    gs_marketprice ,
                    gs_costprice ,
                    gs_weight ,
                    gs_upstock ,
                    gs_downstork ,
                    gs_alarmstock ,
                    gs_columnid ,
                    gs_purchase ,
                    gs_oc_id ,
                    gs_addtime ,
                    gs_updatetime ,
                    gs_type_id ,
                    gs_type_id_parentid ,
                    gs_taobao_id ,
                    gs_is_custom ,
                    gs_discount ,
                    gss_cp_id ,
                    gss_di_id ,
                    gs_status
            FROM    DELETED
END
go

