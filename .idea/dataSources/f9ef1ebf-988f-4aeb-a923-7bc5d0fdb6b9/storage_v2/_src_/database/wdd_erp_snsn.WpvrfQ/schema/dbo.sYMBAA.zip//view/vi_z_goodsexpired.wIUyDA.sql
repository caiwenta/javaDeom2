CREATE VIEW [dbo].[vi_z_goodsexpired]
as 
SELECT
 
(CASE WHEN shelflife<>0 THEN CONVERT(varchar,CONVERT(DECIMAL(10,0),(((remainderdays*0.1)/(shelflife*0.1))*100)))+'%' ELSE '' END) AS percentagedays, 
(gi_retailprice * gnum) AS gi_retailmoney,(gi_purchase * gnum) AS gi_purchasemoney,
* 
FROM
(
	
SELECT isnull(DateDiff (Day,GETDATE(),expdate),0) AS remainderdays,
*
 
FROM
(
		
SELECT 
ebn.productiondate,
ebn.expirationdate AS expdate,
isnull(ebn.shelflife,0) AS shelflife,
bg.gi_name,bg.gi_code,bg.gi_id,
bg.gi_retailprice,
bg.gi_purchase,
bg.gi_barcode,
bg.gi_costprice,
bg.gi_skuid,

bs.sei_id,bs.sei_name,bs.sei_is_tb,
bs.sei_cp_id as cp_id,bs.sei_erp_id as erp_id,
ss.*
 
FROM(
SELECT 
si_giid as si_giid,
si_seiid as si_seiid,
si_cp_id,
sum(si_number) as gnum,
MAX (si_indate) AS si_indate,
max(si_pm) as si_pm
FROM b_stockinfobatch 
WHERE si_status<>0
GROUP BY si_giid,si_seiid,si_cp_id,si_pm
) ss
INNER JOIN dbo.b_storageinfo  AS bs WITH (NOLOCK) ON  ss.si_seiid = bs.sei_id 
INNER JOIN dbo.b_goodsinfo AS bg WITH (NOLOCK) ON  ss.si_giid = bg.gi_id
LEFT JOIN erp_batchnumber AS ebn WITH (NOLOCK) ON ebn.bn_giid = bg.gi_id AND ebn.bn_pm=ss.si_pm
where gnum<>0
) AS sf
) AS ty
go

