CREATE PROCEDURE [dbo].[pro_mergeStockSumBatchNumber]
@cp_id INT=0,
@id INT=0,
@type INT=0,

@negative_inventory INT=0,--产生了负库存是否提示
@old_sei_id INT=0,  
@new_sei_id INT=0
AS
EXEC pro_mergeStockLog_check
	@cp_id = @cp_id,
	@negative_inventory = @negative_inventory,
	@old_sei_id = @old_sei_id,
	@new_sei_id = @new_sei_id
IF @@ERROR!=0
BEGIN
	DECLARE @ERROR_MESSAGE VARCHAR(100)='';
	select @ERROR_MESSAGE=ERROR_MESSAGE();
	RAISERROR (
			@ERROR_MESSAGE,	
			16,	
			1,	
			N'number',	
			5 
		);
	RETURN;
END
else
BEGIN


BEGIN TRAN

DECLARE @now DATETIME = GETDATE();

if(@type<>0)
begin

SELECT DISTINCT js.sl_giid INTO #g FROM j_stocklog js WHERE js.sl_type=@type
AND js.sl_eoid=@id
MERGE INTO b_stockinfobatch AS ta 
USING 
(

SELECT 
js.sl_seiid AS [sid],
js.sl_giid AS gid,
isnull(js.sl_pm,'')   as pm,
js.sl_skuid AS skuid,
js.sl_cp_id AS  cp_id,
SUM(
	CASE WHEN sl_status>0 THEN 
	CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE - js.sl_number END
	ELSE 
	0
	END	
) AS gnum
FROM j_stocklog js WHERE  js.sl_cp_id=@cp_id AND js.sl_giid
IN(SELECT sl_giid FROM #g)
Group By 
js.sl_seiid,
js.sl_giid,
js.sl_skuid,
js.sl_cp_id,
isnull(js.sl_pm,'')

) AS so ON 
ta.si_seiid = so.[sid]  
AND ta.si_giid = so.gid 
AND ta.si_skuid = so.skuid 
AND ta.si_cp_id=so.cp_id 
AND ta.si_pm=so.pm
WHEN matched THEN 
UPDATE SET 
ta.si_number = so.gnum,
ta.si_status=1,
ta.si_indate=case when  ta.si_number!=so.gnum then @now else ta.si_indate END
WHEN NOT matched THEN
INSERT 
  (
    si_seiid,
    si_giid,
    si_skuid,
    si_number,
    si_status,
    si_indate,
    si_cp_id,
	si_pm
  )
VALUES
  (
    so.[sid],
    so.gid,
    so.skuid,
    so.gnum,
    1,
    @now,
    so.cp_id,
	isnull(so.pm,'')
  );

end
else
begin

MERGE INTO b_stockinfobatch AS ta 
USING 
(

Select 
sl.[sid],
sl.gid,
isnull(sl.pm,'')   as pm,
sl.skuid,
sl.cp_id,
Sum(Case when sl.countType=1 Then sl.gnum Else -sl.gnum End)As gnum,
MAX(sl.addtime) AS addtime
From vi_stockList_nolock sl WHERE sl.cp_id=@cp_id
Group By 
sl.[sid],
sl.gid,
sl.skuid,
sl.cp_id,
isnull(sl.pm,'')

) AS so
ON 
ta.si_seiid = so.[sid] 
AND ta.si_giid = so.gid 
AND ta.si_skuid = so.skuid 
AND ta.si_cp_id=so.cp_id 
AND ta.si_pm=so.pm
WHEN matched THEN 
UPDATE 
SET    
ta.si_number = so.gnum,
ta.si_status=1,
ta.si_indate=case when  ta.si_number!=so.gnum then @now else ta.si_indate END
WHEN NOT matched THEN
INSERT 
  (
    si_seiid,
    si_giid,
    si_skuid,
    si_number,
    si_status,
    si_indate,
    si_cp_id,
	si_pm
  )
VALUES
  (
    so.[sid],
    so.gid,
    so.skuid,
    so.gnum,
    1,
    @now,
    so.cp_id,
	isnull(so.pm,'')
   
  )
WHEN NOT matched BY source AND ta.si_status != 0 AND ta.si_cp_id=@cp_id THEN 
UPDATE 
SET    ta.si_number=0,
       ta.si_indate =CASE WHEN si_number!=0 THEN  @now ELSE si_indate END;

end

IF @@ERROR <> 0
BEGIN
	IF @@TRANCOUNT > 0 ROLLBACK TRAN;
END
ELSE
BEGIN
    IF @@TRANCOUNT > 0 COMMIT TRAN
END

END
go

