CREATE PROCEDURE [dbo].[pro_j_orderblank_op]
@mol_box_num INT = 0,
@mol_pm VARCHAR(500) = '',
--主键  
@mo_id INT = 0,  
@mo_erp_id INT = 0,  
@mol_erp_id INT = 0,  
--移出仓库  
@mo_out_st_id INT = 0,  
--移入仓库  
@mo_in_st_id INT = 0, 
@mo_locationid INT=0, 
--移出数量  
@mo_num INT = 0,  
--单据号  
@mo_no VARCHAR(50) = '',  
--移仓日期  
@mo_date DATETIME = '2014-10-31',  
--添加人主键  
@mo_add_man INT = 0,  
--添加时间  
@mo_add_time DATETIME = '2014-10-31',  
--修改人主键  
@mo_update_man INT = 0,  
--修改时间  
@mo_update_time DATETIME = '2014-10-31',  
--审核人主键  
@mo_audit_man INT = 0,  
--审核时间  
@mo_audit_time DATETIME = '2014-10-31',  
--制单人主键  
@mo_order_man INT = 0,  
--备注  
@mo_remark VARCHAR(50) = '',  
--主键  
@mol_id INT = 0,  
--移仓主键  
@mol_mo_id INT = 0,  
--商品主键  
@mol_gi_id INT = 0,  
--商品sku主键  
@mol_sku_id INT = 0,  
--日期库存数量  
@mol_stock_num INT = 0,  
--移出数量  
@mol_num INT = 0,  
--备注  
@mol_remark VARCHAR(50) = '',  
--添加时间  
@mol_add_time DATETIME = '2014-10-31',  
--零售价
@mol_retail_price DECIMAL(18, 2) = 0,
--进货价
@mol_stock_price DECIMAL(18, 2) = 0,
--折扣
@mol_discount DECIMAL(18, 2) = 0,
--金额
@mol_money DECIMAL(18, 2) = 0,
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  
--结果  
@result VARCHAR(100) = '' OUT,
--产生了负库存是否提示
@negative_inventory INT = 0,
--公司主键
@mo_cp_id INT = 0,
--部门主键
@mo_di_id INT = 0,
--保存字符串
@savestr VARCHAR(MAX)='',


@mo_type INT=0,
@orderguid VARCHAR(500)='', --唯一guid    
@isenablestocknum int=0                              
AS
BEGIN
	
	DECLARE @old_sei_id INT=0;
	DECLARE @new_sei_id INT=0;
	SET @new_sei_id=@mo_out_st_id;
	DECLARE @isInsert INT = 0;	--是否添加单据
	DECLARE @need_update INT = 0;	--是否需要更新单据
	DECLARE @old_order_date DATETIME;--旧的单据日期
	DECLARE @old_order_date_is_changed INT = 0;--单据日期是否更改
	DECLARE @myprevTxt VARCHAR(50) = 'OB';--凭证号前缀
	      
	                                      --
	 --按库位库存生成订单                                     
	IF @mo_locationid>0 AND @mo_type>0
	BEGIN
		SELECT 
		@mo_out_st_id=sei_id,
		@mo_in_st_id=sei_id
		FROM erp_storagelocation 
		WHERE slt_id=@mo_locationid AND erp_id=@mo_erp_id
	END




	
	BEGIN TRAN
	IF @op_type = '添加修改单据,明细'
	BEGIN
	    IF @mo_id = 0
	    BEGIN
	        --添加单据
	        INSERT INTO j_orderblank
	          (
	          	mo_locationid,
	            mo_out_st_id,
	            mo_in_st_id,
	            mo_num,
	            mo_vo,
	            mo_no,
	            mo_date,
	            mo_add_man,
	            mo_add_time,
	            mo_update_man,
	            mo_update_time,
	            mo_order_man,
	            mo_status,
	            mo_remark,
	            mo_cp_id,
	            mo_di_id,
	            mo_erp_id,
	            mo_type
	          )
	        VALUES
	          (
	          	@mo_locationid,
	            @mo_out_st_id,--
	            @mo_in_st_id,
	            @mo_num,
	            NEWID(),
	            @mo_no,
	            @mo_date,
	            @mo_add_man,
	            @mo_add_time,
	            @mo_update_man,
	            @mo_update_time,
	            @mo_order_man,
	            1,
	            @mo_remark,
	            @mo_cp_id,
	            @mo_di_id,
	            @mo_erp_id,
	            @mo_type
	          );
	        SET @mo_id = SCOPE_IDENTITY();
	        
	        SET @mol_mo_id = @mo_id;
	        SET @isInsert = 1;
	    END
	    ELSE
	    BEGIN
	        SET @need_update = 1;
	    END
	    
	    if @orderguid=''
		begin

	      IF @mo_type=0
	      BEGIN
	      	
	    	IF EXISTS(
	           SELECT *
	           FROM   j_orderblanklist AS jt
	           WHERE  jt.mol_mo_id = @mo_id
	                  AND jt.mol_status = 1
	                  AND jt.mol_add_time = @mol_add_time
	                  AND jt.mol_gi_id != @mol_gi_id
	       )
	    BEGIN
	        UPDATE j_orderblanklist
	        SET    mol_status           = 0
	        WHERE  mol_mo_id            = @mo_id
	               AND mol_add_time     = @mol_add_time
	               AND mol_status       = 1
	               AND mol_gi_id != @mol_gi_id;
	        SET @mol_id = 0;
	    END
			SELECT @mol_stock_num = ISNULL(
	               SUM(
	                   CASE 
	                        WHEN js.sl_counttype = 1 THEN js.sl_number
	                        ELSE -js.sl_number
	                   END
	               ),
	               0
	           )
	    FROM   j_stocklog AS js
	    WHERE  js.sl_seiid = @mo_out_st_id
	           AND (
	                   (
	                       CONVERT(VARCHAR(50), js.sl_order_date, 23) <= @mo_date
	                   )
	                   OR js.sl_type = 3
	               )
	           AND js.sl_status != 0
	           AND js.sl_giid = @mol_gi_id
			   and js.sl_pm=@mol_pm
	    GROUP BY
	           js.sl_giid,
			   isnull(js.sl_pm,'')
			 --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
			DECLARE @savestr_item VARCHAR(MAX)='';
			--起始数值,每次循环后递增
			DECLARE @start_int INT=1;
			--终止数值
			DECLARE @end_int INT=1;
			IF @savestr!='' 
			--AND 1=2
			BEGIN
	    	--得到明细数量
	    	--即要循环的次数
	    	SELECT @end_int=(LEN(@savestr)-LEN(REPLACE(@savestr,'|','')))
	    END
			WHILE @start_int<=@end_int
			BEGIN
			--动态赋值
			IF @savestr!='' 

	    BEGIN
	    	SET @savestr_item=dbo.Get_StrArrayStrOfIndex(@savestr,'|',@start_int);
	    	IF(RTRIM(LTRIM(@savestr_item))='')
			BEGIN
				BREAK;
			END
			ELSE
			BEGIN

				SET @mol_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));
				
				SET @mol_gi_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));
				
				SET @mol_sku_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3));
				
				SET @mol_num=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));
				
				SET @mol_retail_price=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5));
				
				SET @mol_stock_price=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',6));
				
				SET @mol_discount=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',7));

				
			END
			--SET @start_int=@start_int+1;
	    END	
			IF @mol_id = 0
			BEGIN
				INSERT INTO j_orderblanklist
	          (
	            mol_mo_id,
	            mol_gi_id,
	            mol_sku_id,
	            mol_stock_num,
	            mol_num,
	            mol_remark,
	            mol_status,
	            mol_add_time,
	            mol_retail_price,
	            mol_discount,
	            mol_stock_price,
	            mol_money,
	            mol_box_num,
	            mol_pm,
	            mol_erp_id
	          )
				VALUES
	          (
	            @mol_mo_id,
	            @mol_gi_id,
	            @mol_sku_id,
	            @mol_stock_num,
	            @mol_num,
	            @mol_remark,
	            1,
	            @mol_add_time,
	            @mol_retail_price,
	            @mol_discount,
	            @mol_stock_price,
	            @mol_num * @mol_stock_price,
	            @mol_box_num,
	            @mol_pm,
	            @mol_erp_id
	          );
	        SET @mol_id = SCOPE_IDENTITY();
			 END
			 ELSE
			 BEGIN
	        UPDATE j_orderblanklist
	        SET    mol_mo_id            = @mol_mo_id,
	               mol_gi_id            = @mol_gi_id,
	               mol_sku_id           = @mol_sku_id,
	               mol_stock_num        = @mol_stock_num,
	               mol_num              = @mol_num,
	               mol_remark           = @mol_remark,
	               mol_discount         = @mol_discount,
	               mol_retail_price     = @mol_retail_price,
	               mol_stock_price      = mol_stock_price,
	               mol_money            = @mol_num * @mol_stock_price,
	               mol_box_num          = @mol_box_num,
	               mol_pm               = @mol_pm	        
	        WHERE  mol_id               = @mol_id;
			END
			SET @start_int=@start_int+1;
			END
		  END	
		
		  IF @mo_type=1
		  BEGIN
		  	 INSERT INTO j_orderblanklist
	          (
	            mol_mo_id,
	            mol_gi_id,mol_sku_id,
	            mol_stock_num,
				mol_num,
	            mol_status,mol_add_time,mol_box_num,mol_pm,mol_erp_id
				,mol_locationid
	          )
		  	SELECT
		  	@mo_id,
			si_giid,si_skuid,
			gnum,
			enable_stock_num,
			1,GETDATE(),0,'',erp_id,
			@mo_locationid
			FROM v_z_stockinfolocation_detail WHERE slt_id=@mo_locationid AND enable_stock_num>0
		  END	--移出仓位
		
		
		
		end
		else
		begin
		 
		  MERGE INTO j_orderblanklist AS ta
					USING
					(
				  		SELECT  @mo_id as el_eoid, gi_id, sku_id,pm,gift,erp_id,
                        number,
						discount,--折扣
						retailprice,--零售价
                        purchase,--进货价
						orderstatus,
						box_num
						FROM  erp_goodslisttemp WHERE orderguid = @orderguid 
					  ) as so on ta.mol_gi_id=so.gi_id AND  ta.mol_sku_id=so.sku_id and  ta.mol_mo_id=so.el_eoid and ta.mol_status=1
					  WHEN MATCHED THEN  UPDATE
                           SET  
						   ta.mol_num += so.number,
						   ta.mol_money=((ta.mol_num+so.number)*so.purchase)
					  WHEN NOT MATCHED THEN
							INSERT 
							(mol_mo_id , mol_gi_id , mol_sku_id ,mol_pm ,mol_erp_id ,
							mol_num , 
							mol_discount , --折扣
							mol_retail_price , --零售价
							mol_stock_price, --进货价
							mol_money,--进货价金额
							mol_status ,
							mol_add_time
							)
							VALUES
							( 
							 so.el_eoid, so.gi_id, so.sku_id,so.pm,so.erp_id,
							 so.number,
							 so.discount,--折扣
							 so.retailprice,--销售价
							 so.purchase,--进货价
							 so.number* so.purchase,--进货价金额
							 so.orderstatus,
							 (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
							 SELECT GETDATE() as nows, (SELECT TOP 1 mol_add_time FROM j_orderblanklist WHERE mol_gi_id=so.gi_id AND mol_mo_id=so.el_eoid) AS addtime) AS TT)
					);

		end

		exec dbo.pro_setPmNumberSum @orderid=@mo_id, @erp_id=@mo_erp_id, @stockType=11;

	END
	

	IF @op_type = '审核单据'
	BEGIN
	    --审核单据
	    UPDATE j_orderblank
	    SET    mo_status         = 2,
	           mo_audit_man      = @mo_update_man,
	           mo_audit_time     = GETDATE()
	    WHERE  mo_id             = @mo_id;

		if @Isenablestocknum=1
		begin
		  exec dbo.pro_AvailableInventory @orderid=@mo_id,@type=2;
		end
	END
	
	IF @op_type = '取消审核单据'
	BEGIN
	    --取消审核单据
	    UPDATE j_orderblank
	    SET    mo_status     = 1
	    WHERE  mo_id         = @mo_id;
	END
	
	IF @op_type = '删除单据'
	BEGIN
		
		SELECT @old_sei_id=fd.mo_out_st_id
	     FROM j_orderblank fd WHERE fd.mo_id=@mo_id;
	      
	    --删除单据
	    UPDATE j_orderblank
	    SET    mo_status     = 0
	    WHERE  mo_id         = @mo_id;
	END
	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE j_orderblanklist
	    SET    mol_status     = 0
	    WHERE  mol_id         = @mol_id;
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   j_orderblanklist AS jt
	           WHERE  jt.mol_mo_id = @mol_mo_id
	                  AND jt.mol_status = 1
	       )
	    BEGIN
	        UPDATE j_orderblank
	        SET    mo_status     = 0
	        WHERE  mo_id         = @mol_mo_id;
	    END
	END
	
	IF @op_type = '批量删除明细'
	BEGIN
		
		SELECT @old_sei_id=fd.mo_out_st_id
	      FROM j_orderblank fd WHERE fd.mo_id=@mo_id;
	      
	    UPDATE j_orderblanklist
	    SET    mol_status           = 0
	    WHERE  mol_mo_id            = @mol_mo_id
	           AND mol_add_time     = @mol_add_time
	           AND mol_gi_id        = @mol_gi_id;
	    
	    
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   j_orderblanklist AS jt
	           WHERE  jt.mol_mo_id = @mol_mo_id
	                  AND jt.mol_status = 1
	       )
	    BEGIN
	        UPDATE j_orderblank
	        SET    mo_status     = 0
	        WHERE  mo_id         = @mol_mo_id;
	    END
	END
	
	IF @op_type = '添加修改单据,明细'
	   OR @need_update = 1
	   OR @op_type = '修改单据'
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.mo_date
	    FROM   j_orderblank AS jt
	    WHERE  jt.mo_id = @mo_id;
	    IF @old_order_date != @mo_date
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	    SELECT @old_sei_id=fd.mo_out_st_id
	      FROM j_orderblank fd WHERE fd.mo_id=@mo_id;
	    
	    UPDATE j_orderblank
	    SET    mo_out_st_id       = @mo_out_st_id,
	           mo_in_st_id        = @mo_in_st_id,
	           mo_num             = @mo_num,
	           mo_no              = @mo_no,
	           mo_date            = @mo_date,
	           mo_update_man      = @mo_update_man,
	           mo_update_time     = @mo_update_time,
	           mo_order_man       = @mo_order_man,
	           mo_remark          = @mo_remark
	    WHERE  mo_id              = @mo_id;
	END
	
	
	IF @isInsert = 1
	   --OR @old_order_date_is_changed = 1
	BEGIN
	    --凭证号生成
	    --更新凭证号 
	    DECLARE @tableName VARCHAR(50) = 'j_orderblank'
	    DECLARE @idField VARCHAR(50) = 'mo_id'
	    DECLARE @idValue INT = @mo_id;
	    
	    DECLARE @dateField VARCHAR(50) = 'mo_date'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @mo_date, 23)
	    
	    DECLARE @noField VARCHAR(50) = 'mo_vo'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN
	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	             @idField,
	             @idValue,
	             @dateField,
	             @dateValue,
	             @noField,
	             @prevTxt,
	             @outno OUTPUT,
	             0,
	             @mo_cp_id
	        
	        BEGIN TRY
	        	--更新
	        	UPDATE j_orderblank
	        	SET    mo_vo     = @outno
				,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)

	        	WHERE  mo_id     = @mo_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
			PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
	        END CATCH
	    END
	END
	

	IF @op_type = '审核单据' or  @op_type = '取消审核单据'
	BEGIN

	IF @mo_id>0
    BEGIN
    	UPDATE j_orderblank 
			       SET mo_num=(SELECT SUM(mol_num) FROM j_orderblankList WHERE mol_mo_id=@mo_id AND mol_status<>0)
    	WHERE mo_id=@mo_id
    END	
	

	EXEC pro_orderblanklistOccupySum @mo_id=@mo_id

	if @mo_out_st_id=0
	begin	    
		select @mo_out_st_id=mo_out_st_id,@mo_cp_id=mo_cp_id
		from j_orderblank where mo_id = @mo_id;
	end

	EXEC pro_mergeOccupy_check @cp_id=@mo_cp_id,@sei_id=@mo_out_st_id
	  IF @@ERROR <> 0
	  BEGIN
       GOTO theRollback;
	  END
	end


	IF @@ERROR <> 0
	BEGIN
	    theRollback:
	    SET @result = '0';
		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @mo_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细' 
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @mol_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END
END
go

