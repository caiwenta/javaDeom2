CREATE TRIGGER [dbo].[trg_b_goodsinfo_after_insert_update] ON dbo.b_goodsinfo
       AFTER INSERT,UPDATE
AS
BEGIN
      UPDATE    b_goodsinfo
      SET       gi_class_id = del.gi_class_id,gi_lastdate=GETDATE()
      FROM      b_goodsinfo gi ,
                (SELECT gi_id ,
                        gi_class_id
                 FROM   DELETED
                ) del
      WHERE     gi.gi_id = del.gi_id;
END
go

