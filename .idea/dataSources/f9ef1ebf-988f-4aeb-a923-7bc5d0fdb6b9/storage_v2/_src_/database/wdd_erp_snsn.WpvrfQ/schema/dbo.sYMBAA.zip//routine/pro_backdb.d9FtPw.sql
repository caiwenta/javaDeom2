
--EXEC pro_backdb @db_name = 'WddERP'
CREATE Proc [dbo].[pro_backdb]
@db_name varchar(50)
As
Declare @ml Varchar(100);
Set @ml='D:\Web\WddERP\Company\File\';

--mls
--Set @ml='F:\ERPServer\MLS\WddErp.Web\File\';


Declare @filename Varchar(50);
Set @filename=Convert(Varchar(50),Getdate());
Set @filename=Replace(Replace(@filename,' ',''),':','')+'--'+@db_name+'.bak';
Declare @path Varchar(200);
Set @path=@ml+@filename;
Backup Database @db_name To Disk =@path


go

