
CREATE function [dbo].[fn_getGoodsCode]()
returns varchar(100)
as
begin

declare @result varchar(100);
set @result='';
--商品编号
declare @rint int;
select @rint=rt from vi_get_rand_txt

declare @rand_txt varchar(100);
set @rand_txt='';
select @rand_txt=vr.rt from vi_rand as vr
declare @now_var varchar(100);
set @now_var=''
Select @now_var=replace(replace(replace(replace(CONVERT(varchar(100), GETDATE(), 120),'-','')
,' ',''),':',''),'.','')+replace(substring(convert(varchar(100),@rand_txt),0,6),'0.','')
select @result=char(@rint)+ @now_var+convert(varchar(10),@rint);
return @result;
end

go

