CREATE VIEW [dbo].[v_z_pos_allocationList]
	AS
select 
max(all_id) as all_id,
all_sku_id,
SUM(all_num) as all_num,
AVG(all_retail_price) as all_retail_price,
sum(all_retail_money) as all_retail_money,
MAX(all_discount) as all_discount,
avg(all_stock_price) as all_stock_price,
sum(all_money) as all_money,
max(all_add_time) as all_add_time,
all_status,
all_al_id,
all_gi_id  
from pos_allocationList  WHERE all_status=1
group by all_al_id,all_gi_id,all_sku_id,all_status
go

