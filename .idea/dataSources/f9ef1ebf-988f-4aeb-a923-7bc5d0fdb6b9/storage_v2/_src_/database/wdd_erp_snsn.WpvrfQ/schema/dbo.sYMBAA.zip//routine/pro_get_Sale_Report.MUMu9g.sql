

CREATE Proc [dbo].[pro_get_Sale_Report]
@id INT=0
AS

UPDATE pos_sale SET 
sa_times = ISNULL(sa_times,0)+1,
sa_print_time = GETDATE()
WHERE sa_id=@id;

DECLARE @yyname VARCHAR(50)='';
select @yyname+=(st_st_id+' ')  from dbo.pos_staffClassSet WITH (NOLOCK)  WHERE st_id IN
(select sal_list_man FROM [dbo].[pos_saleList] where sal_sa_id=@id);

SELECT fd.*,sg.gs_remark AS gs_remark1,sg2.gs_remark AS gs_remark2,
CASE WHEN sg.gs_remark IS NOT NULL  THEN
	CASE WHEN sg.gs_remark='颜色' then skuidclassname1 else
	skuidclassname2 END
ELSE '' END AS 颜色,
CASE WHEN sg2.gs_remark IS NOT NULL  THEN
	CASE WHEN sg2.gs_remark='尺码' then skuidclassname2 else
	skuidclassname1 END
ELSE '' END AS 尺码,nos_vs_url
 FROM (
SELECT *,
skuidclass1=CASE WHEN fd.skuid1!='' THEN dbo.Get_StrArrayStrOfIndex(fd.skuid1,'-',1) ELSE '' END,skuidclass2=CASE WHEN fd.skuid2!='' THEN dbo.Get_StrArrayStrOfIndex(fd.skuid2,'-',1) ELSE '' END 
,
skuidclassname1=CASE WHEN fd.skuid1!='' THEN dbo.Get_StrArrayStrOfIndex(fd.skuname1,':',2) ELSE '' END,skuidclassname2=CASE WHEN fd.skuid2!='' THEN dbo.Get_StrArrayStrOfIndex(fd.skuname2,':',2) ELSE '' END 
FROM (
select 
(select me_name from dbo.pos_memberInfo WITH (NOLOCK)  where me_id=le.sa_me_id)   vip名称,
op.sh_name 店名,
(op.phone+' '+op.fax) 收货人电话,
le.sa_vo 订单号,  
(select si_name from dbo.b_stafftinfo WITH (NOLOCK)   where si_id=le.sa_add_man) 经办人,  
(select st_st_id from dbo.pos_staffClassSet WITH (NOLOCK)  where st_id=le.sa_co_man) 营业员,
(select si_ids from dbo.b_stafftinfo WITH (NOLOCK)   where si_id=le.sa_add_man) 操作员账号,  
(op.province+op.city+op.county+op.[address])  收货人地址,
(select me_card from dbo.pos_memberInfo WITH (NOLOCK)  where me_id=le.sa_me_id)   vip编号,
(select gi_name from b_goodsinfo WITH (NOLOCK)  where gi_id=st.sal_gi_id) 商品标题,
st.sal_gi_id,
st.sal_num 数量, 
le.sa_in_money 积分, 
st.sal_discount 折扣,   
@yyname 多营业员,
(select top 1 il.gd_name from dbo.b_goodsruleset et WITH (NOLOCK)  inner join s_goodsruledetail il WITH (NOLOCK)  on    et.gs_name like '%'+il.gd_name+'%' and il.gs_id in  (select gs_id from dbo.s_goodsrule WITH (NOLOCK)   where gs_remark='尺码')   where  et.gss_id=st.sal_sku_id ) as  货号,
st.sal_sku_id,
(st.sal_real_price*st.sal_num)  购买时金额,
st.sal_real_price  单价,
( case when st.sal_is_gift=1 THEN 0 ELSE  st.sal_money end )as 订单金额,   
st.sal_is_gift,
 le.sa_real_money 实收,
 le.sa_card_money 刷卡金额,
 le.sa_cashmoney 现金,
 le.sa_bankmomey 银联支付,
 le.sa_weixinmoney 微信支付,
 le.sa_alipaymoney 支付宝,
 le.sa_paidmomey 总实收,
 le.sa_storedmoney 储值卡支付,
le.sa_surplus_money 找零, 
le.sa_salmanname 销售员,
((case when le.sa_money<>0 and le.sa_paytype<>'现金支付' then '现金支付,' else '' end)+le.sa_paytype) as  付款方式,
((case when le.sa_paytype<>'现金支付' then le.sa_paytype +':' else '' end)) as  三方支付,
le.sa_remark 备注, 0 vo_id,st.sal_status,
(SELECT bg.gi_code
FROM b_goodsinfo bg WITH (NOLOCK)  WHERE bg.gi_id=st.sal_gi_id) as '商品编号',
CASE WHEN st.sal_sku_id=0 THEN (SELECT bg.gi_barcode
FROM b_goodsinfo bg WITH (NOLOCK)  WHERE bg.gi_id=st.sal_gi_id)
ELSE (SELECT bg.gss_no FROM b_goodsruleset bg WITH (NOLOCK)  WHERE bg.gss_id=st.sal_sku_id)
END AS '款号',
CASE WHEN st.sal_sku_id=0 THEN ''
ELSE
CASE WHEN LEN(bg.gs_name)-len(replace(bg.gs_name,':',''))=2 THEN 
dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1)
ELSE 
bg.gs_id
END
END	
AS skuid1
,
CASE WHEN st.sal_sku_id=0 THEN ''
ELSE
CASE WHEN LEN(bg.gs_name)-len(replace(bg.gs_name,':',''))=2 THEN 
dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2)
ELSE 
''
END
END	
AS skuid2,
CASE WHEN st.sal_sku_id=0 THEN ''
ELSE
CASE WHEN LEN(bg.gs_name)-len(replace(bg.gs_name,':',''))=2 THEN 
dbo.Get_StrArrayStrOfIndex(bg.gs_name,'|',1)
ELSE 
bg.gs_name
END
END	
AS skuname1,
CASE WHEN st.sal_sku_id=0 THEN ''
ELSE
CASE WHEN LEN(bg.gs_name)-len(replace(bg.gs_name,':',''))=2 THEN 
dbo.Get_StrArrayStrOfIndex(bg.gs_name,'|',2)
ELSE 
''
END
END	
AS skuname2,
ns.nos_vs_url ,le.sa_times AS '次数',
le.sa_print_time  AS  '打印时间',
op.phone as '店铺电话',
st.sal_retail_price AS '零售价',
st.sal_deduct_money as '扣除金额',
(st.sal_retail_price-sal_real_price)+st.sal_deduct_money AS '优惠金额2',
st.sal_retail_price-sal_real_price AS '优惠金额'

from 
pos_sale le WITH (NOLOCK)   inner join pos_saleList st WITH (NOLOCK)  on  le.sa_id=st.sal_sa_id inner JOIN
dbo.pos_shop op WITH (NOLOCK)  on le.sa_sh_id=op.sh_id  
LEFT JOIN b_goodsruleset bg WITH (NOLOCK)  ON st.sal_sku_id=bg.gss_id
LEFT JOIN pos_sale_net ON le.sa_id=pos_sale_net.sa_net_sa_id
LEFT JOIN netorder_tbl nt ON pos_sale_net.sa_net_ord_id=nt.ord_id
LEFT JOIN netorder_shop_tbl ns ON ns.nos_id=nt.ord_nos_id
where  sa_id in(@id) and sal_status=1
) AS fd
) AS fd LEFT JOIN s_goodsrule sg WITH (NOLOCK)  ON fd.skuidclass1=sg.gs_id
LEFT JOIN s_goodsrule sg2 WITH (NOLOCK)  ON fd.skuidclass2=sg2.gs_id
go

