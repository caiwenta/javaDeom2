


CREATE VIEW [dbo].[vi_j_purchaseStorageList_group_goods_new] AS 
SELECT jt.pll_pl_id,
       jt.pll_gi_id,
       jt.pll_num,
       jt.pll_stock_price,
       jt.pll_retail_price,
       jt.pll_discount,
       jt.pll_money,
	   (select max(pll_id) FROM j_purchaseStorageList jpsl WHERE jpsl.pll_pl_id=jt.pll_pl_id AND jpsl.pll_gi_id= jt.pll_gi_id  and jpsl.pll_status=1 and isnull(jpsl.pll_pm,'')=isnull(jt.pll_pm,'')) as pll_id,--没有规格明细id
       (case when isnull(bg.gi_skuid,'')='' then 0 else 1 end) as pll_sku_id,
	   '' pll_pddate,
	   '' pll_pdgddate,
	   0  pll_integral,
	   0 pll_totalintegral,
	   pll_boxbynum,
	   pll_box_num,
	   (case when pl_source=1 then (SELECT pos.og_vo FROM pos_ogStorage pos WHERE pos.og_id=jt.pll_source_id) else '' end) as og_vo,
	    (case when pl_source=1 then (SELECT (case when pos.og_ci_id>0 then (SELECT bc.ci_name FROM b_clientinfo AS bc WHERE ci_id=pos.og_ci_id) else '' end) FROM pos_ogStorage pos WHERE pos.og_id=jt.pll_source_id) else '' end) as og_ci_id_txt,
		 (case when pl_source=1 then (SELECT (case when pos.og_ci_id>0 then (SELECT bc.ci_code FROM b_clientinfo AS bc WHERE ci_id=pos.og_ci_id) else '' end) FROM pos_ogStorage pos WHERE pos.og_id=jt.pll_source_id) else '' end) as og_ci_code_txt,
       pll_add_time,
       jt.pll_status,
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
	   bg.gi_cratebox,
       bg.gi_retailprice,
	   bg.gi_factoryprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
	   bg.gi_productiondate,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bg.gi_attribute_ids,
       bg.gi_attribute_parentids,
	   bg.gi_sampleno,--样品号
       bu.ut_name                  AS gi_unit,
	   bu.ut_id                  AS gi_unit_id,
       jt.pll_pm,
       pll_pause_num AS pll_pause_num1,
       abs(ISNULL(jt.pll_num_ed, 0))   AS pll_num_ed,
       jt.pll_num - abs(ISNULL(jt.pll_num_ed, 0)) -ISNULL( jt.pll_pause_num,0) AS pll_num_ding,
       jt.pll_num - (abs(ISNULL(jt.pll_num_ed, 0)))-ISNULL(jt.pll_pause_num,0) AS pll_num_do,
       jt.pll_num - (abs(ISNULL(jt.pll_num_ed, 0)))-ISNULL(jt.pll_pause_num,0) AS pll_num_end,
	   jt.pll_source_id,
	   (case when jp.pl_pltype=1 then  0 else pll_num_ed end)  AS rk_el_number,
	   (case when jp.pl_pltype=1 then pll_num_ed else 0 end)  AS rkth_el_number
FROM   j_purchasestoragelistmergesum AS jt
       left join j_purchasestorage as jp on jt.pll_pl_id=jp.pl_id and jp.pl_status>0
       LEFT JOIN dbo.b_goodsinfo  AS bg ON jt.pll_status<>0 and jt.pll_gi_id = bg.gi_id
       LEFT JOIN dbo.b_unit AS bu ON  bg.gi_unit = bu.ut_id
   --    LEFT OUTER JOIN (
   --             SELECT 
			--		  eo_source_id,
   --                   el_siid,
			--		  el_pm,
   --                   SUM(en_number)  AS el_number
   --             FROM   (
   --                        SELECT 
						           
   --                               jes.eo_source_id,
   --                               jesl.el_siid,
   --                               (
   --                                   CASE jes.eo_type
   --                                        WHEN 1 THEN - jesl.el_number
   --                                        WHEN 0 THEN jesl.el_number
   --                                        ELSE 0
   --                                   END
   --                               ) AS en_number,
			--					  jesl.el_pm
   --                        FROM   dbo.j_enterStorage AS jes
   --                               INNER JOIN dbo.j_enterStorageList AS jesl
   --                                    ON  jes.eo_id = jesl.el_eoid
   --                        WHERE  (jes.eo_status > 0)
   --                               AND (jesl.el_status = 1)
   --                               AND (jes.eo_source_type = 1)
   --                    )               AS aa
   --             GROUP BY
   --                    eo_source_id,
   --                    el_siid,
			--		   el_pm
   --         )          AS fd_1
   --         ON  
   --         jt.pll_gi_id = fd_1.el_siid
   --         AND jt.pll_pl_id=fd_1.eo_source_id
			--and jt.pll_pm=fd_1.el_pm
go

