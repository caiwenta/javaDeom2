CREATE PROCEDURE [dbo].[pro_gen_orderNo_New]


@tableName Varchar(50),--表名
@idField Varchar(50),--主键字段名
@idValue Int,--主键值
@dateField Varchar(50),--日期字段名
@dateValue Varchar(50),--日期值
@noField Varchar(50),--单据号字段名
@prevTxt Varchar(50),--前缀
@outno varchar(100) output,--输入单据号
@sh_id int=0,
@cp_id INT=0
As
begin
	if @tableName='pos_allocation'
	BEGIN
		select @dateValue=convert(varchar(50),pa.al_date,23) from pos_allocation as pa where pa.al_id=@idValue;
	END
	
	set @dateValue=replace(@dateValue,'/','-');
/*
* 时间:2014-7-19 15:22:11
* 编码:黄晓毅
* */
/*
* 如何确保单据号的唯一性?
* 1.表加拦截物理删除的触发器
* 2.单据号字段加唯一约束
* */
	Declare @sql Nvarchar(1000);
	Declare @count Int=0;
	Declare @countstr Varchar(50);
	
--set @sql='Select @count=isnull(max(dbo.Get_StrArrayStrOfIndex('+@noField+',''-'',3)),0) From '+@tableName+' Where dbo.Get_StrArrayStrOfIndex('+@noField+',''-'',1)='''+@prevTxt+'''  And Convert(Varchar(50),'+@dateField+',23)=Convert(Varchar(10),'''+@dateValue+''',23) And '+@idField+'!='+Convert(Varchar(50),@idValue)

set @sql='Select @count=isnull(max(dbo.Get_StrArrayStrOfIndex('+@noField+',''-'',3)),0) From '+@tableName+' Where pzone='''+@prevTxt+'''  And pztwo=REPLACE(Convert(Varchar(10),'''+@dateValue+''',23),''-'','''') And '+@idField+'!='+Convert(Varchar(50),@idValue)


if @sh_id>0
BEGIN

declare @sh_id_field varchar(50)='';
if @tableName='pos_alStorage'
BEGIN
	set @sh_id_field='al_sh_id';
end
if @tableName='pos_cost'
BEGIN
	set @sh_id_field='co_sh_id';
end
if @tableName='pos_funds'
BEGIN
	set @sh_id_field='fu_sh_id';
end
if @tableName='pos_initStorage'
BEGIN
	set @sh_id_field='in_sh_id';
end
if @tableName='pos_inStorage'
BEGIN
	set @sh_id_field='in_sh_id';
end
if @tableName='pos_moStorage'
BEGIN
	set @sh_id_field='mo_sh_id';
end
if @tableName='pos_plStorage'
BEGIN
	set @sh_id_field='pl_sh_id';
end
if @tableName='pos_reStorage'
BEGIN
	set @sh_id_field='re_sh_id';
end
if @tableName='pos_sale_temp'
BEGIN
	set @sh_id_field='sa_sh_id';
end
if @tableName='pos_takeStorage'
BEGIN
	set @sh_id_field='ts_sh_id';
end

if @tableName='pos_sale'
BEGIN
	set @sh_id_field='sa_sh_id';
END	
	set @sql=@sql +' and '+@sh_id_field+'='+convert(varchar(50),@sh_id);
	

	
END 
ELSE 
IF @cp_id>0 
BEGIN

declare @cp_id_field varchar(50)='';

if @tableName='j_enterStorage'
BEGIN
	set @cp_id_field='eo_cp_id';
END

if @tableName='j_outStorage'
BEGIN
	set @cp_id_field='oo_cp_id';
END

if @tableName='c_fundorder'
BEGIN
	set @cp_id_field='fo_cp_id';
END

if @tableName='j_initStorage'
BEGIN
	set @cp_id_field='in_cp_id';
END


if @tableName='j_moStorage'
BEGIN
	set @cp_id_field='mo_cp_id';
END


if @tableName='j_plStorage'
BEGIN
	set @cp_id_field='pl_cp_id';
END


if @tableName='j_purchaseStorage'
BEGIN
	set @cp_id_field='pl_cp_id';
END

if @tableName='pos_ogStorage'
BEGIN
	set @cp_id_field='og_cp_id';
END

if @tableName='pos_allocation'
BEGIN
	set @cp_id_field='al_cp_id';
END


if @tableName='j_takeStorage'
BEGIN
	set @cp_id_field='ts_cp_id';
END

set @sql=@sql +' and '+@cp_id_field+'='+convert(varchar(50),@cp_id);
         	
END
	EXECUTE sp_executesql @sql,N'@count int output',@count=@count Output
	
	If @count=0 Or @count=Null
	Begin
		Set @count=1;
	End
	Else
	Begin
		Set @count=@count+1;
	End
	Select @countstr=Convert(Varchar(50),@count);
	If Len(@countstr)=1
	Begin
		Set @countstr='000'+@countstr;
	End
	Else If Len(@countstr)=2
	Begin
		Set @countstr='00'+@countstr;
	End
	Else If Len(@countstr)=3
	Begin
		Set @countstr='0'+@countstr;
	End
	set @outno=@prevTxt+'-'+Replace(Replace(Convert(Varchar(10),@dateValue,23),'-',''),'/','')+'-'+@countstr
End
go

