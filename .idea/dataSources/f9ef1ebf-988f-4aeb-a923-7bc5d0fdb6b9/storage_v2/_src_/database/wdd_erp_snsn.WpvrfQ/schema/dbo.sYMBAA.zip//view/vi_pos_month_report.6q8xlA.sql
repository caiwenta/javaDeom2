CREATE VIEW [dbo].[vi_pos_month_report] AS 
SELECT
	rp.gid,
	rp.sid,
	rp.shid,
	rp.en_num,
	rp.en_money,
	(-rp.enth_num) AS enth_num,
	(-rp.enth_money) AS enth_money,
	(-rp.oo_num) as oo_num,
	rp.ooth_num,
	rp.ts_num,
	(rp.mo_num+	rp.mi_num) AS mo_num,
	rp.mi_num,
	(rp.ts_num+rp.yk_num) as yk_num,
	rp.price,
	rp.start_money,
	rp.start_num,
	(rp.start_money+rp.en_money +rp.enth_money +rp.oo_money +rp.ooth_money+(rp.mo_money+rp.mi_money+rp.ts_money+rp.yk_money) ) as end_money,
	(start_num+rp.en_num +rp.enth_num+rp.oo_num +rp.ooth_num +rp.mo_num+rp.mi_num  +rp.ts_num+rp.yk_num) AS end_num,
	
	rp.m_year,
	rp.m_month,
	b.gi_code,
	b.gi_name,
	b.gi_barcode,
	b.gi_attribute_ids,
	b.gi_attribute_parentids,
	b.gi_retailprice,
	b.gi_types,
    b.gi_typesid,
	s.sei_name,
	un.ut_name,
	sp.sh_name,
	sp.sh_company,

     -rp.oo_money AS oo_money,
	-rp.ooth_money AS ooth_money,
	rp.ts_num * rp.price AS ts_money,
	(rp.ts_money+rp.yk_money)  AS yk_money,
	(rp.mo_money+rp.mi_money)  AS mo_money,
	rp.mi_num * rp.price AS mi_money,
	rp.en_num +rp.enth_num AS enhj,
	(rp.en_money +rp.enth_money) AS enmoneyhj,
	( -rp.oo_num -rp.ooth_num) AS ooth_numhj,
	  ( -rp.oo_money +rp.ooth_money)  AS ooth_moneyhj,
	
	  (start_num*b.gi_retailprice) AS retail_start_money,
       (en_num*b.gi_retailprice) AS retail_en_money,
       ((en_num+rp.enth_num)*b.gi_retailprice) AS retail_enmoneyhj,
        (-rp.enth_num*b.gi_retailprice) as retail_enth_money,
	   (-rp.[oo_num]*b.gi_retailprice) AS retail_oo_money, 
	   (rp.[ooth_num]*b.gi_retailprice) AS retail_ooth_money,
	   ((rp.oo_num + rp.ooth_num)*b.gi_retailprice) AS retail_ooth_moneyhj,
	   ((rp.[yk_num]+ rp.[ts_num]) * b.gi_retailprice)     AS retail_yk_money,
	   ((rp.[mo_num]+rp.[mi_num]) *  b.gi_retailprice)     AS retail_mo_money,
       ((rp.[start_num]+rp.en_num + rp.enth_num+rp.oo_num + rp.ooth_num+ rp.[yk_num]+ rp.

[ts_num]+rp.[mo_num]+rp.[mi_num]  )  *  b.gi_retailprice)     AS retail_end_money,          
	CAST (rp.m_year AS VARCHAR(100)) + '-' + CAST (rp.m_month AS VARCHAR(100)) AS DATE,
	b.gi_skus,
	b.gi_costprice
FROM
	dbo.pos_month_report AS rp WITH (NOLOCK) 
INNER JOIN dbo.b_goodsinfo AS b  WITH (NOLOCK) ON b.gi_id = rp.gid
INNER JOIN dbo.pos_storageInfo AS s  WITH (NOLOCK) ON s.sei_id = rp.sid
INNER JOIN dbo.b_unit AS un  WITH (NOLOCK) ON un.ut_id = b.gi_unit
INNER JOIN dbo.pos_shop AS sp WITH (NOLOCK) ON sp.sh_id = rp.shid
where rp.reporttype=0
go

