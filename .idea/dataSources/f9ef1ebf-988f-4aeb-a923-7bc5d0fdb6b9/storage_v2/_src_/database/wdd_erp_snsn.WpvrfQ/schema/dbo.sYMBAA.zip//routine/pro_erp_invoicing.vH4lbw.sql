CREATE PROCEDURE [dbo].[pro_erp_invoicing]
	@erp_id int = 0,
	@order_date datetime
AS

delete erp_invoicing where ei_date=@order_date and ei_erp_id=@erp_id


insert into erp_invoicing(ei_erp_id,ei_objectid,ei_objecttype,ei_sei_id,ei_date,
                          ei_gi_id, ei_skuid,ei_retailprice,ei_costprice,
                          ei_firstnum,ei_firstcprice,
                          ei_initnum,ei_initmoney,ei_initcprice,
                          ei_initback,ei_initbackmoney,ei_initbackcprice,
                          ei_onlyinitnum,ei_onlyinitmoney,ei_onlyinitcprice,
                          ei_ci_outnum,ei_ci_outmoney,ei_ci_outcprice,
                          ei_cp_outnum,ei_cp_outmoney,ei_cp_outcprice,
                          ei_sh_sa_outnum,ei_sh_sa_outmoney,ei_sh_sa_outcprice,
                          ei_sh_dis_outnum,ei_sh_dis_outmoney, ei_sh_dis_outcprice, 
                          ei_ci_outback,ei_ci_outbackmoney,ei_ci_outbackcprice, 
                          ei_cp_outback,ei_cp_outbackmoney, ei_cp_outbackcprice,
                          ei_sh_sa_outback, ei_sh_sa_outbackmoney,ei_sh_sa_outbackcprice, 
                          ei_sh_dis_outback,ei_sh_dis_outbackmoney, ei_sh_dis_outbackcprice,
                          ei_ci_onlyoutnum, ei_ci_onlyoutmoney,ei_ci_onlyoutcprice, 
                          ei_sh_onlysale, ei_sh_onlysalemoney,ei_sh_onlysalecprice, 
                          ei_sh_sa_initnum,ei_sh_sa_initcprice, 
                          ei_sh_dis_initnum,ei_sh_dis_initcprice, 
                          ei_sh_sa_initback,ei_sh_sa_initbackcprice, 
                          ei_sh_dis_initback,ei_sh_dis_initbackcprice, 
                          ei_sh_sa_allotnum,ei_sh_sa_allotcprice, 
                          ei_sh_dis_allotnum,ei_sh_dis_allotcprice, 
                          ei_lossnum, ei_losscprice,
                          ei_shiftinnum, ei_shiftincprice, 
                          ei_shiftoutnum,ei_shiftoutcprice, 
                          ei_lastnum, ei_lastcprice)


SELECT @erp_id,ei_objectid,ei_objecttype,ei_sei_id,ei_date,
       ei_gi_id, isnull(ei_skuid,0)ei_skuid,ei_retailprice,ei_costprice,
        isnull(SUM(case when num_type='firstnum' then ei_firstnum else 0 end),0) as ei_firstnum,
        isnull(SUM(case when num_type='firstnum' then ei_firstcprice else 0 end),0) as ei_firstcprice,
        isnull(SUM(case when num_type='initnum' then ei_firstnum else 0 end),0) as ei_initnum,
        isnull(SUM(case when num_type='initnum' then ei_firstmoney else 0 end),0) as ei_initmoney,
        isnull(SUM(case when num_type='initnum' then ei_firstcprice else 0 end),0) as ei_initcprice,
        isnull(SUM(case when num_type='initback' then ei_firstnum else 0 end),0) as ei_initback,
        isnull(SUM(case when num_type='initback' then ei_firstmoney else 0 end),0) as ei_initbackmoney,
        isnull(SUM(case when num_type='initback' then ei_firstcprice else 0 end),0) as ei_initbackcprice,
        isnull((SUM(case when num_type='initnum' then ei_firstnum else 0 end)-
                SUM(case when num_type='initback' then ei_firstnum else 0 end)),0) as ei_onlyinitnum,
        isnull((SUM(case when num_type='initnum' then ei_firstmoney else 0 end)-
                SUM(case when num_type='initback' then ei_firstmoney else 0 end)),0) as ei_onlyinitmoney,
        isnull((SUM(case when num_type='initnum' then ei_firstcprice else 0 end)-
                SUM(case when num_type='initback' then ei_firstcprice else 0 end)),0) as ei_onlyinitcprice,
        isnull(SUM(case when num_type='ci_outnum' then ei_firstnum else 0 end),0) as ei_ci_outnum,
        isnull(SUM(case when num_type='ci_outnum' then ei_firstmoney else 0 end),0) as ei_ci_outmoney,
        isnull(SUM(case when num_type='ci_outnum' then ei_firstcprice else 0 end),0) as ei_ci_outcprice,
        isnull(SUM(case when num_type='cp_outnum' then ei_firstnum else 0 end),0) as ei_cp_outnum,
        isnull(SUM(case when num_type='cp_outnum' then ei_firstmoney else 0 end),0) as ei_cp_outmoney,
        isnull(SUM(case when num_type='cp_outnum' then ei_firstcprice else 0 end),0) as ei_cp_outcprice,
        isnull(SUM(case when num_type='sh_sa_outnum' then ei_firstnum else 0 end),0) as ei_sh_sa_outnum,
        isnull(SUM(case when num_type='sh_sa_outnum' then ei_firstmoney else 0 end),0) as ei_sh_sa_outmoney,
        isnull(SUM(case when num_type='sh_sa_outnum' then ei_firstcprice else 0 end),0) as ei_sh_sa_outcprice,
        isnull(SUM(case when num_type='sh_dis_outnum' then ei_firstnum else 0 end),0) as ei_sh_dis_outnum,
        isnull(SUM(case when num_type='sh_dis_outnum' then ei_firstmoney else 0 end),0) as ei_sh_dis_outmoney,
        isnull(SUM(case when num_type='sh_dis_outnum' then ei_firstcprice else 0 end),0) as ei_sh_dis_outcprice,
        isnull(SUM(case when num_type='ci_outback' then ei_firstnum else 0 end),0) as ei_ci_outback,
        isnull(SUM(case when num_type='ci_outback' then ei_firstmoney else 0 end),0) as ei_ci_outbackmoney,
        isnull(SUM(case when num_type='ci_outback' then ei_firstcprice else 0 end),0) as ei_ci_outbackcprice,
        isnull(SUM(case when num_type='cp_outback' then ei_firstnum else 0 end),0) as ei_cp_outback,
        isnull(SUM(case when num_type='cp_outback' then ei_firstmoney else 0 end),0) as ei_cp_outbackmoney,
        isnull(SUM(case when num_type='cp_outback' then ei_firstcprice else 0 end),0) as ei_cp_outbackcprice,
        isnull(SUM(case when num_type='sh_sa_outback' then ei_firstnum else 0 end),0) as ei_sh_sa_outback,
        isnull(SUM(case when num_type='sh_sa_outback' then ei_firstmoney else 0 end),0) as ei_sh_sa_outbackmoney,
        isnull(SUM(case when num_type='sh_sa_outback' then ei_firstcprice else 0 end),0) as ei_sh_sa_outbackcprice,
        isnull(SUM(case when num_type='sh_dis_outback' then ei_firstnum else 0 end),0) as ei_sh_dis_outback,
        isnull(SUM(case when num_type='sh_dis_outback' then ei_firstmoney else 0 end),0) as ei_sh_dis_outbackmoney,
        isnull(SUM(case when num_type='sh_dis_outback' then ei_firstcprice else 0 end),0) as ei_sh_dis_outbackcprice,
        isnull((SUM(case when num_type='ci_outnum' then ei_firstnum else 0 end)-SUM(case when num_type='ci_outback' then ei_firstnum else 0 end)),0) as ei_ci_onlyoutnum,
        isnull((SUM(case when num_type='ci_outnum' then ei_firstmoney else 0 end)-
                SUM(case when num_type='ci_outback' then ei_firstmoney else 0 end)),0) as ei_ci_onlyoutmoney,
        isnull((SUM(case when num_type='ci_outnum' then ei_firstcprice else 0 end)-
                SUM(case when num_type='ci_outback' then ei_firstcprice else 0 end)),0) as ei_ci_onlyoutcprice,
        isnull(SUM(case when num_type='sh_onlysale' then ei_firstnum else 0 end),0) as ei_sh_onlysale,
        isnull(SUM(case when num_type='sh_onlysale' then ei_firstmoney else 0 end),0) as ei_sh_onlysalemoney,
        isnull(SUM(case when num_type='sh_onlysale' then ei_firstcprice else 0 end),0) as ei_sh_onlysalecprice,
        isnull(SUM(case when num_type='sh_sa_initnum' then ei_firstnum else 0 end),0) as ei_sh_sa_initnum,
        isnull(SUM(case when num_type='sh_sa_initnum' then ei_firstcprice else 0 end),0) as ei_sh_sa_initcprice,
        isnull(SUM(case when num_type='sh_dis_initnum' then ei_firstnum else 0 end),0) as ei_sh_dis_initnum,
        isnull(SUM(case when num_type='sh_dis_initnum' then ei_firstcprice else 0 end),0) as ei_sh_dis_initcprice,
        isnull(SUM(case when num_type='sh_sa_initback' then ei_firstnum else 0 end),0) as ei_sh_sa_initback,
        isnull(SUM(case when num_type='sh_sa_initback' then ei_firstcprice else 0 end),0) as ei_sh_sa_initbackcprice,
        isnull(SUM(case when num_type='sh_dis_initback' then ei_firstnum else 0 end),0) as ei_sh_dis_initback,
        isnull(SUM(case when num_type='sh_dis_initback' then ei_firstcprice else 0 end),0) as ei_sh_dis_initbackcprice,
        isnull(SUM(case when num_type='sh_sa_allotnum' then ei_firstnum else 0 end),0) as ei_sh_sa_allotnum,
        isnull(SUM(case when num_type='sh_sa_allotnum' then ei_firstcprice else 0 end),0) as ei_sh_sa_allotcprice,
        isnull(SUM(case when num_type='sh_dis_allotnum' then ei_firstnum else 0 end),0) as ei_sh_dis_allotnum,
        isnull(SUM(case when num_type='sh_dis_allotnum' then ei_firstcprice else 0 end),0) as ei_sh_dis_allotcprice,
        isnull(SUM(case when num_type='lossnum' then ei_firstnum else 0 end),0) as ei_lossnum,
        isnull(SUM(case when num_type='lossnum' then ei_firstcprice else 0 end),0) as ei_losscprice,
        isnull(SUM(case when num_type='shiftinnum' then ei_firstnum else 0 end),0) as ei_shiftinnum,
        isnull(SUM(case when num_type='shiftinnum' then ei_firstcprice else 0 end),0) as ei_shiftincprice,
        isnull(SUM(case when num_type='shiftoutnum' then ei_firstnum else 0 end),0) as ei_shiftoutnum,
        isnull(SUM(case when num_type='shiftoutnum' then ei_firstcprice else 0 end),0) as ei_shiftoutcprice,
        isnull(SUM(case when num_type='lastnum' then ei_firstnum else 0 end),0) as ei_lastnum,
        isnull(SUM(case when num_type='lastnum' then ei_firstcprice else 0 end),0) as ei_lastcprice
FROM(
------ERP
-------期初数量firstnum：当天的前一天的日期库存【商品库存】
select sl_cp_id ei_objectid,
       2 ei_objecttype,
       sl_seiid ei_sei_id,
       CONVERT(varchar(100),@order_date, 23) ei_date,
       sl_giid ei_gi_id,
       sl_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=sl_giid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=sl_giid) ei_costprice,
	   SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END) ei_firstnum,
	   0 ei_firstmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=sl_giid)*SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END)) ei_firstcprice,
	   'firstnum' num_type  
from j_stocklog WITH (NOLOCK)
INNER JOIN b_goodsinfo AS bg WITH (NOLOCK) ON sl_giid = bg.gi_id --避免库存出现不存在的商品
WHERE sl_status <> 0
and sl_cp_id>0 
and sl_seiid>0 
and sl_giid>0
and (CONVERT(varchar(100), sl_order_date, 23) <= CONVERT(varchar(100), dateadd(day,-1,@order_date), 23)
     OR (sl_type = 3 and CONVERT(varchar(100), sl_order_date, 23) <= CONVERT(varchar(100), @order_date, 23)))   --没有进销存库存时，取期初，and后面的条件用于控制到有期初的日期为止
AND (select sei_erp_id from b_storageinfo where sei_id=sl_seiid)=@erp_id 
GROUP BY sl_cp_id,
         sl_seiid,
         sl_giid,
         sl_skuid
HAVING SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END)<>0
         
union all

-------入库数量initnum：本公司仓库商品入库数量【商品入库】入库
select eo_cp_id ei_objectid,
       2 ei_objecttype,
       eo_siid ei_sei_id,
       CONVERT(varchar(100),eo_entrydate, 23) ei_date,
       el_siid ei_gi_id,
       el_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=el_siid)  ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=el_siid) ei_costprice,
	   el_number ei_initnum,
	   el_realmoney ei_initmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=el_siid)*el_number) ei_initcprice,
	   'initnum' num_type
from j_enterStorage WITH (NOLOCK)  
left join 
j_enterStorageList WITH (NOLOCK) 
on eo_id=el_eoid 
where eo_type=0 and eo_status=2 AND el_status>0
and eo_cp_id>0 
and eo_siid>0 
and el_siid>0
and el_number!=0
and (CONVERT(varchar(100), eo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and eo_erp_id=@erp_id

union all

-------入库退货initback：本公司仓库入库退货数量【入库退货】退货
select eo_cp_id ei_objectid,
       2 ei_objecttype,
       eo_siid ei_sei_id,
       CONVERT(varchar(100),eo_entrydate, 23) ei_date,
       el_siid ei_gi_id,
       el_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=el_siid)  ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=el_siid) ei_costprice,
	   el_number ei_initback,
	   el_realmoney ei_initbackmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=el_siid)*el_number) ei_initbackcprice,
	   'initback' num_type
from j_enterStorage  WITH (NOLOCK) 
left join 
j_enterStorageList  WITH (NOLOCK) 
on eo_id=el_eoid 
where eo_type=1 and eo_status=2 and el_status>0
and eo_cp_id>0 
and eo_siid>0 
and el_siid>0
and el_number!=0
and (CONVERT(varchar(100), eo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and eo_erp_id=@erp_id

union all

-------客户出库数量ci_outnum：【商品出库】
select oo_cp_id ei_objectid,
       2 ei_objecttype,
       oo_siid ei_sei_id,
       CONVERT(varchar(100),oo_entrydate, 23) ei_date,
       ol_siid ei_gi_id,
       ol_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ol_siid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid) ei_costprice,
	   ol_number ei_ci_outnum,
	   ol_realmoney ei_ci_outmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid)*ol_number) ei_ci_outcprice,
	   'ci_outnum' num_type
from j_outStorage WITH (NOLOCK) 
left join 
j_outStorageList  WITH (NOLOCK)
on oo_id=ol_eoid
where oo_type=1 and oo_status=2 and ol_status>0
and oo_ciid>0 
and oo_siid>0 
and ol_siid>0
and ol_number!=0
and (CONVERT(varchar(100), oo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and oo_erp_id=@erp_id

union all

-------分公司出库数量cp_outnum：【商品出库】
select oo_cp_id ei_objectid,
       2 ei_objecttype,
       oo_siid ei_sei_id,
       CONVERT(varchar(100),oo_entrydate, 23) ei_date,
       ol_siid ei_gi_id,
       ol_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ol_siid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid) ei_costprice,
	   ol_number ei_cp_outnum,
	   ol_realmoney ei_cp_outmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid)*ol_number) ei_cp_outcprice,
	   'cp_outnum' num_type
from j_outStorage WITH (NOLOCK) 
left join 
j_outStorageList  WITH (NOLOCK) 
on oo_id=ol_eoid
where oo_type=1 and oo_status=2 and ol_status>0
and oo_to_cp_id>0 
and oo_siid>0 
and ol_siid>0
and ol_number!=0
and (CONVERT(varchar(100), oo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and oo_erp_id=@erp_id

union all

-------店铺出库数量（同一体系）sh_sa_outnum：【商品出库】
select oo_cp_id ei_objectid,
       2 ei_objecttype,
       oo_siid ei_sei_id,
       CONVERT(varchar(100),oo_entrydate, 23) ei_date,
       ol_siid ei_gi_id,
       ol_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ol_siid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid) ei_costprice,
	   ol_number ei_sh_sa_outnum,
	   ol_realmoney ei_sh_sa_outmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid)*ol_number) ei_sh_sa_outcprice,
	   'sh_sa_outnum' num_type
from j_outStorage WITH (NOLOCK) 
left join 
j_outStorageList  WITH (NOLOCK) 
on oo_id=ol_eoid
where oo_type=1 and oo_status=2 and ol_status>0
and (select sh_client from pos_shop where sh_id=oo_sh_id)=oo_cp_id
and oo_sh_id>0 
and oo_siid>0 
and ol_siid>0
and ol_number!=0
and (CONVERT(varchar(100), oo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and oo_erp_id=@erp_id

union all

-------店铺出库数量（不同体系）sh_dis_outnum：【商品出库】
select oo_cp_id ei_objectid,
       2 ei_objecttype,
       oo_siid ei_sei_id,
       CONVERT(varchar(100),oo_entrydate, 23) ei_date,
       ol_siid ei_gi_id,
       ol_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ol_siid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid) ei_costprice,
	   ol_number ei_sh_dis_outnum,
	   ol_realmoney ei_sh_dis_outmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid)*ol_number) ei_sh_dis_outcprice,
	   'sh_dis_outnum' num_type
from j_outStorage WITH (NOLOCK) 
left join 
j_outStorageList  WITH (NOLOCK) 
on oo_id=ol_eoid
where oo_type=1 and oo_status=2 and ol_status>0
and (select sh_client from pos_shop where sh_id=oo_sh_id)<>oo_cp_id
and oo_sh_id>0 
and oo_siid>0 
and ol_siid>0
and ol_number!=0
and (CONVERT(varchar(100), oo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and oo_erp_id=@erp_id

union all

-------客户出库退货ci_outback：【出库退货】
select oo_cp_id ei_objectid,
       2 ei_objecttype,
       oo_siid ei_sei_id,
       CONVERT(varchar(100),oo_entrydate, 23) ei_date,
       ol_siid ei_gi_id,
       ol_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ol_siid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid)  ei_costprice,
	   ol_number ei_ci_outback,
	   ol_realmoney ei_ci_outbackmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid) *ol_number) ei_ci_outbackcprice,
	   'ci_outback' num_type
from j_outStorage WITH (NOLOCK) 
left join 
j_outStorageList  WITH (NOLOCK) 
on oo_id=ol_eoid
where oo_type=0 and oo_status=2 and ol_status>0
and oo_ciid>0 
and oo_siid>0 
and ol_siid>0
and ol_number!=0
and (CONVERT(varchar(100), oo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and oo_erp_id=@erp_id

union all

-------分公司出库退货cp_outback：【出库退货】
select oo_cp_id ei_objectid,
       2 ei_objecttype,
       oo_siid ei_sei_id,
       CONVERT(varchar(100),oo_entrydate, 23) ei_date,
       ol_siid ei_gi_id,
       ol_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ol_siid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid) ei_costprice,
	   ol_number ei_cp_outback,
	   ol_realmoney ei_cp_outbackmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid)*ol_number) ei_cp_outbackcprice,
	   'cp_outback' num_type
from j_outStorage WITH (NOLOCK) 
left join 
j_outStorageList  WITH (NOLOCK) 
on oo_id=ol_eoid
where oo_type=0 and oo_status=2 and ol_status>0
and oo_to_cp_id>0 
and oo_siid>0 
and ol_siid>0
and ol_number!=0
and (CONVERT(varchar(100), oo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and oo_erp_id=@erp_id

union all

-------店铺出库退货（同一体系）sh_sa_outback：【出库退货】
select oo_cp_id ei_objectid,
       2 ei_objecttype,
       oo_siid ei_sei_id,
       CONVERT(varchar(100),oo_entrydate, 23) ei_date,
       ol_siid ei_gi_id,
       ol_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ol_siid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid) ei_costprice,
	   ol_number ei_sh_sa_outback,
	   ol_realmoney ei_sh_sa_outbackmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid)*ol_number) ei_sh_sa_outbackcprice,
	   'sh_sa_outback' num_type
from j_outStorage WITH (NOLOCK) 
left join 
j_outStorageList  WITH (NOLOCK) 
on oo_id=ol_eoid
where oo_type=0 and oo_status=2 and ol_status>0
and (select sh_client from pos_shop where sh_id=oo_sh_id)=oo_cp_id
and oo_sh_id>0 
and oo_siid>0 
and ol_siid>0
and ol_number!=0
and (CONVERT(varchar(100), oo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and oo_erp_id=@erp_id

union all

-------店铺出库退货（不同体系）sh_dis_outback：【出库退货】
select oo_cp_id ei_objectid,
       2 ei_objecttype,
       oo_siid ei_sei_id,
       CONVERT(varchar(100),oo_entrydate, 23) ei_date,
       ol_siid ei_gi_id,
       ol_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ol_siid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid) ei_costprice,
	   ol_number ei_sh_dis_outback,
	   ol_realmoney ei_sh_dis_outbackmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ol_siid)*ol_number) ei_sh_dis_outbackcprice,
	   'sh_dis_outback' num_type
from j_outStorage WITH (NOLOCK) 
left join 
j_outStorageList  WITH (NOLOCK) 
on oo_id=ol_eoid
where oo_type=0 and oo_status=2 and ol_status>0
and (select sh_client from pos_shop where sh_id=oo_sh_id)<>oo_cp_id
and oo_sh_id>0 
and oo_siid>0 
and ol_siid>0
and ol_number!=0
and (CONVERT(varchar(100), oo_entrydate, 23)= CONVERT(varchar(100), @order_date, 23))
and oo_erp_id=@erp_id

union all

--盈亏数量lossnum：本公司仓库盈亏数【盈亏查询】
select pl_cp_id ei_objectid,
       2 ei_objecttype,
       pl_st_id ei_sei_id,
       CONVERT(varchar(100),pl_date, 23) ei_date, 
       ppl_gi_id ei_gi_id,
       ppl_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ppl_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ppl_gi_id) ei_costprice,
	   ppl_num ei_lossnum,
	   0 ei_lossmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ppl_gi_id)*ppl_num) ei_losscprice,
	   'lossnum' num_type
from vi_j_plStorage_Search_new  WITH (NOLOCK) 
where pl_status=2 
and pl_cp_id>0 
and pl_st_id>0 
and gi_id>0
and ppl_num!=0
and (CONVERT(varchar(100), pl_date, 23)= CONVERT(varchar(100), @order_date, 23))
and pl_cp_id IN (select cp_id from companyinfo where cp_erp_id=@erp_id)

union all

--移仓（移入）shiftinnum：已收货的部分【区域移仓（移入）】
select mo_cp_id ei_objectid,
       2 ei_objecttype,
       mo_to_st_id ei_sei_id,
       CONVERT(varchar(100),mo_date, 23) ei_date, 
       mol_gi_id ei_gi_id,
       mol_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=mol_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=mol_gi_id) ei_costprice,
	   mol_num ei_shiftinnum,
	   0 ei_shiftinmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=mol_gi_id)*mol_num) ei_shiftincprice,
	   'shiftinnum' num_type 
from v_z_moStorage_detail
where mo_source_id >0 and mo_status=2
and mo_cp_id>0 
and mo_to_st_id>0 
and mol_gi_id>0
and mol_num!=0
and (CONVERT(varchar(100), mo_date, 23)= CONVERT(varchar(100), @order_date, 23))
and erp_id=@erp_id

union all

--移仓（移出）shiftoutnum：已收货的部分【区域移仓（移出）】
select mo_cp_id ei_objectid,
       2 ei_objecttype,
       mo_out_st_id ei_sei_id,
       CONVERT(varchar(100),mo_date, 23) ei_date,
       mol_gi_id ei_gi_id,
       mol_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=mol_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=mol_gi_id) ei_costprice,
	   mol_num ei_shiftoutnum,
	   0 ei_shiftoutmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=mol_gi_id)*mol_num) ei_shiftoutcprice,
	   'shiftoutnum' num_type 
from v_z_moStorage_detail
WHERE mo_status=2
and mo_cp_id>0 
and mo_to_st_id>0 
and mol_gi_id>0
and mol_num!=0
and (CONVERT(varchar(100), mo_date, 23)= CONVERT(varchar(100), @order_date, 23))
and erp_id=@erp_id

union all

-------期末数量lastnum：当天的日期库存【商品库存】
select sl_cp_id ei_objectid,
       2 ei_objecttype,
       sl_seiid ei_sei_id,
       CONVERT(varchar(100),@order_date, 23) ei_date,
       sl_giid ei_gi_id,
       sl_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=sl_giid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=sl_giid) ei_costprice,
	   SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END) ei_lastnum,
	   0 ei_lastmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=sl_giid)*SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END)) ei_lastcprice,
	   'lastnum' num_type  
from j_stocklog WITH (NOLOCK)
INNER JOIN b_goodsinfo AS bg WITH (NOLOCK) ON sl_giid = bg.gi_id --避免库存出现不存在的商品
WHERE sl_status <> 0
and sl_cp_id>0 
and sl_seiid>0 
and sl_giid>0
and (CONVERT(varchar(100), sl_order_date, 23) <= CONVERT(varchar(100), @order_date, 23)
     OR (sl_type = 3 and CONVERT(varchar(100), sl_order_date, 23) <= CONVERT(varchar(100), @order_date, 23)))   --没有进销存库存时，取期初，and后面的条件用于控制到有期初的日期为止  
AND (select sei_erp_id from b_storageinfo where sei_id=sl_seiid)=@erp_id 
GROUP BY sl_cp_id,
         sl_seiid,
         sl_giid,
         sl_skuid
HAVING SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END)<>0
        
union all

------POS
-------期初数量firstnum：当天的前一天的日期库存【商品库存】
select sl_shop_id ei_objectid,
       1 ei_objecttype,
       sl_seiid ei_sei_id,
       CONVERT(varchar(100),@order_date, 23) ei_date,
       sl_giid ei_gi_id,
       sl_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=sl_giid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=sl_giid) ei_costprice,
	   SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END) ei_firstnum,
	   0 ei_firstmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=sl_giid)*SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END)) ei_firstcprice,
	   'firstnum' num_type  
from pos_stocklog WITH (NOLOCK)
INNER JOIN b_goodsinfo AS bg WITH (NOLOCK) ON sl_giid = bg.gi_id --避免库存出现不存在的商品
WHERE sl_status <> 0
and sl_shop_id>0 
and sl_seiid>0 
and sl_giid>0
and (CONVERT(varchar(100), sl_order_date, 23) <= CONVERT(varchar(100), dateadd(day,-1,@order_date), 23)
     OR (sl_type = 11 and CONVERT(varchar(100), sl_order_date, 23) <= CONVERT(varchar(100), @order_date, 23)))   --没有进销存库存时，取期初，and后面的条件用于控制到有期初的日期为止
AND (select sei_erp_id from pos_storageinfo where sei_id=sl_seiid)=@erp_id 
GROUP BY sl_shop_id,
         sl_seiid,
         sl_giid,
         sl_skuid
HAVING SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END)<>0

union all

--店铺净销售sh_onlysale：直接求合计【销售查询】
select sa_sh_id ei_objectid,
       1 ei_objecttype,
       sa_st_id ei_sei_id,
       CONVERT(varchar(100),sa_date, 23) ei_date,
       sal_gi_id ei_gi_id,
       sal_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=sal_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=sal_gi_id) ei_costprice,
	   sal_num ei_sh_onlysalenum,
	   sal_paidmomey ei_sh_onlysalemoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=sal_gi_id)*sal_num) ei_sh_onlysalecprice,
	   'sh_onlysale' num_type 
FROM pos_sale AS ps 
LEFT JOIN pos_saleList AS psl
ON ps.sa_id=psl.sal_sa_id
WHERE sa_status > 0 and sal_status>0
and sa_sh_id>0 
and sa_st_id>0 
and sal_gi_id>0
and sal_num!=0
and (CONVERT(varchar(100), sa_date, 23)= CONVERT(varchar(100), @order_date, 23))
and sa_erp_id=@erp_id

union all

--店铺入库（同一体系）sh_sa_initnum【入库】
select in_sh_id ei_objectid,
       1 ei_objecttype,
       in_st_id ei_sei_id,
       CONVERT(varchar(100),in_date, 23) ei_date,
       inl_gi_id ei_gi_id,
       inl_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=inl_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=inl_gi_id) ei_costprice,
	   inl_num ei_sh_sa_initnum,
	   0 ei_sh_sa_initmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=inl_gi_id)*inl_num) ei_sh_sa_initcprice,
	   'sh_sa_initnum' num_type  
from pos_inStorage WITH (NOLOCK)  
left join pos_inStorageList WITH (NOLOCK)  
on in_id=inl_in_id 
where in_status!=0 and in_type=0 and inl_status>0  
AND (CASE WHEN in_source=0 or in_source=1 THEN (SELECT si_companyid from pos_supplierinfo WHERE si_id=in_supplier_sh_id)
          WHEN in_source=2 THEN (select sh_client from pos_shop where sh_id=in_supplier_sh_id) END)=(select sh_client from pos_shop where sh_id=in_sh_id)
and in_sh_id>0 
and in_st_id>0 
and inl_gi_id>0
and inl_num!=0
and (CONVERT(varchar(100), in_date, 23)= CONVERT(varchar(100), @order_date, 23))
and in_erp_id=@erp_id

union all

--店铺入库（不同体系）sh_dis_initnum【入库】
select in_sh_id ei_objectid,
       1 ei_objecttype,
       in_st_id ei_sei_id,
       CONVERT(varchar(100),in_date, 23) ei_date,
       inl_gi_id ei_gi_id,
       inl_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=inl_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=inl_gi_id) ei_costprice,
	   inl_num ei_sh_dis_initnum,
	   0 ei_sh_dis_initmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=inl_gi_id)*inl_num) ei_sh_dis_initcprice,
	   'sh_dis_initnum' num_type  
from pos_inStorage WITH (NOLOCK)  
left join pos_inStorageList WITH (NOLOCK)  
on in_id=inl_in_id 
where in_status!=0 and in_type=0 and inl_status>0  
AND (CASE WHEN in_source=0 or in_source=1 THEN (SELECT si_companyid from pos_supplierinfo WHERE si_id=in_supplier_sh_id)
          WHEN in_source=2 THEN (select sh_client from pos_shop where sh_id=in_supplier_sh_id) END)<>(select sh_client from pos_shop where sh_id=in_sh_id)
and in_sh_id>0 
and in_st_id>0 
and inl_gi_id>0
and inl_num!=0
and (CONVERT(varchar(100), in_date, 23)= CONVERT(varchar(100), @order_date, 23))
and in_erp_id=@erp_id

union all

--店铺入库退货（同一体系）sh_sa_initback【入库退货】
select in_sh_id ei_objectid,
       1 ei_objecttype,
       in_st_id ei_sei_id,
       CONVERT(varchar(100),in_date, 23) ei_date,
       inl_gi_id ei_gi_id,
       inl_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=inl_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=inl_gi_id) ei_costprice,
	   inl_num ei_sh_sa_initback,
	   0 ei_sh_sa_initbackmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=inl_gi_id)*inl_num) ei_sh_sa_initbackcprice,
	   'sh_sa_initback' num_type  
from pos_inStorage WITH (NOLOCK)  
left join pos_inStorageList WITH (NOLOCK)  
on in_id=inl_in_id 
where in_status!=0 and in_type=1 and inl_status>0  
AND (CASE WHEN in_source=0 or in_source=1 THEN (SELECT si_companyid from pos_supplierinfo WHERE si_id=in_supplier_sh_id)
          WHEN in_source=2 THEN (select sh_client from pos_shop where sh_id=in_supplier_sh_id) END)=(select sh_client from pos_shop where sh_id=in_sh_id)
and in_sh_id>0 
and in_st_id>0 
and inl_gi_id>0
and inl_num!=0
and (CONVERT(varchar(100), in_date, 23)= CONVERT(varchar(100), @order_date, 23))
and in_erp_id=@erp_id

union all

--店铺入库退货（不同体系）sh_dis_initback【入库退货】
select in_sh_id ei_objectid,
       1 ei_objecttype,
       in_st_id ei_sei_id,
       CONVERT(varchar(100),in_date, 23) ei_date,
       inl_gi_id ei_gi_id,
       inl_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=inl_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=inl_gi_id) ei_costprice,
	   inl_num ei_sh_dis_initback,
	   0 ei_sh_dis_initbackmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=inl_gi_id)*inl_num) ei_sh_dis_initbackcprice,
	   'sh_dis_initback' num_type  
from pos_inStorage WITH (NOLOCK)  
left join pos_inStorageList WITH (NOLOCK)  
on in_id=inl_in_id 
where in_status!=0 and in_type=1 and inl_status>0  
AND (CASE WHEN in_source=0 or in_source=1 THEN (SELECT si_companyid from pos_supplierinfo WHERE si_id=in_supplier_sh_id)
          WHEN in_source=2 THEN (select sh_client from pos_shop where sh_id=in_supplier_sh_id) END)<>(select sh_client from pos_shop where sh_id=in_sh_id)
and in_sh_id>0 
and in_st_id>0 
and inl_gi_id>0
and inl_num!=0
and (CONVERT(varchar(100), in_date, 23)= CONVERT(varchar(100), @order_date, 23))
and in_erp_id=@erp_id

union all

--店铺调拨（同一体系）sh_sa_allotnum【调拨】
select al_sh_id ei_objectid,
       1 ei_objecttype,
       al_st_id ei_sei_id,
       CONVERT(varchar(100),al_date, 23) ei_date,
       all_gi_id ei_gi_id,
       all_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=all_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=all_gi_id) ei_costprice,
	   all_num ei_sh_sa_allotnum,
	   0 ei_sh_sa_allotmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=all_gi_id)*all_num) ei_sh_sa_allotcprice,
	   'sh_sa_allotnum' num_type  
from Pos_AlStorage WITH (NOLOCK)
left join 
Pos_AlStorageList WITH (NOLOCK)
on al_id=all_al_id 
where al_status!=0 and al_status !=3 and all_status>0  
AND (select sh_client from pos_shop where sh_id=al_get_sh_id)=(select sh_client from pos_shop where sh_id=al_sh_id)
and al_sh_id>0 
and al_st_id>0 
and all_gi_id>0
and all_num!=0
and (CONVERT(varchar(100), al_date, 23)= CONVERT(varchar(100), @order_date, 23))
and al_erp_id=@erp_id

union all

--店铺调拨（不同体系）sh_dis_allotnum【调拨】
select al_sh_id ei_objectid,
       1 ei_objecttype,
       al_st_id ei_sei_id,
       CONVERT(varchar(100),al_date, 23) ei_date,
       all_gi_id ei_gi_id,
       all_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=all_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=all_gi_id) ei_costprice,
	   all_num ei_sh_dis_allotnum,
	   0 ei_sh_dis_allotmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=all_gi_id)*all_num) ei_sh_dis_allotcprice,
	   'sh_dis_allotnum' num_type  
from Pos_AlStorage WITH (NOLOCK)
left join 
Pos_AlStorageList WITH (NOLOCK)
on al_id=all_al_id 
where al_status!=0 and al_status !=3 and all_status>0   
AND (select sh_client from pos_shop where sh_id=al_get_sh_id)<>(select sh_client from pos_shop where sh_id=al_sh_id)
and al_sh_id>0 
and al_st_id>0 
and all_gi_id>0
and all_num!=0
and (CONVERT(varchar(100), al_date, 23)= CONVERT(varchar(100), @order_date, 23))
and al_erp_id=@erp_id

union all

--盈亏数量lossnum【盈亏查询】
select pl_sh_id ei_objectid,
       1 ei_objecttype,
       pl_st_id ei_sei_id,
       CONVERT(varchar(100),pl_date, 23) ei_date, 
       ppl_gi_id ei_gi_id,
       ppl_sku_id ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=ppl_gi_id) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=ppl_gi_id) ei_costprice,
	   ppl_num ei_lossnum,
	   0 ei_lossmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=ppl_gi_id)*ppl_num) ei_losscprice,
	   'lossnum' num_type
from vi_j_Pos_plStorage_Search  WITH (NOLOCK) 
where pl_status=2 
and pl_sh_id>0 
and pl_st_id>0 
and gi_id>0
and ppl_num!=0
and (CONVERT(varchar(100), pl_date, 23)= CONVERT(varchar(100), @order_date, 23))
and erp_id=@erp_id
        
union all

-------期末数量lastnum：当天的日期库存【商品库存】
select sl_shop_id ei_objectid,
       1 ei_objecttype,
       sl_seiid ei_sei_id,
       CONVERT(varchar(100),@order_date, 23) ei_date,
       sl_giid ei_gi_id,
       sl_skuid ei_skuid,
	   (select gi_retailprice from b_goodsinfo WHERE gi_id=sl_giid) ei_retailprice,
	   (select gi_costprice from b_goodsinfo WHERE gi_id=sl_giid) ei_costprice,
	   SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END) ei_lastnum,
	   0 ei_lastmoney,
	   ((select gi_costprice from b_goodsinfo WHERE gi_id=sl_giid)*SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END)) ei_lastcprice,
	   'lastnum' num_type  
from pos_stocklog WITH (NOLOCK)
INNER JOIN b_goodsinfo AS bg WITH (NOLOCK) ON sl_giid = bg.gi_id --避免库存出现不存在的商品
WHERE sl_status <> 0
and sl_shop_id>0 
and sl_seiid>0 
and sl_giid>0
and (CONVERT(varchar(100), sl_order_date, 23) <= CONVERT(varchar(100), @order_date, 23)
     OR (sl_type = 11 and CONVERT(varchar(100), sl_order_date, 23) <= CONVERT(varchar(100), @order_date, 23)))   --没有进销存库存时，取期初，and后面的条件用于控制到有期初的日期为止
AND (select sei_erp_id from pos_storageinfo where sei_id=sl_seiid)=@erp_id 
GROUP BY sl_shop_id,
         sl_seiid,
         sl_giid,
         sl_skuid
HAVING SUM(CASE WHEN sl_counttype = 1 THEN sl_number
                ELSE -sl_number END)<>0

)Invoicing
GROUP BY ei_objectid,ei_objecttype,ei_sei_id,ei_date,
         ei_gi_id, ei_skuid,ei_retailprice,ei_costprice
go

