

CREATE Proc [dbo].[pro_td_do]
@list_id VARCHAR(50)='',
@op_type VARCHAR(50)='',
@table VARCHAR(50)='入库'
as

 DECLARE @order_id INT=0;
 DECLARE @gi_id INT=0;
 DECLARE @sku_id INT=0;
 DECLARE @add_time DATETIME;
 DECLARE @color_id INT=0;
 DECLARE @column_id INT=0;



IF @op_type='规格数据'
BEGIN
 
IF @table='出库'
BEGIN
 
 
SELECT @order_id=jesl.ol_eoid,@sku_id=jesl.ol_skuid,@gi_id=jesl.ol_siid,@add_time=jesl.ol_addtime
  FROM j_outStorageList jesl WHERE jesl.ol_id=@list_id



SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id

SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id


SELECT bg.gs_is_custom,fd.ol_number,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
SELECT * FROM j_outStorageList 
WHERE ol_eoid=@order_id
AND ol_siid=@gi_id AND ol_addtime=@add_time
AND ol_skuid IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.ol_skuid=bg.gss_id
 


END



ELSE IF @table='pos库存'
BEGIN

 

SELECT TOP 1 @sku_id=fd.skuid,@gi_id=fd.gid
  FROM vi_pos_stockSumList_copy fd WITH (NOLOCK)   
WHERE CONVERT(VARCHAR(50),vertical_column_id)+'|'+CONVERT(VARCHAR(50),gi_id)+'|'+CONVERT(VARCHAR(50),sid)=@list_id

 

  
SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id





SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id



SELECT bg.gs_is_custom,fd.gnum,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
  
  SELECT *
  FROM vi_pos_stockSumList_copy fd WITH (NOLOCK)   
WHERE CONVERT(VARCHAR(50),vertical_column_id)+'|'+CONVERT(VARCHAR(50),gi_id)+'|'+CONVERT(VARCHAR(50),sid)=@list_id
AND fd.skuid IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.skuid=bg.gss_id


END

ELSE IF @table='总部库存'
BEGIN

 

SELECT TOP 1 @sku_id=fd.skuid,@gi_id=fd.gid
  FROM vi_stockSumList_copy fd WITH (NOLOCK)   
WHERE CONVERT(VARCHAR(50),vertical_column_id)+'|'+CONVERT(VARCHAR(50),gi_id)+'|'+CONVERT(VARCHAR(50),sid)=@list_id

 

  
SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id





SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id



SELECT bg.gs_is_custom,fd.gnum,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
  
  SELECT *
  FROM vi_stockSumList_copy fd WITH (NOLOCK)   
WHERE CONVERT(VARCHAR(50),vertical_column_id)+'|'+CONVERT(VARCHAR(50),gi_id)+'|'+CONVERT(VARCHAR(50),sid)=@list_id
AND fd.skuid IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.skuid=bg.gss_id


END

ELSE IF @table='终端入库'
BEGIN

SELECT @order_id=jesl.inl_in_id,@sku_id=jesl.inl_sku_id,@gi_id=jesl.inl_gi_id,@add_time=jesl.inl_add_time
  FROM pos_inStorageList jesl WHERE jesl.inl_id=@list_id
SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id

SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id

SELECT bg.gs_is_custom,fd.inl_num,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
SELECT * FROM pos_inStorageList 
WHERE inl_in_id=@order_id
AND inl_gi_id=@gi_id AND inl_add_time=@add_time
AND inl_sku_id IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.inl_sku_id=bg.gss_id
end
ELSE IF @table='调拨'
BEGIN
SELECT 
@order_id=jesl.all_al_id,@sku_id=jesl.all_sku_id,@gi_id=jesl.all_gi_id,@add_time=jesl.all_add_time
  FROM pos_alStorageList jesl WHERE jesl.all_id=@list_id
  
SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) 

ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex

(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) 

ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex

(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id

SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id


SELECT bg.gs_is_custom,fd.all_num,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) 

ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex

(bg.gs_id,'/',1),'-',2)
 END  FROM (
SELECT * FROM pos_alStorageList 
WHERE all_al_id=@order_id
AND all_gi_id=@gi_id AND all_add_time=@add_time
AND all_sku_id IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex

(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) 

END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.all_sku_id=bg.gss_id

end
ELSE IF @table='盘点'
BEGIN

SELECT @order_id=jesl.tsl_ts_id,@sku_id=jesl.tsl_sku_id,@gi_id=jesl.tsl_gi_id,@add_time=jesl.tsl_add_time
  FROM j_takeStorageList jesl WHERE jesl.tsl_id=@list_id

SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id

SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id


SELECT bg.gs_is_custom,fd.tsl_new_num,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
SELECT * FROM j_takeStorageList 
WHERE tsl_ts_id=@order_id
AND tsl_gi_id=@gi_id AND tsl_add_time=@add_time
AND tsl_sku_id IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.tsl_sku_id=bg.gss_id

end
ELSE IF @table='终端盘点'
BEGIN

SELECT @order_id=jesl.tsl_ts_id,@sku_id=jesl.tsl_sku_id,@gi_id=jesl.tsl_gi_id,@add_time=jesl.tsl_add_time
  FROM pos_takeStorageList jesl WHERE jesl.tsl_id=@list_id
  
SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id

SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id


SELECT bg.gs_is_custom,fd.tsl_new_num,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN 

dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
SELECT * FROM pos_takeStorageList 
WHERE tsl_ts_id=@order_id
AND tsl_gi_id=@gi_id AND tsl_add_time=@add_time
AND tsl_sku_id IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex

(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.tsl_sku_id=bg.gss_id

end
ELSE IF @table='采购'
BEGIN

SELECT @order_id=jesl.pll_pl_id,@sku_id=jesl.pll_sku_id,@gi_id=jesl.pll_gi_id,@add_time=jesl.pll_add_time
  FROM j_purchaseStorageList jesl WHERE jesl.pll_id=@list_id
  
SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id

SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id


SELECT bg.gs_is_custom,fd.pll_num,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
SELECT * FROM j_purchaseStorageList 
WHERE pll_pl_id=@order_id
AND pll_gi_id=@gi_id AND pll_add_time=@add_time
AND pll_sku_id IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.pll_sku_id=bg.gss_id

end
ELSE IF @table='入库'
BEGIN

SELECT @order_id=jesl.el_eoid,@sku_id=jesl.el_skuid,@gi_id=jesl.el_siid,@add_time=jesl.el_addtime
  FROM j_enterStorageList jesl WHERE jesl.el_id=@list_id
  
SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id

SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id


SELECT bg.gs_is_custom,fd.el_number,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
SELECT * FROM j_enterStorageList 
WHERE el_eoid=@order_id
AND el_siid=@gi_id AND el_addtime=@add_time
AND el_skuid IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.el_skuid=bg.gss_id
 
END
ELSE IF @table='移仓'
BEGIN
SELECT @order_id=jesl.mol_mo_id,@sku_id=jesl.mol_sku_id,@gi_id=jesl.mol_gi_id,@add_time=jesl.mol_add_time
  FROM j_moStorageList jesl WHERE jesl.mol_id=@list_id
SELECT 
@color_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END
,
@column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END FROM b_goodsruleset bg WHERE bg.gss_id=@sku_id

SELECT sg.gd_id,sg.gd_name FROM s_goodsruledetail sg WHERE sg.gs_id=(
SELECT top 1 sg.gs_id FROM s_goodsruledetail sg WHERE sg.gd_id=@column_id
) ORDER BY sg.dg_sort,sg.gd_id
SELECT bg.gs_is_custom,fd.mol_num,column_id=CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2)
 END  FROM (
SELECT * FROM j_moStorageList 
WHERE mol_mo_id=@order_id
AND mol_gi_id=@gi_id AND mol_add_time=@add_time
AND mol_sku_id IN(
SELECT bg.gss_id FROM b_goodsruleset bg WHERE bg.gi_id=@gi_id
AND CASE WHEN CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1))!=bg.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',2) END=@color_id
)
) AS fd LEFT JOIN b_goodsruleset bg ON fd.mol_sku_id=bg.gss_id
END
END
IF @op_type='最多规格数量'
BEGIN
SELECT top 1 sg.gs_id,count(1) as count FROM s_goodsrule sg WITH (NOLOCK)  INNER JOIN s_goodsruledetail sg2  WITH (NOLOCK) 
ON sg.gs_id=sg2.gs_id
AND sg.gs_status>0
AND sg.gs_remark!='颜色'
GROUP BY sg.gs_id
ORDER BY count(1) desc
END
go

