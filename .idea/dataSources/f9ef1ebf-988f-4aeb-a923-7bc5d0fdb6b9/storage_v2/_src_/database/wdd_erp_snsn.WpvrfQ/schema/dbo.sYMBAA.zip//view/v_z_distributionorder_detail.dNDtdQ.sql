CREATE VIEW [dbo].[v_z_distributionorder_detail] 
	AS 
SELECT

(CASE WHEN isnull(gss_no,'')<>'' THEN gss_no ELSE gi_barcode END) AS barcode, 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
purchaselist.*
from 
(
select 
isnull(grl.gss_no,'') as gss_no,--规格编码
isnull(grl.colorname,'无') as color,
(case when grl.colorid is not null then (select gd_code from s_goodsruledetail where gd_id=grl.colorid) else '' end)colorcode,
isnull(grl.specname,'无') as spec,
(case when grl.specid is not null then (select gd_code from s_goodsruledetail where gd_id=grl.specid) else '' end)speccode,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
purchase.*

from
(
	
SELECT 
edi.warehousingtype as stocktype,



gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
ui.ut_name,--单位
edi.do_vo,

--0:入库　1:出库　3:盘点 4：移动移仓 5:POS出库
(
case edi.warehousingtype
when 0 then (SELECT  top 1 pl_pltype FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
when 1 then 0
when 3 then (
case (SELECT  top 1 al_source FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
		when 4 then 0
		when 6 then 0
		else 1 
		end)
WHEN 5 THEN 0
when 8 then 0
when 27 then (
CASE (SELECT top 1 pa.mo_type FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id) WHEN 0 then 1 WHEN 1 THEN 4 ELSE 0 end
)
when 36 then 5
else
	edi.warehousingtype
end
) as warehousingtype,


(
   case edi.warehousingtype
   when 27 then (SELECT top 1 pa.mo_locationid FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id)
   else 0 end
) as locationid,




(case edi.warehousingtype 
when 0 then
			(case (SELECT  top 1 pl_pltype FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
			      when 0 then  '入库单'  else  '供应商退货'  end
			)
when 1 then '分公司退货'
when 3 then(case (SELECT  top 1 al_source FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
		    when 3 then '店铺退货单' 
		    when 4 then '客户退货单'
		    when 6 then '分公司退货'
            else '出库单' end
)
WHEN 5 THEN '移仓入库单'
when 8 then '店铺退货单'
when 27 THEN  CASE (SELECT top 1 pa.mo_type FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id) WHEN 0 then '移仓出库单' WHEN 1 THEN  '移仓单' ELSE '移仓出库单' end  
WHEN 36 THEN '网络订单'
else '盘点'
end
) as typename,






(
case edi.warehousingtype 
when 0 then (SELECT top 1 pl_vo FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
when 1 then (SELECT top 1 jps.eo_no FROM j_enterStorage jps WHERE jps.eo_id=edi.do_source_id)
when 3 then (SELECT top 1 al_vo FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
WHEN 5 then (SELECT top 1 mo_vo FROM j_moStorage AS jms  WHERE jms.mo_source_type=1 AND jms.mo_id=edi.do_source_id )
when 8 then (SELECT top 1 pa.in_vo FROM pos_inStorage pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT top 1 pa.mo_vo FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id )
when 36 then (SELECT top 1 pa.ord_no FROM netorder_tbl pa WHERE pa.ord_id=edi.do_source_id )--网络订单
end
) as do_no,


(
case edi.warehousingtype 
when 0 then (SELECT top 1 pl_date FROM j_purchaseStorage jps WHERE jps.pl_id=edi.do_source_id)
when 1 then (SELECT top 1 jps.eo_entrydate FROM j_enterStorage jps WHERE jps.eo_id=edi.do_source_id)
when 3 then (SELECT top 1 al_date FROM pos_allocation pa WHERE pa.al_id=edi.do_source_id )
WHEN 5 then (SELECT top 1 mo_date FROM j_moStorage AS jms  WHERE jms.mo_source_type=1 AND jms.mo_id=edi.do_source_id )
when 8 then (SELECT top 1 pa.in_date FROM pos_inStorage pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT top 1 pa.mo_date FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id )
when 36 then (SELECT top 1 pa.ord_paydate FROM netorder_tbl pa WHERE pa.ord_id=edi.do_source_id )--网络订单
end
)  AS do_date,


(case when edi.sh_id >0 then psi.sei_name else bsi.sei_name end)sei_name,
(case when edi.sh_id >0 then psi.sei_code else bsi.sei_code end)sei_code,


--对象名称（单位）
(case edi.warehousingtype 
when 0 then (SELECT top 1 pl_ci_id_txt FROM v_z_purchaseStorage_detail jps WHERE jps.pl_id=edi.do_source_id)
when 1 THEN (SELECT top 1 (SELECT cp_name FROM companyinfo c WHERE c.cp_id=jps.eo_cp_id) FROM v_z_enterStorage jps WHERE jps.eo_id=edi.do_source_id)
when 3 then (SELECT top 1 subname FROM v_z_allocation_detail pa WHERE pa.al_id=edi.do_source_id)
WHEN 5 then (SELECT top 1 mo_out_st_id_txt FROM v_z_moStorage_detail AS jms  WHERE  jms.mo_id=edi.do_source_id )
when 8 then (SELECT top 1 pa.sh_name FROM v_z_pos_inStorage_detail pa WHERE pa.in_id=edi.do_source_id )
when 27 then (SELECT sei_name FROM b_storageinfo WHERE sei_id=(SELECT top 1 pa.mo_in_st_id FROM j_orderblank pa WHERE pa.mo_id=edi.do_source_id))
when 36 then (SELECT top 1 pa.ord_b_linkman FROM netorder_tbl pa WHERE pa.ord_id=edi.do_source_id )--网络订单
end
) as subname,

(SELECT SUM(dpk.dp_inspectionnum) from erp_distributionpicking as dpk WHERE dpk.dol_id=lst.dol_id ) AS inspectionnum,
ISNULL((SELECT top 1 di_status FROM erp_distributionpdaing WHERE do_id=edi.do_id AND si_id=lst.si_id),0) AS finishstatus,

'' as slt_no,
edi.sei_id,
edi.do_source_id,
edi.do_status,
edi.do_addtime,
edi.cp_id,
(SELECT si_name FROM b_stafftinfo bs WHERE bs.si_id=do_man) as do_man,
(SELECT si_name FROM b_stafftinfo bs WHERE bs.si_id=lst.si_id) as pda_man,

lst.*
FROM erp_distributionorder AS edi  
INNER JOIN erp_distributionorderlist AS lst ON edi.do_id=lst.do_id AND edi.do_status<>0 AND lst.dol_status<>0
inner join b_goodsinfo gi on gi.gi_id=lst.dol_gi_id and gi_status=1
inner join b_unit ui on ui.ut_id=gi.gi_unit 
left join b_storageinfo as bsi on bsi.sei_id=edi.sei_id 
left join pos_storageInfo as psi on psi.sei_id=edi.sei_id 

) as  purchase
left join b_goodsruleset as grl on  grl.gss_id=purchase.dol_sku_id

) as purchaselist
left join s_goodsruledetail rulenum on gd_id=purchaselist.size
go

