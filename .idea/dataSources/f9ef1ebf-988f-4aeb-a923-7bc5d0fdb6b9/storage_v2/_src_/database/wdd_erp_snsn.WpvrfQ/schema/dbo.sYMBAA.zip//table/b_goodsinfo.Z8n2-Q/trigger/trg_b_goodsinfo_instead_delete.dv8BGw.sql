CREATE TRIGGER [dbo].[trg_b_goodsinfo_instead_delete] ON dbo.b_goodsinfo
       INSTEAD OF DELETE
AS
BEGIN
      DECLARE @gi_id INT= 0;
      
      DECLARE sopcor CURSOR
      FOR
      (SELECT   gi_id
       FROM     DELETED
      )
      OPEN sopcor
      FETCH NEXT FROM sopcor INTO @gi_id
      WHILE @@FETCH_STATUS = 0
            BEGIN
                  INSERT    INTO log_c
                            (li_content)
                            EXEC pro_check_delete
                                @op_type = '商品' ,
                                @id = @gi_id
                  DECLARE @content VARCHAR(50)= '';
                  SELECT    @content = lc.li_content
                  FROM      log_c lc
                  WHERE     lc.li_id = SCOPE_IDENTITY();
                  
                  IF (@content) = '1'
                     BEGIN
                           INSERT   INTO log_c
                                    (li_content,li_time)
                           VALUES   ('删除商品',GETDATE())
                           PRINT '删除商品'
							--可以删除
                           DELETE   FROM b_goodsinfo
                           WHERE    gi_id = @gi_id
                     END
                  ELSE
                     BEGIN
                           INSERT   INTO log_c
                                    (li_content,li_time)
                           VALUES   ('删除商品失败',GETDATE())
                           PRINT @content
                     END

                  FETCH NEXT FROM sopcor INTO @gi_id
            END
      CLOSE sopcor
      DEALLOCATE sopcor
END
go

