CREATE PROCEDURE [dbo].[pro_pz_moStorageList_sku_search_tb]
@mol_mo_id INT = 0,
@mol_add_time DATETIME = '2004-10-17',
@gi_id INT,
@cp_id INT = 0 ,
@mol_pm varchar(50)=''
AS

DECLARE @lsj DECIMAL(9, 2) = 0;

select (TT.mol_num-abs(isnull(var_num,0))) as optnum,TT.* INTO #p 
from (
SELECT bg.*,
       p1.*,
       ( SELECT SUM(var_num) FROM erp_inspectionofgoods WHERE orderid=mol_mo_id AND warehousingtype=5 and iog_status=1 and gi_id=p1.mol_gi_id AND sku_id=p1.mol_sku_id ) as var_num,
       bg2.gi_name,
       bg2.gi_code 
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT *
                FROM   v_z_moStorageList AS jisl
                WHERE  jisl.mol_mo_id = @mol_mo_id
					   AND jisl.mol_pm=@mol_pm
                       AND jisl.mol_gi_id = @gi_id
            ) AS p1
            ON  bg.gi_id = p1.mol_gi_id
            AND bg.gss_id = p1.mol_sku_id
       LEFT JOIN b_goodsinfo bg2
            ON  bg.gi_id = bg2.gi_id
WHERE  bg.gi_id = @gi_id
) as TT







--分公司时设置零售价为吊牌价
IF @cp_id != 0
BEGIN

if EXISTS(SELECT c.cp_goods_type FROM  companyinfo c WHERE  c.cp_id = @cp_id and cp_goods_type!=0)
		BEGIN
    SELECT @lsj = gd_price
    FROM   b_goods_discount
    WHERE  gd_gi_id = @gi_id
           AND gd_type IN (SELECT c.cp_goods_type
                           FROM   companyinfo c
                           WHERE  c.cp_id = @cp_id)
           AND gd_class = 1
    
    UPDATE #p
    SET    gs_marketprice = @lsj
    
    UPDATE #p
    SET    gs_purchase = gs_marketprice * gs_discount
    
    END
END

SELECT * FROM  #p
go

