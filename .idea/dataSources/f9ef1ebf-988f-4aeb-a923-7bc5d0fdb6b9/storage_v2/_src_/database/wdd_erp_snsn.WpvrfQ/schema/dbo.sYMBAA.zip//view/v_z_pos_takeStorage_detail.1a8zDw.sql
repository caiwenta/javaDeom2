CREATE VIEW [dbo].[v_z_pos_takeStorage_detail] AS 
select 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
rulenum.gd_code as sizecode,--尺码代号
plSlist.*
from 
(
	
select
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=isnull(grl.colorid,0))as colorcode,--颜色代号
isnull(grl.gss_no,'') as gss_no,--规格编码,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
plS.*
	
FROM
(
	 
SELECT 
ts_vo,--凭证号
ts_no,--单据号
ts_erp_id,
tsl_ts_id,
tsl_pm,
(select max(tsl_type) from pos_takeStorageLog where tsl_st_id=ts_st_id and tsl_date=ts_take_date)tsl_type,


ts_take_date,--盘点日期
gi.gi_id,
gi.gi_skuid,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
ui.ut_name as gi_unit,  --单位      
tsl_stock_price,--进货价

isnull(tsl_old_num,0) as tsl_old_num,--日期库存
isnull(tsl_new_num,0) as tsl_new_num,--实盘数量
isnull(tsl_log_num,0) as tsl_log_num,--盈亏数量
isnull(tsl_old_money,0) as tsl_old_money,--日期金额
isnull(tsl_new_money,0) as tsl_new_money,--实盘金额
isnull(tsl_log_money,0) as tsl_log_money,--盈亏金额

tsl_add_time,--商品添加时间
sg.sei_name as ts_st_id_txt,--仓库
ts_order_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = ts_order_man) ),--经手人
ts_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = ts_add_man) ),--添加人
ts_add_time,--添加时间
ts_update_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = ts_update_man) ),--修改人            
ts_update_time, --修改时间
ts_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = ts_audit_man) ), --审核人
ts_audit_time,--审核时间
ts_remark, --备注
ts_status,  --状态
            --
ps.sh_company,
ps.sh_erp_id as erp_id,
pts.ts_id,
pts.ts_st_id,
pts.ts_sh_id,
ptsl.tsl_gi_id,
ptsl.tsl_sku_id,
ps.sh_id,
ps.sh_name ts_sh_id_txt

FROM pos_takeStorage as pts
INNER JOIN pos_takeStorageList as ptsl on pts.[ts_id] =ptsl.tsl_ts_id AND ptsl.tsl_status=1 AND pts.ts_status<>0
inner join b_goodsinfo gi on gi.gi_id=ptsl.tsl_gi_id and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 
inner join pos_storageInfo sg on sg.sei_id=pts.ts_st_id
inner join pos_shop ps on ps.sh_id=pts.ts_sh_id
) AS pls
left join b_goodsruleset  as grl on  grl.gss_id=pls.tsl_sku_id
) as plSlist
left join s_goodsruledetail rulenum on gd_id=plSlist.size
go

