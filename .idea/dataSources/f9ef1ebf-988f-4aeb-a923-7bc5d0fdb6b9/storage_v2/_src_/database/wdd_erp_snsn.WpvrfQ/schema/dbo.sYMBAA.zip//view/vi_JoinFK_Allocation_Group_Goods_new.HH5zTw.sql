

CREATE VIEW [dbo].[vi_JoinFK_Allocation_Group_Goods_new] AS 
SELECT al.all_al_id,
       al.all_gi_id,
       al.all_num,
       ((select max(all_id) FROM pos_allocationList jpsl WHERE all_al_id=al.all_al_id AND jpsl.all_gi_id= al.all_gi_id and jpsl.all_status=1 and isnull(jpsl.all_pm,'')=isnull(al.all_pm,'')) ) as all_id,
       al.all_money,
       al.all_retail_price,
       al.all_stock_price,
       al.all_discount,
       (case when isnull(bg.gi_skuid,'')='' then 0 else 1 end) as all_sku_id,
       al.all_gift,
       al.all_status,
       all_boxbynum,
       all_box_num,
       all_pm,
	   fd.al_no,
       ISNULL(al.all_num_ed, 0)        AS all_num_ed,
       (al.all_num -ISNULL(al.all_num_ed, 0))-ISNULL(al.all_pause_num,0) AS all_num_ding,
       (al.all_num -ISNULL(al.all_num_ed, 0))-ISNULL(al.all_pause_num,0) AS all_num_do,
       (al.all_num -ISNULL(al.all_num_ed, 0))-ISNULL(al.all_pause_num,0) AS all_num_end,
       ISNULL(al.all_pause_num,0) AS all_pause_num1,
       CONVERT(VARCHAR(100), al.all_add_time, 25)  AS all_add_time ,
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
	   bg.gi_cratebox,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
       bg.gi_retailprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bg.gi_attribute_ids,
       bg.gi_attribute_parentids,
	   bg.gi_sampleno,--样品号
       bu.ut_id                       AS gi_unit,
	   bu.ut_id                     AS gi_unit_id,
       bu.ut_name                      AS gi_unit_name,
       supplyprice,
	   discount,
	   (case when supplyprice=0 then 0 else CONVERT(decimal(9,2), (all_stock_price/supplyprice)) end ) as realitydiscount
    
       
FROM   pos_allocationListMergeSum AS al
INNER JOIN pos_allocation fd ON fd.al_id=al.all_al_id AND al.all_status>0 
LEFT JOIN dbo.b_goodsinfo  AS bg ON  al.all_gi_id = bg.gi_id and bg.gi_status>0
LEFT JOIN dbo.b_unit AS bu ON  bg.gi_unit = bu.ut_id
   --    LEFT JOIN (
   --    			--查询已出库数量
   --             SELECT 
			--	       ol_pm,
   --                    ol_siid,
   --                    ol_source_add_time,
   --                    SUM(ol_number) AS ol_number
   --             FROM   vi_allocation_outed
   --             GROUP BY ol_siid,ol_source_add_time,ol_pm
   --         ) fd
   --         ON  fd.ol_siid = al.all_gi_id
   --         and al.all_add_time = fd.ol_source_add_time
			--and fd.ol_pm=al.all_pm
go

