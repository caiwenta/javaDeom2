CREATE VIEW [dbo].[vi_stockSumList_copy_union] AS 
SELECT ss.si_giid as gid, 
       ss.si_skuid as skuid,
       ss.si_seiid as sid,
       ss.si_number as gnum,
       (
           CASE 
                WHEN (ss.si_number - ISNULL(val.all_num, 0)) < 0 THEN 0
                ELSE (ss.si_number - ISNULL(val.all_num, 0))
           END
       )                             AS all_num,
       isnull(ss.si_occupy_num,0)        AS take_up_num,
       enable_stock_num=ss.si_number-(isnull(ss.si_occupy_num,0)),
      ss.si_cp_id as cp_id,
       bs.sei_id,
       bs.sei_name, 
       bs.sei_is_tb,--是否同步
       bg2.gs_id,
       bg2.gs_name,
       bg2.gss_no,
       bg2.gs_is_custom,
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_entrydate,
       bg.gi_unit,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
       bg.gi_retailprice,
        (bg.gi_retailprice*si_number)AS gi_retailprice_money,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bg.gi_add_man,
       bg.gi_add_time,
       bg.gi_update_man,
       bg.gi_update_time,
       bg.gi_cp_id,
       bg.gi_di_id,
       bg.gi_attribute_ids,
       bg.gi_is_tb,
       bg.gi_attribute_parentids,
       bg.gi_purchase_discount,
       bu.ut_name
       --垂直列,颜色列
                  ,
                  vertical_column_id = CASE 
                                            WHEN ISNULL(
                                                     dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 1),
                                                     0
                                                 ) = 0 THEN --没规格
                                                 0
                                            ELSE CASE 
                                                      WHEN bg2.gs_is_custom > 0 THEN CASE 
                                                                                         WHEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 1)
                                                                                              )
                                                                                              = 
                                                                                              bg2.gs_is_custom THEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 2), '-', 2)
                                                                                              )
                                                                                         ELSE 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 2)
                                                                                              )
                                                                                    END
                                                      ELSE CONVERT(
                                                               INT,
                                                               dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 2)
                                                           )
                                                 END
                                       END,
                  vertical_column_name = CASE 
                                              WHEN ISNULL(
                                                       dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 1),
                                                       0
                                                   ) = 0 THEN --没规格
                                                   ''
                                              ELSE CASE 
                                                        WHEN bg2.gs_is_custom > 0 THEN CASE 
                                                                                           WHEN 
                                                                                                CONVERT(
                                                                                                    INT,
                                                                                                    dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 1)
                                                                                                )
                                                                                                = 
                                                                                                bg2.gs_is_custom THEN 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_name, '|', 2), ':', 2)
                                                                                           ELSE 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_name, '|', 1), ':', 2)
                                                                                      END
                                                        ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_name, '|', 1), ':', 2)
                                                   END
                                         END
FROM   b_stockinfo              AS ss WITH (NOLOCK)
       INNER JOIN dbo.b_storageinfo  AS bs WITH (NOLOCK)
            ON  ss.si_seiid = bs.sei_id

       INNER JOIN dbo.b_goodsinfo    AS bg WITH (NOLOCK)
            ON  ss.si_giid = bg.gi_id
       LEFT OUTER JOIN dbo.b_goodsruleset AS bg2 WITH (NOLOCK)
            ON  ss.si_skuid = bg2.gss_id
       LEFT JOIN dbo.b_unit         AS bu WITH (NOLOCK)
            ON  bg.gi_unit = bu.ut_id
       LEFT OUTER JOIN (
                SELECT ogl_gi_id,
                       al_st_id,
                       ogl_sku_id,
                       al_cp_id,
                       SUM(all_num) AS all_num
                FROM   dbo.vi_stockList_Allocation WITH (NOLOCK)
                WHERE  (al_cp_id > 0)
                GROUP BY
                       ogl_gi_id,
                       ogl_gi_id,
                       al_st_id,
                       ogl_sku_id,
                       al_cp_id
            )                        AS val
            ON  ss.si_giid = val.ogl_gi_id
            AND ss.si_seiid = val.al_st_id
            AND ss.si_skuid = val.ogl_sku_id
go

