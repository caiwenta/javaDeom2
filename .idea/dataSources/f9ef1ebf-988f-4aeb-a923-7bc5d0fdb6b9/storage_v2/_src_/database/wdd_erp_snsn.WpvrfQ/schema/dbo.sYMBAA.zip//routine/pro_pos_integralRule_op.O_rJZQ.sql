




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pro_pos_integralRule_op]
@in_id int output,
@in_expense Decimal(18,2),
@in_member_integral Decimal(18,2),
@in_introducer_integral Decimal(18,2),
@in_update_time datetime,
@in_update_man int,
@in_cp_id int=0,
@in_di_id int=0,
@in_erp_id int=0,
--操作类型(1:添加 2:修改 )
@op_type Int=0,
@outResult int Output
AS
BEGIN
	IF @op_type=1
    Begin
	INSERT INTO [pos_integralRule](
	[in_expense],[in_member_integral],[in_introducer_integral],[in_update_time],[in_update_man],[in_cp_id],[in_di_id]
	,in_erp_id)VALUES(
	@in_expense,@in_member_integral,@in_introducer_integral,@in_update_time,@in_update_man,@in_cp_id,@in_di_id
	,@in_erp_id)
	SET @in_id = SCOPE_IDENTITY()
	END
	
	IF @op_type=2 AND @in_id>0
    Begin
    UPDATE [pos_integralRule] SET 
	[in_expense] = @in_expense,[in_member_integral] = @in_member_integral,[in_introducer_integral] = @in_introducer_integral,[in_update_time] = @in_update_time,[in_update_man] = @in_update_man,[in_cp_id]=@in_cp_id,[in_di_id]=@in_di_id,in_erp_id=@in_erp_id
	WHERE in_id=@in_id 
    END
    
    
    
    if @@error<>0 
begin 
	set @outResult=0;
end
else 
begin
   set @outResult=@in_id;
end
  Return @outResult;
END
go

