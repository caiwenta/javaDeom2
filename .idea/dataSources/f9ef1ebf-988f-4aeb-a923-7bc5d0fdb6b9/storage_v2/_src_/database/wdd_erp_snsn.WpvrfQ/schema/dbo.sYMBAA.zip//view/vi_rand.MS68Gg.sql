CREATE VIEW [dbo].[vi_rand] AS 
select rand() as rt
go

