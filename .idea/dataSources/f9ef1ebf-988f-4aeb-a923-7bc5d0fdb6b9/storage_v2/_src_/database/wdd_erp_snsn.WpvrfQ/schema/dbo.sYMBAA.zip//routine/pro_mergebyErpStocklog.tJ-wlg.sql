CREATE PROCEDURE [dbo].[pro_mergebyErpStocklog]
	@op_type VARCHAR(100),
	@stockType int = 0,
	@orderid int=0,
	@new_sei_id int=0,
	@old_sei_id int=0
	
AS

declare @erp_id int=0
declare @negative_inventory int=0;--产生了负库存是否提示
declare @cp_id int=0;--公司id
declare @sei_id int=0;--仓库id
DECLARE @date DATETIME='1988-7-30';
DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';

BEGIN TRY

--入库
IF @stockType=1
BEGIN

 select 
 @erp_id=eo_erp_id, 
 @cp_id=eo_cp_id,
 @sei_id=eo_siid,
 @date=eo_entrydate
 from j_enterStorage where eo_id=@orderid
 

 select @negative_inventory=sei_is_negative_inventory 
 from b_storageinfo where sei_id=@sei_id;

 if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end

--审核计算库存


	
	EXEC pro_stockcheck @date =@date, @cp_id = @cp_id, @old_sei_id = @old_sei_id, @new_sei_id = @new_sei_id


	IF (@op_type='审核单据' OR @op_type='取消审核单据')
	BEGIN

		EXEC pro_mergeStockLog_j_enterStorage 
		@cp_id = @cp_id, 
		@negative_inventory=@negative_inventory,
		@old_sei_id=@old_sei_id,
		@new_sei_id=@new_sei_id,
		@id=@orderid;
	 
		
		EXEC pro_update_b_stockinfo_si_pddate @order_id = @orderid, @order_type = 'erp入库'
		  
	END



END

--出库
IF @stockType=2
BEGIN

 select 
 @erp_id=oo_erp_id, 
 @cp_id=oo_cp_id,
 @sei_id=oo_siid,
 @date=oo_entrydate
 from j_outStorage where oo_id=@orderid


 select @negative_inventory=sei_is_negative_inventory 
 from b_storageinfo where sei_id=@sei_id;


 if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end

--审核计算库存


	EXEC pro_stockcheck @date =@date, @cp_id = @cp_id, @old_sei_id = @old_sei_id, @new_sei_id = @new_sei_id
	
	IF (@op_type='审核单据' OR @op_type='取消审核单据')
	BEGIN

		EXEC pro_mergeStockLog_j_outStorage 
		@cp_id = @cp_id, 
		@negative_inventory=@negative_inventory,
		@old_sei_id=@old_sei_id,
		@new_sei_id=@new_sei_id,
		@id=@orderid;
		
	END

END

--期初
IF @stockType=3
BEGIN

 select 
 @erp_id=in_erp_id, 
 @cp_id=in_cp_id,
 @sei_id=in_st_id,
 @date=in_date
 from j_initStorage where in_id=@orderid


 select @negative_inventory=sei_is_negative_inventory 
 from b_storageinfo where sei_id=@sei_id;


 if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end


	
	EXEC pro_stockcheck @date =@date, @cp_id = @cp_id, @old_sei_id = @old_sei_id, @new_sei_id = @new_sei_id


	IF (@op_type='审核单据' OR @op_type='取消审核单据')
	BEGIN

		EXEC pro_mergeStockLog_j_initStorage 
		@cp_id = @cp_id, 
		@negative_inventory=@negative_inventory,
		@old_sei_id=@old_sei_id,
		@new_sei_id=@new_sei_id,
		@id=@orderid;
		
	END




END

--移仓
IF @stockType=4 OR @stockType=5
BEGIN

 select 
 @erp_id=mo_erp_id, 
 @cp_id=mo_cp_id,
 @old_sei_id=mo_out_st_id,
 @new_sei_id=mo_in_st_id,
 @date=mo_date
 from j_moStorage where mo_id=@orderid


   
    EXEC pro_stockcheck @date =@date, @cp_id = @cp_id, @old_sei_id = @old_sei_id, @new_sei_id = @new_sei_id


	IF (@op_type='审核单据' OR @op_type='取消审核单据'or @op_type ='收货' or @op_type ='取消收货')
	BEGIN
	    
		if @op_type ='收货'
		BEGIN
			UPDATE j_moStorage SET mo_status=2 WHERE MO_ID=@orderid
		END

		if @op_type ='取消收货'
		BEGIN
			UPDATE j_moStorage SET mo_status=0 WHERE MO_ID=@orderid;--注意取消收货是把移入删除掉
		END

		 EXEC pro_mergeStockLog_j_moStorage 
	     @cp_id = @cp_id, 
	     @id=@orderid,
	     @negative_inventory = @negative_inventory,
		 @old_sei_id=@old_sei_id,
		 @new_sei_id=@new_sei_id

	END

END

--盈亏
if @stockType=6
begin

 select 
 @erp_id=pl_erp_id, @cp_id=pl_cp_id,
 @sei_id=pl_st_id,
 @date=pl_date
 from j_plStorage where pl_id=@orderid

 if @new_sei_id=0 begin 
	set @new_sei_id=@sei_id;
 end
 if	@old_sei_id=0 begin
	set @old_sei_id=@sei_id;
 end


	EXEC pro_stockcheck @date =@date, @cp_id = @cp_id, @old_sei_id = @old_sei_id, @new_sei_id = @new_sei_id
	
	IF @op_type = '审核单据' OR @op_type = '取消审核单据'
	BEGIN
	
	EXEC pro_mergeStockLog_j_plStorage @cp_id = @cp_id,
	         @negative_inventory = @negative_inventory,
	         @old_sei_id = @old_sei_id,
	         @new_sei_id = @new_sei_id, @id = @orderid
	END

end

END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

