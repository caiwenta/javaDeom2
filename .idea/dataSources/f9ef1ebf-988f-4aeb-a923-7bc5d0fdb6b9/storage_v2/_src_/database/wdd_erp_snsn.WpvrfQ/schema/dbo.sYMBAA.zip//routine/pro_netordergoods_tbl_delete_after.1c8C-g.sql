CREATE PROC [dbo].[pro_netordergoods_tbl_delete_after] @ord_id INT = 0
AS
    BEGIN
		--作废或退款,释放占用库存
        UPDATE  netorder_occupy_tbl
        SET     o_status = 0 ,
                o_update_time = GETDATE() ,
                o_status_int = -100
        WHERE   o_ord_id = @ord_id
				AND o_status <> 0;
		
		IF @@ROWCOUNT > 0
			EXEC pro_update_occupy_num @id = @ord_id;
    END
go

