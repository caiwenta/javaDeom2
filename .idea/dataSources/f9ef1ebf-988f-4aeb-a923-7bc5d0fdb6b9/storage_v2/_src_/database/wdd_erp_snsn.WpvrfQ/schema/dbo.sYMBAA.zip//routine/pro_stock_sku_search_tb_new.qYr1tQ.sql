CREATE   proc [dbo].[pro_stock_sku_search_tb_new]      
@gi_id int ,
@Type int
AS
DECLARE @erp_id INT;
SELECT @erp_id=bg.gi_erp_id FROM b_goodsinfo bg WHERE bg.gi_id=@gi_id;
if(@Type=0)
begin
  SELECT top 1  le.gs_values,el.gs_values  FROM (
	SELECT * FROM b_goodsruleset fd WHERE fd.gi_id=@gi_id
	) AS fd LEFT JOIN (
	SELECT sl.skuid
	FROM vi_stockList sl 
	WHERE sl.gid=@gi_id
	GROUP BY sl.skuid	
	) fd2 ON fd.gss_id=fd2.skuid
left join s_goodsrule le on fd.gs_name like  
    '%:'+le.gs_name+'%' and  le.gs_remark='尺码'
    AND le.gs_erp_id=@erp_id
        left join s_goodsrule el on fd.gs_name like  
    '%:'+el.gs_name+'%' and  el.gs_remark='颜色'
    
end
ELSE--有仓库
BEGIN
 
	SELECT bs.sei_name, fo.gi_name 商品名称,fo.gi_code 商品编码,fo.gi_barcode 条形码,le.gs_values 尺码类型,il.gd_name 尺码值,
    tail.gd_name 颜色值,(case when dr.gnum is not null then dr.gnum else 0 end) 数量  from (SELECT fd2.[sid], fd.*,fd2.gnum,gs_money=fd2.gnum*fd.gs_purchase FROM (
	SELECT * FROM b_goodsruleset fd WHERE fd.gi_id=@gi_id
	) AS fd LEFT JOIN (
	SELECT sl.skuid,sl.[sid],
	Sum(Case when sl.countType=1 Then sl.gnum Else -sl.gnum End)As gnum FROM vi_stockList sl 
INNER JOIN b_goodsinfo bg ON bg.gi_id =sl.gid  and sl.cp_id=bg.gi_cp_id 
	WHERE  sl.gid=@gi_id
	GROUP BY sl.skuid,sl.[sid]	
	) fd2 ON fd.gss_id=fd2.skuid) as dr inner join b_goodsinfo fo on fo.gi_id=dr.gi_id 
	INNER JOIN b_storageinfo bs ON dr.sid=bs.sei_id
	
	left join s_goodsrule le on dr.gs_name like  
    '%'+le.gs_name+'%' and  le.gs_remark='尺码'
    AND le.gs_erp_id=@erp_id
    left join s_goodsrule utqc on dr.gs_name like  
    '%'+utqc.gs_name+'%' and  utqc.gs_remark='颜色'
    AND utqc.gs_erp_id=@erp_id
    left join s_goodsruledetail il on  dr.gs_name like 
    '%:'+ il.gd_name+'%' and il.gs_id=le.gs_id    
    left join s_goodsruledetail tail on  (dr.gs_name LIKE '%:' + tail.gd_name  or  dr.gs_name LIKE '%:' + tail.gd_name+'|%') and tail.gs_id=utqc.gs_id
 
end
go

