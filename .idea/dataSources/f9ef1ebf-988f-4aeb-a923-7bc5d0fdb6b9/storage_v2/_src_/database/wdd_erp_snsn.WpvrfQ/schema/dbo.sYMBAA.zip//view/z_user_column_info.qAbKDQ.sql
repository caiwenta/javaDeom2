CREATE VIEW [dbo].[z_user_column_info] AS 
SELECT 
si.*,
ui.*,
sg.di_name, sg.di_id,
(CASE WHEN uci_sort is not null then ui.uci_sort else si.sci_sort end)as sort
FROM  s_sys_column_info AS si 
INNER JOIN s_dg_info AS sg ON si.sci_di_id = sg.di_id AND sg.di_status<>0
LEFT JOIN s_user_column_info AS ui ON si.sci_id = ui.uci_sci_id
go

