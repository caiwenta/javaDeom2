CREATE VIEW [dbo].[v_z_pos_inStorageList]
	AS 
SELECT
	inl_in_id,
	inl_gi_id,
	inl_add_time,
	SUM (inl_num) AS inl_num,
	MIN (inl_id) AS inl_id,
	inl_sku_id,
	SUM (inl_money) AS inl_money,
	CONVERT (
		DECIMAL (10, 2),
		AVG (inl_retail_price)
	) AS inl_retail_price,
	CONVERT (
		DECIMAL (10, 2),
		AVG (inl_stock_price)
	) AS inl_stock_price,
	MAX (inl_gift) AS inl_gift,
	MAX (inl_sample_no) AS inl_sample_no,
	CONVERT (
		DECIMAL (10, 2),
		AVG (inl_discount)
	) AS inl_discount,
	MAX (replace(inl_pm, '*', ',')) AS inl_pm,
	MAX (inl_box_num) AS inl_box_num,
	max(inl_pddate) as inl_pddate,
	max(inl_pdgddate) as inl_pdgddate,
	max(inl_erp_id) as inl_erp_id
FROM
	dbo.pos_inStorageList AS jt WITH (NOLOCK) 
WHERE
	(inl_status = 1)
GROUP BY
	inl_in_id,
	inl_gi_id,
	inl_sku_id,
	inl_add_time
go

