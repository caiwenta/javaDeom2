CREATE VIEW [dbo].[v_z_allocation_color]
	AS 

SELECT
ge.al_review,
st.allmcs_id color_order_id,
ge.al_id,
ge.al_cp_id,
sg.sei_erp_id AS erp_id,
ge.al_vo,--凭证号
ge.al_no,--单据号
CONVERT(VARCHAR(100), ge.al_date, 23)al_date,--配货日期
ge.al_type,--交易方式
ge.al_trans,--运输方式
ge.al_freight_no,--货运单号
ge.al_fright,--垫付运费
ge.al_source,--来源
ge.al_source_id,--退货
ge.al_add_man_txt,--添加人
ge.al_add_time,--单据添加时间
ge.al_update_man_txt,--修改人
ge.al_update_time,--单据修改时间
ge.al_audit_man_txt,--审核人
ge.al_audit_time,
ge.al_status,
ge.al_remark,
(CASE ge.al_source WHEN 2 THEN (SELECT re_vo FROM pos_reStorage AS bs  WITH (NOLOCK) WHERE re_id = ge.al_source_id )
                   WHEN 3 THEN (SELECT in_vo FROM pos_inStorage AS bs  WITH (NOLOCK) WHERE in_id = ge.al_source_id ) 
                   WHEN 5 THEN (SELECT og_vo FROM pos_ogStorage AS bs  WITH (NOLOCK) WHERE og_id = ge.al_source_id)
                   WHEN 7 THEN (SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) 
                                        LEFT JOIN dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id WHERE eio.io_id =ge.al_source_id )
 END) AS al_source_vo,--来源

sg.sei_name AS al_st_id_txt,--仓库
sg.sei_name,--仓库
ge.al_ci_id,
ci_name  as al_ci_id_txt,--客户
ci.ci_code as al_ci_code_txt,--客户代号
ISNULL(ci.ci_name,'') AS ci_name,--客户
ISNULL(ci.ci_code,'') AS ci_code,--客户代号
ge.al_sh_id,
sh_name as al_sh_id_txt,--店铺
sh_no as al_sh_code_txt,--店铺代号
ISNULL(ps.sh_name,'') AS sh_name,--店铺
ISNULL(ps.sh_no,'') AS sh_no,--店铺代号
ge.al_to_cp_id,
cp.cp_name as al_to_cp_id_txt,--公司
cp.cp_code as al_to_cp_code_txt,--分公司代号
ISNULL(cp.cp_name,'') AS cp_name,--分公司
ISNULL(cp.cp_code,'') AS cp_code,--分公司代号
ui.ut_name as gi_unit_name,--单位
ui.ut_name,--单位


st.all_source_id,--明细来源id
st.all_source_add_time,--明细来源时间            
st.all_gift,--是否赠送
st.all_add_time,--单据商品添加时间
 
'' AS specname,
   
st.all_gi_id, 
st.all_color_id,--颜色id    
ISNULL((SELECT TOP 1 colorname FROM b_goodsruleset b WHERE b.gi_id=st.all_gi_id AND colorid=st.all_color_id ),'无') AS color,   
gi.gi_id,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
gi.gi_skus,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_sampleno,--样品号
ISNULL((SELECT TOP 1 b.gs_sampleno 
        FROM b_goodsruleset b 
        WHERE b.gi_id=st.all_gi_id AND colorid=st.all_color_id),gi.gi_sampleno) AS gs_sampleno,--规格样品号
ISNULL(st.all_discount,0) AS all_discount,--折率
ISNULL(st.all_retail_price,0) AS all_retail_price,--零售价
ISNULL(st.all_stock_price,0) AS all_stock_price,--供货价
ISNULL(st.all_retail_money,0) AS all_retail_money,--零售金额
ISNULL(st.all_money,0) AS all_money,--金额
st.supplyprice,--出货价
st.discount,--出货价折扣
(CASE WHEN st.supplyprice=0 THEN 0 ELSE CONVERT(DECIMAL(9,2), (st.all_stock_price/st.supplyprice)) END) AS realitydiscount,--实际折扣        
            
ISNULL(st.all_num,0) AS num,--规格数量
ISNULL(st.all_num,0) AS all_num,--数量
ISNULL(st.all_num_ed, 0) AS all_num_ed, --已执行数量
ISNULL(st.all_pause_num, 0) AS all_pause_num ,--终止数量
(ISNULL(st.all_num,0)-ISNULL(st.all_num_ed,0)) - ISNULL(st.all_pause_num, 0) AS all_num_do, --未执行数量
               
st.all_pm,--配码
ISNULL(st.all_boxbynum,0) AS all_boxbynum,--数量/箱
ISNULL(st.all_box_num,0) AS all_box_num, --箱数
ISNULL(st.all_box_num_ed,0) AS all_box_num_ed, --已执行箱数
ISNULL(st.all_pause_box_num,0) AS all_pause_box_num, --终止箱数
(ISNULL(st.all_box_num,0)-ISNULL(st.all_box_num_ed,0)) - ISNULL(st.all_pause_box_num, 0) AS all_box_num_do --未执行箱数
            
FROM   pos_allocation ge
inner join  pos_allocationListMergeColorSum st ON ge.al_id = st.all_al_id AND st.all_status = 1 and ge.al_status>0
inner join b_goodsinfo gi on gi.gi_id=st.all_gi_id and gi_status=1
inner join b_unit ui on ui.ut_id=gi.gi_unit 
inner join b_storageinfo sg on sg.sei_id=ge.al_st_id--仓库
left join b_clientinfo ci on ci.ci_id= ge.al_ci_id and ci.ci_status=1 --客户
left join pos_shop ps on ps.sh_id=ge.al_sh_id --店铺
left join companyinfo cp on cp.cp_id= ge.al_to_cp_id --分公司
WHERE all_num<>0
go

