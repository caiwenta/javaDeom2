


CREATE VIEW [dbo].[vi_allocation_outed]
AS
SELECT 
       
       jos.oo_id,
       josl.ol_siid,
	   josl.ol_skuid,
       josl.ol_number,
       josl.ol_source_id,
       josl.ol_source_add_time,
	   josl.ol_box_num,
	   josl.ol_boxbynum,
	   isnull(josl.ol_pm,'') as ol_pm
FROM   j_outStorage                 AS jos WITH (NOLOCK) 
       INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) 
            ON  jos.oo_id = josl.ol_eoid
WHERE  jos.oo_source_type = 1
       AND jos.oo_source_id > 0
       AND josl.ol_status = 1
       AND jos.oo_status > 0
go

