
CREATE VIEW [dbo].[vi_j_pos_takeStorageList_sum] AS 
select jtsl.tsl_ts_id,sum(jtsl.tsl_old_num) as tsl_old_num,sum(jtsl.tsl_new_num) as tsl_new_num,sum(jtsl.tsl_log_num) as tsl_log_num,sum(jtsl.tsl_old_money) as tsl_old_money,sum(jtsl.tsl_new_money) as tsl_new_money,sum(jtsl.tsl_log_money) as tsl_log_money from pos_takeStorageList as jtsl
where jtsl.tsl_status=1
group by jtsl.tsl_ts_id
go

