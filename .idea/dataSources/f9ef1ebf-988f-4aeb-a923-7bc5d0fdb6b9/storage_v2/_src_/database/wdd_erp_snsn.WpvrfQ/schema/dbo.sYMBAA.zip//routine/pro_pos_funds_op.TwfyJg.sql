CREATE PROC [dbo].[pro_pos_funds_op]
    @fu_id INT = 0 , --主键  
    @fu_sh_id INT = 0 , --店铺主键  
    @fu_date DATETIME = '2014-10-24' , --日期   
    @fu_ci_id INT = 0 ,  --供方主键
    @fu_type INT = 0 ,  --类型(0,应收:1,应付)
    @fu_order_man INT = 0 ,  --制单人主键  
    @fu_add_man INT = 0 ,  --添加人主键  
    @fu_add_time DATETIME = '2014-10-24' ,  --添加时间  
    @fu_update_man INT = 0 ,  --修改人主键  
    @fu_update_time DATETIME = '2014-10-24' ,  --修改时间  
    @fu_audit_man INT = 0 ,  --审核人  
    @fu_audit_time DATETIME = '2014-10-24' ,  --审核时间  
    @fu_remark VARCHAR(200) = '' , --备注
    @fu_source_type INT = 0 , --来源类型(1,入库)
    @fu_source_id INT = 0 , --来源主键
    @fu_source_vo VARCHAR(200) = '' , --来源凭证号
    @ful_id INT = 0 ,  --主键  
    @ful_fu_id INT = 0 ,  --账款登记主键  
    @ful_ensure_money DECIMAL(9, 2) = 0 ,  --保证金  
    @ful_handsel_money DECIMAL(9, 2) = 0 ,  --定金  
    @ful_freight DECIMAL(9, 2) = 0 ,  --垫付运费  
    @ful_other_out_money DECIMAL(9, 2) = 0 ,  --其他应收  
    @ful_other_in_money DECIMAL(9, 2) = 0 ,  --其他应付  
    @ful_money DECIMAL(9, 2) = 0 ,  --本期收款  
    @ful_vo VARCHAR(50) = '' ,  --记账凭证  
    @ful_remark VARCHAR(50) = '' ,  --摘要  
    @ful_in_money DECIMAL(9, 2) = 0 , --入库金额
    @ful_out_money DECIMAL(9, 2) = 0 , --退货金额
    @op_type VARCHAR(100) = '添加修改单据,明细' ,  --操作类型  
    @result VARCHAR(100) = '' OUT --结果  
AS
    BEGIN
        IF @fu_source_vo != ''
            BEGIN
				--其他地方生成的账款
                IF EXISTS ( SELECT  *
                            FROM    pos_funds AS pf
                            WHERE   pf.fu_source_vo = @fu_source_vo
                                    AND pf.fu_status != 0 )
                    BEGIN
						--从其他地方生成过来的账款,只会有一条明细
                        SELECT TOP 1
                                @fu_id = pf.fu_id
                        FROM    pos_funds AS pf
                        WHERE   pf.fu_source_vo = @fu_source_vo
                                AND pf.fu_status != 0;

                        SET @ful_fu_id = @fu_id;

                        IF EXISTS ( SELECT  *
                                    FROM    pos_fundsList AS pfl
                                    WHERE   pfl.ful_fu_id = @ful_fu_id
                                            AND pfl.ful_status = 1 )
                            BEGIN
								--得到明细主键
                                SELECT TOP 1
                                        @ful_id = pfl.ful_id
                                FROM    pos_fundsList AS pfl
                                WHERE   pfl.ful_fu_id = @ful_fu_id
                                        AND pfl.ful_status = 1;
                            END
                    END
            END
		--是否添加单据
        DECLARE @isInsert INT = 0;
		--是否需要更新单据
        DECLARE @need_update INT = 0;
		--旧的单据日期
        DECLARE @old_order_date DATETIME;
		--单据日期是否更改
        DECLARE @old_order_date_is_changed INT = 0;
		--凭证号前缀
        DECLARE @myprevTxt VARCHAR(50) = '';
	
        IF @fu_type = 0
            BEGIN
				--应收账款
                SET @myprevTxt = 'YSZK';
            END
        ELSE
            IF @fu_type = 1
                BEGIN
					--应付账款
                    SET @myprevTxt = 'YFZK';
                END
	
        BEGIN TRAN

        IF @op_type = '添加修改单据,明细'
            BEGIN
                IF @fu_id = 0
                    BEGIN
						--添加单据
                        INSERT  INTO pos_funds
                                ( fu_sh_id ,
                                  fu_vo ,
                                  fu_date ,
                                  fu_ci_id ,
                                  fu_type ,
                                  fu_status ,
                                  fu_order_man ,
                                  fu_add_man ,
                                  fu_add_time ,
                                  fu_update_man ,
                                  fu_update_time ,
                                  fu_remark ,
                                  fu_source_type ,
                                  fu_source_id ,
                                  fu_source_vo
	                            )
                        VALUES  ( @fu_sh_id ,
                                  NEWID() ,
                                  @fu_date ,
                                  @fu_ci_id ,
                                  @fu_type ,
                                  1 ,
                                  @fu_order_man ,
                                  @fu_add_man ,
                                  @fu_add_time ,
                                  @fu_update_man ,
                                  @fu_update_time ,
                                  @fu_remark ,
                                  @fu_source_type ,
                                  @fu_source_id ,
                                  @fu_source_vo
	                            );

                        SET @fu_id = SCOPE_IDENTITY();
                        SET @old_order_date = @fu_date;
                        SET @ful_fu_id = @fu_id;
                        SET @isInsert = 1;
                    END
                ELSE
                    BEGIN
                        SET @need_update = 1;
                    END
	    
                IF @ful_id = 0
                    BEGIN
                        INSERT  INTO pos_fundsList
                                ( ful_fu_id ,
                                  ful_ensure_money ,
                                  ful_handsel_money ,
                                  ful_freight ,
                                  ful_other_out_money ,
                                  ful_other_in_money ,
                                  ful_money ,
                                  ful_vo ,
                                  ful_remark ,
                                  ful_status ,
                                  ful_add_time ,
                                  ful_update_time ,
                                  ful_in_money ,
                                  ful_out_money
	                            )
                        VALUES  ( @ful_fu_id ,
                                  @ful_ensure_money ,
                                  @ful_handsel_money ,
                                  @ful_freight ,
                                  @ful_other_out_money ,
                                  @ful_other_in_money ,
                                  @ful_money ,
                                  @ful_vo ,
                                  @ful_remark ,
                                  1 ,
                                  GETDATE() ,
                                  GETDATE() ,
                                  @ful_in_money ,
                                  @ful_out_money
	                            );

                        SET @ful_id = SCOPE_IDENTITY();
                    END
                ELSE
                    BEGIN
                        UPDATE  pos_fundsList
                        SET     ful_fu_id = @ful_fu_id ,
                                ful_ensure_money = @ful_ensure_money ,
                                ful_handsel_money = @ful_handsel_money ,
                                ful_freight = @ful_freight ,
                                ful_other_out_money = @ful_other_out_money ,
                                ful_other_in_money = @ful_other_in_money ,
                                ful_money = @ful_money ,
                                ful_vo = @ful_vo ,
                                ful_remark = @ful_remark ,
                                ful_update_time = GETDATE() ,
                                ful_in_money = @ful_in_money ,
                                ful_out_money = @ful_out_money
                        WHERE   ful_id = @ful_id;
                    END
            END
	
        IF @op_type = '审核单据'
            BEGIN
				--审核单据
                UPDATE  pos_funds
                SET     fu_status = 2 ,
                        fu_audit_man = @fu_update_man ,
                        fu_audit_time = GETDATE()
                WHERE   fu_id = @fu_id;
            END
	
        IF @op_type = '取消审核单据'
            BEGIN
				--取消审核单据
                UPDATE  pos_funds
                SET     fu_status = 1
                WHERE   fu_id = @fu_id;
            END
	
        IF @op_type = '删除单据'
            BEGIN
				--删除单据
                UPDATE  pos_funds
                SET     fu_status = 0
                WHERE   fu_id = @fu_id;
            END
	
        IF @op_type = '删除明细'
            BEGIN
				--删除明细
                UPDATE  pos_fundsList
                SET     ful_status = 0
                WHERE   ful_id = @ful_id;
            END
		
        IF @op_type = '添加修改单据,明细'
            OR @need_update = 1
            OR @op_type = '修改单据'
            BEGIN
				--得到旧的单据日期
                SELECT  @old_order_date = jt.fu_date
                FROM    pos_funds AS jt
                WHERE   jt.fu_id = @fu_id;

                IF @old_order_date != @fu_date
                    BEGIN
                        SET @old_order_date_is_changed = 1;
                    END
	    
                UPDATE  pos_funds
                SET     fu_sh_id = @fu_sh_id ,
                        fu_date = @fu_date ,
                        fu_ci_id = @fu_ci_id ,
                        fu_type = @fu_type ,
                        fu_order_man = @fu_order_man ,
                        fu_update_man = @fu_update_man ,
                        fu_update_time = @fu_update_time ,
                        fu_remark = @fu_remark ,
                        fu_source_type = @fu_source_type ,
                        fu_source_id = @fu_source_id ,
                        fu_source_vo = @fu_source_vo
                WHERE   fu_id = @fu_id;
            END
	
        SET @old_order_date_is_changed = 0;

        IF @isInsert = 1
		   --OR @old_order_date != @fu_date
		   --OR @old_order_date_is_changed = 1
            BEGIN
				--凭证号生成
				--更新凭证号 
                DECLARE @tableName VARCHAR(50) = 'pos_funds'
                DECLARE @idField VARCHAR(50) = 'fu_id'
                DECLARE @idValue INT = @fu_id;
	    
                DECLARE @dateField VARCHAR(50) = 'fu_date'
                DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @fu_date, 23)
	    
                DECLARE @noField VARCHAR(50) = 'fu_vo'
                DECLARE @prevTxt VARCHAR(50) = @myprevTxt
                DECLARE @outno VARCHAR(100) = ''
                DECLARE @while INT = 0;

                WHILE @while = 0
                    BEGIN
						--得到凭证号
                        EXECUTE [pro_gen_orderNo] @tableName, @idField, @idValue, @dateField, @dateValue, @noField, @prevTxt, @outno OUTPUT, @fu_sh_id
	        
                        BEGIN TRY
	        				--更新
                            UPDATE  pos_funds
                            SET     fu_vo = @outno ,
                                    pzone = dbo.Get_StrArrayStrOfIndex(@outno, '-', 1) ,
                                    pztwo = dbo.Get_StrArrayStrOfIndex(@outno, '-', 2) ,
                                    pzthree = dbo.Get_StrArrayStrOfIndex(@outno, '-', 3)
                            WHERE   fu_id = @fu_id;
	        				--更新成功,赋值,结束循环
                            SET @while = 1;
                        END TRY
                        BEGIN CATCH
                            PRINT '';
	        				----发生错误,判断错误类型
	        				--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        				--BEGIN
	        				--    --不是发生重复的错误
	        				--    --赋值,结束循环
	        				--    SET @while = 1;
	        				--END
                        END CATCH
                    END
            END
	
        UPDATE  pos_funds
        SET     fu_dateint = dbo.Get_StrArrayStrOfIndex(fu_vo, '-', 2) ,
                fu_orderint = dbo.Get_StrArrayStrOfIndex(fu_vo, '-', 3)
        WHERE   fu_id = @fu_id;
	
        EXEC pro_update_pos_fundsList @fu_id = @fu_id ;
	
        IF @@ERROR <> 0
            BEGIN
                SET @result = '0';
                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN;
            END
        ELSE
            BEGIN
                IF @isInsert = 1
                    BEGIN
                        SET @result = CONVERT(VARCHAR(50), @fu_id);
                    END
                ELSE
                    BEGIN
                        IF @op_type = '添加修改单据,明细'
                            BEGIN
                                SET @result = CONVERT(VARCHAR(50), @ful_id);
                            END
                        ELSE
                            BEGIN
                                SET @result = '1';
                            END
                    END
                IF @@TRANCOUNT > 0
                    COMMIT TRAN;
            END
    END
go

