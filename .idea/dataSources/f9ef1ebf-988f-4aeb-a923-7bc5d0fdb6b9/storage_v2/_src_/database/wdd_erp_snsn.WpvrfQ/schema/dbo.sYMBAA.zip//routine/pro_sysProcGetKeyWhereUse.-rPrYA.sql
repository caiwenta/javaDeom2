

CREATE PROCEDURE [dbo].[pro_sysProcGetKeyWhereUse]
    @xtype VARCHAR(10) ,
    @text VARCHAR(100)
-- =============================================
-- Author:		<查询表或字段在哪里使用过>
-- Create date: <2015-07-11>
-- xtype  代表类型
-- C = CHECK 约束
-- D = 默认值或 DEFAULT 约束
-- F = FOREIGN KEY 约束
-- L = 日志
-- FN = 标量函数
-- IF = 内嵌表函数
-- P = 存储过程
-- PK = PRIMARY KEY 约束（类型是 K）
-- RF = 复制筛选存储过程
-- S = 系统表
-- TF = 表函数
-- TR = 触发器
-- U = 用户表
-- UQ = UNIQUE 约束（类型是 K）
-- V = 视图
-- X = 扩展存储过程
-- =============================================
AS
    BEGIN
        SELECT  b.name
        FROM    dbo.syscomments a ,
                dbo.sysobjects b
        WHERE   a.id = b.id
                AND b.xtype = @xtype
                AND a.text LIKE '%' + @text + '%'
        ORDER BY name 
    END
go

