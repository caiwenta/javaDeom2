CREATE VIEW [dbo].[v_z_takeStorage_color]
	AS 

SELECT '' specname,
    tlt.tslmcs_id color_order_id,
    tlt.tsl_color_id,--颜色id    
	ISNULL((SELECT TOP 1 colorname FROM b_goodsruleset b WHERE b.gi_id=tlt.tsl_gi_id AND colorid=tlt.tsl_color_id ),'无') AS color,   
	ISNULL((SELECT TOP 1 b.gs_sampleno  FROM b_goodsruleset b  WHERE b.gi_id=tlt.tsl_gi_id AND colorid=tlt.tsl_color_id),gi.gi_sampleno) AS gs_sampleno,--规格样品号
	(select max(tsl_type) from j_takeStorageLog where tsl_st_id=tke.ts_st_id and tsl_date=tke.ts_take_date) tsl_type,

	tlt.tsl_ts_id,
	tke.ts_st_id,
	tke.ts_cp_id,
	tke.ts_erp_id as erp_id,
	tlt.tsl_gi_id,
	tke.ts_vo, 
	tke.ts_no,  
	CONVERT(varchar(100), tke.ts_take_date, 23)ts_take_date, 
	gi.gi_code, 
	gi.gi_barcode, 
	gi.gi_name, 
	gi.gi_id, 
	gi.gi_skuid,
	gi.gi_attribute_ids, 
	gi.gi_attribute_parentids, 
	gi.gi_typesid,
	gi.gi_types,
	gi.gi_type1,
	gi.gi_type2,
	gi.gi_type3,
	gi.gi_type4,
	gi.gi_sampleno,--样品号
	gi.gi_unit as unit_txt,
	ui.ut_name AS gi_unit,
	ui.ut_name,
	0 as tsl_pm_sum,  
	tlt.tsl_pm,
	tlt.tsl_box_num, --箱数
	tlt.tsl_boxbynum,--数量/箱
	tlt.tsl_stock_price, 
	tlt.tsl_retail_price,
	tlt.tsl_discount,

	tsl_old_num, 
	tlt.tsl_new_num, 
	tlt.tsl_log_num, 
	tlt.tsl_old_money, 
	tlt.tsl_new_money, 
	tlt.tsl_log_money, 
	tlt.tsl_add_time,  
	sg.sei_name as ts_st_id_txt, 

	(SELECT di_name FROM dbo.b_departmentinfo AS bs WITH (NOLOCK) WHERE(di_id = tke.ts_it_id)) AS ts_it_id_txt,
	(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE(si_id = tke.ts_order_man)) AS ts_order_man_txt,
	(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = tke.ts_add_man) ) AS ts_add_man_txt,
	ts_add_man,
	ts_add_time,
	(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = tke.ts_update_man) ) AS ts_update_man_txt,
	ts_update_man,
	ts_update_time, 
	(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = tke.ts_audit_man) ) AS ts_audit_man_txt,
	ts_audit_man,
	ts_audit_time,
	ts_remark,
	ts_status,
	tlt.tsl_old_box_num,
	tlt.tsl_log_box_num
FROM j_takeStorage tke
inner join  
(
	SELECT
	    tsl_id as tslmcs_id,
		tsl_ts_id,
		tsl_gi_id,
		tsl_add_time,
		tsl_old_num,
		tsl_new_num,
		tsl_log_num,
		tsl_pm ,
		tsl_boxbynum,--数量/箱
		tsl_box_num, --箱数
		tsl_old_box_num,
		tsl_log_box_num,
		tsl_stock_price,
		tsl_retail_price,
		tsl_discount,
		tsl_old_money,
		tsl_new_money,
		tsl_log_money,
		tsl_color_id
	FROM
		j_takeStorageListMergeColorSum AS jt WITH (NOLOCK) 


) tlt ON tke.ts_id = tlt.tsl_ts_id AND tke.ts_status <>0 
left join b_goodsinfo gi on gi.gi_id=tlt.tsl_gi_id and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 
left join b_storageinfo sg on tke.ts_st_id=sg.sei_id
go

