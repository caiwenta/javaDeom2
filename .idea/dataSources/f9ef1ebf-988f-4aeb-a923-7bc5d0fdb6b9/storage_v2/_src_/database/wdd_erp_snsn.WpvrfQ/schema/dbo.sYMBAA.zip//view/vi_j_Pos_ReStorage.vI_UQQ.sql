
CREATE VIEW [dbo].[vi_j_Pos_ReStorage] AS 

SELECT (ISNULL(sumnum,0)-ISNULL(ph_num,0))un_phnum,*
FROM(
SELECT 
       (SELECT top 1 al_vo
		FROM dbo.pos_allocation WITH (NOLOCK) 
		WHERE al_source=2 and al_status<>0 and al_source_id = re_id)ph_vo,--配货凭证号
	   re_id,
       re_is_audit,
       re_sh_id,
       re_vo,
       CONVERT(VARCHAR(10), re_date, 120) AS re_date,
       re_no,
       re_supplier_sh_id,
       re_add_man,
       re_update_man,
       re_audit_man,
	         (
           SELECT sh_no
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.re_supplier_sh_id)
       )  AS re_sh_no,
       (
           SELECT sh_name
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.re_supplier_sh_id)
       )  AS re_supplier_sh_id_txt,
       (
           SELECT sh_name
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.re_sh_id)
       )  AS re_sh_id_txt,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.re_order_man)
       )  AS re_order_man_txt,
       re_order_man,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.re_add_man)
       )  AS re_add_man_txt,
       re_add_time,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.re_update_man)
       )  AS re_update_man_txt,
       re_update_time,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.re_main_audit_man)
       )  AS re_main_audit_man_txt,
       re_main_audit_time,
       (
           SELECT cp_simplename
           FROM   dbo.companyinfo AS bs
           WHERE  (cp_id = 1)
       )  AS in_company,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.re_audit_man)
       )  AS re_audit_man_txt,
       re_audit_time,
       re_remark,
       re_status,
       (
           SELECT SUM(rel_num)
           FROM   pos_reStorageList
           WHERE  rel_re_id = jis.re_id
                  AND rel_status = 1
       )  AS sumnum,
       (
           SELECT SUM(rel_num)
           FROM   pos_reStorageList
                  LEFT JOIN pos_reStorage
                       ON  rel_re_id = re_id
                  LEFT JOIN pos_allocationList
                       ON  all_source_id = rel_id
                  LEFT JOIN pos_allocation
                       ON  al_id = all_al_id
           WHERE  al_status > 0
                  AND rel_re_id = jis.re_id
                  AND al_source_id = jis.re_id
                  AND rel_status > 0
                  AND re_status > 0
                  AND all_status > 0
                  AND all_source_id > 0
                  AND pos_allocation.al_source=2
                  AND all_source_add_time IS NOT NULL
       )  AS sum_alnum,
       (
           SELECT SUM(rel_money)
           FROM   pos_reStorageList
           WHERE  rel_re_id = jis.re_id
                  AND rel_status = 1
       )  AS summoney,
       (
           SELECT TOP 1 al_id
           FROM   pos_allocation
           WHERE  al_source_id = jis.re_id
                  AND al_status > 0
                  AND al_source_id > 0
                  AND pos_allocation.al_source=2
           ORDER BY
                  al_id
       )  AS source_id,
       (
           SELECT MAX(oo_status)
           FROM   vi_JoinFK_Allocation
           WHERE  al_source_id = jis.re_id
                  AND al_status > 0
                  AND al_source_id > 0
       )  AS oo_status,
        ISNULL( (
           SELECT SUM(all_num)
           FROM   pos_allocation
                  JOIN pos_allocationList
                       ON  al_id = all_al_id
           WHERE  al_source_id = jis.re_id
                  AND al_status > 0
                  AND al_source_id > 0
                  AND all_status > 0
                  AND al_source = 2
       ) ,0) AS ph_num,
	   fd.sh_company,
             (
           SELECT  cp_name
           FROM   companyinfo AS cp
           WHERE  cp.cp_id= jis.re_tocompanyid
            
       )  AS cp_name,
             (
           SELECT  cp_code
           FROM   companyinfo AS cp
           WHERE  cp.cp_id= jis.re_tocompanyid
            
       )  AS cp_code,
	    (
           SELECT  cp_name
           FROM   companyinfo AS cp
           WHERE  cp.cp_id= jis.re_cp_id
            
       )  AS re_cp_name,
	    (
           SELECT  cp_code
           FROM   companyinfo AS cp
           WHERE  cp.cp_id= jis.re_cp_id
            
       )  AS re_cp_code,
	   jis.re_tocompanyid,
	   jis.re_cp_id
FROM   dbo.pos_reStorage AS jis left JOIN pos_shop fd
on jis.re_sh_id=fd.sh_id
)T
go

