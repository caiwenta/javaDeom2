CREATE FUNCTION [dbo].[FuStringNumberSum](@str varchar(500))
returns int
as
begin

declare @n int
declare @m int
declare @i int
declare @sum int
set @n=len(@str)
set @m=0  
set @i=1
set @sum=0;

while @i<=@n
 begin
  set @m=substring(@str,@i,1)
  set @sum=@m+@sum
  set @i=@i+1
end 

return @sum;
end
go

