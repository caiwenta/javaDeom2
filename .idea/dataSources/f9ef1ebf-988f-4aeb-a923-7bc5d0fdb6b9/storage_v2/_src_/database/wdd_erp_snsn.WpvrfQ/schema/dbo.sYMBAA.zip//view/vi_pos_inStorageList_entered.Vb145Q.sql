CREATE VIEW [dbo].[vi_pos_inStorageList_entered]
AS
SELECT pis.in_source_id              AS in_source_id,
       pis.in_source                 AS in_source,
       pisl.inl_gi_id                AS inl_gi_id,
	   pisl.inl_sku_id               AS inl_sku_id,
       pisl.inl_source_add_time,
       SUM(pisl.inl_num)             AS inl_num
FROM   pos_inStorage                 AS pis
       INNER JOIN pos_inStorageList  AS pisl
       ON  pis.in_id = pisl.inl_in_id
WHERE  pis.in_status > 0
       AND pisl.inl_status > 0 
       AND pisl.inl_source_add_time IS NOT NULL
GROUP BY
       pis.in_source,
       pis.in_source_id,
       pisl.inl_gi_id,
	   pisl.inl_sku_id,
       pisl.inl_source_add_time


go

