CREATE PROCEDURE [dbo].[proc_DockingNetOrderAftermarket]
       @outerr VARCHAR(255) OUTPUT ,
       @sendtype VARCHAR(255) OUTPUT ,		--返回erp的发货方类型
       @send_sid INT OUTPUT ,		--返回erp的发货方ID
       @erp_gi_id INT OUTPUT ,		--返回erp的商品ID
       @oc_id INT ,			--平台ID
       @orderno VARCHAR(255) ,	--订单编号
       @ordersno VARCHAR(255) ,	--子单编号
       @goodscode VARCHAR(255) ,	--商品编号
       @skucode VARCHAR(255) ,	--SKU编号
       @refund DECIMAL(10, 2) ,	--退款金额
       @servtype INT ,			--售后类型（0、正常，1、仅退款，2、退货退款，3、换货）
       @servstatus INT ,			--售后状态（0、申请售后，1、拒绝退款，3、取消申请， 4、退款成功）
       @servtime DATETIME ,		--售后时间
       @refundnum INT ,
       @goodsdeliver INT = 0			--申请前商品是否已发货，其它的时候没用，取消申请时应该清除这个值
AS
       SET NOCOUNT ON
		------------------------------------
		--用途：同步订单售后 
		------------------------------------
       SET @outerr = 'ERR'
       SET @erp_gi_id = 0
       DECLARE @ord_id INT= 0;
	   DECLARE @erp_id INT= 0; --企业ID
       DECLARE @ord_sn VARCHAR(255)
       DECLARE @ord_status INT
       DECLARE @nog_id INT
       DECLARE @nog_refundprice DECIMAL(10, 2)
       DECLARE @nog_servtype INT			--售后类型（0、正常,1、退款,2、退货退款)*****
       DECLARE @nog_servstatus INT			--售后状态（0、正常,1、申请售后，2售后成功）*****
       DECLARE @nog_serving INT			--1售后退款中
       DECLARE @nog_vr_state VARCHAR(255)--店中店对应的状态
		--判断订单是否存在
       SELECT   @ord_sn = ord_sn ,
                @ord_status = ord_status ,
                @sendtype = ord_sendtype ,
                @send_sid = ord_send_erp_sid ,
                @ord_id = ord_id ,
				@erp_id = ord_erp_id
       FROM     netorder_tbl
       WHERE    ord_status > -1
                AND ord_no = @orderno
                AND ord_sno = @ordersno
                AND ord_oc_id = @oc_id

       IF ( @@ROWCOUNT = 0 )
          BEGIN
                SET @outerr = '订单不存在';
                RETURN
          END
		--判断申请售后的订单商品是否存在
       SELECT   @nog_id = nog_id ,
                @nog_refundprice = nog_refundprice ,
                @nog_servtype = nog_servtype ,
                @nog_servstatus = nog_servstatus ,
                @nog_serving = nog_serving ,
                @nog_vr_state = ISNULL(nog_vr_state, '')
       FROM     netordergoods_tbl
       WHERE    ord_sn = @ord_sn
                AND nog_goodscode = @goodscode
                AND nog_skucode = @skucode
                AND ISNULL(nog_type, 0) = 0

       IF ( @@ROWCOUNT = 0 )
          BEGIN
                SET @outerr = '订单商品不存在';
                RETURN
          END
		--取erp的商品信息
       SELECT   @erp_gi_id = gi_id
       FROM     b_goodsinfo
       WHERE    gi_code = @goodscode 
				AND gi_erp_id = @erp_id

       IF ( @@ROWCOUNT = 0 )
            SET @erp_gi_id = 0

		--换货的收货状态，不处理
       IF ( @servstatus = 9
            AND @servtype = 3
          )
          BEGIN
                SET @outerr = '' 
                RETURN;
          END
		--店中店售后状态{0,"退款申请中"},{2,"店铺同意"},{5,"买家退回中"},{6,"供应商同意"},{7,"等待打款"},{8,"买家商品退回中"},{9,"卖家已发货"}
       IF ( @servstatus = 0
            OR @servstatus = 2
            OR @servstatus = 5
            OR @servstatus = 6
            OR @servstatus = 7
            OR @servstatus = 8
          )
          BEGIN
                IF ( @nog_servtype = 0
                     AND @nog_serving = 0
                   )
                   BEGIN
                         UPDATE netordergoods_tbl
                         SET    nog_servtype = @servtype ,
                                nog_refund_num = @refundnum ,
                                nog_servstatus = 1 ,
                                nog_serving = 1 ,
                                nog_refundprice = @refund ,
                                nog_servtime = @servtime ,
                                nog_updatime = GETDATE() ,
                                nog_isdeliver = @goodsdeliver ,
                                nog_servorderstatus = @ord_status ,
                                nog_vr_state = @nog_vr_state + ',' + CAST(@servstatus AS VARCHAR(255))
                         WHERE  nog_id = @nog_id

                         IF ( @@ROWCOUNT > 0 )
                            BEGIN
                                  UPDATE    netorder_tbl
                                  SET       ord_servinig = 1 ,
                                            ord_updatime = GETDATE()
                                  WHERE     ord_id = @ord_id

                                  IF ( @@ROWCOUNT > 0 )
                                     BEGIN
                                           SET @outerr = '';
                                           RETURN
                                     END
                            END
                   END
                ELSE
                   BEGIN
                         UPDATE netordergoods_tbl
                         SET    nog_updatime = GETDATE() ,
                                nog_vr_state = @nog_vr_state + ',' + CAST(@servstatus AS VARCHAR(255))
                         WHERE  nog_id = @nog_id
                         SET @outerr = '此商品已申请售后';
                         RETURN 
                   END
          END
		---------------拒绝退款,取消申请
       IF ( @servstatus = 1
            OR @servstatus = 3
          )
          BEGIN
                IF ( @nog_servtype > 0
                     AND @nog_serving = 1
                   )
                   BEGIN
                         UPDATE netordergoods_tbl
                         SET    nog_isdeliver = NULL ,
                                nog_servtype = 0 ,
                                nog_servstatus = 0 ,
                                nog_serving = 0 ,
                                nog_refundprice = 0 ,
                                nog_servorderstatus = 0 ,
                                nog_updatime = GETDATE() ,
                                nog_vr_state = @nog_vr_state + ',' + CAST(@servstatus AS VARCHAR(255))
                         WHERE  nog_id = @nog_id
                         
                         IF ( @@ROWCOUNT > 0 )
                            BEGIN
								--如果此订单不存在售后中的商品，则结束订单售后状态
                                  IF ( ( SELECT COUNT (1) FROM netordergoods_tbl WHERE ord_sn= @ord_sn AND nog_serving= 1
                                       ) = 0 )
                                     BEGIN
                                           UPDATE   netorder_tbl
                                           SET      ord_servinig = 0 ,
                                                    ord_updatime = GETDATE()
                                           WHERE    ord_id = @ord_id
                                           
                                           IF ( @@ROWCOUNT > 0 )
                                              BEGIN
                                                    SET @outerr = '';
                                                    RETURN
                                              END
                                     END
                                  ELSE
                                     BEGIN
                                           SET @outerr = '';
                                           RETURN 
                                     END
                            END
                   END
                ELSE
                   BEGIN
                         SET @outerr = '此商品未申请售后或已退款成功,1,3';
                         RETURN 
                   END
          END
		----退款成功
       IF ( @servstatus = 4 )
          BEGIN
                IF ( @nog_servtype > 0
                     AND @nog_serving = 1
                   )
                   BEGIN
                         SET @outerr = 'ERR'

                         UPDATE netordergoods_tbl
                         SET    nog_serving = 2 ,
                                nog_servstatus = 2 ,
                                nog_updatime = GETDATE() ,
                                nog_vr_state = @nog_vr_state + ',' + CAST(@servstatus AS VARCHAR(255))
                         WHERE  nog_id = @nog_id

                         IF ( @@ROWCOUNT > 0 )
                            BEGIN
                                  EXEC pro_netordergoods_tbl_nog_servtype_update_after @nog_id = @nog_id, @ord_id = @ord_id;
				
                                  IF ( @servtype = 2
                                       AND ( SELECT ISNULL (nog_is_ok, 0) FROM netordergoods_tbl WHERE nog_id= @nog_id
                                           ) <> 1
                                     )
                                     BEGIN 
                                           RETURN
                                     END
	
                                  DECLARE @ord_servinig INT= 1
								  --如果不存在售后申请中的商品，则标记订单的售后结束
                                  IF ( ( SELECT COUNT (1) FROM netordergoods_tbl WHERE ord_sn= @ord_sn AND nog_serving= 1
                                       ) = 0 )
                                     BEGIN
                                           SET @ord_servinig = 0 
                                     END

                                  UPDATE    netorder_tbl
                                  SET       ord_refundmoney = ord_refundmoney + @nog_refundprice ,
                                            ord_servinig = @ord_servinig ,
                                            ord_updatime = GETDATE()
                                  WHERE     ord_id = @ord_id

                                  IF ( @@ROWCOUNT > 0 )
                                     BEGIN
										--如果所有商品都退款成功(正常数量=0),则订单标记结束
                                           IF ( ( SELECT COUNT (1) FROM netordergoods_tbl WHERE ord_sn= @ord_sn AND nog_serving< 2
                                                ) = 0 )
                                              BEGIN
                                                    UPDATE  netorder_tbl
                                                    SET     ord_status = -1 ,
                                                            ord_updatime = GETDATE()
                                                    WHERE   ord_id = @ord_id 

                                                    IF ( @@ROWCOUNT > 0 )
                                                             SET @outerr = '';
                                              END
                                           ELSE
                                              SET @outerr = ''; 
                                     END
                            END
                   END
                ELSE
                   BEGIN
                         SET @outerr = '此商品未申请售后或已退款成功,4'
                         RETURN 
                   END
          END

       SET NOCOUNT OFF
go

