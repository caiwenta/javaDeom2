CREATE VIEW [dbo].[vi_button_page_oper] AS 
select * from s_button_oper as sbo left join vi_page_oper_info as vpoi on sbo.bo_po_id=vpoi.po_id
go

