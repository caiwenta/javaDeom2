CREATE PROCEDURE [dbo].[pro_instructionnotice_op]
	@id int = 0,
	@in_auditman int=0,
	@in_erp_id int=0,
	@op_type VARCHAR(100) = '审核' ,  --操作类型
	@result VARCHAR(100) = '' OUT
AS
BEGIN
	BEGIN TRAN
	
	DECLARE @in_id INT=0;
	DECLARE @in_type INT=0;
	DECLARE @in_level INT=1;
	DECLARE @in_jytype INT=0;
	declare @in_remark varchar(500)='';

	SELECT 
	       @in_id=in_id,
	       @in_type=in_type,
		   @in_level=in_level,
		   @in_jytype=in_jytype,
		   @in_remark=in_remark
	FROM erp_InstructionNotice
	WHERE in_id=@id and 
	      in_erp_id=@in_erp_id


    if @op_type='审核'
	BEGIN

	     UPDATE erp_InstructionNotice SET in_status=2 WHERE in_id=@id AND in_erp_id=@in_erp_id
		
		 --一级
		 declare @io_sender int=0;--发货方的仓库
		 declare @io_sendertype int=0;-- 0:公司 1:店铺
		 declare @io_receiver int=0;--收货方的仓库
		 declare @io_receivertype int=0;-- 0:公司 1:店铺
		 --二级
		 declare @io_sender2 int=0;--发货方的仓库
		 declare @io_sendertype2 int=0;-- 0:公司 1:店铺
		 declare @io_receiver2 int=0;--收货方的仓库
		 declare @io_receivertype2 int=0;-- 0:公司 1:店铺

		 declare @now DATETIME =getdate();
		 declare @orderdate datetime =CONVERT(varchar(100), @now, 23);

		 declare @al_to_cp_id int=0;
		 declare @al_sh_id int=0;
		 declare @al_cp_id int=0;


		 SELECT 
				@io_sender=io_sender,--仓库id
				@io_sendertype=io_sendertype,

				@io_receiver=io_receiver,
				@io_receivertype=io_receivertype 
		FROM erp_instructionObject 
	    WHERE io_in_id=@in_id AND io_level =1;

		SELECT 
				@io_sender2=io_sender,--仓库id
				@io_sendertype2=io_sendertype,

				@io_receiver2=io_receiver,
				@io_receivertype2=io_receivertype 
		FROM erp_instructionObject 
		WHERE io_in_id=@in_id AND io_level =2 ;

		 declare @al_st_id int=0;
		 PRINT N'开始执行指令';
		
		 declare @io_id int=0;
		 IF @in_level=1
		 BEGIN
			--一级指令  
			IF EXISTS (SELECT * FROM erp_instructionObject WHERE io_in_id=@in_id AND io_level =1 AND io_status=0)
			 BEGIN

			 SELECT @io_id=io_id
					FROM erp_instructionObject WHERE io_in_id=@in_id AND io_level =1 AND io_status=0

				--判断单据类型  0-配货单 1-调拨单
				IF @in_type=0
				BEGIN
					PRINT '开始生成配货单';


					

					set @al_to_cp_id =(case when @in_level=2 then 
					(case when @io_sendertype2=0 then (SELECT bs.sei_cp_id FROM b_storageinfo AS bs WHERE bs.sei_erp_id=@in_erp_id AND bs.sei_id=@io_sender2) else 0 end) 
								      else 
									     (case when @io_receivertype=0 then @io_receiver else 0 end) 
								      end);
                    
					set @al_sh_id = (case when @in_level=2 then 
										(case when @io_sendertype2=1 then @io_sender2 else 0 end) 
									 else 
										(case when @io_receivertype=1 then @io_receiver else 0 end)
									 end);


					SELECT @al_cp_id=bs.sei_cp_id FROM b_storageinfo AS bs
					WHERE  bs.sei_erp_id=@in_erp_id AND bs.sei_id=@io_sender

					EXEC pro_pos_allocation_op
						@al_cp_id=@al_cp_id,
						@al_st_id=@io_sender,
	    				@al_id = 0,
	    				@al_update_time = @now,
	    				@al_type = @in_jytype,
	    				@al_source = 7,
	    				@al_source_id = @io_id,
						@al_ci_id = 0,
	    				@al_sh_id = @al_sh_id,
						@al_to_cp_id=@al_to_cp_id,
	    				@al_date =@orderdate ,
	    				@al_order_man = @in_auditman,
	    				@al_add_man = @in_auditman,
						@al_erp_id=@in_erp_id,
	    				@al_add_time = @now,
						@al_remark=@in_remark,
	    				@op_type = '添加修改单据,明细',
	    				@result = @result OUT
					IF @@ERROR <> 0
					BEGIN
						 SET @result = '';

						IF @@TRANCOUNT > 0 ROLLBACK TRAN;
					END

				END 
				ELSE IF @in_type=1
				BEGIN
				    PRINT N'开始生成调拨单';

					SELECT TOP 1 
					@al_st_id=sei_id ,
					@al_sh_id=sei_sh_id
					FROM pos_storageInfo AS psi 
					WHERE psi.sei_erp_id=@in_erp_id and psi.sei_id=@io_sender

				    EXEC pro_pos_alStorage_op
					  @al_erp_id  = @in_erp_id ,
                      @al_sh_id  = @al_sh_id ,  --店铺主键 
					  @al_get_sh_id = @io_receiver , --调入店铺主键   
                      @al_date = @orderdate , --调拨日期   
                      @al_cp_do = 2 ,--1为公司帮店铺做的调拨 2:指令单
                      @al_st_id = @al_st_id , --仓库主键
                      @al_order_man  = @in_auditman , --制单人主键   
                      @al_add_man  = @in_auditman , --添加人主键 
                      @al_add_time  = @now , --添加时间 
                      @al_remark = @in_remark,  --备注 
					  @op_type = '添加修改单据,明细',
					  @al_source_id=@io_id
					IF @@ERROR <> 0
					BEGIN
						 SET @result = '';
						 IF @@TRANCOUNT > 0 ROLLBACK TRAN;
					END
				END
             END
		 END


		 IF @in_level=2
		 BEGIN
			 --一级指令  
			IF EXISTS (SELECT * FROM erp_instructionObject WHERE io_in_id=@in_id AND io_level =1 AND io_status=0)
			 BEGIN

			     SELECT @io_id=io_id FROM erp_instructionObject WHERE io_in_id=@in_id AND io_level =1 AND io_status=0

				--判断单据类型  0-配货单 1-调拨单
				IF @in_type=0
				BEGIN
					PRINT '开始生成配货单';

					set @al_to_cp_id =(case when @in_level=2 then 

					(case when @io_sendertype2=0 then (SELECT bs.sei_cp_id FROM b_storageinfo AS bs WHERE bs.sei_erp_id=@in_erp_id AND bs.sei_id=@io_sender2) else 0 end) 
								      else 
									     (case when @io_receivertype=0 then @io_receiver else 0 end) 
								      end);
                    

					set @al_sh_id = (case when @in_level=2 then 
										(case when @io_sendertype2=1 then @io_sender2 else 0 end) 
									 else 
										(case when @io_receivertype=1 then @io_receiver else 0 end)
									 end);

					SELECT @al_cp_id=bs.sei_cp_id FROM b_storageinfo AS bs
					WHERE  bs.sei_erp_id=@in_erp_id AND bs.sei_id=@io_sender

					EXEC pro_pos_allocation_op
						@al_cp_id=@al_cp_id,
						@al_st_id=@io_sender,
	    				@al_id = 0,
	    				@al_update_time = @now,
	    				@al_type = @in_jytype,
	    				@al_source = 7,
	    				@al_source_id = @io_id,
						@al_ci_id = 0,
	    				@al_sh_id = @al_sh_id,
						@al_to_cp_id=@al_to_cp_id,
	    				@al_date =@orderdate ,
	    				@al_order_man = @in_auditman,
	    				@al_add_man = @in_auditman,
						@al_erp_id=@in_erp_id,
	    				@al_add_time = @now,
						@al_remark=@in_remark,
	    				@op_type = '添加修改单据,明细',
	    				@result = @result OUT
					IF @@ERROR <> 0
					BEGIN
						 SET @result = '';

						IF @@TRANCOUNT > 0 ROLLBACK TRAN;
					END

				END 
				ELSE IF @in_type=1
				BEGIN
				    PRINT N'开始生成调拨单';

					
					SELECT TOP 1 @al_st_id=sei_id ,
					@al_sh_id=sei_sh_id
					FROM pos_storageInfo AS psi 
					WHERE psi.sei_erp_id=@in_erp_id and psi.sei_id=@io_sender

				    EXEC pro_pos_alStorage_op
					  @al_erp_id  = @in_erp_id ,
                      @al_sh_id  = @al_sh_id ,  --店铺主键 
					  @al_get_sh_id = @io_receiver , --调入店铺主键   
                      @al_date = @orderdate , --调拨日期   
                      @al_cp_do = 2 ,--1为公司帮店铺做的调拨 2:指令单
                      @al_st_id = @al_st_id , --仓库主键
                      @al_order_man  = @in_auditman , --制单人主键   
                      @al_add_man  = @in_auditman , --添加人主键 
                      @al_add_time  = @now , --添加时间 
                      @al_remark = @in_remark,  --备注 
					  @op_type = '添加修改单据,明细',
					  @al_source_id=@io_id
					IF @@ERROR <> 0
					BEGIN
						 SET @result = '';
						 IF @@TRANCOUNT > 0 ROLLBACK TRAN;
					END
				END
			END

			---2-二级指令
			IF EXISTS (SELECT * FROM erp_instructionObject WHERE io_in_id=@in_id AND io_level =2 AND io_status=0)
			BEGIN
				set @al_to_cp_id=0;
				set @al_sh_id=0;
				set @al_cp_id =0;

				SELECT @io_id=io_id
					FROM erp_instructionObject WHERE io_in_id=@in_id AND io_level =2 AND io_status=0

				--判断单据类型  0-配货单 1-调拨单
					--判断单据类型  0-配货单 1-调拨单
				IF @in_type=0
				BEGIN
					PRINT N'开始生成配货单';

					set @al_to_cp_id = (case when @io_receivertype2=0 then @io_receiver2 else 0 end);
					set @al_sh_id = (case when @io_receivertype2=1 then @io_receiver2 else 0 end);
					SELECT @al_cp_id=bs.sei_cp_id FROM b_storageinfo AS bs
					WHERE  bs.sei_erp_id=@in_erp_id AND bs.sei_id=@io_sender2


					EXEC pro_pos_allocation_op
						@al_cp_id=@al_cp_id,
						@al_st_id=@io_sender2,
	    				@al_id = 0,
	    				@al_update_time = @now,
	    				@al_type = @in_jytype,
	    				@al_source = 7,
	    				@al_source_id = @io_id,
						@al_ci_id = 0,
	    				@al_sh_id = @al_sh_id,
						@al_to_cp_id=@al_to_cp_id,
	    				@al_date =@orderdate ,
	    				@al_order_man = @in_auditman,
	    				@al_add_man = @in_auditman,
						@al_erp_id=@in_erp_id,
	    				@al_add_time = @now,
						@al_remark=@in_remark,
	    				@op_type = '添加修改单据,明细',
	    				@result = @result OUT
					IF @@ERROR <> 0
					BEGIN
						 SET @result = '';

						IF @@TRANCOUNT > 0 ROLLBACK TRAN;
					END

				END 
			END
		 END

	END


	if @op_type='取消审核'
	BEGIN
	    print '取消审核'

		--修改主订单审核状态
	    UPDATE erp_InstructionNotice SET in_status=1 WHERE in_id=@id AND in_erp_id=@in_erp_id


		 SELECT ROW_NUMBER() over(order by al_id) as tmp,al_id into #temp
		 FROM pos_allocation AS pa  WHERE pa.al_source=7 AND 
		 pa.al_source_id in (SELECT io_id FROM erp_instructionObject WHERE io_in_id=@in_id) AND pa.al_status=1 

			    declare @tmepid int=0;
			    declare @indexmax int=0;
				select @indexmax=count(*) from #temp;


				declare @i int=1;
				while @i<=@indexmax
				begin

					select @tmepid=al_id from #temp where tmp=@i;

					EXEC pro_pos_allocation_op @al_id = @tmepid, @op_type = '删除单据'

					IF @@ERROR <> 0
					BEGIN
						 SET @result = '';
						 IF @@TRANCOUNT > 0 ROLLBACK TRAN;
						 break;
					END
					set @i=@i+1
				end
        drop table #temp


		SELECT ROW_NUMBER() over(order by al_id) as tmp,al_id  into #temp2 FROM pos_alStorage WHERE al_cp_do=2 AND 
		al_source_id in (SELECT io_id FROM erp_instructionObject WHERE io_in_id=@in_id)


				select @indexmax=count(*) from #temp2;
				set @i =1;
				while @i<=@indexmax
				begin

					select @tmepid=al_id from #temp2 where tmp=@i;

					EXEC pro_pos_alStorage_op @al_id = @tmepid, @op_type = '删除单据'

					IF @@ERROR <> 0
					BEGIN
						 SET @result = '';
						 IF @@TRANCOUNT > 0 ROLLBACK TRAN;
						 break;
					END
					set @i=@i+1
				end
		drop table #temp2

		print '取消审核'
	END

	if @op_type='删除'
	begin

	  
	  UPDATE erp_InstructionNotice SET in_status=0 WHERE in_id=@id AND in_erp_id=@in_erp_id
	end

	IF @@ERROR <> 0
	  BEGIN
	     SET @result = '0';
	     IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	  END
	ELSE
	  BEGIN
		SET @result = '1';
		IF @@TRANCOUNT > 0 COMMIT TRAN;
      END
END
go

