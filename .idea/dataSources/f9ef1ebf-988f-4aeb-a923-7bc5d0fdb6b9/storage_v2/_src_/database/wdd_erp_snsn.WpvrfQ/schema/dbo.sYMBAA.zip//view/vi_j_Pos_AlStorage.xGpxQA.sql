


CREATE VIEW [dbo].[vi_j_Pos_AlStorage] AS 
SELECT ord_sn,
       al_id,
       al_sh_id,
	   al_erp_id,
       al_vo,
       CONVERT(VARCHAR(10), al_date, 120) AS al_date,
       al_no,
       al_get_sh_id,
       al_st_id,
       al_order_man,
       al_add_man,
       al_update_man,
       al_audit_man,
	    (case when (SELECT  isnull(inl_num_ed,0) 
                    FROM   dbo.vi_pos_inStorage_audit_se_news AS ins
                    WHERE  (in_id = jis.al_id and in_supplier_id=jis.al_sh_id) )>0 then '已收货' else '未收货' end)  AS al_down_status,
       (
           SELECT  inl_num_ed 
           FROM   dbo.vi_pos_inStorage_audit_se_news AS ins
           WHERE  (in_id = jis.al_id and in_supplier_id=jis.al_sh_id )
       )  AS inl_num_ed,
       (
           SELECT sh_name
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.al_sh_id)
       )  AS al_out_sh_id_txt,
       (
           SELECT sh_no
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.al_sh_id)
       )  AS al_out_sh_no,
       (
           SELECT sh_name
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.al_get_sh_id)
       )  AS al_get_sh_id_txt,
	       (
           SELECT sh_no
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.al_get_sh_id)
       )  AS al_get_sh_no,
       (
           SELECT sh_company
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.al_get_sh_id)
       )  AS sh_company,
       (
           SELECT sei_name
           FROM   dbo.pos_storageInfo AS bs
           WHERE  (sei_id = jis.al_st_id)
       )  AS al_st_id_txt,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.al_order_man)
       )  AS al_order_man_txt,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.al_add_man)
       )  AS al_add_man_txt,
       al_add_time,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.al_update_man)
       )  AS al_update_man_txt,
       al_update_time,
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.al_audit_man)
       )  AS al_audit_man_txt,
       al_audit_time,
       al_remark,
       al_status,
       (
           SELECT SUM(all_num) AS Expr1
           FROM   dbo.pos_alStorageList
           WHERE  (all_al_id = jis.al_id)
                  AND (all_status = 1)
       )  AS sumnum,
       (
           SELECT SUM(all_money) AS Expr1
           FROM   dbo.pos_alStorageList AS pos_alStorageList_1
           WHERE  (all_al_id = jis.al_id)
                  AND (all_status = 1)
       )  AS summoney,
	    isnull(jis.al_cp_do,0) AS al_cp_do,
	    isnull(jis.al_source_id,0) AS al_source_id,
		jis.al_io_logistics,
		jis.al_logistics_no
FROM   dbo.pos_alStorage AS jis
go

