CREATE PROCEDURE [dbo].[Get_Goods_Details]

as



declare @aa int=0;
DECLARE @ID varchar(100),@Str varchar(max)='',@Sql varchar(max)
declare mycursor cursor  for select ''''' as '''+a_name+''',' as ID from vi_b_attribute where a_pid=0 and a_status>0  and a_type='1'
open mycursor
fetch next from mycursor into @ID
while(@@fetch_status = 0)
begin
set @Str=@Str+@ID
fetch next from mycursor into @ID
end
close mycursor
deallocate mycursor

set @Sql='SELECT g.gi_types as 商品分类,g.gi_code as 商品编号,g.gi_simplecode as 商品简码,g.gi_name as 商品名称,g.gi_shortname as 商品简称,(select ut_name from dbo.b_unit where ut_id= g.gi_unit) as 单位,g.gi_barcode as 条形码, g.gi_retailprice as 零售价,g.gi_purchase_discount as 进货折扣,g.gi_purchase as 进货价,g.gi_costprice as 成本价,g.gi_importprices as 销售价,g.gi_brands as 品牌, '''' as 颜色编码,'''' as 颜色名称,'''' as 尺码名称,'+@Str+'g.gi_seiname as 入住仓库,g.gi_weight as 重量,g.gi_upstock as 上线库存,g.gi_downstork as 下限库存,g.gi_alarmstock as 警报库存,CONVERT(varchar,g.gi_id)+'+''',2,0,1'''+' as A折扣,CONVERT(varchar,g.gi_id)+'+''',2,1,1'''+' as A供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,2'''+' as  B折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,2'''+' as  B供货价, CONVERT(varchar,g.gi_id)+'+''',2,1,3'''+' as  C折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,3'''+' as  C供货价, CONVERT(varchar,g.gi_id)+'+''',2,1,4'''+' as  D折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,4'''+' as D供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,5'''+' as   E折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,5'''+' as E供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,6'''+' as  F折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,6'''+' as F供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,7'''+' as   G折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,7'''+' as  G供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,8'''+' as   H折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,8'''+' as H供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,9'''+' as   I折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,9'''+' as I供货价,CONVERT(varchar,g.gi_id)+'+''',2,0,10'''+' as   J折扣,CONVERT(varchar,g.gi_id)+'+''',2,1,10'''+' as J供货价,CONVERT(varchar,g.gi_id)+'+''',2,0,11'''+' as  K折扣,CONVERT(varchar,g.gi_id)+'+''',2,1,11'''+' as K供货价,CONVERT(varchar,g.gi_id)+'+''',2,0,12'''+' as   L折扣,CONVERT(varchar,g.gi_id)+'+''',2,1,12'''+' as L供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,13'''+' as   M折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,13'''+' as  M供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,14'''+' as   N折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,4'''+' as  N供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,15'''+' as   O折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,15'''+' as O供货价, CONVERT(varchar,g.gi_id)+'+''',2,0,16'''+' as  P折扣, CONVERT(varchar,g.gi_id)+'+''',2,1,15'''+' as P供货价, CONVERT(varchar,g.gi_id)+'+''',1,0,1'''+' as  类别0折扣,CONVERT(varchar,g.gi_id)+'+''',1,1,1'''+' 类别0吊牌价, CONVERT(varchar,g.gi_id)+'+''',1,0,2'''+' as  类别1折扣, CONVERT(varchar,g.gi_id)+'+''',1,1,2'''+' 类别1吊牌价, CONVERT(varchar,g.gi_id)+'+''',1,0,3'''+' as  类别2折扣, CONVERT(varchar,g.gi_id)+'+''',1,1,3'''+' 类别2吊牌价, CONVERT(varchar,g.gi_id)+'+''',1,0,4'''+' as  类别3折扣, CONVERT(varchar,g.gi_id)+'+''',1,1,4'''+' as 类别3吊牌价, CONVERT(varchar,g.gi_id)+'+''',1,0,5'''+' as   类别4折扣,CONVERT(varchar,g.gi_id)+'+''',1,1,5'''+' 类别4吊牌价, CONVERT(varchar,g.gi_id)+'+''',1,0,6'''+' as   类别5折扣,CONVERT(varchar,g.gi_id)+'+''',1,1,6'''+' as 类别5吊牌价,CONVERT(varchar,g.gi_id)+'+''',1,0,7'''+' as   类别6折扣,CONVERT(varchar,g.gi_id)+'+''',1,1,7'''+' as  类别6吊牌价, CONVERT(varchar,g.gi_id)+'+''',1,0,8'''+' as   类别7折扣, CONVERT(varchar,g.gi_id)+'+''',1,1,8'''+' as  类别7吊牌价, CONVERT(varchar,g.gi_id)+'+''',1,0,9'''+' as   类别8折扣,CONVERT(varchar,g.gi_id)+'+''',1,1,9'''+'  类别8吊牌价,CONVERT(varchar,g.gi_id)+'+''',1,0,10'''+' as   类别9折扣, CONVERT(varchar,g.gi_id)+'+''',1,1,10'''+' as 类别9吊牌价,g.gi_add_man as 添加人,g.gi_add_time as 添加时间,g.gi_update_man as 修改人,g.gi_update_time as 修改时间, g.gi_entrydate as 入档时间, g.gi_remark as 备注,CASE WHEN g.gi_status =1 THEN '+'''正常'''+' ELSE '+'''异常'''+' end as 商品状态,g.si_img as 图片路径,case when g.gi_is_tb=1 then '+'''是'''+' else '+'''否'''+' end as 是否同步,g.gi_id,g.gi_norm,g.gi_attribute_parentids,g.gi_attribute_ids,g.gi_skuid FROM b_goodsinfo g where gi_status=1  order by g.gi_id desc'
--select @Sql
exec (@Sql)
go

