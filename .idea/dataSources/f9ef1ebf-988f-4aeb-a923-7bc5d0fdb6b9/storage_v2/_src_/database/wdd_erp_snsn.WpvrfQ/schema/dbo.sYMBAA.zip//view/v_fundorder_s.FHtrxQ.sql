

CREATE VIEW [dbo].[v_fundorder_s]
AS
SELECT 
	  (CASE WHEN fo_order_id>0 THEN (
         (CASE  WHEN fo_type=0 THEN
            (SELECT jos.oo_status FROM j_outStorage AS jos WHERE jos.oo_id=fo_order_id)
         ELSE
            jes.eo_status
         END)
       ) ELSE 1 END) as orderstatus,
       (select cp_name from companyinfo where cp_id=fo_cp_id)set_cpname,
       dbo.c_fundorder.fo_id,
       dbo.c_fundorder.fo_erp_id,
       dbo.c_fundorder.fo_type,
       dbo.c_fundorder.fo_ciid,
       dbo.c_fundorder.fo_bs,
       dbo.c_fundorder.fo_orderid,
       dbo.c_fundorder.fo_takeman,
       dbo.c_fundorder.fo_ticketno,
       dbo.c_fundorder.fo_realmoney,
       dbo.c_fundorder.fo_thiyetmoney,
       dbo.c_fundorder.fo_ofdate,
       dbo.c_fundorder.fo_remark,
       dbo.c_fundorder.fo_lastman,
       dbo.c_fundorder.fo_status,
       dbo.c_fundorder.fo_outmoney,
       dbo.c_fundorder.fo_admoney,
       dbo.c_fundorder.fo_otheronmoney,
       dbo.c_fundorder.fo_otheoutmoney,
       dbo.c_fundorder.fo_givemoney,
       dbo.c_fundorder.fo_ensuremoney,
       dbo.c_fundorder.fo_subscription,
       dbo.c_fundorder.fo_no,
       dbo.c_fundorder.fo_addtime,
       dbo.c_fundorder.fo_updatetime,
       dbo.c_fundorder.fo_rowNum,
       dbo.c_fundorder.fo_userorderno AS si_id,
       dbo.b_supplierinfo.si_name,
	   dbo.b_supplierinfo.si_code,
	   fo_qc_integral, fo_realmoney_integral, fo_thiyetmoney_integral, fo_outmoney_integral, fo_otheronmoney_integral,fo_otheoutmoney_integral, fo_givemoney_integral,c_fundorder.fo_qm_integral, 
       fo_cp_id,
        CASE WHEN fo_realmoney_integral=0
                AND fo_thiyetmoney_integral=0
                AND fo_outmoney_integral=0
                AND fo_otheronmoney_integral=0
                AND fo_otheoutmoney_integral=0
                AND fo_givemoney_integral=0
                THEN 1 ELSE 0 
                END AS integral_status,
                CASE WHEN fo_realmoney=0
                AND fo_thiyetmoney=0
                AND fo_outmoney=0
                AND fo_otheronmoney=0
                AND fo_otheoutmoney=0
                AND fo_givemoney=0
                AND fo_admoney=0
                AND fo_ensuremoney=0
                AND fo_subscription=0
                THEN 1 ELSE 0 
                END AS fun_status,
			   (case when fo_order_id >0 then (SELECT si_name FROM dbo.b_stafftinfo AS bs  WITH (NOLOCK) WHERE (si_id = jes.eo_addman)) else fo_addman end)as addman , --制单人
			   (case when fo_order_id >0 then eo_remark else fo_custom_remark end)as remark --自定义备注

				,(case when fo_outmoney >0 then -fo_finished_money else fo_finished_money end)fo_finished_money
				,(case when fo_outmoney >0 then -fo_parts_money else fo_parts_money end)fo_parts_money
				,fo_queue_status
	FROM   dbo.b_supplierinfo INNER JOIN dbo.c_fundorder
            ON  dbo.b_supplierinfo.si_id = dbo.c_fundorder.fo_ciid
			LEFT JOIN j_enterStorage AS jes WITH ( NOLOCK ) ON jes.eo_id =dbo.c_fundorder.fo_order_id 
			WHERE si_isdel=1
go

