CREATE TRIGGER [dbo].[Trigger_companyinfo_object] ON [dbo].[companyinfo]
    FOR DELETE, INSERT, UPDATE
    AS
BEGIN

    DECLARE @maxID int,  
			@inserted INT,
            @deleted INT, 
			@ChangeType NVARCHAR(20);
	SELECT  @inserted = COUNT(1) FROM Inserted;
    SELECT  @deleted = COUNT(1) FROM Deleted;

	--判断对表Table1的操作类型
	IF @inserted > 0 AND @deleted = 0
	BEGIN 
		SET @ChangeType = 'INSERT';
	END;
	ELSE IF @inserted > 0  AND @deleted > 0
	BEGIN 
		SET @ChangeType = 'UPDATE';
	END;
	ELSE IF @inserted = 0AND @deleted > 0
	BEGIN 
		SET @ChangeType = 'DELETE';
	END;

	IF @ChangeType = 'DELETE'
	BEGIN
		SELECT @maxID = cp_id FROM Deleted;
	end
	else
	begin
	    SELECT  @maxID = cp_id FROM Inserted;   
	end
	exec pro_objectlist_op @id=@maxID,@type=3;
 END
go

