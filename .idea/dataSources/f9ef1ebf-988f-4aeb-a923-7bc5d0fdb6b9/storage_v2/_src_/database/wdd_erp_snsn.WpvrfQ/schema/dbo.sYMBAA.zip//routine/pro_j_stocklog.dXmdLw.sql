
CREATE Proc [dbo].[pro_j_stocklog]
@s_time DATETIME='2015-5-1',
@sl_seiid INT=0
AS


select
CONVERT(VARCHAR(50), @s_time, 23)  as  s_time,
(select sei_name from b_storageinfo where sei_id=@sl_seiid) as sei_name,
(select gi_code from b_goodsinfo where gi_id=sl_giid) code,
isnull((select gd_name from s_goodsruledetail where gd_id=color),'') as color,
ISNULL((select tmpnum from dbo.v_z_goodsruledetail_tmp where gd_id=size),'') as size,
stock_num
from (
select 
*
from(
SELECT js.sl_giid,js.sl_skuid,
SUM(CASE WHEN js.sl_counttype = 1 THEN js.sl_number ELSE -js.sl_number
END
) AS stock_num
FROM   j_stocklog AS js
WHERE  js.sl_seiid = @sl_seiid AND ((

CONVERT(VARCHAR(50), js.sl_order_date, 23) <= @s_time
)
OR js.sl_type = 3
)
 AND js.sl_status != 0
GROUP BY
js.sl_giid,
js.sl_skuid
 ) 
 as stgs left join dbo.v_z_goodsruleset_of gof on stgs.sl_skuid=gof.gss_id)
 as log_stock
where (sl_skuid=0 and gss_id is null ) or (sl_skuid>0 and gss_id is not null)


go

