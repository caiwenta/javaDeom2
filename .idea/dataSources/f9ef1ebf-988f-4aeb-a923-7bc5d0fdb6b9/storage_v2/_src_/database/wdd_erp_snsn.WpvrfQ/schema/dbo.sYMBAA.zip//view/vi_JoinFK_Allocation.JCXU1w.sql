


CREATE VIEW [dbo].[vi_JoinFK_Allocation] AS 
SELECT
	*, OutNum_do = PHNum - ISNULL(fd.OutNum, 0) - ISNULL(all_pause_num, 0)
FROM
	(
		SELECT
		    al_review,
			al_vo,
			al_no,
			CONVERT (VARCHAR(10), al_date, 120) AS al_date,
			al_type,
			al_trans,
			al_freight_no,
			al_fright,
			al_source,
			al_add_time,
			al_update_time,
			al_audit_time,
			al_status,
			al_id,
			al_source_id,
			al_cp_id,
			al_di_id,
			al_totalboxnum,
			al_remark,
			( SELECT ci_name FROM dbo.b_clientinfo AS bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ) AS al_ci_id_txt,
			al_ci_id,
			( SELECT ci_code FROM dbo.b_clientinfo AS bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ) AS al_ci_code_txt,
			( SELECT ci_province FROM dbo.b_clientinfo AS bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ) AS ci_province,
			( SELECT ci_city FROM dbo.b_clientinfo AS bs  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ) AS ci_city,
			( SELECT sh_name FROM dbo.pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ) AS al_sh_id_txt,
			al_sh_id,
			( SELECT province FROM dbo.pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ) AS sh_province,
			( SELECT city FROM dbo.pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ) AS sh_city,
			( SELECT cp_name FROM companyinfo AS bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id ) AS al_to_cp_id_txt,
			al.al_to_cp_id,
			( SELECT sei_name FROM dbo.b_storageinfo AS bs  WITH (NOLOCK) WHERE sei_id = al.al_st_id ) AS al_st_id_txt,
			( SELECT cp_province FROM companyinfo AS bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id ) AS cp_province,
			( SELECT cp_city FROM companyinfo AS bs  WITH (NOLOCK) WHERE bs.cp_id = al.al_to_cp_id ) AS cp_city,
			al_st_id,
			( SELECT si_name FROM dbo.b_stafftinfo AS bs  WITH (NOLOCK) WHERE si_id = al.al_order_man ) AS al_order_man_txt,
			al_order_man,
			( SELECT si_name FROM dbo.b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_add_man ) AS al_add_man_txt,
			al_add_man,
			( SELECT si_name FROM dbo.b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_update_man ) AS al_update_man_txt,
			al_update_man,
			( SELECT si_name FROM dbo.b_stafftinfo  WITH (NOLOCK) WHERE si_id = al.al_audit_man ) AS al_audit_man_txt,
			al_audit_man,
			CASE al.al_source
		WHEN 1 THEN
			( SELECT og_no FROM dbo.pos_ogStorage AS bs  WITH (NOLOCK) WHERE og_id = al.al_source_id )
		WHEN 2 THEN
			( SELECT re_no FROM dbo.pos_reStorage AS bs  WITH (NOLOCK) WHERE re_id = al.al_source_id )
		WHEN 3 THEN
			( SELECT in_no FROM dbo.pos_inStorage AS bs  WITH (NOLOCK) WHERE in_id = al.al_source_id )
		WHEN 5 THEN
			( SELECT og_no FROM dbo.pos_ogStorage AS bs  WITH (NOLOCK) WHERE og_id = al.al_source_id )
		END AS al_source_id_txt,
		--来源凭证号
		CASE al_source
	WHEN 2 THEN
		( SELECT re_vo FROM dbo.pos_reStorage AS bs  WITH (NOLOCK) WHERE re_id = al.al_source_id )
	WHEN 3 THEN
		( SELECT in_vo FROM dbo.pos_inStorage AS bs  WITH (NOLOCK) WHERE in_id = al.al_source_id )
	WHEN 5 THEN
		( SELECT og_vo FROM dbo.pos_ogStorage AS bs  WITH (NOLOCK) WHERE og_id = al.al_source_id )
    WHEN 6 THEN
		( SELECT re_vo FROM dbo.pos_reStorage AS bs  WITH (NOLOCK) WHERE re_id = al.al_source_id )
	WHEN 7 THEN
		( SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id where eio.io_id = al.al_source_id )
	END AS al_source_vo,
	--出库数量
	--( SELECT SUM (ol_number) FROM j_outStorage_allout  WITH (NOLOCK) WHERE oo_source_type = 1 AND oo_source_id = al.al_id ) AS OutNum,
	( SELECT SUM (oo_num) FROM j_outStorage  WITH (NOLOCK) WHERE oo_source_type = 1 AND oo_source_id = al.al_id AND oo_status > 0  ) AS OutNum,
	--出库状态
	( SELECT MAX (oo_status) FROM j_outStorage  WITH (NOLOCK) WHERE oo_source_type = 1 AND oo_source_id = al.al_id AND oo_status > 0 ) AS oo_status,
	--配货数量
	( SELECT SUM (all_num) FROM pos_allocationList  WITH (NOLOCK) WHERE all_al_id = al.al_id AND all_status > 0 ) AS PHNum,
	--配货数量
	( SELECT SUM (all_pause_num) FROM pos_allocationList  WITH (NOLOCK) WHERE all_al_id = al.al_id AND all_status > 0 ) AS all_pause_num,
	--配货金额
	( SELECT SUM (all_money) FROM pos_allocationList  WITH (NOLOCK) WHERE all_al_id = al.al_id AND all_status > 0 ) AS PHmoney,
	( SELECT ci_attribute_ids FROM b_clientinfo  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ) AS ci_attribute_ids,
	( SELECT ci_attribute_parentids FROM b_clientinfo  WITH (NOLOCK) WHERE ci_id = al.al_ci_id ) AS ci_attribute_parentids,
	( SELECT sh_attribute_ids FROM dbo.pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ) AS sh_attribute_ids,
	( SELECT sh_attribute_parentids FROM dbo.pos_shop AS bs  WITH (NOLOCK) WHERE sh_id = al.al_sh_id ) AS sh_attribute_parentids
FROM pos_allocation AS al  WITH (NOLOCK) 
) AS fd
go

