CREATE VIEW [dbo].[vi_j_plStorage_Search_new]
	AS
SELECT
ppl_gi_id AS gi_id,
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
locationlist.*
from 
(	
	
   
select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,

ln.* 
from
(	
	

	 SELECT
	 isnull((ppl_retail_price*ppl_num),0)ppl_zero_money,--零售金额
	pl_id,pl_vo,pl_no,CONVERT(varchar(10),isnull(pl_date,''),12) as pl_date ,gi_code,gi_barcode,gi_name,gi_unit,ppl_stock_num,ppl_retail_price
	,ppl_stock_price,ppl_pm,0 as ppl_pm_sum,ppl_box_num,ppl_num,ppl_money,ppl_add_time,
	pl_order_man_txt,pl_st_id_txt,pl_st_id,pl_add_man_txt,pl_add_time,pl_update_man_txt,pl_update_time
	,pl_audit_man_txt,pl_audit_time,pl_remark,pl_status,pl_cp_id,ppl_gi_id
	,ppl_sku_id,(case when gi_skus='' THEN 0 ELSE 1 END )AS  gi_skus,
	gi_attribute_ids,
	gi_attribute_parentids,
	gi_types,
	gi_typesid,
	gi_skuid  --规格组编号
FROM
	vi_j_plStorageList_group_goods AS el
LEFT JOIN vi_j_plStorage AS eo ON el.ppl_pl_id = eo.pl_id
AND eo.pl_status > 0

 UNION ALL
	 
SELECT 
	 isnull((gi_retailprice*Sum(jj.sl_number)),0)ppl_zero_money,--零售金额
	jj.ts_id,
	 jj.ts_vo,
	jj.ts_no,
	 CONVERT(varchar(10),jj.ts_take_date,120) as ts_take_date ,
	 jj.gi_code,
jj.gi_barcode,
jj.gi_name,
jj.gi_unit_name,
 Sum(jj.sl_number) As si_number,
 jj.gi_retailprice,
cast(avg(jj.gs_purchase) as decimal(15,2)),
jj.sl_pm,
 0,
 0,
 Sum(jj.sl_number) As si_number,
SUM(jj.menoy),
 jj.ts_add_time,
'',
(select sei_name from b_storageinfo WHERE  jj.sl_seiid =sei_id),
jj.sl_seiid,
(SELECT si_name from b_stafftinfo WHERE si_id = jj.ts_add_man),
jj.ts_add_time,
 (SELECT si_name from b_stafftinfo WHERE si_id = jj.ts_update_man),
jj.ts_update_time,
  (SELECT si_name from b_stafftinfo WHERE si_id = jj.ts_audit_man),
  jj.ts_audit_time,
  '',
 jj.ts_status,
jj.sl_cp_id,jj.sl_giid,
sum(jj.sl_skuid),
SUM(gi_skus),
max(gi_attribute_ids),
max(gi_attribute_parentids),
MAX(gi_types),
max(gi_typesid),
max(gi_skuid)  --规格组编号
	  FROM	 
	  (
	  	SELECT
--jt.tsl_id as ts_id,
(SELECT TOP 1 ts_id FROM dbo.j_takeStorage WHERE ts_st_id=jt.tsl_st_id AND ts_vo=js.sl_order_no) as ts_id,
js.sl_order_no as ts_vo,
'' ts_no,
jt.tsl_date as ts_take_date,
gi_skuid,  --规格组编号
gi_code,
gi_barcode,
gi_name,
gi_unit_name,
(Case when sl_counttype=1 Then sl_number Else -sl_number End) As sl_number,
sl_skuid,
js.sl_pm,
jt.tsl_update_time as ts_update_time,
jt.tsl_update_man as ts_audit_time,
jt.tsl_status as ts_status,
js.sl_cp_id,
js.sl_seiid,
jt.tsl_add_man as ts_add_man,
jt.tsl_update_man as ts_update_man,
jt.tsl_update_man as ts_audit_man,
sl_counttype,sl_giid,
bg.gi_retailprice,
bg.gi_importprices,
jt.tsl_add_time as ts_add_time,
(CASE WHEN sl_skuid=0 THEN gi_purchase ELSE gs_purchase END ) AS  gs_purchase,
 (CASE WHEN sl_skuid=0 THEN(gi_purchase* (Case when sl_counttype=1 Then sl_number Else -sl_number End)) ELSE (gs_purchase* (Case when sl_counttype=1 Then sl_number Else -sl_number End))END ) as menoy ,
 (CASE WHEN  gi_skus='' THEN 0 ELSE 1 END ) AS   gi_skus,gi_attribute_ids,
gi_attribute_parentids,gi_types,gi_typesid
 FROM  j_stocklog AS js
LEFT JOIN j_takeStorageLog jt  ON js.sl_elid=jt.tsl_id AND js.sl_eoid=jt.tsl_id AND jt.tsl_status<>0
LEFT JOIN b_goodsinfo AS bg ON sl_giid=bg.gi_id
LEFT JOIN b_goodsruleset AS bg2 ON bg2.gss_id=sl_skuid
WHERE (sl_type=7 OR sl_type=8 OR sl_type=9 OR sl_type=10) AND sl_number!=0
) AS jj 
	 GROUP BY
	 jj.ts_id,
	jj.ts_vo,
	 jj.ts_no,
	 jj.ts_take_date,
	 jj.gi_code,
jj.gi_barcode,
jj.gi_name,
jj.gi_types,
jj.gi_retailprice,
 jj.gi_importprices,
 jj.ts_add_time,
   jj.ts_update_time,
    jj.ts_audit_time,
     jj.ts_status,
jj.sl_cp_id,
jj.sl_seiid,
jj.ts_add_man,
jj.ts_update_man,
jj.ts_audit_man,
jj.gi_unit_name,jj.sl_giid ,jj.sl_pm



) as ln
left join b_goodsruleset  as grl on  grl.gss_id=ln.ppl_sku_id

) as locationlist
left join s_goodsruledetail rulenum on gd_id=locationlist.size
go

