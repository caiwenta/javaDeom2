CREATE FUNCTION [dbo].[FnCheckGoodInfo]
(
	  @op_type VARCHAR(50) ,
       @id INT
)
RETURNS varchar(100)
AS
BEGIN

     DECLARE @result VARCHAR(100) = '';
	   --返回1则表示可以删除
     SET @result = '1';

	 IF @op_type = '商品'
          BEGIN
                IF EXISTS ( SELECT  1
                            FROM    j_purchaseStorage fd
                            WHERE   pl_id IN ( SELECT   pll_pl_id
                                               FROM     j_purchaseStorageList fd
                                               WHERE    fd.pll_gi_id = @id
                                                        AND fd.pll_status > 0 )
                                    AND pl_status > 0 )
                   SET @result = '已被采购引用,不可删除!';
                ELSE
                   IF EXISTS ( SELECT   1
                               FROM     j_enterStorage
                               WHERE    eo_id IN ( SELECT   fd.el_eoid
                                                   FROM     j_enterStorageList fd
                                                   WHERE    fd.el_siid = @id
                                                            AND fd.el_status > 0 )
                                        AND eo_status > 0 )
                      SET @result = '已被入库引用,不可删除!';
                   ELSE
                      IF EXISTS ( SELECT    1
                                  FROM      j_outStorage
                                  WHERE     oo_id IN ( SELECT   fd.ol_eoid
                                                       FROM     j_outStorageList fd
                                                       WHERE    fd.ol_siid = @id
                                                                AND fd.ol_status > 0 )
                                            AND oo_status > 0 )
                         SET @result = '已被出库引用,不可删除!';
                      ELSE
                         IF EXISTS ( SELECT 1
                                     FROM   j_moStorage
                                     WHERE  mo_id IN ( SELECT   fd.mol_mo_id
                                                       FROM     j_moStorageList fd
                                                       WHERE    fd.mol_gi_id = @id
                                                                AND fd.mol_status > 0 )
                                            AND mo_status > 0 )
                            SET @result = '已被移仓引用,不可删除!';
                         ELSE
                            IF EXISTS ( SELECT  1
                                        FROM    j_plStorage
                                        WHERE   pl_id IN ( SELECT   fd.ppl_pl_id
                                                           FROM     j_plStorageList fd
                                                           WHERE    fd.ppl_gi_id = @id
                                                                    AND fd.ppl_status > 0 )
                                                AND pl_status > 0 )
                               SET @result = '已被盈亏引用,不可删除!';
                            ELSE
                               IF EXISTS ( SELECT   1
                                           FROM     j_takeStorage
                                           WHERE    ts_id IN ( SELECT   fd.tsl_ts_id
                                                               FROM     j_takeStorageList fd
                                                               WHERE    fd.tsl_gi_id = @id
                                                                        AND fd.tsl_status > 0 )
                                                    AND ts_status > 0 )
                                  SET @result = '已被盘点引用,不可删除!';
                               ELSE
                                  IF EXISTS ( SELECT    1
                                              FROM      pos_allocation
                                              WHERE     al_id IN ( SELECT   fd.all_al_id
                                                                   FROM     pos_allocationList fd
                                                                   WHERE    fd.all_gi_id = @id
                                                                            AND fd.all_status > 0 )
                                                        AND al_status > 0 )
                                     SET @result = '已被配货引用,不可删除!';
                                  ELSE
                                     IF EXISTS ( SELECT 1
                                                 FROM   pos_ogStorageList fd
                                                 INNER JOIN pos_ogStorage fs
                                                        ON fd.ogl_og_id = fs.og_id
                                                 WHERE  fd.ogl_gi_id = @id
                                                        AND fs.og_status > 0
                                                        AND fd.ogl_status > 0 )
                                        SET @result = '已被订单引用,不可删除!';
                                     ELSE
                                        IF EXISTS ( SELECT  1
                                                    FROM    pos_reStorage fd
                                                    INNER JOIN pos_reStoragelist fs
                                                            ON fd.re_id = fs.rel_re_id
                                                    WHERE   fs.rel_gi_id = @id
                                                            AND fs.rel_status > 0
                                                            AND fd.re_status > 0 )
                                           SET @result = '已被补货引用,不可删除!';
                                        ELSE
                                           IF EXISTS ( SELECT   1
                                                       FROM     pos_activeGoods fd
                                                       INNER JOIN pos_active pa
                                                                ON fd.ac_ac_id = pa.ac_id
                                                       WHERE    fd.ac_gi_id = @id
                                                                AND fd.ac_status > 0
                                                                AND pa.ac_status > 0 )
                                              SET @result = '已被设为活动商品,不可删除!';
                                           ELSE
                                              IF EXISTS ( SELECT    1
                                                          FROM      pos_activeGift fd
                                                          INNER JOIN pos_active pa
                                                                    ON fd.ac_ac_id = pa.ac_id
                                                          WHERE     fd.ac_gi_id = @id
                                                                    AND fd.ac_status > 0
                                                                    AND pa.ac_status > 0 )
                                                 SET @result = '已被设为活动商品,不可删除!';
                                              ELSE
                                                 IF EXISTS ( SELECT 1
                                                             FROM   pos_customPrice fd
                                                             INNER JOIN pos_customPriceList fs
                                                                    ON fd.cp_id = fs.cpl_cp_id
                                                             WHERE  fs.cpl_gi_id = @id
                                                                    AND fd.cp_status > 0 )
                                                    SET @result = '已被总部调整价格,不可删除!';
                                                 ELSE
                                                    IF ( SELECT COUNT (1) AS count FROM vi_stockList fd WITH (NOLOCK) WHERE fd.gid= @id
                                                       ) > 0
                                                       SET @result = '已产生总部库存,不可删除!';
                                                    ELSE
                                                       IF ( SELECT COUNT (1) AS count FROM vi_pos_stockList fd WITH (NOLOCK) WHERE fd.gid= @id
                                                          ) > 0
                                                          SET @result = '已产生店铺库存,不可删除!';
                                                       ELSE
                                                          IF ( SELECT   COUNT(1) AS count
                                                               FROM     j_takeStorageList jtsl
                                                               INNER JOIN j_takeStorage jts
                                                                        ON jtsl.tsl_ts_id = jts.ts_id
                                                               WHERE    jts.ts_status != 0
                                                                        AND jtsl.tsl_status > 0
                                                                        AND jtsl.tsl_gi_id = @id
                                                             ) > 0
                                                             SET @result = '已被总部盘点引用,不可删除!';
                                                          ELSE
                                                             IF ( SELECT    COUNT(1) AS COUNT
                                                                  FROM      pos_takeStorageList ptsl
                                                                  INNER JOIN pos_takeStorage pts
                                                                            ON ptsl.tsl_ts_id = pts.ts_id
                                                                  WHERE     pts.ts_status != 0
                                                                            AND ptsl.tsl_status > 0
                                                                            AND ptsl.tsl_gi_id = @id
                                                                ) > 0
                                                                SET @result = '已被店铺盘点引用,不可删除!';
          END


	 RETURN @result;
END
go

