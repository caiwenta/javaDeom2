
CREATE TRIGGER [dbo].[Trigger_erp_distributionorderlist_after_update_insert]
    ON [dbo].[erp_distributionorderlist]
    FOR DELETE, INSERT, UPDATE
    AS
    BEGIN
         UPDATE    erp_distributionorderlist
      SET       dol_lastdate =GETDATE()
      FROM      erp_distributionorderlist es ,
                (SELECT dol_id 
                 FROM   DELETED
                ) del
      WHERE     es.dol_id = del.dol_id;
    END
go

