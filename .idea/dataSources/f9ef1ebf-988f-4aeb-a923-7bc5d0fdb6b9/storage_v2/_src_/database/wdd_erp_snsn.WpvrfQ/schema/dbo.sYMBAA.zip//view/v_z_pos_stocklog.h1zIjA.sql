CREATE VIEW [dbo].[v_z_pos_stocklog]
	AS 



select 

'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
rulenum.gd_code as sizecode,--尺码代号
purchaselist.*
from 
(
select 
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=isnull(grl.colorid,0))as colorcode,--颜色代号
isnull(grl.gss_no,'') as gss_no,--规格编码
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
purchase.* 
from
(	
 
SELECT            
st.*,
       convert(varchar(50),st.order_date,23) AS addtime, 
       in_source= (CASE WHEN st.sl_type=1 THEN (SELECT in_source 
                                                FROM pos_inStorage AS ps 
                                                WHERE  ps.in_status=2 and ps.in_id=st.sl_eoid) 
                        WHEN st.sl_type=6 THEN  -1  ELSE ''  END), 
       ord_no= (CASE WHEN st.sl_type=1 THEN (SELECT ord_no 
                                             FROM pos_inStorage AS ps 
                                             WHERE  ps.in_status=2 AND  ps.in_remark='网络订单' and ps.in_id=st.sl_eoid) 
                     WHEN st.sl_type=5 THEN  (SELECT pas.ord_sn 
                                              FROM pos_alStorage pas 
                                              WHERE pas.al_id=st.sl_eoid)  ELSE ''  END) 
FROM ( SELECT js.*, 
              bps.sh_name,
  
              bs.sei_name,
              bg.gi_name, 
              bg.gi_code, 
              bg.gi_types, 
              bg.gi_type1, 
              bg.gi_type2, 
              bg.gi_type3, 
              bg.gi_type4, 
             (select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi_type1)gi_typename1,
             (select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi_type2)gi_typename2,
             (select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi_type3)gi_typename3,
             (select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi_type4)gi_typename4,
              bg.gi_barcode 
              
       FROM ( SELECT
                     sh_erp_id,
 
                     js.sl_eoid , 
                     js.sl_order_no AS orderno,  
                     js.sl_shop_id AS shid, 
                     js.sl_seiid, 
                     js.sl_giid AS gi_id, 
                     js.sl_skuid,
                     js.sl_type, 
                     js.sl_remark AS myremark, 
                     convert(varchar(50),max(js.sl_order_date),23) AS order_date, 
                     js.sl_pm AS pm, 
                     MAX(CASE WHEN sl_skuid=0 THEN '' ELSE '1' END ) AS gi_skus, 
                     max(js.sl_order_add_time) AS order_add_time, 
                     SUM(CASE WHEN sl_countType=1 THEN sl_number ELSE-sl_number END) AS gnum, 
                     (CASE sl_type WHEN 1 THEN (SELECT in_supplier_sh_id_txt 
                                                FROM vi_pos_inStorage 
                                                WHERE in_id=sl_eoid) 
                                   WHEN 5 THEN (SELECT al_get_sh_id_txt 
                                                FROM vi_j_Pos_AlStorage 
                                                WHERE al_id=sl_eoid) ELSE '其它' END ) AS sup 
              FROM pos_stocklog AS js 
              left join pos_shop 
              on sl_shop_id=sh_id 
              WHERE js.sl_status<>0 
              Group BY  sh_erp_id,js.sl_eoid ,js.sl_order_no,js.sl_seiid,js.sl_giid,js.sl_shop_id,js.sl_type,js.sl_remark,js.sl_pm,sl_skuid ) AS js 
       INNER JOIN pos_storageinfo AS bs 
       ON  js.sl_seiid = bs.sei_id  
       INNER JOIN dbo.b_goodsinfo AS bg  
       ON  js.gi_id = bg.gi_id  
       INNER JOIN pos_shop AS bps
       ON   js.shid  =bps.sh_id) AS st

) as  purchase
left join b_goodsruleset  as grl on  grl.gss_id=purchase.sl_skuid

) as purchaselist
left join s_goodsruledetail rulenum on gd_id=purchaselist.size
go

