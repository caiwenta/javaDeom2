CREATE FUNCTION [dbo].[FnCheckStockinfolocation]
(
	@si_seiid int,
	@si_location INT,
	@erp_id INT
)
RETURNS INT
AS
BEGIN
	--用途：验证库存si_seiid与si_location是否匹配
    DECLARE @re INT;
    
   IF EXISTS ( SELECT  1 FROM  dbo.erp_storagelocation WHERE slt_id = @si_location AND sei_id = @si_seiid AND erp_id=@erp_id )
     SET @re = 1;
    ELSE
     SET @re = 0;
    
    RETURN @re;
END
go

