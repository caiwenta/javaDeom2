

CREATE View [dbo].[vi_sample]
as


select 
top 1000 * 
from 
(
select 
*,
zong_xiang_txt=
dbo.Get_StrArrayStrOfIndex(
dbo.Get_StrArrayStrOfIndex(gs_name, '|', 
case when fd.gs_is_custom=fd.first_gs_id then 2 else 1 end
),':',2),
zong_xiang_id=
dbo.Get_StrArrayStrOfIndex(
dbo.Get_StrArrayStrOfIndex(gs_id, '/', 
case when fd.gs_is_custom=fd.first_gs_id then 2 else 1 end
),'-',1),
heng_xiang_txt=dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_name, '|', 
case when fd.gs_is_custom=fd.first_gs_id then 1 else 2 end
),':',2),
heng_xiang_id=dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 
case when fd.gs_is_custom=fd.first_gs_id then 1 else 2 end
),'-',2)
from (
select 
bg2.gi_id,je.el_addtime,
bg2.gi_code,
bg2.gi_name,
replace(je.el_pm,'*',',') as el_pm,
je.el_costprice,
je.el_realmoney,
je.el_remark,
je.el_number,
bs.sei_name,
jes.eo_no,
jes.eo_entrydate,
bs2.si_name,
je.el_box_num,
bg.gs_id,
bg.gs_name,
bg.gs_is_custom,
first_gs_id=dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',1),'-',1),
second_gs_id=dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg.gs_id,'/',2),'-',1)
from j_enterStorageList as je
inner join b_goodsruleset as bg on je.el_skuid=bg.gss_id
inner join b_goodsinfo as bg2 on je.el_siid=bg2.gi_id
inner join j_enterStorage as jes on je.el_eoid=jes.eo_id
inner join b_storageinfo as bs on jes.eo_siid=bs.sei_id
left join b_stafftinfo as bs2 on jes.eo_takemanid=bs2.si_id
where je.el_eoid=207
) as fd	
) as fd
order by fd.gi_id,fd.el_addtime,fd.zong_xiang_txt


go

