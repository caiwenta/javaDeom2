
CREATE Proc [dbo].[pro_get_report_data]
@op_type VARCHAR(50)='入库单',
@id INT=0
AS


IF @op_type='出库单一维'
BEGIN

SELECT 

ROW_NUMBER() OVER (ORDER BY josl.ol_id DESC,bg.gi_code) AS '序号',
bg.gi_unit_name AS '单位',  
'出库单单据标题'=case when oo_type=1 then '商品出库' 

ELSE '出库退货' end,

jos.oo_remark AS '备注', 
bg.gi_code AS '商品编号',
bg.gi_name AS '商品名称'
,
(case when josl.ol_skuid>0 then bg2.gss_no else bg.gi_barcode end) AS '条形码'
,bg2.gs_name AS '颜色'
,josl.ol_costprice AS '进货价'
,josl.ol_unit AS '零售价'
 ,case when oo_type=1 then josl.ol_number ELSE -josl.ol_number END AS '数量'
 ,josl.ol_realmoney AS '进货金额',
 (josl.ol_unit * ol_number)AS '零售金额'
 ,bs.sei_name AS '仓库',jos.oo_no as '凭证号',
 (CASE WHEN josl.ol_skuid!=0 THEN bg2.gss_no ELSE bg.gi_barcode END) AS '规格条形码'
 ,CONVERT(VARCHAR(50),jos.oo_entrydate,23) AS '单据日期',
 '添加人'=(SELECT bs3.si_name FROM b_stafftinfo bs3 WHERE bs3.si_id=jos.oo_addman ) ,
  '经手人'=jos.takeman
 ,'收货单位'= CASE WHEN jos.oo_ciid>0 THEN (SELECT bc.ci_name
                                 FROM b_clientinfo bc WHERE bc.ci_id=jos.oo_ciid)
WHEN jos.oo_sh_id>0 THEN (
SELECT ps.sh_name FROM pos_shop ps WHERE ps.sh_id=jos.oo_sh_id	
)   
WHEN jos.oo_to_cp_id>0 THEN
	(
	SELECT c.cp_name FROM companyinfo c WHERE c.cp_id=jos.oo_to_cp_id	
	)         
 END
 ,
'审核人'=(SELECT bs3.si_name FROM b_stafftinfo bs3 WHERE bs3.si_id=jos.oo_lastmanid ) 
  FROM j_outStorage jos 
  INNER JOIN j_outStorageList josl
   ON jos.oo_id=josl.ol_eoid
   
   INNER JOIN b_storageinfo bs ON jos.oo_siid=bs.sei_id
   LEFT JOIN b_stafftinfo bs2 ON jos.oo_addman=bs2.si_id
INNER JOIN b_goodsinfo bg ON josl.ol_siid=bg.gi_id
LEFT JOIN b_goodsruleset bg2 ON josl.ol_skuid=bg2.gss_id WHERE jos.oo_id=@id AND josl.ol_status>0

RETURN;
END	

if  @op_type='出库单二维'
begin

select '1'



end

IF @op_type='出库单'
BEGIN
	
--得到横向规格详细信息
SELECT fd.* INTO #chu_ku_fd FROM s_goodsruledetail fd 
INNER JOIN 
(
--得到横向规格明细集合
SELECT DISTINCT fd.gs_is_custom FROM b_goodsruleset fd 
INNER JOIN 
(
--得到单据明细的商品集合	
SELECT DISTINCT fd.ol_siid FROM j_outStorageList fd WHERE fd.ol_eoid=@id
) fd2 ON fd.gi_id=fd2.ol_siid
) AS fd2 ON fd.gs_id=fd2.gs_is_custom

--得到最大横向列数量
SELECT MAX(fd.count) AS max_count FROM (
SELECT fd.gs_id,COUNT(1) as count FROM #chu_ku_fd fd
GROUP BY fd.gs_id
) AS fd 

SELECT * FROM (
SELECT  fd.*,fd2.count FROM #chu_ku_fd fd INNER JOIN (
--统计横向规格数量
SELECT fd.gs_id,COUNT(1) as count FROM #chu_ku_fd fd
GROUP BY fd.gs_id
) fd2 ON fd.gs_id=fd2.gs_id
) AS fd ORDER BY fd.count,fd.gd_id

DROP TABLE #chu_ku_fd


--返回单据信息
SELECT fd.*,fd2.sei_name,bs2.si_name
,bs3.si_name AS si_audit_man
,'收货单位'
 =
 CASE WHEN fd.oo_ciid>0 THEN (SELECT bc.ci_name
                                 FROM b_clientinfo bc WHERE bc.ci_id=fd.oo_ciid)
WHEN fd.oo_sh_id>0 THEN (
SELECT ps.sh_name FROM pos_shop ps WHERE ps.sh_id=fd.oo_sh_id	
)   
WHEN fd.oo_to_cp_id>0 THEN
	(
	SELECT c.cp_name FROM companyinfo c WHERE c.cp_id=fd.oo_to_cp_id	
	)         
         END  


 FROM j_outStorage fd 
inner join b_storageinfo as fd2 on fd.oo_siid=fd2.sei_id
 LEFT JOIN b_stafftinfo bs2 ON fd.oo_addman=bs2.si_id
 LEFT JOIN b_stafftinfo bs3 ON fd.oo_lastmanid=bs3.si_id
WHERE fd.oo_id=@id 


--返回单据明细
SELECT * INTO #ol_list FROM (
SELECT 
*
,order_int=CASE WHEN fd.first_id=fd.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 2), '-', 2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 1), '-', 2) 
         END FROM (
SELECT fd.*,fd2.*,fd3.gi_name,fd3.gi_code,CONVERT(VARCHAR(55),fd.ol_addtime,21) AS ol_addtime_str 
,first_id=
dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 1), '-', 1)
,second_id=
dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 2), '-', 1)
FROM j_outStorageList fd 
LEFT JOIN b_goodsruleset fd2 ON fd.ol_skuid=fd2.gss_id
INNER JOIN b_goodsinfo fd3 ON fd.ol_siid=fd3.gi_id
WHERE fd.ol_eoid=@id AND fd.ol_status>0
) AS fd
) AS fd
ORDER BY fd.ol_addtime DESC ,fd.order_int 
DECLARE @oo_type INT=0;
SELECT @oo_type=fd.oo_type FROM j_outStorage fd  WHERE fd.oo_id=@id
UPDATE #ol_list SET ol_number =case when @oo_type=1 then ol_number ELSE -ol_number END

SELECT * FROM #ol_list;

SELECT * FROM s_goodsruledetail sg WHERE sg.gs_id IN(
SELECT sg.gs_id FROM s_goodsrule sg WHERE sg.gs_remark='颜色'
AND sg.gs_status=1
)


END

IF @op_type='入库单'
BEGIN

SELECT 
ROW_NUMBER()over(ORDER BY [商品标题] desc)
AS '序号',
 * FROM (
SELECT 
bs.si_name AS '供应商',
fd.eo_no AS '凭证号',
bs2.sei_name AS '仓库',
CONVERT(VARCHAR(50),fd.eo_entrydate,23) AS '入库时间',
bg.gi_name AS '商品标题',
bg.gi_code AS '商品编码',
bu.ut_name AS '单位',
SUM(

CASE WHEN fd.eo_type=0 THEN fd2.el_number ELSE -fd2.el_number END

) AS '数量',

'单据标题'=case when fd.eo_type=0 then '入库单' else
 '入库退货单' end
 
,

AVG(fd2.el_costprice) AS '购买时进货价',
AVG(bg.gi_purchase) AS '进货价',
AVG(fd2.el_integral) AS '入库积分',
SUM(fd2.el_totalintegral) AS '总积分',
SUM(fd2.el_costprice*fd2.el_number) AS '商品金额',

AVG(bg.gi_factoryprice) AS '买易送现金',
SUM(bg.gi_factoryprice*fd2.el_number) AS '买易送合计现金',

fd.eo_remark AS '备注'
FROM j_enterStorage fd 
INNER JOIN 
j_enterStorageList fd2 ON fd.eo_id=fd2.el_eoid 
INNER JOIN b_goodsinfo bg ON fd2.el_siid=bg.gi_id
INNER JOIN b_unit bu ON bg.gi_unit=bu.ut_id
INNER JOIN b_supplierinfo bs ON fd.eo_ciid=bs.si_id
INNER JOIN b_storageinfo bs2 ON fd.eo_siid=bs2.sei_id
AND fd2.el_status>0
WHERE fd.eo_id=@id
GROUP BY eo_entrydate,gi_name,ut_name,eo_remark,si_name,eo_no,sei_name,bg.gi_code,fd.eo_type
) AS fd
RETURN;	

END

IF @op_type='入库单'
BEGIN
	
IF 1=1
BEGIN

--得到横向规格详细信息
SELECT fd.* INTO #ru_ku_fd FROM s_goodsruledetail fd 
INNER JOIN 
(
--得到横向规格明细集合
SELECT DISTINCT fd.gs_is_custom FROM b_goodsruleset fd 
INNER JOIN 
(
--得到单据明细的商品集合	
SELECT DISTINCT fd.el_siid FROM j_enterStorageList fd WHERE fd.el_eoid=@id
) fd2 ON fd.gi_id=fd2.el_siid
) AS fd2 ON fd.gs_id=fd2.gs_is_custom

--得到最大横向列数量
SELECT MAX(fd.count) AS max_count FROM (
SELECT fd.gs_id,COUNT(1) as count FROM #ru_ku_fd fd
GROUP BY fd.gs_id
) AS fd 

SELECT * FROM (
SELECT  fd.*,fd2.count FROM #ru_ku_fd fd INNER JOIN (
--统计横向规格数量
SELECT fd.gs_id,COUNT(1) as count FROM #ru_ku_fd fd
GROUP BY fd.gs_id
) fd2 ON fd.gs_id=fd2.gs_id
) AS fd ORDER BY fd.count,fd.gd_id

DROP TABLE #ru_ku_fd


--返回单据信息
SELECT fd.*,fd2.sei_name FROM j_enterStorage fd 
inner join b_storageinfo as fd2 on fd.eo_siid=fd2.sei_id
WHERE fd.eo_id=@id



--返回单据明细
SELECT * FROM (
SELECT *,order_int=CASE WHEN fd.first_id=fd.gs_is_custom THEN dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 2), '-', 2) ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 1), '-', 2) 
         END FROM (
SELECT fd.*,fd2.*,fd3.gi_name,fd3.gi_code,CONVERT(VARCHAR(55),fd.el_addtime,21) AS el_addtime_str 
,first_id=
dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 1), '-', 1)
,second_id=
dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id, '/', 2), '-', 1)
FROM j_enterStorageList fd 
INNER JOIN b_goodsruleset fd2 ON fd.el_skuid=fd2.gss_id
INNER JOIN b_goodsinfo fd3 ON fd.el_siid=fd3.gi_id
WHERE fd.el_eoid=@id 
) AS fd
) AS fd
ORDER BY fd.el_addtime DESC ,fd.order_int 


END


	
END


IF @op_type='采购单'
BEGIN
	

SELECT *,'添加人'=si_name,
'供应单位'=(
 SELECT bs3.si_name FROM b_supplierinfo bs3 WHERE bs3.si_id=pl_ci_id
 ),'供应商代号'=(
 SELECT bs3.si_code FROM b_supplierinfo bs3 WHERE bs3.si_id=pl_ci_id
 ) ,
  '经手人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=pl_order_man) ,
  '修改人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=pl_update_man) ,
 '审核人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=pl_audit_man) 
FROM (
SELECT 
ROW_NUMBER() OVER (ORDER BY josl.pll_add_time  desc) AS '序号',
bg.gi_unit_name AS '单位',
bg.gi_code AS '商品编号',
bg.gi_name AS '商品名称',
 bg.gi_code AS  '条形码',
josl.pll_retail_price AS '零售价',
josl.pll_stock_price AS '进货价',
josl.pll_num AS '采购数量',
jos.pl_freight as '垫付运费',
josl.pll_money AS '采购金额',
--bs.sei_name AS '仓库',
jos.pl_vo AS '凭证号',
(case when pll_sku_id=''THEN bg.gi_barcode ELSE  bg2.gss_no end )AS '规格条形码',
CONVERT(VARCHAR(50),jos.pl_date,23) AS '单据日期',bs2.si_name,pl_ci_id,pl_audit_man,pl_update_man,pl_order_man,

(case when jos.pl_source=1 --来源为订单
then 
isnull((
 SELECT ci_name FROM b_clientinfo AS bs WITH (NOLOCK) WHERE ci_id = (select og_ci_id from pos_ogStorage where og_id=(SELECT top 1 ogl_og_id FROM pos_ogStorageList psl WITH (NOLOCK) WHERE psl.ogl_id=josl.pll_source_id and psl.ogl_status=1) and og_ci_id>0
	 ) ),'')
 end)as  '客户名称', --客户名称

 (case when jos.pl_source=1 --来源为订单
then 
isnull((  SELECT ci_code FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = (select og_ci_id from pos_ogStorage where og_id= (SELECT top 1 ogl_og_id FROM pos_ogStorageList psl WITH (NOLOCK) WHERE psl.ogl_id=josl.pll_source_id and psl.ogl_status=1) and og_ci_id>0 )) 
),'')
end)AS  '客户代号'--客户代号


FROM j_purchaseStorage jos 
INNER JOIN j_purchaseStorageList josl
ON jos.pl_id=josl.pll_pl_id
--INNER JOIN b_storageinfo bs ON jos.pl_st_id=bs.sei_id
LEFT JOIN b_stafftinfo bs2 ON jos.pl_add_man=bs2.si_id
INNER JOIN b_goodsinfo bg ON josl.pll_gi_id=bg.gi_id
LEFT JOIN b_goodsruleset bg2 ON josl.pll_sku_id=bg2.gss_id 
WHERE jos.pl_id=@id AND josl.pll_status>0

) AS fd

	
	END


IF @op_type='补货单'
BEGIN


SELECT *,'添加人'=si_name,
'收货单位'=(
 SELECT ps.sh_name FROM pos_shop ps WHERE fd.re_sh_id=sh_id
 ) ,
 '经手人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=re_order_man) ,
'修改人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=re_update_man) ,
 '审核人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=re_audit_man) 
FROM (
SELECT 
ROW_NUMBER() OVER (ORDER BY josl.rel_id  ASC) AS '序号',

bg.gi_unit_name AS '单位',
jos.re_sh_id,
bg.gi_code AS '商品编号',
bg.gi_name AS '商品名称',
bg.gi_barcode '条形码',
josl.rel_retail_price AS '零售价',
josl.rel_stock_price AS '进货价',
josl.rel_num AS '数量',
josl.rel_money AS '进货金额',
jos.re_vo AS '凭证号',
(case when josl.rel_sku_id=''THEN bg.gi_barcode ELSE  bg2.gss_no end )AS '规格条形码',
 CONVERT(VARCHAR(50),jos.re_date,23)AS '单据日期',bs2.si_name,re_supplier_sh_id,re_audit_man,re_update_man,re_order_man
FROM pos_reStorage jos 
INNER JOIN pos_reStorageList josl
ON jos.re_id=josl.rel_re_id
LEFT JOIN b_stafftinfo bs2 ON jos.re_add_man=bs2.si_id
INNER JOIN b_goodsinfo bg ON josl.rel_gi_id=bg.gi_id
LEFT JOIN b_goodsruleset bg2 ON josl.rel_sku_id=bg2.gss_id 
WHERE jos.re_id=@id AND josl.rel_status>0

) AS fd



END


IF @op_type='采购入库'
BEGIN
	
	SELECT 
	ROW_NUMBER() OVER (ORDER BY fend.pll_pl_id  ASC) AS '序号',
	* ,(采购数量-已入库数量-终止数量) as '未入库数量' FROM (
SELECT *,'添加人'=si_name,
'供应单位'=(
 SELECT bs3.si_name FROM b_supplierinfo bs3 WHERE bs3.si_id=pl_ci_id
 ),'供应商代号'=(
 SELECT bs3.si_code FROM b_supplierinfo bs3 WHERE bs3.si_id=pl_ci_id
 ) ,
  '经手人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=pl_order_man) ,
 '单据修改人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=pl_update_man) ,
 '审核人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=pl_audit_man) 
FROM (
SELECT 
bg.gi_unit_name AS '单位',
bg.gi_code AS '商品编号',
bg.gi_name AS '商品名称',
bg.gi_barcode '条形码',
jps.pll_retail_price AS '零售价',
jps.pll_stock_price AS '进货价',
jps.pll_num AS '采购数量',
isnull(el_number,0)* pll_stock_price AS '进货金额',
--bs.sei_name AS '仓库',
jps.pll_pl_id,
jos.pl_vo AS '凭证号',
jos.pl_freight as '垫付运费',
	 CONVERT(VARCHAR(50),bg.gi_productiondate,23)'生产日期',
el_number AS '已入库数量',

(case when pll_sku_id=''THEN bg.gi_barcode ELSE  gss_no end )AS '规格条形码',
	isnull(jps.pll_pause_num,0) AS '终止数量',
	
CONVERT(VARCHAR(50),jos.pl_date,23) AS '单据日期',bs2.si_name,pl_ci_id,pl_audit_man,pl_update_man,pl_order_man
FROM j_purchaseStorage jos 
LEFT JOIN 
(
	SELECT pll_pl_id,pll_gi_id,pll_add_time,isnull(je.el_number,0)AS el_number,bg2.gss_no,pll_sku_id,
	
josl.pll_retail_price AS pll_retail_price,
josl.pll_stock_price AS pll_stock_price,
josl.pll_num AS pll_num,
josl.pll_money AS pll_money,
pll_pause_num AS pll_pause_num

	FROM 
j_purchaseStorageList josl
LEFT JOIN j_enterStorageList je ON je.el_source_id=josl.pll_id
LEFT JOIN b_goodsruleset bg2 ON josl.pll_sku_id=bg2.gss_id 
WHERE pll_status=1

) as jps ON jos.pl_id=jps.pll_pl_id 
--INNER JOIN b_storageinfo bs ON jos.pl_st_id=bs.sei_id
LEFT JOIN b_stafftinfo bs2 ON jos.pl_add_man=bs2.si_id
INNER JOIN b_goodsinfo bg ON jps.pll_gi_id=bg.gi_id

WHERE jos.pl_id=@id 

) AS fd ) AS fend

END


IF @op_type='商品入库'
BEGIN
SELECT

ROW_NUMBER() OVER (ORDER BY fd.el_addtime  desc) AS '序号',
*,
( CASE WHEN 凭证号 like 'RKTH%' then '入库退货'else '商品入库' end )AS '单据标题',
'添加人'=si_name,

'审核人'=(SELECT bs3.si_name FROM b_stafftinfo bs3 WHERE bs3.si_id=eo_lastmanid) , 
'经手人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=eo_takemanid),
'修改人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=eo_updateman) 

FROM (
SELECT 
jos.eo_remark AS '备注',
bg.gi_unit_name AS '单位',  
bg.gi_code AS '商品编号',
bg.gi_name AS '商品名称',
sg.sei_name as '仓库',
bg.gi_barcode '条形码',
josl.el_unit AS '零售价',
josl.el_costprice AS '进货价',
( CASE WHEN eo_no like 'RKTH%' then -josl.el_number else josl.el_number end ) AS '数量',
josl.el_realmoney AS '进货金额',
jos.eo_no AS '凭证号',
 CONVERT(VARCHAR(50),jos.eo_entrydate,23)AS '单据日期',bs2.si_name,
 CONVERT(VARCHAR(50),bg.gi_productiondate ,23) AS '生产日期',
(CASE WHEN josl.el_skuid=0 THEN bg.gi_barcode ELSE  bg2.gss_no END ) AS '规格条形码',
'供应单位'=(
 SELECT bs3.si_name FROM b_supplierinfo bs3 WHERE bs3.si_id=jos.eo_ciid
 ),'供应商代号'=(
 SELECT bs3.si_code FROM b_supplierinfo bs3 WHERE bs3.si_id=eo_ciid
 ),
 josl.el_id,josl.el_addtime,
jos.eo_lastmanid,jos.eo_updateman,jos.eo_takemanid
FROM j_enterStorage jos 
INNER JOIN j_enterStorageList josl ON jos.eo_id=josl.el_eoid
LEFT JOIN b_stafftinfo bs2 ON jos.eo_addman=bs2.si_id
INNER JOIN b_goodsinfo bg ON josl.el_siid=bg.gi_id
LEFT JOIN b_goodsruleset bg2 ON josl.el_skuid=bg2.gss_id 
left join b_storageinfo sg on jos.eo_siid=sg.sei_id
WHERE jos.eo_id=@id AND josl.el_status>0 
) AS fd 
END

IF @op_type='配货出库'
BEGIN

SELECT *,
'添加人'=si_name,
'审核人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=al_audit_man) ,
'修改人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=al_update_man)
FROM (
SELECT 
al_id,
ROW_NUMBER() OVER (ORDER BY josl.all_add_time DESC, gi_barcode DESC) AS '序号',
bg.gi_unit_name AS '单位',
bg.gi_code AS '商品编号',
bg.gi_name AS '商品名称',
bg.gi_barcode '条形码',
josl.all_retail_price AS '零售价',
josl.all_stock_price AS '供货价',
josl.all_num AS '配货数量',
isnull(fd.ol_number,0)*all_stock_price AS '金额',
isnull(fd.ol_number,0)*all_retail_price AS '执行零售金额',
isnull(fd.ol_number,0) AS '执行数量',
(josl.all_num -isnull(fd.ol_number,0))AS '未执行数量',
jos.al_vo AS '凭证号',
 CONVERT(VARCHAR(50),jos.al_date,23)AS '单据日期',bs2.si_name,
 all_discount AS '折扣',
 (SELECT bs2.sei_name FROM  b_storageinfo bs2 WHERE jos.al_st_id=bs2.sei_id) AS '仓库',
 (case when all_sku_id='' or all_sku_id is null THEN bg.gi_barcode ELSE  josl.gss_no end )AS '规格条形码',
 '收货单位'=( CASE WHEN jos.al_ci_id<>0 then ( SELECT bc.ci_name FROM b_clientinfo bc WHERE bc.ci_id=al_ci_id )
 WHEN (jos.al_to_cp_id<>0) THEN (SELECT cp.cp_name FROM companyinfo cp WHERE cp.cp_id=al_to_cp_id )
 ELSE  (SELECT ps.sh_name FROM pos_shop ps WHERE ps.sh_id=al_sh_id ) END  ),

jos.al_audit_man,jos.al_update_man
FROM pos_allocation jos 
INNER JOIN 	(	
	
	SELECT bg2.gss_no, all_al_id, all_gi_id, all_add_time, CONVERT (VARCHAR (100),all_source_add_time,25) AS all_source_add_time,all_pause_num, all_num, 
	 all_id, all_sku_id, all_money,all_retail_money,all_gift, all_status, CONVERT (DECIMAL (10, 2), all_retail_price,23) AS all_retail_price,
	 CONVERT (DECIMAL (10, 2), all_stock_price,23)AS all_stock_price, CONVERT (DECIMAL (10, 2),all_discount,23)AS all_discount, all_pm ,all_box_num FROM pos_allocationList AS al  
	 LEFT JOIN b_goodsruleset bg2 ON al.all_sku_id=bg2.gss_id 
	   where al.all_status > 0  
)josl
ON jos.al_id=josl.all_al_id
LEFT JOIN b_stafftinfo bs2 ON jos.al_add_man=bs2.si_id
INNER JOIN b_goodsinfo bg ON josl.all_gi_id=bg.gi_id
LEFT JOIN   
		
		( SELECT  ol_source_id, ol_siid, ol_source_add_time, ol_number FROM   j_outStorage          AS jos WITH (NOLOCK)  INNER JOIN j_outStorageList  AS josl WITH (NOLOCK)  ON  jos.oo_id = josl.ol_eoid WHERE  jos.oo_source_type = 1  AND jos.oo_source_id > 0 AND josl.ol_status = 1 AND jos.oo_status > 0  )AS  fd 
		
		 ON josl.all_add_time = fd.ol_source_add_time and fd.ol_source_id =josl.all_id
--LEFT JOIN b_goodsruleset bg2 ON josl.el_skuid=bg2.gss_id 
WHERE jos.al_id=@id


) AS fd

END


IF @op_type='订单管理'
BEGIN



SELECT *,'添加人'=si_name,

 '经手人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=og_order_man) ,
'修改人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=og_update_man) ,
 '审核人'=(SELECT bs3.si_name
FROM b_stafftinfo bs3 WHERE bs3.si_id=og_audit_man) 
FROM (
SELECT 
ROW_NUMBER() OVER (ORDER BY josl.ogl_add_time desc) AS '序号',
 '收货单位'=( CASE WHEN jos.og_ci_id<>0 then ( SELECT bc.ci_name FROM b_clientinfo bc WHERE bc.ci_id=og_ci_id )
 WHEN (jos.og_to_cp_id<>0) THEN (SELECT cp.cp_name FROM companyinfo cp WHERE cp.cp_id=og_to_cp_id )
 ELSE  (SELECT ps.sh_name FROM pos_shop ps WHERE ps.sh_id=og_sh_id ) END  ) ,
bg.gi_unit_name AS '单位',
jos.og_sh_id,
jos.og_remark AS '备注',
bg.gi_code AS '商品编号',
bg.gi_name AS '商品名称',
bg.gi_barcode '条形码',
josl.ogl_retail_price AS '零售价',
josl.ogl_stock_price AS '进货价',
josl.ogl_num AS '配货数量',
josl.ogl_num*josl.ogl_retail_price AS '执行零售金额',
josl.ogl_num*josl.ogl_stock_price AS '供货金额',
jos.og_vo AS '凭证号',
(case when josl.ogl_sku_id=''THEN bg.gi_barcode ELSE  bg2.gss_no end )AS '规格条形码',
 CONVERT(VARCHAR(50),jos.og_date,23)AS '单据日期',bs2.si_name,og_audit_man,og_update_man,og_order_man
FROM pos_ogStorage jos 
INNER JOIN pos_ogStorageList josl
ON jos.og_id=josl.ogl_og_id
LEFT JOIN b_stafftinfo bs2 ON jos.og_add_man=bs2.si_id
INNER JOIN b_goodsinfo bg ON josl.ogl_gi_id=bg.gi_id
LEFT JOIN b_goodsruleset bg2 ON josl.ogl_sku_id=bg2.gss_id 
WHERE jos.og_id=@id AND josl.ogl_status>0

) AS fd


END


if @op_type='调拨'
BEGIN

SELECT 
bg2.gs_name AS '规格名称',
jis.al_vo AS '凭证号',
jis.al_date AS '调拨日期',
jis.al_no  AS '单据号',
(
           SELECT sh_name
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.al_sh_id)
       )  AS '调出店铺',
 (
           SELECT sh_name
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.al_get_sh_id)
       )  AS '调入店铺',
  (
           SELECT sh_no
           FROM   dbo.pos_shop AS bs
           WHERE  (sh_id = jis.al_get_sh_id)
       )  AS '店铺编号',
       (
           SELECT sei_name
           FROM   dbo.pos_storageInfo AS bs
           WHERE  (sei_id = jis.al_st_id)
       )  AS '仓库',
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.al_order_man)
       )  AS '经手人',
      (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.al_add_man)
       )  AS '添加人',
       al_add_time AS '添加时间',
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.al_update_man)
       )  AS '修改人',
       al_update_time AS '修改时间',
       (
           SELECT si_name
           FROM   dbo.b_stafftinfo AS bs
           WHERE  (si_id = jis.al_audit_man)
       )  AS '审核人',
       al_audit_time AS '审核时间',
       al_remark AS '备注',
       bg.gi_code AS '商品编号',
       bg.gi_barcode AS '条形码',
       bg.gi_name AS '商品名称',
       bu.ut_name AS '单位',
       all_retail_price AS '零售价',
       all_discount AS '折扣',
       all_stock_price AS '进货价',
       all_num AS '数量',
       all_money AS '金额',
       all_gift AS '是否获赠', 
       bg2.gss_no AS '规格条形码' 
      
FROM(
SELECT     
all_al_id, all_gi_id, all_add_time,all_sku_id, 
SUM(all_num) AS all_num, 
MIN(all_id) AS all_id, 
SUM(all_money) AS all_money, 
CONVERT(decimal(10, 2), 
AVG(all_retail_price)) AS all_retail_price, 
CONVERT(decimal(10, 2), AVG(all_stock_price)) AS all_stock_price, 
MAX(all_gift) 
AS all_gift, 
CONVERT(decimal(10,2), avg(all_discount)) AS all_discount
FROM    dbo.pos_alStorageList AS jt
WHERE   (all_status = 1) AND jt.all_al_id=@id
GROUP BY all_al_id, all_gi_id, all_add_time,jt.all_sku_id
) AS jt
INNER JOIN pos_alStorage AS jis ON jis.al_id=jt.all_al_id and al_status!=0 and al_status !=3
INNER JOIN dbo.b_goodsinfo  AS bg 
ON  jt.all_gi_id = bg.gi_id
LEFT JOIN b_goodsruleset bg2 ON bg2.gi_id=jt.all_gi_id AND bg2.gss_id=jt.all_sku_id
INNER JOIN dbo.b_unit       AS bu
ON  bg.gi_unit = bu.ut_id
end


if @op_type='移仓一维'
begin
SELECT 
mo_vo AS [凭证号],
mo_date AS [单据日期],
mo_out_st_id_txt AS [移出仓库],
mo_in_st_id_txt AS [移入仓库],
mo_add_man_txt AS [添加人],
mo_add_time AS [添加时间],
mo_audit_man_txt AS [审核人],
mo_audit_time AS [审核时间],
gi_code AS [商品编号],
gi_name AS [商品名称],
gi_unit AS [单位],
barcode AS [商品条形码],
color AS [颜色],
spec AS [尺码],
mol_retail_price AS [零售价],
mol_stock_price AS [进货价],
mol_num AS [数量],
mol_pm AS [批号],
mol_money AS [金额],
mol_money AS [总金额],
mo_remark AS [备注]
FROM v_z_moStorage_detail
WHERE mo_id=@id
end
go

