CREATE VIEW [dbo].[vi_pos_inStorage_audit]
AS
SELECT  jo.oo_status ,
         (SELECT top 1 si_id FROM pos_supplierinfo where [si_companyid] =oo_cp_id and [si_sh_id]=oo_sh_id ) as in_supplier_id  , --供方主键
        --供方类型
        (CASE WHEN (SELECT  cp_is_zorf FROM  companyinfo WHERE   cp_id = jo.oo_cp_id ) = 1 THEN '总部' ELSE '分公司' END) AS in_supplier , 

        --供方编号
        (CASE WHEN (SELECT  cp_is_zorf FROM  companyinfo WHERE   cp_id = jo.oo_cp_id ) = 2 then
        (SELECT  cp_code FROM  companyinfo WHERE   cp_id = jo.oo_cp_id) else
        (SELECT top 1 si_code FROM pos_supplierinfo where [si_companyid] =oo_cp_id and [si_sh_id]=oo_sh_id)end )  AS in_supplier_code_txt ,

        --供方名称
        (CASE WHEN (SELECT  cp_is_zorf FROM  companyinfo WHERE   cp_id = jo.oo_cp_id ) = 2 then (SELECT  cp_name FROM  companyinfo WHERE   cp_id = jo.oo_cp_id)
        else (SELECT top 1 si_name FROM pos_supplierinfo where [si_companyid] =oo_cp_id and [si_sh_id]=oo_sh_id) end ) AS in_supplier_id_txt ,


        in_type = 1 , --单据类型(1,总部配货:2,店铺调拨)
        oo_id AS in_id , --单据主键
        oo_erp_id AS in_erp_id , --客户主键
        oo_sh_id AS in_shop_id , --店铺主键
        oo_to_cp_id AS in_to_cp_id , --分公司主键
        oo_siid AS in_st_id , --仓库主键
        oo_no AS in_vo , --凭证号
        oo_manual AS in_no , --单据号
        oo_entrydate AS in_date , --单据日期
       --oo_itid,
       --oo_type,
        oo_takemanid AS in_man , --制单人 
       --oo_cost
       --oo_freight,
       --oo_express,
       --oo_expressno,
        oo_remark AS in_remark , --备注
       --oo_source_type,
       --oo_source_id,
        oo_addman AS in_add_man , --添加人
        oo_addtime AS in_add_time , --添加时间
        oo_lastmanid AS in_audit_man , --审核人
        oo_auditdate AS in_audit_time , --审核时间
        oo_updatemam AS in_update_man , --修改人
        oo_updatetime AS in_update_time , --修改时间
       --pos审核人
        in_pos_audit_man = (SELECT TOP 1
                                    pis.in_audit_man
                            FROM    pos_inStorage AS pis
                            WHERE   in_audit_man IS NOT NULL
                                    AND pis.in_status > 0
                                    AND pis.in_source = 1
                                    AND pis.in_source_id = jo.oo_id
                           ) ,
       --pos审核时间
        in_pos_audit_time = (SELECT TOP 1
                                    pis.in_audit_time
                             FROM   pos_inStorage AS pis
                             WHERE  pis.in_status > 0
                                    AND pis.in_source = 1
                                    AND pis.in_source_id = jo.oo_id
                            ) ,
        oo_cp_id,
		thtype=jo.oo_type,
		oo_io_id
FROM    j_outStorage AS jo
LEFT JOIN pos_allocation ja ON jo.oo_source_id = ja.al_id
--审核状态,配货出库产生的单据
WHERE   jo.oo_status = 2
        AND ((jo.oo_sh_id > 0
              AND (al_source <> 3
                   OR al_source IS NULL))
             OR (jo.oo_to_cp_id > 0
                 AND (al_source <> 3
                      OR al_source IS NULL)))
        AND jo.oo_source_type IN (0,1)
UNION ALL
--调拨,审核状态
SELECT  pa.al_status ,
        in_supplier_id = al_sh_id ,
        in_supplier = '店铺' ,
        --供方编号
        (SELECT  sh_no FROM    dbo.pos_shop WHERE  (sh_id = al_sh_id)) AS in_supplier_code_txt ,
        --供方名称
        (SELECT  sh_name FROM  dbo.pos_shop WHERE  (sh_id = al_sh_id)) AS in_supplier_id_txt ,
        in_type = 2 ,
        al_id AS in_id ,
        al_erp_id AS in_erp_id ,
        al_get_sh_id AS in_shop_id ,
        al_get_to_cp_id AS in_to_cp_id ,
        al_st_id AS in_st_id ,
        al_vo AS in_vo ,
        al_no AS in_no ,
        al_date AS in_date ,
        al_order_man AS in_order_man ,
        al_remark AS in_remark ,
        al_add_man AS in_add_man ,
        al_add_time AS in_add_time ,
        al_audit_man AS in_audit_man ,
        al_audit_time AS in_audit_time ,
        al_update_man AS in_update_man ,
        al_update_time AS al_update_time ,
       --pos审核人
        in_pos_audit_man = (SELECT TOP 1
                                    pis.in_audit_man
                            FROM    pos_inStorage AS pis
                            WHERE   in_audit_man IS NOT NULL
                                    AND pis.in_status > 0
                                    AND pis.in_source = 2
                                    AND pis.in_source_id = pa.al_id
                           ) ,
       --pos审核时间
        in_pos_audit_time = (SELECT TOP 1
                                    pis.in_audit_time
                             FROM   pos_inStorage AS pis
                             WHERE  pis.in_status > 0
                                    AND pis.in_source = 2
                                    AND pis.in_source_id = pa.al_id
                            ) ,
        0,
		1,
		''
FROM    pos_alStorage AS pa
WHERE   pa.al_status = 2
go

