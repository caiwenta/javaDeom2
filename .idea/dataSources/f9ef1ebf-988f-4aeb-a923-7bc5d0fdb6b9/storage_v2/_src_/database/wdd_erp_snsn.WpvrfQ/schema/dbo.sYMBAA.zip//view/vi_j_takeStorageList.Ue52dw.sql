CREATE VIEW [dbo].[vi_j_takeStorageList] AS 
select tsl_ts_id,
       tsl_gi_id,
       tsl_add_time,
       sum(tsl_old_num)       as tsl_old_num,
       sum(tsl_new_num)       as tsl_new_num,
       sum(tsl_log_num)       as tsl_log_num,
       min(tsl_id)            as tsl_id,
       max(tsl_sku_id)        as tsl_sku_id,
       avg(tsl_stock_price) as tsl_stock_price,
       sum(tsl_old_money) as tsl_old_money,
       sum(tsl_new_money) as tsl_new_money,
       sum(tsl_log_money) as tsl_log_money,
	   isnull(tsl_pm,'')  as tsl_pm,
	   tsl_boxbynum,
	   max(tsl_pddate) as tsl_pddate,
	   max(tsl_shelflife) as tsl_shelflife,
	   max(tsl_expirationdate) as tsl_expirationdate,
	   max(tsl_box_num) as  tsl_box_num
from   dbo.j_takeStorageList  as jt 
where  (tsl_status = 1)
group by
       tsl_ts_id,
       tsl_gi_id,
       tsl_add_time,
	   tsl_boxbynum,tsl_pm
go

