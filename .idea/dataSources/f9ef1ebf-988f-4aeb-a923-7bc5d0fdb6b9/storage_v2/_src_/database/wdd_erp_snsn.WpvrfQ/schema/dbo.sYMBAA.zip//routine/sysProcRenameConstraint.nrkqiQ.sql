
CREATE PROCEDURE [dbo].[sysProcRenameConstraint]
-- =============================================
-- Author:		<重新命名默认值约束名称>
-- Create date: <2015-05-03>
-- Description:	<为了规范，重新命名默认值约束名称>
-- =============================================
AS
    BEGIN
        DECLARE dfcur CURSOR
        FOR
            SELECT  OBJECT_NAME(col.object_id) AS dfConstraintName ,
                    dfTable.name AS dfTable ,
                    dfCol.name AS dfColumn
            FROM    sys.default_constraints col
                    INNER JOIN sys.objects dfTable ON dfTable.object_id = col.parent_object_id
                    INNER JOIN sys.columns dfCol ON dfCol.column_id = col.parent_column_id
                                                    AND dfCol.object_id = dfTable.object_id  
    
        OPEN dfcur  
        DECLARE @constraintName NVARCHAR(128)  
        DECLARE @dfTable NVARCHAR(64)  
        DECLARE @dfColumn NVARCHAR(64)  
        DECLARE @newConstraintName NVARCHAR(128)  
 
        FETCH NEXT FROM dfcur INTO @constraintName, @dfTable, @dfColumn
        WHILE @@FETCH_STATUS = 0
            BEGIN  
                SET @newConstraintName = 'DF_' + @dfTable + '_On_' + @dfColumn  
                IF @constraintName != @newConstraintName
                    BEGIN
                        EXEC sp_rename @constraintName, @newConstraintName,
                            'Object'  
                    END
                FETCH NEXT FROM dfcur INTO @constraintName, @dfTable,
                    @dfColumn
            END  
        CLOSE dfcur  
        DEALLOCATE dfcur
    END

go

