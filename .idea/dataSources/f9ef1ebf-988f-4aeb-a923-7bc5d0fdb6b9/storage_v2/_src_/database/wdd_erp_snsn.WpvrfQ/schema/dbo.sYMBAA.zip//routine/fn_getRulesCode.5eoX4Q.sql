CREATE function [dbo].[fn_getRulesCode](@str varchar(100))
returns varchar(500)
as
BEGIN
declare @result varchar(500);
set @result='';	
declare @sz varchar(100);
set @sz='';
select @sz=dbo.fun_getPY(@str)
declare @ms varchar(100);
set @ms='';
select @ms=convert(varchar,datepart(ms,getdate()));
set @result=@sz+@ms;
return @result;
end
go

