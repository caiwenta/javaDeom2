CREATE VIEW [dbo].[vi_j_outStorage]
AS
SELECT  
 
(case when poutlist.ci_name IS not null then poutlist.ci_name when poutlist.oo_sh_id_txt is not null then poutlist.oo_sh_id_txt when poutlist.oo_to_cp_id_txt is not null  then poutlist.oo_to_cp_id_txt else '' end) AS sh_ci_name,
 
  (case when poutlist.ci_code IS not null then poutlist.ci_code when poutlist.sh_no is not null then poutlist.sh_no when poutlist.cp_code is not null then poutlist.cp_code 
 else '' end) AS sh_ci_code,

 
 * from (select do_id,
        jis.oo_realmoney ,
		isnull(jis.oo_totalboxnum,0)oo_totalboxnum,
        jis.oo_num ,
        jis.oo_id ,
        jis.oo_no ,
        CONVERT (VARCHAR(10), jis.oo_entrydate, 120) AS oo_entrydate ,
        jis.oo_manual ,
        jis.oo_type ,
        jis.oo_siid ,
        jis.oo_freight ,
        jis.oo_ciid ,
        jis.oo_cost ,
        jis.oo_takemanid ,
		jis.oo_source_type,
        jis.oo_source_id ,
        jis.oo_cp_id ,
        jis.oo_di_id ,
        ( case oo_source_type when 1 then
		    (SELECT  al_vo FROM  pos_allocation AS bs WITH ( NOLOCK ) WHERE   al_id = jis.oo_source_id )
            when 2 then
	        (SELECT eo_no FROM  j_enterStorage AS bs WITH ( NOLOCK ) WHERE  eo_id = jis.oo_source_id )
		    when 3 then
		   (SELECT  in_vo FROM   pos_inStorage AS bs WITH ( NOLOCK ) WHERE  in_id = jis.oo_source_id )
		   else '' end
	    ) AS al_vo ,
        ( SELECT    ci_name
          FROM      dbo.b_clientinfo AS bs WITH ( NOLOCK )
          WHERE     ( ci_id = jis.oo_ciid )
        ) AS ci_name ,
        ( SELECT    ci_province
          FROM      dbo.b_clientinfo AS bs WITH ( NOLOCK )
          WHERE     ( ci_id = jis.oo_ciid )
        ) AS ci_province ,
        ( SELECT    ci_city
          FROM      dbo.b_clientinfo AS bs WITH ( NOLOCK )
          WHERE     ( ci_id = jis.oo_ciid )
        ) AS ci_city ,
        bs.sh_name AS oo_sh_id_txt ,
        bs.sh_no AS sh_no ,
        jis.oo_sh_id ,
        ( SELECT    province
          FROM      dbo.pos_shop AS bs WITH ( NOLOCK )
          WHERE     ( sh_id = jis.oo_sh_id )
        ) AS sh_province ,
        ( SELECT    city
          FROM      dbo.pos_shop AS bs WITH ( NOLOCK )
          WHERE     ( sh_id = jis.oo_sh_id )
        ) AS sh_city ,
        ( SELECT    ci_code
          FROM      dbo.b_clientinfo AS bs WITH ( NOLOCK )
          WHERE     ( ci_id = jis.oo_ciid )
        ) AS ci_code ,
        ( SELECT    sei_name
          FROM      dbo.b_storageinfo AS bs WITH ( NOLOCK )
          WHERE     ( sei_id = jis.oo_siid )
        ) AS sei_name ,
        ( SELECT    si_name
          FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
          WHERE     ( si_id = jis.oo_takemanid )
        ) AS takeman ,
        ( SELECT    si_name
          FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
          WHERE     ( si_id = jis.oo_addman )
        ) AS oo_addman_txt ,
        jis.oo_addman ,
        jis.oo_addtime ,
        ( SELECT    si_name
          FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
          WHERE     ( si_id = jis.oo_updatemam )
        ) AS oo_updatemam_txt ,
        jis.oo_updatemam ,
        jis.oo_updatetime ,
        ( SELECT    si_name
          FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
          WHERE     ( si_id = jis.oo_lastmanid )
        ) AS oo_lastman ,
        jis.oo_lastmanid ,
        jis.oo_auditdate ,
        jis.oo_remark ,
        jis.oo_status ,
        cpy.cp_name AS oo_to_cp_id_txt ,
        cpy.cp_code AS cp_code ,
        jis.oo_to_cp_id ,
        ( SELECT    cp_province
          FROM      dbo.companyinfo AS bs WITH ( NOLOCK )
          WHERE     ( cp_id = jis.oo_to_cp_id )
        ) AS cp_province ,
        ( SELECT    cp_city
          FROM      dbo.companyinfo AS bs WITH ( NOLOCK )
          WHERE     ( cp_id = jis.oo_to_cp_id )
        ) AS cp_city ,


       isnull(   ( 
	 case  when jis.oo_sh_id>0 then --店铺
	 
	 (SELECT TOP 1 2 FROM dbo.vi_pos_inStorage AS bs WITH ( NOLOCK ) WHERE  in_source_id = jis.oo_id AND  in_source_no = jis.oo_no AND  in_status > 0) 

		   when jis.oo_to_cp_id>0 then --分公司
	 (select top 1 2 from j_enterStorage as jes where eo_source_type=2 AND jes.eo_source_id=jis.oo_id AND eo_status>0)
		   end
        ),0) AS in_status ,


        jis.oo_jytype ,
        fd.ord_no AS oi_no ,
        jis.oo_fo_audit_ed ,
        jis.oo_erp_id,

        jis.oo_io_logistics,   --指令单物流公司
        jis.oo_logistics_no,   --指令单物流单号
		( SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id where eio.io_id=oo_io_id)instru_vo --指令单凭证号

FROM    dbo.j_outStorage AS jis WITH ( NOLOCK )
        LEFT JOIN companyinfo AS cpy WITH ( NOLOCK ) ON cpy.cp_id = jis.oo_to_cp_id
        LEFT JOIN dbo.pos_shop AS bs WITH ( NOLOCK ) ON bs.sh_id = jis.oo_sh_id
        LEFT OUTER JOIN dbo.netorder_tbl AS fd WITH ( NOLOCK ) ON jis.oo_di_id = fd.ord_id
        AND CHARINDEX('网络订单', jis.oo_remark, 0) > 0
        )as poutlist
go

