



 CREATE VIEW [dbo].[vi_JoinFK_Allocation__renum_Group_Goods_new]
 AS
SELECT al.*,
       ISNULL(red.rel_num, 0) AS rel_num,
       red.re_id,
       CONVERT (
		VARCHAR (100),
		red.rel_add_time,
		25
	) AS rel_add_time,
       --red.rel_add_time,
       red.rel_gi_id
FROM   vi_JoinFK_Allocation__re_Group_Goods_new AS al
       LEFT JOIN (
                SELECT re_id,
                       rel_gi_id,
                       SUM(rel_num)  AS rel_num,
                       rel_add_time
                FROM                    vi_allocation_re_outed
                GROUP BY
                       re_id,
                       rel_gi_id,
                       rel_add_time
            ) red
            ON  red.re_id = al.al_source_id
            AND red.rel_gi_id = al.all_gi_id
            AND al.al_source = 2
 go

