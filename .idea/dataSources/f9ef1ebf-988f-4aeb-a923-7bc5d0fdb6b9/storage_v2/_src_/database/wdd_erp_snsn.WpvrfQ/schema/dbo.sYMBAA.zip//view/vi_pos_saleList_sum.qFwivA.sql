CREATE VIEW [dbo].[vi_pos_saleList_sum] AS 
select 
*,
(fd.sal_money-fd.sal_change_money) as sa_money1
from (
select 
ps.sal_sa_id,
--数量
sum(
	case 
	when ps.sal_is_change=1 or ps.sal_is_return=1
	then -abs(ps.sal_num) 
	else
		ps.sal_num 
	end
	--ps.sal_num 
)as sal_num,
--扣除金额
sum(ps.sal_deduct_money)as sal_deduct_money,
--销售金额
sum(
	case 
	when 
	ps.sal_is_gift=0 
	and ps.sal_is_change=0 
	and ps.sal_is_in=0
	and ps.sal_is_return=0
	then (ps.sal_num*ps.sal_real_price)-ps.sal_deduct_money
		--ps.sal_money 
	else 0 
	end
	)as sal_money,
--原价
sum(
	case 
	when 
	ps.sal_is_change=0 
	and ps.sal_is_return=0 
	and ps.sal_is_gift=0
	then 
		ps.sal_retail_price*ps.sal_num 
	when ps.sal_is_change=1 or ps.sal_is_return=1 
	then -(ps.sal_retail_price*abs(ps.sal_num))
	--then (ps.sal_retail_price*ps.sal_num)
	else 0
	end
)as sal_money_full,

--原价
sum(
	case 
	when ps.sal_is_change=0 and ps.sal_is_return=0 and ps.sal_is_gift=0 then 
	ps.sal_paidmomey
	when ps.sal_is_change=1 or ps.sal_is_return=1 then 
	-abs(ps.sal_paidmomey)
	else 0
	end
)as salpaidmomey,

--实收金额
sum(
	case 
	when ps.sal_is_change=0 and ps.sal_is_return=0 and ps.sal_is_gift=0 AND ps.sal_is_in=0 then 
	ps.sal_paidmomey
	when ps.sal_is_change=1 or ps.sal_is_return=1 then 
	-abs(ps.sal_paidmomey)
	else 0
	end
)as sal_paidmomey,

--换货金额
sum(case when ps.sal_is_return=1 or ps.sal_is_change=1 then (ps.sal_real_price*abs(ps.sal_num))-sal_deduct_money else 0 end)as sal_change_money,
--兑换积分
sum(case when ps.sal_is_in=1 then ps.sal_in_num else 0 end) as sal_in_num 

from pos_saleList as ps where ps.sal_status=1 
group by ps.sal_sa_id
) as fd
go

