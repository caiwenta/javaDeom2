
CREATE function [dbo].[fn_get_attribute_id_str]( @gi_id INT,@a_cp_id INT)
returns varchar(MAX)
as
begin

DECLARE @result VARCHAR(MAX)=',';

SELECT @result+=CONVERT(VARCHAR(10),ba.a_id)+',' FROM b_attribute_set bas 
INNER JOIN b_attribute ba ON bas.a_a_id=ba.a_id 
WHERE bas.a_gi_id=@gi_id AND bas.a_type=1 


return @result;
end
go

