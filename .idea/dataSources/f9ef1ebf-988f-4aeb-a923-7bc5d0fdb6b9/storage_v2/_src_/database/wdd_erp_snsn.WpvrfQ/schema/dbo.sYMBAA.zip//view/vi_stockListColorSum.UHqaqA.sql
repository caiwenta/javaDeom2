CREATE VIEW [dbo].[vi_stockListColorSum]
	AS 
SELECT  je2.el_color_id as color_id,
        je.eo_siid AS sid ,
        je.eo_ciid AS cid ,
        je2.el_siid AS gid ,
        abs(je2.el_number) AS gnum ,
        ISNULL(je2.el_pm,'') AS pm ,
        countType = CASE WHEN je.eo_type = 0 THEN 1
                         ELSE 0
                    END ,
        myremark = CASE WHEN je.eo_type = 0 THEN '入库'
                        ELSE '入库退货'
                   END ,
        addtime = je2.el_addtime ,
        orderno = je.eo_no ,
        eoid = je.eo_id ,
        elid = je2.elmcs_id ,
        mytype = 1 ,
		ISNULL(el_box_num,0) as box_num,
		el_boxbynum as boxbynum,
        order_add_time = je.eo_addtime ,
        order_date = je.eo_entrydate ,
        je.eo_cp_id AS cp_id ,
        je.eo_erp_id ,
        'j_enterStorage' AS table_name
FROM    j_enterStorage je
INNER JOIN j_enterStorageListMergeColorSum je2 ON je.eo_id = je2.el_eoid
WHERE   je.eo_status=2
        AND je2.el_status = 1
        AND je2.el_siid > 0
        AND je.eo_siid > 0
UNION ALL
--出库
SELECT  je2.ol_color_id as color_id,
        je.oo_siid AS SID ,
        je.oo_ciid AS cid ,
        je2.ol_siid AS gid ,
        abs(je2.ol_number) AS gnum ,
        ISNULL(je2.ol_pm,'') AS pm ,
        countType = CASE WHEN je.oo_type = 0 THEN 1
                         ELSE 0
                    END ,
        myremark = CASE WHEN je.oo_type = 0 THEN '出库退货'
                        ELSE '出库'
                   END ,
        addtime = je2.ol_addtime ,
        orderno = je.oo_no ,
        eoid = je.oo_id ,
        elid = je2.olmcs_id ,
        mytype = 2 ,
		ISNULL(ol_box_num,0) as box_num,
		ol_boxbynum as boxbynum,
        order_add_time = je.oo_addtime ,
        order_date = je.oo_entrydate ,
        je.oo_cp_id ,
        je.oo_erp_id ,
        'j_outStorage' AS table_name
FROM    j_outStorage je
INNER JOIN j_outStorageListMergeColorSum je2 ON je.oo_id = je2.ol_eoid
WHERE   je.oo_status=2
        AND je2.ol_status = 1
        AND je2.ol_siid > 0
        AND je.oo_siid > 0
UNION ALL
--期初
SELECT  ji.inl_color_id as color_id, 
        jt.in_st_id AS [sid],
        cid = 0 ,
        ji.inl_gi_id AS gid ,
        ji.inl_num AS gnum ,
        ISNULL(ji.inl_pm,'') AS pm ,
        countType = 1 ,
        myremark = '期初' ,
        ji.inl_add_time AS addtime ,
        jt.in_vo AS orderno ,
        jt.in_id AS eoid ,
        ji.inlmcs_id AS elid ,
        mytype = 3 ,
		ISNULL(inl_box_num,0) as box_num,
		inl_boxbynum as boxbynum,
        order_add_time = jt.in_add_time ,
        order_date = jt.in_date ,
        jt.in_cp_id ,
        jt.in_erp_id ,
        'j_initStorage' AS table_name
FROM    j_initStorage AS jt
INNER JOIN j_initStorageListMergeColorSum AS ji ON jt.in_id = ji.inl_in_id
WHERE   jt.in_status=2
        AND ji.inl_status = 1
        AND ji.inl_gi_id > 0
        AND jt.in_st_id > 0
UNION ALL
--移仓
SELECT  jmsl.mol_color_id as color_id,
        jms.mo_out_st_id AS SID ,
        cid = 0 ,
        jmsl.mol_gi_id AS gid ,
        abs(jmsl.mol_num) AS gnum ,
        ISNULL(jmsl.mol_pm,'') AS pm ,
        countType = 0 ,
        myremark = '移出仓库' ,
        addtime = jmsl.mol_add_time ,
        orderno = mo_vo ,
        eoid = mo_id ,
        elid = molmcs_id ,
        mytype = 4 ,
		ISNULL(mol_box_num,0) as box_num,
		mol_boxbynum as boxbynum,
        order_add_time = jms.mo_add_time ,
        order_date = jms.mo_date ,
        jms.mo_cp_id ,
        jms.mo_erp_id ,
        'j_moStorage' AS table_name
FROM    j_moStorage AS jms
INNER JOIN j_moStorageListMergeColorSum AS jmsl ON jms.mo_id = jmsl.mol_mo_id
WHERE   jms.mo_status=2
        AND jmsl.mol_status = 1
        AND jmsl.mol_gi_id > 0
        AND jms.mo_out_st_id > 0
		and jmsl.mol_type=0
UNION ALL
SELECT  jmsl.mol_color_id as color_id,
        jms.mo_in_st_id AS SID ,
        cid = 0 ,
        jmsl.mol_gi_id AS gid ,
         abs(jmsl.mol_num) AS gnum ,
        ISNULL(jmsl.mol_pm,'') AS pm ,
        countType = 1 ,
        myremark = '移入仓库' ,
        addtime = jmsl.mol_add_time ,
        orderno = mo_vo ,
        eoid = mo_id ,
        elid = molmcs_id ,
        mytype = 5 ,
		ISNULL(mol_box_num,0) as box_num,
		mol_boxbynum as boxbynum,
        order_add_time = jms.mo_add_time ,
        order_date = jms.mo_date ,
        jms.mo_cp_id ,
        jms.mo_erp_id ,
        'j_moStorage' AS table_name
FROM    j_moStorage AS jms
INNER JOIN j_moStorageListMergeColorSum AS jmsl ON jms.mo_id = jmsl.mol_mo_id
WHERE   jms.mo_status=2
        AND jmsl.mol_status = 1
        AND jmsl.mol_gi_id > 0
        AND jms.mo_in_st_id > 0
		and jmsl.mol_type=1
UNION ALL
SELECT  jmsl.mol_color_id as color_id,
        jms.mo_in_st_id AS SID ,
        cid = 0 ,
        jmsl.mol_gi_id AS gid ,
         abs(jmsl.mol_num) AS gnum ,
        ISNULL(jmsl.mol_pm,'') AS pm ,
        countType = 1 ,
        myremark = '移入仓库' ,
        addtime = jmsl.mol_add_time ,
        orderno = mo_vo ,
        eoid = mo_id ,
        elid = molmcs_id ,
        mytype = 5 ,
		ISNULL(mol_box_num,0) as box_num,
		mol_boxbynum as boxbynum,
        order_add_time = jms.mo_add_time ,
        order_date = jms.mo_date ,
        jms.mo_cp_id ,
        jms.mo_erp_id ,
        'j_moStorage' AS table_name
FROM    j_moStorage AS jms
INNER JOIN j_moStorageListMergeColorSum AS jmsl ON jms.mo_id = jmsl.mol_mo_id
WHERE   jms.mo_status=2
        AND jmsl.mol_status = 1
        AND jmsl.mol_gi_id > 0
        AND jms.mo_in_st_id > 0
		and jmsl.mol_type=2
UNION ALL
 --盈亏明细
SELECT  jpsl.ppl_color_id as color_id,
        jps.pl_st_id AS SID ,
        cid = 0 ,
        jpsl.ppl_gi_id AS gid ,
        ABS(jpsl.ppl_num) AS gnum ,
        ISNULL(jpsl.ppl_pm,'') AS pm ,
        countType = (CASE WHEN jpsl.ppl_num >= 0 THEN 1
                          ELSE 0
                     END) ,
        myremark = '盈亏' ,
        addtime = jpsl.ppl_add_time ,
        orderno = jps.pl_vo ,
        eoid = jps.pl_id ,
        elid = jpsl.ppl_id ,
        mytype = 6 ,
		ABS(ISNULL(ppl_box_num,0)) as box_num,
		ppl_boxbynum as boxbynum,
        order_add_time = jps.pl_add_time ,
        order_date = jps.pl_date ,
        jps.pl_cp_id ,
        jps.pl_erp_id ,
        'j_plStorage' AS table_name
FROM    j_plStorage AS jps
INNER JOIN j_plStorageListMergeColorSum AS jpsl ON jps.pl_id = jpsl.ppl_pl_id 
         and jpsl.ppl_type=0
WHERE   jps.pl_status = 2
        AND jpsl.ppl_status = 1
        AND jpsl.ppl_gi_id > 0
        AND jps.pl_st_id > 0
UNION ALL
--盘点,整仓盘点库存抵消
SELECT  js.sl_color_id as color_id,
        js.sl_seiid AS SID ,
        cid = 0 ,
        js.sl_giid AS gid ,
        js.sl_number AS gnum ,
        ISNULL(js.sl_pm,'') AS pm ,
        js.sl_counttype ,
        js.sl_remark ,
        js.sl_addtime ,
        js.sl_order_no ,
        js.sl_eoid ,
        js.sl_elid ,
        mytype = 7 ,--前台可以此为条件,不显示
		js.sl_box_num as box_num,
		js.sl_boxbynum as boxbynum,
        order_add_time = js.sl_order_add_time ,
        order_date = js.sl_order_date ,
        js.sl_cp_id ,
        js.sl_erp_id ,
        'j_stocklog_pal' AS table_name
FROM    j_stocklog_palMergeColorSum AS js
WHERE   js.sl_status = 2
        AND js.sl_giid > 0
        AND js.sl_seiid > 0
UNION ALL
--整仓盘点,盘点明细
SELECT  vt.sl_color_id as color_id,
        vt.sl_seiid AS SID ,
        cid = 0 ,
        vt.sl_giid ,
        vt.sl_number ,
        ISNULL(vt.sl_pm,'') ,
        vt.sl_counttype ,
        vt.sl_remark ,
        vt.sl_addtime ,
        vt.sl_order_no ,
        vt.sl_eoid ,
        vt.sl_elid ,
        vt.sl_type ,
		vt.sl_box_num as box_num,
		vt.sl_boxbynum as boxbynum,
        vt.sl_order_add_time ,
        vt.sl_order_date ,
        vt.sl_cp_id ,
        vt.sl_erp_id ,
        'j_stocklog_pal' AS table_name
FROM    j_stocklog_palMergeColorSum AS vt
WHERE   vt.sl_status = 1
        AND vt.sl_giid > 0
        AND vt.sl_seiid > 0
go

