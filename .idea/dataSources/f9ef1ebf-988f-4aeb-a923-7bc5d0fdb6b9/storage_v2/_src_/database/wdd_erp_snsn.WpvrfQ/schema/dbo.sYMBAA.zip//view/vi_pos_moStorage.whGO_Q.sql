CREATE VIEW [dbo].[vi_pos_moStorage] AS 
SELECT
	mo_id,
	mo_sh_id,
	mo_vo,
	CONVERT (VARCHAR(10), mo_date, 120) AS mo_date,
	mo_no,
	mo_out_st_id,
	mo_in_st_id,
	mo_order_man,
	(
		SELECT
			sei_name
		FROM
			dbo.pos_storageInfo AS bs WITH (NOLOCK)
		WHERE
			(sei_id = jis.mo_in_st_id)
	) AS mo_in_st_id_txt,
	(
		SELECT
			sei_name
		FROM
			dbo.pos_storageInfo AS bs WITH (NOLOCK)
		WHERE
			(sei_id = jis.mo_out_st_id)
	) AS mo_out_st_id_txt,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			(si_id = jis.mo_order_man)
	) AS mo_order_man_txt,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			(si_id = jis.mo_add_man)
	) AS mo_add_man_txt,
	mo_add_man,
	mo_add_time,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			(si_id = jis.mo_update_man)
	) AS mo_update_man_txt,
	mo_update_man,
	mo_update_time,
	(
		SELECT
			si_name
		FROM
			dbo.b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			(si_id = jis.mo_audit_man)
	) AS mo_audit_man_txt,
	mo_audit_man,
	mo_audit_time,
	mo_remark,
	mo_status,
	(
		SELECT
			SUM (mol_num)
		FROM
			pos_moStorageList WITH (NOLOCK)
		WHERE
			mol_mo_id = jis.mo_id
		AND mol_status > 0
	) AS sumnum,
	(
		SELECT
			SUM (mol_money)
		FROM
			pos_moStorageList WITH (NOLOCK)
		WHERE
			mol_mo_id = jis.mo_id
		AND mol_status > 0
	) AS summoney
FROM
	dbo.pos_moStorage AS jis WITH (NOLOCK)
go

