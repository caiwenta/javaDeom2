CREATE VIEW [dbo].[vi_page_oper_info] AS 
select soi.oi_name,spo.po_oi_id,spo.po_pi_id,spo.po_id,spo.po_remark
  from s_page_oper as spo inner join s_oper_info as soi on spo.po_oi_id=soi.oi_id inner join s_pageInfo as spi on spo.po_pi_id=spi.pi_id
where soi.oi_status=1 and spi.pi_status=1
go

