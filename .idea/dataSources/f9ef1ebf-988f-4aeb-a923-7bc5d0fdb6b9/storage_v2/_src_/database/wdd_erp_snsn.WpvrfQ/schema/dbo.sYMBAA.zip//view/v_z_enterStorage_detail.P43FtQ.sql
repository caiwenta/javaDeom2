

CREATE  VIEW [dbo].[v_z_enterStorage_detail] AS 
select
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
(CASE WHEN rulenum.gd_row_number IS NULL THEN '' ELSE 'spec' + CONVERT(VARCHAR,rulenum.gd_row_number) END) AS specno ,
(select gd_code from s_goodsruledetail where gd_id=size)sizecode, --尺码编码
(select gd_code from s_goodsruledetail where gd_id=col)colorcode, --颜色编码
(select gd_code from s_goodsruledetail where gd_id=size)spec_code, --尺码编码
(select gd_code from s_goodsruledetail where gd_id=col)color_code, --颜色编码
rulenum.gd_row_number,
enterlist.*,
rulenum.gd_code as rulecode

from 
(

select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
--ISNULL((CASE WHEN(SELECT gs_remark FROM dbo.s_goodsrule WHERE gs_id=group2)='颜色' THEN rule2 ELSE rule1 END),0) AS col, 
--ISNULL((CASE WHEN(SELECT gs_remark FROM dbo.s_goodsrule WHERE gs_id=group2)='颜色' THEN group2 ELSE group1 END),0) AS colorid, 
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
isnull(grl.colorid,0) as col,
isnull(grl.colorgroupid,0) as colorid,
enter.* , 


(CASE WHEN grl.gss_id IS NULL THEN enter.gi_retailprice ELSE  grl.gs_marketprice END) AS gs_marketprice,--零售价
(CASE WHEN grl.gss_id IS NULL THEN enter.gi_costprice ELSE  grl.gs_costprice END) AS gs_costprice --成本价
from
(

SELECT
ge.eo_id, 
st.el_id,
st.el_eoid,
ge.eo_type,
(case WHEN ge.eo_type=0 then '入库' else '退货'end)eotype,  --单据类型
ge.eo_cp_id,
cp.cp_name as eo_cp_name,
cp.cp_code as eo_cp_code,
(
case when eo_source_type=1 then
     (

	   --SELECT top 1 pl_vo FROM j_purchaseStorage jp 
	   --                 where eo_source_id=jp.pl_id  
	   --                 AND pl_status > 0
	 select pl_vo from j_purchaseStorage where  pl_id=(select pll_pl_id from j_purchaseStorageList where pll_id=(select  el_source_id from  j_enterStorageList where el_eoid=ge.eo_id and el_id=st.el_id)) AND pl_status > 0
	 )
     when eo_source_type=2 then
	 (SELECT top 1  oo_no FROM j_outStorage WHERE oo_id=eo_source_id AND oo_status<>0)
end
)
as pl_vo,


ge.eo_erp_id as erp_id,

 
ge.eo_no,--凭证号
ge.eo_manual,--单据号
CONVERT(varchar(100), ge.eo_entrydate, 23) as eo_entrydate,--入库日期

ge.eo_siid,
sg.sei_name,--仓库名称
sg.sei_code,--仓库编号
gi.gi_id,
gi.gi_skuid,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi_factoryprice,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码

gi.gi_retailprice,--零售价
gi.gi_costprice,--成本价

isnull(st.el_number,0) as num,--规格数量

spi.si_name,--供应商
spi.si_code,--供应商代号
ui.ut_name,--单位
st.el_skuid,--skuid
st.el_siid,
st.el_pm,
isnull((CASE WHEN eo_type=1 THEN  -el_number ELSE el_number END),0) AS el_number,--数量
isnull((CASE WHEN eo_type=0 THEN  el_number ELSE 0 END),0) AS eo_number,--入库数量
isnull((CASE WHEN eo_type=1 THEN  -el_number ELSE 0 END),0) AS eo_returnnum,--退货数量
isnull(st.el_unit,0) as el_unit,--零售价
ISNULL(st.el_totalintegral,0) AS el_totalintegral,--积分
isnull(st.el_discount,0) as el_discount,--折率
isnull(st.el_costprice,0) as el_costprice,--进货价
isnull((CASE WHEN eo_type=1 THEN  -el_realmoney ELSE el_realmoney END),0) AS el_realmoney,--入库金额（合计金额）
isnull((CASE WHEN eo_type=1 THEN  -el_realmoney ELSE 0 END),0) AS eo_returnrealmoney,--退货金额
ISNULL((CASE WHEN ge.eo_type = 0 THEN el_realmoney ELSE 0 END),0) AS eo_realmoney ,--入库金额(不含退货)

isnull(((CASE WHEN eo_type=1 THEN  -st.el_number ELSE st.el_number END) *st.el_unit),0) AS el_unit_money,--零售金额
isnull(st.el_box_num,0) as el_box_num,--箱数

el_integral,
ui.ut_name as gi_unit, --单位
el_pddate, --生产日期
el_addtime, --商品添加时间
takeman=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = eo_takemanid ) ,   --经手人
eo_addman_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs  WITH (NOLOCK) WHERE si_id = eo_addman ) , --单据添加人

--CONVERT(varchar(7), eo_entrydate, 120 )as eo_month,--月份
(CONVERT(VARCHAR(10),YEAR(eo_entrydate))+'年'+CONVERT(VARCHAR(10),MONTH(eo_entrydate))+'月') AS eo_month , --月份
eo_addtime, --单据添加时间
eo_update_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = eo_updateman ), --单据修改人
eo_updatetime,  --单据修改时间
eo_lastman=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = eo_lastmanid), --单据审核人
eo_auditdate, --单据审核时间
eo_remark,  --备注
eo_status,  --单据状态
( SELECT in_vo FROM dbo.erp_instructionNotice AS eis  WITH (NOLOCK) left join dbo.erp_instructionObject AS eio  WITH (NOLOCK) ON eis.in_id=eio.io_in_id where eio.io_id=eo_io_id)instru_vo --指令单凭证号

FROM   j_enterStorage ge WITH (NOLOCK)
inner join  j_enterStorageList st WITH (NOLOCK) ON ge.eo_id = el_eoid AND st.el_status = 1 and ge.eo_status>0

LEFT JOIN companyinfo cp WITH (NOLOCK) ON cp.cp_id = ge.eo_cp_id

left join b_goodsinfo gi WITH (NOLOCK) on gi.gi_id=st.el_siid and gi_status=1
left join b_unit ui WITH (NOLOCK) on ui.ut_id=gi.gi_unit 
inner join b_supplierinfo spi WITH (NOLOCK) on spi.si_id= ge.eo_ciid --and spi.si_status=1
left join b_storageinfo sg WITH (NOLOCK) on ge.eo_siid=sg.sei_id


) as enter
left join b_goodsruleset  as grl on  grl.gss_id=enter.el_skuid

) as enterlist
LEFT JOIN s_goodsruledetail rulenum WITH (NOLOCK) ON rulenum.gd_id = enterlist.size
LEFT JOIN s_goodsruledetail colorrule WITH (NOLOCK) ON colorrule.gd_id = enterlist.col
go

