CREATE FUNCTION [dbo].[NowOrderCount](@Dateim DATETIME)
RETURNS VARCHAR(12)
AS
BEGIN

DECLARE @coun INT,@coun1 INT,
@CountStr VARCHAR(12)

SET @coun=0
SET @CountStr=''
SELECT @coun=COUNT(*) FROM pos_ogStorage WHERE og_date>=CONVERT(DATETIME,@Dateim) AND og_date<CONVERT(DATETIME,@Dateim)+1


IF(@coun=0)
BEGIN
	SET @CountStr='0001'
END 
ELSE
BEGIN
	SET @coun1=4-LEN(@coun)
	while(@coun1>0 )
    BEGIN
    	SET @CountStr= @CountStr+'0'
    	SET @coun1 = @coun1-1;
    END
SET @CountStr=@CountStr+CONVERT(VARCHAR(12),@coun+1)
	END
RETURN @CountStr


END
go

