CREATE Proc [dbo].[pro_modify_gss_no]
@old VARCHAR(50)='',
@new VARCHAR(50)=''
AS
IF EXISTS(SELECT * FROM b_goodsruleset bg WHERE bg.gss_no=@old)
BEGIN
 IF EXISTS(SELECT * FROM b_goodsruleset bg WHERE bg.gss_no=@new)
 BEGIN
  SELECT '新条形码已被使用!';
 END
 ELSE
 BEGIN
  UPDATE b_goodsruleset
  SET gss_no = @new WHERE gss_no=@old;
  SELECT '更新成功!刷新下页面看看!';
 END
END
ELSE
BEGIN
 SELECT '旧条形码不存在!';
END


go

