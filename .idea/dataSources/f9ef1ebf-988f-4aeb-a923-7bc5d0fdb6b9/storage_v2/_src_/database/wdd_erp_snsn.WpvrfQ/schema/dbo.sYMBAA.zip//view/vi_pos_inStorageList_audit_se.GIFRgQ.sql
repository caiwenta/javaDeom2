CREATE VIEW [dbo].[vi_pos_inStorageList_audit_se] AS 
SELECT
	p1.*, p2.inl_num AS inl_num_ed
FROM
	(
		SELECT
			inl_in_id,
			inl_gi_id,
			inl_add_time,
			inl_type,
			SUM (inl_num) AS inl_num,
			MIN (inl_id) AS inl_id,
			inl_sku_id AS inl_sku_id,
			SUM (inl_money) AS inl_money,
			CONVERT (
				DECIMAL (10, 2),
				AVG (inl_retail_price)
			) AS inl_retail_price,
			CONVERT (
				DECIMAL (10, 2),
				AVG (inl_stock_price)
			) AS inl_stock_price,
			CONVERT (
				DECIMAL (10, 2),
				AVG (inl_discount)
			) AS inl_discount,
			inl_pm,
			inl_box_num
		FROM
			dbo.vi_pos_inStorageList_audit AS jt WITH (NOLOCK)
		GROUP BY
			inl_in_id,
			inl_gi_id,
			inl_sku_id,
			inl_type,
			inl_pm,
			inl_box_num,
			inl_add_time
	) AS p1
LEFT JOIN (
	--得到已入库数量
	SELECT
		in_source,
		in_source_id,
		inl_gi_id,
		inl_sku_id,
		SUM (inl_num) AS inl_num,
		inl_source_add_time
	FROM
		vi_pos_inStorageList_entered WITH (NOLOCK)
	GROUP BY
		in_source,
		in_source_id,
		inl_gi_id,
		inl_sku_id,
		inl_source_add_time
) AS p2 ON p1.inl_gi_id = p2.inl_gi_id
AND p1.inl_sku_id = p2.inl_sku_id
AND p1.inl_add_time = p2.inl_source_add_time
AND p1.inl_type = p2.in_source
AND p1.inl_in_id = p2.in_source_id
go

