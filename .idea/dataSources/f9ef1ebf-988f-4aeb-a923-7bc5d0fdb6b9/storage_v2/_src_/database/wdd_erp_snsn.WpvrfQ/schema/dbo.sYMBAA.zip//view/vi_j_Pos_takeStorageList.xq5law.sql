CREATE VIEW [dbo].[vi_j_Pos_takeStorageList] AS 
SELECT
	tsl_ts_id,
	tsl_gi_id,
	tsl_add_time,
	SUM (tsl_old_num) AS tsl_old_num,
	SUM (tsl_new_num) AS tsl_new_num,
	SUM (tsl_log_num) AS tsl_log_num,
	MIN (tsl_id) AS tsl_id,
	MAX (tsl_sku_id) AS tsl_sku_id,
	AVG (tsl_stock_price) AS tsl_stock_price,
	SUM (tsl_old_money) AS tsl_old_money,
	SUM (tsl_new_money) AS tsl_new_money,
	SUM (tsl_log_money) AS tsl_log_money,
	MAX (replace(tsl_pm, '*', ',')) AS tsl_pm,
	MAX (tsl_box_num) AS tsl_box_num
FROM
	dbo.pos_takeStorageList AS jt  WITH (NOLOCK)
WHERE
	(tsl_status = 1)
GROUP BY
	tsl_ts_id,
	tsl_gi_id,
	tsl_add_time
go

