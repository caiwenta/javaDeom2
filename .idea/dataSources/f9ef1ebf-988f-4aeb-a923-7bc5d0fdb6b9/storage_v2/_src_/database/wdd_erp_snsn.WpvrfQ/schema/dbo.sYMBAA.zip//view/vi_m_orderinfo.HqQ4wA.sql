CREATE VIEW [dbo].[vi_m_orderinfo] AS 
SELECT mo.*,
       mo2.og_id,
       mo2.og_serialid,
       mo2.og_goodsno,
       mo2.og_goodsid,
       mo2.og_title,
       mo2.og_picurl,
       mo2.og_buynum,
       mo2.og_marketprice,
       mo2.og_buyprice,
       mo2.og_actualprice,
       mo2.gs_id,
       mo2.gs_name,
       mo2.gs_weight,
       mo2.gs_status,
       mo2.gs_ys,
       (og_actualprice * og_buynum)  AS totalmoney,
       bc.ci_name,
       bc.ci_linkman,
       bc.ci_phone,
       p1.gi_unit,
       p1.gi_types
FROM   m_orderinfo mo
       INNER JOIN m_ordergoods mo2
            ON  mo.oi_id = mo2.oi_id
       INNER JOIN b_clientinfo bc
            ON  mo.oi_uid = bc.ci_id
       LEFT JOIN (
                SELECT bg.gi_id,
                       bg.gi_unit,
                       bg2.gss_no,
                       bg.gi_types
                FROM   b_goodsinfo bg
                       LEFT JOIN b_goodsruleset bg2
                            ON  bg.gi_id = bg2.gi_id
            )                        AS p1
            ON  mo2.og_goodsid = p1.gss_no
go

