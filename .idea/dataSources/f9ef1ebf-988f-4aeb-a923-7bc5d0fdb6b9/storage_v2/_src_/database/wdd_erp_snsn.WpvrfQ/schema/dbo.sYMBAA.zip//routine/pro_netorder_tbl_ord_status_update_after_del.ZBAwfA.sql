CREATE PROC [dbo].[pro_netorder_tbl_ord_status_update_after_del] @ord_id INT
AS
    BEGIN
        UPDATE  netorder_occupy_tbl
        SET     o_status = 0
        WHERE   o_ord_id = @ord_id
				AND o_status <> 0;
        
		IF @@ROWCOUNT > 0
		   EXEC pro_update_occupy_num @id = @ord_id;
    END
go

