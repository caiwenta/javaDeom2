CREATE PROC [dbo].[pro_mergeStockLog]
       @cp_id INT = 0 ,
       @negative_inventory INT = 0 ,--产生了负库存是否提示
       @old_sei_id INT = 0 ,
       @new_sei_id INT = 0 ,
	   @obj_id INT = 0,
	   @obj_type INT = 0
AS
BEGIN

	        BEGIN TRY

			print N'开始事务'
			BEGIN TRAN
			
			DECLARE @now DATETIME = GETDATE();
	        DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';

			print N'验证数据'
	        EXEC pro_mergeStockLog_check
			@cp_id = @cp_id ,
			@negative_inventory = @negative_inventory ,
			@old_sei_id = @old_sei_id ,
			@new_sei_id = @new_sei_id

			print N'删除旧明细'
            DELETE j_stocklog WHERE sl_cp_id=@cp_id;

			print N'重新合并明细'
			INSERT j_stocklog(
					 sl_eoid ,
                     sl_elid ,
                     sl_seiid ,
					 sl_location,
                     sl_ciid ,
                     sl_giid ,
                     sl_skuid ,
                     sl_type ,
                     sl_counttype ,
                     sl_number ,
                     sl_addtime ,
                     sl_updatetime ,
                     sl_remark ,
                     sl_status ,
                     sl_order_no ,
                     sl_order_date ,
                     sl_order_add_time ,
                     sl_cp_id ,
                     sl_erp_id ,
                     sl_pm
			)
		 SELECT
									so.eoid ,
                                     so.elid ,
                                     so.[sid],
									 ISNULL(so.locationid,0),
                                     so.cid ,
                                     so.gid ,
                                     so.skuid ,
                                     so.mytype ,
                                     so.countType ,
                                     so.gnum ,
                                     so.addtime ,
                                     @now ,
                                     so.myremark ,
                                     1 ,
                                     so.orderno ,
                                     so.order_date ,
                                     so.order_add_time ,
                                     so.cp_id ,
                                     so.eo_erp_id ,
                                     ISNULL(so.pm,'')
           from vi_stockList AS so
		   inner join b_goodsinfo as bgi on so.gid=bgi.gi_id and bgi.gi_status<>0 
           WHERE  so.cp_id = @cp_id 
		   AND so.eoid = (CASE WHEN @obj_id > 0 THEN  @obj_id  ELSE so.eoid END)
		   AND so.mytype = (CASE WHEN @obj_type > 0 THEN  @obj_type  ELSE so.mytype END)
	
            print N'明细汇总库存'
            EXEC pro_mergeStockSum @cp_id = @cp_id

            print N'明细汇总仓位库存'
			EXEC pro_mergeStocklocationSum  @cp_id = @cp_id
	        
			print N'明细汇总批号库存'
			EXEC pro_mergeStockBatchCodeSum  @cp_id = @cp_id

			print N'提交事务'
			COMMIT TRAN

			END TRY
			BEGIN CATCH
				SET @ERROR_MESSAGE = ERROR_MESSAGE();
				ROLLBACK TRANSACTION;
			END CATCH

			if @ERROR_MESSAGE<>''
				RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);

END
go

