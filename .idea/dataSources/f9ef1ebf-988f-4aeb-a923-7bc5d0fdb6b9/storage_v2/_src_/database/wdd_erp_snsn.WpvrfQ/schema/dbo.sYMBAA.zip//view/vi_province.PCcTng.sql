CREATE VIEW [dbo].[vi_province] AS 
Select * From sys_chinalibrary_tbl Where provinceid=0 
--And diming Not In (
--'北京','天津','上海','重庆','香港特别行政区','澳门特别行政区' 	
--)
go

