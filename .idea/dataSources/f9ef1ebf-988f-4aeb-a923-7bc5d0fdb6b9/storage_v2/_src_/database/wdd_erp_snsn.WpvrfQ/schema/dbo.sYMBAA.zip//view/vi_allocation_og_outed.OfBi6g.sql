



CREATE VIEW [dbo].[vi_allocation_og_outed]
AS
SELECT jos.og_id,
       josl.ogl_id,
       josl.ogl_gi_id,
       josl.ogl_num,
       josl.ogl_add_time
FROM   pos_ogStorage                 AS jos
       INNER JOIN pos_ogStorageList  AS josl
            ON  jos.og_id = josl.ogl_og_id
WHERE  josl.ogl_status = 1
       AND jos.og_status > 0


go

