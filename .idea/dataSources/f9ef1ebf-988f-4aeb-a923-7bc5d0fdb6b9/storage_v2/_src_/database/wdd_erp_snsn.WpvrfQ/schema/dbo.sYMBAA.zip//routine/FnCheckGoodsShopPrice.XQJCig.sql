CREATE FUNCTION [dbo].[FnCheckGoodsShopPrice]
(@gi_belong int,
 @costprice decimal(18,2),
 @gi_id int,
 @gi_skuid int,
 @sh_id int
)
RETURNS decimal(18,2)
AS
BEGIN
	 DECLARE @re decimal(18,2)=0;

	 IF @gi_belong=1
	 BEGIN

		SELECT 
			@re=sp_costprice 
		FROM erp_goodsshopprice 
		WHERE gi_id=@gi_id AND gi_skuid=@gi_skuid and sh_id=@sh_id;


		IF @re<=0
		begin
			SET @re=@costprice;
		end


	 END
	 ELSE
	 BEGIN
	   SET @re=@costprice;
	 END


	 RETURN @re;
END
go

