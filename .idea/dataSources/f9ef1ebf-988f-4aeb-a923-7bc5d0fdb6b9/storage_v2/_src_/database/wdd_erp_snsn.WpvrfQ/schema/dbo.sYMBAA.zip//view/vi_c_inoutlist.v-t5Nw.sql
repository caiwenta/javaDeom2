CREATE VIEW [dbo].[vi_c_inoutlist]
AS
    SELECT  qcje = ISNULL(( SELECT  cb.bk_qcje
                            FROM    c_bankinfo cb WITH ( NOLOCK )
                            WHERE   cb.bk_id = iol.bk_id
                          ), 0) ,
            iol_id ,
            iol_itid ,
            cit.it_name AS iol_itname ,
            iol_ciid ,
            CASE iol_type
              WHEN 1 THEN cli.ci_name
              WHEN 2 THEN spi.si_name
              ELSE ''
            END AS iol_ciname ,
            iol_shid ,
            psh.sh_name AS iol_shname ,
            iol_cpid ,
            cpi.cp_name AS iol_cpname ,
            iol_type ,
            iol_money ,
            iol_indate = CONVERT(VARCHAR(50), iol_indate, 23) ,
            iol_takeman ,
            iol_lastman ,
            iol_remark ,
            Audittime ,
            Audit ,
            iol_lastmancode ,
            iol_rumoney ,
            iol_chumoney ,
            iol.bk_id ,
            iol_status ,
            iol_cp_id ,
            iol_di_id ,
            iol_erp_id ,
            iol_vo ,
            iol_audit_ed ,
            pzone ,
            pztwo ,
            pzthree ,
            iol_row_num ,
            cbk.bk_no ,
            cbk.bk_name ,
            ISNULL(cip.it_id, 0) AS it_id_parent ,
            ISNULL(cip.it_name, '顶级科目') AS it_name_parent
    FROM    c_inoutlist iol WITH ( NOLOCK )
            LEFT JOIN c_bankinfo cbk ON cbk.bk_id = iol.bk_id
            LEFT JOIN c_infotype cit ON cit.it_id = iol.iol_itid
            LEFT JOIN c_infotype cip ON cip.it_id = cit.it_parent
            LEFT JOIN pos_shop psh ON psh.sh_id = iol.iol_shid
                                      AND iol.iol_type = 1
            LEFT JOIN companyinfo cpi ON cpi.cp_id = iol.iol_cpid
                                         AND iol.iol_type = 1
            LEFT JOIN b_clientinfo cli ON cli.ci_id = iol.iol_ciid
                                          AND iol.iol_type = 1
            LEFT JOIN b_supplierinfo spi ON spi.si_id = iol.iol_ciid
                                            AND iol.iol_type = 2
    WHERE   iol.iol_status > 0
go

