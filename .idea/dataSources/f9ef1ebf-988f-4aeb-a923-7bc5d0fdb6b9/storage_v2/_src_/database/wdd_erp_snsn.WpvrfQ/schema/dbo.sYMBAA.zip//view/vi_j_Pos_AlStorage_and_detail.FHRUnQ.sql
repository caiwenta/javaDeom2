CREATE VIEW [dbo].[vi_j_Pos_AlStorage_and_detail] AS 
SELECT jt.al_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.pos_alStorage                 AS jt
       INNER JOIN dbo.pos_alStorageList  AS jt1
            ON  jt.al_id = jt1.all_al_id
       INNER JOIN dbo.b_goodsinfo   AS bg
            ON  jt1.all_gi_id = bg.gi_id
WHERE  (jt1.all_status = 1)
       AND (jt.al_status <> 0)
go

