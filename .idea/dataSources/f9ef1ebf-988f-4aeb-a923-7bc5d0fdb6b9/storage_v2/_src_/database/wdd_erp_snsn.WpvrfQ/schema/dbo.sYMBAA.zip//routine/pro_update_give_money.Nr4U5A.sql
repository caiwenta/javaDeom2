CREATE Proc [dbo].[pro_update_give_money]
@order_id INT=0,
@type VARCHAR(50)=''
AS


DECLARE @no VARCHAR(50)='';
DECLARE @cp_id INT=0;
DECLARE @oo_cash INT=0;
IF @type='出库'
BEGIN
	
SELECT @no=jos.oo_no,@cp_id=jos.oo_cp_id,@oo_cash=jos.oo_cash
  FROM j_outStorage jos WHERE jos.oo_id=@order_id
  
UPDATE c_fundorder 
SET 
fo_realmoney =fd.moneyed,
fo_givemoney = fd.giftedmoney,
fo_thiyetmoney=(case when @oo_cash =1 then fd.moneyed else 0 end)--本期收款
FROM 
c_fundorder cf,(
SELECT ISNULL( SUM(CASE WHEN ISNULL( josl.ol_gift,0)=1 THEN  josl.ol_realmoney ELSE 0 END),0) AS giftedmoney, ISNULL( SUM(CASE WHEN ISNULL( josl.ol_gift,0)=0 THEN  josl.ol_realmoney ELSE 0 END),0) AS moneyed FROM j_outStorageList josl WHERE josl.ol_eoid=@order_id
AND josl.ol_status>0	
) fd WHERE cf.fo_orderid=@no AND cf.fo_cp_id=@cp_id

END
ELSE IF @type='入库'
BEGIN
SELECT @no=jos.eo_no,@cp_id=jos.eo_cp_id
FROM j_enterStorage jos WHERE jos.eo_id=@order_id

UPDATE c_fundorder 
SET 
fo_realmoney =fd.moneyed,
fo_givemoney = fd.giftedmoney,
fo_givemoney_integral=fd.el_gift_integral,
fo_realmoney_integral=el_totalintegral
FROM 
c_fundorder cf,(
SELECT 
ISNULL(SUM(CASE WHEN ISNULL( josl.el_gift,0)=1 THEN  josl.el_realmoney ELSE 0 END),0) AS giftedmoney,
ISNULL(SUM(CASE WHEN ISNULL( josl.el_gift,0)=0 THEN  josl.el_realmoney ELSE 0 END),0) AS moneyed, 

ISNULL(SUM(CASE WHEN ISNULL( josl.el_gift,0)=0 THEN  el_totalintegral ELSE  0 END),0) AS el_totalintegral
,
ISNULL(SUM(CASE WHEN isnull(josl.el_gift,0)=1 THEN  el_totalintegral ELSE  0 END),0) AS el_gift_integral

FROM j_enterStorageList josl WHERE josl.el_eoid=@order_id
AND josl.el_status>0	
) fd WHERE cf.fo_orderid=@no AND cf.fo_cp_id=@cp_id
END



Declare @id Int=0;
Declare @old_ciid Int=0;
Declare @old_bs Varchar(50)='';
DECLARE @fo_type INT=0;
DECLARE @fo_to_cpid INT=0;
DECLARE @fo_shid INT=0;

SELECT
	TOP 1
	@id = fo_id,
	@old_bs = fo_bs
	,@old_ciid = fo_ciid,
	@fo_to_cpid=fo_to_cpid,
	@fo_shid=fo_shid,
	@fo_type=fo_type
FROM c_fundorder cf WHERE fo_orderid=@no AND fo_cp_id=@cp_id
AND cf.fo_status>0

EXEC pro_merge_c_fundorder
	@fo_bs = @old_bs,
	@fo_ciid = @old_ciid,
	@fo_id = 0,
	@fo_shid=@fo_shid,
	@fo_to_cpid=@fo_to_cpid,
	@operate_type = '计算客户供应商固化数据';
go

