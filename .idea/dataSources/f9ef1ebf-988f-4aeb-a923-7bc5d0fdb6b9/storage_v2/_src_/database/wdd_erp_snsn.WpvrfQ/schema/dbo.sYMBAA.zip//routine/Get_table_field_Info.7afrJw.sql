CREATE Function [dbo].[Get_table_field_Info](@tableName Varchar(100))
Returns @t Table(
	fieldName Varchar(50),
	typeName Varchar(50),
	typeLength Int	
)
As
Begin
	
	Insert into @t select syscolumns.name, systypes.name, 
	length= case when systypes.name='decimal' then 
	syscolumns.length *2 else syscolumns.length end
	               
	               from syscolumns    
  left join systypes on syscolumns. xusertype =systypes. xusertype  
  where id=(select id from sysobjects where name=@tableName);
  Return
	End
go

