CREATE  PROCEDURE [dbo].[pro_mergeOccupy_check]
	@cp_id int = 0,
	@sei_id INT = 0
AS

DECLARE @negative_inventory INT=0;
DECLARE @result_var VARCHAR(1000) = '';
DECLARE @bool_need_error INT = 0;


SELECT @negative_inventory=isnull(sei_is_negative_occupyinventory,0) 
FROM b_storageinfo AS bs WHERE sei_id=@sei_id

if @negative_inventory=1
begin

--ISNULL(bs.si_occupy_num,0)
IF EXISTS (
SELECT * FROM (SELECT enable_stock_num=bs.si_number-(ISNULL(bs.si_allocationoccupy_num,0)+ISNULL(bs.si_orderblankoccupy_num,0)) FROM b_stockinfo AS bs 
WHERE bs.si_seiid=@sei_id AND bs.si_cp_id=@cp_id  ) AS fd WHERE enable_stock_num<0)
BEGIN
	SET @result_var = '可用库存不足，不允许配货!';
    SET @bool_need_error = 1;
	GOTO theEnd;
END

end

theEnd:
     IF @bool_need_error = 1
     RAISERROR (@result_var,16,2,N'number',5);
go

