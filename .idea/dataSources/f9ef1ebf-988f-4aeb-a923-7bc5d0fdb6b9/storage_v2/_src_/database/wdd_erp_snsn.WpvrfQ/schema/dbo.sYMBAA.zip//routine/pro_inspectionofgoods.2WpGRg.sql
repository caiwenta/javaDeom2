CREATE PROCEDURE dbo.pro_inspectionofgoods
@gi_id int,
@sku_id int,
@var_num int,
@pm varchar(500),
@orderid int,
@iog_source_id int,
@warehousingtype int,
@iog_erp_id int
AS

if exists(select * from erp_inspectionofgoods where orderid=@orderid and warehousingtype=@warehousingtype and gi_id=@gi_id and sku_id=@sku_id)
begin

UPDATE erp_inspectionofgoods SET 
var_num = @var_num
WHERE 
gi_id=@gi_id and sku_id=@sku_id and orderid=@orderid and warehousingtype=@warehousingtype  

end
else
begin

INSERT INTO erp_inspectionofgoods(
gi_id,sku_id,var_num,pm,orderid,iog_source_id,warehousingtype,iog_erp_id,iog_status,iog_add_time
)VALUES(
	@gi_id,@sku_id,@var_num,@pm,@orderid,@iog_source_id,@warehousingtype,@iog_erp_id,1,GETDATE()
)
end
go

