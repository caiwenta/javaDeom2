
CREATE view [dbo].[vi_supplier_address]
as
	select  ci_id as id,ci_province as province,ci_city as city from b_clientinfo where ci_province !=' 无'
		union all select sh_id, replace(province,'省','')as province ,city from pos_shop where province!=''
		union all select cp_id,cp_province,cp_city from companyinfo where cp_is_zorf != 1 and cp_province !=' 无'

go

