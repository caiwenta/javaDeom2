








CREATE PROC [dbo].[pro_allocationList_sku_search_tb]
@all_al_id INT = 0,
@all_add_time DATETIME = '2004-10-17',
@date VARCHAR(30) ='',
@gi_id INT,--客户
@ci_id INT,--店铺
@sh_id INT,--分公司
@to_cp_id INT,
@type INT,
@do_type INT=0,
@cp_id INT = 0,
@cpzorf_id int=0,
@all_pm  varchar(500)='',
@colorid INT=0
AS
DECLARE @ghj DECIMAL(9, 2) = 0;
DECLARE @ghj_type INT = 0
--吊牌价
--DECLARE @dpj DECIMAL(9,2) = 0 ;
DECLARE @lsj       DECIMAL(9, 2) = 0;





IF @do_type=0
BEGIN
	
SELECT [all_id],
       [all_al_id],
       [all_gi_id],
       [all_sku_id],
       [all_retail_price],
       [all_retail_money],
       [all_discount],
       [all_stock_price],
       all_num,
       [all_gift],
       [all_status],
       [all_source_id],
       [all_source_add_time],
	   supplyprice,
	   discount,
       all_box_num,
       all_pm,
       ol_number,
       ogl_num,
       rel_num,
       bg.*,
       bg2.gi_name,
       bg2.gi_code,
       (all_num -ol_number)  AS all_wc_num,
       (ogl_num -all_num)    AS ogl_num1,
       all_num               AS all_num_wzx,
       (all_num -ol_number)  AS all_num_rk,
       all_money
       INTO #p
FROM   b_goodsruleset        AS bg
       LEFT JOIN (

                SELECT jisl.*,
                       ISNULL(ed.ol_number, 0) AS ol_number,
                       ISNULL(ogl_num, 0) AS ogl_num,
                       (
                           SELECT rel.rel_num
                           FROM   pos_reStorage re
                                  LEFT JOIN pos_reStorageList rel
                                       ON  rel.rel_re_id = re.re_id
                                  LEFT JOIN pos_allocation al
                                       ON  al.al_source_id = re.re_id
                           WHERE  re.re_status > 0
                                  AND rel.rel_status > 0
                                  AND rel.rel_id = jisl.all_source_id
                                  AND al_source = 2
                                  AND al_status > 0
                       ) AS rel_num
                FROM   pos_allocationList AS jisl
                       LEFT JOIN (
                                SELECT ol_source_id,
                                       SUM(OL_NUMBER) AS OL_NUMBER
                                FROM   vi_Allocation_OUTED
                                GROUP BY
                                       ol_source_id
                            ) ed
                            ON  ed.ol_source_id = jisl.all_id
                       LEFT JOIN (
                                SELECT ogl_id,
                                       SUM(ogl_num) AS ogl_num
                                FROM   vi_allocation_og_outed
                                GROUP BY
                                       ogl_id
                            ) red
                            ON  red.ogl_id = jisl.all_source_id
                WHERE  jisl.all_al_id = @all_al_id
                       AND jisl.all_status = 1 
					   and isnull(jisl.all_pm,'')=isnull(@all_pm,'')

		    )                AS p1
            ON  bg.gi_id = p1.all_gi_id AND bg.gss_id = p1.all_sku_id 
			LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;

END
IF @do_type=1
BEGIN
	
	
	SELECT bg.*,p1.*,goo.gi_code,goo.gi_name INTO #p1
	FROM   b_goodsruleset  AS bg
	    LEFT JOIN (
	    	      SELECT 
	    	      all_id, all_al_id, all_gi_id, all_sku_id, 
	    	      (all_num-ISNULL(fd.ol_number,0)-ISNULL(jisl.all_pause_num,0)) AS all_num, 
				  all_retail_price, 
				  all_retail_money, 
				  all_discount, 
				  all_stock_price, 
				  all_money, 
				  all_gift, 
				  all_status,
				  all_add_time, 
				  all_source_id, 
				  all_source_add_time, 
				  (isnull(jisl.all_box_num,0)-isnull(fd.ol_box_num,0)-ISNULL(jisl.all_pause_box_num,0)) as all_box_num,
				  all_pm,supplyprice,discount
	    	      FROM pos_allocationList AS jisl
	    	     LEFT JOIN
                (
						--查询已出库数量
                SELECT 
                       ol_source_id,
					   Sum(ol_box_num) as ol_box_num,
                       SUM(ol_number) AS ol_number
                FROM   vi_allocation_outed
                GROUP BY ol_source_id
                
                
                ) fd  ON fd.ol_source_id = jisl.all_id
                WHERE  jisl.all_al_id = @all_al_id
                       AND jisl.all_add_time = @all_add_time
					   and isnull(jisl.all_pm,'')=isnull(@all_pm,'')
                       AND jisl.all_status = 1
	    ) AS p1
	     ON  bg.gi_id = p1.all_gi_id
            AND bg.gss_id = p1.all_sku_id  inner join 
            b_goodsinfo goo on bg.gi_id=goo.gi_id
		WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;
		--------配货出库，供货价为配货管理设置的价格
		DECLARE @stock_price DECIMAL(9,2);
		SELECT TOP 1 @stock_price = all_stock_price FROM #p1 WHERE all_stock_price IS NOT NULL
		IF @stock_price IS NOT NULL
		BEGIN
			UPDATE #p1
			SET	   gs_purchase = @stock_price
		END
END
else if @do_type=3
begin
	
	SELECT bg.*,p1.*,goo.gi_code,goo.gi_name INTO #p2
	FROM   b_goodsruleset  AS bg
	    LEFT JOIN (
	    	      SELECT 
	    	      all_id, 
				  all_al_id, 
				  all_gi_id, 
				  all_sku_id, 
	    	      fd.ol_number AS all_num, 
				  all_retail_price, 
				  all_retail_money, 
				  all_discount, 
				  all_stock_price, 
				  all_money, 
				  all_gift, 
				  all_status, 
				  all_add_time, 
				  all_source_id, 
				  all_source_add_time, 
				  ol_box_num  as all_box_num,
				  all_pm,
				  supplyprice,
				  discount
	    	      FROM pos_allocationList AS jisl
	    	     LEFT JOIN
                (

				--查询已出库数量
                SELECT 
                       ol_source_id,
					   Sum(ol_box_num) as ol_box_num,
                       SUM(ol_number) AS ol_number
                FROM   vi_allocation_outed
                GROUP BY ol_source_id
                
                
                ) fd  ON fd.ol_source_id = jisl.all_id
                WHERE  jisl.all_al_id = @all_al_id
                       AND jisl.all_add_time = @all_add_time
					   and isnull(jisl.all_pm,'')=isnull(@all_pm,'')
                       AND jisl.all_status = 1
	    ) AS p1
	     ON  bg.gi_id = p1.all_gi_id
            AND bg.gss_id = p1.all_sku_id   inner join 
            b_goodsinfo goo on bg.gi_id=goo.gi_id
		WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;
end
else if @do_type=4
begin



SELECT bg.*,p1.*,goo.gi_code,goo.gi_name INTO #p4
	FROM   b_goodsruleset  AS bg
	    LEFT JOIN (
	    	      SELECT 
	    	       all_id, 
				   all_al_id, 
				   all_gi_id, 
				   all_sku_id, 
	    	      (ISNULL(jisl.all_pause_num,0)) AS all_num, 
				   all_retail_price, all_retail_money,
				   all_discount, all_stock_price, 
				   all_money, 
				   all_gift, 
				   all_status, 
				   all_add_time, 
				   all_source_id, 
				   all_source_add_time, 
				   all_pause_box_num as all_box_num, 
				   all_pm,
				   supplyprice,
				   discount
	    	      FROM pos_allocationList AS jisl
                WHERE  jisl.all_al_id = @all_al_id
                       AND jisl.all_add_time = @all_add_time
					   and isnull(jisl.all_pm,'')=isnull(@all_pm,'')
                       AND jisl.all_status = 1
	    ) AS p1
	     ON  bg.gi_id = p1.all_gi_id
            AND bg.gss_id = p1.all_sku_id  inner join 
            b_goodsinfo goo on bg.gi_id=goo.gi_id
		WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;
		--------配货出库，供货价为配货管理设置的价格



--SELECT bg.*,p1.*,goo.gi_code,goo.gi_name INTO #p4
--	FROM   b_goodsruleset  AS bg
--	    LEFT JOIN (
--	    	      SELECT 
--	    	      jisl.all_id, jisl.all_al_id, jisl.all_gi_id, jisl.all_sku_id, 
--	    	      fd.all_pause_num AS all_num, jisl.all_retail_price, jisl.all_retail_money, jisl.all_discount, jisl.all_stock_price, jisl.all_money, jisl.all_gift, jisl.all_status, jisl.all_add_time, all_source_id, jisl.all_source_add_time,jisl. all_box_num, jisl.all_pm
	    	      
--	    	      FROM pos_allocationList AS jisl
--	    	     LEFT JOIN
--                (
--						----查询终止数量
     
      
--                 SELECT     al.all_al_id, al.all_gi_id, al.all_add_time, CONVERT(VARCHAR(100), MIN(al.all_source_add_time), 25) AS all_source_add_time, SUM(al.all_pause_num) AS all_pause_num, SUM(al.all_num) 
--                      AS all_num, MIN(al.all_id) AS all_id, MAX(al.all_sku_id) AS all_sku_id, SUM(al.all_money) AS all_money, SUM(al.all_retail_money) AS all_retail_money, MIN(al.all_gift) AS all_gift, MAX(al.all_status) 
--                      AS all_status, CONVERT(DECIMAL(10, 2), AVG(al.all_retail_price)) AS all_retail_price, CONVERT(DECIMAL(10, 2), AVG(al.all_stock_price)) AS all_stock_price, CONVERT(DECIMAL(10, 2), 
--                      AVG(al.all_discount)) AS all_discount, MAX(REPLACE(al.all_pm, '*', ',')) AS all_pm, MAX(al.all_box_num) AS all_box_num
--FROM         dbo.pos_allocation AS fd INNER JOIN
--                      dbo.pos_allocationList AS al ON fd.al_id = al.all_al_id AND al.all_status > 0
--GROUP BY al.all_al_id, al.all_gi_id, al.all_add_time
                
                
--                ) fd  ON  fd.all_al_id = jisl.all_al_id
--            AND fd.all_gi_id = jisl.all_gi_id and jisl.all_id=fd.all_id
--            and jisl.all_add_time = fd.all_add_time
            
--                WHERE  jisl.all_al_id = @all_al_id
--                       AND jisl.all_add_time = @all_add_time
--                       AND jisl.all_status = 1
--	    ) AS p1
--	     ON  bg.gi_id = p1.all_gi_id
--            AND bg.gss_id = p1.all_sku_id   inner join 
--            b_goodsinfo goo on bg.gi_id=goo.gi_id
--		WHERE  bg.gi_id = @gi_id;
		
end








IF @cpzorf_id != 0
BEGIN
if EXISTS(SELECT c.cp_goods_type FROM  companyinfo c WHERE  c.cp_id = @cpzorf_id and cp_goods_type!=0)
		BEGIN

    SELECT @lsj = gd_price
    FROM   b_goods_discount
    WHERE  gd_gi_id = @gi_id
           AND gd_type IN (SELECT c.cp_goods_type
                           FROM   companyinfo c
                           WHERE  c.cp_id = @cpzorf_id)
           AND gd_class = 1
    
    IF @do_type = 0
    BEGIN
        UPDATE #p
        SET    gs_marketprice = @lsj
        
        UPDATE #p
        SET    gs_purchase = gs_marketprice * gs_discount
    END
    ELSE 
    IF @do_type = 1
    BEGIN
        UPDATE #p1
        SET    gs_marketprice = @lsj
        
        UPDATE #p1
        SET    gs_purchase = gs_marketprice * gs_discount
    END
END

END



DECLARE @discount  DECIMAL(9, 2) = 1
IF @do_type=0
BEGIN

declare @returntable table(
		cspid int,
		gi_id int,
		sku_id int,
		retailprice DECIMAL(9, 2),--零售价
		discount DECIMAL(9, 2),
		importprices DECIMAL(9, 2)    --供货价
)

IF @date !=''
BEGIN
	INSERT @returntable
	SELECT 
	cspid,gi_id,sku_id,retailprice,discount,importprices 
	FROM dbo.FnGoodsCustomPrice(@ci_id,@sh_id,@to_cp_id,@date,@gi_id,0,@cp_id)
END

if exists (select * from @returntable)  
begin

	update #p set
		  gs_marketprice=l.retailprice,
		  gs_salesprice= l.importprices,
		  gs_purchase = l.importprices,
		  gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id

end
else
begin
	INSERT @returntable
	SELECT
				0,
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
	FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,@ci_id,@sh_id,@to_cp_id,@type)
	 
	 update #p set
		        gs_salesprice= l.importprices,
				gs_purchase = l.importprices,
				gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id
end

SELECT * FROM #p

END
ELSE IF @do_type=1
	BEGIN
	SELECT * FROM #p1
	END
else if @do_type=3
	select * from #p2
else if @do_type=4
	select * from #p4
go

