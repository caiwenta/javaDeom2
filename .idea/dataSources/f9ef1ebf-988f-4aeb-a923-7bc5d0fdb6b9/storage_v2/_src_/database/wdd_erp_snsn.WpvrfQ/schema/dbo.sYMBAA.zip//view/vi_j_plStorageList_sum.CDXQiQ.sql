CREATE VIEW [dbo].[vi_j_plStorageList_sum]
	AS 
SELECT 
jmsl.ppl_pl_id,
(SELECT SUM(isnull(ppl_box_num,0)) FROM (
Select (case when fd.ppl_boxbynum=0 then 0 else ceiling(sum(fd.ppl_num)/fd.ppl_boxbynum) end) as ppl_box_num
From j_plStorageList fd where fd.ppl_status=1 AND fd.ppl_pl_id=jmsl.ppl_pl_id
GROUP BY fd.ppl_gi_id,isnull(fd.ppl_pm,''),fd.ppl_boxbynum
) AS BB
) AS ppl_boxnum,
SUM(ppl_num) AS ppl_num,
SUM(ppl_money) AS ppl_money
FROM j_plStorageList AS jmsl WHERE jmsl.ppl_status=1 
GROUP BY jmsl.ppl_pl_id
go

