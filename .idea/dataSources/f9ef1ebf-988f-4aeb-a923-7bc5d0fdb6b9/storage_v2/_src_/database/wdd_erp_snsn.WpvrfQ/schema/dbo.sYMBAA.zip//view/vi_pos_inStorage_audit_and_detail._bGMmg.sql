CREATE VIEW [dbo].[vi_pos_inStorage_audit_and_detail] AS 
SELECT jt.in_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.pos_inStorage           AS jt
       INNER JOIN dbo.vi_pos_inStorageList_audit AS jt1
            ON  jt.in_id = jt1.inl_in_id
       INNER JOIN dbo.b_goodsinfo  AS bg
            ON  jt1.inl_gi_id = bg.gi_id
go

