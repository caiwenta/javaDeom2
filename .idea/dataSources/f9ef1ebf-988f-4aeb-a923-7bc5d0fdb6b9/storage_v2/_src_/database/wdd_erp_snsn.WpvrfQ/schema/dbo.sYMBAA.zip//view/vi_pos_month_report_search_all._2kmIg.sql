CREATE VIEW [dbo].[vi_pos_month_report_search_all]
	AS 
	
	
	SELECT *,
isnull(sc.en_num,0)+isnull(sc.enth_num,0) AS enhj ,
isnull(sc.enth_money,0)+isnull(sc.en_money,0) AS enmoneyhj,

isnull(-sc.oo_num,0)- isnull(sc.ooth_num,0)  AS ooth_numhj,
isnull(-sc.[ooth_money],0)-isnull(sc.[oo_money],0) AS ooth_moneyhj,
 (start_money+enth_money+en_money-ooth_money-oo_money+yk_money+ ts_money+mo_money+mi_money) AS end_money,
 (start_num+en_num + enth_num-oo_num - ooth_num+ yk_num+ts_num+mo_num+mi_num) AS end_num,
 0 AS retail_start_money,0 as  retail_en_money,0 as retail_enth_money,0 AS retail_oo_money,0 as retail_ooth_money,
 0 as retail_enmoneyhj,0 AS retail_ooth_moneyhj,0 AS retail_yk_money,0 AS retail_mo_money,0 AS retail_end_money
 FROM(
	SELECT 
	
		fd.gid,
		fd.sid,
		fd.shid,
			fd.sei_erp_id AS erp_id,
		fd.gi_name,
		fd.gi_code,
		fd.gi_unit_name AS ut_name,
		fd.sei_name,
				SUM(case when fd.myremark='期初' then fd.gnum else 0 end) as start_num,
		SUM(case when fd.myremark='期初' then fd.allmoney else 0 end) as start_money,
	SUM(case when fd.myremark='入库' then fd.gnum else 0 end) as en_num,
		SUM(case when fd.myremark='入库' then fd.allmoney else 0 end) as en_money,
		SUM(case when fd.myremark='入库退货'  or fd.myremark='调拨' then fd.gnum else 0 end) as enth_num,
		SUM(case when fd.myremark='入库退货'  or fd.myremark='调拨' then fd.allmoney else 0 end) as enth_money,
		SUM(case when fd.myremark='销售前台' and  fd.gnum <0 then fd.gnum else 0 end) as oo_num,
		SUM(case when fd.myremark='销售前台' and  fd.gnum <0 then fd.allmoney else 0 end) as oo_money,
	    SUM(case when fd.myremark='销售前台' and  fd.gnum >0 then fd.gnum else 0 end) as ooth_num,
		SUM(case when fd.myremark='销售前台' and  fd.gnum >0 then fd.allmoney else 0 end) as ooth_money,
		SUM(case when fd.myremark='整仓盘点盈亏调整' then fd.gnum else 0 end) as ts_num,
		SUM(case when fd.myremark='整仓盘点盈亏调整' then fd.allmoney else 0 end) as ts_money,
		SUM(case when fd.myremark='移出仓库' then fd.gnum else 0 end) as mo_num,
		SUM(case when fd.myremark='移出仓库' then fd.allmoney else 0 end) as mo_money,
		SUM(case when fd.myremark='移入仓库' then fd.gnum else 0 end) as mi_num,
		SUM(case when fd.myremark='移入仓库' then fd.allmoney else 0 end) as mi_money,
		SUM(case when fd.myremark='盈亏' then fd.gnum else 0 end) as yk_num,
		SUM(case when fd.myremark='盈亏' then fd.allmoney else 0 end) as yk_money
		FROM vi_pos_stockList_createmonthly fd
			group by 
		fd.gid,
		fd.sid,
		fd.shid,
		sei_erp_id,fd.gi_name,
		fd.gi_code,
		fd.gi_unit_name,fd.sei_name) AS sc
go

