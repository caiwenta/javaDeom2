CREATE TRIGGER [dbo].[trg_b_supplierinfo_insert_update] ON [dbo].[b_supplierinfo]
       AFTER UPDATE, INSERT
AS
       BEGIN
             DECLARE @id INT= 0;
			 DECLARE @isdel INT= 0;
             DECLARE @qcje DECIMAL(15, 2)= 0;
             DECLARE @oldqcje DECIMAL(15, 2)= 0;
             
             SELECT @id = si_id ,
					@isdel = si_isdel ,
                    @qcje = si_qcje
             FROM   INSERTED;
             
             SELECT @oldqcje = si_qcje
             FROM   DELETED;
	
             --IF @oldqcje <> @qcje OR @isdel = 0 or @oldqcje=0
             --   EXEC pro_update_c_fundorder_QcQm @type = 1, @ciid = @id
       END
go

