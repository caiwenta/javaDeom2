
CREATE Proc [dbo].[pro_pos_sale_temp_op_news]
--主键  
@sal_erp_id int=0, 
@sa_erp_id int=0, 
@sal_id int=0,  
--销售登记主键  
@sal_sa_id int=0,  
--商品主键  
@sal_gi_id int=0,  
--商品sku主键  
@sal_sku_id int=0,  
--数量  
@sal_num int=0,  
--零售价  
@sal_retail_price decimal(9,2)=0,  
--折率  
@sal_discount decimal(9,2)=0,  
--导购员主键  
@sal_list_man int=0,  
--实售价  
@sal_real_price decimal(9,2)=0,  
--应收金额  
@sal_money decimal(9,2)=0,  
--扣除金额  
@sal_deduct_money decimal(9,2)=0,  
--是否赠送  
@sal_is_gift int=0,  
--是否换货  
@sal_is_change int=0,  
--是否正价  
@sal_is_zhengjia int=0,  
--是否特价  
@sal_is_tejia int=0,  
--是否积分兑换  
@sal_is_in int=0,  
--积分  
@sal_in_num int=0,  
--是否退货
@sal_is_return int=0,
--备注  
@sal_remark varchar(50)='',  
--备注2  
@sal_remark2 varchar(50)='',  

@sal_st_id INT=0,
--添加时间  
@sal_add_time datetime='2014-10-24',  
--主键  
@sa_id int=0,  
--店铺主键  
@sa_sh_id int=0,  
--收银人员主键  
@sa_co_man int=0,  
--销售日期  
@sa_date datetime='2014-10-24',  
--单据号  
@sa_no varchar(50)='',  
--活动主键  
@sa_ac_id int=0,  
--制单人主键  
@sa_order_man int=0,  
--仓库主键  
@sa_st_id int=0,  
--修改人主键  
@sa_update_man int=0,  
--修改时间  
@sa_update_time datetime='2014-10-24',  
--添加人主键  
@sa_add_man int=0,  
--添加时间  
@sa_add_time datetime='2014-10-24',  
--单据类型(0,销售登记:1,销售退货登记)  
@sa_type int=0,  
--销售类型(0,会员:1,零售)  
@sa_sa_type int=0,  
--会员主键  
@sa_me_id int=0,  
--备注  
@sa_remark varchar(50)='',  
--积分消费规则主键  
@sa_in_id int=0,  
--积分消费  
@sa_in_num int=0,  
--获得积分  
@sa_get_in_num int=0,  
--扣除金额  
@sa_deduct_money decimal(9,2)=0,  
--消费代金劵  
@sa_sa_vo int=0,  
--赠送代金券  
@sa_gift_vo int=0,  
--积分抵扣额  
@sa_in_money decimal(9,2)=0,  
--刷卡金额  
@sa_card_money decimal(9,2)=0,  
--商城金额  
@sa_shop_money decimal(9,2)=0,  
--应收金额  
@sa_money decimal(9,2)=0,  
--实收金额  
@sa_real_money decimal(9,2)=0,  
--挂账金额  
@sa_charge_money decimal(9,2)=0,  
--找零  
@sa_surplus_money decimal(9,2)=0,  
--收款方式  
@sa_select int=0,  
--审核人主键  
@sa_audit_man int=0,  
--审核时间  
@sa_audit_time datetime='2014-10-24',  
--销售金额
@sa_sale_money  decimal(9,2)=0, 
--退货金额
@sa_change_money  decimal(9,2)=0, 
--赠送金额
@sa_gift_money  decimal(9,2)=0, 
--现有积分
@sa_current_vo int=0,
--是否挂账
@sa_is_charge int=0,
--支付方式
@sa_paytype varchar(100)='',  

--操作类型  
@op_type varchar(100)='添加修改单据,明细',  

@negative_inventory INT=0,
--结果  
@result varchar(100)='' out
as
BEGIN
	
	
	IF ISNULL(@sal_gi_id,0)=0
	BEGIN
		IF ISNULL(@sal_sku_id,0)!=0
		BEGIN
			SELECT @sal_gi_id=bg.gi_id
			  FROM b_goodsruleset bg WITH (NOLOCK) 
			   WHERE bg.gss_id=@sal_sku_id
		END
	END
	
	
	IF(DATEPART(YEAR,@sa_update_time)=2014)
	BEGIN
		SET @sa_update_time=GETDATE();
	END
	
	
	
declare @sei_is_negative int=0;
select @sei_is_negative=sei_is_negative_inventory from pos_storageInfo WITH (NOLOCK)  where sei_id =@sa_st_id
if @op_type='会员打折'
begin
	
	if @sa_me_id=
	(
	select isnull(fd.sa_me_id,0) 
	from pos_sale_temp as fd WITH (NOLOCK)  where fd.sa_id=@sa_id
	)BEGIN
	 	
	 	set @result='1';
		return;
	 END
	else
	BEGIN
		
		if (select isnull(fd.sa_me_id,0) 
		from pos_sale_temp as fd WITH (NOLOCK)  where fd.sa_id=@sa_id)>0
		BEGIN
			
			update pos_saleList_temp
			set sal_discount =isnull(sal_discount_old_mem,1)
			where sal_sa_id=@sa_id;
		END
	END
	
	
	
	declare @gr_discount decimal(10,2)=0;
	select @gr_discount=pg.gr_discount
	from pos_grade as pg WITH (NOLOCK)  where pg.gr_id=
	(select pmi.me_gr_id from pos_memberInfo 
	as pmi  WITH (NOLOCK)  where pmi.me_id=@sa_me_id)
	
	
		--会员卡级别为空   
  if((select case when pmi.me_gr_id  is null then 0 else pmi.me_gr_id end  from pos_memberInfo    
	as pmi  WITH (NOLOCK)  where pmi.me_id=@sa_me_id)=0)
	begin
	   set @gr_discount=1
	end
	--会员卡级别为空
	
	
	
	update pos_saleList_temp
	set sal_discount_old_mem = sal_discount where sal_sa_id=@sa_id
	
	update pos_saleList_temp 
	set sal_discount=1*@gr_discount
	--set sal_discount=sal_discount*@gr_discount
	where sal_sa_id=@sa_id 
	
	update pos_saleList_temp 
	set 
	sal_real_price=sal_retail_price*sal_discount,
	sal_money=(sal_num*(sal_retail_price*sal_discount))
	-sal_deduct_money 
	where sal_sa_id=@sa_id
	
	
	update pos_sale_temp
	set sa_me_id = @sa_me_id 
	,sa_current_vo=(
		select me_cu_in_num from pos_memberInfo as pmi  WITH (NOLOCK)  where pmi.me_id=@sa_me_id
	)
	where sa_id=@sa_id;
	
	
	
	
	set @result='1';
	return;
END


if @op_type='删除会员'
BEGIN
	
  		
	
	update pos_saleList_temp
	set sal_discount =isnull(sal_discount_old_mem,1)
	where sal_sa_id=@sa_id;
	
	update pos_saleList_temp 
	set 
	sal_real_price=sal_retail_price*sal_discount,
	sal_money=(sal_num*(sal_retail_price*sal_discount))
	-sal_deduct_money 
	where sal_sa_id=@sa_id
	
	set @result='1';
	return;
END



if @op_type='挂单'
begin
	update pos_sale_temp
	set sa_status = 2
	where sa_id=@sa_id;
	if @@ROWCOUNT>0
	BEGIN
		set @result='1';
	END
	else
	BEGIN
		set @result='0';
	END
	return;
END
	

if @op_type='数据签出'
BEGIN
	exec pro_sale_merge
		@sa_id = @sa_id,
		@op_type = '数据签出'
	set @result='1';
	return;
END	
	
	
	
 --是否添加单据
 declare @isInsert int = 0;
 --是否需要更新单据
 declare @need_update int = 0;
 --旧的单据日期
 declare @old_order_date datetime;
 --单据日期是否更改
 declare @old_order_date_is_changed int = 0;
 --凭证号前缀
 declare @myprevTxt varchar(50) = 'XS';
 begin tran
 
 if @op_type='是否销售过'
 BEGIN
 	
 	if @sa_me_id>0
 	BEGIN
 		--会员
 		if exists(select * from pos_sale_temp as ps inner join pos_saleList_temp as psl  WITH (NOLOCK)  on ps.sa_id=psl.sal_sa_id where ps.sa_status>0 and psl.sal_status>0 and psl.sal_gi_id=@sal_gi_id and ps.sa_me_id=@sa_me_id
 		and psl.sal_id!=@sal_id
 		)
 		begin
 			--有销售过
 			set @result='1';
 		end
 		else
 		begin
 			--没有
 			set @result='0';
 		END
 	end
 	else
 	BEGIN
 		--零售
 		if exists(select * from pos_sale_temp as ps inner join pos_saleList_temp as psl  WITH (NOLOCK)  on ps.sa_id=psl.sal_sa_id where ps.sa_status>0 and psl.sal_status>0 and psl.sal_gi_id=@sal_gi_id and psl.sal_id!=@sal_id)
 		begin
 			--有销售过
 			set @result='1';
 		end
 		else
 		begin
 			--没有
 			set @result='0';
 		END
 	END
 	
 	IF @@TRANCOUNT > 0 ROLLBACK TRAN
 	return 1;
 END
 
 if @op_type='删除活动'
 BEGIN
 	--恢复应用活动之前的数据
 	update pos_sale_temp
 	set sa_ac_id = 0
 	where sa_id=@sa_id;
 	
 	update pos_saleList_temp
 	set	sal_discount = sal_discount_old,
 		sal_real_price = sal_real_price_old,
 		sal_deduct_money = sal_deduct_money_old,sal_old_record = 0
 	where sal_sa_id=@sa_id and sal_old_record=1;
 	
 	delete from pos_saleList_temp where sal_sa_id=@sa_id
 	and sal_is_active_gift=1;


 	set @result=1;
 	
 END
 
 if @op_type='活动扣除金额'
 begin
 	
 	--if(1=2)
 	--BEGIN
 	
 	
 	--活动赠送金额
 	declare @ac_money decimal(10,2)=0;
 	
 	--销售总金额
	declare @sa_money1 decimal(10,2)=0;
 	--折扣
 	declare @ac_discount_rate decimal(10,2)=0;
 	--特价
 	declare @ac_sale_price decimal(10,2)=0;
 	--赠送代金券
 	declare @ac_gift_money decimal(10,2)=0;
 	
 	--折上折
 	declare @ac_is_discount int=0;
 	--递增赠送
 	declare @ac_is_gift int=0;
 	--买x件打y折 
 	declare @ac_xy int=0;
 	
 	--金额满多少
 	declare @ac_biger_equal decimal(10,2)=0;
 	
 	
 	--数量满多少
 	declare @ac_smaller_equal int=0;

 	select 
 	
 	@ac_money=isnull(pa.ac_immediately_money,0),
 	@ac_discount_rate=isnull(pa.ac_discount_rate,0),
 	@ac_sale_price=isnull(pa.ac_sale_price,0),
 	@ac_is_discount=isnull(pa.ac_is_discount,0),
 	@ac_is_gift=isnull(pa.ac_is_gift,0),
 	@ac_xy=isnull(pa.ac_xy,0),
 	@ac_gift_money=isnull(pa.ac_gift_money,0),
 	@ac_smaller_equal=isnull(pa.ac_smaller_equal,0),
 	@ac_biger_equal=isnull(pa.ac_biger_equal,0)
 	
 	from pos_active as pa  WITH (NOLOCK)  where pa.ac_id=@sa_ac_id
 	
 	
 	
 	
 	--促销商品数量
 	declare @ac_goods_count int=0;
 	select @ac_goods_count=
 	isnull(Count(1),0) from 
 	pos_activeGoods as pag 
 	where pag.ac_ac_id=@sa_ac_id 
 	and pag.ac_status=1;
 	
 	
 	if @ac_goods_count!=0
 	begin
 		
 	--判断商品
 	if not exists (
 		select * from pos_saleList_temp as fd  WITH (NOLOCK) 
 		inner join (
 		select distinct pag.ac_gi_id 
 		from pos_activeGoods as pag   WITH (NOLOCK) 
 		where pag.ac_ac_id=@sa_ac_id 
 		and pag.ac_status=1
 		) as fd2 on fd.sal_gi_id=fd2.ac_gi_id
 		where fd.sal_sa_id=@sa_id and fd.sal_status=1
 	)
 	BEGIN
 		set @result='此商品没有参与活动';
		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
 		return;
 	END
 		
 		
 		
 		
 		
 		
 		--条件
 		--指定商品的数量,金额
 		if @ac_smaller_equal>0
 		BEGIN
 			print '金额'
 			
 			
 			
 		END
 		else
 		BEGIN
 			print '数量'
 			
 			
 			
 		END
 		
 		
 		print 1;
 	END
 	
 	
 	
 	
 	
 	--设置活动id
 	update pos_sale_temp
 	set sa_ac_id = @sa_ac_id
 	where sa_id=@sa_id;
 	
 	
 	
 	--记录旧的数据
 	if @ac_goods_count=0
 	begin
 	--对所有商品有效
 	update pos_saleList_temp
 	set
 		sal_discount_old = sal_discount,
 		sal_deduct_money_old = sal_deduct_money,
 		sal_real_price_old = sal_real_price,
 		sal_old_record=1
 	where sal_sa_id=@sa_id and isnull(sal_old_record,0)=0
 	end
 	else
 	begin
 	--具体商品
 	--记录旧的数据
 	update pos_saleList_temp
 	set
 		sal_discount_old = sal_discount,
 		sal_deduct_money_old = sal_deduct_money,
 		sal_real_price_old = sal_real_price,
 		sal_old_record=1
 	where sal_sa_id=@sa_id and sal_gi_id in(
			select distinct pag.ac_gi_id
			  from pos_activeGoods as pag  WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id 
			  and pag.ac_status=1
 	) and isnull(sal_old_record,0)=0
 	END
 	
 	declare @sal_num1 int=0;
	--扣除金额	
	select 
	@sa_money1=fd.sa_money1,
	@sal_num1=fd.sal_num
	from vi_pos_saleList_temp_sum as fd  where fd.sal_sa_id=@sa_id;
	if @ac_is_gift=1
 	begin
 		--递增赠送
 		declare @bei_shu int=0;
 		if @ac_biger_equal>0
 		BEGIN
 			--金额
 			set @bei_shu=FLOOR(@sa_money1/@ac_biger_equal);
 		end
 		else
 		begin
 			--数量
 			set @bei_shu=FLOOR(@sa_money1/@ac_smaller_equal);
 		END
		set @ac_money=@ac_money*@bei_shu;
 	end
 	--去最小整数
 	--declare @sint decimal(10,2)=13.5;
	--select FLOOR(@sint/13)
	
	--添加赠送商品
 if exists(select pag.*from pos_active as pa  WITH (NOLOCK)  inner join pos_activeGift as pag  WITH (NOLOCK)  on pa.ac_id=pag.ac_ac_id where pag.ac_status=1 and pa.ac_id=@sa_ac_id) and not exists(select*from pos_saleList_temp as psl  WITH (NOLOCK)  where psl.sal_sa_id=@sa_id and psl.sal_is_active_gift=1)
 begin
 	declare @sint int=1;
 	
 	if @bei_shu>0
 	BEGIN
	--递增赠送,循环添加赠送商品
 	while @sint<=@bei_shu
 	BEGIN
 	insert into pos_saleList_temp
 	(
 		sal_sa_id,
 		sal_gi_id,
 		sal_num,
 		sal_retail_price,
 		sal_discount,
 		sal_real_price,
 		sal_status,
 		sal_is_active_gift,
 		--,sal_money,
 		--sal_deduct_money,
 		sal_is_gift
 		--sal_is_change,
 		--sal_is_in,
 		--sal_in_num,
 		--sal_remark,
 		--sal_add_time,
 		--sal_is_return,
 		--sal_discount_old,
 		--sal_deduct_money_old,
 		--sal_real_price_old,
 		--sal_old_record,
 		--sal_is_active_gift
 	)select @sa_id,pag.ac_gi_id,pag.ac_num,pag.ac_retail_price,
 	        pag.ac_discount_money, pag.ac_retail_price,1,1,1
 	   from pos_activeGift as pag  WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id
 	and pag.ac_status=1
 		set @sint=@sint+1;
 	END
 	 		
 	end
 	else
 	BEGIN
 	insert into pos_saleList_temp
 		(
 		sal_sa_id,
 		sal_gi_id,
 		sal_num,
 		sal_retail_price,
 		sal_discount,
 		sal_real_price,
 		sal_status,
 		sal_is_active_gift,
 		--,sal_money,
 		--sal_deduct_money,
 		sal_is_gift
 		--sal_is_change,
 		--sal_is_in,
 		--sal_in_num,
 		--sal_remark,
 		--sal_add_time,
 		--sal_is_return,
 		--sal_discount_old,
 		--sal_deduct_money_old,
 		--sal_real_price_old,
 		--sal_old_record,
 		--sal_is_active_gift
 	)select @sa_id,pag.ac_gi_id,pag.ac_num,pag.ac_retail_price,
 	        pag.ac_discount_money, pag.ac_retail_price,1,1,1
 	   from pos_activeGift as pag  WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id
 	and pag.ac_status=1
 	END
 	
 	DECLARE @t2out DATETIME=GETDATE();
 	
 	--更新赠送商品的添加时间
 	declare @ac_sal_id int=0;
 	DECLARE sopcor CURSOR FOR(select psl.sal_id
 	                            from pos_saleList_temp as psl  WITH (NOLOCK)  where psl.	sal_sa_id=@sa_id and psl.sal_is_active_gift=1)
OPEN sopcor
		FETCH NEXT FROM sopcor into @ac_sal_id
		WHILE @@FETCH_STATUS =0
		begin
			EXEC pro_get_rand_time
	@t1 = @t2out,
	@t2out = @t2out OUT
			update pos_saleList_temp
 	set sal_add_time =@t2out
			where sal_id=@ac_sal_id;
		
		FETCH NEXT FROM sopcor into @ac_sal_id
		End
CLOSE sopcor
DEALLOCATE sopcor

 	
 	
 end
	
	
	
	if @ac_discount_rate>0
	begin
	if @ac_goods_count=0
	BEGIN

	--折扣
	update pos_saleList_temp
	set sal_discount = case when @ac_is_discount=1 then sal_discount* @ac_discount_rate else @ac_discount_rate end
	where sal_sa_id=@sa_id;
	
	update pos_saleList_temp
	set sal_real_price  = sal_retail_price*sal_discount
	where sal_sa_id=@sa_id;
	
	
	update pos_saleList_temp set sal_money =
	(sal_real_price*pslt.sal_num)-pslt.sal_deduct_money
	from pos_saleList_temp as pslt WITH (NOLOCK)  where pslt.sal_sa_id=@sa_id;
			 
	END	
	else
	begin
		
	--折扣
	update pos_saleList_temp
	set sal_discount = case when @ac_is_discount=1 then sal_discount* @ac_discount_rate else @ac_discount_rate end
	where sal_sa_id=@sa_id and sal_gi_id in(
			select distinct pag.ac_gi_id
			  from pos_activeGoods as pag WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id and pag.ac_status=1
	)
	
	update pos_saleList_temp
	set sal_real_price  = sal_retail_price*sal_discount
	where sal_sa_id=@sa_id and sal_gi_id in(
			select distinct pag.ac_gi_id
			  from pos_activeGoods as pag WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id and pag.ac_status=1
	)
	
	update pos_saleList_temp set sal_money =
	(sal_real_price*pslt.sal_num)-pslt.sal_deduct_money
	from pos_saleList_temp as pslt where pslt.sal_sa_id=@sa_id and pslt.sal_gi_id in (
	select distinct pag.ac_gi_id
		from pos_activeGoods as pag WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id and pag.ac_status=1
	)
	
		
		
	END
	end
	else if @ac_money>0
	begin
		
	--立减金额
	if @ac_goods_count=0
	begin
 	--销售金额/总销售金额*立减金额=扣除金额
	update pos_saleList_temp
	set sal_deduct_money= (sal_real_price*sal_num)/@sa_money1*@ac_money
	where sal_sa_id=@sa_id;
	END	
	else
	BEGIN
 	--销售金额/总销售金额*立减金额=扣除金额
	update pos_saleList_temp
	set sal_deduct_money= (sal_real_price*sal_num)/@sa_money1*@ac_money
	where sal_sa_id=@sa_id and sal_gi_id in(
			select distinct pag.ac_gi_id
			  from pos_activeGoods as pag WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id and pag.ac_status=1
	)
	END
	end
	else if @ac_sale_price>0
	begin
		if @ac_goods_count=0
		BEGIN
		
		--特价
		update pos_saleList_temp
		set sal_real_price = @ac_sale_price
		where sal_sa_id=@sa_id;	
		
		update pos_saleList_temp
		set sal_discount  = round(@ac_sale_price/sal_retail_price,2)
		where sal_sa_id=@sa_id;	
			
		end
		else
		begin
			
		--特价
		update pos_saleList_temp
		set sal_real_price = @ac_sale_price
		where sal_sa_id=@sa_id and sal_gi_id in(
			select distinct pag.ac_gi_id
			  from pos_activeGoods as pag WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id and pag.ac_status=1
	)
		
		update pos_saleList_temp
		set sal_discount  = round(@ac_sale_price/sal_retail_price,2)
		where sal_sa_id=@sa_id and sal_gi_id in(
			select distinct pag.ac_gi_id
			  from pos_activeGoods as pag WITH (NOLOCK)  where pag.ac_ac_id=@sa_ac_id and pag.ac_status=1
	)
		
		END
	end
	else if @ac_gift_money>0
	BEGIN
		--赠送代金券
		
		print '未做'
		
	END
	
	
	
	

	
	
 	--END
	if @@ERROR<>0
	BEGIN
		set @result='0';
		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	end
	else
	BEGIN
		set @result='1';
		IF @@TRANCOUNT > 0 commit tran;
	END
	return;

	
	
 end
 
 
 if @op_type='退换货'
 begin
 	

 	
 	
 	if exists(select * from pos_sale as ps WITH (NOLOCK)  where ps.sa_vo=@sal_remark
 	and ps.sa_status>0
 	)
 	begin
 		--游标方式生成销售单
 		declare @first_id int=0;
 		
 		
 		
 		DECLARE sopcor CURSOR FOR(
 			select ps.sa_sh_id,ps.sa_co_man,ps.sa_date,ps.sa_ac_id,ps.sa_order_man,ps.sa_st_id,ps.sa_me_id,ps.sa_remark,ps.sa_in_id,ps.sa_in_num,ps.sa_get_in_num,ps.sa_deduct_money,ps.sa_sa_vo,ps.sa_gift_vo,ps.sa_in_money,ps.sa_card_money,ps.sa_shop_money,ps.sa_money,ps.sa_real_money,ps.sa_charge_money,ps.sa_surplus_money,ps.sa_select,ps.sa_sale_money,ps.sa_change_money,ps.sa_gift_money,ps.sa_current_vo,ps.sa_is_charge,psl.sal_gi_id,psl.sal_sku_id,psl.sal_num,psl.sal_retail_price,psl.sal_discount,psl.sal_list_man,psl.sal_real_price,psl.sal_money,psl.sal_deduct_money,psl.sal_is_gift,psl.sal_is_change,psl.sal_is_in,psl.sal_in_num,psl.sal_remark,psl.sal_is_return,psl.sal_add_time,psl.sal_remark2,psl.sal_st_id,ps.sa_paytype,sal_is_zhengjia,sal_is_tejia
 			  from pos_sale as ps WITH (NOLOCK)  inner join pos_saleList as psl WITH (NOLOCK) 
 		on ps.sa_id=psl.sal_sa_id where ps.sa_vo=@sal_remark
 		and psl.sal_status=1
 		)
OPEN sopcor
declare @now datetime;
declare @prev_now datetime;
declare @old_sal_add_time datetime='2014-12-17';

set @now=getdate();
FETCH NEXT FROM sopcor INTO @sa_sh_id,@sa_co_man,@sa_date,@sa_ac_id,@sa_order_man,@sa_st_id,@sa_me_id,@sa_remark,@sa_in_id,@sa_in_num,@sa_get_in_num,@sa_deduct_money,@sa_sa_vo,@sa_gift_vo,@sa_in_money,@sa_card_money,@sa_shop_money,@sa_money,@sa_real_money,@sa_charge_money,@sa_surplus_money,@sa_select,@sa_sale_money,@sa_change_money,@sa_gift_money,@sa_current_vo,@sa_is_charge,@sal_gi_id,@sal_sku_id,@sal_num,@sal_retail_price,@sal_discount,@sal_list_man,@sal_real_price,@sal_money,@sal_deduct_money,@sal_is_gift,@sal_is_change,@sal_is_in,@sal_in_num,@sal_remark,@sal_is_return,@sal_add_time,@sal_remark2,@sal_st_id,@sa_paytype,@sal_is_zhengjia,@sal_is_tejia
		WHILE @@FETCH_STATUS =0
		begin
			
			if @old_sal_add_time!=@sal_add_time
			BEGIN
			set @old_sal_add_time=@sal_add_time;
			set @now=getdate();
			while 1=1
			BEGIN
				if @prev_now=@now
				BEGIN
					set @now=getdate();
				end
				else
				BEGIN
					break;
				END
			end
			END
			
			exec pro_pos_sale_temp_op
				--@sal_id = null,
				@sal_sa_id = @first_id,
				@sal_gi_id = @sal_gi_id,
				@sal_sku_id = @sal_sku_id,
				@sal_num = @sal_num,
				@sal_retail_price = @sal_retail_price,
				@sal_discount = @sal_discount,
				@sal_list_man = @sal_list_man,
				@sal_real_price = @sal_real_price,
				@sal_money = @sal_money,
				@sal_deduct_money = @sal_deduct_money,
				@sal_is_gift = @sal_is_gift,
				@sal_is_change = @sal_is_change,
				@sal_is_in = @sal_is_in,
				@sal_in_num = @sal_in_num,
				@sal_is_return = @sal_is_return,
				@sal_is_zhengjia = @sal_is_zhengjia,				
				@sal_is_tejia = @sal_is_tejia,	
				@sal_remark = @sal_remark,
				@sal_remark2 = @sal_remark2,
				@sa_erp_id=	@sa_erp_id,
				@sal_erp_id=@sal_erp_id,
				@sal_st_id=@sal_st_id,
				
				@sal_add_time = @now,
				@sa_id = @first_id,
				@sa_sh_id = @sa_sh_id,
				@sa_co_man = @sa_co_man,
				--@sa_date = convert(varchar(50),@now,23),
				@sa_date = @sa_date,
				@sa_no = @sa_no,
				@sa_ac_id = @sa_ac_id,
				@sa_order_man = @sa_order_man,
				@sa_st_id = @sa_st_id,
				@sa_update_man = @sa_update_man,
				@sa_update_time = @sa_update_time,
				@sa_add_man = @sa_add_man,
				@sa_add_time = @sa_add_time,
				@sa_type = @sa_type,
				@sa_sa_type = @sa_sa_type,
				@sa_me_id = @sa_me_id,
				@sa_remark = @sa_remark,
				@sa_in_id = @sa_in_id,
				@sa_in_num = @sa_in_num,
				@sa_get_in_num = @sa_get_in_num,
				@sa_deduct_money = @sa_deduct_money,
				@sa_sa_vo = @sa_sa_vo,
				@sa_gift_vo = @sa_gift_vo,
				@sa_in_money = @sa_in_money,
				@sa_card_money = @sa_card_money,
				@sa_shop_money = @sa_shop_money,
				@sa_money = @sa_money,
				@sa_real_money = @sa_real_money,
				@sa_charge_money = @sa_charge_money,
				@sa_surplus_money = @sa_surplus_money,
				@sa_select = @sa_select,
				@sa_audit_man = @sa_audit_man,
				@sa_audit_time = @sa_audit_time,
				@sa_sale_money = @sa_sale_money,
				@sa_change_money = @sa_change_money,
				@sa_gift_money = @sa_gift_money,
				@sa_current_vo = @sa_current_vo,
				@sa_is_charge = @sa_is_charge,
				@sa_paytype = @sa_paytype,											
				@op_type = '添加修改单据,明细',
				@result = @result out
				
				set @prev_now=@now;
				
				if @first_id=0
				BEGIN
					set @first_id=convert(int,@result);
				end
				
		FETCH NEXT FROM sopcor INTO @sa_sh_id,@sa_co_man,@sa_date,@sa_ac_id,@sa_order_man,@sa_st_id,@sa_me_id,@sa_remark,@sa_in_id,@sa_in_num,@sa_get_in_num,@sa_deduct_money,@sa_sa_vo,@sa_gift_vo,@sa_in_money,@sa_card_money,@sa_shop_money,@sa_money,@sa_real_money,@sa_charge_money,@sa_surplus_money,@sa_select,@sa_sale_money,@sa_change_money,@sa_gift_money,@sa_current_vo,@sa_is_charge,@sal_gi_id,@sal_sku_id,@sal_num,@sal_retail_price,@sal_discount,@sal_list_man,@sal_real_price,@sal_money,@sal_deduct_money,@sal_is_gift,@sal_is_change,@sal_is_in,@sal_in_num,@sal_remark,@sal_is_return,@sal_add_time,@sal_remark2,@sal_st_id,@sa_paytype,@sal_is_zhengjia,@sal_is_tejia
		End
CLOSE sopcor
DEALLOCATE sopcor
 		
 		if @@ERROR<>0
 		BEGIN
 			
 			set @result='操作失败!';
 			IF @@TRANCOUNT > 0 ROLLBACK TRAN;
 			return 1;
 		end
 		else
 		BEGIN
 			
 		set @result=convert(varchar(50),@first_id);
 		IF @@TRANCOUNT > 0 commit tran;
 		return 1;
 		END
 		
 	END
 	else
 	BEGIN
 		set @result='凭证号不存在!';
 		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
 		return 0;
 	END
 END
 
 if @op_type='是否结算'
 begin
 	declare @max_sa_date datetime;
 	declare @sar_type_var varchar(50)='';
 	select top 1 @sar_type_var=isnull(psr.sar_type,'')
 	from pos_sale_record as psr  WITH (NOLOCK)  where convert(varchar(50), psr.sar_date,23)=convert(varchar(50),@sa_date,23)
 	and psr.sar_sh_id=@sa_sh_id
 	order by psr.sar_id desc;
 	
 	if @sar_type_var='' or @sar_type_var='反结算'
 	BEGIN
 		--检查上一个日期是否结算
 		select top 1 @sar_type_var=psr.sar_type
 	from pos_sale_record as psr WITH (NOLOCK)  where convert(varchar(50), psr.sar_date,23)= convert(varchar(50),dateadd(day,-1,@sa_date),23)
 	and psr.sar_sh_id=@sa_sh_id
 	order by psr.sar_id desc;
 		if @sar_type_var='' or @sar_type_var='反结算'
 		begin
 			set @result='该日期的前一天未结算利润，无法输入';
 		end
 		else
 		BEGIN
 			set @result='1';
 		END
 	end
 	else
 	BEGIN
 		--当前已结算
 		set @result='该日期已结算利润，无法输入'
 	END
 	 	IF @@TRANCOUNT > 0 ROLLBACK TRAN;
 		return 1;
 END
 
 
 if @op_type='结算'
 begin
 	update pos_sale_temp
	set sa_is_calculated = 1 where sa_date=@sa_date
	and sa_sh_id=@sa_sh_id;
 	insert into pos_sale_record
 	(
 		sar_type,
 		sar_date,
 		sar_add_time,
 		sar_add_man,sar_sh_id
 	)
 	values
 	(
 		'结算',
 		@sa_date,
 		getdate(),
 		@sa_add_man,@sa_sh_id
 	)
 	--update pos_sale_temp
 	update pos_sale
 	set sa_status = 3
 	where sa_date=@sa_date
 	and sa_status!=0 and sa_status!=2;
 end
 
 
 if @op_type='反结算'
 begin
 	update pos_sale_temp
	set sa_is_calculated = 0 where sa_date=@sa_date
	and sa_sh_id=@sa_sh_id;
 	insert into pos_sale_record
 	(
 		sar_type,
 		sar_date,
 		sar_add_time,
 		sar_add_man,sar_sh_id
 	)
 	values
 	(
 		'反结算',
 		@sa_date,
 		getdate(),
 		@sa_add_man,@sa_sh_id
 	)
 	--update pos_sale_temp
 	update pos_sale
 	set sa_status = 1
 	where sa_date=@sa_date
 	and sa_status=3;
 END
 
 
if @op_type='添加修改单据,明细'
begin
	
	if @sal_is_return=0 and @sal_is_change=0
	BEGIN
		set @sal_num=abs(@sal_num);
		set @sal_money=abs(@sal_money);
	END
	
	
 if @sa_id=0
 begin
  
 --添加单据
 insert into pos_sale_temp(sa_sh_id,sa_co_man,sa_date,sa_no,sa_vo,sa_ac_id,sa_order_man,sa_st_id,sa_update_man,sa_update_time,sa_add_man,sa_add_time,sa_status,sa_type,sa_sa_type,sa_me_id,sa_remark,sa_in_id,sa_in_num,sa_get_in_num,sa_deduct_money,sa_sa_vo,sa_gift_vo,sa_in_money,sa_card_money,sa_shop_money,sa_money,sa_real_money,sa_charge_money,sa_surplus_money,sa_select,
 sa_sale_money,sa_change_money,sa_gift_money,sa_current_vo,sa_is_charge,sa_is_calculated,sa_paytype,sa_erp_id
 )values(@sa_sh_id,@sa_co_man,@sa_date,@sa_no,newid(),@sa_ac_id,@sa_order_man,@sa_st_id,@sa_update_man,@sa_update_time,@sa_add_man,@sa_add_time,0,@sa_type,@sa_sa_type,@sa_me_id,@sa_remark,@sa_in_id,@sa_in_num,@sa_get_in_num,@sa_deduct_money,@sa_sa_vo,@sa_gift_vo,@sa_in_money,@sa_card_money,@sa_shop_money,@sa_money,@sa_real_money,@sa_charge_money,@sa_surplus_money,@sa_select
 ,@sa_sale_money,@sa_change_money,@sa_gift_money,@sa_current_vo,@sa_is_charge,0,@sa_paytype,@sa_erp_id
 );set  @sa_id=SCOPE_IDENTITY();
 
 set @sal_sa_id=@sa_id;
 set @isInsert = 1;
 end
  else
     begin
         set @need_update = 1;
     end
   if exists(select * from  pos_saleList_temp as jt WITH (NOLOCK) where jt.sal_sa_id=@sa_id and jt.sal_status=1 and jt.sal_add_time=@sal_add_time and jt.sal_gi_id!=@sal_gi_id)
   begin
    update pos_saleList_temp
    set sal_status = 0 where sal_sa_id=@sa_id and sal_add_time=@sal_add_time and sal_status=1 and sal_gi_id!=@sal_gi_id;
   END
     if @sal_id=0
     BEGIN
      insert into pos_saleList_temp(sal_sa_id,sal_gi_id,sal_sku_id,sal_num,sal_retail_price,sal_discount,sal_list_man,sal_real_price,sal_money,sal_deduct_money,sal_is_gift,sal_is_change,sal_is_in,sal_in_num,sal_remark,sal_status,sal_add_time,sal_is_return
      ,sal_remark2,sal_st_id,sal_is_tejia,sal_is_zhengjia,sal_erp_id
      )values(@sal_sa_id,@sal_gi_id,@sal_sku_id,@sal_num,@sal_retail_price,@sal_discount,@sal_list_man,@sal_real_price,@sal_money,@sal_deduct_money,@sal_is_gift,@sal_is_change,@sal_is_in,@sal_in_num,@sal_remark,1,@sal_add_time,@sal_is_return
      ,@sal_remark2,@sal_st_id,@sal_is_tejia,@sal_is_zhengjia,@sal_erp_id
      );set  @sal_id=SCOPE_IDENTITY();
     end
     else
     BEGIN
   update pos_saleList_temp set 
   --sal_sa_id=@sal_sa_id,
   sal_gi_id=@sal_gi_id,sal_sku_id=@sal_sku_id,sal_num=@sal_num,sal_retail_price=@sal_retail_price,sal_discount=@sal_discount,sal_list_man=@sal_list_man,sal_real_price=@sal_real_price,sal_money=@sal_money,sal_deduct_money=@sal_deduct_money,sal_is_gift=@sal_is_gift,sal_is_change=@sal_is_change,sal_is_in=@sal_is_in,sal_in_num=@sal_in_num,sal_remark=@sal_remark,sal_is_return=@sal_is_return,sal_remark2 = @sal_remark2,sal_st_id = @sal_st_id,sal_is_tejia=@sal_is_tejia,sal_is_zhengjia=@sal_is_zhengjia,sal_erp_id=@sal_erp_id
   
    where sal_id=@sal_id;
     END
end
if @op_type = '审核单据'
 begin
     --审核单据
      select  @sa_st_id=sa_st_id from pos_sale_temp WITH (NOLOCK)  where sa_id=@sa_id;--得到仓库id
     update pos_sale_temp
     set    sa_status = 2,
            sa_audit_man     =@sa_update_man,
            sa_audit_time       = getdate()
     where  sa_id               = @sa_id;
    
 end
if @op_type = '取消审核单据'
 begin
     --取消审核单据
      select  @sa_st_id=sa_st_id from pos_sale_temp  WITH (NOLOCK) where sa_id=@sa_id;--得到仓库id
     update pos_sale_temp
     set    sa_status     = 1
     where  sa_id         = @sa_id;
    
 end
 
 if @op_type = '删除单据'
 begin
     --删除单据
     select  @sa_st_id=sa_st_id from pos_sale_temp WITH (NOLOCK)  where sa_id=@sa_id;--得到仓库id
     update pos_sale_temp
     set    sa_status     = 0
     where  sa_id         = @sa_id;
     
 end
 
 if @op_type = '删除明细'
 begin
     --删除明细
     update   pos_saleList_temp set sal_status = 0
     where sal_id = @sal_id;
 end

if @op_type='批量删除明细'
 begin
  update   pos_saleList_temp set sal_status = 0
  where sal_sa_id=@sal_sa_id and sal_add_time=@sal_add_time and sal_gi_id=@sal_gi_id;
 end

 if @op_type = '添加修改单据,明细' or @need_update = 1 or @op_type='修改单据'
 begin
    --得到旧的单据日期
     select @old_order_date = jt.sa_date
     from pos_sale_temp  as jt
     where  jt.sa_id = @sa_id;
     if @old_order_date != @sa_date
     begin
         set @old_order_date_is_changed = 1;
     end
     
  --select * from pos_sale_temp as ps order by ps.sa_id desc
  
  update pos_sale_temp set sa_sh_id=@sa_sh_id,sa_co_man=@sa_co_man,sa_date=@sa_date,sa_no=@sa_no,sa_ac_id=@sa_ac_id,sa_order_man=@sa_order_man,sa_st_id=@sa_st_id,sa_update_man=@sa_update_man,sa_update_time=@sa_update_time,sa_type=@sa_type,sa_sa_type=@sa_sa_type,sa_me_id=@sa_me_id,sa_remark=@sa_remark,sa_in_id=@sa_in_id,sa_in_num=@sa_in_num,sa_get_in_num=@sa_get_in_num,sa_deduct_money=@sa_deduct_money,sa_sa_vo=@sa_sa_vo,sa_gift_vo=@sa_gift_vo,sa_in_money=@sa_in_money,sa_card_money=@sa_card_money,sa_shop_money=@sa_shop_money,sa_money=@sa_money,sa_real_money=@sa_real_money,sa_charge_money=@sa_charge_money,sa_surplus_money=@sa_surplus_money,sa_select=@sa_select,
  
  
  sa_sale_money=@sa_sale_money,
  sa_change_money=@sa_change_money,
  sa_gift_money=@sa_gift_money,
  sa_current_vo=@sa_current_vo,
  sa_is_charge=@sa_is_charge,  
  sa_paytype=@sa_paytype
  
  where sa_id=@sa_id;
  if @op_type='修改单据'
  begin
  	
  	update pos_sale_temp
	set sa_status = 1
  	where sa_id=@sa_id;
  	

--select 10000*0.018

 declare @old_sa_me_id int=0;	
 if exists(select * from pos_sale as ps WITH (NOLOCK)  where ps.sa_id=@sa_id)
 BEGIN
 	if(select isnull(ps.sa_me_id,0) from pos_sale as ps WITH (NOLOCK)  where ps.sa_id=@sa_id)>0
 	begin
 		
 		 select @old_sa_me_id=ps.sa_me_id from pos_sale as ps where ps.sa_id=@sa_id
 		 
 	END
 end
  	
  	exec pro_sale_merge
  		@sa_id = @sa_id,
  		@op_type = '数据签入'
  	
 
  	--重算会员积分	
  	exec pro_recount_member
  		@sa_id = @sa_id	
  		
  	if @old_sa_me_id>0
  	begin
  		
  		--重算会员积分	
  		exec pro_recount_member
  		@sa_id =0,@sa_me_id=@old_sa_me_id
  		
  	END
  		
  		 	
  END
  
  end


if @isInsert = 1
    --or @old_order_date_is_changed = 1
 begin
     --凭证号生成
     --更新凭证号 
     declare @tableName varchar(50) = 'pos_sale_temp'
     declare @idField varchar(50) = 'sa_id'
     declare @idValue int = @sa_id;
    
     declare @dateField varchar(50) = 'sa_date'
     declare @dateValue varchar(50) = convert(varchar(50),@sa_date, 23)
 
     declare @noField varchar(50) = 'sa_vo'
     declare @prevTxt varchar(50) = @myprevTxt
     declare @outno varchar(100) = ''
     declare @while int = 0;
     while @while = 0
     begin
         --得到凭证号
         execute [pro_gen_orderNo]@tableName,
              @idField,
              @idValue,
              @dateField,
              @dateValue,
              @noField,
              @prevTxt,
              @outno output,@sa_sh_id
         
         begin try
          --更新
          update pos_sale_temp
          set sa_vo = @outno
          where sa_id           = @sa_id;
          
          --更新成功,赋值,结束循环
          set @while = 1;
         end try
         begin catch
		 PRINT '';
          ----发生错误,判断错误类型
          --if charindex('重复键', error_message(), 0) = 0
          --begin
          --    --不是发生重复的错误
          --    --赋值,结束循环
          --    set @while = 1;
          --end
         end catch
     end
 end


   
   
   	exec [dbo].[pro_pos_mergeStockLog] 
	     @tsl_sh_id=@sa_sh_id, 
         @negative_inventory=@negative_inventory,
         @old_sei_id=0,  
         @new_sei_id=@sa_st_id  
  	 if @@ERROR<>0
     BEGIN
                set @result='0';
                IF @@TRANCOUNT > 0 ROLLBACK TRAN;
                RETURN 0;
     END




if @@ERROR <> 0
 begin
     set @result = '0';
     IF @@TRANCOUNT > 0 ROLLBACK TRAN;
 end
 else
 begin
     if @isInsert = 1
     BEGIN--
         set @result = convert(varchar(50),@sa_id)+'|'+convert(varchar(50),@sal_id) ;
     end
     else
     begin
         if @op_type = '添加修改单据,明细'
         begin
             set @result = convert(varchar(50),@sal_id);
         end
         else
         begin
             set @result = '1';
         end
     end
     IF @@TRANCOUNT > 0 commit tran;
 end
  
end
go

