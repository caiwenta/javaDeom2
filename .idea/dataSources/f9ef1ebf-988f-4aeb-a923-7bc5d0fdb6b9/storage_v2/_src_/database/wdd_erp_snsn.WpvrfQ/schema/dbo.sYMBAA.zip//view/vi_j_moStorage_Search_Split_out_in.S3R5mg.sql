CREATE VIEW [dbo].[vi_j_moStorage_Search_Split_out_in]
	AS 

SELECT
TT.mo_id as order_id,
TT.col AS color_id,


'' AS specname,--暂时为空  
(CASE WHEN rulenum.gd_row_number is null THEN '无' ELSE  'spec'+CONVERT(VARCHAR,rulenum.gd_row_number) END) AS spec2,
(CASE WHEN rulenum.gd_row_number IS NULL THEN '' ELSE 'spec' + CONVERT(VARCHAR,rulenum.gd_row_number) END) AS specno ,
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=size)sizecode, --尺码编码
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=col)colorcode, --颜色编码
rulenum.gd_row_number,
rulenum.gd_code AS rulecode,
TT.*

FROM
(

SELECT   
ISNULL(grl.gss_no,'') AS gss_no,--规格编码,
ISNULL(grl.colorname,'无') AS color,
ISNULL(grl.specname,'无') AS spec,
ISNULL(grl.specid,0) AS size,
ISNULL(grl.specngroupid,0) AS specid,
ISNULL(grl.colorid,0) AS col,
ISNULL(grl.colorgroupid,0) AS colorid,
isnull(grl.gs_sampleno,gi_sampleno)gs_sampleno,--规格样品号
T.*,bg.*  
FROM 
(
SELECT '移出' mo_out_in,
       (CASE WHEN mo_in_st_id<>0 THEN mo_in_st_id ELSE mo_to_st_id END)mo_in_st_id, 
       (CASE WHEN mo_in_st_id<>0 THEN mo_in_st_id_txt ELSE mo_to_st_id_txt END)mo_in_st_id_txt, --移入仓库(旧) 
       mo_out_st_id, 
       mo_out_st_id_txt, --移出仓库
       mo_id, 
       mo_vo, 
       mo_date, 
       mo_no, 
       mo_order_man, 
       mo_cp_id, 
       mo_di_id, 
       mo_order_man_txt, 
       mo_add_man_txt, 
       mo_add_man, 
       mo_add_time, 
       mo_update_man_txt, 
       mo_update_man, 
       mo_update_time, 
       mo_audit_man_txt, 
       mo_audit_man, 
       mo_audit_time, 
       mo_remark, 
       mo_status, 
       mol_mo_id, 
       mol_id, 
       mol_gi_id, 
       mol_sku_id, 
       -mol_num mol_num, 
       mol_stock_num, 
       mol_discount, 
       -mol_retail_money mol_retail_money,
       mol_retail_price,
       mol_stock_price, 
       -mol_money mol_money, 
       mol_boxbynum,--数量/箱
       -abs(case when isnull(mol_boxbynum,0)=0 then 0 else ceiling(mol_num/mol_boxbynum) end) as mol_box_num, --箱数
       mol_pm, 
       mol_add_time, 
       sumnum, 
       summoney 
FROM (
	SELECT mol_retail_price* mol_num AS mol_retail_money,*
	FROM j_moStorageList el
	LEFT JOIN vi_j_moStorage eo ON el.mol_mo_id = eo.mo_id AND eo.mo_status > 0
	)T  
WHERE mo_out_st_id > 0

UNION ALL

SELECT '移入' mo_out_in,
       mo_in_st_id, 
       mo_in_st_id_txt, --移入仓库(旧) 
       mo_out_st_id, 
       mo_out_st_id_txt, --移出仓库
       mo_id, 
       mo_vo, 
       mo_date, 
       mo_no, 
       mo_order_man, 
       mo_cp_id, 
       mo_di_id, 
       mo_order_man_txt, 
       mo_add_man_txt, 
       mo_add_man, 
       mo_add_time, 
       mo_update_man_txt, 
       mo_update_man, 
       mo_update_time, 
       mo_audit_man_txt, 
       mo_audit_man, 
       mo_audit_time, 
       mo_remark, 
       mo_status, 
       mol_mo_id, 
       mol_id, 
       mol_gi_id, 
       mol_sku_id, 
       mol_num, 
       mol_stock_num, 
       mol_discount, 
       mol_retail_money,
       mol_retail_price,
       mol_stock_price, 
       mol_money, 
       mol_boxbynum,--数量/箱
      (case when isnull(mol_boxbynum,0)=0 then 0 else ceiling(mol_num/mol_boxbynum) end) as mol_box_num, --箱数
       mol_pm, 
       mol_add_time, 
       sumnum, 
       summoney 
FROM (
	SELECT mol_retail_price* mol_num AS mol_retail_money,*
	FROM j_moStorageList el
	LEFT JOIN vi_j_moStorage eo ON el.mol_mo_id = eo.mo_id AND eo.mo_status > 0
	)T  
WHERE mo_in_st_id > 0 AND mo_source_type=0

UNION ALL

SELECT '移入' mo_out_in,
       mo_in_st_id, 
       mo_in_st_id_txt, --移入仓库(新)
      (SELECT mo_out_st_id FROM j_moStorage WHERE mo_id=T.mo_source_id),
      (SELECT (SELECT sei_name FROM b_storageinfo AS bs WITH (NOLOCK) WHERE sei_id = mo_out_st_id) FROM j_moStorage WHERE mo_id=T.mo_source_id), --移出仓库
       mo_id, 
       mo_vo, 
       mo_date, 
       mo_no, 
       mo_order_man, 
       mo_cp_id, 
       mo_di_id, 
       mo_order_man_txt, 
       mo_add_man_txt, 
       mo_add_man, 
       mo_add_time, 
       mo_update_man_txt, 
       mo_update_man, 
       mo_update_time, 
       mo_audit_man_txt, 
       mo_audit_man, 
       mo_audit_time, 
       mo_remark, 
       mo_status, 
       mol_mo_id, 
       mol_id, 
       mol_gi_id, 
       mol_sku_id, 
       mol_num, 
       mol_stock_num, 
       mol_discount, 
       mol_retail_money,
       mol_retail_price,
       mol_stock_price, 
       mol_money, 
       mol_boxbynum,--数量/箱
      (case when isnull(mol_boxbynum,0)=0 then 0 else ceiling(mol_num/mol_boxbynum) end) as mol_box_num, --箱数
       mol_pm, 
       mol_add_time, 
       sumnum, 
       summoney 
FROM (
	SELECT mol_retail_price* mol_num AS mol_retail_money,*
	FROM j_moStorageList el
	LEFT JOIN vi_j_moStorage_RU eo ON el.mol_mo_id = eo.mo_id AND eo.mo_status > 0
	)T  
WHERE T.mo_source_type=2
)T
INNER JOIN b_goodsinfo bg ON bg.gi_id=T.mol_gi_id
LEFT JOIN b_goodsruleset  as grl on  grl.gss_id=T.mol_sku_id

) as TT
LEFT JOIN s_goodsruledetail rulenum WITH (NOLOCK) ON rulenum.gd_id = TT.size
LEFT JOIN s_goodsruledetail colorrule WITH (NOLOCK) ON colorrule.gd_id = TT.col
go

