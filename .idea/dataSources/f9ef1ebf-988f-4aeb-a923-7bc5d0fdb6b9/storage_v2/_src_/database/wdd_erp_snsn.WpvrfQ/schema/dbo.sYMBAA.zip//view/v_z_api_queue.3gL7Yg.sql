CREATE VIEW [dbo].[v_z_api_queue]
	AS 
SELECT 
(case when tdoc_state=0 THEN '处理中' ELSE '完成' end) as tdoc_state_txt,
(CASE WHEN tdoc_level=6 THEN '登录日志'
      WHEN tdoc_level=10 THEN '调试'
      WHEN tdoc_level=20 THEN '信息中心' 
      WHEN tdoc_level=30 THEN '警告' 
      WHEN tdoc_level=40 THEN '错误' 
      WHEN tdoc_level=50 THEN '严重的' 
      end
) AS loglevel,
(case when tdoc_target='royaltyscheme' then '分润'
      when tdoc_target='storage' then '库存'
      when tdoc_target='storedvaluecard' then '储值卡'
      else tdoc_target
   end)as td_target,
   (case when tdoc_action='commissionmemesgpush' then '帐户资金变动提醒'
      when tdoc_action='withdrawalsmemesgpush' then '提成提醒'
      else tdoc_action
   end)as td_action,
   (case when tdoc_method='royaltyscheme' then '分润'
      when tdoc_method='weixinmessagepush' then '微信推送提醒'
      else tdoc_method
   end)as td_method,
* 
FROM [api_queue]
go

