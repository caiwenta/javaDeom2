CREATE VIEW [dbo].[vi_pos_funds_pos_fundsList] AS 
select * from pos_funds as pf WITH (NOLOCK)  inner join pos_fundsList as pfl WITH (NOLOCK) 
on pf.fu_id=pfl.ful_fu_id
where pf.fu_status>0 and pfl.ful_status=1
go

