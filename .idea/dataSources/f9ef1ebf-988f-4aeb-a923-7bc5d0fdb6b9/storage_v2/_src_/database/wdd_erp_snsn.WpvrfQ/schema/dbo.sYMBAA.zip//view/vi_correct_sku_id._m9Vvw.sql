
create View [dbo].[vi_correct_sku_id]
		as
SELECT bgdb.gss_id,bgdb.gs_id,
bgdb.gs_name,
bgdb.gss_no,
bg.gss_id AS new_gss_id,
bg.gs_id AS new_gs_id,bg.gs_name AS new_gs_name,bg.gss_no AS new_gss_no
  FROM b_goodsruleset_delete_back bgdb
INNER JOIN b_goodsruleset bg ON bg.gi_id=bgdb.gi_id
AND bg.gs_id=bgdb.gs_id
go

