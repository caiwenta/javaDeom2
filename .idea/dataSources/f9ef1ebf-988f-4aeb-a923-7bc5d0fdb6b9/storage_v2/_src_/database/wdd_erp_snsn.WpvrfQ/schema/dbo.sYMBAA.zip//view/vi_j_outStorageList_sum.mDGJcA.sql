
CREATE VIEW [dbo].[vi_j_outStorageList_sum] AS 
Select je.ol_eoid,
(
SELECT SUM(ol_box_num) FROM (
 SELECT 
 (case when fd.ol_boxbynum=0 then 0 else ceiling(sum(fd.ol_number)/fd.ol_boxbynum) end) as ol_box_num
 FROM j_outStorageList fd 
 WHERE fd.ol_status=1  AND fd.ol_eoid=je.ol_eoid
 GROUP BY fd.ol_siid,isnull(fd.ol_pm,''),fd.ol_boxbynum
) AS BB
) AS ol_box_num,
Sum(je.ol_number) As ol_number,
Sum(je.ol_realmoney) As ol_realmoney

From j_outStorageList je WITH (NOLOCK) 
 where je.ol_status=1 group By je.ol_eoid
go

