CREATE PROCEDURE [dbo].[pro_instructionNoticeList_sku_search]
	@in_id INT = 0,
	@gi_id INT=0
AS

DECLARE @skuid varchar(200)='';
select 
@skuid=isnull(gi_skus,'')
from b_goodsinfo as bgf where gi_id=@gi_id


IF @skuid=''
BEGIN

SELECT
bg.*,
nlst.*
FROM b_goodsinfo AS bg
LEFT JOIN erp_instructionNoticeList AS nlst ON nlst.inl_gi_id=bg.gi_id AND nlst.inl_sku_id=0 and nlst.inl_in_id=@in_id 
WHERE bg.gi_id=@gi_id

END
ELSE
BEGIN
SELECT
bg.*,
bg2.gi_name,
bg2.gi_code,
nlst.*
FROM b_goodsruleset AS bg
LEFT JOIN erp_instructionNoticeList AS nlst ON nlst.inl_gi_id=bg.gi_id AND nlst.inl_sku_id=bg.gss_id and nlst.inl_in_id=@in_id 
LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE bg.gi_id=@gi_id
END
go

