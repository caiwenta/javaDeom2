CREATE PROCEDURE [dbo].[pro_importbyfile_op]
@if_filepaht varchar(500),
@if_name varchar(100),
@if_type int=0,
@si_id int=0,
@sh_id int=0,
@erp_id int=0,
@cp_id int=0,
@if_target varchar(50)='',
@if_action varchar(50)='',
@if_state int=0,
@if_data text='',
@if_WarehousingType int =-1 
AS

IF NOT EXISTS(SELECT 1 FROM  erp_importbyfile WHERE 
if_filepaht=@if_filepaht 
and sh_id=@sh_id
and si_id=@si_id
and cp_id=@cp_id
and erp_id=@erp_id
and if_target=@if_target 
and if_action=@if_action
AND if_state=0 and if_WarehousingType=@if_WarehousingType)
BEGIN
insert into erp_importbyfile(
if_filepaht,
if_name,
if_type,
cp_id,
si_id,
sh_id,
erp_id,
if_target,
if_action,
if_state,
if_data,
if_WarehousingType
)
values (
@if_filepaht,
@if_name,
@if_type,
@cp_id,
@si_id,
@sh_id,
@erp_id,
@if_target,
@if_action,
@if_state,
@if_data,
@if_WarehousingType
)
END
go

