CREATE Proc [dbo].[pro_getPage]
@page INT=1,--页码
@rows INT=10,--分页大小
@order VARCHAR(300),--排序字符
@sqlStr VARCHAR(max),--查询语句
@ptableName varchar(1000)='',--固化数据的表名
@psqlStr varchar(1000)=''--创建固化数据表的sql
As
IF @page=0
BEGIN
 SET @page=1;
END
DECLARE @sint INT=1;
DECLARE @eint INT=10;
IF @page=1
BEGIN
 SET @sint=1;
 SET @eint=@rows;
END
ELSE
BEGIN
  SET @eint=@rows*@page;
  SET @sint=@eint-@rows+1;
END
DECLARE @sql NVARCHAR(max)='';
SET @sqlStr=rtrim(LTRIM(@sqlStr));
if(@ptableName!='')
BEGIN
 if object_id(@ptableName) is null
 BEGIN
  execute sp_executesql @psqlStr;
 END
END

SET @sqlStr=SUBSTRING(@sqlStr,7,LEN(@sqlStr));

if(@ptableName!='')
begin
 SET @sql='insert into '+@ptableName+' SELECT *  FROM (
SELECT ROW_NUMBER()OVER(ORDER BY '+@order+') AS rownum,'+@sqlStr+'
) AS p1 WHERE p1.rownum BETWEEN @sint AND @eint';
end
else
BEGIN
 SET @sql='SELECT * FROM (
SELECT ROW_NUMBER()OVER(ORDER BY '+@order+') AS rownum,'+@sqlStr+'
) AS p1 WHERE p1.rownum BETWEEN @sint AND @eint';
end

--PRINT @sql;
execute sp_executesql @sql,N'@sint int,@eint int',@sint,@eint;
go

