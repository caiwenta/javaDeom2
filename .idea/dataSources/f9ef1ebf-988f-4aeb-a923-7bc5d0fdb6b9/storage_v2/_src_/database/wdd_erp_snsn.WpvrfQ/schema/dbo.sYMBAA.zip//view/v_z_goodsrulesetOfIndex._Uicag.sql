CREATE VIEW [dbo].[v_z_goodsrulesetOfIndex]
AS
SELECT  gss_id ,
        gs_id ,
        gs_name ,
        gss_no ,
        gi_id ,
        gss_erp_id ,
        CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id,'/',1),'-',1)) AS group1 ,
        CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id,'/',1),'-',2)) AS rule1 ,
        dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_name,'|',1),':',1) AS groupname1 ,
        dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_name,'|',1),':',2) AS rulename1 ,
        CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id,'/',2),'-',1)) AS group2 ,
        CONVERT(INT,dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_id,'/',2),'-',2)) AS rule2 ,
        dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_name,'|',2),':',1) AS groupname2 ,
        dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(gs_name,'|',2),':',2) AS rulename2 ,
        gs_salesprice ,
        gs_marketprice ,
        gs_costprice ,
        gs_purchase
FROM    dbo.b_goodsruleset WITH (NOLOCK)
WHERE   gs_status <> 0
go

