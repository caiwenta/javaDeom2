CREATE PROCEDURE [dbo].[pro_AvailableInventory]
	@orderid int = 0,
	@type int --1:配货 2:区域移仓(需求通知)
AS
--明细表有多个规格重复会报错 只能一对一
--@type 1:配货
--可用库存配货

DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
BEGIN TRY

declare @aitable table(
 ordid INT,
 number int,
 gi_id int,
 sku_id int,
 pm varchar(500),
 locationid int
)


declare @seiid int=0;
declare @cp_id int=0;

if @type=1
begin

	select 
	@seiid=al_st_id,
	@cp_id=al_cp_id
	from pos_allocation 
	where al_id=@orderid


	INSERT INTO @aitable(ordid,number,gi_id,sku_id,pm,locationid)
	SELECT 
		ord.ordid,
		isnull((bsf.si_number-bsf.take_up_num),0) AS curnumber, --按可配库存数配货
		ord.gi_id,
		ord.sku_id,
		ord.pm,
		ord.locationid
	FROM (
			SELECT  
			all_al_id AS ordid,
			st.all_gi_id AS gi_id,    
			st.all_sku_id AS sku_id,  
			sum(st.all_num) AS num,  
			ISNULL(st.all_pm,'') AS pm,
			st.locationid  
			FROM (  
		
				SELECT   
				all_al_id,  
				all_gi_id,  
				all_sku_id,  
				((isnull(all_num,0)-ISNULL((SELECT sum(josl.ol_number) AS ol_number FROM j_outStorage AS jos WITH (NOLOCK) INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) ON jos.oo_id = josl.ol_eoid 
				WHERE jos.oo_source_type=1 and jos.oo_status<>0 AND josl.ol_source_id=st.all_id AND josl.ol_status<>0 AND josl.ol_status = 1), 0)-isnull(st.all_pause_num,0))  
				) AS all_num,   
				ISNULL(st.all_pm,'') AS all_pm, 
				0 AS locationid   
				FROM pos_allocation ge WITH (NOLOCK)    
				inner join pos_allocationList st WITH (NOLOCK) ON ge.al_id = st.all_al_id and st.all_status>0 -- st.all_status = 1 补货生成的配货单all_status状态会临时为0
				WHERE st.all_al_id=@orderid
	
			) AS st  
			GROUP BY all_al_id,st.all_gi_id,st.all_sku_id,st.all_pm,st.locationid
		) AS ord
	 LEFT JOIN(  
		SELECT   
		ss.si_cp_id,    
		ss.si_seiid,   
		ss.si_giid,   
		ss.si_skuid,   
		ss.si_number,    
		(ISNULL(ss.si_occupy_num,0)+ISNULL(ss.si_allocationoccupy_num,0)+ISNULL(ss.si_orderblankoccupy_num,0)) AS take_up_num  
		FROM b_stockinfo AS ss WITH (NOLOCK)  WHERE ss.si_status>0 AND ss.si_seiid=@seiid
	) AS bsf ON 
	ord.gi_id=bsf.si_giid AND 
	ord.sku_id=bsf.si_skuid
	WHERE (isnull((bsf.si_number-bsf.take_up_num),0)-ord.num)<0


	--修改配货的数量
	UPDATE pos_allocationList 
	SET all_num = ap.number,
		all_old_num=all_num
	FROM pos_allocationList psa 
	INNER JOIN @aitable as ap ON 
		psa.all_al_id=ap.ordid AND 
		psa.all_gi_id=ap.gi_id AND 
		psa.all_sku_id=ap.sku_id AND 
		ISNULL(psa.all_pm,'')=ap.pm 
	where psa.all_al_id=@orderid

	UPDATE pos_allocationList set all_status=0  where all_al_id=@orderid and all_num=0


	IF NOT EXISTS(SELECT * FROM pos_allocationList WHERE all_num<>0 AND all_status>0 and all_al_id=@orderid)
	BEGIN
		update pos_allocation set al_status=0 where al_id=@orderid
	END

end


if @type=2
begin
	select 
		@seiid=mo_out_st_id,
		@cp_id=mo_cp_id
	from j_orderblank 
	where mo_id=@orderid

	INSERT INTO @aitable(ordid,number,gi_id,sku_id,pm,locationid)
	SELECT 
		ord.ordid,
		isnull((bsf.si_number-bsf.take_up_num),0) AS curnumber, --按可配库存数配货
		ord.gi_id,
		ord.sku_id,
		ord.pm,
		ord.locationid
	FROM (
			SELECT 
				mol_mo_id AS ordid,
				mol_gi_id AS gi_id,    
				mol_sku_id AS sku_id,  
				sum(mo_num) AS num,  
				mol_pm AS pm,
				locationid
			FROM (
				SELECT 
				jol.mol_mo_id,
				jol.mol_gi_id,
				jol.mol_sku_id,
				abs(jol.mol_num) AS  mo_num,
				isnull(jol.mol_pm,'') AS mol_pm,
				isnull(jol.mol_locationid,0) AS locationid
				FROM j_orderblank AS jo
				INNER JOIN j_orderblanklist AS jol ON jo.mo_id=jol.mol_mo_id
				WHERE jol.mol_mo_id=@orderid
			) AS bb
			GROUP BY 
			mol_mo_id,mol_gi_id,mol_sku_id,locationid,mol_pm
		) AS ord
	 LEFT JOIN(  
		SELECT   
			ss.si_cp_id,    
			ss.si_seiid,   
			ss.si_giid,   
			ss.si_skuid,   
			ss.si_number,    
			(ISNULL(ss.si_occupy_num,0)+ISNULL(ss.si_allocationoccupy_num,0)+ISNULL(ss.si_orderblankoccupy_num,0)) AS take_up_num  
		FROM b_stockinfo AS ss WITH (NOLOCK) WHERE ss.si_status>0 AND ss.si_seiid=@seiid
	) AS bsf ON 
	ord.gi_id=bsf.si_giid AND 
	ord.sku_id=bsf.si_skuid
	WHERE (isnull((bsf.si_number-bsf.take_up_num),0)-ord.num)<0

	UPDATE j_orderblanklist 
	SET mol_num = ap.number,
		mol_old_num=mol_num
	FROM j_orderblanklist psa 
	INNER JOIN @aitable as ap ON 
		psa.mol_mo_id=ap.ordid AND 
		psa.mol_gi_id=ap.gi_id AND 
		psa.mol_sku_id=ap.sku_id AND 
		ISNULL(psa.mol_pm,'')=ap.pm and
		isnull(psa.mol_locationid,0)=ap.locationid
	where psa.mol_mo_id=@orderid


	UPDATE j_orderblanklist set mol_status=0  where mol_mo_id=@orderid and mol_num=0

	IF NOT EXISTS(SELECT * FROM j_orderblanklist WHERE mol_num<>0 AND mol_status>0 and mol_mo_id=@orderid)
	BEGIN
		update j_orderblank set mo_status=0 where mo_id=@orderid
	END

end












END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

