







CREATE PROC [dbo].[pro_pos_takeStorageList_sku_search_tb]
  @gi_id INT = 259,
  @sei_id INT = 19,
  @date VARCHAR(50) = '2004-9-10',
  @add_time DATETIME = '2004-9-10 11:56:14',
  @ts_id INT = 0,
  @sh_id INT = 0
AS

BEGIN
SELECT bg.*,
       jt.*,
       js.stock_num,bg2.gi_name,bg2.gi_code INTO #p
FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT js.sl_giid,
                       js.sl_skuid,
                       SUM(
                           CASE 
                                WHEN js.sl_counttype = 1 THEN js.sl_number
                                ELSE -js.sl_number
                           END
                       ) AS stock_num
                FROM   pos_stocklog AS js
                WHERE  js.sl_seiid = @sei_id
                       AND js.sl_giid = @gi_id
                       AND (
                               (
                                   --CONVERT(VARCHAR(50), js.sl_addtime, 23) <= @date AND 
                                   CONVERT(VARCHAR(50), js.sl_order_date, 23)
                                       <= @date
                               )
                               OR js.sl_type = 3
                           )
                       AND js.sl_status != 0
                       AND js.sl_shop_id = @sh_id
                GROUP BY
                       js.sl_giid,
                       js.sl_skuid
            )          AS js
            ON  bg.gi_id = js.sl_giid
            AND bg.gss_id = js.sl_skuid
       LEFT JOIN (
                SELECT *
                FROM   pos_takeStorageList AS jt
                WHERE  jt.tsl_ts_id = @ts_id
                       AND jt.tsl_add_time = @add_time
            )          AS jt
            ON  bg.gi_id = jt.tsl_gi_id
            AND bg.gss_id = jt.tsl_sku_id  LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
WHERE  bg.gi_id = @gi_id 



	declare @type int=1;--交易方式订货
	declare @returntable table(
			gi_id int,
			sku_id int,
			retailprice DECIMAL(9, 2),--零售价
			discount DECIMAL(9, 2),
			importprices DECIMAL(9, 2)    --供货价
	);
	INSERT @returntable
	SELECT
				gi_id,
				gi_skuid,
				gs_marketprice,
				gs_discount,
				gs_purchase
	FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,0,@sh_id,0,@type);


	update #p set
		        gs_salesprice= l.importprices,
				gs_purchase = l.importprices,
				gs_discount=l.discount
	from #p as p 
	inner join @returntable as l on p.gi_id=l.gi_id and p.gss_id=l.sku_id


	--吊牌价设置
	DECLARE @lsj       DECIMAL(9, 2) = 0;--零售价
	DECLARE @dpj_type  INT = 0;--吊牌价类型

	SELECT @dpj_type = ps.sh_goods_type
	FROM   pos_shop ps
	WHERE  ps.sh_id = @sh_id

	IF @dpj_type != 0
	BEGIN
	    SELECT @lsj = gd_price
	    FROM   b_goods_discount
	    WHERE  gd_type = @dpj_type
	           AND gd_class = 1 AND gd_gi_id = @gi_id
		--零售价
		UPDATE #p SET  gs_marketprice = @lsj
	END

	UPDATE #p
	    SET   gs_discount = (
	               CASE 
	                    WHEN gs_marketprice = 0.00 THEN 0.00
	                    ELSE gs_purchase / gs_marketprice
	               END
	    )



    SELECT * FROM   #p




	--DECLARE @ghj       DECIMAL(9, 2) = 0;
	--DECLARE @lsj       DECIMAL(9, 2) = 0;
	--DECLARE @ghj_type  INT = 0;
	--DECLARE @dpj_type  INT = 0;
 --   declare @discount DECIMAL(9, 2) = 1;
	--SELECT @ghj_type = ps.sh_dhprice,
	--       @discount=sh_dhdiscount
	--FROM   pos_shop ps
	--WHERE  ps.sh_id = @sh_id
	
	--SELECT @dpj_type = ps.sh_goods_type
	--FROM   pos_shop ps
	--WHERE  ps.sh_id = @sh_id

	--IF @dpj_type != 0
	--BEGIN
	--    SELECT @lsj = gd_price
	--    FROM   b_goods_discount
	--    WHERE  gd_type = @dpj_type
	--           AND gd_class = 1 AND gd_gi_id = @gi_id
	--END
	--IF @dpj_type = 0 OR @lsj = 0 
	--BEGIN
	--    SELECT @lsj = bg.gi_retailprice
	--    FROM   b_goodsinfo bg
	--    WHERE  bg.gi_id = @gi_id
	--END
	
	--SELECT @ghj = gd_price
	--FROM   b_goods_discount
	--WHERE  gd_gi_id = @gi_id
	--       AND gd_class = 2
	--       AND gd_type = @ghj_type
	
	----零售价
	--UPDATE #p
	--SET    gs_marketprice = @lsj
	
	
	--IF @ghj > 0.00
	--BEGIN
	--    --更细供货价
	--    UPDATE #p
	--    SET    gs_purchase = @ghj*@discount
	    
	--    --更新折扣价
	--    UPDATE #p
	--    SET    gs_discount = (
	--               CASE 
	--                    WHEN gs_marketprice = 0.00 THEN 0.00
	--                    ELSE gs_purchase / gs_marketprice
	--               END
	--           )
	--END
	--ELSE
	--BEGIN
	--    UPDATE #p
	--    SET    gs_purchase = @lsj
	    
	--    UPDATE #p
	--    SET    gs_discount = 1
	--END
	
	
	
	
	
END
go

