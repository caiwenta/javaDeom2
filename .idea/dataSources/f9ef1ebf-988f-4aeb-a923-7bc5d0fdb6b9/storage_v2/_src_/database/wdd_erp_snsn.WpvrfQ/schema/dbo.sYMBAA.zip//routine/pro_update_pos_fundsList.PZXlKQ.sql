CREATE PROC [dbo].[pro_update_pos_fundsList] ( @fu_id INT )
AS
    DECLARE @fu_sh_id INT = 0;

    SELECT  @fu_sh_id = fu_sh_id
    FROM    pos_funds
    WHERE   fu_id = @fu_id;

    UPDATE  pos_fundsList
    SET     ful_start_money = fd.qc ,
            ful_end_money = fd.qm
    FROM    pos_fundsList AS fd2 ,
            ( SELECT    * ,
                        qm = fd.qc + CASE WHEN fd.fu_type = 0
                                          THEN
												--应收
												--实际金额+垫付运费+其他应收-其他应付-退货金额-本次收款
                                               fd.ful_in_money + fd.ful_freight + fd.ful_other_out_money - fd.ful_other_in_money - fd.ful_out_money
                                               - fd.ful_money
                                          WHEN fd.fu_type = 1
                                          THEN 
												--应付
												--实际金额+其他应付-退货金额-本次付款-垫付运费-其他应收
                                               fd.ful_in_money + fd.ful_other_in_money - fd.ful_out_money - fd.ful_money - fd.ful_freight
                                               - fd.ful_other_out_money
                                     END
              FROM      ( SELECT    fd.fu_id ,
                                    fd.ful_id ,
                                    fd.fu_type ,
                                    fd.ful_freight ,
                                    fd.ful_other_out_money ,
                                    fd.ful_other_in_money ,
                                    fd.ful_money ,
                                    fd.ful_in_money ,
                                    fd.ful_out_money ,
                                    COUNT(1) AS count ,
                                    qc = ISNULL(SUM(CASE WHEN fd.fu_type = 0
                                                         THEN
															--应收
															--实际金额+垫付运费+其他应收-其他应付-退货金额-本次收款
                                                              fd2.ful_in_money + fd2.ful_freight + fd2.ful_other_out_money - fd2.ful_other_in_money
                                                              - fd2.ful_out_money - fd2.ful_money
                                                         WHEN fd.fu_type = 1
                                                         THEN 
															--应付
															--实际金额+其他应付-退货金额-本次付款-垫付运费-其他应收
                                                              fd2.ful_in_money + fd2.ful_other_in_money - fd2.ful_out_money - fd2.ful_money - fd2.ful_freight
                                                              - fd2.ful_other_out_money
                                                    END), 0)
                          FROM      vi_pos_funds_pos_fundsList AS fd
                          LEFT JOIN vi_pos_funds_pos_fundsList AS fd2 ON fd2.fu_sh_id = fd.fu_sh_id
                                                                         AND fd2.fu_dateint <= fd.fu_dateint
                                                                         AND fd2.fu_orderint <= fd.fu_orderint
                                                                         AND fd2.ful_add_time < fd.ful_add_time
                          WHERE     fd.fu_sh_id = @fu_sh_id
                          GROUP BY  fd.fu_id ,
                                    fd.ful_id ,
                                    fd.fu_type ,
                                    fd.ful_freight ,
                                    fd.ful_other_out_money ,
                                    fd.ful_other_in_money ,
                                    fd.ful_money ,
                                    fd.ful_in_money ,
                                    fd.ful_out_money
                        ) AS fd
            ) AS fd
    WHERE   fd2.ful_id = fd.ful_id
go

