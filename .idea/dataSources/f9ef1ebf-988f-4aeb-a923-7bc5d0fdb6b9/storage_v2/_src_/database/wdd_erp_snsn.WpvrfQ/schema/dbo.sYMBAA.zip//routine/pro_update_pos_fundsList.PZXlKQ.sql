
CREATE Proc [dbo].[pro_update_pos_fundsList]
As
update pos_fundsList
set
 ful_start_money = fd.qc,
 ful_end_money = fd.qm
from pos_fundsList as fd2,(
select 
*,
qm=fd.qc+case 
when fd.fu_type=0 then
 --应收
 --实际金额+垫付运费+其他应收-其他应付-退货金额-本次收款
 fd.ful_in_money+fd.ful_freight+fd.ful_other_out_money-fd.ful_other_in_money-fd.ful_out_money-fd.ful_money
when fd.fu_type=1 then 
 --应付
 --实际金额+其他应付-退货金额-本次付款-垫付运费-其他应收
 fd.ful_in_money+fd.ful_other_in_money-fd.ful_out_money-fd.ful_money-fd.ful_freight-fd.ful_other_out_money
end
from (
select 
fd.fu_id,
fd.ful_id,
fd.fu_type,
fd.ful_freight, 
fd.ful_other_out_money, 
fd.ful_other_in_money, 
fd.ful_money,
fd.ful_in_money, 
fd.ful_out_money,
Count(1) As count,
qc=isnull(sum(
case 
when fd.fu_type=0 then
 --应收
 --实际金额+垫付运费+其他应收-其他应付-退货金额-本次收款
 fd2.ful_in_money+fd2.ful_freight+fd2.ful_other_out_money-fd2.ful_other_in_money-fd2.ful_out_money-fd2.ful_money
when fd.fu_type=1 then 
 --应付
 --实际金额+其他应付-退货金额-本次付款-垫付运费-其他应收
 fd2.ful_in_money+fd2.ful_other_in_money-fd2.ful_out_money-fd2.ful_money-fd2.ful_freight-fd2.ful_other_out_money
end),0)
from 
vi_pos_funds_pos_fundsList as fd left join vi_pos_funds_pos_fundsList as fd2
on fd.fu_sh_id=fd2.fu_sh_id 
and fd2.fu_dateint<=fd.fu_dateint 
and fd2.fu_orderint<=fd.fu_orderint
and fd2.ful_add_time<fd.ful_add_time
group by 
fd.fu_id,
fd.ful_id,
fd.fu_type,
fd.ful_freight, 
fd.ful_other_out_money, 
fd.ful_other_in_money, 
fd.ful_money,
fd.ful_in_money, 
fd.ful_out_money
) as fd
) as fd where fd2.ful_id=fd.ful_id
go

