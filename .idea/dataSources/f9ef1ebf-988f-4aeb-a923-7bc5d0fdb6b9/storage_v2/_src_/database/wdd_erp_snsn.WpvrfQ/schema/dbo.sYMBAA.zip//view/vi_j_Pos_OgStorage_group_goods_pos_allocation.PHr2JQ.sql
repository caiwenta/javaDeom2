






CREATE VIEW [dbo].[vi_j_Pos_OgStorage_group_goods_pos_allocation]
		AS
SELECT jt.ogl_og_id,
       jt.ogl_gi_id,
       jt.ogl_num,
       jt.ogl_id,
       jt.ogl_money,
       jt.ogl_retail_money,
       jt.ogl_retail_price,
       jt.ogl_stock_price,
       jt.ogl_sku_id,
       CONVERT(VARCHAR(100), jt.ogl_add_time, 25) AS ogl_add_time,
       jt.ogl_discount,
       ogl_box_num,
       ogl_pm,
       ISNULL(fd.all_num, 0)        AS ogl_num_ed,
       (jt.ogl_num -ISNULL(fd.all_num, 0))-ISNULL(jt.ogl_pause_num,0) AS ogl_num_ding,
       (jt.ogl_num -ISNULL(fd.all_num, 0))-ISNULL(jt.ogl_pause_num,0) AS ogl_num_do,
       (jt.ogl_num -ISNULL(fd.all_num, 0))-ISNULL(jt.ogl_pause_num,0) AS ogl_num_end,
	   ogl_pause_num,--终止数量
       
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
       bg.gi_retailprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bu.ut_name                   AS gi_unit
      
FROM   vi_j_Pos_OgStorageList AS jt
       INNER  JOIN dbo.b_goodsinfo  AS bg
            ON  jt.ogl_gi_id = bg.gi_id
       INNER  JOIN dbo.b_unit       AS bu
            ON  bg.gi_unit = bu.ut_id
       LEFT JOIN 
            (
            	
                SELECT all_gi_id,
                       SUM(all_num) AS all_num,
                       all_source_add_time
                  
                FROM   pos_allocationList
                       INNER JOIN pos_allocation
                            ON  all_al_id = al_id
                WHERE  al_status > 0
                       AND all_status > 0
                       AND al_source = 5
                       AND all_source_add_time > 0
                GROUP BY
                   
                       all_gi_id,
                       all_source_add_time
            )
            fd
            ON  
             fd.all_gi_id = ogl_gi_id
            AND fd.all_source_add_time = ogl_add_time
go

