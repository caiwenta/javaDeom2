CREATE VIEW [dbo].[vi_pos_stockSumList_copy] AS 
SELECT
	ss.shid,
	ss.gid,
	ss.skuid,
	ss.sid,
	ss.gnum,
	bs.sei_name,
	bs.sei_is_tb,--是否同步
	bg2.gs_name,
	bg2.gss_no,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.gi_unit,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_add_man,
	bg.gi_add_time,
	bg.gi_update_man,
	bg.gi_update_time,
	bg.gi_cp_id,
	bg.gi_di_id,
	bg.gi_attribute_ids,
	bg.gi_is_tb,
	bg.gi_attribute_parentids,
	bg.gi_purchase_discount,
	bu.ut_name,
--	--最后的供应商
--	(
--		SELECT
--			(
--(case shid when -1 then '未进货' else (
				  
--						isnull(
--							(
--								CASE type
--								WHEN 0 THEN
--									(
--										SELECT top 1 dbo.companyinfo.cp_name FROM dbo.companyinfo INNER JOIN dbo.pos_shop ON dbo.companyinfo.cp_id = dbo.pos_shop.sh_company WHERE dbo.pos_shop.sh_id =  shid
--									)
--								WHEN 1 THEN
--									(
--										SELECT
--											TOP 1 dbo.pos_shop.sh_name
--										FROM
--											dbo.pos_alStorage
--										INNER JOIN dbo.pos_shop ON dbo.pos_alStorage.al_get_sh_id = dbo.pos_shop.sh_id
--										WHERE
--											sh_id = shid
--									)
--								WHEN 2 THEN
--									(
--										SELECT
--											TOP 1 dbo.pos_supplierinfo.si_name
--										FROM
--											dbo.pos_inStorage
--										INNER JOIN dbo.pos_supplierinfo ON dbo.pos_supplierinfo.si_id = dbo.pos_inStorage.in_supplier_sh_id
--										WHERE
--											in_supplier_sh_id = shid
--									)
--								WHEN 3 THEN
--									'总部出库'
--								END
--							),
--							'未选择'
--						)
--					)
--			 end )
--			) AS gonghuofang

--		FROM
--			(
--				SELECT
--					TOP 1 lasttime,
--					shid,
--					type,
--					gid
--				FROM
--					(
--						--补货
--						SELECT
--							TOP 1 dbo.pos_reStorage.re_audit_time AS lasttime,
--							dbo.pos_reStorage.re_supplier_sh_id AS shid,
--							0 type,
--							rel_gi_id AS gid
--						FROM
--							dbo.pos_reStorageList
--						INNER JOIN dbo.pos_reStorage ON dbo.pos_reStorageList.rel_re_id = dbo.pos_reStorage.re_id
--						WHERE
--							re_audit_time <> ''
--						AND rel_gi_id = bg.gi_id
--						ORDER BY
--							re_audit_time DESC
--						UNION ALL
--							(
--								--调拨
--								SELECT
--									TOP 1 dbo.pos_alStorage.al_audit_time AS lasttime,
--									pos_alStorage.al_get_sh_id AS shid,
--									1 type,
--									all_gi_id AS gid
--								FROM
--									dbo.pos_alStorageList
--								INNER JOIN dbo.pos_alStorage ON dbo.pos_alStorageList.all_al_id = dbo.pos_alStorage.al_id
--								WHERE
--									al_audit_time <> ''
--								AND all_gi_id = bg.gi_id
--								and pos_alStorage.al_st_id = ss.sid
--								ORDER BY
--									al_audit_time DESC
--							)
--						UNION
--							(
--								--入库
--								SELECT
--									TOP 1 dbo.pos_inStorage.in_audit_time AS lasttime,
--									dbo.pos_inStorage.in_supplier_sh_id AS shid,
--									2 type,
--									inl_gi_id AS gid
--								FROM
--									dbo.pos_inStorageList
--								INNER JOIN dbo.pos_inStorage ON dbo.pos_inStorageList.inl_in_id = dbo.pos_inStorage.in_id
--								WHERE
--									in_audit_time <> ''
--								AND inl_gi_id = bg.gi_id
--								and pos_inStorageList.inl_source_id='0'
--								and pos_inStorage.in_st_id = ss.sid
--								ORDER BY
--									in_audit_time DESC
--							)
--						UNION
--							(
--								--总部出库
--							 SELECT
--								TOP 1 dbo.j_outStorage.oo_auditdate AS lasttime,
--								0 shid,3 type,j_outStorageList.ol_siid AS gid
--								FROM
--								dbo.j_outStorageList
--								INNER JOIN dbo.j_outStorage ON dbo.j_outStorageList.ol_eoid = dbo.j_outStorage.oo_id
--								INNER JOIN dbo.pos_inStorage ON dbo.pos_inStorage.in_source_id = dbo.j_outStorage.oo_id
--								WHERE
--								dbo.j_outStorage.oo_auditdate <> '' AND
--								dbo.j_outStorageList.ol_siid =  bg.gi_id	 AND
--								dbo.j_outStorage.oo_no <> '' AND
--								dbo.pos_inStorage.in_st_id = ss.sid 
--								ORDER BY
--								dbo.j_outStorage.oo_auditdate DESC
--							)
--						UNION(SELECT -1 lasttime,-1 shid,-1 type,-1 gid)
--					) temp
--				ORDER BY
--					temp.lasttime DESC
--			) t
--	) gonghuofang 
	
	
	
	
	
	--垂直列,颜色列
                 -- ,
                  vertical_column_id = CASE 
                                            WHEN ISNULL(
                                                     dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 1),
                                                     0
                                                 ) = 0 THEN --没规格
                                                 0
                                            ELSE CASE 
                                                      WHEN bg2.gs_is_custom > 0 THEN CASE 
                                                                                         WHEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 1)
                                                                                              )
                                                                                              = 
                                                                                              bg2.gs_is_custom THEN 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 2), '-', 2)
                                                                                              )
                                                                                         ELSE 
                                                                                              CONVERT(
                                                                                                  INT,
                                                                                                  dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 2)
                                                                                              )
                                                                                    END
                                                      ELSE CONVERT(
                                                               INT,
                                                               dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 2)
                                                           )
                                                 END
                                       END,
                  vertical_column_name = CASE 
                                              WHEN ISNULL(
                                                       dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 1),
                                                       0
                                                   ) = 0 THEN --没规格
                                                   ''
                                              ELSE CASE 
                                                        WHEN bg2.gs_is_custom > 0 THEN CASE 
                                                                                           WHEN 
                                                                                                CONVERT(
                                                                                                    INT,
                                                                                                    dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_id, '/', 1), '-', 1)
                                                                                                )
                                                                                                = 
                                                                                                bg2.gs_is_custom THEN 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_name, '|', 2), ':', 2)
                                                                                           ELSE 
                                                                                                dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_name, '|', 1), ':', 2)
                                                                                      END
                                                        ELSE dbo.Get_StrArrayStrOfIndex(dbo.Get_StrArrayStrOfIndex(bg2.gs_name, '|', 1), ':', 2)
                                                   END
                                         END

--最后的供应商
,psi.st_occupy_num
,
	enable_stock_num=ss.gnum-ISNULL(psi.st_occupy_num,0)
FROM
	dbo.vi_pos_stockSum AS ss
	INNER JOIN pos_stockInfo psi WITH (NOLOCK) 
	ON ss.shid=psi.st_sh_id
	AND ss.[sid]=psi.st_st_id
	AND ss.gid=psi.st_gi_id
	AND ss.skuid=psi.st_sku_id
LEFT OUTER JOIN dbo.pos_storageInfo AS bs ON ss.sid = bs.sei_id
INNER JOIN dbo.b_goodsinfo AS bg ON ss.gid = bg.gi_id
LEFT OUTER JOIN dbo.b_goodsruleset AS bg2 ON ss.skuid = bg2.gss_id
LEFT OUTER JOIN dbo.b_unit AS bu ON bg.gi_unit = bu.ut_id
go

