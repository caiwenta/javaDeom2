

CREATE PROCEDURE [dbo].[pro_b_goods_discount_op]
@gd_id int,
@gd_gi_id int,
@gd_type int,
@gd_discount decimal(6,2),
@gd_price decimal(18,2),
@gd_class int,
@gd_add_man int,
@gd_add_time datetime,
@gd_update_man int,
@gd_update_time datetime,
@gd_erp_id int=0,
--操作类型(1:添加 2:修改)
@op_type Int=0,
@outResult int Output
AS
BEGIN
	 IF @op_type=1
    Begin
	INSERT INTO [b_goods_discount](
	[gd_gi_id],[gd_type],[gd_discount],[gd_price],[gd_class],[gd_add_man],[gd_add_time],gd_erp_id
	)VALUES(
	@gd_gi_id,@gd_type,@gd_discount,@gd_price,@gd_class,@gd_add_man,@gd_add_time,@gd_erp_id
	)
	SET @gd_id = SCOPE_IDENTITY()
	END
	
	IF @op_type=2
    Begin
    UPDATE [b_goods_discount] SET 
	[gd_discount] = @gd_discount,[gd_price] = @gd_price,[gd_update_man] = @gd_update_man,[gd_update_time] = @gd_update_time
	WHERE gd_gi_id=@gd_gi_id  and  gd_type=@gd_type  and gd_class=@gd_class
    END
    
    if @@error<>0 
	begin 
		set @outResult=0;
	end
	else 
	begin
	   set @outResult=@gd_id;
	end
	  Return @outResult;
	END
go

