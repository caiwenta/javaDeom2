
CREATE PROCEDURE [dbo].[pro_no_ruleset_puruchse]
	@date varchar(30)='',
	@gi_id INT=0,
	--客户
	@ci_id INT=0,
	--店铺
	@sh_id INT=0,
	--分公司
	@to_cp_id INT=0 ,
	--交易类型
	@type INT=0,
	@st_id int=0,
	@gss_no varchar(30) = '',
	@cp_id int=0
AS	
	if @gss_no != ''
	begin
		select @gi_id = gi_id from b_goodsinfo where gi_barcode = @gss_no
	end

	declare @returntable table(
			cspid int,
			gi_id int,
			sku_id int,
			retailprice DECIMAL(9, 2),--零售价
			discount DECIMAL(9, 2),
			importprices DECIMAL(9, 2)    --供货价
	)
	--供货价
	DECLARE @ghj DECIMAL(9, 2) = 0;
	--供货价类别
	DECLARE @ghj_type INT = 0
	
	
				
	BEGIN
		
			SELECT *,(select SUM(gnum) from vi_stockSumList where  gi_id=@gi_id and sei_id=@st_id) as Repertory,
			         (select si_number-(ISNULL(si_occupy_num,0)+ISNULL(si_allocationoccupy_num,0)+ISNULL(si_orderblankoccupy_num,0)) 
					  from b_stockinfo  
					  where  si_giid=@gi_id and si_seiid=@st_id) as EnableRepertory INTO #p
		FROM   b_goodsinfo  AS bg WHERE  bg.gi_id= @gi_id;


		        UPDATE #p
		        SET    gi_purchase = gi_retailprice,gi_purchase_discount=1
				WHERE ISNULL(gi_purchase,0)=0

		        UPDATE #p
		        SET    gi_purchase_discount =gi_purchase/gi_retailprice
		        WHERE ISNULL(gi_purchase,0)!=0
				AND ISNULL(gi_purchase_discount,0)=0
		        
		        
        IF @type > 0
		begin
		   if @date!=''
		   begin

				INSERT @returntable
				SELECT * FROM dbo.FnGoodsCustomPrice(@ci_id,@sh_id,@to_cp_id,@date,@gi_id,0,@cp_id);

		   end
		   if exists (select * from @returntable)  
			begin

		    update #p set
					gi_retailprice=l.retailprice,
					gi_importprices= l.importprices,
					gi_purchase = l.importprices,
					gi_purchase_discount=l.discount
		    from #p as p 
	        inner join @returntable as l on p.gi_id=l.gi_id

			end
			else
			begin

				INSERT @returntable
				SELECT
					0,
					gi_id,
					gi_skuid,
					gs_marketprice,
					gs_discount,
					gs_purchase
				FROM dbo.FnGoodsERPPurchasePrice(@gi_id,0,@ci_id,@sh_id,@to_cp_id,@type);
		  
			update #p set
		        gi_importprices= l.importprices,
				gi_purchase = l.importprices,
				gi_purchase_discount=l.discount
			 from #p as p 
			inner join @returntable as l on p.gi_id=l.gi_id 


			end
		end


		SELECT * FROM   #p
	END
go

