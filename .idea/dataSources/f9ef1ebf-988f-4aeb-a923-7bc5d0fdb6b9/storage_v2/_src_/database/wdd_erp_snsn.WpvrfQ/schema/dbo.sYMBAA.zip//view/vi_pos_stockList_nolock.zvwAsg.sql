

CREATE VIEW [dbo].[vi_pos_stockList_nolock] AS 
SELECT 

--je.ord_no,

       je.in_st_id           AS SID,
       je.in_sh_id           AS shid,
       cid = 0,
       je2.inl_gi_id         AS gid,
       je2.inl_sku_id        AS skuid,
       je2.inl_num           AS gnum,
	   isnull(je2.inl_pm,'')        As pm ,
       countType = CASE 
                        WHEN je.in_type = 0 THEN 1
                        ELSE 0
                   END,
       myremark = CASE 
                       WHEN je.in_type = 0 THEN '入库'
                       ELSE     '入库退货'
                  END,
       addtime = je2.inl_add_time,
       orderno = je.in_vo,
       eoid = je.in_id,
       elid = je2.inl_id,
       mytype = 1,
       order_add_time = je.in_add_time,
       order_date = je.in_date
       ,je.in_erp_id AS erp_id
       
FROM   pos_inStorage je WITH (NOLOCK) 
       INNER JOIN pos_inStorageList je2  WITH (NOLOCK) 
            ON  je.in_id = je2.inl_in_id
WHERE  je.in_status > 0
       AND je2.inl_status = 1
       AND je2.inl_gi_id > 0
       AND je.in_st_id > 0
UNION ALL
SELECT 

--'' AS                              ord_no,

       jt.in_st_id                     AS [sid],
       jt.in_sh_id                     AS shid,
       cid = 0,
       ji.inl_gi_id                    AS gid,
       ji.inl_sku_id                   AS skuid,
       ji.inl_num                      AS gnum,
	   isnull(ji.inl_pm,'')        As pm ,
       countType = 1,
       myremark = '期初',
       ji.inl_add_time                 AS addtime,
       jt.in_vo                        AS orderno,
       jt.in_id                        AS eoid,
       ji.inl_id                       AS elid,
       mytype = 3,
       order_add_time = jt.in_add_time,
       order_date = jt.in_date
              ,jt.in_erp_id AS erp_id
FROM   pos_initStorage                 AS jt  WITH (NOLOCK) 
       INNER JOIN pos_initStorageList  AS ji  WITH (NOLOCK) 
            ON  jt.in_id = ji.inl_in_id
WHERE  jt.in_status > 0
       AND ji.inl_status = 1
       AND ji.inl_gi_id > 0
       AND jt.in_st_id > 0
UNION ALL
SELECT 

--'' AS                            ord_no,


       jms.mo_out_st_id              AS SID,
       jms.mo_sh_id                  AS shid,
       cid = 0,
       jmsl.mol_gi_id                AS gid,
       jmsl.mol_sku_id               AS skuid,
       jmsl.mol_num                  AS gnum,
	   isnull(jmsl.mol_pm,'')        As pm ,
       countType = 0,
       myremark = '移出仓库',
       addtime = jmsl.mol_add_time,
       orderno = mo_vo,
       eoid = mo_id,
       elid = mol_id,
       mytype = 4,
       order_add_time = jms.mo_add_time,
       order_date = jms.mo_date
              ,jms.mo_erp_id AS erp_id
FROM   pos_moStorage                 AS jms  WITH (NOLOCK) 
       INNER JOIN pos_moStorageList  AS jmsl  WITH (NOLOCK) 
            ON  jms.mo_id = jmsl.mol_mo_id
WHERE  jms.mo_status > 0
       AND jmsl.mol_status = 1 
       AND jmsl.mol_gi_id > 0
       AND jms.mo_out_st_id > 0
UNION ALL
SELECT 

--'' AS                            ord_no,

       jms.mo_in_st_id               AS SID,
       jms.mo_sh_id                  AS shid,
       cid = 0,
       jmsl.mol_gi_id                AS gid,
       jmsl.mol_sku_id               AS skuid,
       jmsl.mol_num                  AS gnum,
	    isnull(jmsl.mol_pm,'')        As pm ,
       countType = 1,
       myremark = '移入仓库',
       addtime = jmsl.mol_add_time,
       orderno = mo_vo,
       eoid = mo_id,
       elid = mol_id,
       mytype = 5,
       order_add_time = jms.mo_add_time,
       order_date = jms.mo_date
             ,jms.mo_erp_id AS erp_id
FROM   pos_moStorage                 AS jms  WITH (NOLOCK) 
       INNER JOIN pos_moStorageList  AS jmsl  WITH (NOLOCK) 
            ON  jms.mo_id = jmsl.mol_mo_id
WHERE  jms.mo_status > 0
       AND jmsl.mol_status = 1
       AND jmsl.mol_gi_id > 0
       AND jms.mo_in_st_id > 0
UNION ALL
SELECT 

--'' AS                            ord_no,


       jps.pl_st_id                  AS SID,
       jps.pl_sh_id                  AS shid,
       cid = 0,
       jpsl.ppl_gi_id                AS gid,
       jpsl.ppl_sku_id               AS skuid,
       ABS(jpsl.ppl_num)             AS gnum,
	   isnull(jpsl.ppl_pm,'')        As pm ,
       countType = (CASE WHEN jpsl.ppl_num >= 0 THEN 1 ELSE 0 END),
       myremark = '盈亏',
       addtime = jpsl.ppl_add_time,
       orderno = jps.pl_vo,
       eoid = jps.pl_id,
       elid = jpsl.ppl_id,
       mytype = 6,
       order_add_time = jps.pl_add_time,
       order_date = jps.pl_date
             ,jps.pl_erp_id AS erp_id
FROM   pos_plStorage                 AS jps  WITH (NOLOCK) 
       INNER JOIN pos_plStorageList  AS jpsl  WITH (NOLOCK) 
            ON  jps.pl_id = jpsl.ppl_pl_id
WHERE  jps.pl_status=2  
       AND jpsl.ppl_status = 1
       AND jpsl.ppl_gi_id > 0
       AND jps.pl_st_id > 0
UNION ALL
SELECT 
--jps.ord_sn,

       jps.al_st_id                  AS SID,
       jps.al_sh_id                  AS shid,
       cid = 0,
       jpsl.all_gi_id                AS gid,
       jpsl.all_sku_id               AS skuid,
       ABS(jpsl.all_num)             AS gnum,
	   isnull(jpsl.all_pm,'')        As pm ,
       countType = 0,
       myremark = '调拨',
       addtime = jpsl.all_add_time,
       orderno = jps.al_vo,
       eoid = jps.al_id,
       elid = jpsl.all_id,
       mytype = 6,
       order_add_time = jps.al_add_time,
       order_date = jps.al_date
          ,jps.al_erp_id AS erp_id
FROM   pos_alStorage                 AS jps  WITH (NOLOCK) 
       INNER JOIN pos_alStorageList  AS jpsl  WITH (NOLOCK) 
            ON  jps.al_id = jpsl.all_al_id
WHERE  jps.al_status > 0
       AND jpsl.all_status = 1
       AND jpsl.all_gi_id > 0
       AND jps.al_st_id > 0
UNION ALL
SELECT 

--(
--           SELECT TOP(1) nt.ord_no
--           FROM   dbo.pos_sale_net WITH (NOLOCK) 
--                  INNER JOIN dbo.netorder_tbl AS nt WITH (NOLOCK) 
--                       ON  dbo.pos_sale_net.sa_net_ord_id = nt.ord_id
--                       AND dbo.pos_sale_net.sa_net_sa_id = jps.sa_id
--       )                        AS ord_no,
       
       
       jps.sa_st_id             AS SID,
       jps.sa_sh_id             AS shid,
       cid = 0,
       jpsl.sal_gi_id           AS gid,
       jpsl.sal_sku_id          AS skuid,
      ABS(CASE WHEN batch.sal_id IS NULL THEN 
         jpsl.sal_num 
       ELSE 
         cast(isnull(batch.applyqty,0) as int) 
       END ) AS gnum ,
	   isnull(batch.batchno,'')                  as pm,
       countType = (CASE 
       WHEN jpsl.sal_is_return=1 OR jpsl.sal_is_change=1 THEN 
       1
       WHEN jpsl.sal_num >= 0 THEN 0 ELSE 1 
                    END
       ),
       myremark =CASE WHEN jpsl.sal_is_return=1 THEN '销售退货' when jpsl.sal_is_change=1 then '销售换货' else '销售出库' end,
       addtime = jpsl.sal_add_time,
       orderno = jps.sa_vo,
       eoid = jps.sa_id,
       elid = jpsl.sal_id,
       mytype = 6,
       order_add_time = jps.sa_add_time,
       order_date = jps.sa_date
       ,jps.sa_erp_id AS erp_id
FROM   pos_sale                 AS jps WITH (NOLOCK) 
       INNER JOIN pos_saleList  AS jpsl  WITH (NOLOCK) 
            ON  jps.sa_id = jpsl.sal_sa_id  
       left JOIN pos_batchdistribution AS batch
		   ON batch.sal_id=jpsl.sal_id
WHERE  jps.sa_status > 0
       AND jpsl.sal_status = 1
       AND jpsl.sal_gi_id > 0
       AND jps.sa_st_id > 0
UNION ALL
SELECT 

--'' AS                ord_no,


       js.sl_seiid       AS SID,
       js.sl_shid        AS shid,
       cid = 0,
       js.sl_giid        AS gid,
       js.sl_skuid       AS skuid,
       js.sl_number,
	   isnull(js.sl_pm,'') as pm,
       js.sl_counttype,
       js.sl_remark,
       js.sl_addtime,
       js.sl_order_no,
       js.sl_eoid,
       js.sl_elid,
       mytype = 7,
       order_add_time = js.sl_order_add_time,
       order_date = js.sl_order_date
        ,js.sl_erp_id AS erp_id
FROM   pos_stocklog_pal  AS js  WITH (NOLOCK) 
WHERE  js.sl_status = 2
       AND js.sl_giid > 0
       AND js.sl_seiid > 0
UNION ALL
SELECT 
--'' AS                ord_no,

       vt.sl_seiid,
       vt.sl_shid,
       cid = 0,
       vt.sl_giid,
       vt.sl_skuid,
       vt.sl_number,
	   isnull(vt.sl_pm,'') as pm,
       vt.sl_counttype,
       vt.sl_remark,
       vt.sl_addtime,
       vt.sl_order_no,
       vt.sl_eoid,
       vt.sl_elid,
       vt.sl_type,
       vt.sl_order_add_time,
       vt.sl_order_date
        ,vt.sl_erp_id AS erp_id
FROM   pos_stocklog_pal  AS vt  WITH (NOLOCK) 
WHERE  vt.sl_status = 1
       AND vt.sl_seiid > 0
       AND vt.sl_giid > 0
go

