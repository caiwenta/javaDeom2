
CREATE  PROC [dbo].[pro_enterStorage_op]

@eo_tax_point decimal(15, 2)=0,
@eo_tax_money decimal(15, 2)=0,

--订单id
@eo_id INT ,
@eo_erp_id INT ,
@el_erp_id INT ,
--客户id
@eo_ciid INT = 0,
--仓库id
@eo_siid INT = 0,
--经手人id
@eo_takemanid INT = 0,
--备注
@eo_remark NVARCHAR(200) = '',
--单据时间
@eo_entrydate DATETIME = '2014-7-22',
--审核人id
@eo_lastmanid INT = 0,

--是否为扫描
@is_saomiao INT = 0,

--添加人id
@eo_addman INT = 0,
--修改人id
@eo_updateman INT = 0,
--部门id
@eo_itid INT = 0,
--类型(0,入库:1:退货)
@eo_type INT = 0,
--状态(0,删除:1,可用:2,审核)
@eo_status INT = 0,
--总金额(实际总重)
@eo_totalmoney DECIMAL(18, 2) = 0,
--优惠金额
@eo_couponmoney DECIMAL(15, 2) = 0,
--实际金额
@eo_realmoney DECIMAL(15, 2) = 0,
--总数量
@eo_num INT = 0,
--手工单号
@eo_manual VARCHAR(50) = '',
--费用
@eo_cost DECIMAL(15, 2) = 0,
--运费
@eo_freight DECIMAL(15, 2) = 0,
--快递公司
@eo_express VARCHAR(100) = '',
--货运单号
@eo_expressno VARCHAR(100) = '',
--来源类型(1,采购)
@eo_source_type INT = 0,
--来源主键
@eo_source_id INT = 0,
--单据明细id
@el_id INT = 0,
--商品id
@el_siid INT = 0,
--数量
@el_number INT = 0,
--折扣
@el_discount DECIMAL(10, 2) = 0,
--实际金额
@el_realmoney DECIMAL(10, 2) = 0,
--备注
@el_remark NVARCHAR(500) = '',
--自动匹配采购单
@eo_ismatching INT=0,

--进货价
@el_unit DECIMAL(10, 2) = 0,
--零售价
@el_costprice DECIMAL(10, 2) = 0,
--添加时间
@el_addtime DATETIME = '2014-7-22',
--规格id
@el_skuid INT = 0,
@el_gift INT =0,
--来源明细主键
@el_source_id INT = 0,
--来源明细添加时间
@el_source_add_time DATETIME = '2014-11-20',
--公司主键
@eo_cp_id INT = 0,
--部门主键
@eo_di_id INT = 0,
--分公司主键
@eo_to_cp_id INT = 0,
--前台排出的商品(单击清空明细按钮时会记录商品主键,添加时间)
@not_in_ids VARCHAR(MAX) = '',
--保存字符串
@savestr VARCHAR(MAX)='',
--箱数
@el_box_num INT = 0,
--配码
@el_pm VARCHAR(500) = '',
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  

@negative_inventory INT=0,

@order_id  VARCHAR(MAX)='',
@good_id VARCHAR(MAX)='',
@goodscode VARCHAR(MAX) = '',
@pm VARCHAR(MAX) = '',
--结果  
@result VARCHAR(100) = '' OUT,

--供应商积分开关
@isupplierintegral int=0,

--生产日期
@pddate VARCHAR(80) = '',
--商品日期
@pdgddate  VARCHAR(80) = '',

--积分
@el_integral numeric(18,2)=0,
--总积分
@el_totalintegral numeric(18,2)=0,

--采购退货
@pl_pltype int=0,

@el_expirationdate VARCHAR(80) = null,
@el_shelflife int=0,
@orderguid VARCHAR(500)='', --唯一guid
@do_id int=0,
@IsPDA int=0,
@slt_id int=0,

--总部仓库
@hq_seiid int=0,

@warehousingtype int=0,

--售后调价
@aspd int=0,
@isModifyEndNum int=0 , --是否修改终止数量

@slt_no varchar(50)=''
AS
BEGIN


	--防止仓位为负数
      IF @slt_id<0
	  BEGIN
	   SET @slt_id=0;
	  END

	DECLARE @tdoc_xml VARCHAR(max)= '';
	DECLARE @el_update_time DATETIME;
	SET @el_update_time=GETDATE();
    DECLARE @finished_money DECIMAL(15, 2) = 0; --成品金额
    DECLARE @parts_money    DECIMAL(15, 2) = 0; --辅品金额
	--cc
	DECLARE @ma_pl_id INT=0;
	
	--终止标识
	DECLARE @op_type_end VARCHAR(100)='';
	IF @op_type='添加修改单据,明细,终止操作'
	BEGIN
		SET @op_type='添加修改单据,明细';
		SET @op_type_end='添加修改单据,明细,终止操作';
	END
	
	DECLARE @fo_id INT = 0;
	DECLARE @old_sei_id INT=0;
	DECLARE @new_sei_id INT=0;
	SET @new_sei_id=@eo_siid;
	
	DECLARE @sql NVARCHAR(MAX) = '';
	
	--是否添加单据
	DECLARE @isInsert INT = 0;
	--是否需要更新单据
	DECLARE @need_update INT = 0;
	--旧的单据日期
	DECLARE @old_order_date DATETIME;
	--单据日期是否更改
	DECLARE @old_order_date_is_changed INT = 0;
	--凭证号前缀
	DECLARE @myprevTxt VARCHAR(50) = 'RK';

	DECLARE @eo_io_id INT=0;
	IF @eo_type = 1
	BEGIN
	    SET @myprevTxt = 'RKTH';
	END
	
	

	BEGIN TRAN
	IF @op_type = '添加修改单据,明细'
	BEGIN
	    IF @eo_id = 0 AND @op_type_end=''
	    BEGIN
	        IF @eo_cp_id = 0
	        BEGIN
	            SELECT @eo_cp_id = fd.si_company,
	                   @eo_di_id = fd.si_did
	            FROM   b_stafftinfo fd
	            WHERE  fd.si_id = @eo_addman
	        END
	        

	        IF @eo_source_type =2
	     	BEGIN
			  select @eo_io_id=oo_io_id from j_outStorage 
			  where oo_id=@eo_source_id and oo_io_id>0
	        END   


	        --添加订单
	        INSERT INTO j_enterStorage
	          (
	            eo_ciid,
	            eo_siid,
	            eo_no,
	            eo_takemanid,
	            eo_remark,
	            eo_entrydate,
	            eo_lastmanid,
	            eo_itid,
	            eo_type,
	            eo_status,
	            eo_totalmoney,
	            eo_couponmoney,
	            eo_realmoney,
	            eo_num,
	            eo_addtime,
	            eo_manual,
	            eo_cost,
	            eo_freight,
	            eo_express,
	            eo_expressno,
	            eo_source_type,
	            eo_source_id,
	            eo_addman,	    
	            eo_cp_id,
	            eo_di_id,
	            eo_to_cp_id,
	            eo_ismatching,
	            eo_erp_id,
	            eo_tax_point,
				eo_tax_money,
				do_id,
				hq_seiid,
				eo_io_id
	          )
	        VALUES
	          (
	            @eo_ciid,
	            @eo_siid,
	            NEWID(),
	            @eo_takemanid,
	            @eo_remark,
	            @eo_entrydate,
	            @eo_lastmanid,
	            @eo_itid,
	            @eo_type,
	            1,
	            @eo_totalmoney,
	            @eo_couponmoney,
	            @eo_realmoney,
	            @eo_num,
	            GETDATE(),
	            @eo_manual,
	            @eo_cost,
	            @eo_freight,
	            @eo_express,
	            @eo_expressno,
	            @eo_source_type,
	            @eo_source_id,
	            @eo_addman,	          
	            @eo_cp_id,
	            @eo_di_id,
	            @eo_to_cp_id,
	            @eo_ismatching,
	            @eo_erp_id,
				@eo_tax_point,
				@eo_tax_money,
				@do_id,
				@hq_seiid,
				@eo_io_id
	          );
	        SET @eo_id = SCOPE_IDENTITY();
	        SET @isInsert = 1;
	    END
	    ELSE
	    BEGIN
	        SET @need_update = 1;
	    END
	    --END
	    --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
	    DECLARE @savestr_item VARCHAR(MAX)='';
	    --起始数值,每次循环后递增
	    DECLARE @start_int INT=1;
	    --终止数值
		DECLARE @end_int INT=1;
	    IF @savestr!='' 
	    BEGIN
	    	--得到明细数量
	    	--即要循环的次数
	    	SELECT @end_int=(LEN(@savestr)-LEN(REPLACE(@savestr,'|','')))
	    END
	    ELSE
	    BEGIN
	    	
	    	IF @eo_source_type>0 AND @eo_ismatching=0
	    	BEGIN
	    		--采购入库,采购退货
	    		--@savestr为空,整单执行,使其不符合条件
	    		SET @start_int=@end_int+1;
	    	END
	    END
	    
	    DECLARE @add_time_not_in VARCHAR(MAX)='';
	    SELECT @add_time_not_in=NEWID();
	    
	    SELECT 
	    fd.pll_pl_id AS pll_id,
	    fd.pll_pl_id,
	    fd.pll_gi_id,
	    fd.pll_sku_id,
	    fd.pll_num,
	    fd.pll_add_time,
	    fd.pll_retail_price,
	    fd.pll_discount,
	    fd.pll_stock_price,
	    fd.pll_box_num,
	    fd.pll_pm,
		fd.pll_pddate,
		fd.pll_pdgddate,
		fd.pll_integral,
		fd.pll_totalintegral,
		fd.pll_erp_id
		INTO #temp_pll
		FROM j_purchaseStorageList fd WHERE 1=2

		if @orderguid=''
		begin
			WHILE @start_int<=@end_int
			BEGIN
			
				IF @savestr!='' 
					BEGIN
	    				SET @savestr_item=dbo.Get_StrArrayStrOfIndex(@savestr,'|',@start_int);
	    			IF(RTRIM(LTRIM(@savestr_item))='')
						BEGIN
							BREAK;
						END
						ELSE
						BEGIN
							SET @savestr_item=REPLACE(@savestr_item,',,',',0,');	
							IF @eo_source_type=0 
							BEGIN
				
						--正常的入库,入库退货操作
						SET @el_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));

						SET @el_siid=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));
						SET @el_skuid=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3));
						SET @el_number=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));
						SET @el_unit=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5));
						SET @el_costprice=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',6));
						SET @el_discount=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',7));
						SET @el_box_num=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',8));
						SET @el_pm=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',9);
						if @el_pm='0' begin set @el_pm='' end

						set @pddate=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',10);
						SET @pdgddate=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',11);

						


					END
							ELSE IF @eo_source_type>0 
							BEGIN

							--采购入库,采购退货
							SET @el_id=0;
							SET @el_source_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));
							SET @el_number=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));
							SET @el_source_add_time=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3);
					
							IF(dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4)='')
					BEGIN
						
					   IF @eo_source_type = 1 AND @eo_ismatching=0
						BEGIN
							--采购入库
						    --没规格
						    SELECT @el_siid = jpsl.pll_gi_id,
						           @el_skuid = jpsl.pll_sku_id,
						           @el_unit = jpsl.pll_retail_price,
						           @el_discount = jpsl.pll_discount,
						           @el_costprice = jpsl.pll_stock_price
						    FROM   j_purchaseStorageList jpsl
						    WHERE  jpsl.pll_id = @el_source_id
						END
					   
					   	IF @eo_source_type=2
						BEGIN
							--入库审核
							SELECT @el_siid = jpsl.ol_siid,
						           @el_skuid = jpsl.ol_skuid,
						           @el_unit = jpsl.ol_unit,
						           @el_discount = jpsl.ol_discount,
						           @el_costprice = jpsl.ol_costprice
							FROM j_outStorageList  jpsl
						    WHERE  jpsl.ol_id = @el_source_id
						END

					   
					  
					END
					ELSE
					BEGIN
						
					SET @el_box_num=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));
					
					SET @el_pm=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5);
					if @el_pm='0' begin set @el_pm='' end

					SET @el_unit=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',6));
					SET @el_costprice=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',7));
					SET @el_discount=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',8));
					--商品主键
					SET @el_siid=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',9));
					--sku主键
					SET @el_skuid=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',10));
					set @pddate=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',11);
					SET @pdgddate=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',12);

					if ISNUMERIC(@pdgddate)=1
					begin
					 SET @pdgddate=NULL
					end
					if @pddate='0'
					begin
					 SET @pddate=NULL
					end


				
					END
					        
							--if @el_skuid=0
							--begin

						 --   select 
						 --    @el_source_id=pll_id
				   --          @pll_box_num=pll_box_num+@pll_box_num
				   --          FROM j_purchaseStorageList jpsl WHERE pll_pl_id=@pll_pl_id AND pll_gi_id= @el_siid  AND pll_sku_id= @el_skuid and pll_status=1 and isnull(jpsl.pll_pm,'')=isnull(@el_pm,'') ;
							--end

						
							INSERT INTO #temp_pll(pll_id,pll_pl_id,pll_gi_id,
							pll_sku_id,pll_num,pll_add_time,
							pll_retail_price,
							pll_discount,
							pll_stock_price,
							pll_box_num,
							pll_pm,
							pll_pddate,
							pll_pdgddate,
							pll_integral,
							pll_totalintegral
							)VALUES(@el_source_id,0,@el_siid,@el_skuid,@el_number,@el_source_add_time,@el_unit,@el_discount,@el_costprice,@el_box_num,@el_pm,@pddate,@pdgddate,0,0);
							
	
								SET @start_int=@start_int+1;
					
								CONTINUE;
							END
						END
				END
	    
	    
				IF @el_id = 0 AND @is_saomiao = 1
				BEGIN
					select @el_id=el_id,@el_number=el_number+@el_number FROM j_enterStorageList jpsl WHERE el_eoid=@eo_id AND el_siid= @el_siid  AND el_skuid= @el_skuid
				IF @el_id IS NULL
	    			SET @el_id = 0
				END
	    
			    --@pdgddate会为0时处理
				IF @pddate='' BEGIN set @pddate=NULL SET @pdgddate=NULL END
				if ISNUMERIC(@pdgddate)=1 begin SET @pdgddate=NULL end
				if @pddate='0' begin SET @pddate=NULL end

				DECLARE @cha_el_number INT=0;
				IF @el_id = 0
				BEGIN
	    			IF @op_type_end=''
	    			BEGIN
	    		
	    					
					INSERT INTO j_enterStorageList
	          (
	            el_eoid,
	            el_siid,
	            el_number,
	            el_discount,
	            el_realmoney,
	            el_remark,
	            el_unit,
	            el_costprice,
	            el_addtime,
	            el_skuid,
	            el_status,
	            el_source_id,
	            el_source_add_time,
	            el_box_num,
	            el_gift,
	            el_pm,
				el_pddate,
				el_pdgddate,
				el_expirationdate,
				el_shelflife,
				el_integral,
				el_totalintegral,
				el_erp_id
	          )
	        VALUES
	          (
	            @eo_id,
	            @el_siid,
	            @el_number,
	            @el_discount,
	            @el_costprice * @el_number,
	            @el_remark,
	            @el_unit,
	            @el_costprice,
	            @el_addtime,
	            @el_skuid,
	            1,
	            @el_source_id,
	            @el_source_add_time,
	            @el_box_num,
	            @el_gift,
	            @el_pm,
				@pddate,
				@pdgddate,
				@el_expirationdate,
				@el_shelflife,
				@el_integral,
				@el_totalintegral,@el_erp_id
	          );
								SET @el_id = SCOPE_IDENTITY();
	    					
	    			  END
	    			ELSE
	    			BEGIN

	    				INSERT INTO j_add_time_record ( a_add_time, a_guid ) 
						VALUES ( @el_source_add_time, @add_time_not_in );

						UPDATE j_purchaseStorageList 
						SET pll_pause_num =ISNULL(pll_pause_num,0)+ @el_number,
						    pll_pause_box_num=isnull(pll_pause_box_num,0)+@el_box_num 
						WHERE pll_id=@el_source_id;
	    		       

	    	       END
		    END
				ELSE
				BEGIN

	    		
	    	        
					--售后调价
					IF @aspd=1
					BEGIN
							UPDATE j_enterStorageList
							SET el_olddiscount=el_discount,
								el_oldcostprice=el_costprice,
								el_aspd=@eo_updateman
							WHERE el_id = @el_id;
					END

					--明细更新
					UPDATE j_enterStorageList
					SET     el_siid = @el_siid,
							el_number = @el_number,
							el_discount = @el_discount,
							el_realmoney = @el_costprice * @el_number,
							el_remark = @el_remark,
							el_unit = @el_unit,
							el_costprice = @el_costprice,
							el_skuid = @el_skuid,
							el_box_num = @el_box_num,
							el_pm = @el_pm,
							el_gift = @el_gift,
							el_pddate=@pddate,
							el_expirationdate= @el_expirationdate,
							el_shelflife=@el_shelflife,
							el_integral=@el_integral,
							el_totalintegral=@el_totalintegral
					 WHERE	el_id = @el_id;


				END
	    

	    
				SET @start_int=@start_int+1;

			END
		END
		ELSE
		BEGIN

            --匹配采购单
            if @eo_ismatching=1 and @eo_source_type=1
			 begin

					DECLARE @pid AS dbo.UDTypeOrderId;
					declare @next int 
					set @next=1
					while @next<=dbo.Get_StrArrayLength(@order_id,',')
					begin
						insert @pid(id)VALUES(dbo.Get_StrArrayStrOfIndex(@order_id,',',@next))
						set @next=@next+1
					end

					INSERT INTO j_enterStorageList
					(
						 el_eoid , 
						 el_siid , 
						 el_skuid ,
						 el_pm ,
						 el_gift,
						 el_erp_id ,
						 el_number,
						 el_discount , 
						 el_unit ,
						 el_costprice,
						 el_realmoney,
						 el_status ,
						 el_box_num,
						 el_addtime,
						 el_source_add_time,
						 el_source_id
					)
					SELECT
						@eo_id,
						so.pll_gi_id,
						so.pll_sku_id,
						'',
						0,
						@eo_erp_id,
						so.qty,
					   (select discount from erp_goodslisttemp where orderguid = @orderguid and gi_id=so.pll_gi_id and sku_id=so.pll_sku_id) as discount,--so.pll_discount
					   (select retailprice from erp_goodslisttemp where orderguid = @orderguid and gi_id=so.pll_gi_id and sku_id=so.pll_sku_id) as retail_price,--so.pll_retail_price
					   (select purchase from erp_goodslisttemp where orderguid = @orderguid and gi_id=so.pll_gi_id and sku_id=so.pll_sku_id) as stock_price,	--so.pll_stock_price,
					   (select purchase from erp_goodslisttemp where orderguid = @orderguid and gi_id=so.pll_gi_id and sku_id=so.pll_sku_id)*so.qty ,
						1,
						0,
						GETDATE(),
						pll_add_time,
						pll_id
					FROM dbo.FnPurchaseBYFIFO(@pid,@orderguid,@eo_erp_id) as so;

					EXEC pro_update_unique_time_source @id = @eo_id, @type = '入库'

			 end
			 else
			 begin

				MERGE INTO j_enterStorageList AS ta
					USING
					(
				  		SELECT  @eo_id as el_eoid, gi_id, sku_id,pm,gift,erp_id,
                        number,
						discount,--折扣
						retailprice,--零售价
                        purchase,--进货价
						orderstatus,
						box_num
						FROM  erp_goodslisttemp WHERE orderguid = @orderguid 
					  ) as so on ta.el_siid=so.gi_id AND  ta.el_skuid=so.sku_id and  ta.el_eoid=so.el_eoid and ta.el_status=1
					  WHEN MATCHED THEN  UPDATE
                           SET  
						   ta.el_number += so.number,
						   ta.el_realmoney=((ta.el_number+so.number)*so.purchase)
					  WHEN NOT MATCHED THEN
							INSERT 
							(el_eoid , el_siid , el_skuid ,el_pm ,el_gift,el_erp_id ,
							el_number , 
							el_discount , --折扣
							el_unit , --零售价
							el_costprice, --进货价
							el_realmoney,--进货价金额
							el_status ,
							el_box_num,
							el_addtime
							)
							VALUES
							( 
							 so.el_eoid, so.gi_id, so.sku_id,so.pm,so.gift,so.erp_id,
							 so.number,
							 so.discount,--折扣
							 so.retailprice,--销售价
							 so.purchase,--进货价
							 so.number* so.purchase,--进货价金额
							 so.orderstatus,
							 so.box_num,
							 (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
							 SELECT GETDATE() as nows,
                             (SELECT TOP 1 el_addtime FROM j_enterStorageList WHERE el_siid=so.gi_id AND el_eoid=so.el_eoid) AS addtime) AS TT)
					);

			 end

		END
		

		if @eo_ismatching=0
		begin

			IF @isInsert=1 
			BEGIN
	    	EXEC pro_update_unique_time
				@id = @eo_id,
				@type = '入库'
			END
		
			IF ((@eo_source_type>0  AND @isInsert=1 ) OR @op_type_end!='') And @IsPDA=0
			BEGIN   
		      	UPDATE #temp_pll SET pll_pl_id=fd2.pll_pl_id
				FROM #temp_pll fd,j_purchaseStorageList fd2
				WHERE fd.pll_id=fd2.pll_id

				DECLARE @exfields VARCHAR(100)=',fd.pll_pddate,fd.pll_pdgddate';

		        --采购入库 @op_type_end=''禁用数量
				IF @eo_source_type=1 
				BEGIN
					
					--select * into pslist_temp from #temp_pll

					DECLARE @gids TABLE(gi_id int);
					DECLARE @orids TABLE(order_id int);
					DECLARE @pms TABLE(order_id int);
					declare @tt int;
					if @good_id <>''
					begin
					  set @tt=1;
					  while @tt<=dbo.Get_StrArrayLength(@good_id,',')
						begin
					    insert @gids(gi_id)VALUES(dbo.Get_StrArrayStrOfIndex(@good_id,',',@tt));
						set @tt=@tt+1;
					  end
					end
					if @order_id <>''
					begin
					  set @tt=1;
					  while @tt<=dbo.Get_StrArrayLength(@order_id,',')
						begin
							insert @orids(order_id)VALUES(dbo.Get_StrArrayStrOfIndex(@order_id,',',@tt));
							set @tt=@tt+1;
					   end
					end

					if @pm<>''
					begin
					 set @tt=1;
					  while @tt<=dbo.Get_StrArrayLength(@pm,',')
						begin
							insert @pms(order_id)VALUES(dbo.Get_StrArrayStrOfIndex(@pm,',',@tt));
							set @tt=@tt+1;
					   end
					end
					else
					begin
						insert @pms(order_id)VALUES('');
					end

					
					SELECT 
					    @eo_id as eo_id,
						fd.pll_gi_id,
						fd.pll_sku_id,
						(CASE WHEN tp.pll_gi_id IS NULL THEN
						(fd.pll_num-abs(isnull((SELECT sum(el_number) FROM j_enterStorageList jesl WITH(NOLOCK) INNER JOIN j_enterStorage AS jes WITH(NOLOCK) ON jes.eo_id = jesl.el_eoid WHERE jes.eo_status > 0 and jes.eo_source_type=1 and jesl.el_source_id=fd.pll_id AND jesl.el_status<>0 ),0))-ISNULL(pll_pause_num,0)) 
						 else
						tp.pll_num end )AS pll_num,
						fd.pll_discount,
						fd.pll_retail_price,
						fd.pll_stock_price,
						fd.pll_status,
						fd.pll_id,
						fd.pll_add_time,
						(CASE WHEN tp.pll_gi_id IS NULL THEN
						(isnull(fd.pll_box_num,0)-abs(isnull((SELECT sum(jesl.el_box_num) FROM j_enterStorageList jesl WITH(NOLOCK) INNER JOIN j_enterStorage AS jes WITH(NOLOCK) ON jes.eo_id = jesl.el_eoid WHERE jes.eo_status > 0 and jes.eo_source_type=1 and jesl.el_source_id=fd.pll_id AND jesl.el_status<>0 ),0))-ISNULL(pll_pause_box_num,0))
						 else 
						tp.pll_box_num end ) AS pll_box_num,
						fd.pll_pm,
						fd.pll_boxbynum,
						fd.pll_erp_id
						into #pslist
					FROM j_purchaseStorageList fd WITH(NOLOCK)  
					inner join @orids odi on fd.pll_pl_id=odi.order_id
					inner join (SELECT DISTINCT gi_id FROM @gids) gis on gis.gi_id=fd.pll_gi_id
					inner join (SELECT DISTINCT order_id FROM @pms) pp on isnull(fd.pll_pm,'')=isnull(pp.order_id,'')
					left join #temp_pll tp on fd.pll_id=tp.pll_id
					where fd.pll_status>0
					

				     IF @op_type_end!=''
					 begin

						IF @isModifyEndNum=1 --修改终止数量
						BEGIN

							UPDATE j_purchaseStorageList
							SET pll_pause_num = ISNULL(fd2.pll_num,0),
							    pll_pause_box_num=isnull(fd2.pll_box_num,0)
							FROM j_purchaseStorageList fd,#pslist fd2
							WHERE fd.pll_id=fd2.pll_id AND fd2.pll_add_time NOT IN (
								SELECT fd3.a_add_time FROM j_add_time_record fd3 WHERE fd3.a_guid=@add_time_not_in	
							);

						END
						ELSE
						BEGIN

							UPDATE j_purchaseStorageList
							SET pll_pause_num = ISNULL(pll_pause_num,0)+ISNULL(fd2.pll_num,0),
							    pll_pause_box_num=isnull(pll_pause_box_num,0)+fd2.pll_box_num
							FROM j_purchaseStorageList fd,#pslist fd2
								WHERE fd.pll_id=fd2.pll_id AND fd2.pll_add_time NOT IN (
								SELECT fd3.a_add_time FROM j_add_time_record fd3 WHERE fd3.a_guid=@add_time_not_in	
							);

					   END

					   declare @orderids UDTypeOrderId;
						insert into @orderids(Id) select order_id from @orids;
						exec pro_mergeSums @orderids=@orderids, @stockType=9;--订货采购

					end
					else
					begin
					   INSERT INTO j_enterStorageList
						(
						el_eoid,
						el_siid,
						el_skuid,
						el_number,
						el_discount,
						el_unit,
						el_costprice,
						el_status,
						el_source_id,
						el_source_add_time,
						el_box_num,
						el_pm,
						el_boxbynum,
						el_erp_id
						)
						select * from #pslist
					end

					drop table #pslist
					drop table #temp_pll

				END
				



				--入库审核
				IF @eo_source_type=2 and @op_type_end=''
				BEGIN
				
				--入库审核
				--插入剩余的全部数据
				SET @sql=REPLACE(REPLACE(REPLACE('SELECT * INTO ##p FROM (SELECT fd.ol_siid,fd.ol_skuid,(fd.ol_number-ISNULL(el_number,0)) AS  ol_number,fd.ol_discount,fd.ol_unit,fd.ol_costprice,fd.ol_status,fd.ol_id,fd.ol_addtime,fd.ol_box_num,fd.ol_pm,ol_erp_id

FROM j_outStorageList fd
LEFT JOIN (

SELECT el_source_id,
       SUM(el_number)  AS el_number
FROM   (
                 select 
                  josl.el_source_id,
                  josl.el_siid,
                  josl.el_number,
                  josl.el_source_add_time
           FROM   j_enterStorage  AS jos
                  INNER JOIN j_enterStorageList AS josl
                       ON  jos.eo_id = josl.el_eoid
           WHERE  jos.eo_source_type = 2
                  AND jos.eo_source_id = @eo_source_id
                  AND josl.el_status = 1
                  AND jos.eo_status > 0
       )                  fd
GROUP BY
       el_source_id 
) AS ed ON ed.el_source_id=fd.ol_id
WHERE fd.ol_eoid= @eo_source_id
AND fd.ol_status=1
AND (fd.ol_number -ISNULL(el_number, 0)) > 0) AS fd',
       '@eo_source_id',CONVERT(VARCHAR(50),@eo_source_id)),
       '{0}',
       
     CASE WHEN   dbo.Get_StrArrayStrOfIndex(@not_in_ids, '|', 2)='' THEN ''''''
     ELSE dbo.Get_StrArrayStrOfIndex(@not_in_ids, '|', 2) END),
       '@eo_id',CONVERT(VARCHAR(50),@eo_id));
				exec sp_executesql @sql

				INSERT INTO j_enterStorageList
					(
					el_eoid,
					el_siid,
					el_skuid,
					el_number,
					el_discount,
					el_unit,
					el_costprice,
					el_status,
					el_source_id,
					el_source_add_time,
					el_box_num,
					el_pm,
					el_erp_id
					)
				SELECT @eo_id AS el_eoid,* FROM ##p

				DROP TABLE ##p

				END

				IF @op_type_end=''
				BEGIN

					UPDATE j_enterStorageList
						SET el_realmoney = el_costprice*el_number
						WHERE el_eoid=@eo_id;
	    			EXEC pro_update_unique_time_source @type = '入库', @id = @eo_id;

				END


		END

			-------------PDA生成入库单------------ and @do_id>0
			if @IsPDA=1 
		BEGIN
		    --pda入库
		    IF @eo_source_type=1
			begin

			  INSERT INTO j_enterStorageList
				(
					el_eoid,
					el_siid,
					el_skuid,
					el_number,
					el_discount,
					el_unit,
					el_costprice,
					el_realmoney,
					el_status,
					el_source_id,
					el_source_add_time,
					el_erp_id,
					el_locationid,
					dol_id,
					el_box_num,
					el_pm,
					el_addtime
				)
				SELECT
						@eo_id,
						ed.dol_gi_id,
						ed.dol_sku_id,
						pk.dp_inspectionnum,
						jps.pll_discount,
						jps.pll_retail_price,
						jps.pll_stock_price,
						jps.pll_stock_price*pk.dp_inspectionnum,
						1,
						jps.pll_id,
						jps.pll_add_time,
						@eo_erp_id,
						pk.slt_id,  --仓位
						ed.dol_id,
						0,
						'',
						GETDATE()
				FROM erp_distributionorderlist as ed
						INNER JOIN erp_distributionpicking pk ON pk.dol_id=ed.dol_id
						INNER JOIN j_purchaseStoragelist jps ON ed.dol_gi_id=jps.pll_gi_id AND ed.dol_sku_id=jps.pll_sku_id AND jps.pll_pl_id=@eo_source_id
				WHERE 
				do_id IN (SELECT do_id FROM erp_distributionorder where do_source_id=@eo_source_id and warehousingtype=@warehousingtype and erp_id=@eo_erp_id) 
				AND ed.erp_id=@eo_erp_id

			   if(@eo_type=1)
	           begin
			
			
				 exec pro_MergeDistributionorderManyOccupySum 1,@eo_source_id,@warehousingtype,@eo_erp_id

			   end
			END

		END
			-------------PDA生成入库单------------
		end

	
	    IF @eo_source_type=1
			BEGIN
		
		         --插入没有在采购单的商品
				INSERT INTO j_purchaseStorageList(
					pll_pl_id,
					pll_gi_id,
					pll_sku_id,
					pll_num,
					pll_retail_price,
					pll_discount,
					pll_stock_price,
					pll_money,
					pll_status,
					pll_add_time,
					pll_box_num,
					pll_pm,
					pll_source_id,
					pll_erp_id
				)
				SELECT
					fd.pl_id,
					jt.el_siid,
					jt.el_skuid,
					0 AS num,
					el_unit,
					el_discount,
					el_costprice,
					el_realmoney,
					el_status,
					(SELECT TOP 1 pll_add_time FROM j_purchaseStorageList WHERE pll_gi_id=jt.el_siid AND pll_pl_id=fd.pl_id) AS addtime,
					el_box_num,
					el_pm,
					0,
					@el_erp_id
				FROM j_enterStoragelist AS jt
				LEFT JOIN j_purchaseStorage AS fd ON fd.pl_id =(SELECT MAX (fd.pll_pl_id) FROM j_purchaseStorageList fd WITH (NOLOCK) WHERE fd.pll_add_time = jt.el_source_add_time)
				WHERE jt.el_eoid=@eo_id AND jt.el_number>0 AND el_status=1 AND jt.el_source_id=0

				UPDATE j_enterStoragelist
				SET 
				el_source_id = fd.pll_id
				FROM j_enterStoragelist jt 
				INNER JOIN j_purchaseStorageList fd on jt.el_source_add_time=fd.pll_add_time AND jt.el_siid=fd.pll_gi_id AND jt.el_skuid= fd.pll_sku_id
				WHERE jt.el_eoid=@eo_id AND jt.el_number>0 AND jt.el_source_id=0 AND el_status=1
		
			end

		IF @eo_source_type>0 and @op_type_end=''
		begin
			set @op_type = '审核单据'
	    end


		--库位
        if @slt_no<>''
		begin

		   if EXISTS(SELECT * FROM erp_storagelocation AS bs WHERE bs.sei_id=@eo_siid AND bs.slt_no=@slt_no)
		   begin

		     UPDATE j_enterStorageList 
			 set el_locationid=(SELECT slt_id FROM erp_storagelocation AS bs WHERE bs.sei_id=@eo_siid AND bs.slt_no=@slt_no)
			 where el_eoid=@eo_id and el_status=1;
		    
		   end	
		    else
			begin
				RAISERROR ( '库位不存在!', 16, 1, N'number', 5 );
				GOTO theRollback;
			end
		end

		exec dbo.pro_setPmNumberSum @orderid=@eo_id,@erp_id=@eo_erp_id ,@stockType=1;
	

	  
	END
	

    DECLARE @si_company int=0;
	DECLARE @nowal DATETIME = GETDATE();
	IF @op_type = '退货审核'
	BEGIN
	    --审核单据
	    UPDATE j_enterStorage
	    SET    eo_is_return_audit = 1,
	           eo_lastmanid = @eo_lastmanid,
	           eo_auditdate = GETDATE()
	    WHERE  eo_id = @eo_id;



		select 
		@eo_ciid=eo_ciid, 
		@eo_erp_id=eo_erp_id,
		@eo_cp_id=eo_cp_id,
		@si_company=(SELECT bs.si_company FROM b_supplierinfo bs WHERE bs.si_id=eo_ciid),
		@eo_remark=eo_remark
		from j_enterStorage where eo_id = @eo_id;

		if @si_company>0
		begin
		--declare @orderguid VARCHAR(500)='';
		--生成商品明细临时表
		exec pro_goodsstock_op @eo_id,'enter',@eo_erp_id,@orderguid Out,@slt_id
		IF @@error <> 0
	    BEGIN
			GOTO theRollback;
	    END
		if @orderguid<>''
		begin
				EXEC pro_outStorage_op
		         @op_type = '添加修改单据,明细',
				 @oo_erp_id=@eo_erp_id,
				 @oo_cp_id=@si_company,
				 @oo_remark=@eo_remark,
				 @oo_jytype=1,
		         @oo_source_type =2 ,--来源(1:配货,2:分公司入库退货，3:pos入库退货)
			     @oo_source_id = @eo_id,  --来源主键
				 @oo_type=0,--类型(0,出库退货:1,出库)
				 @oo_ciid=0,--客户id               
				 @oo_sh_id= 0,   --店铺主键         
				 @oo_to_cp_id=@eo_cp_id,--公司主键
				 @oo_siid=@eo_siid,--仓库id
				 @oo_entrydate=@eo_entrydate,
				 @oo_gift=0,
				 @oo_addman=@eo_lastmanid,
				 @orderguid=@orderguid
				IF @@ERROR <> 0
					BEGIN
					GOTO theRollback;
					END
		END

	END

	END

	IF @op_type = '取消退货审核'
	BEGIN
	    --审核单据
	    UPDATE j_enterStorage
	    SET    eo_is_return_audit = 0,
	           eo_lastmanid = 0,
	           eo_auditdate = null
	    WHERE  eo_id = @eo_id;

		select 
		@eo_ciid=eo_ciid, 
		@eo_erp_id=eo_erp_id,
		@eo_cp_id=eo_cp_id,
		@si_company=(SELECT bs.si_company FROM b_supplierinfo bs WHERE bs.si_id=eo_ciid)
		from j_enterStorage where eo_id = @eo_id;


		   --获取出库信息
		DECLARE @oo_id int=0;
		SELECT  @oo_id = fd.oo_id 
                FROM    j_outStorage fd WITH ( NOLOCK )
                WHERE   fd.oo_source_id=@eo_id and fd.oo_source_type=2 and oo_to_cp_id=@eo_cp_id and fd.oo_status>0

		if @si_company>0 and @oo_id>0
		begin

		EXEC pro_outStorage_op
		         @op_type = '取消审核单据',
				 @oo_erp_id=@eo_erp_id,
				 @oo_cp_id=@si_company,
				 @oo_source_type =2, --来源(1:配货,2:分公司入库退货，3:pos入库退货)
				 @oo_id=@oo_id
				 IF @@ERROR <> 0
					BEGIN
					GOTO theRollback;
					END
		EXEC pro_outStorage_op
		         @op_type = '删除单据',
				 @oo_erp_id=@eo_erp_id,
				 @oo_cp_id=@si_company,
				 @oo_source_type =2, --来源(1:配货,2:分公司入库退货，3:pos入库退货)
				 @oo_id=@oo_id
				 IF @@ERROR <> 0
					BEGIN
					GOTO theRollback;
					END
		end
	END
	
	IF @op_type = '删除单据'
	BEGIN

		
		SELECT distinct jesl.el_siid
		INTO #pp_date
		  FROM j_enterStorageList jesl 
		WHERE jesl.el_eoid=@eo_id 
		AND jesl.el_status>0
		AND jesl.el_pddate IS NOT NULL
		
		SELECT 
		bs.si_giid,
		MAX(bs.si_pddate_update_time) AS si_pddate_update_time 
		INTO #pp_date1
		FROM b_stockinfo bs WHERE bs.si_giid IN(
			SELECT * FROM #pp_date fd WITH (NOLOCK)   
		) AND bs.si_cp_id=@eo_cp_id
		GROUP BY si_giid
		
		SELECT fd.l_gi_id,MAX(fd.l_add_time) 
		AS l_add_time
		INTO #pp_date2
		 FROM b_stockinfo_ppdate_change_log fd
		 INNER JOIN #pp_date1 fd2 ON fd.l_gi_id=fd2.si_giid AND fd.l_add_time<fd2.si_pddate_update_time
		 WHERE fd.l_type=1 AND l_cp_id=@eo_cp_id
		GROUP BY fd.l_gi_id
		
		UPDATE b_stockinfo SET si_pddate = fd2.l_gen_date,si_pddate_update_time = fd2.l_add_time
		FROM b_stockinfo fd,(
		SELECT fd.l_gi_id,fd.l_gen_date,fd.l_add_time
		 FROM b_stockinfo_ppdate_change_log fd
		INNER JOIN #pp_date2 fd2 ON fd.l_gi_id=fd2.l_gi_id AND fd.l_add_time=fd2.l_add_time
		WHERE fd.l_type=1 AND l_cp_id=@eo_cp_id
		) AS fd2 WHERE fd.si_giid=fd2.l_gi_id
		AND fd.si_cp_id=@eo_cp_id
		
		SELECT @old_sei_id=fd.eo_siid
	    FROM j_enterStorage fd WHERE fd.eo_id=@eo_id;
	    
	    --删除单据
	    UPDATE j_enterStorage
	    SET    eo_status = 0
	    WHERE  eo_id = @eo_id;
	  
	    if @eo_erp_id=0
		begin
		select @eo_erp_id=eo_erp_id from j_enterStorage where eo_id = @eo_id
		end

	    

	END
	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE j_enterStorageList
	    SET    el_status = 0
	    WHERE  el_id = @eo_id;

	
	END
	
	IF @op_type = '批量删除明细'
	BEGIN
		
		SELECT @old_sei_id=fd.eo_siid
	    FROM j_enterStorage fd WHERE fd.eo_id=@eo_id;
	    
	    EXEC pro_recovery_ppdate
	    	@gi_id = @el_siid,
	    	@order_id = @eo_id,
	    	@type = 'erp'
	    IF @@ERROR <> 0
							BEGIN
							 GOTO theRollback;
							 END
	    UPDATE j_enterStorageList
	    SET    el_status = 0
	    WHERE  el_eoid = @eo_id
	           AND el_addtime = @el_addtime
	           AND el_siid = @el_siid;
	   
	   
	   
		
		
	    --判断是否为最后一条明细
	    IF (
	           (
	               SELECT COUNT(1) AS COUNT
	               FROM   j_enterStorageList AS je
	               WHERE  je.el_eoid = @eo_id
	                      AND je.el_status = 1
	           ) = 0
	       )
	    BEGIN
	        UPDATE j_enterStorage
	        SET    eo_status = 0
	        WHERE  eo_id = @eo_id;
	        --款项删除
	        UPDATE c_fundorder
	        SET    fo_status      = 0
	        WHERE  fo_orderid     = (
	                   SELECT je.eo_no
	                   FROM   j_enterStorage je
	                   WHERE  je.eo_id = @eo_id
	               )
	               AND fo_cp_id = @eo_cp_id
	    END
	END

	IF(@op_type = '添加修改单据,明细' and @eo_source_type = 1 and @eo_tax_point>0)
	BEGIN

		UPDATE j_enterStorage SET 
		eo_tax_money=@eo_tax_point* (SELECT SUM(el_realmoney) FROM vi_j_enterStorageList_sum WHERE el_eoid=@eo_id)
		WHERE eo_id	=@eo_id	

	END
	
	IF (@op_type = '添加修改单据,明细' OR @need_update = 1 OR @op_type = '修改单据' ) AND @isInsert!=1	AND @op_type_end=''
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.eo_entrydate
	    FROM   j_enterStorage AS jt
	    WHERE  jt.eo_id = @eo_id;
	    IF @old_order_date != @eo_entrydate
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	    SELECT @old_sei_id=fd.eo_siid
	    FROM j_enterStorage fd WHERE fd.eo_id=@eo_id;
	    
	    
	    
	    UPDATE j_enterStorage
	    SET    eo_ciid = @eo_ciid,
	           eo_siid = @eo_siid,
	           eo_takemanid = @eo_takemanid,
	           eo_remark = @eo_remark,
	           eo_entrydate = @eo_entrydate,
	           eo_lastmanid = @eo_lastmanid,
	           eo_itid = @eo_itid,
			   
	           eo_totalmoney = @eo_totalmoney,
	           eo_couponmoney = @eo_couponmoney,
	           eo_realmoney = @eo_realmoney,
	           eo_num = @eo_num,
	           eo_updatetime = GETDATE(),
	           eo_manual = @eo_manual,
	           eo_cost = @eo_cost,
	           eo_freight = @eo_freight,
	           
	           eo_tax_point = @eo_tax_point,
	           eo_tax_money = @eo_tax_money,
	           
	           eo_express = @eo_express,
	           eo_expressno = @eo_expressno,
	           eo_updateman = @eo_updateman,
	           eo_ismatching = @eo_ismatching,
	           hq_seiid=@hq_seiid
	    WHERE  eo_id = @eo_id;
	    
	    IF(SELECT fd.eo_status FROM j_enterStorage fd WHERE fd.eo_id=@eo_id)=0
	    BEGIN
	    	UPDATE j_enterStorage
	        SET    eo_status = 1
	        WHERE  eo_id = @eo_id;
	        --款项删除
	        UPDATE c_fundorder
	        SET    fo_status      = 1
	        WHERE  fo_orderid     = (
	                   SELECT je.eo_no
	                   FROM   j_enterStorage je
	                   WHERE  je.eo_id = @eo_id
	               )
	               AND fo_cp_id = @eo_cp_id
	    END
	END
	
	SET @old_order_date_is_changed=0;
	
	IF CHARINDEX('网络订单',@eo_remark)!=0
	BEGIN
		SET @old_order_date_is_changed=1;
	END

	IF (@isInsert = 1 OR @old_order_date_is_changed = 1 ) AND @op_type_end=''
	BEGIN
	    --旧的单据号
	    DECLARE @oldno VARCHAR(50) = '';
	    SELECT @oldno = je.eo_no
	    FROM   j_enterStorage je
	    WHERE  je.eo_id = @eo_id;
	    
	    --凭证号生成
	    --更新凭证号 
	    DECLARE @tableName VARCHAR(50) = 'j_enterStorage'
	    DECLARE @idField VARCHAR(50) = 'eo_id'
	    DECLARE @idValue INT = @eo_id;
	    
	    DECLARE @dateField VARCHAR(50) = 'eo_entrydate'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @eo_entrydate, 23)
	    
	    DECLARE @noField VARCHAR(50) = 'eo_no'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    
	    
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN
	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	        @idField,
	        @idValue,
	        @dateField,
	        @dateValue,
	        @noField,
	        @prevTxt,
	        @outno OUTPUT,0,@eo_cp_id
	        
	        BEGIN TRY
	        	--更新
	        	UPDATE j_enterStorage
	        	SET    eo_no = @outno
				,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)
	        	WHERE  eo_id = @eo_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
				PRINT '';
	        END CATCH
	    END
	    IF @isInsert != 1
	    BEGIN
	        --更新了凭证号
	        IF EXISTS( SELECT * FROM   c_fundorder cf WHERE  cf.fo_orderid = @oldno AND cf.fo_cp_id = @eo_cp_id )
	        BEGIN
	            --更新款项中的凭证号
	            UPDATE c_fundorder
	            SET    fo_orderid       = @outno
	            WHERE  fo_orderid       = @oldno
	                   AND fo_cp_id     = @eo_cp_id
	        END
	    END
	END
	
	--单据信息统计
	UPDATE j_enterStorage
	SET    --实际金额
	       eo_realmoney = vj.el_realmoney,
		   eo_totalboxnum=vj.el_boxnum,
	       --总数量
	       eo_num = vj.el_number
	FROM   j_enterStorage je,
	       vi_j_enterStorageList_sum vj
	WHERE  je.eo_id = vj.el_eoid
	       AND je.eo_id = @eo_id;
	
	
	--款项更新
   IF @op_type='审核单据'
	BEGIN
	    
		--审核单据
	    UPDATE j_enterStorage
	    SET    eo_status = 2,
	           eo_lastmanid = @eo_lastmanid,
	           eo_auditdate = GETDATE()
	    WHERE  eo_id = @eo_id;


	    DECLARE @mymoney DECIMAL(15, 2) = 0;
		--赠送金额
		DECLARE @giftedmoney DECIMAL(15,2) = 0;
	
		--赠送积分
	
		--单据号
		DECLARE @orderNo VARCHAR(50);

	

		SELECT @orderNo = je.eo_no,
		       @eo_ciid=eo_ciid,
			   @eo_entrydate=eo_entrydate,
			   @eo_freight=eo_freight,
			   @eo_cost=eo_cost,
			   @eo_cp_id=eo_cp_id,
			   @eo_di_id=eo_di_id,
			   @eo_erp_id=eo_erp_id,
			   @eo_type=eo_type,
			   @eo_remark=eo_remark
		FROM   j_enterStorage je
		WHERE  je.eo_id = @eo_id;
	
		--积分合计
		DECLARE @integral_sum DECIMAL(10,2)=0;
	
		DECLARE @fo_realmoney_integral DECIMAL(10,2) = 0;
		DECLARE @fo_outmoney_integral  DECIMAL(10,2) = 0;
	
		--成本价*数量
		SELECT @mymoney = SUM(je.el_costprice * je.el_number),
	       @integral_sum=SUM(je.el_totalintegral)
		FROM j_enterStorageList je
		WHERE je.el_eoid = @eo_id AND je.el_status =1 AND isnull(je.el_gift,0) = 0

		--成品金额
		SELECT  @finished_money = SUM(je.el_costprice * je.el_number)
		FROM    j_enterStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.el_siid = bg.gi_id
		WHERE   je.el_eoid = @eo_id
        AND je.el_status = 1
        AND ISNULL(je.el_gift, 0) = 0 and bg. gi_ownership=0

		--辅品金额
		SELECT  @parts_money = SUM(je.el_costprice * je.el_number)
		FROM    j_enterStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.el_siid = bg.gi_id
		WHERE   je.el_eoid = @eo_id
        AND je.el_status = 1
        AND ISNULL(je.el_gift, 0) = 0 and bg. gi_ownership=1


		DECLARE @fo_givemoney_integral DECIMAL(10,2);
	
		SELECT @giftedmoney = SUM(je.el_costprice * je.el_number), 
		   @fo_givemoney_integral=SUM(je.el_totalintegral) 
		FROM j_enterStorageList je
		WHERE je.el_eoid = @eo_id AND je.el_status =1 AND isnull(je.el_gift,0) !=0
	
		DECLARE @rkje DECIMAL(15, 2) = 0;
		DECLARE @rkthje DECIMAL(15, 2) = 0;
		DECLARE @myremark VARCHAR(50) = '';
		IF @eo_type = 0
		BEGIN
			SET @fo_realmoney_integral=@integral_sum;
			SET @rkje = @mymoney;
			SET @myremark = '入库应付';
		END
		ELSE
		BEGIN
			SET @fo_outmoney_integral=@integral_sum;
			SET @rkthje = @mymoney;
			SET @myremark = '入库退货应付';
		END

	    DECLARE @RC INT = 0;
	    
	    DECLARE @fo_type TINYINT = 1;--应付账款
	    DECLARE @fo_ciid INT = @eo_ciid;
	    DECLARE @fo_bs VARCHAR(20) = 'G';
	    DECLARE @fo_orderid VARCHAR(50) = @orderNo;
	    DECLARE @fo_takeman VARCHAR(50) = '';
	    DECLARE @fo_ticketno VARCHAR(50) = '';
	    DECLARE @fo_realmoney DECIMAL(15, 2) = @rkje;
	    DECLARE @fo_thiyetmoney DECIMAL(15, 2) = 0;
	    DECLARE @fo_ofdate DATETIME = @eo_entrydate;
	    DECLARE @fo_remark VARCHAR(200) = @myremark;
	    DECLARE @fo_lastman VARCHAR(50) = '';
	    DECLARE @fo_status TINYINT = 1;
	    DECLARE @fo_outmoney DECIMAL(15, 2) = @rkthje;
	    --垫付运费
	    DECLARE @fo_admoney DECIMAL(15, 2) = @eo_freight;
	    --其他应收
	    DECLARE @fo_otheronmoney DECIMAL(15, 2) = @eo_cost;
	    --其他应付
	    DECLARE @fo_otheoutmoney DECIMAL(15, 2) = 0;
	    
	    SET @fo_otheoutmoney=@eo_tax_money;
	    
	    DECLARE @fo_givemoney DECIMAL(15, 2) = @giftedmoney;
	    DECLARE @fo_ensuremoney DECIMAL(15, 2) = 0;
	    DECLARE @fo_subscription DECIMAL(15, 2) = 0;
	    DECLARE @fo_no VARCHAR(50) = '';
	    DECLARE @fo_userorderno VARCHAR(50) = '';
	    DECLARE @outResult INT = 0;

		DECLARE @fo_finished_money DECIMAL(15, 2)= @finished_money;
		DECLARE @fo_parts_money DECIMAL(15, 2)= @parts_money;

	    EXECUTE @RC = [pro_c_fundorder_op] 
	    @fo_id=@fo_id,
	    @fo_type=@fo_type,
	    @fo_ciid=@fo_ciid,
	    @fo_bs=@fo_bs,
	    @fo_orderid=@fo_orderid,
	    @fo_takeman=@fo_takeman,
	    @fo_ticketno=@fo_ticketno,
	    @fo_realmoney=@fo_realmoney,
	    @fo_thiyetmoney=@fo_thiyetmoney,
	    @fo_ofdate=@fo_ofdate,
	    @fo_remark=@fo_remark,
	    @fo_lastman=@fo_lastman,
	    @fo_status=@fo_status,
	    @fo_outmoney=@fo_outmoney,
	    @fo_admoney=@fo_admoney,
	    @fo_otheronmoney=@fo_otheronmoney,
	    @fo_otheoutmoney=@fo_otheoutmoney,
	    @fo_givemoney=@fo_givemoney,
	    @fo_ensuremoney=@fo_ensuremoney,
	    @fo_subscription=@fo_subscription,
	    @fo_no=@fo_no,
	    @fo_userorderno=@fo_userorderno,
	    @outResult=@outResult OUTPUT,
	    @fo_cp_id=@eo_cp_id,
	    @fo_di_id=@eo_di_id,
	    
	    @fo_shid=0,
	    @fo_to_cpid=0,
	    
	    @fo_realmoney_integral=
	    @fo_realmoney_integral,--入库获得积分

	    @fo_thiyetmoney_integral =0,
	    
		@fo_outmoney_integral =
		@fo_outmoney_integral,--入库退货扣减积分
		
		@fo_otheronmoney_integral =0,
		@fo_otheoutmoney_integral =0,
		@fo_givemoney_integral =
		@fo_givemoney_integral,
		@fo_erp_id=@eo_erp_id,
	    @fo_order_id=@eo_id,
	    @fo_finished_money=@finished_money,
		@fo_parts_money=@parts_money,
		@fo_custom_remark=@eo_remark
	    IF @RC = 0
	    BEGIN
			RAISERROR ('款项更新失败!',16,1,N'number',5);
			GOTO theRollback;
	    END
	END

   IF @op_type = '取消审核单据'
	begin

		SELECT 
	    @fo_id=cf.fo_id,
		@eo_cp_id=cf.fo_cp_id
		FROM c_fundorder cf 
		WHERE cf.fo_order_id=@eo_id  and cf.fo_type=1

		 --取消审核单据
	    UPDATE j_enterStorage
	    SET    eo_status = 1
	    WHERE  eo_id = @eo_id;


	  IF @fo_id>0
	  BEGIN

		   DECLARE @erp_id int=0;
	       select @erp_id=cp_erp_id from companyinfo where cp_id=@eo_cp_id
		   if EXISTS(SELECT * FROM s_system_set AS sss WHERE sss.s_key='fundorderreconciliation' AND sss.s_erp_id=@erp_id AND sss.s_value=1)
	        begin

					update c_fundorder set fo_status=1 where fo_id=@fo_id
					--生成明细报表
					 --exec pro_merge_c_fundorder_reconciliation @fo_id=@fo_id


					 SET @tdoc_xml = '{ "fo_id":"' + CONVERT(VARCHAR(50), @fo_id) + '"}';
							EXEC pro_apiqueue_op 
									@tdoc_method = 'fundorderreconciliation', 
									@tdoc_xml = @tdoc_xml, 
									@tdoc_erp_id =@erp_id, 
									@tdoc_cp_id=@eo_cp_id,
									@tdoc_state = 0;	
		    end
			else
			begin
			    --检查帐款状态
				IF EXISTS(SELECT * FROM c_fundorder cf WHERE cf.fo_order_id=@eo_id and cf.fo_status=2 and cf.fo_type=1)
				begin
				  RAISERROR ('帐款已审核,禁止取消审核单据!',16,1,N'number',5);
				  GOTO theRollback;
				end

			end


	        --款项删除
	        UPDATE c_fundorder
	        SET    fo_status = 0
	        WHERE  fo_orderid =(SELECT je.eo_no FROM j_enterStorage je WHERE je.eo_id = @eo_id ) AND fo_cp_id = @eo_cp_id
	  
	        EXEC pro_merge_fundorder @fo_id=@fo_id;
	  END



	end

   IF @op_type = '添加修改单据,明细'
	BEGIN
		--更成本价
		
		SET @tdoc_xml = '{ "update":"' + CONVERT(varchar(100), @el_update_time, 121) + '","cp_id":"' + CONVERT(VARCHAR(50), @eo_cp_id) + '","sh_id":"0","orderid":"'+CONVERT(VARCHAR(50),  @eo_id)+'"  }';
		EXEC pro_apiqueue_op 
		@tdoc_method = 'updatecostprice', 
		@tdoc_xml = @tdoc_xml, 
		@tdoc_erp_id =@eo_erp_id, 
		@tdoc_cp_id=@eo_cp_id,
		@tdoc_state = 0;
	end


	--退货审核和取消退货审核 用于生成出库退货单，不用计算库存。
   if @aspd=0 and @op_type <> '退货审核' and  @op_type <> '取消退货审核'
	begin

	exec pro_mergebyErpStocklog @op_type=@op_type,@stockType=1,@orderid=@eo_id;

	IF @@error <> 0
	BEGIN
		GOTO theRollback;
	END
	exec pro_instructionstate @orderid=@eo_id ,@type=2;

	END



	

    exec dbo.pro_mergesingleSums @orderid=@eo_id ,@stockType=1;
	
	--售后调整
	if @aspd=1
	begin
		
		select 
			@eo_type=eo_type,
			@eo_cp_id= eo_cp_id,
			@eo_entrydate=eo_entrydate
		from j_enterStorage where eo_id=@eo_id


		--月报表
		IF EXISTS(SELECT TOP 1 m_month FROM j_month_report WHERE reporttype=0 AND company_id=@eo_cp_id AND  m_year=DATEPART(YEAR,@eo_entrydate) AND m_month=DATEPART(MONTH,@eo_entrydate))	
		BEGIN
			RAISERROR ( '您所要操作的数据已生成月报表,数据已被锁定,禁止操作!', 16, 1, N'number', 5 );
			GOTO theRollback;
		END


		--日报表
		IF EXISTS(SELECT TOP 1 m_day FROM j_month_report WHERE reporttype=1 AND company_id=@eo_cp_id AND  m_year=DATEPART(YEAR,@eo_entrydate) AND m_month=DATEPART(MONTH,@eo_entrydate) AND m_day=DATEPART(day,@eo_entrydate))
		BEGIN
			RAISERROR ( '您所要操作的数据已生成日报表,数据已被锁定,禁止操作!', 16, 1, N'number', 5 );
			GOTO theRollback;
		END


		SELECT @el_realmoney= SUM(jesl.el_realmoney) 
		FROM j_enterStorageList AS jesl WITH ( NOLOCK ) 
		where jesl.el_status=1 and jesl.el_eoid=@eo_id and jesl.el_gift=0;


		DECLARE @el_givemoney DECIMAL(10, 2)=0.00;
		SELECT @el_givemoney= SUM(jesl.el_realmoney) 
		FROM j_enterStorageList AS jesl  WITH ( NOLOCK ) 
		where jesl.el_status=1 and jesl.el_eoid=@eo_id and jesl.el_gift=1;

			--成品金额
		SELECT  @finished_money = SUM(je.el_costprice * je.el_number)
		FROM    j_enterStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.el_siid = bg.gi_id
		WHERE   je.el_eoid = @eo_id
        AND je.el_status = 1
        AND ISNULL(je.el_gift, 0) = 0 and bg. gi_ownership=0

		--辅品金额
		SELECT  @parts_money = SUM(je.el_costprice * je.el_number)
		FROM    j_enterStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.el_siid = bg.gi_id
		WHERE   je.el_eoid = @eo_id
        AND je.el_status = 1
        AND ISNULL(je.el_gift, 0) = 0 and bg. gi_ownership=1

		if @eo_type=0
		begin
			update c_fundorder SET fo_realmoney =@el_realmoney, fo_givemoney =@el_givemoney ,
			    fo_finished_money=@finished_money,
				 fo_parts_money=@parts_money
			WHERE fo_order_id=@eo_id AND fo_type=1;
		end
		else
		begin
			update c_fundorder SET fo_outmoney =@el_realmoney,
			fo_finished_money=@finished_money,
				 fo_parts_money=@parts_money
			 WHERE fo_order_id=@eo_id AND fo_type=1 ;
		end

		SELECT 
			@fo_id=cf.fo_id
		FROM c_fundorder cf 
		WHERE cf.fo_order_id=@eo_id and cf.fo_type=1;


		EXEC pro_merge_fundorder @fo_id=@fo_id;
	end


	IF @@ERROR <> 0
	BEGIN
		theRollback:
	    SET @result = '0';
		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	    RETURN 1;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @eo_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细'  AND @op_type_end='' and @orderguid=''
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @el_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END

END
go

