CREATE PROC [dbo].[pro_merge_c_fundorder]
       @fo_bs VARCHAR(50) = '' ,
       @fo_ciid INT = 0 ,
       @fo_shid INT = 0 ,
       @fo_to_cpid INT = 0 ,
       @fo_id INT = 0 ,
       @operate_type VARCHAR(50) = ''
AS
       BEGIN
	       
 DECLARE @xml VARCHAR(max)= '';
						SET @xml = '{ "fo_id":"'+cast(@fo_id as varchar(50))+'","fo_bs":"'+@fo_bs+'","fo_ciid":"'+cast(@fo_ciid as varchar(50))+'","fo_shid":"'+cast(@fo_shid as varchar(50))+'","fo_to_cpid":"'+cast(@fo_to_cpid as varchar(50))+'","operate_type":"'+@operate_type+'"}';
						EXEC pro_apiqueue_op 
							@tdoc_method = 'mergefundorder', 
							@tdoc_xml = @xml, 
							@tdoc_erp_id =0, 
							@tdoc_cp_id=0,
							@tdoc_state = 0;
       END
go

