CREATE PROCEDURE [dbo].[pro_pos_batchdistribution_pos_sale]
@sh_id INT=0,
@said INT =0,
@st_id INT=0
AS

if(@st_id=0 or @st_id =0)
begin
select @st_id=ps.sa_st_id ,@st_id=ps.sa_st_id from pos_sale ps where ps.sa_id=@said
end

--分配表
CREATE TABLE #batchdistribution
(
    [sal_id] INT NULL, 
	[sa_st_id] INT NULL, 
    [sal_gi_id] INT NULL, 
    [sal_sku_id] INT NULL ,
    [batchno] VARCHAR(50) NULL , 
    [applyqty] NUMERIC NULL,
   
)


--获取销售单
SELECT 
salist.sal_id,
salist.sa_st_id AS st_id,
salist.sal_gi_id AS gi_id, 
salist.sal_sku_id AS sku_id,
(CASE WHEN countType=1 THEN -salist.sal_num ELSE salist.sal_num END) as applyqty
into #salist
FROM
(
SELECT  
countType = (CASE  WHEN jpsl.sal_is_return = 1 OR jpsl.sal_is_change = 1 THEN  1 WHEN jpsl.sal_num >= 0 THEN 0 ELSE 1  END ),
jps.sa_st_id,
jpsl.sal_id,
jpsl.sal_gi_id,
jpsl.sal_sku_id,
jpsl.sal_num
FROM pos_saleList jpsl
LEFT JOIN pos_sale jps ON jpsl.sal_sa_id=jps.sa_id
where jps.sa_status > 0 AND jpsl.sal_status = 1  AND jpsl.sal_gi_id > 0  AND jps.sa_st_id > 0 AND jps.sa_sh_id > 0
AND jpsl.sal_sa_id=@said 
) salist


--当前批号库存
SELECT 
sid as st_st_id,
gid as st_gi_id,
skuid as st_sku_id,
gnum as st_num,
pm AS st_pm,
row_number() over(partition by sid order by sid,pm) as num --用于循环编号
into #stockbatch
FROM (
SELECT 
js.sl_seiid AS [sid],
js.sl_giid AS gid,
js.sl_skuid AS skuid,
isnull(js.sl_pm,'')   as pm,
js.sl_shop_id AS  shid,
SUM(CASE WHEN sl_status>0 THEN CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE - js.sl_number END ELSE 0 END ) AS gnum
 FROM pos_stocklog js WHERE  js.sl_shop_id=@sh_id  AND js.sl_seiid=@st_id AND js.sl_eoid<>@said AND js.sl_giid 
IN(
SELECT
jpsl.sal_gi_id
FROM pos_saleList jpsl
LEFT JOIN pos_sale jps ON jpsl.sal_sa_id=jps.sa_id
where jps.sa_status > 0 AND jpsl.sal_status = 1  AND jpsl.sal_gi_id > 0  AND jps.sa_st_id > 0 AND jps.sa_sh_id > 0
AND jpsl.sal_sa_id=@said 
)
Group By js.sl_seiid,js.sl_giid,js.sl_skuid,js.sl_shop_id,isnull(js.sl_pm,'')	
) AS TT
WHERE gnum>0


--按照批号计算库存
declare @i INT=0, @j INT=1 --取循环次数
select @i=MAX(num)from  #stockbatch --循环向#分配表中插数据
while (@i>=@j)
begin 
	
insert into #batchdistribution(sal_id,sa_st_id,sal_gi_id,sal_sku_id,batchno,applyqty)
SELECT * FROM (
SELECT
c.sal_id, a.st_st_id,a.st_gi_id ,a.st_sku_id,a.st_pm,
case when a.st_num<=c.applyqty then a.st_num else c.applyqty end as  applyqty
FROM #stockbatch AS a left join 
#batchdistribution b on 
a.st_st_id=b.sa_st_id and 
a.st_gi_id=b.sal_gi_id AND
a.st_sku_id=b.sal_sku_id AND
a.st_pm=b.batchno
left join  
(
SELECT
a.sal_id, a.st_id,a.gi_id, a.sku_id,
a.applyqty-isnull(b.applyqty,0)as applyqty 
from #salist a 
left join 
(
	select sal_id ,SUM(isnull(applyqty,0)) as applyqty from #batchdistribution 
	WHERE sal_id  IN (SELECT jpsl.sal_id FROM pos_saleList jpsl LEFT JOIN pos_sale jps ON jpsl.sal_sa_id=jps.sa_id where  jpsl.sal_sa_id=@said )
	group by sal_id 
) b 
on a.sal_id =b.sal_id
) c on a.st_st_id= c.st_id AND a.st_gi_id=c.gi_id and a.st_sku_id=c.sku_id
WHERE num=@j 
) as TT where TT.sal_id IS NOT NULL AND TT.applyqty<>0

set @j=@j+1
end


--没有分配到的商品，就按没批次插入
insert into #batchdistribution(sal_id,sa_st_id,sal_gi_id,sal_sku_id,batchno,applyqty)
SELECT * FROM
(
SELECT bp.sal_id,bp.sa_st_id,bp.sal_gi_id,bp.sal_sku_id,' ' pm, (sal.applyqty-bp.applyqty) AS applyqty
from #salist AS sal
LEFT JOIN (

SELECT sal_id,sa_st_id,sal_gi_id,sal_sku_id,SUM(applyqty) AS applyqty FROM #batchdistribution WHERE sal_id 
IN (SELECT jpsl.sal_id FROM pos_saleList jpsl LEFT JOIN pos_sale jps ON jpsl.sal_sa_id=jps.sa_id where  jpsl.sal_sa_id=@said )
GROUP BY sal_id,sa_st_id,sal_gi_id,sal_sku_id

) AS bp ON sal.sal_id=bp.sal_id AND sal.st_id=bp.sa_st_id AND bp.sal_gi_id=sal.gi_id AND bp.sal_sku_id=sal.sku_id
) AS nodis where applyqty<>0



--删除之前的数据
DELETE pos_batchdistribution where sal_id in(
SELECT
jpsl.sal_id
FROM pos_saleList jpsl
LEFT JOIN pos_sale jps ON jpsl.sal_sa_id=jps.sa_id
where  jpsl.sal_sa_id=@said 
)

insert into pos_batchdistribution(sal_id,sa_st_id,sal_gi_id,sal_sku_id,batchno,applyqty)
SELECT sal_id,sa_st_id,sal_gi_id,sal_sku_id,batchno,sum(applyqty) FROM #batchdistribution AS nodis 
group by sal_id,sa_st_id,sal_gi_id,sal_sku_id,batchno


DROP TABLE #stockbatch
DROP TABLE #salist
go

