CREATE VIEW [dbo].[vi_pos_inStorageList] AS 
SELECT
	inl_in_id,
	inl_gi_id,
	inl_add_time,
	SUM (inl_num) AS inl_num,
	MIN (inl_id) AS inl_id,
	MAX (inl_sku_id) AS inl_sku_id,
	SUM (inl_money) AS inl_money,
	CONVERT (
		DECIMAL (10, 2),
		AVG (inl_retail_price)
	) AS inl_retail_price,
	CONVERT (
		DECIMAL (10, 2),
		AVG (inl_stock_price)
	) AS inl_stock_price,
	MAX (inl_gift) AS inl_gift,
	MAX (inl_sample_no) AS inl_sample_no,
	CONVERT (
		DECIMAL (10, 2),
		AVG (inl_discount)
	) AS inl_discount,
	MAX (replace(inl_pm, '*', ',')) AS inl_pm,
	MAX (inl_box_num) AS inl_box_num,
	max(inl_pddate) as inl_pddate,
	max(inl_pdgddate) as inl_pdgddate
FROM
	dbo.pos_inStorageList AS jt WITH (NOLOCK) 
WHERE
	(inl_status = 1)
GROUP BY
	inl_in_id,
	inl_gi_id,
	inl_add_time
go

