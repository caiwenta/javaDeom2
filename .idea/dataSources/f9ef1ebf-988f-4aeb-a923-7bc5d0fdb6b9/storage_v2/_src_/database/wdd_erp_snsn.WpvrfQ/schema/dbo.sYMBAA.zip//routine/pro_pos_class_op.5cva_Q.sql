

CREATE PROCEDURE [dbo].[pro_pos_class_op]
@cl_id int output,
@cl_sh_id int,
@cl_name varchar(50),
@cl_start_time datetime,
@cl_end_time datetime,
@cl_add_man int,
@cl_add_time datetime,
@cl_update_man int,
@cl_update_time datetime,
@cl_status int,
--操作类型(1:添加 2:修改 3:删除)
@op_type Int=0,
@outResult int Output
AS
BEGIN
	IF @op_type=1
    Begin
	INSERT INTO [pos_class](
	[cl_sh_id],[cl_name],[cl_start_time],[cl_end_time],[cl_add_man],[cl_add_time],[cl_update_man],[cl_update_time],[cl_status]
	)VALUES(
	@cl_sh_id,@cl_name,@cl_start_time,@cl_end_time,@cl_add_man,@cl_add_time,@cl_update_man,@cl_update_time,@cl_status
	)
	SET @cl_id = SCOPE_IDENTITY()
	END
	
	IF @op_type=2 AND @cl_id>0
    Begin
    UPDATE [pos_class] SET 
	[cl_status] = @cl_status,[cl_sh_id] = @cl_sh_id,[cl_name] = @cl_name,[cl_start_time] = @cl_start_time,[cl_end_time] = @cl_end_time,[cl_update_man] = @cl_update_man,[cl_update_time] = @cl_update_time
	WHERE cl_id=@cl_id 
	AND cl_sh_id=@cl_sh_id
    END
    
    IF @op_type=3 AND @cl_id>0
    Begin
    UPDATE [pos_class] SET 
	[cl_status] = @cl_status
	WHERE cl_id=@cl_id 
	AND cl_sh_id=@cl_sh_id
    END
    
    if @@error<>0 
begin 
	set @outResult=0;
end
else 
begin
   set @outResult=@cl_id;
end
  Return @outResult;
END
go

