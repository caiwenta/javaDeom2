CREATE  Proc [dbo].[pro_update_s_goodsrule_gs_values]
@id INT=0
as
DECLARE @result VARCHAR(MAX)='';

SELECT @result=@result+fd.gd_name+',' FROM s_goodsruledetail fd
WHERE fd.gs_id=@id
ORDER BY fd.dg_sort,fd.gd_id
SET @result=SUBSTRING(@result,0,LEN(@result))
UPDATE s_goodsrule SET gs_values =@result WHERE gs_id=@id

UPDATE s_goodsruledetail SET gd_row_number=zg.tmpnum 
FROM [dbo].[s_goodsruledetail] AS sg
INNER JOIN (
select 
TOP 2000
(ROW_NUMBER() over(partition by gd.gs_id order by gd.gs_id,dg_sort,gd_id)) as tmpnum
,gd.gd_id
,gd.gd_name
,sg.gs_remark
 from dbo.s_goodsruledetail as gd 
INNER JOIN  dbo.s_goodsrule AS sg ON sg.gs_id=gd.gs_id AND  sg.gs_status<>0  AND sg.gs_id=@id
order by gd.gs_id,dg_sort,gd_id
) AS zg ON sg.gd_id=zg.gd_id
go

