


CREATE View [dbo].[vi_j_enterStorageList_sum]
As
Select 
(SELECT SUM(isnull(el_box_num,0)) FROM (
Select (case when isnull(fd.el_boxbynum,0)=0 then 0 else ceiling(sum(fd.el_number)/fd.el_boxbynum) end) as el_box_num
From j_enterStorageList fd where fd.el_status=1 AND fd.el_eoid=je.el_eoid
GROUP BY fd.el_siid,isnull(fd.el_pm,''),fd.el_boxbynum
) AS BB
) AS el_boxnum,
je.el_eoid,
Sum(je.el_number) As el_number,
Sum(je.el_realmoney) As el_realmoney 
From j_enterStorageList je where je.el_status=1 Group By je.el_eoid
go

