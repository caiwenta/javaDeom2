CREATE  FUNCTION [dbo].[FnCheckOutStorage]
(
	@oo_sh_id int,
	@oo_to_cp_id int,
	@oo_ciid int,
	@oo_status int
)
RETURNS INT
AS
BEGIN
     DECLARE @re INT=1;

	 if @oo_status>0
	 begin

		if @oo_sh_id>0 and @oo_to_cp_id>0
		begin
			SET @re = 0;
		end

		if @oo_ciid>0  and @oo_sh_id>0
		begin
			SET @re = 0;
		end

		if @oo_ciid>0  and @oo_to_cp_id>0
		begin
			SET @re = 0;
		end

	 end

	 RETURN @re;
END
go

