CREATE VIEW dbo.vi_Pos_New_Replenishment_Gist
AS
SELECT     SUM(st.gnum) AS gnum1, gist.sa_date, gist.sa_vo, gist.eosa_sh_id, gist.gi_name, gist.gi_code, gist.gi_unit, gist.sa_st_id_txt, gist.sa_order_man_txt, gist.sal_num, gist.sa_get_in_num, 
                      gist.sa_deduct_money, gist.sa_in_money, gist.sa_shop_money, gist.sa_money, gist.sa_real_money, gist.sa_charge_money, gist.sa_surplus_money, gist.sal_money, gist.sa_sa_vo, 
                      gist.sa_gift_vo, gist.sa_select, gist.sa_audit_man, gist.sa_card_money
FROM         dbo.vi_Pos_Replenishment_Gist AS gist LEFT OUTER JOIN
                      dbo.vi_pos_stockSumList AS st ON gist.gi_name = st.gi_name AND st.shid = gist.eosa_sh_id
GROUP BY gist.sa_date, gist.sa_vo, gist.eosa_sh_id, gist.gi_name, gist.gi_code, gist.gi_unit, gist.sa_st_id_txt, gist.sa_order_man_txt, gist.sal_num, gist.sa_get_in_num, gist.sa_deduct_money, 
                      gist.sa_in_money, gist.sa_shop_money, gist.sa_money, gist.sa_real_money, gist.sa_charge_money, gist.sa_surplus_money, gist.sal_money, gist.sa_sa_vo, gist.sa_gift_vo, gist.sa_select, 
                      gist.sa_audit_man, gist.sa_card_money
go

