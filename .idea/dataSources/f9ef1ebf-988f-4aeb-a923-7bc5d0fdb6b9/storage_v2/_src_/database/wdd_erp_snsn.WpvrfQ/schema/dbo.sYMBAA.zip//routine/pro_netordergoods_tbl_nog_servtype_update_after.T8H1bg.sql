CREATE PROC [dbo].[pro_netordergoods_tbl_nog_servtype_update_after]
    @nog_id INT , --订单商品ID
    @ord_id INT ,--订单ID
    @type VARCHAR(50) = 'return' --是正常退货生成退货(return)还是换货生成退货(exchange)
AS
    BEGIN
		------------------------------------
		--用途：生产订单售后相应的单据（退货单） 
		------------------------------------
        DECLARE @erp_id INT= 0; --企业ID
        DECLARE @nog_type INT= 0; --订单类型'storerule'补货售后
        DECLARE @ord_fromtype VARCHAR(50)= ''; --订单类型
        DECLARE @nog_servtype INT = 0; --售后类型（0、正常，1、退款，2、退货，3、换货）
        DECLARE @nog_servstatus INT = 0; --售后状态
        DECLARE @ord_oc_id INT = 0; --渠道ID
        DECLARE @ord_orderdate VARCHAR(50) = CONVERT(VARCHAR(50), GETDATE(), 23); --订单时间
        DECLARE @oc_client_id INT = 0; --客户主键
        DECLARE @oc_stock_id INT = 0; --仓库主键
        DECLARE @oo_addman INT = 0; --添加人
        DECLARE @ord_saletype VARCHAR(50) = ''; --销售方类型
        DECLARE @ord_sale_erp_sid INT = 0; --销售方ID
        DECLARE @ord_sendtype VARCHAR(50) = ''; --发货方类型
        DECLARE @ord_send_erp_sid INT = 0; --发货方ID
        DECLARE @is_node_to_store INT = 0; --节点销售门店发
        DECLARE @result VARCHAR(500) = '';
        DECLARE @ROLLBACK_msg VARCHAR(500) = '';

        SELECT  @nog_servtype = nog_servtype ,
                @nog_servstatus = nog_servstatus ,
                @ord_id = ord_id ,
                @erp_id = ord_erp_id ,
                @ord_saletype = ord_saletype ,
                @ord_sale_erp_sid = ord_sale_erp_sid ,
                @ord_send_erp_sid = ord_send_erp_sid ,
                @ord_sendtype = ord_sendtype ,
                @ord_fromtype = ord_fromtype ,
                @ord_oc_id = ord_oc_id ,
                @nog_type = nog_type ,
                @nog_id = nog_id
        FROM    ( SELECT    nog.* ,
                            nd.ord_id ,
                            nd.ord_oc_id ,
                            nd.ord_saletype ,
                            nd.ord_sendtype ,
                            nd.ord_fromtype ,
                            nd.ord_sale_erp_sid ,
                            nd.ord_send_erp_sid ,
                            nd.ord_erp_id
                  FROM      netordergoods_tbl nog WITH ( NOLOCK )
                            INNER JOIN netorder_tbl nd WITH ( NOLOCK ) ON nog.ord_sn = nd.ord_sn
                  WHERE     nog.nog_id = @nog_id
                ) fd;
	
        SET @ord_fromtype = LTRIM(RTRIM(@ord_fromtype));
        --店中店补货模式
        IF @ord_fromtype = 'storerule'
            BEGIN
                EXEC pro_netordergoods_tbl_insert_after @new_id = @nog_id, @type = '补货售后'
                RETURN;
            END
		--换货模式先生成出库单，再生成出库退货单
        IF ( ( @nog_type ) = 1 )
            BEGIN
                EXEC pro_netordergoods_tbl_insert_after @nog_id;
                RETURN;
            END
		--未发货退款，解锁占用库存
        IF @nog_servtype = 1
            AND @nog_servstatus = 2
            BEGIN
                UPDATE  netorder_occupy_tbl
                SET     o_status = 0 ,
                        o_update_time = GETDATE()
                WHERE   o_ord_id = @ord_id
                        AND o_nog_id = @nog_id
                        AND o_status <> 0;

                IF @@ROWCOUNT > 0
                    EXEC pro_update_occupy_num @ord_id;
            END
        --网络订单渠道设置的默认客户与默认仓库   
        SELECT  @oc_client_id = oc_client_id ,
                @oc_stock_id = oc_stock_id
        FROM    m_orderchannel WITH ( NOLOCK )
        WHERE   oc_id = @ord_oc_id;
		--需要生成销售单	
        IF @ord_saletype = 'node'
            AND @ord_sendtype = 'store'
            SET @is_node_to_store = 1;
		--生成出库退货单			
        IF ( @ord_sendtype = 'node'
             AND @is_node_to_store = 0
           )
            AND ( ( @nog_servtype = 2
                    AND @nog_servstatus = 2
                  )
                  OR ( @nog_servtype = 3
                       AND @nog_servstatus = 1
                       AND @type = 'exchange'
                     )
                  AND NOT EXISTS ( SELECT   1
                                   FROM     j_outStorage oo WITH ( NOLOCK )
                                            INNER JOIN j_outStorageList ol ON ol.ol_eoid = oo.oo_id
                                   WHERE    oo.oo_status > 0
                                            AND oo.oo_di_id = @ord_id
                                            AND oo.oo_type = 0
                                            AND ol.ol_di_id = @nog_id )
                )
            BEGIN
				--仓库
                EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'refund', 'node', @ord_send_erp_sid
                IF @oc_stock_id = 0
                    BEGIN
                        SET @ROLLBACK_msg = '未设置发货方的网络订单仓库';
                        GOTO theEnd;
                    END
				--得到添加人
                SELECT TOP 1
                        @oo_addman = si_id
                FROM    b_stafftinfo WITH ( NOLOCK )
                WHERE   si_cp_id = @ord_send_erp_sid
                        AND si_isdel = 1

                DECLARE @oo_id INT = 0; 
				--事务开始
                BEGIN TRAN
				--添加单据
                INSERT  INTO j_outStorage
                        ( oo_ciid ,
                          oo_siid ,
                          oo_no ,
                          oo_manual ,
                          oo_entrydate ,
                          oo_itid ,
                          oo_type ,
                          oo_status ,
                          oo_takemanid ,
                          oo_cost ,
                          oo_freight ,
                          oo_express ,
                          oo_expressno ,
                          oo_remark ,
                          oo_source_type ,
                          oo_source_id ,
                          oo_addman ,
                          oo_addtime ,
                          oo_lastmanid ,
                          oo_auditdate ,
                          oo_updatemam ,
                          oo_updatetime ,
                          oo_num ,
                          oo_realmoney ,
                          oo_totalmoney ,
                          oo_sh_id ,
                          oo_cp_id ,
                          oo_di_id ,
                          oo_jytype ,
                          oo_to_cp_id ,
                          oo_erp_id
	                    )
                VALUES  ( @oc_client_id ,
                          @oc_stock_id ,
                          NEWID() ,
                          '' ,
                          '2004-01-02' , --@ord_orderdate
                          0 ,
                          0 ,
                          1 ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          '网络订单' ,
                          0 ,
                          0 ,
                          @oo_addman ,--发货人
                          GETDATE() ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          0 ,
                          0 ,
                          0 ,
                          0 ,
                          @ord_send_erp_sid ,
                          @ord_id ,
                          0 ,
                          0 ,
                          @erp_id
	                    )
                SET @oo_id = SCOPE_IDENTITY();
				--添加明细
                INSERT  INTO j_outStorageList
                        ( ol_eoid ,
                          ol_siid ,
                          ol_skuid ,
                          ol_number ,
                          ol_realmoney ,
                          ol_discount ,
                          ol_remark ,
                          ol_unit ,
                          ol_costprice ,
                          ol_addtime ,
                          ol_status ,
                          ol_di_id ,
                          ol_erp_id
	                    )
                        SELECT  @oo_id AS ol_eoid ,
                                gi.gi_id ,
                                sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id
                                              ELSE 0
                                         END ,
                                nog.nog_refund_num ,
                                nog.nog_refundprice AS ol_realmoney ,
                                ( nog.nog_actualprice / nog.nog_marketprice ) AS gi_purchase_discount ,
                                '' AS ol_remark ,
                                nog.nog_marketprice ,
                                nog.nog_actualprice ,
                                nd.ord_addtime ,
                                1 AS ol_status ,
                                @nog_id ,
                                @erp_id
                        FROM    netordergoods_tbl nog WITH ( NOLOCK )
                                INNER JOIN netorder_tbl nd WITH ( NOLOCK ) ON nog.ord_sn = nd.ord_sn
                                INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                             AND nd.ord_erp_id = gi.gi_erp_id
                                LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gi.gi_id = gss.gi_id
                                                                                AND nog.nog_skucode = gss.gss_no
                        WHERE   nd.ord_id = @ord_id
                                AND nog.nog_id = @nog_id
                                AND gi.gi_status = 1
				--调用存储过程生成出库单
                EXEC pro_outStorage_op @ol_box_num = 0, @ol_pm = '', @oo_id = @oo_id, @oo_ciid = @oc_client_id, @oo_sh_id = 0, @oo_siid = @oc_stock_id,
                    @oo_takemanid = 0, @oo_remark = '网络订单', @oo_entrydate = @ord_orderdate, @oo_lastmanid = 0, @oo_itid = 0, @oo_type = 0, @oo_status = 1,
                    @oo_manual = '', @oo_jytype = 0, @oo_updatemam = @oo_addman, @ol_id = NULL, @ol_siid = NULL, @ol_number = NULL, @ol_discount = NULL,
                    @ol_realmoney = NULL, @ol_remark = NULL, @ol_unit = NULL, @ol_costprice = NULL, @ol_addtime = NULL, @ol_skuid = NULL, @ol_source_id = NULL,
                    @oo_cp_id = @ord_send_erp_sid, @oo_di_id = NULL, @ol_source_add_time = NULL, @not_in_ids = NULL, @savestr = NULL, @oo_to_cp_id = NULL,
                    @negative_inventory = 1, @op_type = '修改单据', @oo_erp_id = @erp_id, @ol_erp_id = @erp_id, @result = @result OUT
	        
                IF @result = '0'
                    OR @@ERROR <> 0
                    BEGIN
                        SET @ROLLBACK_msg = '售后生成出库退货单失败';
                        GOTO theEnd;
                    END
                ELSE
                    IF @@TRANCOUNT > 0
                        COMMIT TRAN;
            END
        ELSE
            IF ( @ord_saletype = 'store'
                 OR @is_node_to_store = 1
               )
                AND @ord_sendtype <> 'node'
                AND ( ( @nog_servtype = 2
                        AND @nog_servstatus = 2
                      )
                      OR ( @nog_servtype = 3
                           AND @nog_servstatus = 1
                           AND @type = 'exchange'
                         )
                      AND NOT EXISTS ( SELECT   1
                                       FROM     pos_sale_net psn
                                                INNER JOIN pos_sale ps ON psn.sa_net_sa_id = ps.sa_id
                                       WHERE    psn.sa_net_ord_id = @ord_id
                                                AND psn.sa_net_nog_id = @nog_id
                                                AND ps.sa_status > 0
                                                AND ps.sa_type = 1 )
                    )
                BEGIN
					--POS的ID  
                    DECLARE @ord_sh_id INT = @ord_sale_erp_sid;
                    IF @is_node_to_store = 1
                        SET @ord_sh_id = @ord_send_erp_sid;
					--得到添加人
                    SELECT TOP 1
                            @oo_addman = si_id
                    FROM    b_stafftinfo WITH ( NOLOCK )
                    WHERE   si_shop_id = @ord_sh_id
                            AND si_isdel = 1
					--仓库
                    EXEC @oc_stock_id = pro_netordergoods_tbl_get_storage_id 'refund', 'store', @ord_sh_id
                    IF @oc_stock_id = 0
                        BEGIN
                            SET @ROLLBACK_msg = '未设置发货方的网络订单仓库';
                            GOTO theEnd;
                        END

                    DECLARE @gi_id INT = 0;
                    DECLARE @sku_id INT = 0;
                    DECLARE @nog_refund_num INT = 0;
                    DECLARE @gi_purchase_discount DECIMAL(10, 2) = 0;
                    DECLARE @gi_retailprice DECIMAL(10, 2) = 0;
                    DECLARE @gi_purchase DECIMAL(10, 2) = 0;
                    DECLARE @gi_comgoods DECIMAL(10, 2) = 0;
                    DECLARE @ord_addtime DATETIME;
                    DECLARE @sa_id INT = 0;
                    DECLARE @sa_add_time DATETIME= GETDATE();
                    DECLARE @t2out DATETIME= GETDATE();
                    DECLARE @ord_payway VARCHAR(100)= '';
					--事务开始
                    BEGIN TRAN
					--游标
                    DECLARE sopcor CURSOR
                    FOR
                        ( SELECT    gi.gi_id ,
                                    sku_id = CASE WHEN gss.gss_id IS NOT NULL THEN gss.gss_id
                                                  ELSE 0
                                             END ,
                                    nog.nog_refund_num ,
                                    gi.gi_purchase_discount ,
                                    gi_retailprice = CASE WHEN CHARINDEX('现金支付', nd.ord_payway) != 0 THEN nog.nog_marketprice
                                                          ELSE nog.nog_marketprice
                                                     END ,
                                    gi_purchase = CASE WHEN CHARINDEX('现金支付', nd.ord_payway) != 0 THEN nog.nog_actualprice
                                                       ELSE nog.nog_actualprice
                                                  END ,
                                    nd.ord_addtime ,
                                    nd.ord_payway,
									-ISNULL(nog.nog_comgoods, 0) AS nog_comgoods
                          FROM      netordergoods_tbl nog WITH ( NOLOCK )
                                    INNER JOIN netorder_tbl nd WITH ( NOLOCK ) ON nog.ord_sn = nd.ord_sn
                                    INNER JOIN b_goodsinfo gi WITH ( NOLOCK ) ON nog.nog_goodscode = gi.gi_code
                                                                                 AND nd.ord_erp_id = gi.gi_erp_id
                                    LEFT JOIN b_goodsruleset gss WITH ( NOLOCK ) ON gi.gi_id = gss.gi_id
                                                                                    AND nog.nog_skucode = gss.gss_no
                          WHERE     nd.ord_id = @ord_id
                                    AND nog.nog_id = @nog_id
                                    AND gi.gi_status = 1
                        )
                    OPEN sopcor
                    FETCH NEXT FROM sopcor INTO @gi_id, @sku_id, @nog_refund_num, @gi_purchase_discount, @gi_retailprice, @gi_purchase, @ord_addtime,
                        @ord_payway, @gi_comgoods
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            EXEC pro_get_rand_time @t1 = @t2out, @t2out = @t2out OUT
	
                            SELECT  @ord_addtime = @t2out;
	            
                            EXEC pro_pos_sale_temp_op @sal_id = 0, @sal_sa_id = @sa_id, @sal_gi_id = @gi_id, @sal_sku_id = @sku_id, @sal_num = @nog_refund_num,
                                @sal_retail_price = @gi_retailprice, @sal_discount = @gi_purchase_discount, @sal_list_man = @oo_addman,
                                @sal_real_price = @gi_purchase, @sal_is_return = 1, @sal_add_time = @ord_addtime, @sa_id = @sa_id, @sa_sh_id = @ord_sh_id,
                                @sa_co_man = @oo_addman, @sa_date = @ord_orderdate, @sa_st_id = @oc_stock_id, @sa_add_man = @oo_addman,
                                @sa_add_time = @sa_add_time, @sa_type = 1, @sa_sa_type = 1, @sa_remark = '网络订单', @op_type = '添加修改单据,明细',
                                @sa_paytype = @ord_payway, @sal_deduction = @gi_comgoods, @result = @result OUT
	            
                            IF @result = '0'
                                BREAK;
	            
                            IF @sa_id = 0
                                SET @sa_id = CONVERT(INT, @result);
                                                 
                            FETCH NEXT FROM sopcor INTO @gi_id, @sku_id, @nog_refund_num, @gi_purchase_discount, @gi_retailprice, @gi_purchase, @ord_addtime,
                                @ord_payway, @gi_comgoods
                        END
                    CLOSE sopcor
                    DEALLOCATE sopcor
                         
                    IF @sa_id > 0
                        BEGIN
                            EXEC pro_pos_sale_temp_op @sa_id = @sa_id, @sa_sh_id = @ord_sh_id, @sa_co_man = @oo_addman, @sa_date = @ord_orderdate,
                                @sa_st_id = @oc_stock_id, @sa_type = 1, @sa_sa_type = 1, @sa_remark = '网络订单', @negative_inventory = 1, @sa_paytype = @ord_payway,
                                @op_type = '修改单据', @result = @result OUT

							UPDATE  netorder_tbl SET [ord_sa_id]=@sa_id
							WHERE   ord_id = @ord_id

							INSERT  INTO pos_sale_net
									( sa_net_sa_id ,
									  sa_net_ord_id ,
									  sa_net_nog_id ,
									  sa_net_add_time
									)
							VALUES  ( @sa_id ,
									  @ord_id ,
									  @nog_id ,
									  GETDATE()
									)
                        END
	            	        
                    IF @result = '0'
                        OR @@ERROR <> 0
                        BEGIN
                            SET @ROLLBACK_msg = '售后生成POS销售退货单失败';
                            GOTO theEnd;
                        END
                    ELSE
                        IF @@TRANCOUNT > 0
                            COMMIT TRAN;
                END

        theEnd:
        IF @ROLLBACK_msg <> ''
            OR @@ERROR <> 0
            BEGIN
                IF @@TRANCOUNT > 0
                    ROLLBACK TRAN;

                UPDATE  netordergoods_tbl
                SET     nog_is_ok = 0 ,
                        nog_is_ok_msg = @ROLLBACK_msg
                WHERE   nog_id = @nog_id;
            END
        ELSE
            UPDATE  netordergoods_tbl
            SET     nog_is_ok = 1 ,
                    nog_is_ok_msg = ''
            WHERE   nog_id = @nog_id;
    END
go

