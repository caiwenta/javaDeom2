

CREATE TRIGGER [dbo].[pos_stocklog_pal_ALTER_delete] ON [dbo].[pos_stocklog_pal] AFTER delete
AS
DECLARE @now DATETIME;
SET @now=GETDATE();

INSERT INTO pos_stocklog_pal_delete_back(

sl_id, sl_eoid, sl_elid, sl_seiid, sl_shid, sl_ciid, sl_giid, sl_skuid, sl_type, sl_counttype, sl_number, sl_addtime, sl_updatetime, sl_remark, sl_status, sl_deltime, sl_order_no, sl_order_date, sl_order_add_time, add_time

)
SELECT sl_id, sl_eoid, sl_elid, sl_seiid, sl_shid, sl_ciid, sl_giid, sl_skuid, sl_type, sl_counttype, sl_number, sl_addtime, sl_updatetime, sl_remark, sl_status, sl_deltime, sl_order_no, sl_order_date, sl_order_add_time,@now as  add_time
 FROM DELETED


go

