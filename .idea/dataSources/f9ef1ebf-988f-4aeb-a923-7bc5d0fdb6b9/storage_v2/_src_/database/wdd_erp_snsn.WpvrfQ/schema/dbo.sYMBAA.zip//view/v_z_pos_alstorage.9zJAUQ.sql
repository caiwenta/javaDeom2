CREATE VIEW [dbo].[v_z_pos_alstorage]
	AS 
select 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
purchaselist.*

from 
(
select 
isnull(grl.gss_no,'') as gss_no,--规格编码
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
purchase.* 
from
(
SELECT ord_sn,
al_id,
al_sh_id,
al_sh_id as sh_id,
al_erp_id,
al_vo,
CONVERT(VARCHAR(10), al_date, 120) AS al_date,
al_no,
al_get_sh_id,
al_st_id,
al_order_man,
al_add_man,
al_update_man,
al_audit_man,
( SELECT inl_num_ed FROM   dbo.vi_pos_inStorage_audit_se AS ins WHERE  (in_id = jis.al_id and in_shop_id=jis.al_sh_id ) )  AS inl_num_ed,
( SELECT sh_name FROM   dbo.pos_shop AS bs WHERE  (sh_id = jis.al_sh_id) )  AS al_out_sh_id_txt,
( SELECT sh_no FROM   dbo.pos_shop AS bs WHERE  (sh_id = jis.al_sh_id) )  AS al_out_sh_no,
( SELECT sh_name FROM   dbo.pos_shop AS bs WHERE  (sh_id = jis.al_get_sh_id) )  AS al_get_sh_id_txt,
( SELECT sh_no FROM   dbo.pos_shop AS bs WHERE  (sh_id = jis.al_get_sh_id) )  AS al_get_sh_no,
( SELECT sh_company FROM   dbo.pos_shop AS bs WHERE  (sh_id = jis.al_get_sh_id) )  AS sh_company,
( SELECT sei_name FROM   dbo.pos_storageInfo AS bs WHERE  (sei_id = jis.al_st_id) )  AS al_st_id_txt,
( SELECT si_name FROM   dbo.b_stafftinfo AS bs WHERE  (si_id = jis.al_order_man) )  AS al_order_man_txt,
( SELECT si_name FROM   dbo.b_stafftinfo AS bs WHERE  (si_id = jis.al_add_man) )  AS al_add_man_txt, al_add_time,
( SELECT si_name FROM   dbo.b_stafftinfo AS bs WHERE  (si_id = jis.al_update_man) )  AS al_update_man_txt, al_update_time,
( SELECT si_name FROM   dbo.b_stafftinfo AS bs WHERE  (si_id = jis.al_audit_man) )  AS al_audit_man_txt,
al_audit_time,
al_remark,
al_status,
isnull(jis.al_cp_do,0) AS al_cp_do,

gi.gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码	
ui.ut_name,--单位
ui.ut_name as gi_unit,
all_retail_price,        
all_discount,        
all_stock_price,
jt.all_sku_id,
jt.all_num,
jt.all_money,
all_gift,
all_add_time,
jt.all_num inl_num,
(case when  (SELECT count(1) FROM [pos_inStorage] where [in_id]=jis.al_id and [in_source]in (0,1,2))>0 then '已执行' else '未执行' end )  AS zx_status--执行状态
FROM   dbo.pos_alStorage AS jis
inner join pos_alStorageList as jt on jis.al_id=jt.all_al_id and jis.al_status<>0 and jt.all_status<>0
inner join b_goodsinfo gi on gi.gi_id=jt.all_gi_id and gi_status=1
inner join b_unit ui on ui.ut_id=gi.gi_unit 

) as  purchase
left join b_goodsruleset as grl on  grl.gss_id=purchase.all_sku_id

) as purchaselist
left join s_goodsruledetail rulenum on gd_id=purchaselist.size
go

