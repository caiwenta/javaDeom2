


CREATE VIEW [dbo].[vi_m_orderinfo_full]
AS
--订单表,订单明细,客户表,渠道订单,商品信息表
SELECT mo.oi_id,
       oi_no,
       oi_realmoney,
       oi_totalmoney,
       oi_couponmoney,
       oi_number,
       oi_status,
       oi_mname,
       oi_uid,
       oi_orderdate,
       oi_paydate,
       oi_outdate,
       oi_refunddate,
       oi_returndate,
       oi_arrivedate,
       oi_receiptid,
       oi_receipt,
       oi_delivery,
       oi_payid,
       oi_pay,
       oi_sendid,
       oi_sendno,
       oi_sendprice,
       oi_aendtype,
       oi_message,
       oi_remark,
       oi_peopleto,
       mo.oc_id,
       si_name,
       oi_stock,
       oi_stockid,
       sa_linkman,
       sa_province,
       sa_city,
       sa_county,
       sa_address,
       sa_zipcode,
       sa_tel,
       sa_phone,
       oi_code,
       vs_name,
       oi_down,
       og_id,
       og_serialid,
       og_goodsid,
       og_title,
       og_picurl,
       og_buynum,
       og_marketprice,
       og_buyprice,
       og_actualprice,
       gs_id,
       gs_name,
       gs_weight,
       gs_status,
       gs_ys,
       og_goodsno,
       oc_platform,
       mo3.oc_username,
       oc_name,
       oc_url,
       oc_linkman,
       oc_phone,
       oc_Token,
       bc.*,
       p1.*,
       (mo2.og_buynum * mo2.og_actualprice) AS og_buynum_og_actualprice
FROM   m_orderinfo mo
       INNER JOIN b_clientinfo bc
            ON  mo.oi_uid = bc.ci_id
       INNER JOIN m_ordergoods mo2
            ON  mo.oi_id = mo2.oi_id
       INNER JOIN m_orderchannel mo3
            ON  mo.oc_id = mo3.oc_id
       LEFT JOIN (
                SELECT bg.gi_id,
                       bg.gi_unit,
                       bg2.gss_no,
                       bg.gi_types,
                       bg.gi_code
                FROM   b_goodsinfo bg
                       LEFT JOIN b_goodsruleset bg2
                            ON  bg.gi_id = bg2.gi_id
            ) AS p1
            ON  mo2.og_goodsid = p1.gss_no


go

