
CREATE VIEW [dbo].[vi_j_orderblanklist] AS 
SELECT mol_mo_id,
       mol_gi_id,
       mol_add_time,
       SUM(mol_num)                    AS mol_num,
       MIN(mol_id)                     AS mol_id,
       MAX(mol_sku_id)                 AS mol_sku_id,
       SUM(mol_stock_num)              AS mol_stock_num,
       CONVERT(DECIMAL(10, 2), AVG(mol_discount)) AS mol_discount,
       CONVERT(DECIMAL(10, 2), AVG(mol_retail_price)) AS mol_retail_price,
       CONVERT(DECIMAL(10, 2), AVG(mol_stock_price)) AS mol_stock_price,
       SUM(mol_money)                  AS mol_money,
       isnull(mol_pm,'')  AS mol_pm,
	   mol_boxbynum,
       MAX(mol_box_num)                AS mol_box_num
FROM   dbo.j_orderblanklist AS jt
WHERE  (mol_status = 1)
GROUP BY
       mol_mo_id,
       mol_gi_id,
       mol_add_time,
	   isnull(mol_pm,''),
	   mol_boxbynum
go

