CREATE PROC [dbo].[pro_afterSaleAdjustment_op]
    @asa_oo_id INT = 0,--被调价的出库单id
    @asa_erp_id INT = 0,
    @asa_cp_id INT = 0,
    @asa_addman INT = 0,
    @savestr VARCHAR(MAX) = '', --被调价的调价信息字符串
    @outResult INT = 0 OUT --返回的结果(大于0的代表成功 0代表失败)
AS 

BEGIN 

     BEGIN TRY

	 DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
	 --事务开始
     BEGIN TRAN

	 DECLARE @oo_type INT= 0;
     DECLARE @oo_cp_id INT= 0;
     DECLARE  @oo_entrydate DATETIME;
	 select 
			 @oo_type=oo_type,
			 @oo_cp_id= oo_cp_id,
			 @oo_entrydate=oo_entrydate
	from j_outStorage where oo_id=@asa_oo_id

	--月报表
	IF EXISTS(SELECT TOP 1 m_month FROM j_month_report WHERE reporttype=0 AND company_id=@oo_cp_id AND  m_year=DATEPART(YEAR,@oo_entrydate) AND m_month=DATEPART(MONTH,@oo_entrydate))	
	BEGIN
		RAISERROR ('您所要操作的数据已生成月报表,数据已被锁定,禁止操作!',16,1,N'number',5);
	END


	--日报表
	IF EXISTS(SELECT TOP 1 m_day FROM j_month_report WHERE reporttype=1 AND company_id=@oo_cp_id AND  m_year=DATEPART(YEAR,@oo_entrydate) AND m_month=DATEPART(MONTH,@oo_entrydate) AND m_day=DATEPART(day,@oo_entrydate))
	BEGIN
		RAISERROR ('您所要操作的数据已生成日报表,数据已被锁定,禁止操作!',16,1,N'number',5);
	END


     ------------------------------- 新增主表信息 -------------------------------
     DECLARE @asa_id INT = 0;  --调价主表id
     INSERT INTO erp_afterSaleAdjustment
                (asa_no, 
                 asa_date, 
                 asa_oo_id, 
                 asa_erp_id,
                 asa_cp_id, 
                 asa_addman, 
                 asa_addtime)
     VALUES (
     	    '',
     	    CONVERT(varchar(100), GETDATE(), 23),
     	    @asa_oo_id, 
     	    @asa_erp_id, 
     	    @asa_cp_id, 
     	    @asa_addman,
     	    GETDATE()
     )
     SET @asa_id = SCOPE_IDENTITY();
     ------------------------------- 新增主表信息 -------------------------------
     
     -------------------------------- 凭证号生成 --------------------------------
     DECLARE @tableName VARCHAR(50) = 'erp_afterSaleAdjustment'
     DECLARE @idField VARCHAR(50) = 'asa_id'
     DECLARE @idValue INT = @asa_id;

     DECLARE @dateField VARCHAR(50) = 'asa_date'
     DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), GETDATE(), 23)

     DECLARE @noField VARCHAR(50) = 'asa_no'
     DECLARE @prevTxt VARCHAR(50) = 'SHTJ'
     DECLARE @outno VARCHAR(100) = ''


     DECLARE @while INT = 0;
     WHILE @while = 0
        BEGIN
	        --得到凭证号
            EXECUTE [pro_gen_orderNo] @tableName, @idField, @idValue, 
                                      @dateField, @dateValue, @noField,
                                      @prevTxt, @outno OUTPUT, 0, @asa_cp_id
            BEGIN TRY
                --更新
                UPDATE  erp_afterSaleAdjustment
                SET     asa_no = @outno, 
				        pzone = dbo.Get_StrArrayStrOfIndex(@outno, '-', 1) ,
                        pztwo = dbo.Get_StrArrayStrOfIndex(@outno, '-', 2) ,
                        pzthree = dbo.Get_StrArrayStrOfIndex(@outno, '-', 3)
                WHERE   asa_id = @asa_id;
                --更新成功,赋值,结束循环
                SET @while = 1;
            END TRY
            BEGIN CATCH
                PRINT '';
	----发生错误,判断错误类型
	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	--BEGIN
	--    --不是发生重复的错误
	--    --赋值,结束循环
	--    SET @while = 1;
	--END
            END CATCH
        END
     -------------------------------- 凭证号生成 --------------------------------
     
     
     DECLARE @savestr_item VARCHAR(MAX)= '';
     DECLARE @start_int INT= 1;
     DECLARE @end_int INT= (LEN(@savestr) - LEN(REPLACE(@savestr, '|', '')));
     
     DECLARE @asal_gi_id INT = 0;--调价商品
     DECLARE @asal_old_discount DECIMAL(15, 2) = 0; --原折扣
     DECLARE @asal_old_costprice DECIMAL(15, 2) = 0; --原供货价
     DECLARE @asal_new_discount DECIMAL(15, 2) = 0; --现折扣
     DECLARE @asal_new_costprice DECIMAL(15, 2) = 0;  --现供货价
     
     WHILE @start_int <= @end_int
     BEGIN 
     	SET @savestr_item=dbo.Get_StrArrayStrOfIndex(@savestr, '|', @start_int);
     	IF (RTRIM(LTRIM(@savestr_item)) = '' )
     	BEGIN
     		BREAK;
     	END
     	ELSE 
     	BEGIN
     			--拆分调价信息
     			SET @asal_gi_id=CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
     			SET @asal_old_discount = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
     			SET @asal_old_costprice = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));
     			SET @asal_new_discount = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
     			SET @asal_new_costprice = CONVERT(DECIMAL(10, 2), dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5));
     			
     			------------------------------------ 新增调价明细 ------------------------------------
     			INSERT INTO erp_afterSaleAdjustmentList(asal_asa_id,
     			                                        asal_gi_id,
     			                                        asal_old_discount,
     			                                        asal_old_costprice,
     			                                        asal_new_discount,
     			                                        asal_new_costprice)
     	        VALUES(@asa_id,
     	        	   @asal_gi_id, 
     	               @asal_old_discount, 
     	               @asal_old_costprice,
     	               @asal_new_discount, 
     	               @asal_new_costprice)
     	        ------------------------------------ 新增调价明细 ------------------------------------
     	        
     	        -------------------------------- 售后调价，更新出库单 --------------------------------
     	        --更新旧折扣、旧供货价   
     	        UPDATE j_outStorageList
     	        SET ol_olddiscount=ol_discount,
     	            ol_oldcostprice=ol_costprice,
     			    ol_aspd=@asa_addman
     	        WHERE ol_eoid=@asa_oo_id AND ol_siid=@asal_gi_id
     	        
     	        --更新现折扣、现供货价、现出库金额
     	        UPDATE j_outStorageList
     	        SET ol_discount=@asal_new_discount,
     	            ol_costprice=@asal_new_costprice,
     	            ol_realmoney=@asal_new_costprice*ol_number
     	        WHERE ol_eoid=@asa_oo_id AND ol_siid=@asal_gi_id
     	        
     	        --更新主表金额
     	        UPDATE j_outStorage
				SET oo_realmoney = vj.ol_realmoney   --实际金额
				FROM j_outStorage je,
				     vi_j_outStorageList_sum vj
				WHERE  je.oo_id=vj.ol_eoid 
					   and  je.oo_id = @asa_oo_id
     	        -------------------------------- 售后调价，更新出库单 --------------------------------
     	        
				SET @start_int = @start_int + 1;
     	END
		------------------------------------ 更新应收账款 ------------------------------------
				
     	------------------------------------ 更新应收账款 ------------------------------------
     END

     DECLARE @ol_realmoney DECIMAL(10, 2) = 0; --实际金额
	 DECLARE @fo_id int=0;
     SELECT  @ol_realmoney = SUM(je.ol_realmoney) 
			FROM  j_outStorageList je WITH ( NOLOCK ) 
			WHERE je.ol_status = 1 AND je.ol_eoid = @asa_oo_id and ol_gift=0 
			GROUP BY je.ol_eoid;

	 DECLARE @ol_givemoney DECIMAL(10, 2)=0.00;
	 SELECT @ol_givemoney = SUM(je.ol_realmoney) FROM  j_outStorageList je WITH ( NOLOCK ) 
	 WHERE je.ol_status = 1 AND je.ol_eoid = @asa_oo_id and ol_gift=1 
	 GROUP BY je.ol_eoid;

    DECLARE @finished_money DECIMAL(15, 2) = 0; --成品金额
	DECLARE @parts_money    DECIMAL(15, 2) = 0; --辅品金额  
	--成品金额
	SELECT  @finished_money = SUM(je.ol_realmoney)
	FROM    j_outStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.ol_siid = bg.gi_id
	WHERE   je.ol_eoid = @asa_oo_id
	AND je.ol_status = 1
	AND ISNULL(je.ol_gift, 0) = 0 and bg. gi_ownership=0

	--辅品金额
	SELECT  @parts_money = SUM(je.ol_realmoney)
	FROM    j_outStorageList je WITH ( NOLOCK ) left join b_goodsinfo bg WITH ( NOLOCK ) on je.ol_siid = bg.gi_id
	WHERE   je.ol_eoid = @asa_oo_id
	AND je.ol_status = 1
	AND ISNULL(je.ol_gift, 0) = 0 and bg. gi_ownership=1


	if @oo_type=0
	begin
		update c_fundorder SET fo_outmoney =@ol_realmoney,
						       fo_finished_money=@finished_money,
							   fo_parts_money=@parts_money
		WHERE fo_order_id=@asa_oo_id AND fo_type=0 ;
	end
	else
	begin
		update c_fundorder SET 
			fo_realmoney =@ol_realmoney, 
			fo_givemoney =@ol_givemoney,
			fo_finished_money=@finished_money,
			fo_parts_money=@parts_money
		WHERE fo_order_id=@asa_oo_id AND fo_type=0;
	end

	SELECT 
		@fo_id=cf.fo_id
	FROM c_fundorder cf 
	WHERE cf.fo_order_id=@asa_oo_id and cf.fo_type=0;

	--持久数据
	exec pro_mergesingleSums @orderid=@asa_oo_id, @stockType=2;

	EXEC pro_merge_fundorder @fo_id=@fo_id;

	 SET @outResult =@asa_id;
	COMMIT TRAN;
END TRY
BEGIN CATCH
	 SET @outResult =0;
	 SET @ERROR_MESSAGE = ERROR_MESSAGE();
     RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
     ROLLBACK TRAN;
END CATCH




END
go

