CREATE PROCEDURE [dbo].[pro_mergeStockLog_j_initStorage]
@cp_id INT = 0,   
@negative_inventory INT=0,--产生了负库存是否提示
@old_sei_id INT=0,  
@new_sei_id INT=0,
@id INT=0
AS
EXEC pro_mergeStockLog_check
	@cp_id = @cp_id,
	@negative_inventory = @negative_inventory,
	@old_sei_id = @old_sei_id,
	@new_sei_id = @new_sei_id
IF @@ERROR!=0
BEGIN
	DECLARE @ERROR_MESSAGE VARCHAR(100)='';
	select @ERROR_MESSAGE=ERROR_MESSAGE();
	RAISERROR ( @ERROR_MESSAGE, 16, 1, N'number', 5 );
	RETURN;
END

BEGIN
    BEGIN TRAN

	DECLARE @now DATETIME = GETDATE();

	update j_stocklog set sl_status = 0 where sl_cp_id = @cp_id and sl_eoid = @id and sl_type = 3


   
    MERGE INTO j_stocklog AS ta
    USING (

	--期初
SELECT jt.in_st_id                   AS [sid],
       cid = 0,
       ji.inl_gi_id                  AS gid,
       ji.inl_sku_id                 AS skuid,
       ji.inl_num                    AS gnum,
	    isnull(ji.inl_pm,'')                     as pm,
       countType = 1,
       myremark = '期初',
       ji.inl_add_time               AS addtime,
       jt.in_vo                      AS orderno,
       jt.in_id                      AS eoid,
       ji.inl_id                     AS elid,
       mytype = 3,
       order_add_time = jt.in_add_time,
       order_date = jt.in_date
       ,jt.in_cp_id AS cp_id,
       jt.in_erp_id erp_id
FROM   j_initStorage                 AS jt
       INNER JOIN j_initStorageList  AS ji
            ON  jt.in_id = ji.inl_in_id
WHERE  
       jt.in_id=@id
       and jt.in_status =2
       AND ji.inl_status = 1
       AND ji.inl_gi_id>0
       AND jt.in_st_id>0
	 
    ) AS so
    ON 
    ta.sl_eoid = so.eoid AND 
    ta.sl_elid = so.elid AND 
    ta.sl_giid = so.gid AND 
    ta.sl_skuid = so.skuid AND 
    ta.sl_type = so.mytype AND 
    ta.sl_cp_id = so.cp_id
    
    AND ta.sl_pm=so.pm
    AND ta.sl_seiid = so.[sid] 
    AND ta.sl_addtime = so.addtime 
    AND ta.sl_order_add_time = so.order_add_time 
    WHEN matched THEN 
    UPDATE 
    SET    ta.sl_number = so.gnum,ta.sl_counttype=so.countType,
           ta.sl_updatetime = @now,
		   ta.sl_ciid=so.cid,
		   ta.sl_pm=so.pm,
		   ta.sl_order_date=so.order_date,ta.sl_order_no=so.orderno
    WHEN NOT matched THEN
    INSERT 
      (
        sl_eoid,
        sl_elid,
        sl_seiid,
        sl_ciid,
        sl_giid,
        sl_skuid,
        sl_type,
        sl_counttype,
        sl_number,
        sl_addtime,
        sl_updatetime,
        sl_remark,
        sl_status,
        sl_order_no,
        sl_order_date,
        sl_order_add_time,
        sl_cp_id,
		sl_erp_id,
		sl_pm
      )
    VALUES
      (
        so.eoid,
        so.elid,
        so.[sid],
        so.cid,
        so.gid,
        so.skuid,
        so.mytype,
        so.countType,
        so.gnum,
        so.addtime,
        @now,
        so.myremark,
        1,
        so.orderno,
        so.order_date,
        so.order_add_time,
        so.cp_id,
		so.erp_id,
		isnull(so.pm,'')
      )
    WHEN NOT matched BY source AND 
    ta.sl_status = 1 AND ta.sl_cp_id=@cp_id AND ta.sl_type=3 AND ta.sl_eoid = @id
    THEN UPDATE SET ta.sl_status = 0,sl_deltime = @now;
    
    --计算汇总库存
    EXEC pro_mergeStockSum_new @cp_id=@cp_id,@id=@id,@type=3

	--计算汇总批次库存
	--exec pro_mergeBatchStockSum @cp_id=@cp_id,@id=@id,@type=3,
	--@negative_inventory=@negative_inventory,@old_sei_id=@old_sei_id,@new_sei_id=@new_sei_id
    
		 --计算汇总仓位库存
	EXEC pro_mergeStocklocationSum_new @cp_id=@cp_id,@id=@id,@type=3

	delete j_stocklog where sl_status = 0 and sl_cp_id = @cp_id and sl_eoid = @id and sl_type = 3

    IF @@ERROR <> 0
    BEGIN
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0 COMMIT TRAN
    END
END
go

