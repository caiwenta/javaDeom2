CREATE Proc [dbo].[pro_gen_s_pro_para_info_solid]
as

--固化存储过程参数信息
IF 1=1
BEGIN

IF OBJECT_ID('s_pro_para_info') IS NOT NULL
BEGIN
 DROP TABLE s_pro_para_info
END
SELECT OBJECT_NAME(OBJECT_ID) AS pro_name, sys.parameters.name,parameter_id,b.name As typeName,
defaultValue=case when b.name='int' or b.name='decimal' or b.name='tinyint' or b.name='numeric' then '0' when b.name='datetime' then convert(varchar(100),getdate(),25)
else '' end
,max_length,precision,is_output 
INTO s_pro_para_info
from sys.parameters Left Join systypes b On sys.parameters.system_type_id=b.xtype where 
--object_id=object_id('pro_get_para_info') And 
b.name!='sysname' Order By parameter_id;
 
END
go

