CREATE PROCEDURE [dbo].[pro_pos_mergeStockSumBatchNumber]
@sh_id INT = 0,
@id INT=0,
@type INT=0,

 @negative_inventory INT = 0 ,
    @old_sei_id INT = 0 ,
    @new_sei_id INT = 0
AS

DECLARE @now DATETIME = GETDATE();
if(@type<>0)
begin	
    SELECT DISTINCT js.sl_giid INTO #g FROM pos_stocklog  js WHERE js.sl_type=@type
    AND js.sl_eoid=@id

	
	MERGE INTO pos_stockInfobatch AS ta 
	USING (
		
	
	    
	    
SELECT 
js.sl_seiid AS [sid],
js.sl_giid AS gid,
js.sl_skuid AS skuid,
isnull(js.sl_pm,'')   as pm,
js.sl_shop_id AS  shid,
SUM(
	CASE WHEN sl_status>0 THEN 
	CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE - js.sl_number END
	ELSE 
	0
	END	
) AS gnum
  FROM pos_stocklog js WHERE  js.sl_shop_id=@sh_id AND js.sl_giid
IN(SELECT sl_giid FROM #g)
Group By 
js.sl_seiid,
js.sl_giid,
js.sl_skuid,
js.sl_shop_id,
isnull(js.sl_pm,'')

	) AS so 
	ON 
	ta.st_sh_id = so.shid AND 
	ta.st_st_id = so.[sid] AND 
	ta.st_gi_id = so.gid AND 
	ta.st_pm=so.pm AND 
	ta.st_sku_id = so.skuid 
	WHEN matched THEN 
	UPDATE 
	SET ta.st_num = so.gnum,
		add_time=CASE WHEN ta.st_num!=so.gnum THEN
		@now ELSE add_time END
	WHEN NOT matched THEN
	INSERT 
	  (
	    st_sh_id,
	    st_st_id,
	    st_gi_id,
	    st_sku_id,
	    st_num,
	    add_time,
		st_pm
	  )
	VALUES
	  (
	    so.shid,
	    so.[sid],
	    so.gid,
	    so.skuid,
	    so.gnum,
	    @now,
		isnull(so.pm,'')
	  );

	IF @@ERROR <> 0
	BEGIN
	    IF @@TRANCOUNT > 0 ROLLBACK TRAN
	END
	ELSE
	BEGIN
	    IF @@TRANCOUNT > 0 COMMIT TRAN
	END
end
else
begin

    EXEC pro_pos_mergeStockLog_check 
	@tsl_sh_id = @sh_id,
	 @negative_inventory = @negative_inventory, 
	 @old_sei_id = @old_sei_id, 
	 @new_sei_id = @new_sei_id

   IF @@ERROR != 0
        BEGIN
            DECLARE @ERROR_MESSAGE VARCHAR(100) = '';
            SELECT  @ERROR_MESSAGE = ERROR_MESSAGE();
            RAISERROR (@ERROR_MESSAGE, 16, 1, N'number', 5);
            RETURN;
        END
    BEGIN
	BEGIN TRAN

    MERGE INTO pos_stockInfobatch AS ta 
	USING (
		
		
	  SELECT shid,
       sid,
       gid,
	   isnull(sl.pm,'')   as pm,
       skuid,
       SUM(CASE WHEN sl.countType = 1 THEN sl.gnum ELSE - sl.gnum END) AS gnum
FROM   dbo.vi_pos_stockList_nolock AS sl WHERE sl.shid=@sh_id
GROUP BY
       shid,
       sid,
       gid,
       skuid,
	   isnull(sl.pm,'')
	    
	) AS so 
	ON 
	ta.st_sh_id = so.shid AND 
	ta.st_st_id = so.[sid] AND 
	ta.st_gi_id = so.gid AND 
	ta.st_sku_id = so.skuid
	AND ta.st_pm=so.pm 
	WHEN matched THEN 
	UPDATE 
	SET ta.st_num = so.gnum,
		add_time=CASE WHEN ta.st_num!=so.gnum THEN
		@now ELSE add_time END
	WHEN NOT matched THEN
	INSERT 
	  (
	    st_sh_id,
	    st_st_id,
	    st_gi_id,
	    st_sku_id,
	    st_num,
	    add_time,
		st_pm
	  )
	VALUES
	  (
	    so.shid,
	    so.[sid],
	    so.gid,
	    so.skuid,
	    so.gnum,
	    @now,
		isnull(so.pm,'')
	  )
	WHEN NOT matched BY source AND ta.st_sh_id=@sh_id 
	then UPDATE  SET ta.st_num = 0,add_time=CASE WHEN ta.st_num!=0 THEN @now ELSE add_time END;


	IF @@ERROR <> 0
	BEGIN
	    IF @@TRANCOUNT > 0 ROLLBACK TRAN
	END
	ELSE
	BEGIN
	    IF @@TRANCOUNT > 0 COMMIT TRAN
	END
	END
end
go

