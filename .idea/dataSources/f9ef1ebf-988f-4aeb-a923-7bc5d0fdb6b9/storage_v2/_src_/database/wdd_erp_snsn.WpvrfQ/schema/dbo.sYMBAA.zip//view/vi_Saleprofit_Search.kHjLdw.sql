CREATE VIEW [dbo].[vi_Saleprofit_Search]
	AS

SELECT
convert(VARCHAR(50),CONVERT(varchar(50),year)+'-'+CONVERT(varchar(50),month)) AS date, 
gi.gi_name,
gi.gi_barcode,
gi.gi_code,
gi.gi_attribute_parentids ,
gi.gi_attribute_ids ,
gi.gi_typesid ,
ui.ut_name,
bs.sei_name,
TTT.*,
sal_zcb=TTT.sal_realcb+TTT.sal_giftmoney,--总成本
sal_profit=allmoney-(TTT.sal_realcb+TTT.sal_giftmoney), --利润额
sal_profitlv=CONVERT(varchar,(CASE WHEN allmoney=0 THEN 0 ELSE (CAST(ROUND(((allmoney-(TTT.sal_realcb+TTT.sal_giftmoney))/allmoney)*100,2) AS DECIMAL(18,2))) END))+'%'
FROM
(

SELECT
TT.*,
jmr.erp_id,
jmr.company_id,
supplyprice=CAST( round((case when gnum=0 then 0 else abs(allmoney /gnum) END),2) AS DECIMAL(18,2)), --销售价
costprice=jmr.price,               --成本价
sal_realcb=jmr.price*gnum,          --销售成本
sal_giftmoney=jmr.price*giftgnum    --赠送成本                                                 
FROM
(
SELECT
year,month,fd.gid,SID,cpid,
SUM(Case when gift=0 then gnum ELSE 0 end) AS gnum,--销售数量
SUM(Case when gift=1 then gnum ELSE 0 end) AS giftgnum,--赠送数量                      
sum(allmoney) AS allmoney --销售金额
FROM (

SELECT
year=DATEPART(YEAR,je.oo_entrydate),
month=DATEPART(MONTH,je.oo_entrydate),
je.oo_cp_id AS cpid
,je2.ol_siid As gid
,je2.ol_skuid As skuid
,je.oo_siid AS sid
,(Case when je.oo_type=0 then -je2.ol_number ELSE je2.ol_number  END) As gnum
,(Case when isnull(ol_gift,0)=0 then ISNULL((Case when je.oo_type=0 then -je2.ol_realmoney ELSE je2.ol_realmoney END),0)ELSE 0 end)  as allmoney
,isnull(ol_gift,0) AS gift
From j_outStorage je Inner Join j_outStorageList je2 On  je.oo_id = je2.ol_eoid
Inner JOIN b_goodsinfo AS bg ON je2.ol_siid =bg.gi_id
Where je.oo_status=2 and je2.ol_status=1
and je2.ol_number!=0
AND je2.ol_siid>0
AND je.oo_siid>0 

) AS fd GROUP BY year,MONTH,fd.gid,SID,cpid
) AS TT
INNER JOIN j_month_report jmr ON 
jmr.gid=TT.gid AND jmr.sid=TT.[SID] AND jmr.m_year=TT.[year] AND jmr.m_month=TT.[month] AND TT.cpid=jmr.company_id and jmr.reporttype=0
) AS TTT
inner join b_goodsinfo gi on gi.gi_id=TTT.gid and gi_status=1
inner join b_unit ui on ui.ut_id=gi.gi_unit 
inner JOIN b_storageinfo bs  ON  bs.sei_id=TTT.SID
go

