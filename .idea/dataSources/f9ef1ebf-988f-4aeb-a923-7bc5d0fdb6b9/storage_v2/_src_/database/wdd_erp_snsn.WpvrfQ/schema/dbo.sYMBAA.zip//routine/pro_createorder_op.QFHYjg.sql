CREATE PROCEDURE [dbo].[pro_createorder_op]
	@param1 int = 0,
	@param2 int
AS

DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';

BEGIN TRY
BEGIN transaction


--pos退货审核
print '审核';





commit transaction
END TRY
BEGIN CATCH
	SET @ERROR_MESSAGE = ERROR_MESSAGE();
	 rollback transaction
END CATCH

if @ERROR_MESSAGE<>''
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
go

