CREATE VIEW [dbo].[v_z_pos_inStorage_audit]
	AS 
SELECT
ps.sh_company,
ps.sh_id,
ps.sh_erp_id as erp_id, 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
molist.*
from 
(

select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
mo.* 
from
(
SELECT
thtype,--0退货　1:入库
in_id,
in_type,
in_erp_id,
in_shop_id,
vpa.in_vo,--凭证号
vpa.in_date,--单据日期
(CASE when vpa.in_type=1 THEN vpa.in_supplier ELSE '调拨' end) as intype,
vpa.in_supplier_id,
vpa.in_supplier_id_txt,--供方
vpa.in_supplier_code_txt,--供方代号
(SELECT TOP 1 in_vo  FROM  pos_inStorage  AS pis WHERE  pis.in_status > 0 AND pis.in_source_id=vpa.in_id AND pis.in_source=vpa.in_type AND pis.in_status<>0 AND pis.in_source_id <>0 ) AS in_source_vo,--入库凭证号
(SELECT si_name FROM dbo.b_stafftinfo AS bs WHERE (si_id = vpa.in_man)) AS in_man_txt,--经手人
(SELECT si_name FROM dbo.b_stafftinfo AS bs WHERE (si_id = vpa.in_add_man)) AS in_add_man, --添加人
vpa.in_add_time,--添加时间
(SELECT     si_name FROM  dbo.b_stafftinfo AS bs WHERE (si_id = vpa.in_update_man)) AS in_update_man,--修改人
vpa.in_update_time,--
(SELECT  si_name FROM  dbo.b_stafftinfo AS bs WHERE (si_id = vpa.in_audit_man)) AS in_audit_man, 
vpa.in_audit_time,--
isnull(vpa.in_remark,'') as in_remark,--备注
(SELECT  TOP (1) in_st_id_txt FROM dbo.vi_pos_inStorage AS bs WHERE (in_source_no = vpa.in_vo) AND (in_status > 0)) AS ins_txt,
(SELECT si_name FROM  dbo.b_stafftinfo AS bs WHERE (si_id = vpa.in_pos_audit_man)) AS in_pos_audit_man_txt,--审核人
vpa.in_pos_audit_man, --审核人
vpa.in_pos_audit_time,--审核时间
ui.ut_name,--单位
           --
gi.gi_id,
gi.gi_skuid,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi_factoryprice,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码
isnull(vpalist.inl_num,0) as num,--规格数量
vpalist.*
FROM vi_pos_inStorage_audit vpa
INNER JOIN vi_pos_inStorageList_audit vpalist ON 
vpa.in_id=vpalist.inl_in_id AND vpa.in_type=vpalist.inl_type
inner join b_goodsinfo gi WITH (NOLOCK) on gi.gi_id=vpalist.inl_gi_id and gi_status=1
inner join b_unit ui WITH (NOLOCK) on ui.ut_id=gi.gi_unit 

) as mo
left join b_goodsruleset  as grl on  grl.gss_id=mo.inl_sku_id

) as molist
left join s_goodsruledetail rulenum on gd_id= molist.size
inner join pos_shop ps on ps.sh_id=molist.in_shop_id
go

