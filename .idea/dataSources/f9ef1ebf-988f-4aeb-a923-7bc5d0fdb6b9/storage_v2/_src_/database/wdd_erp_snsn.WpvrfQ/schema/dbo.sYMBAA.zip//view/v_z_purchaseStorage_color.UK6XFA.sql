CREATE VIEW [dbo].[v_z_purchaseStorage_color]
AS

SELECT
st.pcs_id color_order_id,
ge.pl_status,
ge.pzone,
ge.pl_cp_id,
(SELECT cp_name FROM companyinfo WHERE cp_id=ge.pl_cp_id)cp_name,
ge.pl_erp_id,
ge.pl_erp_id AS erp_id,
st.pll_pl_id,
ge.pl_id,  
ge.pl_pltype,--退货
ge.pl_type,  --采购方式

(SELECT pos.og_vo FROM pos_ogStorage pos WHERE pos.og_id=st.pll_source_id) AS og_vo,

(SELECT MAX(ogl_og_id) FROM pos_ogStorageList psl WITH (NOLOCK) WHERE psl.ogl_id=st.pll_source_id and psl.ogl_status=1) AS og_id,
ge.pl_vo,--凭证号
ge.pl_no,--单据号
CONVERT(VARCHAR(100), ge.pl_date, 23) AS  pl_date,--采购日期
CONVERT(VARCHAR(100), ge.pl_enddate, 23) AS  pl_enddate,--预计交货日期
ge.pl_remark,--单据状态
ge.pl_ci_id,
spi.si_name AS pl_ci_id_txt,--供应商
spi.si_name,--供应商
spi.si_code,--供应商代号
pl_order_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_order_man),--经手人
pl_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_add_man ),--单据添加人
pl_add_time,--单据添加时间
pl_update_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =pl_update_man),--单据修改人
pl_update_time,--单据修改时间
pl_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_audit_man),--单据修改人
pl_audit_time, --单据审核时间
ui.ut_name AS gi_unit, --单位
ui.ut_name,--单位
pll_add_time, --商品添加时间

'' AS specname,   
		
st.pll_color_id,--颜色id    
ISNULL((SELECT TOP 1 colorname FROM b_goodsruleset b WHERE b.gi_id=st.pll_gi_id AND colorid=st.pll_color_id ),'无') AS color,                                                   
st.pll_gi_id,
gi.gi_id,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode, --商品条形码
gi.gi_skuid,
gi.gi_skus,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
(SELECT gc_name FROM s_goodsclass WITH (NOLOCK) WHERE gc_id=gi.gi_type1)gi_typename1,
(SELECT gc_name FROM s_goodsclass WITH (NOLOCK) WHERE gc_id=gi.gi_type2)gi_typename2,
(SELECT gc_name FROM s_goodsclass WITH (NOLOCK) WHERE gc_id=gi.gi_type3)gi_typename3,
(SELECT gc_name FROM s_goodsclass WITH (NOLOCK) WHERE gc_id=gi.gi_type4)gi_typename4,
gi.gi_sampleno,--样品号
ISNULL((SELECT TOP 1 b.gs_sampleno 
		FROM b_goodsruleset b 
		WHERE b.gi_id=st.pll_gi_id AND colorid=st.pll_color_id),gi.gi_sampleno) AS gs_sampleno,--规格样品号
ISNULL(st.pll_discount,0) AS pll_discount,--折率
ISNULL(st.pll_retail_price,0) AS pll_retail_price ,--零售价
(st.pll_num * st.pll_retail_price) AS pll_retail_money,--零售金额
ISNULL(st.pll_stock_price,0) AS pll_stock_price,--进货价
ISNULL(st.pll_money,0) AS pll_money,--采购金额
                                    
ISNULL(st.pll_num,0) AS num,--规格数量
ISNULL(st.pll_num,0) AS pll_num,--数量
ISNULL(st.pll_num_ed,0) AS pll_num_ed, --已入库数量
ISNULL(st.pll_pause_num,0) AS pll_pause_num,
ISNULL(st.pll_pause_num,0) AS pll_pause_num1, --终止数量
(ISNULL(st.pll_num,0)-ISNULL(st.pll_num_ed,0)-ISNULL(st.pll_pause_num,0)) AS rk_el_number_do, --未入库数量
                                
st.pll_pm,--配码
ISNULL(st.pll_boxbynum,0) AS pll_boxbynum,--数量/箱
ISNULL(st.pll_box_num,0) AS pll_box_num,--箱数
ISNULL(st.pll_box_num_ed,0) AS pll_box_num_ed,--已入库箱数
ISNULL(st.pll_pause_box_num,0) AS pll_pause_box_num,--终止箱数
(ISNULL(st.pll_box_num,0)-ISNULL(st.pll_box_num_ed,0)-ISNULL(st.pll_pause_box_num,0)) AS rk_el_box_number_do --未入库箱数

FROM j_purchaseStorage ge
INNER JOIN j_purchasestoragelistmergecolorsum st ON ge.pl_id = pll_pl_id AND st.pll_status = 1 AND ge.pl_status>0
INNER JOIN b_goodsinfo gi ON gi.gi_id=st.pll_gi_id AND gi_status=1
LEFT JOIN b_unit ui ON ui.ut_id=gi.gi_unit 
LEFT JOIN b_supplierinfo spi ON spi.si_id= ge.pl_ci_id AND spi.si_status=1
WHERE pll_num<>0
go

