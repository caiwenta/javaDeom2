

CREATE PROC [dbo].[pro_pos_allocation_skuid_search_tb]

@all_box_num INT = 0,

@all_pm VARCHAR(500) = '',

@gss_no VARCHAR(500) = '',
--主键  
@all_id INT = 0,  
--配货主键  
@all_al_id INT = 0,  
--商品主键  
@all_gi_id INT = 0,  
--商品sku主键  
@all_sku_id INT = 0,  
--数量  
@all_num INT = 0,  
--零售价  
@all_retail_price DECIMAL(9, 2) = 0,  
--零售金额  
@all_retail_money DECIMAL(9, 2) = 0,  
--折率  
@all_discount DECIMAL(9, 2) = 0,  
--供货价  
@all_stock_price DECIMAL(9, 2) = 0,  
--金额  
@all_money DECIMAL(9, 2) = 0,  
--是否赠送  
@all_gift INT = 0,  
--添加时间  
@all_add_time DATETIME = '2014-10-24', 
--来源明细主键
@all_source_id INT = 0, 
--主键  
@al_id INT = 0,  
--单据号  
@al_no VARCHAR(50) = '',  
--配货日期  
@al_date DATETIME = '2014-10-24',  
--交易方式(1,订货:2,补货:3,铺货:4,买断)  
@al_type INT = 0,  
--客户主键  
@al_ci_id INT = 0,  
--店铺主键  
@al_sh_id INT = 0,  
--运输方式  
@al_trans VARCHAR(50) = '',  
--仓库主键  
@al_st_id INT = 0,  
--货运单号  
@al_freight_no VARCHAR(50) = '',  
--垫付运费  
@al_fright DECIMAL(9, 2) = 0,  
--来源(1,订货:2,终端补货:3,终端退货)  
@al_source INT = 0,  
--来源主键  
@al_source_id INT = 0,  
--制单人主键  
@al_order_man INT = 0,  
--添加人主键  
@al_add_man INT = 0,  
--添加时间  
@al_add_time DATETIME = '2014-10-24',  
--修改人主键  
@al_update_man INT = 0,  
--修改时间  
@al_update_time DATETIME = '2014-10-24',  
--审核人主键  
@al_audit_man INT = 0,  
--审核时间  
@al_audit_time DATETIME = '2014-10-24',  
--来源添加时间 
@all_source_add_time DATETIME = '2014-10-24', 
--判断是否是补货审核的数据
@al_butype INT = 0,
--判断是否是订货审核的数据
@al_dhtype INT = 0,
--判断是否是订货审核的存储过程
@dhtype INT = 0,
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  
--结果  
@result VARCHAR(100) = '' OUT,
--公司主键
@al_cp_id INT = 0,
--部门主键
@al_di_id INT = 0,
--分公司主键
@al_to_cp_id INT = 0,
--保存字符串
@savestr VARCHAR(MAX) = '' ,
--前台排出的商品(单击清空明细按钮时会记录商品主键,添加时间)
@not_in_ids VARCHAR(MAX) = '',

@order_id  VARCHAR(MAX)='',
@good_id VARCHAR(MAX)=''
AS

  
begin

DECLARE @m_gi_id int = 0;
DECLARE @m_skuid int = 0;
DECLARE @m_gss_no VARCHAR(50) = '';
DECLARE @m_gi_add_time DATETIME;
DECLARE @m_gi_purchase DECIMAL(9, 2) = 0;
DECLARE @m_gi_retailprice DECIMAL(9, 2) = 0;
DECLARE @tep_gi_purchase DECIMAL(9, 2) = 0;
DECLARE @tep_gi_retailprice DECIMAL(9, 2) = 0;

DECLARE @m_gd_discount DECIMAL(9, 2) = 0;

DECLARE @m_all_new_num int = 0;
DECLARE @m_all_old_num int = 0;

DECLARE @m_gs_weight DECIMAL(9, 2) = 0;  
DECLARE @m_all_add_time DATETIME;  
DECLARE @m_al_add_time datetime;  
DECLARE @m_all_id int = 0;
DECLARE @m_gi_barcode VARCHAR(50) = 0;
DECLARE @m_al_type VARCHAR(50) = 0;
DECLARE @mtest VARCHAR(500) = '';
--============  
 
--修改时
if @al_id>0 BEGIN
  set  @all_al_id=@al_id 
end
set  @all_id=0
 

set  @m_all_new_num=0;
set @savestr ='';

if EXISTS(SELECT * from b_goodsruleset where gss_no like   '%'+@gss_no+'%')--有规格
BEGIN 
declare cursor1 cursor for
SELECT   bg2.gi_id,  bg.gss_no,  bg.gss_id, bg2.gi_add_time, bg.gs_marketprice,
 bg.gs_marketprice,--bg.gs_purchase,
 bg.gs_marketprice/bg.gs_marketprice as gs_discount --bg.gs_discount--bg2.gi_retailprice, bg2.gi_purchase,bg2.gi_purchase_discount
FROM   b_goodsruleset  AS bg  
       LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id  
WHERE  bg2.gi_id=(SELECT top 1 gi_id from b_goodsruleset where gss_no =  @gss_no ) 


 --使用游标的对象(跟据需要填入select文)
 OPEN cursor1 --打开游标
 FETCH NEXT FROM cursor1 INTO  @m_gi_id,@m_gss_no,@m_skuid,@m_gi_add_time,@m_gi_retailprice,@m_gi_purchase,@m_gd_discount --,@m_gs_weight--将游标向下移1行，获取的数据放入之前定义的变量@id,@name中

if @m_gi_id=0 BEGIN

  set @result='输入错误,当前商品有规格，请输入正确的规格编码！';
 SELECT 'id'=@result ;
return
end

WHILE @@fetch_status = 0 --判断是否成功获取数据
BEGIN
    --SELECT 'return='=@m_gss_no 
  --修改数量时得出原单据数量
--set @all_num= @m_all_new_num+3 
 
  if @al_id>0 BEGIN
   IF EXISTS(SELECT * from pos_allocationList WHERE  all_al_id = @al_id  and  all_gi_id = @m_gi_id and all_sku_id=@m_skuid  and all_status>0)
   BEGIN
  SELECT top 1 @m_all_id=all_id,@m_all_add_time=all_add_time,@m_all_old_num =all_num from pos_allocationList WHERE  all_al_id = @al_id and  all_gi_id = @m_gi_id and all_sku_id=@m_skuid  and all_status>0
   set @all_add_time=@m_all_add_time
      SELECT top 1 @m_al_add_time=al_add_time from pos_allocation where al_id=@al_id and al_status>0
   set @al_add_time=@m_al_add_time
     set @m_all_id=@m_all_id
   set @all_id=@m_all_id
   --set @all_num=@m_all_old_num --旧数量
   --if @al_id>0 BEGIN
   --set @all_num=999
  --end
  end
  end

 --判断类型   s
 if @al_type>0 
BEGIN
--店铺主键  
 if @al_sh_id>0 
BEGIN
    --根据店铺获得进货价 s
  
--不同类型的，订货，补货，铺货，买断
 if @al_type=1
 BEGIN
if EXISTS(SELECT * FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_dhprice WHERE  gd_class = 2  and sh_id =@al_sh_id  and a.gd_gi_id=@m_gi_id) 
  BEGIN
   SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_dhprice WHERE  gd_class = 2  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_dhprice WHERE  gd_class = 1  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺零售价
 end
 end
 else if @al_type=2
 BEGIN
if EXISTS(SELECT * FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_bhprice WHERE  gd_class = 2  and sh_id =@al_sh_id  and a.gd_gi_id=@m_gi_id) 
  BEGIN
    SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_bhprice WHERE  gd_class = 2  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_bhprice WHERE  gd_class = 1  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺零售价
  end
 end
 else if @al_type=3
 BEGIN
if EXISTS(SELECT * FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_phprice WHERE  gd_class = 2  and sh_id =@al_sh_id  and a.gd_gi_id=@m_gi_id) 
  BEGIN
    SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_phprice WHERE  gd_class = 2  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_phprice WHERE  gd_class = 1  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺零售价
end
 end
 else if @al_type=4
 BEGIN
if EXISTS(SELECT * FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_mdprice WHERE  gd_class = 2  and sh_id =@al_sh_id  and a.gd_gi_id=@m_gi_id) 
  BEGIN
    SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_mdprice WHERE  gd_class = 2  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_mdprice WHERE  gd_class = 1  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺零售价
end
 
 end 
  --根据店铺获得进货价 e
end

--公司主键  
 if @al_to_cp_id>0 
BEGIN
    --根据店铺获得进货价 s
if @al_type=1
 BEGIN
   if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE  gd_class = 1 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司零售价
  end 
 end
 else if @al_type=2
 BEGIN
   
  if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_bhprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_bhprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_bhprice WHERE  gd_class = 1 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司零售价
  end 
 end
 else if @al_type=3
 BEGIN
  
if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_phprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_phprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_phprice WHERE  gd_class = 1 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司零售价
  end 
 end
 else if @al_type=4
 BEGIN
   if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_mdprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_mdprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_mdprice WHERE  gd_class = 1 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司零售价
  end 

 end
  
  --根据店铺获得进货价 e
end

--客户主键  
 if @al_ci_id>0 
BEGIN
    --根据店铺获得进货价 s
if @al_type=1
 BEGIN
   if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_dhprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_dhprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_dhprice WHERE gd_class = 1 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户零售价
  end 
 end
 else if @al_type=2
 BEGIN
   if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_bhprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_bhprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_bhprice WHERE gd_class = 1 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户零售价
  end 
  
 end
 else if @al_type=3
 BEGIN
  if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_phprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_phprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_phprice WHERE gd_class = 1 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户零售价
  end 

 end
 else if @al_type=4
 BEGIN
   
if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_mdprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_mdprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_mdprice WHERE gd_class = 1 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户零售价
  end 
 end
  
  --根据店铺获得进货价 e
end
if @tep_gi_purchase>0 BEGIN
set @m_gi_purchase=@tep_gi_purchase
end
if @tep_gi_retailprice>0 BEGIN
set @m_gi_retailprice=@tep_gi_retailprice
end
end
 --判断类型   e


  set @all_sku_id=@m_skuid
  set @all_stock_price=@m_gi_purchase
  set @all_retail_price=@m_gi_retailprice
  set @m_gd_discount=@m_gi_purchase/@m_gi_retailprice

  set @all_gi_id=@m_gi_id
  set @mtest=@mtest+cast(@m_skuid as varchar(10)) +'|'
    if @m_gss_no!=@gss_no BEGIN --使用旧数量
    set @savestr =@savestr +cast(@all_id as varchar(10))+',' + cast(@all_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+   cast(@m_all_old_num as varchar(10))+','+  cast(@m_gi_retailprice as varchar(10)) +','+ cast(@all_stock_price as varchar(10))+ ','+cast(@m_gd_discount as varchar(10))+',,0,|'  
  END
  else
  BEGIN--使用新数量 
   set @all_num=@all_num+@m_all_old_num
   set @savestr =@savestr +cast(@all_id as varchar(10))+',' + cast(@all_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+   cast(@all_num as varchar(10))+','+   cast(@m_gi_retailprice as varchar(10)) +','+ cast(@all_stock_price as varchar(10))+','+ cast(@m_gd_discount as varchar(10))+',,0,|'  
  end
 
    --进行相应处理(跟据需要填入SQL文)

 FETCH NEXT

FROM
 cursor1 INTO  @m_gi_id,@m_gss_no,@m_skuid,@m_gi_add_time,@m_gi_retailprice,@m_gi_purchase,@m_gd_discount--,@m_gs_weight --将游标向下移1行
END
CLOSE cursor1 --关闭游标
DEALLOCATE cursor1
end
ELSE
BEGIN
--无规格
if EXISTS(SELECT  * from b_goodsinfo bg2  WHERE  bg2.gi_barcode=@gss_no)
BEGIN
 SELECT  top 1 @m_gi_id= bg2.gi_id, @m_gi_barcode=bg2.gi_barcode, @m_gi_add_time=bg2.gi_add_time, @m_gi_retailprice=bg2.gi_retailprice, @m_gi_purchase=bg2.gi_purchase, @m_gi_retailprice=bg2.gi_retailprice  from b_goodsinfo bg2  WHERE  bg2.gi_barcode=@gss_no

     if @al_id>0 BEGIN
   IF EXISTS(SELECT * from pos_allocationList WHERE  all_al_id = @al_id  and  all_gi_id = @m_gi_id   and all_status>0)
   BEGIN
  SELECT top 1 @m_all_id=all_id,@m_all_add_time=all_add_time,@m_all_old_num =all_num from pos_allocationList WHERE  all_al_id = @al_id and  all_gi_id = @m_gi_id    and all_status>0
   set @all_add_time=@m_all_add_time
      SELECT top 1 @m_al_add_time=al_add_time from pos_allocation where al_id=@al_id and al_status>0
   set @al_add_time=@m_al_add_time
     set @m_all_id=@m_all_id
   set @all_id=@m_all_id
   --set @all_num=@m_all_old_num --旧数量
   --if @al_id>0 BEGIN
   --set @all_num=999
  --end
  end
  end

 --判断类型   s
 if @al_type>0 
BEGIN
--店铺主键  
 if @al_sh_id>0 
BEGIN
    --根据店铺获得进货价 s
  
--不同类型的，订货，补货，铺货，买断
 if @al_type=1
 BEGIN
if EXISTS(SELECT * FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_dhprice WHERE  gd_class = 2  and sh_id =@al_sh_id  and a.gd_gi_id=@m_gi_id) 
  BEGIN
   SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_dhprice WHERE  gd_class = 2  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_dhprice WHERE  gd_class = 1  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺零售价
 end
 end
 else if @al_type=2
 BEGIN
if EXISTS(SELECT * FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_bhprice WHERE  gd_class = 2  and sh_id =@al_sh_id  and a.gd_gi_id=@m_gi_id) 
  BEGIN
    SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_bhprice WHERE  gd_class = 2  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_bhprice WHERE  gd_class = 1  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺零售价
  end
 end
 else if @al_type=3
 BEGIN
if EXISTS(SELECT * FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_phprice WHERE  gd_class = 2  and sh_id =@al_sh_id  and a.gd_gi_id=@m_gi_id) 
  BEGIN
    SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_phprice WHERE  gd_class = 2  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_phprice WHERE  gd_class = 1  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺零售价
end
 end
 else if @al_type=4
 BEGIN
if EXISTS(SELECT * FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_mdprice WHERE  gd_class = 2  and sh_id =@al_sh_id  and a.gd_gi_id=@m_gi_id) 
  BEGIN
    SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_mdprice WHERE  gd_class = 2  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN pos_shop b ON a.gd_type = b.sh_mdprice WHERE  gd_class = 1  and sh_id = @al_sh_id  and a.gd_gi_id=@m_gi_id--店铺零售价
end
 
 end 
  --根据店铺获得进货价 e
end

--公司主键  
 if @al_to_cp_id>0 
BEGIN
    --根据店铺获得进货价 s
if @al_type=1
 BEGIN
   if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_dhprice WHERE  gd_class = 1 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司零售价
  end 
 end
 else if @al_type=2
 BEGIN
   
  if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_bhprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_bhprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_bhprice WHERE  gd_class = 1 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司零售价
  end 
 end
 else if @al_type=3
 BEGIN
  
if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_phprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_phprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_phprice WHERE  gd_class = 1 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司零售价
  end 
 end
 else if @al_type=4
 BEGIN
   if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_mdprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_mdprice WHERE  gd_class = 2 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN companyinfo b ON a.gd_type = b.cp_mdprice WHERE  gd_class = 1 AND   b.cp_id=@al_to_cp_id and a.gd_gi_id=@m_gi_id--公司零售价
  end 

 end
  
  --根据店铺获得进货价 e
end

--客户主键  
 if @al_ci_id>0 
BEGIN
    --根据店铺获得进货价 s
if @al_type=1
 BEGIN
   if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_dhprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_dhprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_dhprice WHERE gd_class = 1 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户零售价
  end 
 end
 else if @al_type=2
 BEGIN
   if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_bhprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_bhprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_bhprice WHERE gd_class = 1 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户零售价
  end 
  
 end
 else if @al_type=3
 BEGIN
  if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_phprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_phprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_phprice WHERE gd_class = 1 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户零售价
  end 

 end
 else if @al_type=4
 BEGIN
   
if EXISTS(SELECT *  FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_mdprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id) 
  BEGIN
  SELECT top 1 @tep_gi_purchase=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_mdprice WHERE gd_class = 2 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户供货价
   SELECT top 1 @tep_gi_retailprice=a.gd_price FROM b_goods_discount a LEFT JOIN b_clientinfo b ON a.gd_type = b.ci_mdprice WHERE gd_class = 1 AND   b.ci_id=@al_ci_id and a.gd_gi_id=@m_gi_id--客户零售价
  end 
 end
  
  --根据店铺获得进货价 e
end
if @tep_gi_purchase>0 BEGIN
set @m_gi_purchase=@tep_gi_purchase
end
if @tep_gi_retailprice>0 BEGIN
set @m_gi_retailprice=@tep_gi_retailprice
end
end
 --判断类型   e

  set @all_sku_id=@m_skuid
  set @all_stock_price=@m_gi_purchase
  set @all_retail_price=@m_gi_retailprice
   set @m_gd_discount=@m_gi_purchase/@m_gi_retailprice
  set @all_gi_id=@m_gi_id
  set @mtest=@mtest+cast(@m_skuid as varchar(10)) +'|'
    if @m_gi_barcode!=@gss_no BEGIN --使用旧数量
    set @savestr =@savestr +cast(@all_id as varchar(10))+',' + cast(@all_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+  cast(@m_all_old_num as varchar(10))+','+  cast(@m_gi_retailprice as varchar(10)) +','+ cast(@all_stock_price as varchar(10))+','+ cast(@m_gd_discount as varchar(10))+',,0,|' 
  END
  else
  BEGIN--使用新数量 
   set @all_num=@all_num+@m_all_old_num
   set @savestr =@savestr +cast(@all_id as varchar(10))+',' + cast(@all_gi_id as varchar(10))+','+ cast(@m_skuid as varchar(10))+','+   cast(@all_num as varchar(10))+','+  cast(@m_gi_retailprice as varchar(10)) +','+ cast(@all_stock_price as varchar(10))+ ','+cast(@m_gd_discount as varchar(10))+',,0,|' 
  end

END
ELSE
BEGIN
 set @result=0;
 SELECT 'id'=@result ;
return
end
end

 


--SELECT 'return='=@m_gd_discount
--SELECT 'return='=@al_type
--return 
--==================



 


set @op_type='添加修改单据,明细'
EXECUTE [pro_pos_allocation_op]
@all_box_num,
@all_pm,
--主键  
@all_id,  
--配货主键  
@all_al_id,  
--商品主键  
@all_gi_id,  
--商品sku主键  
@all_sku_id,  
--数量  
@all_num,  
--零售价  
@all_retail_price,  
--零售金额  
@all_retail_money,  
--折率  
@all_discount,  
--供货价  
@all_stock_price,  
--金额  
@all_money,  
--是否赠送  
@all_gift,  
--添加时间  
@all_add_time, 
--来源明细主键
@all_source_id, 
--主键  
@al_id,  
--单据号  
@al_no,  
--配货日期  
@al_date,  
--交易方式(1,订货:2,补货:3,铺货:4,买断)  
@al_type,  
--客户主键  
@al_ci_id,  
--店铺主键  
@al_sh_id,  
--运输方式  
@al_trans,  
--仓库主键  
@al_st_id,  
--货运单号  
@al_freight_no,  
--垫付运费  
@al_fright,  
--来源(1,订货:2,终端补货:3,终端退货)  
@al_source,  
--来源主键  
@al_source_id,  
--制单人主键  
@al_order_man,  
--添加人主键  
@al_add_man,  
--添加时间  
@al_add_time,  
--修改人主键  
@al_update_man,  
--修改时间  
@al_update_time,  
--审核人主键  
@al_audit_man,  
--审核时间  
@al_audit_time,  
--来源添加时间 
@all_source_add_time, 
--判断是否是补货审核的数据
@al_butype,
--判断是否是订货审核的数据
@al_dhtype,
--判断是否是订货审核的存储过程
@dhtype,
--操作类型  
@op_type,  
--结果  
@result  OUTPUT,
--公司主键
@al_cp_id,
--部门主键
@al_di_id,
--分公司主键
@al_to_cp_id,
--保存字符串
@savestr,
--前台排出的商品(单击清空明细按钮时会记录商品主键,添加时间)
@not_in_ids,

@order_id,
@good_id 

SELECT 'id'=@result 
--==================
--SELECT   bg2.gi_id, bg.gss_no, bg2.gi_add_time
--FROM   b_goodsruleset  AS bg  
--       LEFT JOIN b_goodsinfo bg2 ON bg.gi_id=bg2.gi_id
--WHERE  bg.gi_id = @gi_id   AND bg.gss_no = @gss_no
 
end


go

