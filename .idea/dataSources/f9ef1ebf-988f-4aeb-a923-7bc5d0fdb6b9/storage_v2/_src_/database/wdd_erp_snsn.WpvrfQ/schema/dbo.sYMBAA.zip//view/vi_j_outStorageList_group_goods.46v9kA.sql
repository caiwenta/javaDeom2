CREATE VIEW [dbo].[vi_j_outStorageList_group_goods] AS 
SELECT

(SELECT SUM(var_num) FROM erp_inspectionofgoods WHERE orderid=ol_eoid AND gi_id=ol_siid AND warehousingtype=2 and iog_status=1 ) as var_num, --验货数
isnull((SELECT sum(jesl.el_number) FROM j_enterStorage js INNER JOIN j_enterStorageList jesl ON js.eo_id=jesl.el_eoid AND eo_source_type=2  AND eo_status>0 AND jesl.el_status>0 AND js.eo_source_id=ol_eoid AND  jesl.el_siid=gi_id),0) as ennum, --收货数

	jt.ol_eoid,
	jt.ol_siid,
	jt.ol_number,
	(SELECT max(josl.ol_id) FROM j_outStorageList AS josl  WHERE josl.ol_eoid=jt.ol_eoid  AND josl.ol_siid=jt.ol_siid AND josl.ol_addtime=jt.ol_addtime and jt.ol_status>0)ol_id,
	jt.ol_realmoney,
	jt.ol_unit,
	jt.ol_costprice,
	jt.ol_discount,
	(case when isnull(bg.gi_skuid,'')='' then 0 else 1 end)	as ol_skuid,
	jt.ol_gift,
	(select max(isruleprice) from j_outStorageList where ol_eoid=jt.ol_eoid) as isruleprice ,
	CONVERT (
		VARCHAR (100),
		jt.ol_addtime,
		25
	) AS ol_addtime,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_cratebox,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_factoryprice,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bg.gi_sampleno,--样品号
	bu.ut_name AS gi_unit,
	bu.ut_id AS gi_unit_id,
	ol_pm,
	ol_boxbynum,
    (case when isnull(ol_boxbynum,0)=0 then 0 else ceiling(ol_number/ol_boxbynum) end) as ol_box_num,
	(case when oo_source_type =1 then
	 (select al_vo from pos_Allocation where al_id=jt.ol_source_id ) --配货
	 when oo_source_type=2 then 
	 (select eo_no from j_enterStorage where eo_id=jt.ol_source_id) --分公司入库退货
	 when oo_source_type=3 then
	 (select in_vo from pos_inStorage where in_id=jt.ol_source_id) --pos入库退货
	 end) as al_vo,
	 supplyprice,
	 discount,
	 (case when supplyprice=0 then 0 else CONVERT(decimal(9,2), (ol_costprice/supplyprice)) end ) as realitydiscount
FROM
	dbo.j_outStorageListMergeSum AS jt
	INNER join j_outStorage as jo on jo.oo_id=jt.ol_eoid and jt.ol_status>0
INNER JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON jt.ol_siid = bg.gi_id
LEFT JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
go

