CREATE VIEW [dbo].[vi_j_outStorageList_group_goods] AS 
SELECT

(SELECT SUM(var_num) FROM erp_inspectionofgoods WHERE orderid=ol_eoid AND gi_id=ol_siid AND warehousingtype=2 and iog_status=1 ) as var_num, --验货数
isnull((SELECT sum(jesl.el_number) FROM j_enterStorage js INNER JOIN j_enterStorageList jesl ON js.eo_id=jesl.el_eoid AND eo_source_type=2  AND eo_status>0 AND jesl.el_status>0 AND js.eo_source_id=ol_eoid AND  jesl.el_siid=gi_id),0) as ennum, --收货数

	jt.ol_eoid,
	jt.ol_siid,
	jt.ol_number,
	jt.ol_id,
	jt.ol_realmoney,
	jt.ol_unit,
	jt.ol_costprice,
	jt.ol_discount,
	jt.ol_skuid,
	jt.ol_gift,
	jt.isruleprice as isruleprice ,
	CONVERT (
		VARCHAR (100),
		jt.ol_addtime,
		25
	) AS ol_addtime,
	bg.gi_id,
	bg.gi_shortname,
	bg.gi_name,
	bg.gi_type,
	bg.gi_code,
	bg.gi_grade,
	bg.gi_norm,
	bg.gi_status,
	bg.gi_remark,
	bg.gi_entrydate,
	bg.si_img,
	bg.gi_skus,
	bg.gi_alarmstock,
	bg.gi_barcode,
	bg.gi_brands,
	bg.gi_cratebox,
	bg.gi_category,
	bg.gi_costprice,
	bg.gi_downstork,
	bg.gi_importprices,
	bg.gi_factoryprice,
	bg.gi_number,
	bg.gi_retailprice,
	bg.gi_seiid,
	bg.gi_seiname,
	bg.gi_typeone,
	bg.gi_types,
	bg.gi_typesid,
	bg.gi_upstock,
	bg.gi_virtual,
	bg.gi_weight,
	bg.gi_simplecode,
	bg.gi_brandsid,
	bg.gi_skuid,
	bg.gi_purchase,
	bg.gi_addtime,
	bg.gi_updatetime,
	bg.gi_class,
	bg.gi_class_id,
	bg.gi_oc_id,
	bg.gi_tid,
	bg.gi_taobao_id,
	bg.gi_attribute_ids,
	bg.gi_attribute_parentids,
	bu.ut_name AS gi_unit,
	bu.ut_id AS gi_unit_id,
	ol_pm,
	ol_box_num,
	(
		SELECT
			fd.al_vo
		FROM
			pos_allocation fd WITH (NOLOCK) 
		WHERE
			fd.al_id = (
				SELECT
					MAX (fd.all_al_id)
				FROM
					pos_allocationList fd WITH (NOLOCK) 
				WHERE
					fd.all_add_time = jt.ol_source_add_time
			)
	) AS al_vo,
	 supplyprice,
	 discount,
	 (case when supplyprice=0 then 0 else CONVERT(decimal(9,2), (ol_costprice/supplyprice)) end ) as realitydiscount
FROM
	dbo.vi_j_outStorageList AS jt
INNER JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON jt.ol_siid = bg.gi_id
LEFT JOIN dbo.b_unit AS bu  WITH (NOLOCK) ON bg.gi_unit = bu.ut_id
go

