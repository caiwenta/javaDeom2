CREATE VIEW [dbo].[vi_j_moStorage_and_detail] AS 
SELECT jt.mo_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.j_moStorage                  AS jt
       INNER JOIN dbo.j_moStorageList   AS jt1
            ON  jt.mo_id = jt1.mol_mo_id
       INNER JOIN dbo.b_goodsinfo  AS bg
            ON  jt1.mol_gi_id = bg.gi_id
WHERE  (jt.mo_status <> 0)
       AND (jt1.mol_status = 1)
go

