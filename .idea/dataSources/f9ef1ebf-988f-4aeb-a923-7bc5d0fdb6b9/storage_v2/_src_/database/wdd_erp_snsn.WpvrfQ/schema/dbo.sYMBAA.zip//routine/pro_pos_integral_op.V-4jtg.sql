




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pro_pos_integral_op]
@in_id int output,
@in_score int,
@in_discount_money decimal(10,2),
@in_remark varchar(50),
@in_add_man int,
@in_add_time datetime,
@in_update_man int,
@in_update_time datetime,
@in_status int,
@in_cp_id int=0,
@in_di_id int=0,
@in_erp_id int=0,
--操作类型(1:添加 2:修改 3:删除)
@op_type Int=0,
@outResult int Output
AS
BEGIN
	IF @op_type=1
    Begin
	INSERT INTO [pos_integral](
	[in_score],[in_discount_money],[in_remark],[in_add_man],[in_add_time],[in_update_man],[in_update_time],[in_status],[in_cp_id],[in_di_id],in_erp_id
	)VALUES(
	@in_score,@in_discount_money,@in_remark,@in_add_man,@in_add_time,@in_update_man,@in_update_time,@in_status,@in_cp_id,@in_di_id,@in_erp_id
	)
	SET @in_id = SCOPE_IDENTITY()
	END
	
	IF @op_type=2 AND @in_id>0
    Begin
   UPDATE [pos_integral] SET 
	[in_score] = @in_score,[in_discount_money] = @in_discount_money,[in_remark] = @in_remark,[in_update_man] = @in_update_man,[in_update_time] = @in_update_time,[in_status] = @in_status
	WHERE in_id=@in_id 
    END
    
    IF @op_type=3 AND @in_id>0
    Begin
    UPDATE [pos_integral] SET 
	[in_status] = @in_status
	WHERE in_id=@in_id 
    END
    
    if @@error<>0 
begin 
	set @outResult=0;
end
else 
begin
   set @outResult=@in_id;
end
  Return @outResult;
END
go

