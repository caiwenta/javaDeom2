CREATE VIEW [dbo].[vi_pos_inStorage_audit_Search]
AS
SELECT  in_sh_id AS sh_id ,
        in_erp_id AS erp_id ,
        (CASE WHEN in_vo LIKE 'CKTH%' THEN (-inl_num)
              ELSE inl_num
         END) AS inl_num_search ,
        (CASE WHEN in_vo LIKE 'CKTH%' THEN (-inl_money)
              ELSE inl_money
         END) AS inl_money_search ,
        (CASE WHEN in_vo LIKE 'CKTH%' THEN (-inl_money_do)
              ELSE inl_money_do
         END) AS inl_money_do_search ,
        *
FROM    vi_pos_inStorageList_audit_group_goods el
INNER JOIN (SELECT  jis.in_id ,
                    in_vo ,
                    CONVERT (VARCHAR(10),in_date,120) AS in_date ,
                    in_no ,
                    in_erp_id ,
                    in_st_id ,
                    in_shop_id AS in_sh_id ,
                    in_type ,
				    in_supplier,
                    in_supplier_id ,
					in_supplier_code_txt as in_supplier_id_code , 
					in_supplier_id_txt ,
                    in_man ,
                    (CASE WHEN in_pos_audit_man > 0 THEN 2
                          ELSE 1
                     END) AS in_status ,
                    (SELECT sei_name
                     FROM   dbo.b_storageinfo AS bs WITH (NOLOCK)
                     WHERE  (sei_id = jis.in_st_id)
                    ) AS in_st_id_txt ,
                    (SELECT sh_name
                     FROM   dbo.pos_shop AS bs WITH (NOLOCK)
                     WHERE  (sh_id = jis.in_shop_id)
                    ) AS in_sh_id_txt ,
                    (SELECT sh_company
                     FROM   pos_shop AS bs WITH (NOLOCK)
                     WHERE  (sh_id = jis.in_shop_id)
                    ) AS sh_company ,
                    (CASE WHEN in_type = 1 THEN in_supplier + '出库'
                          ELSE in_supplier + '调拨'
                     END) AS in_sourse ,
                    (SELECT si_name
                     FROM   dbo.b_stafftinfo AS bs WITH (NOLOCK)
                     WHERE  (si_id = jis.in_man)
                    ) AS in_order_man_txt ,
                    in_man AS in_order_man ,
                    (SELECT si_name
                     FROM   dbo.b_stafftinfo AS bs WITH (NOLOCK)
                     WHERE  (si_id = jis.in_add_man)
                    ) AS in_add_man_txt ,
                    in_add_man ,
                    in_add_time ,
                    (SELECT si_name
                     FROM   dbo.b_stafftinfo AS bs WITH (NOLOCK)
                     WHERE  (si_id = jis.in_update_man)
                    ) AS in_update_man_txt ,
                    in_update_man ,
                    in_update_time ,
                    (SELECT si_name
                     FROM   dbo.b_stafftinfo AS bs WITH (NOLOCK)
                     WHERE  (si_id = jis.in_audit_man)
                    ) AS in_audit_man_txt ,
                    in_audit_man ,
                    in_audit_time ,
                    in_remark ,
                    in_pos_audit_man ,
                    in_pos_audit_time
            FROM    dbo.vi_pos_inStorage_audit AS jis WITH (NOLOCK)
           ) eo ON el.inl_in_id = eo.in_id AND el.inl_type = eo.in_type
go

