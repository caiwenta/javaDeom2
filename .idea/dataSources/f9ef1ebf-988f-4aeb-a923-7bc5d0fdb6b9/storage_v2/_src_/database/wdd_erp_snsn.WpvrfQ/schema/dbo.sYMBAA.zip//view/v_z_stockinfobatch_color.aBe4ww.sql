CREATE VIEW [dbo].[v_z_stockinfobatch_color] 
	AS 

SELECT  ss.si_id color_order_id, 
        --仓库信息
        ss.si_seiid AS sid,
        bs.sei_id,
        bs.sei_name,
        bs.sei_is_tb,
        bs.sei_cp_id AS cp_id,
        bs.sei_erp_id AS erp_id, 
        
        '' AS specname,
        
        --商品信息
        bg.gi_id,                             
        ss.si_giid AS gid,
        ss.sl_color_id,--颜色id
        ISNULL((SELECT TOP 1 colorname FROM b_goodsruleset b WHERE b.gi_id=ss.si_giid AND colorid=ss.sl_color_id ),'无') AS color,   
        bg.gi_skus, 
        bg.gi_skuid, 
        bg.gi_name, 
        bg.gi_code, 
        bg.gi_barcode, 
        bg.gi_shortname, 
        bg.gi_simplecode, 
        (STUFF((SELECT ', '+ga_barcode 
                FROM b_goodsarcode bs 
                WHERE bs.gi_id=bg.gi_id AND bs.ga_erp_id=bg.gi_erp_id FOR XML PATH('')), 1, 1, ''))multiple_codes,--一品多码
        bg.gi_unit, 
        bu.ut_name, 
        bg.gi_type, 
        bg.gi_grade, 
        bg.gi_norm, 
        bg.gi_status, 
        bg.gi_remark,
        bg.gi_entrydate, 
        bg.si_img, 
        bg.gi_alarmstock, 
        bg.gi_category,
        (SELECT si_name FROM b_stafftinfo WHERE si_id=bg.gi_buyingteamid) AS gi_buyingteam, --买手小组
        bg.gi_sampleno,--样品号
		ISNULL((SELECT TOP 1 b.gs_sampleno 
				FROM b_goodsruleset b 
				WHERE b.gi_id=ss.si_giid AND colorid=ss.sl_color_id),bg.gi_sampleno) AS gs_sampleno,--规格样品号
        bg.gi_number, 
        bg.gi_typeone, 
        bg.gi_types,
        bg.gi_typesid, 
        bg.gi_brands, 
        bg.gi_brandsid, 
        bg.gi_class, 
        bg.gi_class_id,
        bg.gi_updatetime,
        bg.gi_oc_id, 
        bg.gi_tid, 
        bg.gi_taobao_id, 
        bg.gi_add_man, 
        bg.gi_add_time, 
        bg.gi_update_man, 
        bg.gi_update_time,
        bg.gi_cp_id, 
        bg.gi_seiid, 
        bg.gi_seiname, 
        bg.gi_di_id,  
        bg.gi_is_tb, 
        bg.gi_attribute_ids,
        bg.gi_attribute_parentids, 
        bg.gi_purchase_discount,
        --生产
        bg.gi_shelflife, 
        bg.gi_addtime, --商品添加时间
        ss.si_indate AS addtime, 
        bg.gi_virtual, --虚拟库存
        bg.gi_upstock, --上限库存
        bg.gi_downstork, --下限库存
        bg.gi_weight, --总重量
        
        bg.gi_importprices, --销售价
        bg.gi_retailprice gs_marketprice, --零售价
        bg.gi_costprice gs_costprice,--获取日报表的成本价
        bg.gi_purchase gs_purchase, --进货价
        (SELECT gd_price FROM b_goods_discount WHERE gd_gi_id=bg.gi_id AND gd_class=2 AND gd_type=1) AS a_price, --A供货价
        (gi_retailprice*ss.si_number) AS gi_retailprice_money,--零售金额
                               
        ss.si_number AS gnum,--库存数量
        --(CASE WHEN (ss.si_number - ISNULL(val.all_num, 0)) < 0 THEN 0 ELSE (ss.si_number - ISNULL(val.all_num, 0))END) AS all_num,
        ISNULL(ss.si_occupy_num,0)+ISNULL(ss.si_allocationoccupy_num,0)+ISNULL(ss.si_orderblankoccupy_num,0) AS take_up_num,--占用库存
        ISNULL(ss.si_number-(ISNULL(ss.si_occupy_num,0)+ISNULL(ss.si_allocationoccupy_num,0)+ISNULL(ss.si_orderblankoccupy_num,0)),0) AS enable_stock_num,--可用库存
                                                                                                                                                          
        si_pm AS pm, --配码 
        sl_boxbynum as boxbynum,--数量/箱 
        (case when isnull(sl_boxbynum,0)=0 then 0 else ceiling(si_number/sl_boxbynum) end) as box_num--箱数
                                                                                                     
FROM b_stockinfobatchMergeColorSum  AS ss WITH (NOLOCK) 
INNER JOIN dbo.b_storageinfo  AS bs WITH (NOLOCK) ON  ss.si_seiid = bs.sei_id and ss.si_status<>0  
INNER JOIN dbo.b_goodsinfo AS bg WITH (NOLOCK) ON  ss.si_giid = bg.gi_id and bg.gi_status<>0 
LEFT JOIN dbo.b_unit AS bu WITH (NOLOCK) ON  bg.gi_unit = bu.ut_id 
--LEFT OUTER JOIN (  
--	SELECT ogl_gi_id,al_st_id,ogl_sku_id,al_cp_id,SUM(all_num) AS all_num 
--	FROM dbo.vi_stockList_Allocation WITH (NOLOCK) 
--	WHERE  (al_cp_id > 0) 
--	GROUP BY ogl_gi_id,ogl_gi_id,al_st_id,ogl_sku_id,al_cp_id
--) AS val 
--ON ss.si_giid = val.ogl_gi_id AND ss.si_seiid = val.al_st_id 
go

