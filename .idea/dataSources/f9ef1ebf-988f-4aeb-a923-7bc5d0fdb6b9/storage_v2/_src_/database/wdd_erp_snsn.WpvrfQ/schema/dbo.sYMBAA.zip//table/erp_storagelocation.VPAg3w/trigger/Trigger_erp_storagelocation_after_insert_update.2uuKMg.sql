
CREATE TRIGGER [dbo].[Trigger_erp_storagelocation_after_insert_update]
    ON [dbo].[erp_storagelocation]
    AFTER DELETE, INSERT, UPDATE
    AS
    BEGIN
        
      UPDATE    erp_storagelocation
      SET       slt_lastdate =GETDATE()
      FROM      erp_storagelocation es ,
                (SELECT slt_id 
                 FROM   DELETED
                ) del
      WHERE     es.slt_id = del.slt_id;
    END
go

