
CREATE View [dbo].[vi_pos_storageInfo_sei_is_net]
		as
SELECT MAX(bs.sei_id) AS sei_id,bs.sei_sh_id
  FROM pos_storageInfo bs WITH (NOLOCK)  WHERE bs.sei_status=1
AND bs.sei_is_net=1
GROUP BY bs.sei_sh_id
go

