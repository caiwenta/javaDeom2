CREATE view [dbo].[v_z_ogStorage_detail]
as



select 
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gs_id,
rulenum.gd_row_number,
oglist.*
from 
(


select 
isnull(grl.gss_no,'') as gss_no,--规格编码,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group2)='颜色' then grl.rulename2 else grl.rulename1  end),'无') as color,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=grl.group1)='尺码' then  grl.rulename1 else  grl.rulename2 end),'无') as spec,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then rule2 else rule1 end),0) as size,
--isnull((case when(select gs_remark from dbo.s_goodsrule where gs_id=group2)='尺码' then group2 else group1 end),0) as specid,
isnull(grl.colorname,'无') as color,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,

og.* 
from
(




SELECT
ge.og_id,
ogl_og_id,
st.ogl_id,
ge.og_cp_id,
ge.og_erp_id ,
ge.og_erp_id  as erp_id,

ge.og_vo,--凭证号
ge.og_no,--单据号
ge.og_date,--订货日期
ge.og_out_date,--交货日期
(case ge.og_type when 1 then '订货' when 2 then '补货' when 3 then '铺货' else '买断' end) as typename,
gi.gi_id,
st.ogl_gi_id,
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode,--商品条形码



isnull(ci.ci_name,'') as ci_name,--客户
isnull(ci.ci_code,'') as ci_code,--客户代号
ci.ci_name as og_ci_id_txt,--客户
ci.ci_code as og_ci_code_txt,--客户代号

ISNULL(ps.sh_name,'') as  og_sh_id_txt,
ISNULL(ps.sh_name,'') as sh_name,--店铺
ISNULL(ps.sh_no,'') as sh_no,--店铺代号

cp.cp_name as og_to_cp_id_txt,--公司
ISNULL(cp.cp_name,'') as cp_name,--分公司
ISNULL(cp.cp_code,'') as cp_code,--分公司代号

og_type,--交易方式

ui.ut_name,--单位
ui.ut_name as gi_unit,--单位


isnull(st.ogl_retail_price,0) as ogl_retail_price,--零售价
isnull(st.ogl_discount,0) as ogl_discount,--折率
isnull(st.ogl_stock_price,0) as ogl_stock_price,--供货价
isnull(st.ogl_money,0) as ogl_money,--订货金额
isnull(st.ogl_retail_money,0) as ogl_retail_money,--零售金额
isnull(st.ogl_box_num,0) as ogl_box_num,--箱数

og_status,--状态
og_trans,--运输方式
og_business_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = og_business ),--业务员
og_order_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =og_order_man),--经手人
ogl_add_time,--单据商品添加时间 
og_add_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = og_add_man) ,--添加人
og_add_time,--添加时间
og_update_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = og_update_man ),--修改人
og_update_time,--修改时间
og_is_lock,--是否锁定折扣与供货价不能改
og_audit_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = og_audit_man ),--审核人
og_audit_time,--审核时间
og_remark,--备注
ogl_pm,--配码
 isnull(st.ogl_num,0) as num,--规格数量
isnull(st.ogl_num,0) as ogl_num1,
isnull(st.ogl_num,0) as ogl_num,--数量
isnull((SELECT   sum(pll_num) FROM j_purchaseStorageList je where 
je.pll_source_id=st.ogl_id AND je.pll_status<>0 ),0) AS ogl_num_ed,
ISNULL((
			SELECT
				pll_num
			FROM
			
(select SUM(pll_num) AS pll_num ,pll_source_id,pll_status FROM j_purchaseStorageList WHERE pll_source_id!=0 GROUP BY pll_source_id,pll_status) AS jp
			WHERE
			
			jp.pll_status > 0 
		
			AND jp.pll_source_id = st.ogl_id

),0) AS pl_num, --采购数量
                --
           ISNULL((
			SELECT
				all_num
			FROM
			
(select SUM(all_num) AS all_num ,all_source_id,all_status FROM pos_allocationList WHERE all_source_id!=0 GROUP BY all_source_id,all_status) AS jp
			WHERE
			
			jp.all_status > 0 
		
			AND jp.all_source_id = st.ogl_id

),0) AS al_num,--配货数量
                --
               isnull(st.ogl_num,0)-ISNULL((
			SELECT
				all_num
			FROM
			
(select SUM(all_num) AS all_num ,all_source_id,all_status FROM pos_allocationList WHERE all_source_id!=0 GROUP BY all_source_id,all_status) AS jp
			WHERE
			
			jp.all_status > 0 
		
			AND jp.all_source_id = st.ogl_id

),0) AS al_num_do,--未配货数量

 isnull(st.ogl_pause_num_pll,0) AS ogl_pause_num_pll, --终止数量

 isnull(st.ogl_pause_num,0) AS ogl_pause_num,


 isnull(st.ogl_num,0)-ISNULL((
			SELECT
				pll_num
			FROM
			
(select SUM(pll_num) AS pll_num ,pll_source_id,pll_status FROM j_purchaseStorageList WHERE pll_source_id!=0 GROUP BY pll_source_id,pll_status) AS jp
			WHERE
			
			jp.pll_status > 0 
		
			AND jp.pll_source_id = st.ogl_id

),0)-isnull(st.ogl_pause_num_pll,0) AS pl_num_do,
st.ogl_sku_id
FROM  pos_ogStorage ge
inner join  pos_ogStorageList st ON ge.og_id = ogl_og_id AND st.ogl_status = 1 and ge.og_status<>0
left join b_goodsinfo gi on gi.gi_id=st.ogl_gi_id and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 
left join b_clientinfo ci on ci.ci_id= ge.og_ci_id and ci.ci_status=1
left join pos_shop ps on ps.sh_id=ge.og_sh_id
left join companyinfo cp on cp.cp_id= ge.og_to_cp_id

) as og
left join b_goodsruleset as grl on  grl.gss_id=og.ogl_sku_id

) as oglist
left join s_goodsruledetail rulenum on gd_id= oglist.size
go

