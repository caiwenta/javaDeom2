CREATE VIEW [dbo].[vi_j_purchaseStorageList_og_group_goods] AS 
SELECT fd.*,
	   --已入库数量
       ISNULL(fd2.el_number, 0)  AS el_number,
       --未入库数量
       (pll_num -ISNULL(fd2.el_number, 0)) AS wrk_num,
       --同上
       (pll_num -ISNULL(fd2.el_number, 0)) AS pll_num_rk
FROM   (
           SELECT jt.pl_source,
                  jt.pl_source_id,
                  jt.pll_source_add_time,
                  jt.pll_pl_id,
                  jt.pll_gi_id,
                  jt.pll_num,
                  jt.pll_stock_price,
                  jt.pll_retail_price,
                  jt.pll_discount,
                  jt.pll_money,
                  jt.pll_id,
                  jt.pll_sku_id,
                  CONVERT(VARCHAR(100), jt.pll_add_time, 25) 
                  AS pll_add_time,
                  jt.pll_pm,
                  jt.pll_box_num,
                  pll_status,
                  bg.gi_id,
                  bg.gi_shortname,
                  bg.gi_name,
                  bg.gi_type,
                  bg.gi_code,
                  bg.gi_grade,
                  bg.gi_norm,
                  bg.gi_status,
                  bg.gi_remark,
                  bg.gi_entrydate,
                  bg.si_img,
                  bg.gi_skus,
                  bg.gi_alarmstock,
                  bg.gi_barcode,
                  bg.gi_brands,
                  bg.gi_category,
                  bg.gi_costprice,
                  bg.gi_downstork,
                  bg.gi_importprices,
                  bg.gi_number,
                  bg.gi_retailprice,
                  bg.gi_seiid,
                  bg.gi_seiname,
                  bg.gi_typeone,
                  bg.gi_types,
                  bg.gi_typesid,
                  bg.gi_upstock,
                  bg.gi_virtual,
                  bg.gi_weight,
                  bg.gi_simplecode,
                  bg.gi_brandsid,
                  bg.gi_skuid,
                  bg.gi_purchase,
                  bg.gi_addtime,
                  bg.gi_updatetime,
                  bg.gi_class,
                  bg.gi_class_id,
                  bg.gi_oc_id,
                  bg.gi_tid,
                  bg.gi_taobao_id,
                  bu.ut_name AS gi_unit
           FROM   vi_j_purchaseStorageList_og AS jt
                  INNER JOIN dbo.b_goodsinfo AS bg
                       ON  jt.pll_gi_id = bg.gi_id
                  INNER JOIN dbo.b_unit AS bu
                       ON  bg.gi_unit = bu.ut_id
       )                         AS fd
       LEFT JOIN vi_j_purchaseStorageList_entered AS fd2
            ON  fd.pll_pl_id = fd2.eo_source_id
            AND fd.pll_gi_id = fd2.el_siid
            AND fd.pll_add_time = fd2.el_source_add_time
go

