CREATE VIEW [dbo].[vi_j_AllocationList_sum]
	AS 
select 
(
SELECT SUM(isnull(all_box_num,0)) FROM (
Select (case when isnull(fd.all_boxbynum,0)=0 then 0 else ceiling(sum(fd.all_num)/fd.all_boxbynum) end) as all_box_num
From pos_AllocationList fd where fd.all_status=1 AND fd.all_al_id=je.all_al_id
GROUP BY fd.all_gi_id,isnull(fd.all_pm,''),fd.all_boxbynum
) AS BB
) AS el_boxnum,
je.all_al_id,

SUM (all_pause_num) as all_pause_num,
Sum(je.all_num) As all_num,
Sum(je.all_money) As all_money
 
From pos_AllocationList je where je.all_status=1 
Group By je.all_al_id
go

