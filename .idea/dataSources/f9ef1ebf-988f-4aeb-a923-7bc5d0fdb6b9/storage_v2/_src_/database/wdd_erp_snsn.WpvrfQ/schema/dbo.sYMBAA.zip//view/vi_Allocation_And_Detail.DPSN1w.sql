CREATE VIEW [dbo].[vi_Allocation_And_Detail] AS 
SELECT al.al_id,
       bg.gi_name,
       bg.gi_code
FROM   dbo.pos_allocation                 AS al
       INNER JOIN dbo.pos_allocationList  AS al1
            ON  al.al_id = al1.all_al_id
            AND al1.all_status = 1 AND al.al_status <> 0
       INNER JOIN dbo.b_goodsinfo    AS bg
            ON  al1.all_gi_id = bg.gi_id
go

