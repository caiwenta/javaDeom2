CREATE PROC [dbo].[pro_j_purchaseStorageList_sku_search_tb]
@pll_pl_id INT = 0,
@pll_add_time DATETIME = '2004-10-17',
@gi_id INT,
@do_type INT=0,
@cp_id INT = 0,
@gss_no VARCHAR(30) ='',
@pll_pm varchar(500)='',
@colorid INT=0
AS
DECLARE @lsj DECIMAL(9, 2) = 0;
DECLARE @countBox INT = 0;

SELECT TOP 1 @countBox = el_box_num
FROM   dbo.j_enterStorage AS fd
       INNER JOIN dbo.j_enterStorageList AS fd2
            ON  fd.eo_id = fd2.el_eoid
            AND fd.eo_source_type = 1
            AND fd.eo_source_id = @pll_pl_id
            AND fd2.el_status = 1
            AND fd.eo_status <> 0
            AND fd.eo_type = 0
            AND el_box_num > 0
GROUP BY
       el_box_num

IF @gss_no != ''
BEGIN
    SELECT @gi_id = bg.gi_id
    FROM   b_goodsruleset bg
    WHERE  bg.gss_no = @gss_no
END

IF @do_type=0
BEGIN
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p  --采购数量
FROM   b_goodsruleset AS bg
       LEFT JOIN (
       	
       	
				
				SELECT 
				* 
				FROM j_purchaseStorageList jt 
				WHERE jt.pll_pl_id=@pll_pl_id
                AND jt.pll_gi_id=@gi_id AND jt.pll_pm = @pll_pm
				 
                       
            )AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;
	
END
ELSE IF @do_type=1 OR @do_type=2    --未入库数量
BEGIN
SELECT 
(case when pllnum>0 then pllnum else 0 end) as pll_num,
bg.*,p1.*,bg2.gi_name,bg2.gi_code 
INTO #p1
FROM   b_goodsruleset AS bg
       LEFT JOIN (
       	
       	SELECT pll_pl_id, 
       			pll_gi_id, 
       			pll_sku_id, 
       			pll_add_time, 
       			pll_pause_num, 
       		   (pll_num-abs(ISNULL(fd.el_number,0)))-isnull(pll_pause_num,0) AS pllnum,
       			pll_id, 
       			pll_stock_price, 
       			pll_discount, 
       			pll_money, 
       			pll_retail_price, 
       			pll_status, 
       			pll_pm, 
				(ISNULL(jisl.pll_box_num,0)-ISNULL(fd.el_box_num,0)-ISNULL(jisl.pll_pause_box_num,0)) as pll_box_num,
				pll_integral,
                pll_totalintegral
       			 FROM (
       					SELECT  
       					pll_pl_id, 
       					pll_gi_id, 
       					pll_sku_id, 
       					pll_add_time, 
       					pll_pause_num, 
       					pll_num,
       					pll_id, 
       					pll_stock_price, 
       					pll_discount, 
       					pll_money, 
       					pll_retail_price, 
       					pll_status, 
       					pll_pm, 
       					pll_box_num ,
						pll_pause_box_num,
						pll_integral,
						pll_totalintegral
       					FROM j_purchaseStorageList jt WHERE jt.pll_pl_id=@pll_pl_id
						AND jt.pll_gi_id=@gi_id 
       			) AS jisl
             LEFT JOIN (
                SELECT 
					   SUM(aa.el_box_num) AS el_box_num,
                       aa.el_source_id,
                       SUM(aa.en_number)  AS el_number
                FROM  vi_purchase_entered aa
                GROUP BY el_source_id
			) fd
       ON 
       jisl.pll_id=fd.el_source_id
       WHERE  jisl.pll_pl_id = @pll_pl_id AND jisl.pll_pm = @pll_pm AND jisl.pll_add_time = @pll_add_time
         AND jisl.pll_gi_id=@gi_id
           AND jisl.pll_status = 1

            )                   AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id 
            LEFT JOIN b_goodsinfo bg2 
            ON bg.gi_id = bg2.gi_id
WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;

END
else if @do_type=3   --已入库数量
begin
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p2
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT jisl.pll_id,
                       jisl.pll_pl_id,
                       jisl.pll_gi_id,
                       jisl.pll_sku_id,
                       abs(fd.el_number) AS pll_num,
                       (ISNULL(fd.el_box_num,0)) as pll_box_num,
                       jisl.pll_integral,
					   jisl.pll_totalintegral,
                       jisl.pll_retail_price,
                       jisl.pll_discount,
                       jisl.pll_stock_price,
                       jisl.pll_money,
                       jisl.pll_status,
                       CONVERT(VARCHAR(100), @pll_add_time, 25) pll_add_time,
                       jisl.pll_source_id,
                       jisl.pll_source_add_time,
                       jisl.pll_cp_id,
                       jisl.pll_di_id,
                       jisl.pll_pm
                FROM   j_purchaseStorageList AS jisl
               LEFT JOIN (

              SELECT 
					   SUM(aa.el_box_num) AS el_box_num,
                       aa.el_source_id,
                       SUM(aa.en_number)  AS el_number
                FROM  vi_purchase_entered aa
                GROUP BY el_source_id
       ) fd
       ON jisl.pll_id=fd.el_source_id   
                WHERE  jisl.pll_pl_id = @pll_pl_id
                       AND jisl.pll_add_time = @pll_add_time AND jisl.pll_pm = @pll_pm
                       AND jisl.pll_status = 1
            )                   AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;
 
end
else if @do_type=4   --已退货
begin
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p4
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT jisl.pll_id,
                       jisl.pll_pl_id,
                       jisl.pll_gi_id,
                       jisl.pll_sku_id,
                       ISNULL(fd.el_number,0)              AS pll_num,
                       jisl.pll_retail_price,
                       jisl.pll_discount,
                       jisl.pll_stock_price,
                       jisl.pll_money,
                       jisl.pll_status,
                       CONVERT(VARCHAR(100), @pll_add_time, 25) pll_add_time,
                       jisl.pll_source_id,
                       jisl.pll_source_add_time,
                       jisl.pll_cp_id,
                       jisl.pll_di_id,
                       (ISNULL(fd.el_box_num,0)) as pll_box_num,
                       jisl.pll_pm
                FROM   j_purchaseStorageList AS jisl
				LEFT JOIN (
					 SELECT 
						   SUM(aa.el_box_num) AS el_box_num,
						   aa.el_source_id,
						   SUM(aa.en_number)  AS el_number
					FROM  vi_purchase_entered aa
					GROUP BY el_source_id
       ) fd ON  jisl.pll_id=fd.el_source_id   
                WHERE  jisl.pll_pl_id = @pll_pl_id
                       AND jisl.pll_add_time = @pll_add_time
                       AND jisl.pll_status = 1 AND jisl.pll_pm = @pll_pm
       ) AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;
 
end

else if @do_type=5--未退货
begin
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p5
FROM   b_goodsruleset AS bg
       LEFT JOIN (

                SELECT jisl.pll_id,
                       jisl.pll_pl_id,
                       jisl.pll_gi_id,
                       jisl.pll_sku_id,
                       ISNULL(jisl.pll_num,0)-ISNULL(fd.el_number,0) AS pll_num,
                       jisl.pll_retail_price,
                       jisl.pll_discount,
                       jisl.pll_stock_price,
                       jisl.pll_money,
                       jisl.pll_status,
                       CONVERT(VARCHAR(100), @pll_add_time, 25) pll_add_time,
                       jisl.pll_source_id,
                       jisl.pll_source_add_time,
                       jisl.pll_cp_id,
                       jisl.pll_di_id,
                       (ISNULL(jisl.pll_box_num,0)-ISNULL(fd.el_box_num,0)) as pll_box_num,
                       jisl.pll_pm
                FROM   j_purchaseStorageList AS jisl
                LEFT JOIN (
					SELECT 
						   SUM(aa.el_box_num) AS el_box_num,
						   aa.el_source_id,
						   SUM(aa.en_number)  AS el_number
					FROM  vi_purchase_entered aa
					GROUP BY el_source_id
				 ) fd
				ON  jisl.pll_id=fd.el_source_id
                WHERE  jisl.pll_pl_id = @pll_pl_id
                       AND jisl.pll_add_time = @pll_add_time
                       AND jisl.pll_status = 1 AND jisl.pll_pm = @pll_pm

            )                   AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;
 
end
else if @do_type=6   --终止
begin
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p6
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT jisl.pll_id,
                       jisl.pll_pl_id,
                       jisl.pll_gi_id,
                       jisl.pll_sku_id,
                       jisl.pll_pause_num AS pll_num,
                       jisl.pll_retail_price,
                       jisl.pll_discount,
                       jisl.pll_stock_price,
                       jisl.pll_money,
                       jisl.pll_status,
                       CONVERT(VARCHAR(100), @pll_add_time, 25) pll_add_time,
                       jisl.pll_source_id,
                       jisl.pll_source_add_time,
                       jisl.pll_cp_id,
                       jisl.pll_di_id,
                       jisl.pll_pause_box_num as pll_box_num,
                       jisl.pll_pm
                FROM   j_purchaseStorageList AS jisl
                              
        WHERE  jisl.pll_pl_id = @pll_pl_id AND jisl.pll_add_time = @pll_add_time AND jisl.pll_status = 1
          )  AS p1 ON  bg.gi_id = p1.pll_gi_id AND bg.gss_id = p1.pll_sku_id 
	   LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  (CASE WHEN  @colorid>0 THEN bg.colorid ELSE 0 END)=@colorid AND bg.gi_id = @gi_id;
 



end
--分公司时设置零售价为吊牌价
IF @cp_id != 0
BEGIN

if EXISTS(SELECT c.cp_goods_type FROM  companyinfo c WHERE  c.cp_id = @cp_id and cp_goods_type!=0)
	 begin
    SELECT @lsj = gd_price
    FROM   b_goods_discount
    WHERE  gd_gi_id = @gi_id
           AND gd_type IN (SELECT c.cp_goods_type
                           FROM   companyinfo c
                           WHERE  c.cp_id = @cp_id)
           AND gd_class = 1
    


    IF @do_type = 0
    BEGIN

        UPDATE #p
        SET    gs_marketprice = @lsj
        
        UPDATE #p
        SET    gs_purchase = gs_marketprice * gs_discount


    END
    ELSE 
    IF @do_type = 1 OR @do_type = 2
    BEGIN
        BEGIN
        	UPDATE #p1
        	SET    gs_marketprice = @lsj
        	
        	UPDATE #p1
        	SET    gs_purchase = gs_marketprice * gs_discount
        END
    END


	END

END


IF @do_type = 0
    SELECT *
    FROM   #p
ELSE 
IF @do_type = 1
   OR @do_type = 2
    SELECT *
    FROM   #p1
    
 else if @do_type=3
 select * from #p2
 else if @do_type=4
 select * from #p4
 else if @do_type=5
 select * from #p5
  else if @do_type=6
 select * from #p6
go

