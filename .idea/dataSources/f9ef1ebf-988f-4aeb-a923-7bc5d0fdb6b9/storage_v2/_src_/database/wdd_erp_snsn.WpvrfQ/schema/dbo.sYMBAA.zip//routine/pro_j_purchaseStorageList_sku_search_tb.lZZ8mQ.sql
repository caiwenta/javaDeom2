CREATE PROC [dbo].[pro_j_purchaseStorageList_sku_search_tb]
@pll_pl_id INT = 0,
@pll_add_time DATETIME = '2004-10-17',
@gi_id INT,
@do_type INT=0,
@cp_id INT = 0,
@gss_no VARCHAR(30) =''
AS
DECLARE @lsj DECIMAL(9, 2) = 0;
DECLARE @countBox INT = 0;

SELECT TOP 1 @countBox = el_box_num
FROM   dbo.j_enterStorage AS fd
       INNER JOIN dbo.j_enterStorageList AS fd2
            ON  fd.eo_id = fd2.el_eoid
            AND fd.eo_source_type = 1
            AND fd.eo_source_id = @pll_pl_id
            AND fd2.el_status = 1
            AND fd.eo_status <> 0
            AND fd.eo_type = 0
            AND el_box_num > 0
GROUP BY
       el_box_num

IF @gss_no != ''
BEGIN
    SELECT @gi_id = bg.gi_id
    FROM   b_goodsruleset bg
    WHERE  bg.gss_no = @gss_no
END

IF @do_type=0
BEGIN
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p  --采购数量
FROM   b_goodsruleset AS bg
       LEFT JOIN (
       	
       	
				
				SELECT * FROM vi_j_purchaseStorageList_pro_new jt WHERE jt.pll_pl_id=@pll_pl_id
                AND jt.pll_gi_id=@gi_id 
				 
                       
            )AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  bg.gi_id = @gi_id;
	
END
ELSE IF @do_type=1 OR @do_type=2    --未入库数量
BEGIN
	
SELECT 

(case when pllnum>0 then pllnum else 0 end) as pll_num,
bg.*,p1.*,bg2.gi_name,bg2.gi_code 
INTO #p1
FROM   b_goodsruleset AS bg
       LEFT JOIN (
       	
       	SELECT pll_pl_id, 
       			pll_gi_id, 
       			pll_sku_id, 
       			pll_add_time, 
       			pll_pause_num, 
       		   (pll_num-abs(ISNULL(fd.el_number,0)))-isnull(pll_pause_num,0) AS pllnum,
       			pll_id, 
       			pll_stock_price, 
       			pll_discount, 
       			pll_money, 
       			pll_retail_price, 
       			pll_status, 
       			pll_pm, 
       			pll_box_num,
				pll_integral,
                pll_totalintegral
       			 FROM (
       			SELECT  
       			pll_pl_id, 
       			pll_gi_id, 
       			pll_sku_id, 
       			pll_add_time, 
       			pll_pause_num, 
       		    pll_num,
       			pll_id, 
       			pll_stock_price, 
       			pll_discount, 
       			pll_money, 
       			pll_retail_price, 
       			pll_status, 
       			pll_pm, 
       			pll_box_num ,
				pll_integral,
                pll_totalintegral
       			FROM vi_j_purchaseStorageList_pro_new jt WHERE jt.pll_pl_id=@pll_pl_id
                AND jt.pll_gi_id=@gi_id 
       			) AS jisl
                
              
                
                       LEFT JOIN (
                SELECT 
			
                       aa.el_siid,
                       aa.el_source_add_time,
              
                       aa.el_skuid,
                       SUM(aa.en_number)  AS el_number
                FROM   (
                           SELECT *,
                                  (
                                      CASE jes.eo_type
                                           WHEN 1 THEN -jesl.el_number
                                           WHEN 0 THEN jesl.el_number
                                           ELSE 0
                                      END
                                  )en_number
                           FROM   j_enterStorage AS jes
                                  INNER JOIN j_enterStorageList 
                                  AS jesl
                                       ON  
                                       jes.eo_id = jesl.el_eoid
                           WHERE  jes.eo_status > 0
                                  AND jesl.el_status = 1
                                  AND jes.eo_source_type = 1
                       )                     aa
                GROUP BY
			
                       aa.el_siid,
                       aa.el_source_add_time,
              
                       aa.el_skuid
       ) fd
       ON 
       jisl.pll_gi_id=fd.el_siid
       AND
       jisl.pll_sku_id=fd.el_skuid

       AND jisl.pll_add_time=fd.el_source_add_time   
       WHERE  jisl.pll_pl_id = @pll_pl_id
                       
                       AND jisl.pll_gi_id=@gi_id
                       AND jisl.pll_status = 1
            )                   AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id 
            LEFT JOIN b_goodsinfo bg2 
            ON bg.gi_id = bg2.gi_id
WHERE  bg.gi_id = @gi_id;

END
else if @do_type=3   --已入库数量
begin
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p2
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT jisl.pll_id,
                       jisl.pll_pl_id,
                       jisl.pll_gi_id,
                       jisl.pll_sku_id,
                       
                       
                       abs(fd.el_number) AS pll_num,
                       
                       jisl.pll_integral,
					   jisl.pll_totalintegral,
                       jisl.pll_retail_price,
                       jisl.pll_discount,
                       jisl.pll_stock_price,
                       jisl.pll_money,
                       jisl.pll_status,
                       CONVERT(VARCHAR(100), @pll_add_time, 25) pll_add_time,
                       jisl.pll_source_id,
                       jisl.pll_source_add_time,
                       jisl.pll_cp_id,
                       jisl.pll_di_id,
                       
                       ( jisl.pll_box_num-ISNULL(fd.el_box_num,0)) as pll_box_num,
                       jisl.pll_pm
                FROM   j_purchaseStorageList AS jisl
                
                
                       LEFT JOIN (
                SELECT aa.eo_source_id,
                       aa.el_siid,
                       aa.el_source_add_time,
                       aa.el_box_num,
                       SUM(aa.en_number)  AS el_number,aa.el_source_id
                FROM   (
                           SELECT *,
                                  (
                                      CASE jes.eo_type
                                           WHEN 1 THEN -jesl.el_number
                                           WHEN 0 THEN jesl.el_number
                                           ELSE 0
                                      END
                                  )en_number
                           FROM   j_enterStorage AS jes
                                  INNER JOIN j_enterStorageList 
                                  AS jesl
                                       ON  
                                       jes.eo_id = jesl.el_eoid
                           WHERE  jes.eo_status > 0
                                  AND jesl.el_status = 1
                                  AND jes.eo_source_type = 1
                       )                     aa
                GROUP BY
                       aa.eo_source_id,
                       aa.el_siid,
                       aa.el_source_add_time,aa.el_source_id,aa.el_box_num
       ) fd
       ON jisl.pll_pl_id=fd.eo_source_id
       AND
       jisl.pll_gi_id=fd.el_siid
       AND
       jisl.pll_add_time=fd.el_source_add_time
       
         AND jisl.pll_id=fd.el_source_id                   
                            
                WHERE  jisl.pll_pl_id = @pll_pl_id
                       AND jisl.pll_add_time = @pll_add_time
                       AND jisl.pll_status = 1
            )                   AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  bg.gi_id = @gi_id;
 
end
else if @do_type=4   --已退货
begin
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p4
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT jisl.pll_id,
                       jisl.pll_pl_id,
                       jisl.pll_gi_id,
                       jisl.pll_sku_id,
                       
                       

                      
                       ISNULL(
           ( 
SELECT  sum(fd2.el_number)  AS el_number
               FROM   dbo.j_enterStorage AS fd
                      INNER JOIN dbo.j_enterStorageList AS fd2
                           ON  fd.eo_id = fd2.el_eoid
                           AND fd.eo_source_type = 1
                           AND fd.eo_source_id = jisl.pll_pl_id
                           AND fd2.el_status = 1
                           AND fd.eo_status <> 0
                           AND fd.eo_type = 1
													 AND fd2.el_siid=jisl.pll_gi_id
													 AND fd2.el_skuid=jisl.pll_sku_id
           ),
           0
       )                           AS pll_num

,

                       jisl.pll_retail_price,
                       jisl.pll_discount,
                       jisl.pll_stock_price,
                       jisl.pll_money,
                       jisl.pll_status,
                       CONVERT(VARCHAR(100), @pll_add_time, 25) pll_add_time,
                       jisl.pll_source_id,
                       jisl.pll_source_add_time,
                       jisl.pll_cp_id,
                       jisl.pll_di_id,
                     
                       ( jisl.pll_box_num-ISNULL(fd.el_box_num,0)) as pll_box_num,
                       jisl.pll_pm
                FROM   j_purchaseStorageList AS jisl
                
                
                       LEFT JOIN (
                SELECT aa.eo_source_id,
                       aa.el_siid,
                       aa.el_source_add_time,
                       aa.el_box_num,
                       SUM(aa.en_number)  AS el_number,aa.el_source_id
                FROM   (
                           SELECT *,
                                  (
                                      CASE jes.eo_type
                                           WHEN 1 THEN -jesl.el_number
                                           WHEN 0 THEN jesl.el_number
                                           ELSE 0
                                      END
                                  )en_number
                           FROM   j_enterStorage AS jes
                                  INNER JOIN j_enterStorageList 
                                  AS jesl
                                       ON  
                                       jes.eo_id = jesl.el_eoid
                           WHERE  jes.eo_status > 0
                                  AND jesl.el_status = 1
                                  AND jes.eo_source_type = 1
                       )                     aa
                GROUP BY
                       aa.eo_source_id,
                       aa.el_siid,
                       aa.el_source_add_time,aa.el_source_id,aa.el_box_num
       ) fd
       ON jisl.pll_pl_id=fd.eo_source_id
       AND
       jisl.pll_gi_id=fd.el_siid
       AND
       jisl.pll_add_time=fd.el_source_add_time
       
         AND jisl.pll_id=fd.el_source_id                   
                            
                WHERE  jisl.pll_pl_id = @pll_pl_id
                       AND jisl.pll_add_time = @pll_add_time
                       AND jisl.pll_status = 1
            )                   AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  bg.gi_id = @gi_id;
 
end

else if @do_type=5--未退货
begin
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p5
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT jisl.pll_id,
                       jisl.pll_pl_id,
                       jisl.pll_gi_id,
                       jisl.pll_sku_id,
                       
                       
             
                     jisl.pll_num- ISNULL(
           ( 
SELECT  sum(fd2.el_number)  AS el_number
               FROM   dbo.j_enterStorage AS fd
                      INNER JOIN dbo.j_enterStorageList AS fd2
                           ON  fd.eo_id = fd2.el_eoid
                           AND fd.eo_source_type = 1
                           AND fd.eo_source_id = jisl.pll_pl_id
                           AND fd2.el_status = 1
                           AND fd.eo_status <> 0
                           AND fd.eo_type = 1
													 AND fd2.el_siid=jisl.pll_gi_id
													 AND fd2.el_skuid=jisl.pll_sku_id
           ),
           0
       )                           AS pll_num

,

                       jisl.pll_retail_price,
                       jisl.pll_discount,
                       jisl.pll_stock_price,
                       jisl.pll_money,
                       jisl.pll_status,
                       CONVERT(VARCHAR(100), @pll_add_time, 25) pll_add_time,
                       jisl.pll_source_id,
                       jisl.pll_source_add_time,
                       jisl.pll_cp_id,
                       jisl.pll_di_id,
                     
                       ( jisl.pll_box_num-ISNULL(fd.el_box_num,0)) as pll_box_num,
                       jisl.pll_pm
                FROM   j_purchaseStorageList AS jisl
                
                
                       LEFT JOIN (
                SELECT aa.eo_source_id,
                       aa.el_siid,
                       aa.el_source_add_time,
                       aa.el_box_num,
                       SUM(aa.en_number)  AS el_number,aa.el_source_id
                FROM   (
                           SELECT *,
                                  (
                                      CASE jes.eo_type
                                           WHEN 1 THEN -jesl.el_number
                                           WHEN 0 THEN jesl.el_number
                                           ELSE 0
                                      END
                                  )en_number
                           FROM   j_enterStorage AS jes
                                  INNER JOIN j_enterStorageList 
                                  AS jesl
                                       ON  
                                       jes.eo_id = jesl.el_eoid
                           WHERE  jes.eo_status > 0
                                  AND jesl.el_status = 1
                                  AND jes.eo_source_type = 1
                       )                     aa
                GROUP BY
                       aa.eo_source_id,
                       aa.el_siid,
                       aa.el_source_add_time,aa.el_source_id,aa.el_box_num
       ) fd
       ON jisl.pll_pl_id=fd.eo_source_id
       AND
       jisl.pll_gi_id=fd.el_siid
       AND
       jisl.pll_add_time=fd.el_source_add_time
       
         AND jisl.pll_id=fd.el_source_id                   
                            
                WHERE  jisl.pll_pl_id = @pll_pl_id
                       AND jisl.pll_add_time = @pll_add_time
                       AND jisl.pll_status = 1
            )                   AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  bg.gi_id = @gi_id;
 
end
else if @do_type=6   --终止
begin
SELECT bg.*,p1.*,bg2.gi_name,bg2.gi_code INTO #p6
FROM   b_goodsruleset AS bg
       LEFT JOIN (
                SELECT jisl.pll_id,
                       jisl.pll_pl_id,
                       jisl.pll_gi_id,
                       jisl.pll_sku_id,
                       
                       
                        fd.pll_pause_num AS pll_num,
                       
                       
                       jisl.pll_retail_price,
                       jisl.pll_discount,
                       jisl.pll_stock_price,
                       jisl.pll_money,
                       jisl.pll_status,
                       CONVERT(VARCHAR(100), @pll_add_time, 25) pll_add_time,
                       jisl.pll_source_id,
                       jisl.pll_source_add_time,
                       jisl.pll_cp_id,
                       jisl.pll_di_id,
                        '' as pll_box_num,
                    
                       jisl.pll_pm
                FROM   j_purchaseStorageList AS jisl
                
                
                       LEFT JOIN (
                SELECT     pll_pl_id, pll_gi_id, pll_add_time, pll_source_add_time, SUM(pll_pause_num) AS pll_pause_num, SUM(pll_num) AS pll_num, MIN(pll_id) AS pll_id, MAX(pll_sku_id) AS pll_sku_id, 
                      CONVERT(DECIMAL(10, 2), AVG(pll_stock_price)) AS pll_stock_price, MAX(pll_discount) AS pll_discount, SUM(pll_money) AS pll_money, CONVERT(DECIMAL(10, 2), AVG(pll_retail_price)) 
                      AS pll_retail_price, MAX(pll_status) AS pll_status, MAX(REPLACE(pll_pm, '*', ',')) AS pll_pm, MAX(pll_box_num) AS pll_box_num
FROM         dbo.j_purchaseStorageList AS jt
GROUP BY pll_pl_id, pll_gi_id, pll_add_time, pll_source_add_time,pll_id
                
                
                
       ) fd
       ON jisl.pll_pl_id=fd.pll_pl_id
       AND
       jisl.pll_gi_id=fd.pll_gi_id
     
       
         AND jisl.pll_id=fd.pll_id                   
                            
                WHERE  jisl.pll_pl_id = @pll_pl_id
                       AND jisl.pll_add_time = @pll_add_time
                       AND jisl.pll_status = 1
            )                   AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id LEFT JOIN b_goodsinfo bg2 ON bg.gi_id = bg2.gi_id
WHERE  bg.gi_id = @gi_id;
 



end
--分公司时设置零售价为吊牌价
IF @cp_id != 0
BEGIN

if EXISTS(SELECT c.cp_goods_type FROM  companyinfo c WHERE  c.cp_id = @cp_id and cp_goods_type!=0)
	 begin
    SELECT @lsj = gd_price
    FROM   b_goods_discount
    WHERE  gd_gi_id = @gi_id
           AND gd_type IN (SELECT c.cp_goods_type
                           FROM   companyinfo c
                           WHERE  c.cp_id = @cp_id)
           AND gd_class = 1
    


    IF @do_type = 0
    BEGIN

        UPDATE #p
        SET    gs_marketprice = @lsj
        
        UPDATE #p
        SET    gs_purchase = gs_marketprice * gs_discount


    END
    ELSE 
    IF @do_type = 1 OR @do_type = 2
    BEGIN
        BEGIN
        	UPDATE #p1
        	SET    gs_marketprice = @lsj
        	
        	UPDATE #p1
        	SET    gs_purchase = gs_marketprice * gs_discount
        END
    END


	END

END


IF @do_type = 0
    SELECT *
    FROM   #p
ELSE 
IF @do_type = 1
   OR @do_type = 2
    SELECT *
    FROM   #p1
    
 else if @do_type=3
 select * from #p2
 else if @do_type=4
 select * from #p4
 else if @do_type=5
 select * from #p5
  else if @do_type=6
 select * from #p6
go

