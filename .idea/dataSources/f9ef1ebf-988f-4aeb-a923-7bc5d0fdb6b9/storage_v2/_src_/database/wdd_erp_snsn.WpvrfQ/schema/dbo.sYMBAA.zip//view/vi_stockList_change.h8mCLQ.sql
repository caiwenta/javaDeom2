/*select
[sid], gid, skuid, gnum=case when vi_stockList.countType=1 then gnum else -gnum end, countType, myremark, addtime,
vi_stockList.order_date,vi_stockList.order_add_time,
bg.*,bg2.gss_no,orderno,bg2.gs_name,bs.sei_name
  FROM vi_stockList LEFT JOIN b_goodsinfo AS bg ON gid=bg.gi_id LEFT JOIN b_goodsruleset AS bg2 ON skuid=bg2.gss_id
  left join b_storageinfo as bs on [sid]=bs.sei_id
WHERE addtime IS NOT NULL AND skuid IS not null
order by vi_stockList.addtime,vi_stockList.order_date
and mytype!=7
and mytype!=8*/
CREATE VIEW dbo.vi_stockList_change
AS
SELECT     fd_2.sid, fd_2.cid, fd_2.gid, fd_2.mytype, fd_2.orderno, fd_2.order_date, fd_2.order_add_time, fd_2.cp_id, fd_2.addtime, fd_2.myremark, fd_2.gnum, fd_2.gi_id, fd_2.gi_shortname, fd_2.gi_name, 
                      fd_2.gi_type, fd_2.gi_code, fd_2.gi_grade, fd_2.gi_norm, fd_2.gi_status, fd_2.gi_remark, fd_2.gi_entrydate, fd_2.gi_unit, fd_2.si_img, fd_2.gi_skus, fd_2.gi_alarmstock, fd_2.gi_barcode, 
                      fd_2.gi_brands, fd_2.gi_category, fd_2.gi_costprice, fd_2.gi_downstork, fd_2.gi_importprices, fd_2.gi_number, fd_2.gi_retailprice, fd_2.gi_seiid, fd_2.gi_seiname, fd_2.gi_typeone, fd_2.gi_types, 
                      fd_2.gi_typesid, fd_2.gi_upstock, fd_2.gi_virtual, fd_2.gi_weight, fd_2.gi_simplecode, fd_2.gi_brandsid, fd_2.gi_skuid, fd_2.gi_purchase, fd_2.gi_class, fd_2.gi_class_id, fd_2.gi_addtime, 
                      fd_2.gi_updatetime, fd_2.gi_oc_id, fd_2.gi_tid, fd_2.gi_taobao_id, fd_2.gi_add_man, fd_2.gi_add_time, fd_2.gi_update_man, fd_2.gi_update_time, fd_2.gi_cp_id, fd_2.gi_di_id, fd_2.gi_attribute_ids, 
                      fd_2.gi_is_tb, fd_2.gi_attribute_parentids, fd_2.gi_purchase_discount, fd_2.sei_id, fd_2.sei_fid, fd_2.sei_itid, fd_2.sei_name, fd_2.sei_code, fd_2.sei_sianme, fd_2.sei_siid, fd_2.sei_phone, 
                      fd_2.sei_address, fd_2.sei_remark, fd_2.sei_default, fd_2.sei_status, fd_2.sei_add_man, fd_2.sei_add_time, fd_2.sei_update_man, fd_2.sei_update_time, fd_2.sei_cp_id, fd_2.sei_di_id, 
                      fd_2.sei_is_negative_inventory, fd_2.sei_is_info, fd_2.sei_is_tb, fd_2.sei_is_net, fd_2.oo_di_id, fd2.ord_no AS m_no
FROM         (SELECT     fd_1.sid, fd_1.cid, fd_1.gid, fd_1.mytype, fd_1.orderno, fd_1.order_date, fd_1.order_add_time, fd_1.cp_id, fd_1.addtime, fd_1.myremark, fd_1.gnum, bg.gi_id, bg.gi_shortname, 
                                              bg.gi_name, bg.gi_type, bg.gi_code, bg.gi_grade, bg.gi_norm, bg.gi_status, bg.gi_remark, bg.gi_entrydate, bg.gi_unit, bg.si_img, bg.gi_skus, bg.gi_alarmstock, bg.gi_barcode, 
                                              bg.gi_brands, bg.gi_category, bg.gi_costprice, bg.gi_downstork, bg.gi_importprices, bg.gi_number, bg.gi_retailprice, bg.gi_seiid, bg.gi_seiname, bg.gi_typeone, bg.gi_types, 
                                              bg.gi_typesid, bg.gi_upstock, bg.gi_virtual, bg.gi_weight, bg.gi_simplecode, bg.gi_brandsid, bg.gi_skuid, bg.gi_purchase, bg.gi_class, bg.gi_class_id, bg.gi_addtime, bg.gi_updatetime, 
                                              bg.gi_oc_id, bg.gi_tid, bg.gi_taobao_id, bg.gi_add_man, bg.gi_add_time, bg.gi_update_man, bg.gi_update_time, bg.gi_cp_id, bg.gi_di_id, bg.gi_attribute_ids, bg.gi_is_tb, 
                                              bg.gi_attribute_parentids, bg.gi_purchase_discount, bs.sei_id, bs.sei_fid, bs.sei_itid, bs.sei_name, bs.sei_code, bs.sei_sianme, bs.sei_siid, bs.sei_phone, bs.sei_address, 
                                              bs.sei_remark, bs.sei_default, bs.sei_status, bs.sei_add_man, bs.sei_add_time, bs.sei_update_man, bs.sei_update_time, bs.sei_cp_id, bs.sei_di_id, bs.sei_is_negative_inventory, 
                                              bs.sei_is_info, bs.sei_is_tb, bs.sei_is_net, fd2.oo_di_id
                       FROM          (SELECT     sid, cid, gid, mytype, orderno, order_date, order_add_time, cp_id, CONVERT(VARCHAR(100), addtime, 25) AS addtime, myremark, 
                                                                      SUM(CASE WHEN countType = 1 THEN gnum ELSE - gnum END) AS gnum
                                               FROM          dbo.vi_stockList AS fd
                                               GROUP BY sid, cid, gid, mytype, orderno, order_date, order_add_time, myremark, addtime, cp_id) AS fd_1 INNER JOIN
                                              dbo.b_goodsinfo AS bg ON fd_1.gid = bg.gi_id INNER JOIN
                                              dbo.b_storageinfo AS bs ON fd_1.sid = bs.sei_id LEFT OUTER JOIN
                                              dbo.j_outStorage AS fd2 ON fd_1.mytype = 2 AND fd_1.cp_id = fd2.oo_cp_id AND fd_1.orderno = fd2.oo_no) AS fd_2 LEFT OUTER JOIN
                      dbo.netorder_tbl AS fd2 ON fd_2.oo_di_id = fd2.ord_id
go

