
CREATE VIEW [dbo].[vi_j_initStorage] AS 
SELECT
    in_erp_id as erp_id,
	in_id,
	in_vo,
	in_erp_id,
	CONVERT (VARCHAR(10), in_date, 120) AS in_date,
	in_no,
	in_st_id,
	(
		SELECT
			bs.sei_name
		FROM
			b_storageinfo AS bs WITH (NOLOCK)
		WHERE
			bs.sei_id = in_st_id
	) AS in_st_id_txt,
	in_order_man,
	in_order_man_txt = (
		SELECT
			bs.si_name
		FROM
			b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			bs.si_id = in_order_man
	),
	in_add_man,
	in_add_man_txt = (
		SELECT
			bs.si_name
		FROM
			b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			bs.si_id = in_add_man
	),
	in_add_time,
	in_update_man,
	in_update_man_txt = (
		SELECT
			bs.si_name
		FROM
			b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			bs.si_id = in_update_man
	),
	in_update_time,
	in_audit_man,
	in_audit_man_txt = (
		SELECT
			bs.si_name
		FROM
			b_stafftinfo AS bs WITH (NOLOCK)
		WHERE
			bs.si_id = in_audit_man
	),
	in_audit_time,
	in_remark,
	in_status,
	in_cp_id,
	in_di_id,
	(
		SELECT
			SUM (inl_num)
		FROM
			j_initStorageList WITH (NOLOCK)
		WHERE
			jis.in_id = inl_in_id
		AND j_initStorageList.inl_status = 1
	) AS sumnum,
	(
		SELECT
			SUM (inl_money)
		FROM
			j_initStorageList WITH (NOLOCK)
		WHERE
			jis.in_id = inl_in_id
		AND j_initStorageList.inl_status = 1
	) AS summoney
FROM
	j_initStorage AS jis WITH (NOLOCK)
WHERE
	jis.in_status >0
go

