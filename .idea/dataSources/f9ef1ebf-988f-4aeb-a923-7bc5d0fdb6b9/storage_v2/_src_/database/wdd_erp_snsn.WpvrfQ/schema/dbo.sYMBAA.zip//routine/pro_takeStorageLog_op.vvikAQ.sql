CREATE PROC [dbo].[pro_takeStorageLog_op]
       @tsl_id INT = 0 ,--主键
       @tsl_st_id INT = 0 ,--仓库主键
       @tsl_erp_id INT = 0 ,
       @tsl_date DATETIME = '2014-11-03' ,--盘点日期
       @tsl_type INT = 0 ,--盘点类型　(1,整仓盘点:2,部分盘点)
       @tsl_add_man INT = 0 ,--添加人主键
       @tsl_add_time DATETIME = '2014-11-03' ,--添加时间
       @tsl_update_man INT = 0 ,--修改人主键
       @tsl_update_time DATETIME = '2014-11-03' ,--修改时间
       @tsl_del_man INT = 0 ,--删除人主键
       @tsl_del_time DATETIME = '2014-11-03' ,--删除时间
       @tsl_remark VARCHAR(50) = '' ,--备注
       @op_type VARCHAR(100) = '添加' ,  --操作类型 
       @negative_inventory INT = 0 ,--产生了负库存是否提示
       @result VARCHAR(100) = '' OUT ,--结果
       @tsl_cp_id INT = 0 ,--公司主键
       @tsl_di_id INT = 0--部门主键 
AS
BEGIN
      BEGIN TRAN
	
      IF @op_type = '添加'
         BEGIN
               IF EXISTS ( SELECT   1
                           FROM     j_takeStorageLog AS jt
                           WHERE    jt.tsl_status = 1
                                    AND jt.tsl_st_id = @tsl_st_id
                                    AND jt.tsl_date = @tsl_date )
                  BEGIN
                        SET @result = '当前日期与仓库已经存在盘点准备记录，不可重复操作！';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END
	    
               IF EXISTS ( SELECT   1
                           FROM     j_takeStorageLog AS jt
                           WHERE    jt.tsl_status = 1
                                    AND jt.tsl_st_id = @tsl_st_id )
                  BEGIN
                        SET @result = '当前仓库存在未完成的盘点单，请盘点完成再来进行操作！';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END
	    
               DECLARE @last_tsl_date DATETIME;
               
               SELECT TOP 1
                        @last_tsl_date = jtsl.tsl_date
               FROM     j_takeStorageLog AS jtsl
               WHERE    jtsl.tsl_status = 2
                        AND jtsl.tsl_st_id = @tsl_st_id
               ORDER BY jtsl.tsl_id DESC
	    
               DECLARE @last_tsl_date_var VARCHAR(50)= CONVERT(VARCHAR(50),@last_tsl_date,23);
               
               IF @tsl_date <= @last_tsl_date
                  BEGIN
                        SET @result = '盘点准备失败.<br/>最后一次的盘点日期为[' + @last_tsl_date_var + '],在' + @last_tsl_date_var + '之前的库存已锁定!<br/>';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END
	    
               INSERT   INTO j_takeStorageLog
                        (tsl_st_id ,
                         tsl_date ,
                         tsl_status ,
                         tsl_type ,
                         tsl_add_man ,
                         tsl_add_time ,
                         tsl_update_man ,
                         tsl_update_time ,
                         tsl_remark ,
                         tsl_cp_id ,
                         tsl_di_id ,
                         tsl_erp_id)
               VALUES   (@tsl_st_id ,
                         @tsl_date ,
                         1 ,
                         @tsl_type ,
                         @tsl_add_man ,
                         @tsl_add_time ,
                         @tsl_update_man ,
                         @tsl_update_time ,
                         @tsl_remark ,
                         @tsl_cp_id ,
                         @tsl_di_id ,
                         @tsl_erp_id);
               SET @tsl_id = SCOPE_IDENTITY();
         END
	
      IF @op_type = '修改'
         BEGIN
               IF NOT EXISTS ( SELECT   1
                               FROM     j_takeStorage AS jt
                               WHERE    (jt.ts_status = 1
                                         OR jt.ts_status = 2)
                                        AND jt.ts_st_id = @tsl_st_id
                                        AND jt.ts_take_date = @tsl_date )
                  BEGIN
                        SET @result = '没有相应的盘点单据!';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END
	    
               IF EXISTS ( SELECT   1
                           FROM     j_takeStorage AS jt
                           WHERE    jt.ts_status = 1
                                    AND jt.ts_st_id = @tsl_st_id
                                    AND jt.ts_take_date = @tsl_date )
                  BEGIN
                        SET @result = '存在未审核的盘点单据!';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END
	    
               IF NOT EXISTS ( SELECT   *
                               FROM     j_takeStorageLog AS jt
                               WHERE    jt.tsl_st_id = @tsl_st_id
                                        AND jt.tsl_date = @tsl_date
                                        AND jt.tsl_status = 1 )
                  BEGIN
                        SET @result = '没有处于盘点准备状态的盘点记录!<br/>1.盘点准备.2.盘点录入.3.库存确认.';
	        
                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END
	    
	    
               DECLARE @count INT = 0;
               
               SELECT   @count = COUNT(1)
               FROM     j_takeStorageLog AS jt
               WHERE    jt.tsl_st_id = @tsl_st_id
                        AND jt.tsl_date = @tsl_date
                        AND jt.tsl_status = 1;
                        
               IF @count > 1
                  BEGIN
                        SET @result = '存在多条的盘点准备记录!';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END	    
	    
               SELECT   @tsl_id = jt.tsl_id
               FROM     j_takeStorageLog AS jt
               WHERE    jt.tsl_st_id = @tsl_st_id
                        AND jt.tsl_date = @tsl_date
                        AND jt.tsl_status = 1;
	    	    

	    	    
			  IF (SELECT COUNT(*) FROM j_stocklog WHERE ISNULL(sl_location,0)>0 AND sl_seiid=@tsl_st_id AND sl_order_date<=@tsl_date)>0
			  BEGIN	
			  	 IF (SELECT COUNT(*) FROM j_takeStorageList WHERE tsl_ts_id=@tsl_id AND ISNULL(tsl_location,0)=0)>0
			  	 BEGIN	
			  	 	SET @result='存在仓位库存，不允许盘点数据仓位为空';
			  	 	
                    IF @@TRANCOUNT > 0
                       ROLLBACK TRAN;
                    RETURN 1;
			  	 END
			  END
	     
	     

               UPDATE   j_takeStorage
               SET      ts_tsl_id = @tsl_id
               WHERE    ts_st_id = @tsl_st_id
                        AND ts_take_date = @tsl_date
                        AND ts_status = 2;
	    	    
               DECLARE @ts_vo VARCHAR(50) = '';
               
               SELECT TOP 1
                        @ts_vo = jts.ts_vo
               FROM     j_takeStorage AS jts
               WHERE    jts.ts_tsl_id = @tsl_id
                        AND jts.ts_status > 0;
	    
               SET @tsl_update_time = GETDATE();
	    
               UPDATE  j_takeStorageLog
               SET      tsl_status = 2 ,
                        tsl_type = @tsl_type ,
                        tsl_update_man = @tsl_update_man ,
                        tsl_update_time = @tsl_update_time
               WHERE    tsl_id = @tsl_id;
	    
               SELECT  @tsl_add_time = jtsl.tsl_add_time
               FROM     j_takeStorageLog AS jtsl
               WHERE    jtsl.tsl_id = @tsl_id;

			   --整仓盘点
               IF @tsl_type = 1
                  BEGIN

						--获取当前没有盘点到的商品（注意实盘数为0）
                        INSERT  INTO j_stocklog_pal(
								 sl_seiid,
								 sl_location,
                                 sl_giid ,
                                 sl_skuid ,
                                 sl_counttype ,
                                 sl_number ,
								 sl_takenum,
                                 sl_addtime ,
                                 sl_remark ,
                                 sl_status ,
                                 sl_order_date ,
                                 sl_order_add_time ,
                                 sl_eoid ,
                                 sl_elid ,
                                 sl_ciid ,
                                 sl_type ,
                                 sl_order_no ,
                                 sl_cp_id ,
                                 sl_erp_id ,
                                 sl_pm,
								 sl_boxbynum,
								 sl_box_num
								 )
                                SELECT  p1.sl_seiid,
										p1.sl_location,
                                        p1.sl_giid ,
                                        p1.sl_skuid ,
                                        count_type = CASE WHEN p1.sl_number > 0 THEN 0
                                                          ELSE 1
                                                     END ,
                                        ABS(p1.sl_number),
										0,
                                        DATEADD(second,58,DATEADD(minute,59,DATEADD(hour,23,@tsl_date))) ,
                                        '整仓盘点盈亏调整' ,
                                        2 ,
                                        @tsl_date ,
                                        @tsl_add_time ,
                                        @tsl_id ,
                                        @tsl_id ,
                                        0 ,
                                        7 ,
                                        @ts_vo ,
                                        @tsl_cp_id ,
                                        @tsl_erp_id ,
                                        p1.sl_pm,
										p1.boxbynum,
										ABS(p1.box_num)
                                FROM    (
								         SELECT js.sl_seiid ,
										        ISNULL(js.sl_location,0) as sl_location,
                                                js.sl_giid ,
                                                js.sl_skuid ,
                                                ISNULL(js.sl_pm,'') AS sl_pm ,
                                                SUM(CASE WHEN js.sl_counttype = 1 THEN js.sl_number ELSE -js.sl_number END) AS sl_number,
												SUM( CASE WHEN js.sl_counttype = 1 THEN js.sl_box_num ELSE -js.sl_box_num END ) AS box_num,
												sl_boxbynum as boxbynum
                                         FROM   j_stocklog AS js
                                         WHERE  js.sl_seiid = @tsl_st_id
                                                AND (CONVERT(VARCHAR(50),js.sl_order_date,23) <= @tsl_date
                                                     OR js.sl_type = 3)
                                                AND js.sl_number != 0
                                                AND js.sl_status != 0
                                         GROUP BY 
										        js.sl_seiid ,
												ISNULL(js.sl_location,0),
                                                js.sl_giid ,
                                                js.sl_skuid ,
                                                ISNULL(js.sl_pm,''),
												js.sl_boxbynum
                                        ) AS p1 	  
										
                        INSERT  INTO j_stocklog(
								 sl_seiid ,
								 sl_location,
                                 sl_giid ,
                                 sl_skuid ,
                                 sl_counttype ,
                                 sl_number ,
                                 sl_addtime ,
                                 sl_remark ,
                                 sl_status ,
                                 sl_order_date ,
                                 sl_order_add_time ,
                                 sl_eoid ,
                                 sl_elid ,
                                 sl_ciid ,
                                 sl_type ,
                                 sl_order_no ,
                                 sl_cp_id ,
								 sl_erp_id ,
                                 sl_pm,
								 sl_boxbynum,
								 sl_box_num)
                                SELECT  p1.sl_seiid,
								        p1.sl_location,
                                        p1.sl_giid ,
                                        p1.sl_skuid ,
                                        count_type = CASE WHEN p1.sl_number > 0 THEN 0
                                                          ELSE 1
                                                     END ,
                                        ABS(p1.sl_number) ,
                                        DATEADD(second,58,DATEADD(minute,59,DATEADD(hour,23,@tsl_date))) ,
                                        '整仓盘点盈亏调整' ,
                                        2 ,
                                        @tsl_date ,
                                        @tsl_add_time ,
                                        @tsl_id ,
                                        @tsl_id ,
                                        0 ,
                                        7 ,
                                        @ts_vo ,
                                        @tsl_cp_id ,
										@tsl_erp_id ,
                                        p1.sl_pm,
										p1.boxbynum,
										ABS(p1.box_num)
                                FROM    (
								         SELECT js.sl_seiid,
										        ISNULL(js.sl_location,0) as sl_location,
                                                js.sl_giid ,
                                                js.sl_skuid ,
												js.sl_boxbynum as boxbynum,
                                                ISNULL(js.sl_pm,'') AS sl_pm ,
                                                SUM(CASE WHEN js.sl_counttype = 1 THEN js.sl_number ELSE -js.sl_number END) AS sl_number,
												SUM( CASE WHEN js.sl_counttype = 1 THEN js.sl_box_num ELSE -js.sl_box_num END ) AS box_num
                                         FROM   j_stocklog AS js
                                         WHERE  js.sl_seiid = @tsl_st_id
                                                AND (CONVERT(VARCHAR(50),js.sl_order_date,23) <= @tsl_date
                                                     OR js.sl_type = 3)
                                                AND js.sl_number != 0
                                                AND js.sl_status != 0
                                         GROUP BY 
										        js.sl_seiid ,
												ISNULL(js.sl_location,0),
                                                js.sl_giid ,
                                                js.sl_skuid ,
                                                ISNULL(js.sl_pm,''),
												sl_boxbynum
                                        ) AS p1
				         	
						--去掉当盘点订单商品	  
                        DELETE  FROM j_stocklog_pal
                        FROM    j_stocklog_pal fd ,
                                (
								 SELECT vtlo.tsl_gi_id ,
                                        tsl_sku_id ,
                                        ISNULL(vtlo.tsl_pm,'') AS tsl_pm,
										isnull(tsl_location,0) as tsl_location,
										tsl_boxbynum
                                 FROM   vi_take_list_ok AS vtlo
                                 WHERE  vtlo.tsl_id = @tsl_id
                                ) fd2
                        WHERE   fd.sl_eoid = @tsl_id
                                AND fd.sl_elid = @tsl_id
                                AND fd.sl_giid = fd2.tsl_gi_id
                                AND fd.sl_skuid = fd2.tsl_sku_id
                                AND ISNULL(fd.sl_pm,'') = ISNULL(fd2.tsl_pm,'')
								AND isnull(fd.sl_location,0)=ISNULL(fd2.tsl_location,0)
                                and fd.sl_boxbynum=fd2.tsl_boxbynum

                        DELETE  FROM j_stocklog
                        FROM    j_stocklog fd ,
                                (
								SELECT  vtlo.tsl_gi_id ,
                                        tsl_sku_id ,
                                        ISNULL(vtlo.tsl_pm,'') AS tsl_pm,
										isnull(tsl_location,0) as tsl_location,
										tsl_boxbynum
                                 FROM   vi_take_list_ok AS vtlo
                                 WHERE  vtlo.tsl_id = @tsl_id
                                ) fd2
                        WHERE   fd.sl_eoid = @tsl_id
                                AND fd.sl_elid = @tsl_id
                                AND fd.sl_giid = fd2.tsl_gi_id
                                AND fd.sl_skuid = fd2.tsl_sku_id
                                AND ISNULL(fd.sl_pm,'') = ISNULL(fd2.tsl_pm,'')
								AND isnull(fd.sl_location,0)=ISNULL(fd2.tsl_location,0)
								 and fd.sl_boxbynum=fd2.tsl_boxbynum
                  END

               DECLARE @now DATETIME = GETDATE();
			


			   --当前盘点订单实盘数据
               INSERT INTO j_stocklog
                        (
						 sl_seiid,
						 sl_location,
                         sl_ciid ,
                         sl_giid ,
                         sl_skuid ,
                         sl_number ,
                         sl_counttype ,
                         sl_remark ,
                         sl_order_no ,
                         sl_eoid ,
                         sl_elid ,
                         sl_type ,
                         sl_order_date ,
                         sl_order_add_time ,
                         sl_addtime ,
                         sl_updatetime ,
                         sl_status ,
                         sl_cp_id ,
                         sl_erp_id ,
                         sl_pm,
						 sl_boxbynum,
						 sl_box_num
						 )
                        SELECT  vt.ts_st_id ,
						        isnull(vt.tsl_location,0) as tsl_location,
                                cid = 0 ,
                                vt.tsl_gi_id ,
                                vt.tsl_sku_id ,
                                num = ABS(vt.tsl_logno) ,
                                count_type = CASE WHEN vt.tsl_logno > 0 THEN 1
                                                  ELSE 0
                                             END ,
                                remark = CASE WHEN vt.tsl_type = 1 THEN '整仓盘点盈亏调整'
                                              ELSE '部分盘点盈亏调整'
                                         END ,
                                orderno = vt.ts_vo ,
                                eoid = vt.tsl_id ,
                                elid = vt.tsl_id ,
                                mytype = CASE WHEN vt.tsl_type = 1 THEN 8
                                              WHEN vt.tsl_type = 2
                                                   AND vt.tsl_logno > 0 THEN 9
                                              WHEN vt.tsl_type = 2
                                                   AND vt.tsl_logno <= 0 THEN 10
                                         END ,
                                vt.ts_take_date ,
                                vt.tsl_add_time ,
                                DATEADD(second,59,DATEADD(minute,59,DATEADD(hour,23,@tsl_date))) ,
                                @now ,
                                1 ,
                                @tsl_cp_id ,
                                @tsl_erp_id ,
                                vt.tsl_pm,
								vt.tsl_boxbynum,
								ABS(vt.tsl_log_box_num) as log_box_num

                        FROM    vi_take_list_ok AS vt
                        WHERE   vt.tsl_id = @tsl_id
                                --AND vt.tsl_logno != 0;

               INSERT INTO j_stocklog_pal
                        (
						 sl_seiid ,
						 sl_location,
                         sl_ciid ,
                         sl_giid ,
                         sl_skuid ,
                         sl_number,
						 sl_takenum,
                         sl_counttype ,
                         sl_remark ,
                         sl_order_no ,
                         sl_eoid ,
                         sl_elid ,
                         sl_type ,
                         sl_order_date ,
                         sl_order_add_time ,
                         sl_addtime ,
                         sl_updatetime ,
                         sl_status ,
                         sl_cp_id ,
                         sl_erp_id ,
                         sl_pm,
						 sl_boxbynum,
						 sl_box_num)
                        SELECT  vt.ts_st_id ,
								isnull(vt.tsl_location,0) as tsl_location,
                                cid = 0 ,
                                vt.tsl_gi_id ,
                                vt.tsl_sku_id ,
                                num = ABS(vt.tsl_logno),
								tsl_newno,
                                count_type = CASE WHEN vt.tsl_logno > 0 THEN 1
                                                  ELSE 0
                                             END ,
                                remark = CASE WHEN vt.tsl_type = 1 THEN '整仓盘点盈亏调整'
                                              ELSE '部分盘点盈亏调整'
                                         END ,
                                orderno = vt.ts_vo ,
                                eoid = vt.tsl_id ,
                                elid = vt.tsl_id ,
                                mytype = CASE WHEN vt.tsl_type = 1 THEN 8
                                              WHEN vt.tsl_type = 2 AND vt.tsl_logno > 0 THEN 9
                                              WHEN vt.tsl_type = 2 AND vt.tsl_logno <= 0 THEN 10
                                         END ,
                                vt.ts_take_date ,
                                vt.tsl_add_time ,
                                DATEADD(second,59,DATEADD(minute,59,DATEADD(hour,23,@tsl_date))) ,
                                @now ,
                                1 ,
                                @tsl_cp_id ,
                                @tsl_erp_id ,
                                vt.tsl_pm,
								vt.tsl_boxbynum,
								ABS(vt.tsl_log_box_num) as log_box_num

                        FROM    vi_take_list_ok AS vt
                        WHERE   vt.tsl_id = @tsl_id

	         
			   EXEC pro_mergeStockLog_j_takeStorage
                @cp_id = @tsl_cp_id ,
                @negative_inventory = @negative_inventory ,
                @old_sei_id = @tsl_st_id,
				@new_sei_id = @tsl_st_id,
				@id=@tsl_id
               IF @@error <> 0
                  BEGIN
                        IF @@TRANCOUNT > 0
                           ROLLBACK TRANSACTION 
                        SET @result = '0';
                        RETURN 0;
                  END

               exec pro_mergesingleSums @orderid=@tsl_id,@stockType=11
         END
	
      IF @op_type = '修改为盘点准备状态'
         BEGIN
			   --检查负库存
               EXEC pro_mergeStockLog_check
                @cp_id = @tsl_cp_id ,
                @negative_inventory = @negative_inventory ,
                @old_sei_id = 0 ,
                @new_sei_id = 0

               IF @@ERROR != 0
                  BEGIN
                        DECLARE @ERROR_MESSAGE VARCHAR(100)= '';
                        SELECT  @ERROR_MESSAGE = ERROR_MESSAGE();
                        RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
                        RETURN;
                  END
               ELSE
                  BEGIN
                        DECLARE @tsl_status INT = 0;
                        DECLARE @tsl_date_max DATETIME;
	    
                        SELECT  @tsl_status = jtsl.tsl_status ,
                                @tsl_type = jtsl.tsl_type ,
                                @tsl_date = jtsl.tsl_date ,
                                @tsl_st_id = jtsl.tsl_st_id
                        FROM    j_takeStorageLog AS jtsl
                        WHERE   jtsl.tsl_id = @tsl_id;

                        IF @tsl_status = 2
                           BEGIN
                                 SELECT @tsl_date_max = MAX(jtsl.tsl_date)
                                 FROM   j_takeStorageLog AS jtsl
                                 WHERE  jtsl.tsl_st_id = @tsl_st_id
                                        AND jtsl.tsl_status = 1;

                                 IF @tsl_date_max != @tsl_date
                                    BEGIN
                                          SET @result = '该仓库，存在多张盘点单，只允许修改末次盘点记录！';

                                          IF @@TRANCOUNT > 0
                                             ROLLBACK TRAN;
                                          RETURN 0;
                                    END
	        
                                 SELECT @tsl_date_max = MAX(jtsl.tsl_date)
                                 FROM   j_takeStorageLog AS jtsl
                                 WHERE  jtsl.tsl_st_id = @tsl_st_id
                                        AND jtsl.tsl_status = 2;

                                 IF @tsl_date_max != @tsl_date
                                    BEGIN
                                          SET @result = '该仓库，存在多张盘点单，只允许修改末次盘点记录！';

                                          IF @@TRANCOUNT > 0
                                             ROLLBACK TRAN;
                                          RETURN 0;
                                    END
	        
                                 DELETE FROM j_stocklog_pal
                                 WHERE  sl_eoid = @tsl_id
                                        AND sl_elid = @tsl_id;

								 --DELETE 
								 --FROM   j_stocklog
								 --WHERE  sl_eoid = @tsl_id
								 --		AND sl_elid = @tsl_id;
	        
                                 UPDATE j_takeStorage
                                 SET    ts_status = 1 ,
                                        ts_tsl_id = NULL
                                 WHERE  ts_tsl_id = @tsl_id;
	        
                                 UPDATE j_takeStorageLog
                                 SET    tsl_status = 0
                                 WHERE  tsl_id = @tsl_id;


								  EXEC pro_mergeStockLog_j_takeStorage
									@cp_id = @tsl_cp_id ,
									@negative_inventory = @negative_inventory ,
									@old_sei_id = @tsl_st_id,
									@new_sei_id = @tsl_st_id,
									@id=@tsl_id
								IF @@error <> 0
								BEGIN
									IF @@TRANCOUNT > 0
										ROLLBACK TRANSACTION 
										SET @result = '0';
										RETURN 0;
								END

								exec pro_mergesingleSums @orderid=@tsl_id,@stockType=11

								 ----计算库存
         --                        EXEC pro_mergeStockLog
         --                           @cp_id = @tsl_cp_id ,
         --                           @negative_inventory = @negative_inventory ,
         --                           @old_sei_id = @tsl_st_id

         --                        IF @@error <> 0
         --                           BEGIN
         --                                 IF @@TRANCOUNT > 0
         --                                    ROLLBACK TRANSACTION 
         --                                 SET @result = '0';
         --                                 RETURN 0;
         --                           END
								 ----重新计算汇总批次库存，不按订单
         --                        EXEC pro_mergeStockSumBatchNumber
         --                           @cp_id = @tsl_cp_id
	
         --                        IF @@ERROR <> 0
         --                           BEGIN
         --                                 SET @result = '操作失败,库存锁定!';

         --                                 IF @@TRANCOUNT > 0
         --                                    ROLLBACK TRAN;
         --                                 RETURN 0;
         --                           END
	        



                                 UPDATE j_takeStorageLog
                                 SET    tsl_status = 1
                                 WHERE  tsl_id = @tsl_id;
                           END

                  END

         END
	
      IF @op_type = '删除'
         BEGIN
               SELECT   @tsl_st_id = jtsl.tsl_st_id ,
                        @tsl_date = jtsl.tsl_date
               FROM     j_takeStorageLog AS jtsl
               WHERE    jtsl.tsl_id = @tsl_id;

               IF EXISTS ( SELECT   1
                           FROM     j_takeStorage AS jts WITH (NOLOCK)
                           INNER JOIN j_takeStorageList jtsl WITH (NOLOCK) ON jts.ts_id = jtsl.tsl_ts_id
                           WHERE    jts.ts_st_id = @tsl_st_id
                                    AND jts.ts_take_date = @tsl_date
                                    AND jts.ts_status > 0
                                    AND jtsl.tsl_status > 0 )
                  BEGIN
                        SET @result = '删除失败,存在对应的盘点数据!';

                        IF @@TRANCOUNT > 0
                           ROLLBACK TRAN;
                        RETURN 1;
                  END
	    
               UPDATE   j_takeStorageLog
               SET      tsl_status = 0 ,
                        tsl_del_man = @tsl_del_man ,
                        tsl_del_time = @tsl_del_time
               WHERE    tsl_id = @tsl_id;
         END
	
      IF @@ERROR <> 0
         BEGIN
               SET @result = '0';

               IF @@TRANCOUNT > 0
                  ROLLBACK TRAN;
               RETURN 1;
         END
      ELSE
         BEGIN
               SET @result = CONVERT(VARCHAR(50),@tsl_id);
               IF @@TRANCOUNT > 0
                  COMMIT TRAN;
               RETURN 1;
         END
END
go

