CREATE VIEW [dbo].[v_z_pos_ogStorage_detail]
	AS 

SELECT  

'' AS specname,--暂时为空  
(CASE WHEN rulenum.gd_row_number IS NULL THEN '无' ELSE 'spec'+CONVERT(VARCHAR,rulenum.gd_row_number) END) AS spec2,
rulenum.gd_row_number,
rulenum.gd_code AS sizecode,--尺码代号
purchaselist.*

FROM   
(
SELECT  
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=isnull(grl.colorid,0))as colorcode,--颜色代号
ISNULL(grl.gss_no,'') AS gss_no,--规格编码
ISNULL(grl.colorname,'无') AS color,
ISNULL(grl.colorid,0)colorid,
ISNULL(grl.specname,'无') AS spec,
ISNULL(grl.specid,0) AS size,
ISNULL(grl.specngroupid,0) AS specid,
ISNULL(grl.gs_sampleno,gi_sampleno)gs_sampleno,--规格样品号
purchase.* 
from
(	
SELECT pos.og_id, 
       pos.og_vo, 
       pos.og_no, 
       pos.og_date, 
       pos.og_type, 
       pos.og_ci_id,
       pos.og_sh_id, 
       pos.og_out_date, 
       pos.og_trans, 
       pos.og_business,
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_business)) AS og_business_txt,--业务员名称
       pos.og_add_man, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_add_man)) AS og_add_man_txt,
       pos.og_add_time, 
       pos.og_update_man, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_update_man)) AS og_update_man_txt,
       pos.og_update_time,
       pos.og_audit_man, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_audit_man)) AS og_audit_man_txt,
       pos.og_audit_time, 
       pos.og_refe_no, 
       pos.og_order_man,
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_order_man)) AS og_order_man_txt,
       pos.og_is_lock, 
       pos.og_status, 
       pos.og_remark, 
       pos.og_ph_audit,
       pos.og_cg_audit, 
       pos.og_ph_audit_time, 
       pos.og_ph_audit_man,
       pos.og_cg_audit_time, 
       pos.og_cg_audit_man, 
       pos.og_cp_id, 
	   cp.cp_name,
	   cp.cp_code,
	   (SELECT ci_name FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id =pos.og_ci_id)) AS og_ci_id_txt,--客户名称
	   (SELECT ci_code FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS og_ci_code_txt,--客户代号

	   (SELECT sh_name FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS og_sh_id_txt,--店铺名称

       pos.og_di_id,
       pos.og_to_cp_id, 
	   (SELECT cp_name FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS og_to_cp_id_txt,--分公司名称

       pos.og_erp_id, 
       pos.og_source_id, 
       pos.og_source_type,
       pos.og_totalboxnum, 
       posl.ogl_id, 
       posl.ogl_og_id, 
       posl.ogl_gi_id,
       posl.ogl_sku_id, 
       posl.ogl_num, 
       posl.ogl_retail_price, 
       posl.ogl_stock_price,
       posl.ogl_money, 
       posl.ogl_retail_money, 
       posl.ogl_remark, 
       posl.ogl_status,
       posl.ogl_add_time, 
       posl.ogl_discount, 
       posl.ogl_erp_id, 
       posl.ogl_cspid,
       posl.ogl_boxbynum,
       posl.ogl_box_num, 
       posl.ogl_pm,
       posl.ogl_pause_num, 
       posl.ogl_pause_num_pll, 
       ISNULL((SELECT SUM(all_num)
               FROM pos_allocation WITH (NOLOCK) 
               INNER JOIN pos_allocationList  WITH (NOLOCK) ON al_id = all_al_id
               WHERE al_status > 0
                 AND all_status > 0
                 AND al_source = 5 
				 and al_type=1
                 AND all_source_id=posl.ogl_id),0)ogl_num_ed,--已配货数量
       ISNULL((SELECT SUM(pll_num)
               FROM j_purchaseStorage WITH (NOLOCK) 
               INNER JOIN j_purchaseStorageList  WITH (NOLOCK) ON pl_id = pll_pl_id
               WHERE pl_status > 0
               AND pll_status > 0
               AND pl_source = 1
               AND pll_source_id=posl.ogl_id),0)ogl_num_ed_pll,--已采购数量
			   
			   isnull(posl.ogl_pause_box_num_pll,0)aaogl_pause_box_num_pll,--采购终止箱数

	   ISNULL((SELECT SUM(ol_number)
	           FROM j_outStorageList  WITH (NOLOCK)
			   WHERE ol_topsource_id = ogl_id),0) AS ogl_num_ed_ol,--已发货数量
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_cratebox,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
       bg.gi_retailprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bg.gi_attribute_ids,
       bg.gi_attribute_parentids,
       bg.gi_sampleno,--样品号
       gi_unit gi_unit_id,
       (SELECT ut_name FROM b_unit WHERE ut_id=bg.gi_unit)gi_unit
FROM pos_ogStorage AS pos
INNER JOIN pos_ogStorageList AS posl ON pos.og_id=posl.ogl_og_id AND pos.og_status>0 AND posl.ogl_status>0
left JOIN b_goodsinfo bg ON bg.gi_id=posl.ogl_gi_id and gi_status=1
left join companyinfo cp on pos.og_cp_id=cp.cp_id and cp.cp_status>0

) AS purchase
LEFT JOIN b_goodsruleset AS grl ON grl.gss_id=purchase.ogl_sku_id

) AS purchaselist
LEFT JOIN s_goodsruledetail rulenum ON gd_id=purchaselist.size
go

