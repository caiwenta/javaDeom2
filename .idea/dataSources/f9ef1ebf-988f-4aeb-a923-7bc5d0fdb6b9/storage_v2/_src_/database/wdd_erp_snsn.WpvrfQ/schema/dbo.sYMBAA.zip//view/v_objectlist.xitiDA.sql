CREATE VIEW [dbo].[v_objectlist]
	AS 
	SELECT
		bc.ci_id,
		o_type=1,
		bc.ci_name,
		bc.ci_code, 
		isnull(bc.ci_qcje,0) AS ci_qcje,
		bc.ci_cp_id,
		bc.ci_erp_id,
		(case when bc.ci_status > 0 AND bc.ci_isdel > 0 then 1 else 0 end) as ci_status
	FROM b_clientinfo AS bc WITH (NOLOCK)
	UNION ALL
	SELECT
		bc.si_id,
		o_type=2,
		bc.si_name, 
		bc.si_code,
		isnull(bc.si_qcje,0) AS si_qcje,
		bc.si_cp_id,
		bc.si_erp_id,
		(case when bc.si_status > 0 AND bc.si_isdel > 0 then 1 else 0 end) as ci_status
	FROM b_supplierinfo AS bc WITH (NOLOCK)
	UNION ALL
	select 
		cp.cp_id,
		o_type=3,
		cp.cp_name,
		cp.cp_code,
		isnull(cp.cp_qcje,0) as cp_qcje,
		cp.cp_cp_id,
		cp.cp_erp_id,
		cp.cp_status
	from companyinfo as cp WITH (NOLOCK)
	UNION ALL
	--店铺
	SELECT 
		bs.sh_id,
		o_type=4,
		bs.sh_name,
		bs.sh_no,
		isnull(bs.sh_qcje,0)  AS sh_qcje,
		(SELECT TOP 1 cp_id FROM companyinfo AS c WHERE cp_erp_id=bs.sh_erp_id AND c.cp_is_zorf=1),
		bs.sh_erp_id,
		bs.status
	FROM pos_shop AS bs WITH (NOLOCK)
	UNION ALL
	--分公司的店铺
	SELECT 
		ps.sh_id,
		o_type=5,
		ps.sh_name shname,
		ps.sh_no,
		0  AS sh_qcje,
		c.cp_id,
		c.cp_erp_id,
		ps.status
	FROM pos_shop AS ps,companyinfo AS c
	WHERE ps.sh_erp_id=c.cp_erp_id  AND c.cp_is_zorf=2
go

