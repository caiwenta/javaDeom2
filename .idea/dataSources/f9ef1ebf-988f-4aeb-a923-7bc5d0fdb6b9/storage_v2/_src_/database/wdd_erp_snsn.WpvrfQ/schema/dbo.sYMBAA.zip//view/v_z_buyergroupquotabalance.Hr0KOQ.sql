CREATE VIEW [dbo].[v_z_buyergroupquotabalance]
	AS 

select 
a.*,
CONVERT(DECIMAL(8,2),(

(SELECT availablebalance FROM erp_buyergroupquota WHERE bg_cp_id=c.cp_id AND bq_date=a.bq_date)+
isnull(c.cp_quota,0)+
isnull((SELECT isnull(SUM(money),0) AS money FROM erp_buyergroupquotabyadjustment as jt WHERE jt.cp_id=c.cp_id AND jt.a_date<=a.bq_date AND jt.a_status=1 ),0)

 )/3) AS availablebalance
from (

SELECT 
MAX(bq_date) bq_date,
bg_cp_id,
bq_erpid
FROM erp_buyergroupquota AS bu
GROUP BY bg_cp_id,bq_erpid

) as a
INNER JOIN companyinfo AS c ON c.cp_id=a.bg_cp_id
go

