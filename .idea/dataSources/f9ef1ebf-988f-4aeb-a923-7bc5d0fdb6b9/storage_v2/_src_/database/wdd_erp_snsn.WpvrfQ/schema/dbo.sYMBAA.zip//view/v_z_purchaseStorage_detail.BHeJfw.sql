
CREATE VIEW [dbo].[v_z_purchaseStorage_detail]
AS

select 

'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
rulenum.gd_row_number,
rulenum.gd_code as sizecode,--尺码代号
purchaselist.*,
(isnull(pll_num,0)-isnull(pll_num_ed,0)-isnull(pll_pause_num1,0)) as  rk_el_number_do, --未入库数量
(isnull(pll_box_num,0)-isnull(pll_box_num_ed,0)-isnull(pll_pause_box_num,0))as rk_el_box_number_do--未入库箱数
from 
(
select 
(SELECT gd_code FROM s_goodsruledetail WHERE gd_id=isnull(grl.colorid,0))as colorcode,--颜色代号
isnull(grl.gss_no,'') as gss_no,--规格编码
isnull(grl.colorname,'无') as color,
isnull(grl.colorid,0)colorid,
isnull(grl.specname,'无') as spec,
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
isnull(grl.gs_sampleno,gi_sampleno)gs_sampleno,--规格样品号
purchase.* 
from
(

SELECT
ge.pzone,
ge.pl_cp_id,
cp.cp_name,
cp.cp_code,
ge.pl_status,
ge.pl_erp_id,
ge.pl_erp_id as erp_id,
st.pll_id,
st.pll_gi_id,
st.pll_pl_id,
ge.pl_id,  
(SELECT pos.og_vo FROM pos_ogStorage pos WHERE pos.og_id=(SELECT max(ogl_og_id) FROM pos_ogStorageList psl WITH (NOLOCK) WHERE psl.ogl_id=st.pll_source_id and psl.ogl_status=1)) as og_vo,
(SELECT top 1 ogl_og_id FROM pos_ogStorageList psl WITH (NOLOCK) WHERE psl.ogl_id=st.pll_source_id and psl.ogl_status=1) as og_id,
ge.pl_vo,--凭证号
ge.pl_no,--单据号
CONVERT(varchar(100), ge.pl_date, 23) as  pl_date,--采购日期
CONVERT(varchar(100), ge.pl_enddate, 23) as  pl_enddate,--预计交货日期
gi.gi_id,
gi.gi_skuid,
gi.gi_skus,
ge.pl_pltype,--退货
gi.gi_attribute_parentids,
gi.gi_attribute_ids,
gi.gi_typesid,
gi.gi_types,
gi.gi_type1,
gi.gi_type2,
gi.gi_type3,
gi.gi_type4,
(select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi.gi_type1)gi_typename1,
(select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi.gi_type2)gi_typename2,
(select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi.gi_type3)gi_typename3,
(select gc_name from s_goodsclass WITH (NOLOCK) WHERE gc_id=gi.gi_type4)gi_typename4,
gi.gi_sampleno,--样品号
gi.gi_code,--商品编号
gi.gi_name,--商品名称
gi.gi_barcode, --商品条形码
isnull((select top 1 relativeurl from b_goodspictures bgp where bgp.gi_id= gi.gi_id),'') as gi_relativeurl,--商品图像

st.pll_num as num,--规格数量
spi.si_name,--供应商
st.pll_pm,--配码
ge.pl_ci_id,
spi.si_name AS pl_ci_id_txt,--供应商
spi.si_code,--供应商代号
ui.ut_name,--单位
st.pll_sku_id,--skuid
ge.pl_remark,--单据状态

isnull(st.pll_num,0) as pll_num,--数量
isnull(st.pll_retail_price,0) as pll_retail_price ,--零售价
isnull(st.pll_discount,0) as pll_discount,--折率
isnull(st.pll_stock_price,0) as pll_stock_price,--进货价
isnull(st.pll_money,0) as pll_money,--采购金额
isnull(st.pll_boxbynum,0) as pll_boxbynum,--数量/箱
--(case when isnull(st.pll_boxbynum,0)=0 then 0 else ceiling(pll_num/pll_boxbynum) end) as pll_box_num,--箱数
isnull(st.pll_box_num,0) as pll_box_num,--箱数

(st.pll_num * st.pll_retail_price) AS pll_retail_money,--零售金额

ui.ut_name as gi_unit, --单位
pll_add_time, --商品添加时间
pl_order_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_order_man),--经手人
pl_add_man_txt=( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_add_man ),--单据添加人
pl_add_time,--单据添加时间
pl_update_man_txt=(SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id =pl_update_man),--单据修改人
pl_update_time,--单据修改时间
pl_audit_man_txt=	( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE si_id = pl_audit_man),--单据修改人
pl_audit_time, --单据审核时间

isnull((SELECT   sum(el_number) FROM j_enterStorageList jesl 
        INNER JOIN j_enterStorage AS jes ON  jes.eo_id = jesl.el_eoid
        WHERE jes.eo_status > 0 and jes.eo_source_type=1 and jesl.el_source_id=st.pll_id AND jesl.el_status<>0 ),0) AS pll_num_ed, --已入库数量
0 pll_box_num_ed,--已入库箱数

isnull(st.pll_pause_num,0) as pll_pause_num,
isnull(st.pll_pause_num,0) AS pll_pause_num1, --终止数量
isnull(st.pll_pause_box_num,0)pll_pause_box_num,--终止箱数

pl_type,  --采购方式,

(case when ge.pl_source=1 --来源为订单
then 
isnull((
 SELECT ci_name FROM b_clientinfo AS bs WITH (NOLOCK) WHERE ci_id = (select og_ci_id from pos_ogStorage where og_id=(SELECT top 1 ogl_og_id FROM pos_ogStorageList psl WITH (NOLOCK) WHERE psl.ogl_id=st.pll_source_id and psl.ogl_status=1) and og_ci_id>0
	 ) ),'') --客户名称
 end)as og_ci_id_txt,

 (case when ge.pl_source=1 --来源为订单
then 
isnull((  SELECT ci_code FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = (select og_ci_id from pos_ogStorage where og_id= (SELECT top 1 ogl_og_id FROM pos_ogStorageList psl WITH (NOLOCK) WHERE psl.ogl_id=st.pll_source_id and psl.ogl_status=1) and og_ci_id>0 )) 
),'')
end)AS og_ci_code_txt--客户代号

FROM   j_purchaseStorage ge
INNER join  j_purchaseStorageList st ON ge.pl_id = pll_pl_id AND st.pll_status = 1 and ge.pl_status>0
left join b_goodsinfo gi on gi.gi_id=st.pll_gi_id and gi_status=1
left join b_unit ui on ui.ut_id=gi.gi_unit 
left join b_supplierinfo spi on spi.si_id= ge.pl_ci_id and spi.si_status=1
left join companyinfo cp on ge.pl_cp_id=cp.cp_id and cp.cp_status>0

) as  purchase
left join b_goodsruleset  as grl on  grl.gss_id=purchase.pll_sku_id

) as purchaselist
left join s_goodsruledetail rulenum on gd_id=purchaselist.size
go

