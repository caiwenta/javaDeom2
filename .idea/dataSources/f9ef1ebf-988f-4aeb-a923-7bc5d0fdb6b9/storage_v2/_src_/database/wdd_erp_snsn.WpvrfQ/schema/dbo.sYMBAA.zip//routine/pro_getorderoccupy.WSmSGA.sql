CREATE PROCEDURE [dbo].[pro_getorderoccupy]
	@cp_id int,
	@sid INT,
	@gi_id INT,
	@skuid INT=0,
	@type VARCHAR(50)='node' --store  node
AS

begin

--配货单
SELECT
ge.al_vo,
sum((ISNULL(st.all_num, 0)-st.all_num_ed -ISNULL(st.all_pause_num, 0))) AS gnum
FROM pos_allocation ge 
inner join  pos_allocationList st ON ge.al_id = st.all_al_id AND ge.al_status>0 and st.all_status=1
WHERE ge.al_st_id=@sid AND ge.al_cp_id=@cp_id AND (ISNULL(st.all_num, 0)-st.all_num_ed -ISNULL(st.all_pause_num, 0))>0
AND st.all_gi_id=@gi_id and al_source not in (3,4) AND st.all_sku_id=(CASE WHEN @skuid>0 THEN @skuid ELSE st.all_sku_id END)
GROUP BY ge.al_vo,ge.al_id

UNION ALL

--区域移仓(需求通知)
SELECT 
ob.mo_vo,
sum(obl.mol_num)
FROM j_orderblank AS ob
INNER JOIN j_orderblanklist AS obl 
ON ob.mo_id=obl.mol_mo_id 
AND ob.mo_type=0 AND ob.mo_status=2 AND ob.mo_cp_id=@cp_id AND ob.mo_out_st_id=@sid and obl.mol_status=1
AND obl.mol_gi_id=@gi_id AND obl.mol_sku_id=(CASE WHEN @skuid>0 THEN @skuid ELSE  obl.mol_sku_id END)
GROUP BY ob.mo_vo,ob.mo_id

UNION ALL

--网络订单
SELECT 
ord_no,
number
FROM dbo.FuNetOrderOccupy(@type,@cp_id,@sid) AS fno
WHERE 
fno.gi_id=@gi_id AND fno.sku_id=(CASE WHEN @skuid>0 THEN @skuid ELSE  fno.sku_id END)


end
go

