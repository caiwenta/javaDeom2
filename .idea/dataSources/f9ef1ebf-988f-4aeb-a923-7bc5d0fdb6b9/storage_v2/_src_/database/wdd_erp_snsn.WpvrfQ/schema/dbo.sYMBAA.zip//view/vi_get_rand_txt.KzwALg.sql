CREATE VIEW [dbo].[vi_get_rand_txt] AS 
select (floor(rand()*25)+65) as rt
go

