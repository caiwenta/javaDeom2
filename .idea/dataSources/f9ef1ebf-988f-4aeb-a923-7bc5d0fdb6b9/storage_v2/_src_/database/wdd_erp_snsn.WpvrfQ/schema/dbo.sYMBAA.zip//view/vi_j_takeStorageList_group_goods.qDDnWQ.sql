


CREATE VIEW [dbo].[vi_j_takeStorageList_group_goods] AS 
select jt.tsl_ts_id,
       jt.tsl_gi_id,
       jt.tsl_old_num,
       jt.tsl_new_num,
       jt.tsl_log_num,
       jt.tsl_id,
       jt.tsl_sku_id,
	   convert(varchar(100),jt.tsl_pddate, 23) as tsl_pddate,
	   jt.tsl_shelflife,
	   convert(varchar(100),jt.tsl_expirationdate, 23) as tsl_expirationdate,

       convert(varchar(100), jt.tsl_add_time, 25) as tsl_add_time,
       jt.tsl_old_money, jt.tsl_new_money, jt.tsl_log_money,
       convert(decimal(10,2),jt.tsl_stock_price) as tsl_stock_price,
       CONVERT(varchar(100), jts.ts_take_date, 23)ts_take_date,
       jts.ts_st_id,
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
	   bg.gi_cratebox,
       bg.gi_retailprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bg.gi_attribute_ids,
       bg.gi_attribute_parentids,
       bu.ut_name                       as gi_unit
       
       ,tsl_box_num,tsl_pm
from   dbo.vi_j_takeStorageList         as jt
       INNER join dbo.b_goodsinfo  as bg
            on  jt.tsl_gi_id = bg.gi_id
       INNER join dbo.b_unit       as bu
            on  bg.gi_unit = bu.ut_id
	   INNER JOIN j_takeStorage AS jts
			ON jt.tsl_ts_id = jts.ts_id
go

