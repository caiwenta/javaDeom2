CREATE VIEW [dbo].[vi_j_Pos_OgStorage_pl_al_ol]
	AS 
--订单采购、配货、发货数量（按款）

SELECT pos.og_id, 
	   pos.og_vo, 
	   pos.og_no, 
	   CONVERT (VARCHAR(100), pos.og_date, 23) AS og_date,  --订货日期
	   CONVERT (VARCHAR(100), pos.og_out_date, 23) AS og_out_date, --交货日期
	   pos.og_type,  --交易方式(1,订货:2,补货:3,铺货:4,买断)
	   pos.og_ci_id,
	   (SELECT ci_name FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS og_ci_id_txt,--客户名称
	   (SELECT ci_code FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS og_ci_code_txt,--客户代号
	   (SELECT ci_province FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS ci_province,
	   (SELECT ci_city FROM b_clientinfo AS bs WITH (NOLOCK) WHERE (ci_id = pos.og_ci_id)) AS ci_city,
	   pos.og_sh_id,
	   (SELECT sh_name FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS og_sh_id_txt,--店铺名称
	   (SELECT sh_no FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS sh_no,
	   (SELECT province FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS sh_province,
	   (SELECT city FROM pos_shop AS bs WITH (NOLOCK) WHERE (sh_id = pos.og_sh_id)) AS sh_city,
	   pos.og_to_cp_id,
	   (SELECT cp_name FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS og_to_cp_id_txt,--分公司名称
	   (SELECT cp_code FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS cp_code,
	   (SELECT cp_province FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS cp_province,
	   (SELECT cp_city FROM companyinfo AS bs WITH (NOLOCK) WHERE (cp_id = pos.og_to_cp_id)) AS cp_city,
	   
	   pos.og_trans, --运输方式
	   pos.og_business, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_business)) AS og_business_txt,--业务员名称
	   pos.og_add_man, 
	   pos.og_add_time, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_add_man)) AS og_add_man_txt,
	   pos.og_update_man,
	   pos.og_update_time, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_update_man)) AS og_update_man_txt,
	   pos.og_audit_man, 
	   pos.og_audit_time, 
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_audit_man)) AS og_audit_man_txt,
	   pos.og_refe_no,  --参考单号
	   pos.og_order_man,
	   (SELECT si_name FROM b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = pos.og_order_man)) AS og_order_man_txt,
	   pos.og_is_lock, --是否锁定折率与供应价不能修改
	   pos.og_status, --状态(0,删除:1,可用:2,审核)
	   pos.og_remark, 
	   pos.og_cp_id,
	   pos.og_di_id,  
	   pos.og_erp_id, 
	   pos.og_source_id,
	   pos.og_source_type,
	   (SELECT re_vo FROM pos_reStorage prs WHERE prs.re_cp_id>0 AND re_id=pos.og_source_id) as re_vo,--来源凭证号
	   (SELECT TOP 1 al_id FROM pos_allocation WITH (NOLOCK) 
	    WHERE al_source_id = pos.og_id AND al_status > 0 AND al_source = 5
	    ORDER BY al_id) AS is_al_audited,--配货来源主键	                                            
	   (SELECT TOP 1 pl_id FROM j_purchaseStorage WITH (NOLOCK) 
	    WHERE pl_source_id = pos.og_id AND pl_status > 0 AND pl_source = 1
	    ORDER BY pl_id) AS is_pl_audited,--采购来源主键
	   pos.og_ph_audit,
	   pos.og_cg_audit,
       bg.gi_id,
       bg.gi_shortname,
       bg.gi_name,
       bg.gi_type,
       bg.gi_code,
       bg.gi_grade,
       bg.gi_norm,
       bg.gi_status,
       bg.gi_remark,
       bg.gi_cratebox,
       bg.gi_entrydate,
       bg.si_img,
       bg.gi_skus,
       bg.gi_alarmstock,
       bg.gi_barcode,
       bg.gi_brands,
       bg.gi_category,
       bg.gi_costprice,
       bg.gi_downstork,
       bg.gi_importprices,
       bg.gi_number,
       bg.gi_retailprice,
       bg.gi_seiid,
       bg.gi_seiname,
       bg.gi_typeone,
       bg.gi_types,
       bg.gi_typesid,
       bg.gi_upstock,
       bg.gi_virtual,
       bg.gi_weight,
       bg.gi_simplecode,
       bg.gi_brandsid,
       bg.gi_skuid,
       bg.gi_purchase,
       bg.gi_addtime,
       bg.gi_updatetime,
       bg.gi_class,
       bg.gi_class_id,
       bg.gi_oc_id,
       bg.gi_tid,
       bg.gi_taobao_id,
       bg.gi_attribute_ids,
       bg.gi_attribute_parentids,
       bg.gi_sampleno,--样品号
       gi_unit gi_unit_id,
       (SELECT ut_name FROM b_unit WHERE ut_id=bg.gi_unit)gi_unit,
       posl.*,
	   ogl_num sumnum,
	   ogl_money summoney,
	   ISNULL((ogl_num-pl_num-ogl_pause_num_pll),0)pl_num_do,--未采购数量=订货数量-采购数量-采购终止数量
       ISNULL((ogl_num-al_num-ogl_pause_num),0)al_num_do,--未配货数量=订货数量-配货数量-配货终止数量
       ISNULL((ogl_num-ol_num),0)ol_num_nodo--未发数量=订货数量-发货数量
FROM pos_ogStorage AS pos
LEFT JOIN 
         (
         	 SELECT ogl_og_id,
					ogl_gi_id,
					CONVERT(varchar(100), ogl_add_time, 21)ogl_add_time,
					MIN (ogl_id) AS ogl_id,
					MAX (ogl_sku_id) AS ogl_sku_id,
					SUM (ogl_money) AS ogl_money,
					SUM (ogl_retail_money) AS ogl_retail_money,
					CONVERT(DECIMAL (10, 2),AVG (ogl_retail_price)) AS ogl_retail_price,
					CONVERT (DECIMAL (10, 2),AVG (ogl_stock_price)) AS ogl_stock_price,
					CONVERT (DECIMAL (10, 2),AVG (ogl_discount)) AS ogl_discount,
					MAX (REPLACE(ogl_pm, '*', ',')) AS ogl_pm,
					(case when isnull(MAX (ogl_boxbynum),0)=0 then 0 else ceiling(SUM (ogl_num)/MAX (ogl_boxbynum)) end) AS ogl_box_num,   --数量
					ogl_boxbynum AS ogl_boxbynum, --数量/箱
					SUM (ogl_num) AS ogl_num,--订货数量
					SUM (pl_num) AS pl_num,--采购数量
					SUM (al_num) AS al_num,--配货数量
					SUM (ol_num) AS ol_num,--发货数量
					ISNULL (SUM (jt.ogl_pause_num_pll),0) AS ogl_pause_num_pll,--采购终止数量
					ISNULL (SUM (jt.ogl_pause_num),0) AS ogl_pause_num--配货终止数量
			 FROM
			(
			  SELECT *,
						ISNULL((SELECT SUM(pll_num)
								FROM j_purchaseStorage WITH (NOLOCK) 
								INNER JOIN j_purchaseStorageList  WITH (NOLOCK) ON pl_id = pll_pl_id
								WHERE pl_status > 0
								AND pll_status > 0
								AND pl_source = 1
								AND pll_source_id=ogl_id),0) AS pl_num,--采购数量	      
						   ISNULL((SELECT SUM(all_num)
								   FROM pos_allocation WITH (NOLOCK) 
								   INNER JOIN pos_allocationList  WITH (NOLOCK) ON al_id = all_al_id
								   WHERE al_status > 0
								   AND all_status > 0
								   AND al_source = 5
								   AND all_source_id=ogl_id),0) AS al_num,--配货数量
					   ISNULL((SELECT SUM(ol_number)
							   FROM j_outStorageList  WITH (NOLOCK)
							   WHERE ol_topsource_id = ogl_id),0) AS ol_num--发货数量
                 FROM pos_ogStorageList WITH (NOLOCK) 
			 ) AS jt
            WHERE ogl_status = 1
            GROUP BY ogl_og_id,
                     ogl_gi_id,
                     ogl_add_time,ogl_boxbynum
         ) AS posl ON pos.og_id=posl.ogl_og_id
INNER JOIN dbo.b_goodsinfo AS bg  WITH (NOLOCK) ON posl.ogl_gi_id = bg.gi_id
WHERE pos.og_status>0
go

