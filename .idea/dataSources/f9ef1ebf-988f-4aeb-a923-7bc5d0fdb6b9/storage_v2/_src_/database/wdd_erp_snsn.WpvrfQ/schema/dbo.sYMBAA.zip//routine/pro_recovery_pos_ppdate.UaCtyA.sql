
CREATE Proc [dbo].[pro_recovery_pos_ppdate]
@gi_id INT=0,
@order_id INT=0,
@type VARCHAR(50)=''
AS
DECLARE @sh_id INT=0;
IF @type='pos'
BEGIN



SELECT @sh_id=in_sh_id FROM pos_inStorage pis WHERE pis.in_id=@order_id


SELECT distinct jesl.inl_gi_id
  INTO #pp_date
FROM pos_inStorageList  jesl 
  WHERE jesl.inl_in_id=@order_id 
  AND jesl.inl_status>0
  AND jesl.inl_pddate IS NOT NULL
  AND jesl.inl_gi_id=@gi_id
  
  SELECT 
  bs.st_gi_id,
  MAX(bs.st_pddate_update_time) AS si_pddate_update_time 
  INTO #pp_date1
  FROM pos_stockInfo  bs WHERE bs.st_gi_id IN(
   SELECT * FROM #pp_date fd WITH (NOLOCK) 
  ) AND bs.st_sh_id=@sh_id
  GROUP BY st_gi_id
  
  
  SELECT fd.l_gi_id,MAX(fd.l_add_time) 
  AS l_add_time
  INTO #pp_date2
   FROM b_stockinfo_ppdate_change_log fd
   INNER JOIN #pp_date1 fd2 ON fd.l_gi_id=fd2.st_gi_id AND fd.l_add_time<fd2.si_pddate_update_time
   WHERE fd.l_type=2 AND l_sh_id=@sh_id
  GROUP BY fd.l_gi_id
  
  
  
  UPDATE pos_stockInfo SET st_pddate  = fd2.l_gen_date,st_pddate_update_time  = fd2.l_add_time
  FROM pos_stockInfo fd,(
  SELECT fd.l_gi_id,fd.l_gen_date,fd.l_add_time
   FROM b_stockinfo_ppdate_change_log fd
  INNER JOIN #pp_date2 fd2 ON fd.l_gi_id=fd2.l_gi_id AND fd.l_add_time=fd2.l_add_time
  WHERE fd.l_type=2 AND l_sh_id=@sh_id
  ) AS fd2 WHERE fd.st_gi_id=fd2.l_gi_id
  AND fd.st_sh_id=@sh_id
  
END
go

