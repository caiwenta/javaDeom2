CREATE PROCEDURE [dbo].[pro_merge_c_fundorder_reconciliation]
    @fo_id INT ,
    @fo_ciid INT = 0 ,
    @fo_shid INT = 0 ,
    @fo_to_cpid INT = 0 ,
    @fo_bs VARCHAR(50) = ''
AS
    BEGIN	
        DECLARE @fo_status INT;
        DECLARE @fo_rowNum INT = 0;
        DECLARE @sql NVARCHAR(MAX)= '';
        DECLARE @sql_where NVARCHAR(1000)= '';  
        DECLARE @fo_type INT= 0;--1入库 0:出库　
        DECLARE @orderid INT= 0;
        DECLARE @erp_id INT= 0;
        DECLARE @cp_id INT= 0;
        DECLARE @bool_need_error INT = 0;
        DECLARE @ERROR_MESSAGE VARCHAR(100)= '';

        IF ( @fo_id > 0 )
            BEGIN
                SELECT  @cp_id = fo_cp_id ,
                        @erp_id = fo_erp_id ,
                        @fo_bs = fo_bs ,
                        @fo_status = fo_status ,
                        @fo_ciid = fo_ciid ,
                        @fo_shid = fo_shid ,
                        @fo_to_cpid = fo_to_cpid ,
                        @fo_type = fo_type ,
                        @orderid = fo_order_id
                FROM    c_fundorder
                WHERE   fo_id = @fo_id
            END 
        --应收,审核
        IF ( @fo_status = 2
             AND @fo_id > 0
           )
            BEGIN
                INSERT  INTO dbo.s_operate_log
                        ( ol_addtime ,
                          ol_remark ,
                          ol_operatetype ,
                          ol_sys_remark ,
                          ol_erp_id
                        )
                VALUES  ( GETDATE() ,
                          '应收应付' ,
                          20 ,
                          '队列应收应付生成明细开始' ,
                          @fo_id
                        );
			    
                MERGE INTO c_fundorder_vi_detail_qcqm ta
                    USING
                        ( SELECT    qc ,
                                    [COUNT] ,
                                    qm ,
                                    fo_id ,
                                    fo_erp_id ,
                                    fo_cp_id ,
                                    fo_type ,
                                    fo_ciid ,
                                    fo_shid ,
                                    fo_to_cpid ,
                                    fo_bs ,
                                    fo_orderid ,
                                    fo_ticketno ,
                                    fo_ofdate ,
                                    fo_remark ,
                                    fo_lastman ,
                                    fo_status ,
                                    SUM(fo_admoney) fo_admoney ,
                                    SUM(fo_otheronmoney) fo_otheronmoney ,
                                    SUM(fo_otheoutmoney) fo_otheoutmoney ,
                                    SUM(fo_ensuremoney) fo_ensuremoney ,
                                    SUM(fo_subscription) fo_subscription ,
                                    fo_no ,
                                    fo_addtime ,
                                    fo_updatetime ,
                                    fo_rowNum ,
                                    ciname ,
                                    shname ,
                                    cpname ,
                                    qcje ,
                                    fo_userorderno ,
                                    cicode ,
                                    qc_integral ,
                                    fo_realmoney_integral ,
                                    fo_thiyetmoney_integral ,
                                    fo_outmoney_integral ,
                                    fo_otheronmoney_integral ,
                                    fo_otheoutmoney_integral ,
                                    fo_givemoney_integral ,
                                    qm_integral ,
                                    oe_type ,
                                    gi_code ,
                                    gi_name ,
                                    gi_unit ,
                                    SUM(oe_number) oe_number ,
                                    oe_costprice ,
                                    SUM(fo_realmoney) fo_realmoney ,
                                    SUM(fo_givemoney) fo_givemoney ,
                                    SUM(fo_outmoney) fo_outmoney ,
                                    SUM(fo_thiyetmoney) fo_thiyetmoney ,
                                    ( CASE WHEN MAX(gi_ownership) = 0 THEN CASE WHEN SUM(fo_outmoney) > 0 THEN SUM(fo_outmoney)
                                                                                ELSE SUM(fo_realmoney)
                                                                           END
                                           ELSE 0
                                      END ) fo_finished_money ,
                                    ( CASE WHEN MAX(gi_ownership) = 1 THEN CASE WHEN SUM(fo_outmoney) > 0 THEN SUM(fo_outmoney)
                                                                                ELSE SUM(fo_realmoney)
                                                                           END
                                           ELSE 0
                                      END ) fo_parts_money
                          FROM      ( SELECT    0 AS qc ,
                                                [COUNT] ,
                                                0 AS qm ,
                                                fo_id ,
                                                fo_erp_id ,
                                                fo_cp_id ,
                                                fo_type ,
                                                fo_ciid ,
                                                fo_shid ,
                                                fo_to_cpid ,
                                                fo_bs ,
                                                fo_orderid ,
                                                fo_ticketno ,
                                                fo_ofdate ,
                                                fo_remark ,
                                                fo_lastman ,
                                                fo_status ,
                                                CASE WHEN fo_orderid IS NOT NULL THEN 0
                                                     ELSE fo_admoney
                                                END AS fo_admoney ,
                                                CASE WHEN fo_orderid IS NOT NULL THEN 0
                                                     ELSE fo_otheronmoney
                                                END AS fo_otheronmoney ,
                                                CASE WHEN fo_orderid IS NOT NULL THEN 0
                                                     ELSE fo_otheoutmoney
                                                END AS fo_otheoutmoney ,
                                                fo_ensuremoney ,
                                                fo_subscription ,
                                                fo_no ,
                                                fo_addtime ,
                                                fo_updatetime ,
                                                fo_rowNum ,
                                                ciname ,
                                                shname ,
                                                cpname ,
                                                0 AS qcje ,
                                                fo_userorderno ,
                                                cicode ,
                                                0 AS qc_integral ,
                                                0 AS fo_realmoney_integral ,
                                                0 AS fo_thiyetmoney_integral ,
                                                0 AS fo_outmoney_integral ,
                                                0 AS fo_otheronmoney_integral ,
                                                0 AS fo_otheoutmoney_integral ,
                                                0 AS fo_givemoney_integral ,
                                                0 AS qm_integral ,
                                                ( CASE WHEN oo_type = 1 THEN '出库'
                                                       WHEN oo_type = 0 THEN '出库退货'
                                                       WHEN eo_type = 0 THEN '入库'
                                                       WHEN eo_type = 1 THEN '入库退货'
                                                  END ) AS oe_type ,
                                                ( CASE WHEN cf.fo_bs = 'X' THEN ol.gi_code
                                                       WHEN cf.fo_bs = 'G' THEN el.gi_code
                                                  END ) AS gi_code ,
                                                ( CASE WHEN cf.fo_bs = 'X' THEN ol.gi_name
                                                       WHEN cf.fo_bs = 'G' THEN el.gi_name
                                                  END ) AS gi_name ,
                                                ( CASE WHEN cf.fo_bs = 'X' THEN ol.gi_unit
                                                       WHEN cf.fo_bs = 'G' THEN el.gi_unit
                                                  END ) AS gi_unit ,
                                                ( CASE WHEN oo_type = 0 THEN -ABS(ol_number)
                                                       WHEN oo_type = 1 THEN ABS(ol_number)
                                                       WHEN eo_type = 1 THEN -ABS(el_number)
                                                       WHEN eo_type = 0 THEN ABS(el_number)
                                                  END ) AS oe_number ,
                                                ( CASE WHEN cf.fo_bs = 'X' THEN ol.ol_costprice
                                                       WHEN cf.fo_bs = 'G' THEN el.el_costprice
                                                  END ) AS oe_costprice ,
                                                ( CASE WHEN cf.fo_bs = 'X'
                                                            AND ( oo_type = 0
                                                                  OR ISNULL(ol_gift, 0) = 1
                                                                ) THEN 0
                                                       WHEN cf.fo_bs = 'X'
                                                            AND oo_type = 1
                                                            AND ISNULL(ol_gift, 0) = 0 THEN ABS(ol_realmoney)
                                                       WHEN cf.fo_bs = 'G'
                                                            AND ( eo_type = 1
                                                                  OR ISNULL(el_gift, 0) = 1
                                                                ) THEN 0
                                                       WHEN cf.fo_bs = 'G'
                                                            AND eo_type = 0
                                                            AND ISNULL(el_gift, 0) = 0 THEN ABS(el_realmoney)
                                                       ELSE 0
                                                  END ) AS fo_realmoney ,
                                                ( CASE WHEN ISNULL(ol_gift, 0) = 1 THEN ol.ol_realmoney
                                                       WHEN ISNULL(el_gift, 0) = 1 THEN el.el_realmoney
                                                       ELSE 0
                                                  END ) AS fo_givemoney ,
                                                ( CASE WHEN oo_type = 0 THEN ABS(ol.ol_realmoney)
                                                       WHEN eo_type = 1 THEN ABS(el.el_realmoney)
                                                       ELSE fo_outmoney
                                                  END ) AS fo_outmoney ,
                                                ( CASE WHEN ( oo_cash = 1
                                                              AND ISNULL(ol_gift, 0) = 0
                                                            ) THEN ol_realmoney
                                                       WHEN ( oo_cash = 1
                                                              AND ISNULL(ol_gift, 0) = 1
                                                            ) THEN 0
                                                       ELSE fo_thiyetmoney
                                                  END ) fo_thiyetmoney ,
                                                bg.gi_ownership
                                      FROM      vi_vi_c_fundorder_list_client cf WITH ( NOLOCK )
                                      LEFT JOIN dbo.j_outStorage oo WITH ( NOLOCK ) ON cf.fo_orderid = oo.oo_no
                                                                                       AND cf.fo_cp_id = oo.oo_cp_id
                                                                                       AND cf.fo_erp_id = oo.oo_erp_id
                                                                                       AND cf.fo_bs = 'X'
                                                                                       AND oo.oo_status > 0
                                      LEFT JOIN dbo.j_enterStorage eo WITH ( NOLOCK ) ON cf.fo_orderid = eo.eo_no
                                                                                         AND cf.fo_cp_id = eo.eo_cp_id
                                                                                         AND cf.fo_erp_id = eo.eo_erp_id
                                                                                         AND cf.fo_bs = 'G'
                                                                                         AND eo.eo_status > 0
                                      LEFT JOIN vi_j_outStorageList_group_goods ol WITH ( NOLOCK ) ON ol.ol_eoid = oo.oo_id
                                      LEFT JOIN vi_j_enterStorageList_group_goods el WITH ( NOLOCK ) ON eo.eo_id = el.el_eoid
                                      LEFT JOIN b_goodsinfo bg WITH ( NOLOCK ) ON ( bg.gi_id = ol.ol_siid
                                                                                    OR bg.gi_id = el.el_siid
                                                                                  )
                                      UNION ALL
                                      SELECT    0 AS qc ,
                                                [COUNT] ,
                                                0 AS qm ,
                                                fo_id ,
                                                fo_erp_id ,
                                                fo_cp_id ,
                                                fo_type ,
                                                fo_ciid ,
                                                fo_shid ,
                                                fo_to_cpid ,
                                                fo_bs ,
                                                fo_orderid ,
                                                fo_ticketno ,
                                                fo_ofdate ,
                                                fo_remark ,
                                                fo_lastman ,
                                                fo_status ,
                                                fo_admoney ,
                                                fo_otheronmoney ,
                                                fo_otheoutmoney ,
                                                0 AS fo_ensuremoney ,
                                                0 AS fo_subscription ,
                                                fo_no ,
                                                fo_addtime ,
                                                fo_updatetime ,
                                                fo_rowNum ,
                                                ciname ,
                                                shname ,
                                                cpname ,
                                                0 AS qcje ,
                                                fo_userorderno ,
                                                cicode ,
                                                0 AS qc_integral ,
                                                0 AS fo_realmoney_integral ,
                                                0 AS fo_thiyetmoney_integral ,
                                                0 AS fo_outmoney_integral ,
                                                0 AS fo_otheronmoney_integral ,
                                                0 AS fo_otheoutmoney_integral ,
                                                0 AS fo_givemoney_integral ,
                                                0 AS qm_integral ,
                                                NULL AS oe_type ,
                                                NULL AS gi_code ,
                                                NULL AS gi_name ,
                                                NULL AS gi_unit ,
                                                NULL AS oe_number ,
                                                NULL AS oe_costprice ,
                                                0 AS fo_realmoney ,
                                                0 AS fo_givemoney ,
                                                0 AS fo_outmoney ,
                                                0 AS fo_thiyetmoney ,
                                                '' AS gi_ownership
                                      FROM      vi_vi_c_fundorder_list_client cf WITH ( NOLOCK )
                                      WHERE     ( fo_admoney != 0
                                                  OR fo_otheronmoney != 0
                                                  OR fo_otheoutmoney != 0
                                                )
                                                AND fo_orderid IS NOT NULL
                                    ) AS T
                          WHERE     fo_id = @fo_id
                          GROUP BY  qc ,
                                    [COUNT] ,
                                    qm ,
                                    fo_id ,
                                    fo_erp_id ,
                                    fo_cp_id ,
                                    fo_type ,
                                    fo_ciid ,
                                    fo_shid ,
                                    fo_to_cpid ,
                                    fo_bs ,
                                    fo_orderid ,
                                    fo_ticketno ,
                                    fo_ofdate ,
                                    fo_remark ,
                                    fo_lastman ,
                                    fo_status ,
                                    fo_no ,
                                    fo_addtime ,
                                    fo_updatetime ,
                                    fo_rowNum ,
                                    ciname ,
                                    shname ,
                                    cpname ,
                                    qcje ,
                                    fo_userorderno ,
                                    cicode ,
                                    qc_integral ,
                                    fo_realmoney_integral ,
                                    fo_thiyetmoney_integral ,
                                    fo_outmoney_integral ,
                                    fo_otheronmoney_integral ,
                                    fo_otheoutmoney_integral ,
                                    fo_givemoney_integral ,
                                    qm_integral ,
                                    oe_type ,
                                    gi_code ,
                                    gi_name ,
                                    gi_unit ,
                                    oe_number ,
                                    oe_costprice
                        ) AS so
                    ON     ta.fo_id = so.fo_id
                    WHEN NOT MATCHED
                        THEN INSERT (
                                      qm ,
                                      [COUNT] ,
                                      qc ,
                                      fo_id ,
                                      fo_erp_id ,
                                      fo_cp_id ,
                                      fo_type ,
                                      fo_ciid ,
                                      fo_shid ,
                                      fo_to_cpid ,
                                      fo_bs ,
                                      fo_orderid ,
                                      fo_ticketno ,
                                      fo_realmoney ,
                                      fo_thiyetmoney ,
                                      fo_ofdate ,
                                      fo_remark ,
                                      fo_lastman ,
                                      fo_status ,
                                      fo_outmoney ,
                                      fo_admoney ,
                                      fo_otheronmoney ,
                                      fo_otheoutmoney ,
                                      fo_givemoney ,
                                      fo_ensuremoney ,
                                      fo_subscription ,
                                      fo_no ,
                                      fo_addtime ,
                                      fo_updatetime ,
                                      fo_rowNum ,
                                      ciname ,
                                      shname ,
                                      cpname ,
                                      qcje ,
                                      fo_userorderno ,
                                      cicode ,
                                      qc_integral ,
                                      fo_realmoney_integral ,
                                      fo_thiyetmoney_integral ,
                                      fo_outmoney_integral ,
                                      fo_otheronmoney_integral ,
                                      fo_otheoutmoney_integral ,
                                      fo_givemoney_integral ,
                                      qm_integral ,
                                      gi_code ,
                                      gi_name ,
                                      gi_unit ,
                                      f_number ,
                                      f_costprice ,
                                      f_type ,
                                      fo_finished_money ,
                                      fo_parts_money
                                    )
                         VALUES     ( so.qm ,
                                      so.[COUNT] ,
                                      so.qc ,
                                      so.fo_id ,
                                      so.fo_erp_id ,
                                      so.fo_cp_id ,
                                      so.fo_type ,
                                      so.fo_ciid ,
                                      so.fo_shid ,
                                      so.fo_to_cpid ,
                                      so.fo_bs ,
                                      so.fo_orderid ,
                                      so.fo_ticketno ,
                                      so.fo_realmoney ,
                                      so.fo_thiyetmoney ,
                                      so.fo_ofdate ,
                                      so.fo_remark ,
                                      so.fo_lastman ,
                                      so.fo_status ,
                                      so.fo_outmoney ,
                                      so.fo_admoney ,
                                      so.fo_otheronmoney ,
                                      so.fo_otheoutmoney ,
                                      so.fo_givemoney ,
                                      so.fo_ensuremoney ,
                                      so.fo_subscription ,
                                      so.fo_no ,
                                      so.fo_addtime ,
                                      so.fo_updatetime ,
                                      so.fo_rowNum ,
                                      so.ciname ,
                                      so.shname ,
                                      so.cpname ,
                                      so.qcje ,
                                      so.fo_userorderno ,
                                      so.cicode ,
                                      so.qc_integral ,
                                      so.fo_realmoney_integral ,
                                      so.fo_thiyetmoney_integral ,
                                      so.fo_outmoney_integral ,
                                      so.fo_otheronmoney_integral ,
                                      so.fo_otheoutmoney_integral ,
                                      so.fo_givemoney_integral ,
                                      so.qm_integral ,
                                      so.gi_code ,
                                      so.gi_name ,
                                      so.gi_unit ,
                                      so.oe_number ,
                                      so.oe_costprice ,
                                      so.oe_type ,
                                      so.fo_finished_money ,
                                      so.fo_parts_money
                                    )
                    WHEN NOT MATCHED  BY SOURCE AND ta.fo_id = @fo_id
                        THEN DELETE;

                INSERT  INTO dbo.s_operate_log
                        ( ol_addtime ,
                          ol_remark ,
                          ol_operatetype ,
                          ol_sys_remark ,
                          ol_erp_id
                        )
                VALUES  ( GETDATE() ,
                          '应收应付' ,
                          20 ,
                          '队列应收应付生成明细结束' ,
                          @fo_id
                        );
            END

	    --取消审核     
        IF ( @fo_status = 1
             AND @fo_id > 0
           )
            BEGIN
				--从当前单据往后计算
                SELECT TOP 1
                        @fo_rowNum = fo_rowNum
                FROM    c_fundorder_vi_detail_qcqm WITH ( NOLOCK )
                WHERE   fo_id = @fo_id
                ORDER BY fo_rowNum

                DELETE  c_fundorder_vi_detail_qcqm
                WHERE   fo_id = @fo_id
            END	
				
		--更新排序	
        IF ( @fo_id > 0 )
            BEGIN   
                UPDATE  c_fundorder_vi_detail_qcqm
                SET     fo_rowNum = cfu.rowNum
                FROM    c_fundorder_vi_detail_qcqm cfo ,
                        ( SELECT    ROW_NUMBER() OVER ( ORDER BY cf.fo_ciid, cf.fo_shid, cf.fo_to_cpid, cf.fo_bs, fo_ofdate, cf.fo_no, cf.cq_id ) AS rowNum ,
                                    cf.cq_id
                          FROM      c_fundorder_vi_detail_qcqm cf WITH ( NOLOCK )
                          WHERE     cf.fo_status = 2
                                    AND cf.fo_ciid = @fo_ciid
                                    AND cf.fo_shid = @fo_shid
                                    AND cf.fo_to_cpid = @fo_to_cpid
                                    AND cf.fo_bs = @fo_bs
                        ) cfu
                WHERE   cfo.cq_id = cfu.cq_id		 
				--从当前单据往后计算
                IF ( @fo_rowNum = 0 )
                    BEGIN
                        SELECT TOP 1
                                @fo_rowNum = fo_rowNum
                        FROM    c_fundorder_vi_detail_qcqm WITH ( NOLOCK )
                        WHERE   fo_id = @fo_id
                        ORDER BY fo_rowNum
                    END
            END

        INSERT  INTO dbo.s_operate_log
                ( ol_addtime ,
                  ol_remark ,
                  ol_operatetype ,
                  ol_sys_remark ,
                  ol_erp_id
                )
        VALUES  ( GETDATE() ,
                  '应收应付' ,
                  20 ,
                  '队列更新排序' ,
                  @fo_id
                );

		--计算期初金额
        SELECT  cf.cq_id ,
                ciname = CASE WHEN bcinfo.ci_bs IS NULL THEN ISNULL(bsinfo.si_name, '')
                              ELSE ISNULL(bcinfo.ci_name, '')
                         END ,
                shname = psinfo.sh_name ,
                cpname = cpinfo.cp_name ,
                qcje = CASE WHEN ( bcinfo.ci_bs IS NULL
                                   AND psinfo.sh_bs IS NULL
                                   AND cpinfo.cp_bs IS NULL
                                 ) THEN bsinfo.si_qcje
                            WHEN ( bcinfo.ci_bs IS NULL
                                   AND bsinfo.si_bs IS NULL
                                   AND cpinfo.cp_bs IS NULL
                                 ) THEN psinfo.sh_qcje
                            WHEN ( bcinfo.ci_bs IS NULL
                                   AND psinfo.sh_bs IS NULL
                                   AND bsinfo.si_bs IS NULL
                                 ) THEN cpinfo.cp_qcje
                            ELSE bcinfo.ci_qcje
                       END ,
                qc_integral = ISNULL(bsinfo.si_initial_integral, 0) ,
                cicode = CASE WHEN ( bcinfo.ci_bs IS NULL
                                     AND psinfo.sh_bs IS NULL
                                     AND cpinfo.cp_bs IS NULL
                                   ) THEN bsinfo.si_code
                              WHEN ( bcinfo.ci_bs IS NULL
                                     AND bsinfo.si_bs IS NULL
                                     AND cpinfo.cp_bs IS NULL
                                   ) THEN ''
                              WHEN ( bcinfo.ci_bs IS NULL
                                     AND psinfo.sh_bs IS NULL
                                     AND bsinfo.si_bs IS NULL
                                   ) THEN ''
                              ELSE bcinfo.ci_code
                         END ,
                CASE WHEN cf.fo_realmoney_integral = 0
                          AND cf.fo_thiyetmoney_integral = 0
                          AND cf.fo_outmoney_integral = 0
                          AND cf.fo_otheronmoney_integral = 0
                          AND cf.fo_otheoutmoney_integral = 0
                          AND cf.fo_givemoney_integral = 0 THEN 1
                     ELSE 0
                END AS integral_status ,
                CASE WHEN cf.fo_realmoney = 0
                          AND cf.fo_thiyetmoney = 0
                          AND cf.fo_outmoney = 0
                          AND cf.fo_otheronmoney = 0
                          AND cf.fo_otheoutmoney = 0
                          AND cf.fo_givemoney = 0
                          AND fo_admoney = 0
                          AND fo_ensuremoney = 0
                          AND fo_subscription = 0 THEN 1
                     ELSE 0
                END AS fun_status
        INTO    ##qc
        FROM    ( SELECT    *
                  FROM      c_fundorder_vi_detail_qcqm cf WITH ( NOLOCK )
                  WHERE     cf.fo_status = 2
                            AND cf.fo_bs = @fo_bs
                            AND ISNULL(cf.fo_ciid, 0) = @fo_ciid
                            AND ISNULL(cf.fo_shid, 0) = @fo_shid
                            AND ISNULL(cf.fo_to_cpid, 0) = @fo_to_cpid
                ) AS cf
        LEFT JOIN ( SELECT  ci_bs = 'X' ,
                            bc.ci_id ,
                            bc.ci_name ,
                            ISNULL(bc.ci_qcje, 0) AS ci_qcje ,
                            bc.ci_code
                    FROM    b_clientinfo bc WITH ( NOLOCK )
                  ) AS bcinfo ON cf.fo_ciid = bcinfo.ci_id
                                 AND cf.fo_bs = bcinfo.ci_bs
        LEFT JOIN ( SELECT  sh_bs = 'X' ,
                            ps.sh_id ,
                            ps.sh_name ,
                            ISNULL(ps.sh_qcje, 0) AS sh_qcje ,
                            ps.sh_no
                    FROM    pos_shop ps WITH ( NOLOCK )
                    WHERE   ps.[status] != 0
                  ) AS psinfo ON cf.fo_shid = psinfo.sh_id
                                 AND cf.fo_bs = psinfo.sh_bs
        LEFT JOIN ( SELECT  cp_bs = 'X' ,
                            cp.cp_id ,
                            cp.cp_name ,
                            ISNULL(cp.cp_qcje, 0) AS cp_qcje ,
                            cp.cp_code
                    FROM    companyinfo cp WITH ( NOLOCK )
                  ) AS cpinfo ON cf.fo_to_cpid = cpinfo.cp_id
                                 AND cf.fo_bs = cpinfo.cp_bs
        LEFT JOIN ( SELECT  si_bs = 'G' ,
                            bs.si_id ,
                            bs.si_name ,
                            ISNULL(bs.si_qcje, 0) AS si_qcje ,
                            ISNULL(bs.si_initial_integral, 0) AS si_initial_integral ,
                            bs.si_code
                    FROM    b_supplierinfo bs WITH ( NOLOCK )
                  ) AS bsinfo ON cf.fo_ciid = bsinfo.si_id
                                 AND cf.fo_bs = bsinfo.si_bs;								
  
        UPDATE  c_fundorder_vi_detail_qcqm
        SET     ciname = qc.ciname ,
                shname = qc.shname ,
                cpname = qc.cpname ,
                qcje = qc.qcje ,
                qc_integral = qc.qc_integral ,
                cicode = qc.cicode
        FROM    c_fundorder_vi_detail_qcqm cfo ,
                ##qc qc
        WHERE   cfo.cq_id = qc.cq_id

        DROP TABLE ##qc;

        INSERT  INTO dbo.s_operate_log
                ( ol_addtime ,
                  ol_remark ,
                  ol_operatetype ,
                  ol_sys_remark ,
                  ol_erp_id
                )
        VALUES  ( GETDATE() ,
                  '应收应付' ,
                  20 ,
                  '队列计算期初金额' ,
                  @fo_id
                );

		--计算期末金额
        SELECT  ( cfs.qc + cf.qcje ) AS qc ,
                ( cfs.qc_integral + cf.qc_integral ) AS qc_integral ,
                qm = ISNULL(cfs.qc + cf.qcje, 0) + ( CASE WHEN cf.fo_type = 0
                                                          THEN cf.fo_realmoney + cf.fo_admoney + cf.fo_otheronmoney - cf.fo_otheoutmoney - cf.fo_outmoney
                                                               - cf.fo_thiyetmoney
                                                          ELSE cf.fo_realmoney + cf.fo_otheoutmoney - cf.fo_outmoney - cf.fo_thiyetmoney - cf.fo_admoney
                                                               - cf.fo_otheronmoney
                                                     END ) ,
                qm_integral = ISNULL(cfs.qc_integral + cf.qc_integral, 0) + ( CASE WHEN cf.fo_type = 0
                                                                                   THEN cf.fo_realmoney_integral + cf.fo_otheronmoney_integral
                                                                                        - cf.fo_otheoutmoney_integral - cf.fo_outmoney_integral
                                                                                        - cf.fo_thiyetmoney_integral
                                                                                   ELSE cf.fo_realmoney_integral + cf.fo_otheoutmoney_integral
                                                                                        - cf.fo_outmoney_integral - cf.fo_thiyetmoney_integral
                                                                                        - cf.fo_otheronmoney_integral
                                                                              END ) ,
                cf.cq_id ,
                cf.Count
        INTO    ##qm
        FROM    c_fundorder_vi_detail_qcqm cf WITH ( NOLOCK )
        CROSS APPLY ( SELECT    ISNULL(SUM(CASE WHEN cfs.fo_type = 0
                                                THEN cfs.fo_realmoney + cfs.fo_admoney + cfs.fo_otheronmoney - cfs.fo_otheoutmoney - cfs.fo_outmoney
                                                     - cfs.fo_thiyetmoney
                                                ELSE cfs.fo_realmoney + cfs.fo_otheoutmoney - cfs.fo_outmoney - cfs.fo_thiyetmoney - cfs.fo_admoney
                                                     - cfs.fo_otheronmoney
                                           END), 0) AS qc ,
                                ISNULL(SUM(CASE WHEN cfs.fo_type = 0
                                                THEN cfs.fo_realmoney_integral + cfs.fo_otheronmoney_integral - cfs.fo_otheoutmoney_integral
                                                     - cfs.fo_outmoney_integral - cfs.fo_thiyetmoney_integral
                                                ELSE cfs.fo_realmoney_integral + cfs.fo_otheoutmoney_integral - cfs.fo_outmoney_integral
                                                     - cfs.fo_thiyetmoney_integral - cfs.fo_otheronmoney_integral
                                           END), 0) AS qc_integral
                      FROM      ( SELECT    *
                                  FROM      c_fundorder_vi_detail_qcqm cfs WITH ( NOLOCK )
                                  WHERE     cf.fo_status = cfs.fo_status
                                            AND cf.fo_type = cfs.fo_type
                                            AND cf.fo_ciid = cfs.fo_ciid
                                            AND cf.fo_shid = cfs.fo_shid
                                            AND cf.fo_to_cpid = cfs.fo_to_cpid
                                            AND cf.fo_bs = cfs.fo_bs
                                            AND cfs.fo_rowNum < cf.fo_rowNum
                                ) cfs
                    ) cfs
        WHERE   cf.fo_status = 2
                AND cf.fo_bs = @fo_bs
                AND ISNULL(cf.fo_ciid, 0) = @fo_ciid
                AND ISNULL(cf.fo_shid, 0) = @fo_shid
                AND ISNULL(cf.fo_to_cpid, 0) = @fo_to_cpid
                AND cf.fo_rowNum >= @fo_rowNum 

        INSERT  INTO dbo.s_operate_log
                ( ol_addtime ,
                  ol_remark ,
                  ol_operatetype ,
                  ol_sys_remark ,
                  ol_erp_id
                )
        VALUES  ( GETDATE() ,
                  '应收应付' ,
                  20 ,
                  '队列查询期末金额' ,
                  @fo_id
                );

        UPDATE  c_fundorder_vi_detail_qcqm
        SET     qm_integral = qm.qm_integral ,
                qm = qm.qm ,
                Count = qm.Count ,
                qc = qm.qc ,
                qc_integral = qm.qc_integral
        FROM    c_fundorder_vi_detail_qcqm cfo ,
                ##qm qm
        WHERE   cfo.cq_id = qm.cq_id

        DROP TABLE ##qm;
		 	
        INSERT  INTO dbo.s_operate_log
                ( ol_addtime ,
                  ol_remark ,
                  ol_operatetype ,
                  ol_sys_remark ,
                  ol_erp_id
                )
        VALUES  ( GETDATE() ,
                  '应收应付' ,
                  20 ,
                  '队列计算期末金额' ,
                  @fo_id
                );

        theEnd:
        IF @bool_need_error = 1
            RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);                
    END
go

