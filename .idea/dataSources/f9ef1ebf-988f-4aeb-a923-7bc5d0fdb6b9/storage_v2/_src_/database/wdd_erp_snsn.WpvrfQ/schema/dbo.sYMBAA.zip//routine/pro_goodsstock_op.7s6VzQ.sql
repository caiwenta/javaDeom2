CREATE PROCEDURE [dbo].[pro_goodsstock_op]
	@orderid int = 0,
	@stocktype varchar(50)='',
	@erp_id int,
	@orderguid VARCHAR(500) = '' Out,
    @slt_id int=0
AS
BEGIN
    BEGIN TRAN

    set @orderguid =NewID()



	--pos入库/入库退货
	if @stocktype='posenter'
		begin
	     INSERT  INTO erp_goodslisttemp
                       ( gi_id , sku_id ,pm ,gift,erp_id ,
					    number , 
						discount , --折扣
						retailprice , --零售价
						stockprice, --供货价
						summoney,--出库金额
						box_num,
						stocktype,
						orderguid, 
						orderid,
						orderstatus,slt_id)
		        SELECT  inl_gi_id, inl_sku_id,inl_pm,inl_gift,@erp_id,
                        sum(inl_num) AS inl_num,
						MIN(inl_discount) AS inl_discount,--折扣
						MIN(inl_retail_price) AS inl_retail_price,--零售价
                        MIN(inl_stock_price) AS inl_stock_price,--进货价
						SUM(inl_money) AS inl_money,--入库金额
						sum(inl_box_num) AS  inl_box_num,
						@stocktype,
						@orderguid,
						inl_in_id,
						inl_status,
						@slt_id
				FROM  pos_inStorageList
			    WHERE inl_in_id = @orderid AND inl_status > 0  and inl_num<>0
			    GROUP BY inl_gi_id, inl_sku_id,inl_pm,inl_gift,inl_in_id,inl_status
		end

	if @stocktype='enter'
		begin
	         INSERT  INTO erp_goodslisttemp
                       ( gi_id , sku_id ,pm ,gift,erp_id ,
					    number , 
						discount , --折扣
						retailprice , --零售价
						stockprice, --供货价
						summoney,--出库金额
						box_num,
						stocktype,
						orderguid, 
						orderid,
						orderstatus,slt_id)
		        SELECT  el_siid, el_skuid,el_pm,el_gift,@erp_id,
						sum(el_number) AS inl_num,
						MIN(el_discount) AS inl_discount,--折扣
						MIN(el_unit) AS inl_retail_price,--零售价
						MIN(el_costprice) AS inl_stock_price,--进货价
						SUM(el_realmoney) AS inl_money,--入库金额
						sum(el_box_num) AS  inl_box_num,
						@stocktype,
						@orderguid,
						el_eoid,
						el_status,
						@slt_id
				FROM  j_enterStoragelist
				WHERE el_eoid = @orderid AND el_status > 0 and el_number<>0
				GROUP BY el_siid, el_skuid,el_pm,el_gift,el_eoid,el_status
			end 

	if @stocktype='posrestorage'--分司补货
	   begin
			 INSERT  INTO erp_goodslisttemp
                       ( gi_id , sku_id ,pm ,gift,erp_id ,
					    number , 
						discount , --折扣
						retailprice , --零售价
						stockprice, --供货价
						summoney,--出库金额
						box_num,
						stocktype,
						orderguid, 
						orderid,
						orderstatus,slt_id)
		        SELECT  rel_gi_id, rel_sku_id,rel_pm,rel_is_gift,@erp_id,
						sum(rel_num) AS rel_num,
						MIN(rel_discount) AS rel_discount,--折扣
						MIN(rel_retail_price) AS rel_retail_price,--零售价
						MIN(rel_stock_price) AS rel_stock_price,--进货价
						SUM(rel_money) AS rel_money,--入库金额
						sum(rel_box_num) AS  rel_box_num,
						@stocktype,
						@orderguid,
						rel_re_id,
						rel_status,
						@slt_id
				FROM  pos_reStorageList
				WHERE rel_re_id = @orderid AND rel_status > 0 and rel_num<>0
				GROUP BY rel_gi_id, rel_sku_id,rel_pm,rel_is_gift,rel_re_id,rel_status
	   end

	if @stocktype='posshoprestorage'--店铺补货
	   begin
			 INSERT  INTO erp_goodslisttemp
                       ( gi_id , sku_id ,pm ,gift,erp_id ,
					    number , 
						discount , --折扣
						retailprice , --零售价
						stockprice, --供货价
						summoney,--出库金额
						box_num,
						stocktype,
						orderguid, 
						orderid,
						orderstatus,
						slt_id,
						orderlistid,
						source_id,
						source_addtime
						)
                select 
				rel_gi_id, rel_sku_id,rel_pm,rel_is_gift,@erp_id,
				isnull(rel_num,0)-isnull(phnum,0),
				rel_discount,
				rel_retail_price,
				rel_stock_price,
				rel_money,
				rel_box_num,
				@stocktype,
				@orderguid,
				rel_re_id,
				rel_status,
				@slt_id,
				rel_id,
				rel_id,
				rel_add_time
				from (
		        SELECT  rel_gi_id, rel_sku_id,rel_pm,rel_is_gift,
						sum(rel_num) AS rel_num,
						ISNULL((
						SELECT SUM(all_num) FROM pos_allocation pa WITH (NOLOCK)
							INNER JOIN pos_allocationList pal WITH (NOLOCK) ON pa.al_id=pal.all_al_id AND pa.al_status<>0
							AND pal.all_gi_id=rel_gi_id AND pal.all_sku_id=rel_sku_id AND pa.al_source_id=rel_re_id and al_source IN (2)
						),0) AS phnum,
						MIN(rel_discount) AS rel_discount,--折扣
						 CONVERT(DECIMAL(10, 2),
						 AVG(CASE WHEN rel_num > 0 THEN rel_retail_price ELSE NULL END)
						 ) AS rel_retail_price,--零售价
						 CONVERT(DECIMAL(10, 2),
                         AVG(CASE WHEN rel_num > 0 THEN rel_stock_price ELSE NULL END)
                        )AS rel_stock_price,--进货价
						SUM(rel_money) AS rel_money,--入库金额
						sum(rel_box_num) AS  rel_box_num,
						rel_re_id,
						rel_status,
						max(rel_id) as rel_id,
						rel_add_time
				FROM  pos_reStorageList
				WHERE rel_re_id = @orderid AND rel_status > 0 and rel_num<>0
				GROUP BY rel_gi_id, rel_sku_id,rel_pm,rel_is_gift,rel_re_id,rel_status,rel_add_time

			) as TT
			where isnull(rel_num,0)-isnull(phnum,0)<>0


	   end

	if @stocktype='posallocation'
		begin
		INSERT INTO erp_goodslisttemp
               (gi_id , sku_id ,pm ,gift,erp_id ,
					    number , 
						discount , --折扣
						retailprice , --零售价
						stockprice, --供货价
						summoney,--出库金额
						box_num,
						stocktype,
						orderguid, 
						orderid,
						orderstatus,
						slt_id,
						orderlistid,
						source_id,
						source_addtime
				 )
		SELECT  all_gi_id,pal.all_sku_id,pal.all_pm,pal.all_gift,@erp_id,
				sum(all_num) AS all_num,
				min(all_discount) AS all_discount,
				min(all_retail_price) AS all_retail_price,
				min(all_stock_price) AS all_stock_price,
				SUM(all_money) AS all_money,
				SUM(all_box_num) AS all_box_num,
				@stocktype,
				@orderguid,
				all_al_id,
				all_status,
				@slt_id,
				max(all_id),
				max(all_id),
				all_add_time
				FROM pos_allocationList AS pal
		WHERE pal.all_al_id=@orderid AND pal.all_status>0 AND pal.all_num>0
		GROUP BY all_gi_id,pal.all_sku_id,pal.all_pm,pal.all_gift,all_al_id,all_status,all_add_time
		end


	 IF @@ERROR <> 0
            BEGIN
			    set @orderguid ='';
                ROLLBACK TRANSACTION
            END
       ELSE
            BEGIN
                IF @@TRANCOUNT > 0
                    COMMIT TRAN
            END

end
go

