
create View [dbo].[vi_j_purchaseStorageList_pro_new_all]
		as

SELECT bg.*,
       p1.*
FROM   b_goodsruleset  AS bg
       LEFT JOIN (
                SELECT pll_pl_id,
                       pll_gi_id,
                       pll_sku_id,
                       pll_add_time,
                       pll_pause_num,
                       (pll_num -ISNULL(fd.el_number, 0))
                       -ISNULL(pll_pause_num, 0) AS pll_num,
                       pll_id,
                       pll_stock_price,
                       pll_discount,
                       pll_money,
                       pll_retail_price,
                       pll_status,
                       pll_pm,
                       pll_box_num
                FROM   (
                           SELECT pll_pl_id,
                                  pll_gi_id,
                                  pll_sku_id,
                                  pll_add_time,
                                  pll_pause_num,
                                  pll_num,
                                  pll_id,
                                  pll_stock_price,
                                  pll_discount,
                                  pll_money,
                                  pll_retail_price,
                                  pll_status,
                                  pll_pm,
                                  pll_box_num
                           FROM   vi_j_purchaseStorageList_pro_new jt
                       ) AS jisl
                       LEFT JOIN (
                                SELECT aa.eo_source_id,
                                       aa.el_siid,
                                       aa.el_skuid,
                                       SUM(aa.en_number) AS el_number
                                FROM   (
                                           SELECT *,
                                                  (
                                                      CASE jes.eo_type
                                                           WHEN 1 THEN -jesl.el_number
                                                           WHEN 0 THEN jesl.el_number
                                                           ELSE 0
                                                      END
                                                  )en_number
                                           FROM   j_enterStorage AS jes
                                                  INNER JOIN j_enterStorageList AS 
                                                       jesl
                                                       ON  jes.eo_id = jesl.el_eoid
                                           WHERE  jes.eo_status > 0
                                                  AND jesl.el_status = 1
                                                  AND jes.eo_source_type = 1
                                       ) aa
                                GROUP BY
                                       aa.eo_source_id,
                                       aa.el_siid,
                                       aa.el_skuid
                            ) fd
                            ON  jisl.pll_gi_id = fd.el_siid
                            AND jisl.pll_sku_id = fd.el_skuid
                            AND jisl.pll_pl_id = fd.eo_source_id
                WHERE  jisl.pll_status = 1
            )          AS p1
            ON  bg.gi_id = p1.pll_gi_id
            AND bg.gss_id = p1.pll_sku_id
go

