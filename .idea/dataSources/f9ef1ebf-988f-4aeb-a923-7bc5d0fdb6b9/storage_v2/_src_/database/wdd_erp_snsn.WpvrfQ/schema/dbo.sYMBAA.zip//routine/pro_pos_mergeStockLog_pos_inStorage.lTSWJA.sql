

CREATE PROCEDURE [dbo].[pro_pos_mergeStockLog_pos_inStorage]
	@tsl_sh_id INT,
	@negative_inventory INT = 0,
	@old_sei_id INT = 0,
	@new_sei_id INT = 0,
	@id INT = 0
AS
	EXEC pro_pos_mergeStockLog_check
	     @tsl_sh_id = @tsl_sh_id,
	     @negative_inventory = @negative_inventory,
	     @old_sei_id = @old_sei_id,
	     @new_sei_id = @new_sei_id
	IF @@ERROR != 0
	BEGIN
	    DECLARE @ERROR_MESSAGE VARCHAR(100) = '';
	    SELECT @ERROR_MESSAGE = ERROR_MESSAGE();
	    RAISERROR (@ERROR_MESSAGE, 16, 1, N'number', 5);
	    RETURN;
	END
	BEGIN
		BEGIN TRAN
		
		DECLARE @now DATETIME = GETDATE();
		
		update pos_stocklog set sl_status=0  where sl_shop_id = @tsl_sh_id AND sl_eoid=@id AND sl_type=1

		INSERT pos_stocklog
		 (
		    sl_eoid,
		    sl_elid,
		    sl_seiid,
		    sl_shop_id,
		    sl_ciid,
		    sl_giid,
		    sl_skuid,
		    sl_type,
		    sl_counttype,
		    sl_number,
		    sl_addtime,
		    sl_updatetime,
		    sl_remark,
		    sl_status,
		    sl_order_no,
		    sl_order_date,
		    sl_order_add_time,
			sl_pm,
			sl_erp_id
		  )
		  select   
		    so.eoid,
		    so.elid,
		    so.[sid],
		    so.shid,
		    so.cid,
		    so.gid,
		    so.skuid,
		    so.mytype,
		    so.countType,
		    so.gnum,
		    so.addtime,
		    @now,
		    so.myremark,
		    1,
		    so.orderno,
		    so.order_date,
		    so.order_add_time,
			isnull(so.pm,''),
			so.erp_id
		from (
		    SELECT 

       je.in_st_id           AS SID,
       je.in_sh_id           AS shid,
       cid = 0,
       je2.inl_gi_id         AS gid,
       je2.inl_sku_id        AS skuid,
       je2.inl_num           AS gnum,
	   isnull(je2.inl_pm,'')                  as pm,
       countType = CASE 
                        WHEN je.in_type = 0 THEN 1
                        ELSE 0
                   END,
       myremark = CASE 
                       WHEN je.in_type = 0 THEN '入库'
                       ELSE     '入库退货'
                  END,
       addtime = je2.inl_add_time,
       orderno = je.in_vo,
       eoid = je.in_id,
       elid = je2.inl_id,
       mytype = 1,
       order_add_time = je.in_add_time,
       order_date = je.in_date,
       je.in_erp_id AS erp_id
	   FROM  pos_inStorage je
       INNER JOIN pos_inStorageList je2
            ON  je.in_id = je2.inl_in_id
		    WHERE je2.inl_in_id=@id AND  je.in_status > 0
       AND je2.inl_status = 1
       AND je2.inl_gi_id > 0
       AND je.in_st_id > 0
       AND je.in_sh_id>0
       
		) AS so


		EXEC pro_pos_mergeStockSum_new @tsl_sh_id = @tsl_sh_id,@id=@id,@type=1
		
		EXEC pro_pos_mergeBatchStockSum @tsl_sh_id = @tsl_sh_id,@id=@id,@type=1,
		@negative_inventory=@negative_inventory,@old_sei_id=@old_sei_id,@new_sei_id=@new_sei_id


		DELETE pos_stocklog where sl_status = 0 AND sl_shop_id = @tsl_sh_id AND sl_eoid=@id AND sl_type=1



		IF @@ERROR <> 0
		BEGIN
		    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
		END
		ELSE
		BEGIN
		    IF @@TRANCOUNT > 0 COMMIT TRAN
		END
	END
go

