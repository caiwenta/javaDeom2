CREATE VIEW [dbo].[z_user_column_list] AS 
SELECT
*
FROM
(
SELECT sci_id
      ,sci_di_id
      ,sci_fieldname
      ,(CASE WHEN su.uci_fieldexplain IS NULL THEN sci_fieldexplain ELSE su.uci_fieldexplain END) as sci_fieldexplain
      ,(CASE WHEN su.uci_width IS NULL THEN sci_width ELSE su.uci_width END) as sci_width
      ,(CASE WHEN su.uci_align IS NULL THEN sci_align ELSE su.uci_align END) as sci_align
      ,(CASE WHEN su.uci_is_sort IS NULL THEN sci_is_sort ELSE su.uci_is_sort END) as sci_is_sort
      ,(CASE WHEN su.uci_is_display IS NULL THEN sci_is_display ELSE su.uci_is_display END) as sci_is_display
      ,(CASE WHEN su.uci_is_checkbox IS NULL THEN sci_is_checkbox ELSE su.uci_is_checkbox END) as sci_is_checkbox
      ,sci_formatter
      ,sci_style
      ,(CASE WHEN su.uci_halign IS NULL THEN sci_halign ELSE su.uci_halign END) as sci_halign
      ,(CASE WHEN su.uci_sort IS NULL THEN sci_sort ELSE su.uci_sort END) as  sci_sort
      ,sci_status
      ,sci_cp_id
      ,sci_reftype
      ,sci_refid
      ,sci_erp_id
      ,sci_precision
      ,sci_enumtype
	  ,su.uci_id
FROM s_sys_column_info AS sc LEFT JOIN 
s_user_column_info AS su ON su.uci_sci_id=sc.sci_id
) AS uci
go

