CREATE PROCEDURE [dbo].[pro_fundorder_op]
	@fo_id int = 0,
	@fo_status int=0,
	@fo_lastman VARCHAR(50) = '',
	@op_type VARCHAR(50) = ''
AS

--事务开始
BEGIN TRAN

	DECLARE @ERROR_MESSAGE VARCHAR(MAX)='';
	declare @cp_id int=0;
	declare @fo_erp_id int=0;
	declare @date DATETIME;

	SELECT 
		@date=fo_ofdate,
		@cp_id=fo_cp_id,
		@fo_erp_id=fo_erp_id
	FROM c_fundorder
	WHERE fo_id=@fo_id


BEGIN TRY

	--月报表
	IF EXISTS(SELECT TOP 1 m_month FROM j_month_report WHERE reporttype=0 AND company_id=@cp_id AND  m_year=DATEPART(YEAR,@date) AND m_month=DATEPART(MONTH,@date))	
	BEGIN
		SET @ERROR_MESSAGE =  '您所要操作的数据已生成月报表,数据已被锁定,禁止操作!';
		GOTO theEnd;
	END


	--日报表
	IF EXISTS(SELECT TOP 1 m_day FROM j_month_report WHERE reporttype=1 AND company_id=@cp_id AND  m_year=DATEPART(YEAR,@date) AND m_month=DATEPART(MONTH,@date) AND m_day=DATEPART(day,@date))
	BEGIN
		SET @ERROR_MESSAGE = '您所要操作的数据已生成日报表,数据已被锁定,禁止操作!';
		GOTO theEnd;
	END


	if @op_type='审核'
	begin
		update c_fundorder set fo_status=2,fo_lastman=@fo_lastman where fo_id=@fo_id
	end


	if @op_type='取消审核'
	begin
		update c_fundorder set fo_status=1,fo_lastman=@fo_lastman where fo_id=@fo_id
	end

	if @op_type='删除'
	begin
		update c_fundorder set fo_status=0,fo_lastman=@fo_lastman where fo_id=@fo_id
	end


	--生成报表
	---exec pro_merge_c_fundorder_reconciliation @fo_id=@fo_id
	DECLARE @tdoc_xml VARCHAR(max)= '';
	SET @tdoc_xml = '{ "fo_id":"' + CONVERT(VARCHAR(50), @fo_id) + '"}';
	EXEC pro_apiqueue_op 
	@tdoc_method = 'fundorderreconciliation', 
	@tdoc_xml = @tdoc_xml, 
	@tdoc_erp_id =@fo_erp_id, 
	@tdoc_cp_id=@cp_id,
	@tdoc_state = 0;


	EXEC pro_merge_fundorder @fo_id=@fo_id;

END TRY
BEGIN CATCH

	SET @ERROR_MESSAGE = ERROR_MESSAGE();

END CATCH

if @ERROR_MESSAGE<>''
BEGIN
	theEnd:
    ----执行出错，回滚事务
    ROLLBACK TRAN;
	RAISERROR (@ERROR_MESSAGE,16,1,N'number',5);
END
ELSE
BEGIN
    ----没有异常，提交事务
    COMMIT TRAN;
END
go

