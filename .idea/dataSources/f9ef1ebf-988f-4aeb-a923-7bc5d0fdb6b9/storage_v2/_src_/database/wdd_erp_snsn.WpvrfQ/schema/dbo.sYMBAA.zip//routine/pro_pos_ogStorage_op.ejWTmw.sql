



CREATE PROC [dbo].[pro_pos_ogStorage_op]
@ogl_box_num INT = 0,
@ogl_pm VARCHAR(500) = '',
--主键  
@og_id INT = 0,  
@og_erp_id INT = 0,  
@ogl_erp_id INT = 0,  
--单据号  
@og_no VARCHAR(50) = '',  
--订货日期  
@og_date DATETIME = '2014-10-24',  
--交易方式(1,订货:2,补货:3,铺货:4,买断)  
@og_type INT = 0,  
--客户主键  
@og_ci_id INT = 0,  
--店铺主键  
@og_sh_id INT = 0,  
--分公司主键
@og_to_cp_id INT =0,
--交货日期  
@og_out_date DATETIME = '',  
--运输方式  
@og_trans VARCHAR(50) = '',  
--业务员主键  
@og_business INT = 0,  
--添加人  
@og_add_man INT = 0,  
--添加时间  
@og_add_time DATETIME = '2014-10-24',  
--修改人  
@og_update_man INT = 0,  
--修改时间  
@og_update_time DATETIME = '2014-10-24',  
--审核人  
@og_audit_man INT = 0,  
--审核时间  
@og_audit_time DATETIME = '2014-10-24',  
--参考单号  
@og_refe_no VARCHAR(50) = '',  
--制单人  
@og_order_man INT = 0,  
--是否锁定折率与供应价不能修改  
@og_is_lock INT = 0,  
--备注
@og_remark VARCHAR(50) = '',
--主键  
@ogl_id INT = 0,  
--订货主键  
@ogl_og_id INT = 0,  
--商品主键  
@ogl_gi_id INT = 0,  
--商品sku主键  
@ogl_sku_id INT = 0,  
--数量  
@ogl_num INT = 0,  
--零售价  
@ogl_retail_price DECIMAL(9, 2) = 0,  
--折率  
@ogl_discount DECIMAL(9, 2) = 0,  
--供货价  
@ogl_stock_price DECIMAL(9, 2) = 0,  
--金额  
@ogl_money DECIMAL(9, 2) = 0,  
--零售金额  
@ogl_retail_money DECIMAL(9, 2) = 0,  
--备注  
@ogl_remark VARCHAR(50) = '',  
--添加时间  
@ogl_add_time DATETIME = '2014-10-24',  
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  
--结果  
@result VARCHAR(100) = '' OUT,
--公司主键
@og_cp_id int =0,
--部门主键
@og_di_id int =0,
--保存字符串
@savestr VARCHAR(MAX)='',
@orderguid VARCHAR(500)='', --唯一guid
@og_source_type int =0,
@og_source_id int=0
AS
BEGIN
	--是否添加单据
	DECLARE @isInsert INT = 0;
	--是否需要更新单据
	DECLARE @need_update INT = 0;
	--旧的单据日期
	DECLARE @old_order_date DATETIME;
	--单据日期是否更改
	DECLARE @old_order_date_is_changed INT = 0;
	--凭证号前缀
	DECLARE @myprevTxt VARCHAR(50) = 'DH';
	
	IF @og_out_date = '1997-01-01'
	BEGIN
	    SET @og_out_date = NULL;
	END
	
	BEGIN TRAN
	IF @op_type = '添加修改单据,明细'
	BEGIN
	    IF @og_id = 0
	    BEGIN
	        --添加单据
	        INSERT INTO pos_ogStorage
	          (
	            og_vo,
	            og_no,
	            og_date,
	            og_type,
	            og_ci_id,
	            og_sh_id,
	            og_out_date,
	            og_trans,
	            og_business,
	            og_add_man,
	            og_add_time,
	            og_update_man,
	            og_update_time,
	            og_refe_no,
	            og_order_man,
	            og_is_lock,
	            og_status,
	            og_remark,
	            og_cp_id,
	            og_di_id,
	            og_to_cp_id,
	            og_erp_id,
				og_source_type,
				og_source_id
	          )
	        VALUES
	          (
	            NEWID(),
	            @og_no,
	            @og_date,
	            @og_type,
	            @og_ci_id,
	            @og_sh_id,
	            @og_out_date,
	            @og_trans,
	            @og_business,
	            @og_add_man,
	            @og_add_time,
	            @og_update_man,
	            @og_update_time,
	            @og_refe_no,
	            @og_order_man,
	            @og_is_lock,
	            1,
	            @og_remark,
	            @og_cp_id,
	            @og_di_id,
	            @og_to_cp_id,
	            @og_erp_id,
				@og_source_type,
				@og_source_id
	          );
	        SET @og_id = SCOPE_IDENTITY();
	        
	        SET @ogl_og_id = @og_id;
	        SET @isInsert = 1;
	    END
	    ELSE
	    BEGIN
	        SET @need_update = 1;
	    END

	     --强制时间一样
	    select top 1 @ogl_add_time=j.ogl_add_time FROM pos_ogStorageList j WHERE j.ogl_og_id=@ogl_og_id and j.ogl_gi_id= @ogl_gi_id and j.ogl_pm=@ogl_pm ;
	

	    --IF EXISTS(
	    --       SELECT *
	    --       FROM   pos_ogStorageList AS jt
	    --       WHERE  jt.ogl_og_id = @og_id
	    --              AND jt.ogl_status = 1
	    --              AND jt.ogl_add_time = @ogl_add_time
	    --              AND jt.ogl_gi_id != @ogl_gi_id
	    --   )
	    --BEGIN
	    --    UPDATE pos_ogStorageList
	    --    SET    ogl_status = 0
	    --    WHERE  ogl_og_id = @og_id
	    --           AND ogl_add_time = @ogl_add_time
	    --           AND ogl_status = 1
	    --           AND ogl_gi_id != @ogl_gi_id;
	    --    SET @ogl_id = 0;
	    --END
	    
	    --保存字符串用 | 作为分隔符,此变量存储分割后的具体项

		if @orderguid=''
		begin

	    DECLARE @savestr_item VARCHAR(MAX)='';
	    --起始数值,每次循环后递增
	    DECLARE @start_int INT=1;
	    --终止数值
		DECLARE @end_int INT=1;
	    IF @savestr!='' 
	    --AND 1=2
	    BEGIN
	    	--得到明细数量
	    	--即要循环的次数
	    	SELECT @end_int=(LEN(@savestr)-LEN(REPLACE(@savestr,'|','')))
	    END
	    WHILE @start_int<=@end_int
		BEGIN
			
	    --动态赋值
	    IF @savestr!='' 
	    BEGIN
	    	SET @savestr_item=dbo.Get_StrArrayStrOfIndex(@savestr,'|',@start_int);
	    	IF(RTRIM(LTRIM(@savestr_item))='')
			BEGIN
				BREAK;
			END
			ELSE
			BEGIN

				SET @ogl_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));
				
				SET @ogl_gi_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));
				
				SET @ogl_sku_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3));
				
				SET @ogl_num=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));
				
				SET @ogl_retail_price=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5));
				
				SET @ogl_stock_price=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',6));
				
				SET @ogl_discount=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',7));
				
				
				SET @ogl_box_num=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',8));
				
				SET @ogl_pm=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',9);
				
			END
	    END	


		IF @ogl_id = 0 
	    BEGIN
	        select 
			@ogl_id=ogl_id,
			@ogl_num=ogl_num+@ogl_num,
			@ogl_box_num=ogl_box_num+@ogl_box_num
			FROM pos_ogStorageList jpsl WHERE ogl_og_id=@ogl_og_id AND ogl_gi_id= @ogl_gi_id  AND ogl_sku_id= @ogl_sku_id and ogl_status=1 and isnull(jpsl.ogl_pm,'')=isnull(@ogl_pm ,'');
	    END

	    IF @ogl_id = 0
	    BEGIN
	        INSERT INTO pos_ogStorageList
	          (
	            ogl_og_id,
	            ogl_gi_id,
	            ogl_sku_id,
	            ogl_num,
	            ogl_retail_price,
	            ogl_discount,
	            ogl_stock_price,
	            ogl_money,
	            ogl_retail_money,
	            ogl_remark,
	            ogl_status,
	            ogl_add_time,
	            ogl_box_num,
	            ogl_pm,ogl_erp_id
	          )
	        VALUES
	          (
	            @ogl_og_id,
	            @ogl_gi_id,
	            @ogl_sku_id,
	            @ogl_num,
	            @ogl_retail_price,
	            @ogl_discount,
	            @ogl_stock_price,
	            @ogl_stock_price * @ogl_num,
	            @ogl_retail_price * @ogl_num,
	            @ogl_remark,
	            1,
	            @ogl_add_time,
	            @ogl_box_num,
	            @ogl_pm,@ogl_erp_id
	          );
	        SET @ogl_id = SCOPE_IDENTITY();
	    END
	    ELSE
	    BEGIN
	        UPDATE pos_ogStorageList
	        SET    ogl_og_id = @ogl_og_id,
	               ogl_gi_id = @ogl_gi_id,
	               ogl_sku_id = @ogl_sku_id,
	               ogl_num = @ogl_num,
	               ogl_retail_price = @ogl_retail_price,
	               ogl_discount = @ogl_discount,
	               ogl_stock_price = @ogl_stock_price,
	               ogl_money = @ogl_stock_price * @ogl_num,
	               ogl_retail_money = @ogl_retail_price * @ogl_num,
	               ogl_remark = @ogl_remark,
	               ogl_box_num = @ogl_box_num,
	               ogl_pm = @ogl_pm,
				   ogl_erp_id=@ogl_erp_id
	        WHERE  ogl_id = @ogl_id;
	    END
	    SET @start_int=@start_int+1;
	END
	    end
	  else
		begin

				INSERT INTO pos_ogStorageList
				(
					ogl_og_id,ogl_gi_id,ogl_sku_id,ogl_erp_id,
					ogl_num,ogl_discount,
					ogl_retail_price,
					ogl_stock_price,
					ogl_status,
					ogl_box_num,
					ogl_add_time,
					ogl_pm
				)
				SELECT  @og_id, gi_id, sku_id, erp_id,
                        number,
						discount,--折扣
						retailprice,--零售价
                        stockprice,--进货价
						orderstatus,
						box_num,
						GETDATE(),
						pm
				FROM  erp_goodslisttemp WHERE orderguid = @orderguid;

				 UPDATE pos_ogStorage
				 SET    og_status = 2,
						og_audit_man = @og_update_man,
						og_audit_time = GETDATE()
				 WHERE  og_id = @og_id;

				 exec pro_setGoodsPurchasePrice @oo_id=@og_id,@wt=2;

		end


		exec dbo.pro_setPmNumberSum @orderid=@og_id,@erp_id=@og_erp_id ,@stockType=7;

	END
	
	
	


    IF @op_type = '进度终止'
	BEGIN
		
	
	    UPDATE pos_ogStorage
	    SET og_status   = 3
	    WHERE og_id = @og_id;
	END
	
	IF @op_type = '审核单据'
	BEGIN
	    --审核单据
	    UPDATE pos_ogStorage
	    SET    og_status = 2,
	           og_audit_man = @og_update_man,
	           og_audit_time = GETDATE()
	    WHERE  og_id = @og_id;
	END
	
	IF @op_type = '取消审核单据'
	BEGIN
	    --取消审核单据
	    UPDATE pos_ogStorage
	    SET    og_status = 1
	    WHERE  og_id = @og_id;
	END
	
	IF @op_type = '删除单据'
	BEGIN
	    --删除单据
	    UPDATE pos_ogStorage
	    SET    og_status = 0
	    WHERE  og_id = @og_id;

	END
	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE pos_ogStorageList
	    SET    ogl_status = 0
	    WHERE  ogl_id = @ogl_id;

	END
	
	IF @op_type = '批量删除明细'
	BEGIN
	    UPDATE pos_ogStorageList
	    SET    ogl_status = 0
	    WHERE  ogl_og_id = @ogl_og_id
	           AND ogl_add_time = @ogl_add_time
	           AND ogl_gi_id = @ogl_gi_id;
	    
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   pos_ogStorageList AS jt
	           WHERE  jt.ogl_og_id = @ogl_og_id
	                  AND jt.ogl_status = 1
	       )
	    BEGIN
	        UPDATE pos_ogStorage
	        SET    og_status = 0
	        WHERE  og_id = @ogl_og_id;
	    END

		
	END
	
	IF @op_type = '执行配货' and 1=2
	BEGIN
	    SET @result = '';
	    --配货单
	    --查询补货明细,使用游标方式,循环调用配货存储过程
	    /*
	    1.单击审核按钮，生成配货单（数据副本），处于删除状态，得到配货单的主键值。
	    2.有了主键值，使用配货编辑页面，使用里面的增删改功能
	    3.配货编辑页面的保存按钮要判断是从补货审核那边过来的，是的话，更新配货单的状态为审核状态。
	    4.为此，就把配货单生成了。
	    */
	    
	    --配货单自增主键
	    DECLARE @fristflag INT = 0;
	    BEGIN
	    	BEGIN TRANSACTION
	    	
	    	SELECT @og_type=fd.og_type 
	    	FROM pos_ogStorage fd WHERE fd.og_id=@og_id
	    	
	    	DECLARE @pa_ogl_id INT = 0;
	    	DECLARE @pa_ogl_gi_id INT = 0;
	    	DECLARE @pa_ogl_sku_id INT = 0;
	    	DECLARE @pa_ogl_num INT = 0;
	    	DECLARE @pa_ogl_retail_price DECIMAL(9, 2) = 0;
	    	DECLARE @pa_ogl_ogl_discount DECIMAL(9, 2) = 0;
	    	DECLARE @pa_ogl_stock_pricee DECIMAL(9, 2) = 0;
	    	DECLARE @pa_ogl_money DECIMAL(9, 2) = 0;
	    	DECLARE @pa_ogl_sample_no VARCHAR(50) = '';
	    	DECLARE @pa_ogl_is_gift INT = 0;
	    	DECLARE @pa_ogl_remark VARCHAR(50) = '';
	    	DECLARE @pa_ogl_status INT = 1;
	    	DECLARE @pa_ogl_add_time DATETIME;
	    	DECLARE @now DATETIME = GETDATE();
	    	DECLARE @old_add_time DATETIME = '2001-01-01';
	    	DECLARE @prev_now DATETIME;
	    	DECLARE @old_gi_id INT = 0;
	    	DECLARE delsopcor CURSOR  
	    	FOR
	    	    (
	    	        SELECT ogl_id,
	    	               ogl_gi_id,
	    	               ogl_sku_id,
	    	               (ogl_num - ISNULL(all_num, 0)) AS ogl_num,
	    	               ogl_retail_price,
	    	               ogl_discount,
	    	               ogl_stock_price,
	    	               ogl_money,
	    	               ogl_remark,
	    	               ogl_status,
	    	               ogl_add_time
	    	        FROM   pos_ogStorageList
	    	               LEFT JOIN vi_allocation_sku_outed AS al
	    	                    ON  al.all_source_id = ogl_id
	    	                    AND al.all_source_add_time = ogl_add_time
	    	                    AND al.all_sku_id = ogl_sku_id
	    	        WHERE  ogl_status > 0
	    	               AND ogl_og_id = @og_id
	    	    )
	    	
	    	OPEN delsopcor
	    	FETCH NEXT FROM delsopcor INTO @pa_ogl_id,@pa_ogl_gi_id,@pa_ogl_sku_id,
	    	@pa_ogl_num,@pa_ogl_retail_price,@pa_ogl_ogl_discount,@pa_ogl_stock_pricee,
	    	@pa_ogl_money,@pa_ogl_remark,@pa_ogl_status,@pa_ogl_add_time
	    	WHILE @@FETCH_STATUS = 0
	    	BEGIN
	    	    IF (
	    	           @old_add_time != @pa_ogl_add_time
	    	           OR @old_gi_id != @pa_ogl_gi_id
	    	       )
	    	    BEGIN
	    	        SET @now = GETDATE();
	    	        SET @old_add_time = @pa_ogl_add_time;
	    	        SET @old_gi_id = @pa_ogl_gi_id;
	    	        IF (@now = @prev_now)
	    	        BEGIN
	    	            WHILE @now = @prev_now
	    	            BEGIN
	    	                SET @now = GETDATE();
	    	            END
	    	        END
	    	    END
	    	    
	    	    EXEC pro_pos_allocation_op
	    	         @al_id = @fristflag,
	    	         --@al_update_man=0, 
	    	         @al_update_time = @now,
	    	         @al_type = @og_type,
	    	         @al_source = 5,
	    	         --@al_butype=1,
	    	         @al_source_id = @og_id,
	    	         @all_gi_id = @pa_ogl_gi_id,
	    	         @all_sku_id = @pa_ogl_sku_id,
	    	         @all_num = @pa_ogl_num,
	    	         @al_sh_id = @og_sh_id,
	    	         @al_ci_id = @og_ci_id,
	    	         @all_al_id = @fristflag,
	    	         @all_retail_price = @pa_ogl_retail_price,
	    	         @all_discount = @pa_ogl_ogl_discount,
	    	         @all_stock_price = @pa_ogl_stock_pricee,
	    	         @all_money = @pa_ogl_money,
	    	         @all_gift = @pa_ogl_is_gift,
	    	         @all_add_time = @now,
	    	         @al_date = @now,
	    	         @all_source_id = @pa_ogl_id,
	    	         @al_order_man = @og_add_man,
	    	         @al_add_man = @og_add_man,
	    	         @al_add_time = @now,
	    	         @all_source_add_time = @pa_ogl_add_time,
	    	         @op_type = '添加修改单据,明细',
	    	         @dhtype = 1,
	    	         @result = @result OUT 
	    	    
	    	    SET @prev_now = @now;
	    	    IF @result = '0'
	    	    BEGIN
	    	        CLOSE delsopcor
	    	        DEALLOCATE delsopcor
	    	        IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	    	        RETURN 1;
	    	    END
	    	    ELSE
	    	    BEGIN
	    	        IF @fristflag = '0'
	    	        BEGIN
	    	            SET @fristflag = @result;
	    	        END
	    	    END
	    	    FETCH NEXT FROM delsopcor INTO @pa_ogl_id,@pa_ogl_gi_id,@pa_ogl_sku_id,
	    	    @pa_ogl_num,@pa_ogl_retail_price,@pa_ogl_ogl_discount,@pa_ogl_stock_pricee,
	    	    @pa_ogl_money,@pa_ogl_remark,@pa_ogl_status,@pa_ogl_add_time
	    	END
	    	CLOSE delsopcor
	    	DEALLOCATE delsopcor
	    	SET @result = CONVERT(VARCHAR(50), @fristflag);
	    	
	    	
	    	UPDATE pos_allocation
	    	SET    al_status = 0,
	    	       al_audit_man = @og_add_man,
	    	       al_audit_time = @now
	    	WHERE  al_id = @fristflag;
	    	
	    	
	    	--完成事务
	    	IF @@TRANCOUNT > 0 COMMIT TRANSACTION
	    END
	END
	
	IF @op_type = '执行采购' and 1=2
	BEGIN
	    SET @result = '';
	    --配货单
	    --查询补货明细,使用游标方式,循环调用配货存储过程
	    
	    DECLARE @fflag INT = 0;
	    BEGIN
	    	BEGIN TRANSACTION
	    	DECLARE @p_ogl_id INT = 0;
	    	DECLARE @p_ogl_gi_id INT = 0;
	    	DECLARE @p_ogl_sku_id INT = 0;
	    	DECLARE @p_ogl_num INT = 0;
	    	DECLARE @p_ogl_retail_price DECIMAL(9, 2) = 0;
	    	DECLARE @p_ogl_ogl_discount DECIMAL(9, 2) = 0;
	    	DECLARE @p_ogl_stock_pricee DECIMAL(9, 2) = 0;
	    	
	    	DECLARE @gi_purchase DECIMAL(9, 2) = 0;
	    	
	    	DECLARE @p_ogl_money DECIMAL(9, 2) = 0;
	    	DECLARE @p_ogl_sample_no VARCHAR(50) = '';
	    	DECLARE @p_ogl_is_gift INT = 0;
	    	DECLARE @p_ogl_remark VARCHAR(50) = '';
	    	DECLARE @p_ogl_status INT = 1;
	    	DECLARE @p_ogl_add_time DATETIME;
	    	DECLARE @nowtime DATETIME = GETDATE();
	    	DECLARE @old_add_time1 DATETIME = '2001-01-01';
	    	DECLARE @prev_now1 DATETIME;
	    	DECLARE @old_gi_id1 INT = 0;
	    	
	    	DECLARE @pll_box_num INT = 0;
	    	DECLARE @pll_pm VARCHAR(500) = '';
	    	
	    	DECLARE delsopcor CURSOR  
	    	FOR
	    	    (
	    	        SELECT fd.*,
	    	               bg.gi_purchase
	    	        FROM   (
	    	                   SELECT ogl_id,
	    	                          ogl_gi_id,
	    	                          ogl_sku_id,
	    	                          (ogl_num - ISNULL(pll_num, 0)) 
	    	                          AS ogl_num,
	    	                          ogl_retail_price,
	    	                          ogl_discount,
	    	                          ogl_stock_price,
	    	                          ogl_money,
	    	                          ogl_remark,
	    	                          ogl_status,
	    	                          ogl_add_time,
	    	                          ogl_pm,
	    	                          ogl_box_num
	    	                   FROM   pos_ogStorageList
	    	                          LEFT JOIN vi_j_purchaseStorage_sku_outed AS 
	    	                               al
	    	                               ON  al.pll_source_id = ogl_id
	    	                               AND al.pll_source_add_time = 
	    	                                   ogl_add_time
	    	                               AND al.pll_sku_id = ogl_sku_id
	    	                   WHERE  ogl_og_id = @og_id
	    	                          AND ogl_status > 0
	    	               ) AS fd
	    	               INNER JOIN b_goodsinfo bg
	    	                    ON  fd.ogl_gi_id = bg.gi_id
	    	    )
	    	
	    	OPEN delsopcor
	    	FETCH NEXT FROM delsopcor INTO @p_ogl_id,@p_ogl_gi_id,@p_ogl_sku_id,
	    	@p_ogl_num,@p_ogl_retail_price,@p_ogl_ogl_discount,@p_ogl_stock_pricee,
	    	@p_ogl_money,@p_ogl_remark,@p_ogl_status,@p_ogl_add_time,@pll_pm,@pll_box_num,
	    	@gi_purchase
	    	WHILE @@FETCH_STATUS = 0
	    	BEGIN
	    	    IF (
	    	           @old_add_time1 != @p_ogl_add_time
	    	           OR @old_gi_id1 != @p_ogl_gi_id
	    	       )
	    	    BEGIN
	    	        SET @nowtime = GETDATE();
	    	        SET @old_add_time1 = @p_ogl_add_time;
	    	        SET @old_gi_id1 = @p_ogl_gi_id;
	    	        IF (@nowtime = @prev_now1)
	    	        BEGIN
	    	            WHILE @nowtime = @prev_now1
	    	            BEGIN
	    	                SET @nowtime = GETDATE();
	    	            END
	    	        END
	    	    END
	    	    
	    	    SET @p_ogl_ogl_discount = @gi_purchase / @p_ogl_retail_price;
	    	    EXEC pro_j_purchaseStorage_op
	    	         
	    	         @pll_box_num = @pll_box_num,
	    	         @pll_pm = @pll_pm,
	    	         @pl_id = @fflag,
	    	         @pl_update_time = @nowtime,
	    	         @pl_source = 1,
	    	         @pl_source_id = @og_id,
	    	         @pll_gi_id = @p_ogl_gi_id,
	    	         @pll_sku_id = @p_ogl_sku_id,
	    	         @pll_num = @p_ogl_num,
	    	         --@pl_ci_id=@og_ci_id, 
	    	         @pll_pl_id = @fflag,
	    	         @pll_retail_price = @p_ogl_retail_price,
	    	         @pll_discount = @p_ogl_ogl_discount,
	    	         --@pll_stock_price=@p_ogl_stock_pricee,
	    	         --@pll_stock_price=100, 
	    	         @pll_stock_price = @gi_purchase,
	    	         @pll_money = @p_ogl_money,
	    	         @pll_add_time = @nowtime,
	    	         @pl_date = @nowtime,
	    	         @pll_source_id = @p_ogl_id,
	    	         @pl_order_man = @og_order_man,
	    	         @pl_add_man = @og_add_man,
	    	         @pl_add_time = @nowtime,
	    	         @pll_source_add_time = @p_ogl_add_time,
	    	         @op_type = '添加修改单据,明细',
	    	         @dhtype = 1,
	    	         @result = @result OUT 
	    	    
	    	    SET @prev_now1 = @nowtime;
	    	    IF @result = '0'
	    	    BEGIN
	    	    	
	    	        --set @result='失败!';
	    	        
	    	        --操作失败
	    	        CLOSE delsopcor
	    	        DEALLOCATE delsopcor
	    	        IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	    	        RETURN 1;
	    	        
	    	    END
	    	    ELSE
	    	    BEGIN
	    	        IF @fflag = '0'
	    	        BEGIN
	    	            SET @fflag = @result;
	    	        END
	    	    END
	    	    FETCH NEXT FROM delsopcor INTO @p_ogl_id,@p_ogl_gi_id,@p_ogl_sku_id,
	    	    @p_ogl_num,@p_ogl_retail_price,@p_ogl_ogl_discount,@p_ogl_stock_pricee,
	    	    @p_ogl_money,@p_ogl_remark,@p_ogl_status,@p_ogl_add_time,@pll_pm,
	    	    @pll_box_num,@gi_purchase
	    	END
	    	CLOSE delsopcor
	    	DEALLOCATE delsopcor
	    	SET @result = CONVERT(VARCHAR(50), @fflag);
	    	
	    	UPDATE j_purchaseStorage
	    	SET    pl_status = 0,
	    	       pl_audit_man = @og_add_man,
	    	       pl_audit_time = @nowtime
	    	WHERE  pl_id = @fflag;
	    	
	    	--完成事务
	    	IF @@TRANCOUNT > 0 COMMIT TRANSACTION
	    END
	END
	
	IF @op_type = '添加修改单据,明细'
	   OR @need_update = 1
	   OR @op_type = '修改单据'
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.og_date
	    FROM   pos_ogStorage AS jt
	    WHERE  jt.og_id = @og_id;
	    IF @old_order_date != @og_date
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	    UPDATE pos_ogStorage
	    SET    og_no = @og_no,
	           og_date = @og_date,
	           og_type = @og_type,
	           og_ci_id = @og_ci_id,
	           og_sh_id = @og_sh_id,
	           og_out_date = @og_out_date,
	           og_trans = @og_trans,
	           og_business = @og_business,
	           og_update_man = @og_update_man,
	           og_update_time = @og_update_time,
	           og_refe_no = @og_refe_no,
	           og_order_man = @og_order_man,
			   og_totalboxnum=vi.ogl_boxnum,
	           og_is_lock = @og_is_lock,
	           og_remark = @og_remark
        from pos_ogStorage og,vi_pos_ogStorageList_sum vi
	    WHERE  og_id = @og_id and og.og_id=vi.ogl_og_id;
	    
	    IF(SELECT fd.og_status FROM pos_ogStorage  fd 
	       WHERE fd.og_id=@og_id)=0
	    BEGIN
	    	UPDATE pos_ogStorage
	        SET    og_status = 1
	        WHERE  og_id = @og_id;
	    END    
	    
	    
	END
	
	IF @isInsert = 1
	   --OR @old_order_date_is_changed = 1
	BEGIN
	    --凭证号生成
	    --更新凭证号 
	    DECLARE @tableName VARCHAR(50) = 'pos_ogStorage'
	    DECLARE @idField VARCHAR(50) = 'og_id'
	    DECLARE @idValue INT = @og_id;
	    
	    DECLARE @dateField VARCHAR(50) = 'og_date'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @og_date, 23)
	    
	    DECLARE @noField VARCHAR(50) = 'og_vo'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN
	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	        @idField,
	        @idValue,
	        @dateField,
	        @dateValue,
	        @noField,
	        @prevTxt,
	        @outno OUTPUT,0,@og_cp_id
	        
	        BEGIN TRY
	        	--更新
	        	UPDATE pos_ogStorage
	        	SET    og_vo = @outno
				,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)
	        	WHERE  og_id = @og_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
			PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
	        END CATCH
	    END
	END
	


    exec dbo.pro_mergesingleSums @orderid=@og_id ,@stockType=7;
	
	IF @@ERROR <> 0
	BEGIN
	    SET @result = '0';
	    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @og_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细'
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @ogl_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END
END
go

