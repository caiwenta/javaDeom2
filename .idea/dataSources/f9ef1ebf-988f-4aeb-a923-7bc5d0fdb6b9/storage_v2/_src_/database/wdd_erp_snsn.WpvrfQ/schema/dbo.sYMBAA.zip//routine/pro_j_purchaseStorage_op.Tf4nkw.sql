


CREATE PROC [dbo].[pro_j_purchaseStorage_op]

@pl_tax_point decimal(15, 2)=0,
@pl_tax_money decimal(15, 2)=0,

@pll_box_num INT = 0,
@pll_pm VARCHAR(500) = '',
--主键  
@pl_id INT = 0,  
@pl_erp_id INT = 0,  
@pll_erp_id INT = 0,
--单据号  
@pl_no VARCHAR(50) = '',  
--采购日期  
@pl_date DATETIME = '2014-11-19',  
--供应商主键  
@pl_ci_id INT = 0,  
--仓库主键  
@pl_st_id INT = 0,  
--货运单号  
@pl_freight_no VARCHAR(50) = '',  
--快递公司  
@pl_express INT = 0,  
--采购金额  
@pl_money DECIMAL(18, 2) = 0,  
--采购数量  
@pl_num INT = 0,  
--费用  
@pl_cost DECIMAL(18, 2) = 0,  
--运费  
@pl_fright DECIMAL(18, 2) = 0,  
--制单人主键  
@pl_order_man INT = 0,  
--添加人主键  
@pl_add_man INT = 0,  
--添加时间  
@pl_add_time DATETIME = '2014-11-19',  
--修改人主键  
@pl_update_man INT = 0,  
--修改时间  
@pl_update_time DATETIME = '2014-11-19',  
--审核人主键  
@pl_audit_man INT = 0,  
--审核时间  
@pl_audit_time DATETIME = '2014-11-19',  
--备注
@pl_remark VARCHAR(200) = '',
--自动匹配订单
@pl_ismatching int =0, 

--主键  
@pll_id INT = 0,  
--采购主键  
@pll_pl_id INT = 0,  
--商品主键  
@pll_gi_id INT = 0,  
--商品sku主键  
@pll_sku_id INT = 0,  
--采购数量  
@pll_num INT = 0,  
--零售价  
@pll_retail_price DECIMAL(18, 2) = 0,  
--折率  
@pll_discount DECIMAL(18, 2) = 0,  
--采购价  
@pll_stock_price DECIMAL(18, 2) = 0,  
--采购金额  
@pll_money DECIMAL(18, 2) = 0,  
--添加时间  
@pll_add_time DATETIME = '2014-11-19', 
--来源类型 
@pl_source INT = 0,
--来源id 
@pl_source_id INT = 0,
--来源明细id
@pll_source_id INT = 0,
--来源添加时间
@pll_source_add_time DATETIME = '2014-11-19', 
--是否订货
@pl_dhtype INT = 0,
--是否订货存储过程
@dhtype INT = 0,
--公司主键
@pl_cp_id INT = 0,
--部门主键
@pl_di_id INT = 0,
--采购方式
@pl_type int=0,

--是否是退货  0-采购 1-采购退货 2-裁床
@pl_pltype int=0,


--保存字符串
@savestr VARCHAR(MAX) = '' ,
--前台排出的商品(单击清空明细按钮时会记录商品主键,添加时间)
@not_in_ids VARCHAR(MAX) = '',
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  

@order_id  VARCHAR(MAX)='',
@good_id VARCHAR(MAX)='',
@pm VARCHAR(MAX)='',
--供应商积分开关
@isupplierintegral int=0,

--生产日期
@pddate VARCHAR(80) = '',
--商品日期
@pdgddate  VARCHAR(80) = '',

--积分
@pll_integral numeric(18,2)=0,
--总积分
@pll_totalintegral numeric(18,2)=0,


--结果  
@result VARCHAR(100) = '' OUT,
--运费
@pl_freight DECIMAL(15, 2) = 0,

--预计交货日期
@pl_enddate DATETIME = '2014-11-19',
 --唯一guid 
@orderguid VARCHAR(500)='',
@isModifyEndNum int=0  --是否修改终止数量
AS
BEGIN
	
	
	
	--终止标识
	DECLARE @op_type_end VARCHAR(100)='';
	IF @op_type='添加修改单据,明细,终止操作'
	BEGIN
		SET @op_type='添加修改单据,明细';
		SET @op_type_end='添加修改单据,明细,终止操作';
	END
	
	
	
	
	select top 1 @pll_add_time=j.pll_add_time FROM j_purchaseStorageList j WHERE j.pll_pl_id=@pll_pl_id and j.pll_gi_id= @pll_gi_id and j.pll_pm=@pll_pm ;
	
	DECLARE @sql NVARCHAR(MAX) = '';
	
	--是否添加单据
	DECLARE @isInsert INT = 0;
	--是否需要更新单据
	DECLARE @need_update INT = 0;
	--旧的单据日期
	DECLARE @old_order_date DATETIME;
	--单据日期是否更改
	DECLARE @old_order_date_is_changed INT = 0;

	--凭证号前缀
	DECLARE @myprevTxt VARCHAR(50);
	if @pl_pltype=2
	begin 
	set @myprevTxt = 'CC';
	end
	else
	begin
	set @myprevTxt = 'CG';
	end

	BEGIN TRAN
	IF @op_type = '添加修改单据,明细'
	BEGIN
	    IF @pl_id = 0 AND @op_type_end=''
	    BEGIN
	        IF @pl_cp_id = 0
	        BEGIN
	            --员工信息表
	            --通过添加人得到公司主键,部门主键
	            SELECT @pl_cp_id = fd.si_company,
	                   @pl_di_id = fd.si_did
	            FROM   b_stafftinfo fd
	            WHERE  fd.si_id = @pl_add_man
	        END
	        
	        
	        --添加单据
	        INSERT INTO j_purchaseStorage
	          (
	            pl_vo,
	            pl_no,
	            pl_date,
	            pl_ci_id,
	            pl_st_id,
	            pl_freight_no,
	            pl_express,
	            pl_money,
	            pl_num,
	            pl_cost,
	            pl_fright,
	            pl_status,
	            pl_order_man,
	            pl_add_man,
	            pl_add_time,
	            pl_update_man,
	            pl_update_time,
	            pl_remark,
	            pl_source,
	            pl_source_id,
	            pl_cp_id,
	            pl_di_id,
	            pl_type,
	            pl_ismatching,
	            pl_erp_id,
				pl_pltype,
				pl_freight,
				pl_tax_point,
				pl_tax_money,
				pl_enddate
	          )
	        VALUES
	          (
	            NEWID(),
	            @pl_no,
	            @pl_date,
	            @pl_ci_id,
	            @pl_st_id,
	            @pl_freight_no,
	            @pl_express,
	            @pl_money,
	            @pl_num,
	            @pl_cost,
	            @pl_fright,
	            1,
	            @pl_order_man,
	            @pl_add_man,
	            @pl_add_time,
	            @pl_update_man,
	            @pl_update_time,
	            @pl_remark,
	            @pl_source,
	            @pl_source_id,
	            @pl_cp_id,
	            @pl_di_id,
	            @pl_type,
	            @pl_ismatching,
	            @pl_erp_id,
				@pl_pltype,
				@pl_freight,
				@pl_tax_point,
				@pl_tax_money,
				@pl_enddate
	          );
	        SET @pl_id = SCOPE_IDENTITY();
	        
	        SET @pll_pl_id = @pl_id;
	        SET @isInsert = 1;
	    END
	    ELSE
	    BEGIN
	        SET @need_update = 1;
	    END
	    
	
	    --保存字符串用 | 作为分隔符,此变量存储分割后的具体项
	    DECLARE @savestr_item VARCHAR(MAX) = '';
	    --起始数值,每次循环后递增
	    DECLARE @start_int INT = 1;
	    --终止数值
	    DECLARE @end_int INT = 1;
	    IF @savestr != '' 
	       --AND 1=2
	    BEGIN
	        --得到明细数量
	        --即要循环的次数
	        SELECT @end_int = (LEN(@savestr) -LEN(REPLACE(@savestr, '|', '')))
	    END
	    ELSE
	    BEGIN
	        IF @pl_source = 1
	        BEGIN
	            --采购入库,采购退货
	            --@savestr为空,整单执行,使其不符合条件
	            SET @start_int = @end_int + 1;
	        END
	    END
	    
	    DECLARE @add_time_not_in VARCHAR(MAX)='';
	    SELECT @add_time_not_in=NEWID();


		DECLARE @temp_pll TABLE(
				ogl_og_id         INT             ,
				ogl_gi_id         INT             ,
				ogl_sku_id        INT             ,
				ogl_num           INT             ,
				ogl_discount      DECIMAL (10, 2) ,
				ogl_retail_price  DECIMAL (10, 2) ,
				ogl_stock_price   DECIMAL (10, 2) ,
				ogl_status        INT             ,
				ogl_id int,
				ogl_add_time      DATETIME        ,
				ogl_box_num       INT             ,
				ogl_pm            VARCHAR (500)   ,
				ogl_erp_id int,
				ogl_boxbynum int
				);

		if @orderguid=''
		begin	    
	    WHILE @start_int <= @end_int
	    BEGIN
	        --动态赋值
	        IF @savestr != ''
	        BEGIN
	            SET @savestr_item = dbo.Get_StrArrayStrOfIndex(@savestr, '|', @start_int);
	            IF (RTRIM(LTRIM(@savestr_item)) = '')
	            BEGIN
	                BREAK;
	            END
	            ELSE
	            BEGIN
	                IF @pl_source = 0 
	                BEGIN
	                    SET @pll_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
	                    
	                    SET @pll_gi_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
	                    
	                    SET @pll_sku_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3));
	                    
	                    SET @pll_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
	                    
	                    SET @pll_retail_price = CONVERT(
	                            DECIMAL(10, 2),
	                            dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5)
	                        );
	                    
	                    SET @pll_stock_price = CONVERT(
	                            DECIMAL(10, 2),
	                            dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6)
	                        );
	                    
	                    SET @pll_discount = CONVERT(
	                            DECIMAL(10, 2),
	                            dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7)
	                        );
	                    
	                    SET @pll_box_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9));
	                    
	                    SET @pll_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 10);

	                END
	                ELSE 
	                IF @pl_source = 1
	                BEGIN
	                    
	                    --采购入库,采购退货
	                    SET @pll_id = 0;
	                    SET @pll_source_id = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 1));
	                    SET @pll_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 2));
	                    SET @pll_source_add_time = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 3);
	                    IF (dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4) = '')
	                    BEGIN
	                        --没规格
	                        SELECT @pll_gi_id = posl.ogl_gi_id,
	                               @pll_sku_id = posl.ogl_sku_id,
	                               @pll_retail_price = posl.ogl_retail_price,
	                               @pll_discount = posl.ogl_discount,
	                               @pll_stock_price = posl.ogl_stock_price
	                        FROM   pos_ogStorageList AS posl
	                        WHERE  posl.ogl_id = @pll_source_id
	                    END
	                    ELSE
	                    BEGIN

	                        SET @pll_box_num = CONVERT(INT, dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 4));
	                        SET @pll_pm = dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 5);
	                        SET @pll_retail_price = CONVERT(
	                                DECIMAL(10, 2),
	                                dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 6)
	                            );
	                        
	                        SET @pll_stock_price = CONVERT(
	                                DECIMAL(10, 2),
	                                dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 7)
	                            );
	                        
	                        SET @pll_discount = CONVERT(
	                                DECIMAL(10, 2),
	                                dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 8)
	                            );
	                        
	                        --商品主键
	                        SET @pll_gi_id = CONVERT(
	                                DECIMAL(10, 2),
	                                dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 9)
	                            );
	                        --sku主键
	                        SET @pll_sku_id = CONVERT(
	                                DECIMAL(10, 2),
	                                dbo.Get_StrArrayStrOfIndex(@savestr_item, ',', 10)
	                            );

	                    END

						INSERT INTO @temp_pll(
						    ogl_id,
							ogl_gi_id,
							ogl_sku_id,
							ogl_num,
							ogl_discount,
							ogl_retail_price,
							ogl_stock_price,
							ogl_status,
							ogl_add_time,
							ogl_box_num,
							ogl_pm,
							ogl_erp_id)
							VALUES(@pll_source_id,@pll_gi_id,@pll_sku_id,@pll_num,@pll_discount,
							@pll_retail_price,@pll_stock_price,1,@pll_source_add_time,@pll_box_num,@pll_pm,@pll_erp_id);

						SET @start_int=@start_int+1;

						CONTINUE;

	                END
	            END
	        END
	        
	        IF @pll_id = 0 
	        BEGIN
	        	select 
				@pll_id=pll_id,
				@pll_num=pll_num+@pll_num,
				@pll_box_num=pll_box_num+@pll_box_num
				FROM j_purchaseStorageList jpsl WHERE pll_pl_id=@pll_pl_id AND pll_gi_id= @pll_gi_id  AND pll_sku_id= @pll_sku_id and pll_status=1 and isnull(jpsl.pll_pm,'')=isnull(@pll_pm,'') ;
	        END

	        IF @pddate=''
	        BEGIN
	    	set @pddate=NULL
	    	SET @pdgddate=NULL
	        END
			
	        if ISNUMERIC(@pdgddate)=1
		     begin
		     SET @pdgddate=NULL
		     end


	        IF @pll_id = 0 
	        BEGIN
	        	IF @op_type_end=''
	    		BEGIN
	        	
	            INSERT INTO j_purchaseStorageList
	              (
	                pll_pl_id,
	                pll_gi_id,
	                pll_sku_id,
	                pll_num,
	                pll_retail_price,
	                pll_discount,
	                pll_stock_price,
	                pll_money,
	                pll_status,
	                pll_add_time,
	                pll_source_id,
	                pll_source_add_time,
	                pll_box_num,
	                pll_pm,
				    pll_pddate,
				    pll_pdgddate,
				    pll_integral,
				    pll_totalintegral,pll_erp_id
	              )
	            VALUES
	              (
	                @pll_pl_id,
	                @pll_gi_id,
	                @pll_sku_id,
	                @pll_num,
	                @pll_retail_price,
	                @pll_discount,
	                @pll_stock_price,
	                @pll_stock_price * @pll_num,
	                1,
	                @pll_add_time,
	                @pll_source_id,
	                @pll_source_add_time,
	                @pll_box_num,
	                @pll_pm,
					@pddate,
					@pdgddate,
					@pll_integral,
					@pll_totalintegral,@pll_erp_id
	              );
	            SET @pll_id = SCOPE_IDENTITY();
	            
	            END
	    		ELSE
	    		BEGIN
	    			
	    		INSERT INTO j_add_time_record
	    		(
	    			a_add_time,
	    			a_guid
	    		)
	    		VALUES
	    		(
	    			@pll_source_add_time,
	    			@add_time_not_in
	    		)
	    		IF @isModifyEndNum=1 --修改终止数量
				BEGIN 
				    UPDATE pos_ogStorageList
	    			SET ogl_pause_num_pll = @pll_num,
					     ogl_pause_box_num_pll=@pll_box_num
	    			WHERE ogl_id=@pll_source_id; 
				END
				ELSE
				BEGIN
	    			UPDATE pos_ogStorageList
	    			SET ogl_pause_num_pll =ISNULL(ogl_pause_num_pll,0)+ @pll_num,
					    ogl_pause_box_num_pll=ogl_pause_box_num_pll+@pll_box_num
	    			WHERE ogl_id=@pll_source_id;
	    		END
	    		
	    		END
	        END
	        ELSE
	        BEGIN
	            UPDATE j_purchaseStorageList
	            SET    pll_pl_id = @pll_pl_id,
	                   pll_gi_id = @pll_gi_id,
	                   pll_sku_id = @pll_sku_id,
	                   pll_num = @pll_num,
	                   pll_retail_price = @pll_retail_price,
	                   pll_discount = @pll_discount,
	                   pll_stock_price = @pll_stock_price,
	                   pll_money = @pll_stock_price * @pll_num,
	                   pll_box_num = @pll_box_num,
	                   pll_pm = @pll_pm,
					   pll_pddate=@pddate,
					   pll_integral=@pll_integral,
				       pll_totalintegral=@pll_totalintegral
	            WHERE  pll_id = @pll_id;
	        END

	        SET @start_int = @start_int + 1;
	    END
  end
else
 begin

         MERGE INTO j_purchaseStorageList AS ta
     USING
     (
         SELECT  @pl_id as pll_pl_id, 
                 gi_id, 
                 sku_id,
                 pm,erp_id,
                 number,
                 discount,--折扣
				 retailprice,--零售价  importprices,--销售价
				 purchase,--进货价   stockprice,--供货价
                 orderstatus,
                 box_num
         FROM  erp_goodslisttemp WHERE orderguid = @orderguid
	)as so 
	on ta.pll_gi_id=so.gi_id 
	AND ta.pll_sku_id=so.sku_id 
	and ta.pll_pl_id=so.pll_pl_id 
	and ta.pll_status=1
		WHEN MATCHED THEN  UPDATE
        SET  
		 ta.pll_num += so.number,
		 ta.pll_money=((ta.pll_num+so.number)*so.purchase)  --ta.pll_money=((ta.pll_num+so.number)*so.stockprice)
		WHEN NOT MATCHED THEN
		INSERT (pll_pl_id , 
				pll_gi_id , 
				pll_sku_id ,
				pll_pm ,
				pll_erp_id ,
				pll_num , 
				pll_discount , --折扣
				pll_retail_price , --零售价
				pll_stock_price, --进货价 
				pll_money,--采购金额
				pll_status ,
				pll_box_num,
				pll_add_time
				)
		 VALUES
				( 
				 so.pll_pl_id, 
				 so.gi_id, 
				 so.sku_id,
				 so.pm,
				 so.erp_id,
				 so.number,
				 so.discount,--折扣
				 so.retailprice,--零售价  so.importprices,--销售价
				 so.purchase,--进货价    so.stockprice,--供货价
				 so.number*so.purchase,--入库金额   so.number*so.stockprice
				 so.orderstatus,
				 so.box_num,
				 (SELECT (CASE WHEN addtime IS NULL THEN nows ELSE addtime END) FROM(
				  SELECT GETDATE() as nows,
                 (SELECT TOP 1 pll_add_time FROM j_purchaseStorageList WHERE pll_gi_id=so.gi_id AND pll_pl_id=so.pll_pl_id) AS addtime) AS TT)
				);

		set @isInsert=1;
  end

	    
	    IF @isInsert=1
	    BEGIN
	    	EXEC pro_update_unique_time
				@id = @pl_id,
				@type = '采购'
	    END
	    

	    IF (@pl_source = 1  AND @isInsert=1) OR @op_type_end!=''
	    BEGIN

		--UPDATE @temp_pll SET ogl_og_id=fd2.ogl_og_id
		--FROM @temp_pll fd,pos_ogStorageList fd2
		--WHERE fd.ogl_id=fd2.ogl_id

		DECLARE @gids TABLE(gi_id int);
		DECLARE @orids TABLE(order_id int);
		DECLARE @pms TABLE(order_id varchar(5000));
		declare @tt int;
		if @good_id <>''
		begin
			set @tt=1;
			while @tt<=dbo.Get_StrArrayLength(@good_id,',')
			begin
			insert @gids(gi_id)VALUES(dbo.Get_StrArrayStrOfIndex(@good_id,',',@tt));
			set @tt=@tt+1;
			end
		end
		if @order_id <>''
		begin
			set @tt=1;
			while @tt<=dbo.Get_StrArrayLength(@order_id,',')
			begin
				insert @orids(order_id)VALUES(dbo.Get_StrArrayStrOfIndex(@order_id,',',@tt));
				set @tt=@tt+1;
			end
		end

		if @pm<>''
		begin
			set @tt=1;
			while @tt<=dbo.Get_StrArrayLength(@pm,',')
			begin
				insert @pms(order_id)VALUES(dbo.Get_StrArrayStrOfIndex(@pm,',',@tt));
				set @tt=@tt+1;
			end
		end
		else
		begin
		    insert @pms(order_id)VALUES('');
		end

			SELECT 
			      @pl_id pll_pl_id,
			      fd.ogl_gi_id,
                  fd.ogl_sku_id,
				  (CASE WHEN tp.ogl_gi_id IS NULL THEN
                  (fd.ogl_num -ISNULL(ed.pll_num, 0) -ISNULL(fd.ogl_pause_num_pll, 0)) 
				   else
				  tp.ogl_num end )
				  AS ogl_num,
				  (CASE WHEN tp.ogl_gi_id IS NULL THEN fd.ogl_discount else tp.ogl_discount end ) as ogl_discount,
				  (CASE WHEN tp.ogl_gi_id IS NULL THEN fd.ogl_retail_price else tp.ogl_retail_price end ) as ogl_retail_price,
				  (CASE WHEN tp.ogl_gi_id IS NULL THEN fd.ogl_stock_price else tp.ogl_stock_price end ) as ogl_stock_price,
                  fd.ogl_status,
                  fd.ogl_id,
                  fd.ogl_add_time,
				  (CASE WHEN tp.ogl_gi_id IS NULL THEN
                  (isnull(fd.ogl_box_num,0)-isnull(ed.pll_box_num,0)-ogl_pause_box_num_pll) 
				  else
				  tp.ogl_box_num end ) as ogl_box_num,
				  fd.ogl_pm,
				  fd.ogl_erp_id,
				  fd.ogl_boxbynum
				  into #pslist
           FROM   pos_ogStorageList fd
		   inner join @orids odi on fd.ogl_og_id=odi.order_id
		   inner join (SELECT DISTINCT gi_id FROM @gids) gis on gis.gi_id=fd.ogl_gi_id
		   inner join (SELECT DISTINCT order_id FROM @pms) pp on isnull(fd.ogl_pm,'')=isnull(pp.order_id,'')
		   left join @temp_pll tp on fd.ogl_id=tp.ogl_id
           LEFT  JOIN (
                           SELECT 
						          SUM(pll_num) AS pll_num,
								  sum(pll_box_num) as pll_box_num,
                                  pll_source_id
                           FROM   j_purchaseStorageList
                                  INNER JOIN j_purchaseStorage
                                       ON  pll_pl_id = pl_id
                           WHERE  pl_status > 0
                                  AND pll_status > 0
                                  AND pl_source = 1
                                  AND pll_source_add_time > 0
                                  
                           GROUP BY
                                  pll_source_id
                  )
                   ed
			ON  ed.pll_source_id = fd.ogl_id
			where fd.ogl_status>0

			IF @op_type_end=''
	            BEGIN
	        
	        INSERT INTO j_purchaseStorageList
	          (
	            pll_pl_id,
	            pll_gi_id,
	            pll_sku_id,
	            pll_num,
	            pll_discount,
	            pll_retail_price,
	            pll_stock_price,
	            pll_status,
	            pll_source_id,
	            pll_source_add_time,
	            pll_box_num,
	            pll_pm,
				pll_erp_id,
				pll_boxbynum,
				pll_money,pll_add_time
	          )
	        SELECT 
				pll_pl_id,
				ogl_gi_id,
				ogl_sku_id,
				ogl_num,
				ogl_discount,
				ogl_retail_price,
				ogl_stock_price,
				ogl_status,
				ogl_id,
				ogl_add_time,
				ogl_box_num,
				ogl_pm,ogl_erp_id,ogl_boxbynum,
				(ogl_num * ogl_stock_price),getdate() FROM #pslist

	        UPDATE pos_ogStorage SET og_cg_audit=1,og_cg_audit_time=GETDATE(),og_cg_audit_man=@pl_add_man 
			WHERE og_id IN(select order_id from @orids)
	
	        UPDATE j_purchaseStorage
	        SET    pl_status = 2,
	               pl_audit_time = GETDATE(),
	               pl_audit_man = @pl_add_man
	        WHERE  pl_id = @pl_id;
	        
			exec pro_update_unique_time_source @type='采购',@id=@pl_id;

	       END
	       ELSE
	       BEGIN

				IF @isModifyEndNum=1 --修改终止数量
				BEGIN 

				   UPDATE pos_ogStorageList
	            	SET ogl_pause_num_pll =ISNULL(fd2.ogl_num,0),
					    ogl_pause_box_num_pll=fd2.ogl_box_num
	            	FROM pos_ogStorageList fd,#pslist fd2 WHERE
	            	 fd.ogl_id=fd2.ogl_id 
					
				END
				ELSE
				BEGIN
	            	UPDATE pos_ogStorageList
	            	SET ogl_pause_num_pll = ISNULL(ogl_pause_num_pll,0)+ISNULL(fd2.ogl_num,0),
					    ogl_pause_box_num_pll=ogl_pause_box_num_pll+fd2.ogl_box_num
	            	FROM pos_ogStorageList fd,#pslist fd2 WHERE
	            	 fd.ogl_id=fd2.ogl_id 
				
				end

				declare @orderids UDTypeOrderId;
				insert into @orderids(Id) select order_id from @orids;
				exec pro_mergeSums @orderids=@orderids, @stockType=7;--订货采购



	       END
		    
		   drop table #pslist
	    END


		exec dbo.pro_setPmNumberSum @orderid=@pl_id,@erp_id=@pl_erp_id ,@stockType=9;
	END
	
	IF @op_type = '进度终止'
	BEGIN
	    --审核单据
	    UPDATE j_purchaseStorage
	    SET    pl_status = 3
	    WHERE  pl_id = @pl_id;
	END
	
	
	IF @op_type = '审核单据'
	BEGIN
	    --审核单据
	    UPDATE j_purchaseStorage
	    SET    pl_status = 2,
	           pl_audit_man = @pl_update_man,
	           pl_audit_time = GETDATE()
	    WHERE  pl_id = @pl_id;
	END
	
	IF @op_type = '取消审核单据'
	BEGIN
	    --取消审核单据
	    UPDATE j_purchaseStorage
	    SET    pl_status = 1
	    WHERE  pl_id = @pl_id;
	END
	
	IF @op_type = '删除单据'
	BEGIN
	    --删除单据
	    UPDATE j_purchaseStorage
	    SET    pl_status = 0
	    WHERE  pl_id = @pl_id;


	END
	
	IF @op_type = '删除明细'
	BEGIN
	    --删除明细
	    UPDATE j_purchaseStorageList
	    SET    pll_status = 0
	    WHERE  pll_id = @pll_id;
	END
	

	IF @op_type = '批量删除明细'
	BEGIN
	    UPDATE j_purchaseStorageList
	    SET    pll_status = 0
	    WHERE  pll_pl_id = @pll_pl_id
	           AND pll_add_time = @pll_add_time
	           AND pll_gi_id = @pll_gi_id;
	    
	    
	    IF NOT EXISTS(
	           SELECT 1
	           FROM   j_purchaseStorageList AS jt
	           WHERE  jt.pll_pl_id = @pl_id
	                  AND jt.pll_status = 1
	       )
	    BEGIN
	        UPDATE j_purchaseStorage
	        SET    pl_status = 0
	        WHERE  pl_id = @pl_id;

	    END
	END
	

	IF (@op_type = '添加修改单据,明细'
	   OR @need_update = 1
	   OR @op_type = '修改单据') AND @op_type_end=''
	BEGIN
	    --得到旧的单据日期
	    SELECT @old_order_date = jt.pl_date
	    FROM   j_purchaseStorage AS jt
	    WHERE  jt.pl_id = @pl_id;
	    IF @old_order_date != @pl_date
	    BEGIN
	        SET @old_order_date_is_changed = 1;
	    END
	    
	    UPDATE j_purchaseStorage
	    SET    pl_no = @pl_no,
	           pl_date = @pl_date,
	           pl_ci_id = @pl_ci_id,
	           pl_st_id = @pl_st_id,
	           pl_freight_no = @pl_freight_no,
	           pl_express = @pl_express,
	           pl_money = @pl_money,
	           pl_num = @pl_num,
	           pl_cost = @pl_cost,
	           pl_fright = @pl_fright,
	           pl_order_man = @pl_order_man,
	           pl_update_man = @pl_update_man,
	           pl_update_time = @pl_update_time,
	           pl_type=@pl_type,
	           pl_remark = @pl_remark,
	           pl_ismatching=@pl_ismatching,
			   pl_pltype=@pl_pltype,
			   pl_freight = @pl_freight,
			   
			   pl_tax_point = @pl_tax_point,
			   pl_tax_money = @pl_tax_money,
			   
			   pl_enddate = @pl_enddate
			   
	    WHERE  pl_id = @pl_id;
	    
	    IF (
	           SELECT fd.pl_status
	           FROM   j_purchaseStorage fd
	           WHERE  fd.pl_id = @pl_id
	       ) = 0
	    BEGIN
	        UPDATE j_purchaseStorage
	        SET    pl_status = 1
	        WHERE  pl_id = @pl_id;
	    END
	END
	SET @old_order_date_is_changed=0;
	IF (@isInsert = 1
	   OR @old_order_date_is_changed = 1) AND @op_type_end=''
	BEGIN
	    --凭证号生成
	    --更新凭证号 
	    DECLARE @tableName VARCHAR(50) = 'j_purchaseStorage'
	    DECLARE @idField VARCHAR(50) = 'pl_id'
	    DECLARE @idValue INT = @pl_id;
	    
	    DECLARE @dateField VARCHAR(50) = 'pl_date'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @pl_date, 23)
	    
	    DECLARE @noField VARCHAR(50) = 'pl_vo'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    DECLARE @outno VARCHAR(100) = ''
	    DECLARE @while INT = 0;
	    WHILE @while = 0
	    BEGIN
	        --得到凭证号
	        EXECUTE [pro_gen_orderNo]@tableName,
	        @idField,
	        @idValue,
	        @dateField,
	        @dateValue,
	        @noField,
	        @prevTxt,
	        @outno OUTPUT,
	        0,
	        @pl_cp_id
	        
	        BEGIN TRY
	        	--更新
	        	UPDATE j_purchaseStorage
	        	SET    pl_vo = @outno
				,pzone = dbo.Get_StrArrayStrOfIndex(@outno,'-',1),
		        pztwo = dbo.Get_StrArrayStrOfIndex(@outno,'-',2),
		        pzthree = dbo.Get_StrArrayStrOfIndex(@outno,'-',3)

	        	WHERE  pl_id = @pl_id;
	        	
	        	--更新成功,赋值,结束循环
	        	SET @while = 1;
	        END TRY
	        BEGIN CATCH
			PRINT '';
	        	----发生错误,判断错误类型
	        	--IF CHARINDEX('重复键', ERROR_MESSAGE(), 0) = 0
	        	--BEGIN
	        	--    --不是发生重复的错误
	        	--    --赋值,结束循环
	        	--    SET @while = 1;
	        	--END
	        END CATCH
	    END
	END
	
	--更新数量,金额
	UPDATE j_purchaseStorage
	SET    
	       pl_totalboxnum=fd.pll_boxnum,
	       pl_num = fd.pll_num,
	       pl_money = fd.pl_money
	FROM   j_purchaseStorage AS jps,
	        vi_j_purchaseStorageList_sum AS fd
	WHERE  fd.pll_pl_id = jps.pl_id and jps.pl_id=@pl_id
	
	
	UPDATE j_purchaseStorageList
	SET    pll_source_add_time = NULL
	FROM   j_purchaseStorageList fd,
	       (
	           SELECT fd2.pll_id
	           FROM   j_purchaseStorage fd
	                  INNER JOIN j_purchaseStorageList fd2
	                       ON  fd.pl_id = fd2.pll_pl_id
	                       AND fd.pl_source_id = 0
	                       AND fd2.pll_source_add_time IS NOT NULL
	       ) AS fd2
	WHERE  fd.pll_id = fd2.pll_id and fd.pll_pl_id=@pl_id
	
	
		
	IF(@op_type = '添加修改单据,明细' and @pl_source = 1 and @pl_tax_point>0)
	BEGIN

	UPDATE j_purchaseStorage SET 
	pl_tax_money=@pl_tax_point* (SELECT SUM(pll_money) FROM vi_j_purchaseStorageList_new WHERE pll_pl_id=@pl_id)
	WHERE pl_id=@pl_id	

	END




	UPDATE j_purchaseStorageList
	SET    pll_source_add_time = fd2.pll_source_add_time
	FROM   j_purchaseStorageList fd,
	       (
	           SELECT fd2.pll_pl_id,
	                  fd2.pll_gi_id,
	                  fd2.pll_add_time,
	                  MAX(
	                      CASE 
	                           WHEN fd2.pll_source_id > 0
	                      AND fd2.pll_source_add_time IS NOT NULL
	                          THEN fd2.pll_source_add_time ELSE NULL END
	                  ) AS pll_source_add_time
	           FROM   j_purchaseStorage fd
	                  INNER JOIN j_purchaseStorageList fd2
	                       ON  fd.pl_id = fd2.pll_pl_id
	                       AND fd.pl_source_id > 0
	           GROUP BY
	                  fd2.pll_pl_id,
	                  fd2.pll_gi_id,
	                  fd2.pll_add_time
	       ) AS fd2
	WHERE  fd.pll_pl_id = fd2.pll_pl_id
	       AND fd.pll_gi_id = fd2.pll_gi_id
	       AND fd.pll_add_time = fd2.pll_add_time
	       AND fd.pll_source_id = 0
	       AND fd.pll_source_add_time != fd2.pll_source_add_time
		   and fd.pll_pl_id=@pl_id

		   
	
	exec dbo.pro_mergesingleSums @orderid=@pl_id ,@stockType=9;
	
	IF @@ERROR <> 0
	BEGIN
	    SET @result = '0';

		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @pl_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细' AND @op_type_end=''  and @orderguid=''
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @pll_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
	END
END
go

