CREATE VIEW [dbo].[vi_m_orderchannel] AS 
SELECT mo.*,
       bs.sei_name,
       bc.ci_name
FROM   m_orderchannel           AS mo
       LEFT JOIN b_storageinfo  AS bs
            ON  mo.oc_stock_id = bs.sei_id
       INNER JOIN b_clientinfo   AS bc
            ON  mo.oc_client_id = bc.ci_id
go

