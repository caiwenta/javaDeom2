

CREATE Proc [dbo].[pro_recount_member]
@sa_id int=0,
@sa_me_id int=0
As
if @sa_me_id=0
BEGIN
	select @sa_me_id=ps.sa_me_id from pos_sale as ps WITH (NOLOCK) where ps.sa_id=@sa_id;
END


if @sa_me_id>0
begin


DECLARE @old INT=0;
SELECT @old=isnull(fd.me_cu_in_num,0) FROM pos_memberInfo fd WITH (NOLOCK) WHERE fd.me_id=@sa_me_id;

SELECT * INTO #P FROM (

select * from (
select ps.sa_me_id,
sum(case when ps.sa_status>0 then  case when psl.sal_is_in=1 then psl.sal_in_num else 0 end else 0 end) as sa_dh_num 
from pos_sale as ps  WITH (NOLOCK)
inner join pos_saleList as psl on ps.sa_id=psl.sal_sa_id
where   ps.sa_me_id=@sa_me_id and psl.sal_status=1 group by ps.sa_me_id
) as fd 
left join (

select 

sum(case when ps.sa_status>0 then ps.sa_in_num else 0 end) as sa_in_num,
sum(case when ps.sa_status>0 then  ps.sa_get_in_num else 0 end) as sa_get_in_num 

from pos_sale as ps  WITH (NOLOCK)
where ps.sa_me_id=@sa_me_id

) as fd2 on 1=1	
) AS fd


update pos_memberInfo
set me_init_get=fd.sa_get_in_num+(

SELECT abs(isnull(sum(ir_integral),0)) AS gradeintegral FROM [dbo].[pos_integral_record]
WHERE ir_remark='积分差异调整' and [ir_me_id]=@sa_me_id

),

me_cu_add_num=isnull(fd.sa_in_num,0)+isnull(fd.sa_dh_num,0)+
(

SELECT abs(isnull(sum(ir_integral),0)) AS gradeintegral FROM [dbo].[pos_integral_record]
WHERE ir_remark='会员升级扣除积分' and [ir_me_id]=@sa_me_id

)
from pos_memberInfo as pmi  WITH (NOLOCK),(
SELECT * FROM #P
) as fd where pmi.me_id=fd.sa_me_id


IF NOT EXISTS (SELECT * FROM #p)
BEGIN
	UPDATE pos_memberInfo SET me_init_get=0,me_cu_add_num=0
	WHERE me_id=@sa_me_id;
END

update pos_memberInfo
set me_cu_in_num =isnull(me_in_num,0)-(isnull(me_cu_add_num,0))+(isnull(me_init_get,0))
where me_id=@sa_me_id

DECLARE @new INT=0;
SELECT @new=fd.me_cu_in_num FROM pos_memberInfo fd   WITH (NOLOCK) WHERE fd.me_id=@sa_me_id;

INSERT INTO pos_integral_record
(
	-- ir_id -- this column value is auto-generated
	ir_me_id,
	ir_integral,
	ir_add_time,
	ir_sa_id,
	ir_is_success,ir_remark
)
VALUES
(
	@sa_me_id,
	(@new-@old),
	GETDATE(),
	@sa_id,
	0,'销售前台应用会员消费获得积分'
)

end
--hook
go

