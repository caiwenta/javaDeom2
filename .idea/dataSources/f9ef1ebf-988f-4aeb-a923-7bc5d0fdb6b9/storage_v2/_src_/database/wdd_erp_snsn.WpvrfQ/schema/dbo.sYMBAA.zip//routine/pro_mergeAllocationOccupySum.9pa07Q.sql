CREATE PROCEDURE [dbo].[pro_mergeAllocationOccupySum]
 @id INT=0,
 @SID INT=0,
 @cp_id INT=0,
 @good_id VARCHAR(MAX) = '',
 @type int=0  --0：配货 1:出库
AS
BEGIN
	 TRAN

create table #g 
(
    all_gi_id    int          null  
);


if(@id=0 and @good_id!='')
begin
declare @next int 
set @next=1
while @next<=dbo.Get_StrArrayLength(@good_id,',')
begin
  insert #g(all_gi_id)VALUES(dbo.Get_StrArrayStrOfIndex(@good_id,',',@next))
  set @next=@next+1
end
end


if(@id>0 and @good_id='')
begin

if @type=0
begin

--配货
insert #g
SELECT 
DISTINCT all_gi_id
FROM   pos_allocation ge
inner join  pos_allocationList st ON ge.al_id = st.all_al_id 
inner join b_storageinfo sg on sg.sei_id=ge.al_st_id
WHERE ge.al_id=@id

end
else
begin

--出库
insert #g
SELECT 
DISTINCT ol_siid
FROM   j_outStorage          AS jos WITH (NOLOCK) 
INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) ON  jos.oo_id = josl.ol_eoid
WHERE jos.oo_id=@id AND  jos.oo_source_type = 1 AND jos.oo_source_id > 0 and isnull(ol_source_id,0)<>0

end

end





DECLARE @now DATETIME = GETDATE();
MERGE INTO b_stockinfo AS ta 
USING 
(
	

SELECT 
apl.[SID],apl.gid,apl.skuid,apl.cp_id,apl.gnum 
FROM(SELECT SID,gid,skuid,SUM(gnum) AS gnum,cp_id FROM 
(
SELECT
ge.al_cp_id AS cp_id,ge.al_st_id AS sid,st.all_gi_id AS gid,st.all_sku_id AS skuid,
(case when (ge.al_status<>0 and st.all_status=1 ) then --删除 进度终止 退货
(ISNULL(st.all_num, 0)- ISNULL((SELECT sum(josl.ol_number) AS ol_number FROM j_outStorage AS jos WITH (NOLOCK) INNER JOIN j_outStorageList  AS josl WITH (NOLOCK) 
ON jos.oo_id = josl.ol_eoid WHERE jos.oo_status<>0 AND josl.ol_source_id=st.all_id AND josl.ol_status<>0 AND josl.ol_status = 1	
), 0)-ISNULL(st.all_pause_num, 0)) 
ELSE
0
end) AS gnum 
FROM pos_allocation ge 
inner join  pos_allocationList st ON ge.al_id = st.all_al_id 
inner join b_storageinfo sg on sg.sei_id=ge.al_st_id
WHERE st.all_gi_id IN(SELECT all_gi_id FROM #g) AND ge.al_st_id=@SID AND ge.al_cp_id=@cp_id AND ge.al_source not in (3,4)

) AS TT 
GROUP BY SID,gid,skuid,cp_id
) AS apl




) AS so
ON ta.si_seiid = so.[sid] AND ta.si_giid = so.gid AND ta.si_skuid = so.skuid AND ta.si_cp_id=so.cp_id 
WHEN matched THEN 
UPDATE SET ta.si_allocationoccupy_num = so.gnum, ta.si_status=1, ta.si_indate=@now
WHEN NOT matched THEN
INSERT ( si_seiid, si_giid, si_skuid, si_number, si_allocationoccupy_num, si_status, si_indate, si_cp_id )
VALUES ( so.[sid], so.gid, so.skuid, 0, so.gnum, 1, @now, so.cp_id );


IF @@ERROR <> 0
BEGIN
    ROLLBACK TRAN
END
ELSE
BEGIN
    COMMIT TRAN
END
go

