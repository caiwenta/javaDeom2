CREATE PROC [dbo].[pro_c_fundorder_op]
    @fo_id INT = 0 ,--款项id
    @fo_type TINYINT ,--款项类型(0应收1应付)
    @fo_ciid INT ,--客户id
    @fo_bs VARCHAR(20) ,--客户类型(G/X)供应商或销售客户
    @fo_orderid VARCHAR(50) ,--单据号
    @fo_takeman VARCHAR(50) ,--经手人
    @fo_ticketno VARCHAR(50) ,--票号
    @fo_realmoney DECIMAL(15, 2) = 0 ,--实际金额(出入库金额)
    @fo_thiyetmoney DECIMAL(15, 2) = 0 ,--本期收款
    @fo_ofdate DATETIME ,--款项时间
    @fo_remark VARCHAR(200) ,--备注
    @fo_lastman VARCHAR(50) ,--审核人
    @fo_status TINYINT = 1 ,--状态(大于0的都是可用的,0:删除)
    @fo_outmoney DECIMAL(15, 2) = 0 ,--退货金额
    @fo_admoney DECIMAL(15, 2) = 0 ,--垫付运费
    @fo_otheronmoney DECIMAL(15, 2) = 0 ,--其他应收
    @fo_otheoutmoney DECIMAL(15, 2) = 0 ,--其他应付
    @fo_givemoney DECIMAL(15, 2) = 0 ,--赠送金额
    @fo_ensuremoney DECIMAL(15, 2) = 0 ,--保证金
    @fo_subscription DECIMAL(15, 2) = 0 ,--订金
    @fo_no VARCHAR(50) ,--凭证号
    @fo_userorderno VARCHAR(50) = '' ,--手工单号
    @outResult INT OUTPUT ,
    @fo_cp_id INT = 0 ,--公司主键	
    @fo_di_id INT = 0 ,--部门主键
    @fo_shid INT = 0 ,--店铺id
    @fo_to_cpid INT = 0 , --分公司id
    @fo_erp_id INT = 0 , --使用客户标识id
    @fo_order_id INT = 0 ,
    @fo_realmoney_integral DECIMAL(10, 2) = 0 ,
    @fo_thiyetmoney_integral DECIMAL(10, 2) = 0 ,
    @fo_outmoney_integral DECIMAL(10, 2) = 0 ,
    @fo_otheronmoney_integral DECIMAL(10, 2) = 0 ,
    @fo_otheoutmoney_integral DECIMAL(10, 2) = 0 ,
    @fo_givemoney_integral DECIMAL(10, 2) = 0 ,
    @fo_source_id INT = 0, --来源ID（现金银行）
	@fo_addman_id  int=0,
	@fo_addman  VARCHAR(100)  = '',--应收应付 制单人
	@fo_custom_remark VARCHAR(220) = '',--应收应付 备注
	@fo_c_inlist_type INT  = 0, --应收登记类型
	@fo_customer_balance VARCHAR(100)=''
AS
    BEGIN
    	















    	DECLARE @generatefundor int=0;
    	--供应商资料与客户资料增加“不核算帐款”  fo_type:0   1 应付(供应商)
		IF (@fo_order_id>0 AND @fo_ciid>0)
		BEGIN
			IF @fo_type=0--(0应收1应付)
				BEGIN
				SELECT @generatefundor=isnull(ci_adjust,0) FROM b_clientinfo WHERE ci_id=@fo_ciid--应收(客户)
				END
			 ELSE
			 	BEGIN
		        SELECT @generatefundor=isnull(si_adjust,0) FROM [dbo].[b_supplierinfo] WHERE si_id=@fo_ciid--应付(供应商)
			 	END
		END
    	
    	
    	IF(@generatefundor=0)
    	BEGIN
    	    BEGIN TRANSACTION
      	
		--功能：应收应付生成
        IF @fo_orderid != ''
            BEGIN
				--得到款项id
                IF EXISTS ( SELECT  1
                            FROM    c_fundorder WITH ( NOLOCK )
                            WHERE   fo_orderid = @fo_orderid
                                    AND fo_cp_id = @fo_cp_id )
                    BEGIN
						--得到款项id
                        SELECT  @fo_id = fo_id
                        FROM    c_fundorder WITH ( NOLOCK )
                        WHERE   fo_orderid = @fo_orderid
                                AND fo_cp_id = @fo_cp_id;
                    END
                ELSE
                    SET @fo_id = 0;
            END
	
        DECLARE @olddate DATETIME; --得到旧的款项时间
        DECLARE @isInsert INT= 0; --是否为添加操作
        DECLARE @myprevTxt VARCHAR(50)= ''; --前缀

       IF @fo_type = 0
            BEGIN
				--应收账款
                SET @myprevTxt = 'YSZK';
            END
        ELSE
            IF @fo_type = 1
                BEGIN
					--应付账款
                    SET @myprevTxt = 'YFZK';
                END
		--事务开始	
        
       IF @fo_id = 0
            BEGIN
				--是添加操作
                SET @isInsert = 1;
				--添加
                INSERT  INTO [c_fundorder]
                        ( [fo_type] ,
                          [fo_ciid] ,
                          [fo_bs] ,
                          [fo_orderid] ,
                          [fo_takeman] ,
                          [fo_ticketno] ,
                          [fo_realmoney] ,
                          [fo_thiyetmoney] ,
                          [fo_ofdate] ,
                          [fo_remark] ,
                          [fo_lastman] ,
                          [fo_status] ,
                          [fo_outmoney] ,
                          [fo_admoney] ,
                          [fo_otheronmoney] ,
                          [fo_otheoutmoney] ,
                          [fo_givemoney] ,
                          [fo_ensuremoney] ,
                          [fo_subscription] ,
                          [fo_no] ,
                          fo_addtime ,
                          fo_updatetime ,
                          fo_userorderno ,
                          [fo_cp_id] ,
                          [fo_di_id] ,
                          [fo_shid] ,
                          [fo_to_cpid] ,
                          fo_erp_id ,
                          fo_order_id ,
                          fo_realmoney_integral ,
                          fo_thiyetmoney_integral ,
                          fo_outmoney_integral ,
                          fo_otheronmoney_integral ,
                          fo_otheoutmoney_integral ,
                          fo_givemoney_integral ,
                          fo_source_id,
						  fo_addman_id,
						  [fo_addman],
						  [fo_custom_remark],
						  [fo_c_inlist_type],
						  [fo_customer_balance]
		                )
                VALUES  ( @fo_type ,
                          @fo_ciid ,
                          @fo_bs ,
                          @fo_orderid ,
                          @fo_takeman ,
                          @fo_ticketno ,
                          ISNULL(@fo_realmoney, 0) ,
                          @fo_thiyetmoney ,
                          @fo_ofdate ,
                          @fo_remark ,
                          @fo_lastman ,
                          @fo_status ,
                          @fo_outmoney ,
                          @fo_admoney ,
                          @fo_otheronmoney ,
                          @fo_otheoutmoney ,
                          @fo_givemoney ,
                          @fo_ensuremoney ,
                          @fo_subscription ,
                          NEWID() ,
                          GETDATE() ,
                          GETDATE() ,
                          @fo_userorderno ,
                          @fo_cp_id ,
                          @fo_di_id ,
                          @fo_shid ,
                          @fo_to_cpid ,
                          @fo_erp_id ,
                          @fo_order_id ,
                          @fo_realmoney_integral ,
                          @fo_thiyetmoney_integral ,
                          @fo_outmoney_integral ,
                          @fo_otheronmoney_integral ,
                          @fo_otheoutmoney_integral ,
                          @fo_givemoney_integral ,
                          @fo_source_id,
						  @fo_addman_id,
						  @fo_addman,
						  @fo_custom_remark,
						  @fo_c_inlist_type,
						  @fo_customer_balance
		                )
                SET @fo_id = SCOPE_IDENTITY();
                SET @olddate = @fo_ofdate;
            END
        ELSE
            BEGIN
                SELECT  @olddate = cf.fo_ofdate
                FROM    c_fundorder cf
                WHERE   cf.fo_id = @fo_id;
				--更新
                UPDATE  [c_fundorder]
                SET     [fo_type] = @fo_type ,
                        [fo_ciid] = @fo_ciid ,
                        [fo_bs] = @fo_bs ,
                        [fo_orderid] = @fo_orderid ,
                        [fo_takeman] = @fo_takeman ,
                        [fo_ticketno] = @fo_ticketno ,
                        [fo_realmoney] = ISNULL(@fo_realmoney, 0) ,
                        [fo_thiyetmoney] = @fo_thiyetmoney ,
                        [fo_ofdate] = @fo_ofdate ,
                        [fo_remark] = @fo_remark ,
                        [fo_lastman] = @fo_lastman ,
                        [fo_status] = @fo_status ,
                        [fo_outmoney] = @fo_outmoney ,
                        [fo_admoney] = @fo_admoney ,
                        [fo_otheronmoney] = @fo_otheronmoney ,
                        [fo_otheoutmoney] = @fo_otheoutmoney ,
                        [fo_givemoney] = @fo_givemoney ,
                        [fo_ensuremoney] = @fo_ensuremoney ,
                        [fo_subscription] = @fo_subscription ,
                        fo_updatetime = GETDATE() ,
                        fo_userorderno = @fo_userorderno ,
                        fo_shid = @fo_shid ,
                        fo_to_cpid = @fo_to_cpid ,
                        fo_realmoney_integral = @fo_realmoney_integral ,
                        fo_thiyetmoney_integral = @fo_thiyetmoney_integral ,
                        fo_outmoney_integral = @fo_outmoney_integral ,
                        fo_otheronmoney_integral = @fo_otheronmoney_integral ,
                        fo_otheoutmoney_integral = @fo_otheoutmoney_integral ,
                        fo_givemoney_integral = @fo_givemoney_integral ,
                        fo_order_id = @fo_order_id,
						[fo_custom_remark]=@fo_custom_remark,
						[fo_c_inlist_type]=@fo_c_inlist_type,
						[fo_customer_balance]=@fo_customer_balance
                WHERE   fo_id = @fo_id

                EXEC pro_merge_c_fundorder @fo_bs = @fo_bs, @fo_ciid = @fo_ciid, @fo_id = 0, @fo_shid = @fo_shid, @fo_to_cpid = @fo_to_cpid,
                    @operate_type = '计算客户供应商固化数据';
            END
		--如果是添加操作或日期不相等,则更新凭证号
       IF @isInsert = 1 --Or @olddate!=@fo_ofdate
            BEGIN
				--更新凭证号	
                DECLARE @tableName VARCHAR(50)= 'c_fundorder'
                DECLARE @idField VARCHAR(50)= 'fo_id'
                DECLARE @idValue INT= @fo_id
                DECLARE @dateField VARCHAR(50)= 'fo_ofdate'
                DECLARE @dateValue VARCHAR(50)= CONVERT(VARCHAR(50), @fo_ofdate, 23)
                DECLARE @noField VARCHAR(50)= 'fo_no'
                DECLARE @prevTxt VARCHAR(50)= @myprevTxt
                DECLARE @outno VARCHAR(100)= ''
                DECLARE @while INT= 0;
                WHILE @while = 0
                    BEGIN
					    --得到凭证号
                        EXECUTE [dbo].[pro_gen_orderNo] @tableName, @idField, @idValue, @dateField, @dateValue, @noField, @prevTxt, @outno OUTPUT, 0, @fo_cp_id
                        BEGIN TRY
							--更新
                            UPDATE  c_fundorder
                            SET     fo_no = @outno ,
                                    pzone = dbo.Get_StrArrayStrOfIndex(@outno, '-', 1) ,
                                    pztwo = dbo.Get_StrArrayStrOfIndex(@outno, '-', 2) ,
                                    pzthree = dbo.Get_StrArrayStrOfIndex(@outno, '-', 3)
                            WHERE   fo_id = @fo_id;
							--更新成功,赋值,结束循环
                            SET @while = 1;
                        END TRY
                        BEGIN CATCH
                            PRINT '';
                        END CATCH
                    END

                UPDATE  c_fundorder
                SET     fo_dateint =dbo.Get_StrArrayStrOfIndex(fo_no, '-', 2) ,
                        fo_orderint = dbo.Get_StrArrayStrOfIndex(fo_no, '-', 3)
                WHERE   fo_id = @fo_id;
            END




       DECLARE @erp_id int=0;
	   select @erp_id=cp_erp_id from companyinfo where cp_id=@fo_cp_id
       if EXISTS(SELECT * FROM s_system_set AS sss WHERE sss.s_key='fundorderreconciliation' AND sss.s_erp_id=@erp_id AND sss.s_value=1) and @fo_orderid != ''
	   begin
	     
		 update c_fundorder set fo_status=2 where fo_id=@fo_id;

	     DECLARE @tdoc_xml VARCHAR(max)= '';
		 SET @tdoc_xml = '{ "fo_id":"' + CONVERT(VARCHAR(50), @fo_id) + '"}';
		 EXEC pro_apiqueue_op 
			@tdoc_method = 'fundorderreconciliation', 
			@tdoc_xml = @tdoc_xml, 
			@tdoc_erp_id =@fo_erp_id, 
			@tdoc_cp_id=@fo_cp_id,
			@tdoc_state = 0;	
	   end



		IF @@error <> 0
            BEGIN 
                SET @outResult = 0;
				
                IF @@TRANCOUNT > 0
                    ROLLBACK TRANSACTION;
            END
        ELSE
            BEGIN

                SET @outResult = @fo_id; 

                IF @@TRANCOUNT > 0
                    COMMIT TRANSACTION; 
				END

				RETURN @outResult;

			END
			ELSE
				BEGIN
					RETURN '1';	
				END
    END
go

