

CREATE TRIGGER [dbo].[trg_companyinfo_insert_update] ON [dbo].[companyinfo]
      FOR INSERT, UPDATE
AS
      BEGIN
            DECLARE @cp_id INT= 0;
			DECLARE @oldcp_id INT= 0;
			DECLARE @cp_status INT= 0;
            DECLARE @qcje DECIMAL(15, 2)= 0;
            DECLARE @oldqcje DECIMAL(15, 2)= 0;
       
            SELECT  @cp_id = cp_id ,
					@cp_status = cp_status ,
                    @qcje = cp_qcje
            FROM    INSERTED;
             
            SELECT  @oldcp_id = cp_id ,
					@oldqcje = cp_qcje
            FROM    DELETED;
            --新增记录 
            IF @oldcp_id = 0
               BEGIN
					  --初始现金银行帐号
                     INSERT INTO c_bankinfo
                            ( bk_no ,
                              bk_name ,
                              bk_qcje ,
                              addtime ,
                              bk_status ,
                              bk_add_man ,
                              bk_add_time ,
                              bk_cp_id ,
                              bk_erp_id
                            )
                            SELECT  'XJ' ,
                                    '现金' ,
                                    0 ,
                                    '2014-07-01' ,
                                    1 ,
                                    -1 ,
                                    '2014-07-01' ,
                                    cp_id ,
                                    cp_erp_id
                            FROM    companyinfo
                            WHERE   cp_id = @cp_id
                                    AND cp_id NOT IN ( SELECT   bk_cp_id
                                                       FROM     c_bankinfo WITH ( NOLOCK )
                                                       WHERE    bk_no = 'XJ'
                                                                AND bk_name = '现金'
                                                                AND bk_add_time = '2014-07-01' )
               END
			--删除记录
            IF @cp_status = 0
               BEGIN
                     DELETE c_bankinfo
                     WHERE  bk_cp_id = @cp_id
               END
              --更改期初金额或删除，重新计算期初金额
            --IF @oldqcje <> @qcje OR @cp_status = 0 or @oldqcje=0
            --   EXEC pro_update_c_fundorder_QcQm @type = 0, @to_cpid = @cp_id
      END
go

