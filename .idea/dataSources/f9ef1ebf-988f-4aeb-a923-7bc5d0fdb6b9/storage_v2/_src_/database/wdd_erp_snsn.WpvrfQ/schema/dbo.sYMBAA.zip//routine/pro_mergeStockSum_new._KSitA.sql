


CREATE PROC [dbo].[pro_mergeStockSum_new]
@cp_id INT=0,@id INT=0,@type INT=0
AS
BEGIN
	 TRAN

SELECT DISTINCT js.sl_giid INTO #g FROM j_stocklog js WHERE js.sl_type=@type
AND js.sl_eoid=@id

DECLARE @now DATETIME = GETDATE();
MERGE INTO b_stockinfo AS ta 
USING 
(
SELECT js.sl_seiid AS [sid],js.sl_giid AS gid,js.sl_skuid AS
skuid,js.sl_cp_id AS  cp_id,SUM(
	CASE WHEN sl_status>0 THEN 
	CASE WHEN js.sl_counttype=1 THEN js.sl_number ELSE - js.sl_number END
	ELSE 
	0
	END	
) AS gnum
  FROM j_stocklog js WHERE  js.sl_cp_id=@cp_id AND js.sl_giid
IN(SELECT sl_giid FROM #g)
Group By 
js.sl_seiid,
js.sl_giid,
js.sl_skuid,
js.sl_cp_id




) AS so
ON 
ta.si_seiid = so.[sid] 
AND ta.si_giid = so.gid 
AND ta.si_skuid = so.skuid 
AND ta.si_cp_id=so.cp_id 
WHEN matched THEN 
UPDATE 
SET    
ta.si_number = so.gnum,
ta.si_status=1,
ta.si_indate=case when  ta.si_number!=so.gnum then @now else ta.si_indate END
WHEN NOT matched THEN
INSERT 
  (
    si_seiid,
    si_giid,
    si_skuid,
    si_number,
    si_status,
    si_indate,
    si_cp_id
  )
VALUES
  (
    so.[sid],
    so.gid,
    so.skuid,
    so.gnum,
    1,
    @now,
    so.cp_id
  );
IF @@ERROR <> 0
BEGIN
	IF @@TRANCOUNT > 0 ROLLBACK TRAN;
END
ELSE
BEGIN
    IF @@TRANCOUNT > 0 COMMIT TRAN
END
go

