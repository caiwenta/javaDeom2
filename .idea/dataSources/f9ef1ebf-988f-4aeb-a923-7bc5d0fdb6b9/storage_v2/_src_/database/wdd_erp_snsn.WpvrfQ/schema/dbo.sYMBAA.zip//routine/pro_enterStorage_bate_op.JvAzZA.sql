CREATE PROCEDURE [dbo].[pro_enterStorage_bate_op]
@eo_tax_point decimal(15, 2)=0,
@eo_tax_money decimal(15, 2)=0,

--订单id
@eo_id INT ,
@eo_erp_id INT ,
@el_erp_id INT ,
--客户id
@eo_ciid INT = 0,
--仓库id
@eo_siid INT = 0,
--经手人id
@eo_takemanid INT = 0,
--备注
@eo_remark NVARCHAR(200) = '',
--单据时间
@eo_entrydate DATETIME = '2014-7-22',
--审核人id
@eo_lastmanid INT = 0,

--是否为扫描
@is_saomiao INT = 0,

--添加人id
@eo_addman INT = 0,
--修改人id
@eo_updateman INT = 0,
--部门id
@eo_itid INT = 0,
--类型(0,入库:1:退货)
@eo_type INT = 0,
--状态(0,删除:1,可用:2,审核)
@eo_status INT = 0,
--总金额(实际总重)
@eo_totalmoney DECIMAL(18, 2) = 0,
--优惠金额
@eo_couponmoney DECIMAL(15, 2) = 0,
--实际金额
@eo_realmoney DECIMAL(15, 2) = 0,
--总数量
@eo_num INT = 0,
--手工单号
@eo_manual VARCHAR(50) = '',
--费用
@eo_cost DECIMAL(15, 2) = 0,
--运费
@eo_freight DECIMAL(15, 2) = 0,
--快递公司
@eo_express VARCHAR(100) = '',
--货运单号
@eo_expressno VARCHAR(100) = '',
--来源类型(1,采购)
@eo_source_type INT = 0,
--来源主键
@eo_source_id INT = 0,
--单据明细id
@el_id INT = 0,
--商品id
@el_siid INT = 0,
--数量
@el_number INT = 0,
--折扣
@el_discount DECIMAL(10, 2) = 0,
--实际金额
@el_realmoney DECIMAL(10, 2) = 0,
--备注
@el_remark NVARCHAR(500) = '',
--自动匹配采购单
@eo_ismatching INT=0,

--进货价
@el_unit DECIMAL(10, 2) = 0,
--零售价
@el_costprice DECIMAL(10, 2) = 0,
--添加时间
@el_addtime DATETIME = '2014-7-22',
--规格id
@el_skuid INT = 0,
@el_gift INT =0,
--来源明细主键
@el_source_id INT = 0,
--来源明细添加时间
@el_source_add_time DATETIME = '2014-11-20',
--公司主键
@eo_cp_id INT = 0,
--部门主键
@eo_di_id INT = 0,
--分公司主键
@eo_to_cp_id INT = 0,
--前台排出的商品(单击清空明细按钮时会记录商品主键,添加时间)
@not_in_ids VARCHAR(MAX) = '',
--保存字符串
@savestr VARCHAR(MAX)='',
--箱数
@el_box_num INT = 0,
--配码
@el_pm VARCHAR(500) = '',
--操作类型  
@op_type VARCHAR(100) = '添加修改单据,明细',  

@negative_inventory INT=0,

@order_id  VARCHAR(MAX)='',
@good_id VARCHAR(MAX)='',
@goodscode VARCHAR(MAX) = '',
--结果  
@result VARCHAR(100) = '' OUT,

--供应商积分开关
@isupplierintegral int=0,

--生产日期
@pddate VARCHAR(80) = '',
--商品日期
@pdgddate  VARCHAR(80) = '',

--积分
@el_integral numeric(18,2)=0,
--总积分
@el_totalintegral numeric(18,2)=0,

--采购退货
@pl_pltype int=0,

@el_expirationdate VARCHAR(80) = null,
@el_shelflife int=0,

@eo_ispda int=0,
@eo_do_id int=0
AS
BEGIN TRAN

--为默认仓库，如果没有设置默认仓库就按第一个仓库来
if @eo_siid=0
begin
SELECT TOP 1 @eo_siid=sei_id FROM b_storageinfo bs
WHERE bs.sei_erp_id=@eo_erp_id
ORDER BY sei_default DESC ,bs.sei_id DESC 
end


--是否添加单据
DECLARE @isInsert INT = 0;
--终止标识
DECLARE @op_type_end VARCHAR(100)='';
IF @op_type='添加修改单据,明细,终止操作'
BEGIN
   SET @op_type='添加修改单据,明细';
   SET @op_type_end='添加修改单据,明细,终止操作';
END

DECLARE @old_sei_id INT=0;
DECLARE @new_sei_id INT=0;

--凭证号生成
DECLARE @outno VARCHAR(100) = ''

IF @op_type = '添加修改单据,明细'
BEGIN
	 IF @eo_id = 0 AND @op_type_end=''
	    BEGIN

		    SET @isInsert = 1;

	        IF @eo_cp_id = 0
	        BEGIN
	            SELECT @eo_cp_id = fd.si_company,
	                   @eo_di_id = fd.si_did
	            FROM   b_stafftinfo fd
	            WHERE  fd.si_id = @eo_addman
	        END
			 
		
		DECLARE @myprevTxt VARCHAR(50) = 'RK';--凭证号前缀
		IF @eo_type = 1
		BEGIN
			SET @myprevTxt = 'RKTH';
		END
	    DECLARE @tableName VARCHAR(50) = 'j_enterStorage'
	    DECLARE @idField VARCHAR(50) = 'eo_id'
	    DECLARE @idValue INT = @eo_id;
	    DECLARE @dateField VARCHAR(50) = 'eo_entrydate'
	    DECLARE @dateValue VARCHAR(50) = CONVERT(VARCHAR(50), @eo_entrydate, 23)
	    DECLARE @noField VARCHAR(50) = 'eo_no'
	    DECLARE @prevTxt VARCHAR(50) = @myprevTxt
	    EXECUTE [pro_gen_orderNo]@tableName, @idField, @idValue, @dateField, @dateValue, @noField, @prevTxt, @outno OUTPUT,0,@eo_cp_id

	        --添加订单
	        INSERT INTO j_enterStorage
	          (
	            eo_ciid, eo_siid,  eo_takemanid, eo_remark, eo_entrydate, eo_lastmanid, eo_itid, eo_type, eo_status, eo_totalmoney, eo_couponmoney, eo_realmoney, eo_num, eo_addtime, eo_manual, eo_cost, eo_freight, eo_express, eo_expressno, eo_source_type, eo_source_id, eo_addman, eo_cp_id, eo_di_id, eo_to_cp_id, eo_ismatching, eo_erp_id, eo_tax_point, eo_tax_money,
				  eo_no,pzone,pztwo, pzthree
	          )
	        VALUES
	          (
	            @eo_ciid, @eo_siid,  @eo_takemanid, @eo_remark, @eo_entrydate, @eo_lastmanid, @eo_itid, @eo_type, 1, @eo_totalmoney, @eo_couponmoney, @eo_realmoney, @eo_num, GETDATE(), @eo_manual, @eo_cost, @eo_freight, @eo_express, @eo_expressno, @eo_source_type, @eo_source_id, @eo_addman, @eo_cp_id, @eo_di_id, @eo_to_cp_id, @eo_ismatching, @eo_erp_id, @eo_tax_point, @eo_tax_money,
				  @outno,dbo.Get_StrArrayStrOfIndex(@outno,'-',1),dbo.Get_StrArrayStrOfIndex(@outno,'-',2),dbo.Get_StrArrayStrOfIndex(@outno,'-',3)
	          );

	        SET @eo_id = SCOPE_IDENTITY();
	    END

	  
	    DECLARE @savestr_item VARCHAR(MAX)='';--保存字符串用 | 作为分隔符,此变量存储分割后的具体项
	    DECLARE @start_int INT=1;  --起始数值,每次循环后递增
		DECLARE @end_int INT=1; --终止数值
        IF @savestr!='' 
	    BEGIN
	       SELECT @end_int=(LEN(@savestr)-LEN(REPLACE(@savestr,'|','')))
	    END

	    SELECT fd.pll_pl_id AS pll_id, fd.pll_pl_id, fd.pll_gi_id, fd.pll_sku_id, fd.pll_num, fd.pll_add_time, fd.pll_retail_price, fd.pll_discount, fd.pll_stock_price, fd.pll_box_num, fd.pll_pm, fd.pll_erp_id
		INTO #temp_pll
		FROM j_purchaseStorageList fd WHERE 1=2

--明细添加
WHILE @start_int<=@end_int
BEGIN
			
--动态赋值
IF @savestr!='' 
BEGIN
	
	SET @savestr_item=dbo.Get_StrArrayStrOfIndex(@savestr,'|',@start_int);
	IF(RTRIM(LTRIM(@savestr_item))='')
	BEGIN
		BREAK;
	END
	ELSE
	BEGIN
		IF @eo_source_type>0 
		BEGIN
			--采购入库,采购退货
			SET @el_id=0;
			SET @el_source_id=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',1));
			SET @el_number=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',2));

			SET @el_source_add_time=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',3);
		
			SET @el_box_num=CONVERT(INT,dbo.Get_StrArrayStrOfIndex(@savestr_item,',',4));
			
			SET @el_pm=dbo.Get_StrArrayStrOfIndex(@savestr_item,',',5);

			SET @el_unit=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',6));
			
			SET @el_costprice=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',7));
			
			SET @el_discount=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',8));
		
			SET @el_siid=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',9));	--商品主键
		
			SET @el_skuid=CONVERT(DECIMAL(10,2),dbo.Get_StrArrayStrOfIndex(@savestr_item,',',10));	--sku主键
			

			INSERT INTO
	 #temp_pll( pll_id,pll_pl_id,pll_gi_id, pll_sku_id,pll_num,pll_add_time, pll_retail_price, pll_discount, pll_stock_price, pll_box_num, pll_pm
			)VALUES(@el_source_id,0,@el_siid,@el_skuid,@el_number,@el_source_add_time,@el_unit,@el_discount,@el_costprice,@el_box_num,@el_pm);
	END
    END
END
SET @start_int=@start_int+1;
END	


IF @eo_source_type>0 
BEGIN

--添加明细
INSERT INTO j_enterStorageList
( el_eoid, el_siid,  el_skuid,  el_number, el_discount, el_unit, el_costprice, el_status, el_source_id, el_source_add_time, el_box_num, el_pm,el_cp_id,el_realmoney, el_erp_id )
SELECT 
 @eo_id , pll_gi_id, pll_sku_id, pll_num , pll_discount,pll_retail_price,pll_stock_price,1 ,pll_id,pll_add_time,pll_box_num,pll_pm,@eo_cp_id,
 pll_stock_price*pll_num, --进货金额
 @eo_erp_id
FROM #temp_pll fd

if(@eo_ispda>0 and @eo_do_id>0 )
begin

update erp_distributionorderlist set
dol_inspectionnum=(select sum(pll_num) from #temp_pll where pll_gi_id=dol_gi_id and pll_sku_id=dol_sku_id and pll_id=dol_source_id ),
dol_inspectiontime=GETDATE(),
dol_status=2
WHERE 
    si_id=@eo_ispda 
AND erp_id=@eo_erp_id 
AND do_id=@eo_do_id
and dol_status=1

end






--统一添加时间
EXEC pro_update_unique_time_source @type = '入库', @id = @eo_id;


Set @old_sei_id=@eo_siid;

--计算库存
EXEC pro_mergeStockLog_j_enterStorage
	@cp_id = @eo_cp_id,
	@negative_inventory=@negative_inventory,
	@old_sei_id=@old_sei_id,
	@new_sei_id=@new_sei_id,
	@id=@eo_id
IF @@error <> 0
	BEGIN
	    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION 
	    SET @result = '0';
	    RETURN 0;
	END
	ELSE
	BEGIN
		EXEC pro_update_b_stockinfo_si_pddate
			@order_id = @eo_id,
			@order_type = 'erp入库'
END

--订单有已审核
UPDATE j_enterStorage
SET  eo_status = 2,
eo_lastmanid = @eo_addman,
eo_auditdate = GETDATE()
WHERE  eo_id = @eo_id;



END	


END


--应收应付
IF (@op_type = '添加修改单据,明细' and @outno!='') 
	BEGIN

	DECLARE @mymoney DECIMAL(15, 2) = 0;
	DECLARE @fo_realmoney_integral DECIMAL(10,2) = 0;
	DECLARE @fo_outmoney_integral  DECIMAL(10,2) = 0;
	--赠送金额
	DECLARE @giftedmoney DECIMAL(15,2) = 0;
	--积分合计
	DECLARE @integral_sum DECIMAL(10,2)=0;
    DECLARE @fo_givemoney_integral DECIMAL(10,2);

	--成本价*数量
	SELECT @mymoney = SUM(je.el_costprice * je.el_number)
	,@integral_sum=SUM(je.el_totalintegral)
	FROM   j_enterStorageList je
	WHERE  je.el_eoid = @eo_id 
	AND je.el_status =1 
	AND isnull(je.el_gift,0) = 0


	SELECT 
	@giftedmoney = SUM(je.el_costprice * je.el_number),
	@fo_givemoney_integral=SUM(je.el_totalintegral)
	FROM   j_enterStorageList je
	WHERE  je.el_eoid = @eo_id 
	AND je.el_status =1 
	AND isnull(je.el_gift,0) !=0


	DECLARE @rkje DECIMAL(15, 2) = 0;
	DECLARE @rkthje DECIMAL(15, 2) = 0;
	DECLARE @myremark VARCHAR(50) = '';
    IF @eo_type = 0
	BEGIN
		SET @fo_realmoney_integral=@integral_sum;
	    SET @rkje = @mymoney;
	    SET @myremark = '入库应付';
	END
	ELSE
	BEGIN
		SET @fo_outmoney_integral=@integral_sum;
	    SET @rkthje = @mymoney;
	    SET @myremark = '入库退货应付';
	END


	    DECLARE @RC INT = 0;
	    DECLARE @fo_id INT = 0;
	    DECLARE @fo_type TINYINT = 1;--应付账款
	    DECLARE @fo_ciid INT = @eo_ciid;
	    DECLARE @fo_bs VARCHAR(20) = 'G';
	    DECLARE @fo_orderid VARCHAR(50) = @outno;
	    DECLARE @fo_takeman VARCHAR(50) = '';
	    DECLARE @fo_ticketno VARCHAR(50) = '';
	    DECLARE @fo_realmoney DECIMAL(15, 2) = @rkje;--入库金额
	    DECLARE @fo_thiyetmoney DECIMAL(15, 2) = 0;
	    DECLARE @fo_ofdate DATETIME = @eo_entrydate;
	    DECLARE @fo_remark VARCHAR(200) = @myremark;
	    DECLARE @fo_lastman VARCHAR(50) = '';
	    DECLARE @fo_status TINYINT = 1;
	    DECLARE @fo_outmoney DECIMAL(15, 2) = @rkthje;
	    --垫付运费
	    DECLARE @fo_admoney DECIMAL(15, 2) = @eo_freight;
	    --其他应收
	    DECLARE @fo_otheronmoney DECIMAL(15, 2) = @eo_cost;
	    --其他应付
	    DECLARE @fo_otheoutmoney DECIMAL(15, 2) = 0;
	    
	    SET @fo_otheoutmoney=@eo_tax_money;
	    
	    
	    
	    
	    DECLARE @fo_givemoney DECIMAL(15, 2) = @giftedmoney;
	    DECLARE @fo_ensuremoney DECIMAL(15, 2) = 0;
	    DECLARE @fo_subscription DECIMAL(15, 2) = 0;
	    DECLARE @fo_no VARCHAR(50) = '';
	    DECLARE @fo_userorderno VARCHAR(50) = '';
	    DECLARE @outResult INT = 0;
	    EXECUTE @RC = [pro_c_fundorder_op] 
	    @fo_id=@fo_id,
	    @fo_type=@fo_type,
	    @fo_ciid=@fo_ciid,
	    @fo_bs=@fo_bs,
	    @fo_orderid=@fo_orderid,
	    @fo_takeman=@fo_takeman,
	    @fo_ticketno=@fo_ticketno,
	    @fo_realmoney=@fo_realmoney,
	    @fo_thiyetmoney=@fo_thiyetmoney,
	    @fo_ofdate=@fo_ofdate,
	    @fo_remark=@fo_remark,
	    @fo_lastman=@fo_lastman,
	    @fo_status=@fo_status,
	    @fo_outmoney=@fo_outmoney,
	    @fo_admoney=@fo_admoney,
	    @fo_otheronmoney=@fo_otheronmoney,
	    @fo_otheoutmoney=@fo_otheoutmoney,
	    @fo_givemoney=@fo_givemoney,
	    @fo_ensuremoney=@fo_ensuremoney,
	    @fo_subscription=@fo_subscription,
	    @fo_no=@fo_no,
	    @fo_userorderno=@fo_userorderno,
	    @outResult=@outResult OUTPUT,
	    @fo_cp_id=@eo_cp_id,
	    @fo_di_id=@eo_di_id,
	    
	    @fo_shid=0,
	    @fo_to_cpid=0,
	    
	    @fo_realmoney_integral=
	    @fo_realmoney_integral,--入库获得积分

	    @fo_thiyetmoney_integral =0,
	    
		@fo_outmoney_integral =
		@fo_outmoney_integral,--入库退货扣减积分
		
		@fo_otheronmoney_integral =0,
		@fo_otheoutmoney_integral =0,
		@fo_givemoney_integral =
		@fo_givemoney_integral,
		@fo_erp_id=@eo_erp_id,
	     @fo_order_id=@eo_id
	    
	    IF @RC = 0
	    BEGIN
	        --款项更新失败
			IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION 
	        SET @result = '0';
	        RETURN 0;
	    END
	END

















IF @@ERROR <> 0
	BEGIN
	    SET @result = '0';

		IF @@TRANCOUNT > 0 ROLLBACK TRAN;
	    RETURN 1;
	END
	ELSE
	BEGIN
	    IF @isInsert = 1
	    BEGIN
	        SET @result = CONVERT(VARCHAR(50), @eo_id);
	    END
	    ELSE
	    BEGIN
	        IF @op_type = '添加修改单据,明细'  AND @op_type_end=''
	        BEGIN
	            SET @result = CONVERT(VARCHAR(50), @el_id);
	        END
	        ELSE
	        BEGIN
	            SET @result = '1';
	        END
	    END
	    IF @@TRANCOUNT > 0 COMMIT TRAN;
END
go

