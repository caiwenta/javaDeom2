CREATE VIEW [dbo].[vi_pos_sale_search]
AS

select
'' as specname,--暂时为空  
(case when rulenum.gd_row_number is null then '无' else  'spec'+convert(varchar,rulenum.gd_row_number) end) as spec2,
(select gd_code from s_goodsruledetail where gd_id=size)sizecode, --尺码编码
(select gd_code from s_goodsruledetail where gd_id=col)colorcode, --颜色编码
rulenum.gd_row_number,
(SELECT COUNT(sal_returnedid) FROM pos_saleList AS psl WHERE psl.sal_returnedid=salelist.sal_id) AS returnedid,--退货次数
salelist.*
from 
(

select 
isnull(grl.colorname,'无') as color,
grl.colorgroupname as colorgroupname, 
isnull(grl.specname,'无') as spec,
grl.specngroupname as specngroupname, 
isnull(grl.specid,0) as size,
isnull(grl.specngroupid,0) as specid,
isnull(grl.colorid,0) as col,
isnull(grl.colorgroupid,0) as colorid,
sale.*, 

(CASE WHEN grl.gss_id IS NULL THEN sale.gi_retailprice ELSE  grl.gs_marketprice END) AS gs_marketprice,--零售价
(CASE WHEN grl.gss_id IS NULL THEN sale.gi_costprice ELSE  grl.gs_costprice END) AS gs_costprice --成本价

from
(

SELECT  el.gi_buyingteam,   --买手小组
	    el.gi_supplier,     --供应商
		eo.sa_sh_id AS sh_id ,
        eo.sa_sh_id AS eosa_sh_id ,
		eo.erp_id,
        el.sal_id ,
        ( SELECT    sal_customprice
          FROM      pos_saleList_temp
          WHERE     pos_saleList_temp.sal_id = el.sal_id
        ) AS sal_customprice ,
        el.sal_sa_id ,
        el.sal_gi_id ,
        el.sal_gi_id gi_id,
        el.sal_sku_id ,
        el.sal_num ,
        el.sal_retail_price ,
        ( el.sal_retail_price * el.sal_num ) AS sal_retail_money ,
        el.sal_discount ,
        el.sal_list_man ,
        el.sal_list_man_txt ,
        el.sal_real_price ,
        el.sal_money ,
        el.sal_deduct_money ,
        el.sal_is_gift ,
        el.sal_is_change ,
        el.sal_is_in ,
		el.sal_in_money,
        el.sal_in_num ,
        el.sal_is_return ,
        (case when el.sal_is_return=1 or el.sal_is_change=1 then '退换货' else '销售单' end)saltype,--单据类型
        el.sal_remark ,
        el.sal_remark2 ,
        el.sal_status ,
        el.sal_add_time ,
        el.gi_code ,
        el.gi_name ,
        el.gi_barcode ,
        el.gi_attribute_ids ,
        el.gi_attribute_parentids ,
        el.gi_types ,
        el.gi_typesid ,
        el.gi_unit ,
        el.gi_unit_id ,
        el.gss_no ,
        el.gs_name ,
        el.sal_st_id ,
        el.sal_st_id_txt ,
	    el.sal_paiddiscount,
	    el.sal_paidmomey,
		eo.sa_salmanname,
		eo.sa_erp_id,
        eo.sa_id ,
        eo.sa_sh_id ,
        eo.sa_co_man ,
        eo.sa_co_man_txt ,
        eo.sa_date ,
        eo.sa_no ,
        eo.sa_vo ,
        eo.sa_ac_id ,
        eo.sa_order_man ,
        eo.sa_st_id ,
        eo.sa_update_man ,
        eo.sa_update_time ,
        eo.sa_add_man ,
        eo.sa_add_time ,
        eo.sa_status ,
        eo.sa_type ,
        eo.sa_sa_type ,
        eo.sa_me_id ,
	   (SELECT me_phone FROM pos_memberInfo where me_id=eo.sa_me_id) as me_card,
        eo.sa_remark ,
        eo.sa_in_id ,
        eo.sa_in_num ,
        eo.sa_get_in_num ,
        eo.sa_deduct_money ,
        eo.sa_sa_vo ,
        eo.sa_gift_vo ,
        eo.sa_in_money ,
        eo.sa_card_money ,
        eo.sa_shop_money ,
        eo.sa_money ,
        eo.sa_real_money ,
        eo.sa_charge_money ,
        eo.sa_surplus_money ,
        eo.sa_select ,
        eo.sa_audit_man ,
        eo.sa_audit_time ,
        eo.sa_st_id_txt ,
        eo.sa_sh_id_txt ,
        eo.sh_company ,
        eo.sa_order_man_txt ,
        eo.sa_add_man_txt ,
        eo.sa_audit_man_txt ,
        eo.sa_update_man_txt ,
        eo.sa_paytype ,
        eo.me_name ,
        eo.oi_no ,
        eo.ai_no ,
        eo.vl_no,   --代金券券号
        ( SELECT    gi_skus
          FROM      dbo.b_goodsinfo WITH ( NOLOCK )
          WHERE     ( gi_id = el.sal_gi_id )
        ) AS gi_skus,
        ( SELECT    gi_purchase
          FROM      dbo.b_goodsinfo WITH ( NOLOCK )
          WHERE     ( gi_id = el.sal_gi_id )
        ) AS gi_purchase, --进货价
        (( SELECT    gi_purchase
          FROM      dbo.b_goodsinfo WITH ( NOLOCK )
          WHERE     ( gi_id = el.sal_gi_id )
        )*sal_num)gi_purchase_money,--进货金额
        
        (CASE WHEN sal_sku_id>0 THEN (SELECT gs_costprice 
                                             FROM b_goodsruleset AS bg
                                             WHERE gi_id=el.sal_gi_id AND bg.gss_id=el.sal_sku_id and bg.gs_status>0)
                     ELSE (SELECT gi_costprice 
                           FROM b_goodsinfo AS bg 
                           WHERE bg.gi_id=el.sal_gi_id and bg.gi_status>0) END) AS gi_costprice, --成本价
        ((CASE WHEN sal_sku_id>0 THEN (SELECT gs_costprice 
                                             FROM b_goodsruleset AS bg
                                             WHERE gi_id=el.sal_gi_id AND bg.gss_id=el.sal_sku_id and bg.gs_status>0)
                     ELSE (SELECT gi_costprice 
                           FROM b_goodsinfo AS bg 
                           WHERE bg.gi_id=el.sal_gi_id and bg.gi_status>0) END)*sal_num)gi_costprice_money,--成本金额
        
        ( SELECT    gi_retailprice
          FROM      dbo.b_goodsinfo WITH ( NOLOCK )
          WHERE     ( gi_id = el.sal_gi_id )
        ) AS gi_retailprice --零售价
        ,el.gc_name1
        ,el.gc_name2
        ,el.gc_name3
        ,el.gc_name4
		,el.sa_month
		,eo.sa_ac_names--活动名称
FROM    dbo.vi_pos_saleList AS el WITH ( NOLOCK )
        INNER JOIN ( SELECT sa_id ,
                            sa_sh_id ,
							erp_id ,
                            ps.sa_erp_id ,
							sa_co_man ,
                            sa_co_man_txt ,
                            sa_paytype ,
							--(CASE DATEPART(month,sa_date)
						 --  WHEN 1 THEN '01'
						 --  WHEN 2 THEN '02'
						 --  WHEN 3 THEN '03'
						 --  WHEN 4 THEN '04'
						 --  WHEN 5 THEN '05'
						 --  WHEN 6 THEN '06'
						 --  WHEN 7 THEN '07'
						 --  WHEN 8 THEN '08'
						 --  WHEN 9 THEN '09'
						 --  WHEN 10 THEN '10'
						 --  WHEN 11 THEN '11'
						 --  WHEN 12 THEN '12'
						 --END) AS sa_month , --销售月份
                            CONVERT (VARCHAR(10), sa_date, 120) AS sa_date ,
                            vl_no, --代金券券号
                            sa_no ,
                            sa_vo ,
                            sa_ac_id ,
                            sa_order_man ,
                            sa_st_id ,
                            sa_update_man ,
                            sa_update_time ,
                            sa_add_man ,
							sa_salmanname, 
                            sa_add_time ,
                            sa_status ,
                            sa_type ,
                            sa_sa_type ,
                            sa_me_id ,
                            sa_remark ,
                            sa_in_id ,
                            sa_in_num ,
                            sa_get_in_num ,
                            sa_deduct_money ,
                            sa_sa_vo ,
                            sa_gift_vo ,
                            sa_in_money ,
                            sa_card_money ,
                            sa_shop_money ,
                            sa_money ,
                            sa_real_money ,
                            sa_charge_money ,
                            sa_surplus_money ,
                            sa_select ,
                            sa_audit_man ,
                            sa_audit_time ,
                            oi_no ,
							ai_no ,
							sa_ac_names,--活动名称
                            ( SELECT    sei_name
                              FROM      dbo.pos_storageInfo AS psi WITH ( NOLOCK )
                              WHERE     ( sei_id = ps.sa_st_id )
                            ) AS sa_st_id_txt ,
                            ( SELECT    sh_name
                              FROM      dbo.pos_shop AS psi WITH ( NOLOCK )
                              WHERE     ( sh_id = ps.sa_sh_id )
                            ) AS sa_sh_id_txt ,
                            ( SELECT    sh_company
                              FROM      dbo.pos_shop AS psi WITH ( NOLOCK )
                              WHERE     ( sh_id = ps.sa_sh_id )
                            ) AS sh_company ,
                            ( SELECT    si_name
                              FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
                              WHERE     ( si_id = ps.sa_order_man )
                            ) AS sa_order_man_txt ,
                            ( SELECT    si_name
                              FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
                              WHERE     ( si_id = ps.sa_add_man )
                            ) AS sa_add_man_txt ,
                            ( SELECT    si_name
                              FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
                              WHERE     ( si_id = ps.sa_audit_man )
                            ) AS sa_audit_man_txt ,
                            ( SELECT    si_name
                              FROM      dbo.b_stafftinfo AS bs WITH ( NOLOCK )
                              WHERE     ( si_id = ps.sa_update_man )
                            ) AS sa_update_man_txt ,
                            ISNULL(( SELECT me_name
                                     FROM   dbo.pos_memberInfo AS pmi WITH ( NOLOCK )
                                     WHERE  ( me_id = ps.sa_me_id )
                                   ), '零售') AS me_name
                     FROM   dbo.vi_pos_sale AS ps WITH ( NOLOCK )
                   ) AS eo ON el.sal_sa_id = eo.sa_id
                              AND eo.sa_status > 0

							  
) as sale
left join b_goodsruleset  as grl on  grl.gss_id=sale.sal_sku_id

) as salelist
left join s_goodsruledetail rulenum WITH (NOLOCK) on gd_id=salelist.size
go

