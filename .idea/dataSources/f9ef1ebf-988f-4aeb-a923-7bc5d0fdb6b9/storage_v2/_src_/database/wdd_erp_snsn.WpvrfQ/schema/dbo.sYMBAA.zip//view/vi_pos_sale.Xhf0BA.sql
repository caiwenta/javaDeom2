CREATE VIEW [dbo].[vi_pos_sale]
AS
    SELECT  ps.sa_erp_id AS erp_id ,
            ps.sa_sh_id AS sh_id ,
            ( SELECT    STUFF(( SELECT  ',' + sa_paytype
                                FROM    ( SELECT    sa_id ,
                                                    '现金支付' sa_paytype
                                          FROM      pos_sale WITH ( NOLOCK )
                                          WHERE     sa_cashmoney <> 0
                                                    AND sa_id = ps.sa_id
                                          UNION ALL
                                          SELECT    sa_id ,
                                                    '储值卡' sa_paytype
                                          FROM      pos_sale WITH ( NOLOCK )
                                          WHERE     sa_storedmoney <> 0
                                                    AND sa_id = ps.sa_id
                                          UNION ALL
                                          SELECT    sa_id ,
                                                    '支付宝' sa_paytype
                                          FROM      pos_sale WITH ( NOLOCK )
                                          WHERE     sa_alipaymoney <> 0
                                                    AND sa_id = ps.sa_id
                                          UNION ALL
                                          SELECT    sa_id ,
                                                    '微信支付' sa_paytype
                                          FROM      pos_sale WITH ( NOLOCK )
                                          WHERE     sa_weixinmoney <> 0
                                                    AND sa_id = ps.sa_id
                                          UNION ALL
                                          SELECT    sa_id ,
                                                    '刷卡' sa_paytype
                                          FROM      pos_sale WITH ( NOLOCK )
                                          WHERE     sa_bankmomey <> 0
                                                    AND sa_id = ps.sa_id
                                        ) AS T
                                WHERE   sa_id = ps.sa_id
                              FOR
                                XML PATH('')
                              ), 1, 1, '')
            ) AS sa_paytype ,
            STUFF(( SELECT ', ' + vl_no FROM pos_salevoucher AS psv WITH (NOLOCK) WHERE psv.sa_id = ps.sa_id
                  FOR
                    XML PATH('')
                  ), 1, 1, '') vl_no , --代金券券号
            ps.sa_id ,
            ps.sa_erp_id ,
            ps.sa_sh_id ,
            ps.sa_co_man ,
            ( SELECT st_st_id FROM pos_staffClassSet AS bs WITH (NOLOCK) WHERE (st_id = ps.sa_co_man)
            ) AS sa_co_man_txt ,
            CONVERT (VARCHAR(10), ps.sa_date, 120) AS sa_date ,
            ps.sa_no ,
            ps.sa_vo ,
            ps.sa_ac_id ,
            ps.sa_salmanname ,
            ps.sa_order_man ,
            ps.sa_st_id ,
            ps.sa_update_man ,
            ps.sa_update_time ,
            ps.sa_add_man ,
            ps.sa_add_time ,
            ps.sa_status ,
            ps.sa_type ,
            ps.sa_sa_type ,
            ps.sa_me_id ,
            ps.sa_remark ,
            ps.sa_in_id ,
            ps.sa_in_num ,
            ps.sa_get_in_num ,
            ps.sa_deduct_money ,
            ps.sa_sa_vo ,
            ps.sa_gift_vo ,
            ps.sa_in_money ,
            ps.sa_card_money ,
            ps.sa_shop_money ,
            ps.sa_money ,
            ps.sa_real_money ,
            ps.sa_charge_money ,
            ps.sa_surplus_money ,
            ps.sa_select ,
            ps.sa_audit_man ,
            ps.sa_audit_time ,
            ( SELECT sei_name FROM dbo.pos_storageInfo AS psi WITH (NOLOCK) WHERE (sei_id = ps.sa_st_id)
            ) AS sa_st_id_txt ,
            ( SELECT si_name FROM dbo.New_b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = ps.sa_order_man)
            ) AS sa_order_man_txt ,
            ( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = ps.sa_add_man)
            ) AS sa_add_man_txt ,
            ( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = ps.sa_update_man)
            ) AS sa_update_man_txt ,
            ( SELECT si_name FROM dbo.b_stafftinfo AS bs WITH (NOLOCK) WHERE (si_id = ps.sa_audit_man)
            ) AS sa_audit_man_txt ,
            fd.sal_num ,
            fd.sa_money1 AS sal_money ,
            fd.sal_money_full ,
            ISNULL(( SELECT me_name FROM dbo.pos_memberInfo AS pmi WITH (NOLOCK) WHERE (me_id = ps.sa_me_id)
                   ), '零售') AS me_name ,
            pa.ac_name ,
            nt.ord_no AS oi_no ,
            ao.ord_no AS ai_no ,
            fd.salpaidmomey ,
            fd.sal_paidmomey ,
            ps.sa_storedmoney ,
            ps.sa_alipaymoney ,
            ps.sa_weixinmoney ,
            ps.sa_bankmomey ,
            ps.sa_cashmoney - ps.sa_surplus_money AS sa_cashmoney ,
            (CASE WHEN ps.sa_ac_names!='' THEN ps.sa_ac_names 
                  ELSE STUFF(( SELECT ', ' + ac_name 
                               FROM pos_active WITH (NOLOCK) 
                               WHERE ac_id IN (select sal_acid from pos_saleList WHERE sal_sa_id=sa_id)
					  FOR
						XML PATH('')), 1, 1, '') END)sa_ac_names--活动名称
    FROM    dbo.pos_sale AS ps WITH ( NOLOCK )
    INNER JOIN ( SELECT sal_sa_id ,
                        sal_num ,
                        sal_deduct_money ,
                        sal_money ,
                        sal_money_full ,
                        sal_change_money ,
                        sal_in_num ,
                        salpaidmomey ,
                        sal_paidmomey ,
                        sa_money1
                 FROM   dbo.vi_pos_saleList_sum AS vpsls WITH ( NOLOCK )
               ) AS fd ON ps.sa_id = fd.sal_sa_id
    LEFT JOIN dbo.pos_active AS pa WITH ( NOLOCK ) ON ps.sa_ac_id = pa.ac_id
    LEFT JOIN dbo.netorder_tbl AS nt WITH ( NOLOCK ) ON nt.ord_sa_id = ps.sa_id
                                                        AND nt.ord_sa_id > 0
    LEFT JOIN dbo.apiorder_tbl AS ao WITH ( NOLOCK ) ON ao.ord_sa_id = ps.sa_id
                                                        AND ao.ord_sa_id > 0
    WHERE   ps.sa_status > 0
go

