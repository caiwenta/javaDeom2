CREATE PROCEDURE [dbo].[pro_salelistorder_op]
	@sal_erp_id INT = 0 ,
    @sal_id INT = 0 , --主键   
    @sal_sa_id INT = 0 , --销售登记主键  
    @sal_gi_id INT = 0 , --商品主键  
    @sal_sku_id INT = 0 , --商品sku主键
    @sal_num INT = 0 , --数量  
    @sal_retail_price DECIMAL(9, 2) = 0 , --零售价  
    @sal_discount DECIMAL(9, 2) = 0 , --折率 
    @sal_list_man INT = 0 , --导购员主键 
    @sal_real_price DECIMAL(9, 2) = 0 , --实售价  
    @sal_money DECIMAL(9, 2) = 0 , --应收金额  
    @sal_deduct_money DECIMAL(9, 2) = 0 , --扣除金额  
    @sal_is_gift INT = 0 ,  --是否赠送
    @sal_is_change INT = 0 ,  --是否换货
    @sal_is_zhengjia INT = 0 ,  --是否正价
    @sal_is_tejia INT = 0 ,  --是否特价
    @sal_is_in INT = 0 ,  --是否积分兑换
    @sal_in_num INT = 0 ,  --积分
    @sal_is_return INT = 0 , --是否退货
    @sal_remark VARCHAR(50) = '' ,  --备注
    @sal_remark2 VARCHAR(50) = '' ,--备注2
    @sal_st_id INT = 0 ,
    @sal_add_time DATETIME = '2014-10-24' ,  --添加时间
    @sal_customprice VARCHAR(50)='',
	@sal_deduction DECIMAL(9, 2) = 0, --网络订单扣款
	@sal_paiddiscount DECIMAL(9, 2) = 0,
	@sal_paidmomey DECIMAL(9, 2) = 0,
	@sal_acid int=0,
	@sal_returnedid int=0,
	@sal_in_money DECIMAL(9, 2) = 0,
	@sal_real_price_old DECIMAL(9, 2) = 0,
	@sal_old_record int=0,
	@sal_deduct_money_old DECIMAL(9, 2) = 0,
	@sal_discount_old DECIMAL(9, 2) = 0,
	@sal_status int=0,
	@sal_is_active_gift int=0,
	@sal_discount_old_mem DECIMAL(9, 2) = 0,
	@sal_pkindex int=0
AS

if @sal_id=0
begin

insert into pos_saleList_temp(
sal_money,sal_deduct_money,sal_is_gift,sal_is_change,sal_is_in,sal_in_num,sal_remark,sal_status,sal_add_time,sal_is_return,sal_sa_id,sal_discount_old,sal_deduct_money_old,sal_real_price_old,sal_old_record,sal_is_active_gift,sal_discount_old_mem,sal_remark2,sal_st_id,sal_is_tejia,sal_is_zhengjia,sal_gi_id,sal_sku_id,sal_num,sal_retail_price,sal_discount,sal_list_man,sal_real_price,sal_erp_id,sal_customprice,sal_paiddiscount,sal_paidmomey,sal_buyingteamid,sal_acid,sal_returnedid,sal_in_money,sal_pkindex)
values (
@sal_money,@sal_deduct_money,@sal_is_gift,@sal_is_change,@sal_is_in,@sal_in_num,@sal_remark,@sal_status,@sal_add_time,@sal_is_return,@sal_sa_id,@sal_discount_old,@sal_deduct_money_old,@sal_real_price_old,@sal_old_record,@sal_is_active_gift,@sal_discount_old_mem,@sal_remark2,@sal_st_id,@sal_is_tejia,@sal_is_zhengjia,@sal_gi_id,@sal_sku_id,@sal_num,@sal_retail_price,@sal_discount,@sal_list_man,@sal_real_price,@sal_erp_id,@sal_customprice,@sal_paiddiscount,@sal_paidmomey,(select gi_buyingteamid from b_goodsinfo where gi_id=@sal_gi_id),@sal_acid,@sal_returnedid,@sal_in_money,@sal_pkindex
)

end
else
begin

update pos_saleList_temp set 
    sal_gi_id=@sal_gi_id,
    sal_money=@sal_money,
    sal_discount_old=@sal_discount_old,
    sal_deduct_money_old=@sal_deduct_money_old,
    sal_real_price_old=@sal_real_price_old,
    sal_old_record=@sal_old_record,
    sal_status=@sal_status,
    sal_is_active_gift=@sal_is_active_gift,
    sal_discount_old_mem=@sal_discount_old_mem,
    sal_sa_id=@sal_sa_id
    ,sal_sku_id=@sal_sku_id
    ,sal_num=@sal_num
    ,sal_retail_price=@sal_retail_price
    ,sal_discount=@sal_discount
    ,sal_list_man=@sal_list_man
    ,sal_real_price=@sal_real_price
    ,sal_deduct_money=@sal_deduct_money
    ,sal_is_gift=@sal_is_gift
    ,sal_is_change=@sal_is_change
    ,sal_is_in=@sal_is_in
    ,sal_in_num=@sal_in_num
    ,sal_remark=@sal_remark
    ,sal_add_time=@sal_add_time
    ,sal_is_return=@sal_is_return
    ,sal_remark2=@sal_remark2
    ,sal_st_id=@sal_st_id
    ,sal_is_tejia=@sal_is_tejia
    ,sal_is_zhengjia=@sal_is_zhengjia
    ,sal_erp_id=@sal_erp_id
    ,sal_paiddiscount=@sal_paiddiscount
    ,sal_paidmomey=@sal_paidmomey
    ,sal_buyingteamid=(select gi_buyingteamid from b_goodsinfo where gi_id=@sal_gi_id) 
    ,sal_acid=@sal_acid 
    ,sal_returnedid=@sal_returnedid 
    ,sal_in_money=@sal_in_money 
	,sal_pkindex=@sal_pkindex
where sal_id=@sal_id

end
go

