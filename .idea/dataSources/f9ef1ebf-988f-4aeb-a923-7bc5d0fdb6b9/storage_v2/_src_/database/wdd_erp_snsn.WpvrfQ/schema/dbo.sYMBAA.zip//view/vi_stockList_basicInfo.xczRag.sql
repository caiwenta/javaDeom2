CREATE VIEW [dbo].[vi_stockList_basicInfo] AS 
SELECT vs.*,
       bg.*,
       bs.sei_name,
       bg2.gss_no
FROM   vi_stockList              AS vs
       INNER JOIN b_storageinfo   AS bs
            ON  vs.[sid] = bs.sei_id
       INNER JOIN b_goodsinfo     AS bg
            ON  vs.gid = bg.gi_id
       INNER JOIN b_goodsruleset  AS bg2
            ON  vs.skuid = bg2.gss_id
go

