CREATE VIEW [dbo].[vi_j_Pos_plStorage_Search] AS 
SELECT
    pl_erp_id,
	pl_sh_id,
	pl_erp_id as erp_id ,
	pl_sh_id as sh_id,
	(select sh_name from pos_shop where sh_id=pl_sh_id)sh_name, -- 店铺名称
	(select sh_company from pos_shop where sh_id=pl_sh_id)sh_company, --所属公司
	ppl_pl_id,
	ppl_gi_id,
	ppl_num,--盈亏数
	ISNULL(ppl_stocknum,0)ppl_stocknum, --日期库存
	0 pll_takenum,  --实盘数量
	ppl_id,
	ppl_sku_id,
	ppl_discount,
	ppl_retail_price,
	ppl_stock_price,
	ppl_money,
	ppl_add_time,
	gi_id,

	gi_name,
	gi_code,
	gi_barcode,
	gi_unit,
	gi_unit_id,
	ppl_box_num,
	ppl_pm,
	pl_id,
	pl_vo,
	(CONVERT(varchar(14),pl_date,23))pl_date,
	pl_no,
	pl_st_id,
	pl_order_man,
	pl_st_id_txt,
	pl_order_man_txt,
	pl_add_man_txt,
	pl_add_man,
	pl_add_time,
	pl_update_man_txt,
	pl_update_man,
	pl_update_time,
	pl_audit_man_txt,
	pl_audit_man,
	pl_audit_time,
	pl_remark,
	pl_status,
	el.gi_skus,
	el.gi_attribute_ids,
	el.gi_attribute_parentids,
	el.gi_types,
	el.gi_typesid,
	el.gi_type1,
	el.gi_type2,
	el.gi_type3,
	el.gi_type4,
	el.gi_typename1,
	el.gi_typename2,
	el.gi_typename3,
	el.gi_typename4
FROM
	vi_j_Pos_plStorageList_group_goods el
INNER JOIN vi_j_Pos_plStorage eo ON el.ppl_pl_id = eo.pl_id
AND eo.pl_status > 0



UNION ALL

	 SELECT 
	 jj.sl_erp_id,
	 jj.sl_shid,
	 jj.sl_erp_id as erp_id,
	 jj.sl_shid as sh_id,
	(select sh_name from pos_shop where sh_id=jj.sl_shid)sh_name,-- 店铺名称
	(select sh_company from pos_shop where sh_id=jj.sl_shid)sh_company, --所属公司
	jj.sl_eoid,
	jj.sl_giid,
	Sum(jj.sl_number) As si_number,--盈亏数
	Sum(ISNULL((jj.sl_takenum-jj.sl_number),0)) As si_stocknum, --日期库存数量=实盘数-盈亏数
	Sum(jj.sl_takenum) As si_takenum,  --实盘数量
	0,
	sum(jj.sl_skuid),
	1,
	 jj.gi_retailprice,
	cast(avg(jj.gs_purchase) as decimal(15,2)),
SUM(jj.menoy),
jj.ts_add_time,
		jj.sl_giid,
	jj.gi_name,
 jj.gi_code ,
  jj.gi_barcode,
	jj.gi_unit_name,
	0,
	0,
	'',
			jj.sl_eoid,
		jj.ts_vo,
		 CONVERT(varchar(100), jj.ts_take_date, 23)ts_take_date,
	jj.ts_no,
	jj.sl_seiid,
	0,
	(select sei_name from pos_storageinfo WHERE  jj.sl_seiid =sei_id),
	'',
	(SELECT si_name from b_stafftinfo WHERE si_id = jj.ts_add_man),
	jj.ts_add_man,
	 jj.ts_add_time,
	 (SELECT si_name from b_stafftinfo WHERE si_id = jj.ts_update_man),
	jj.ts_update_man,
	jj.ts_update_time,
	 (SELECT si_name from b_stafftinfo WHERE si_id = jj.ts_audit_man),
	 jj.ts_audit_man,
	  jj.ts_audit_time,
	  '',
	   jj.ts_status,
	(  CASE WHEN  SUM(gi_skus)=0 THEN ''ELSE '有'end),
max(gi_attribute_ids),
max(gi_attribute_parentids),
max(gi_types),
max(gi_typesid),
max(gi_type1),
max(gi_type2),
max(gi_type3),
max(gi_type4),
max(gi_typename1),
max(gi_typename2),
max(gi_typename3),
max(gi_typename4)
  FROM	 
	  (

SELECT
js.sl_erp_id,
sl_giid,
sl_eoid,
js.sl_order_no as ts_vo,
'' as ts_no,
jt.tsl_date as ts_take_date,
gi_code,
gi_barcode,
gi_name,
gi_unit_name,
(Case when sl_counttype=1 Then sl_number Else -sl_number End) As sl_number,--盈亏数
sl_takenum,--实盘数
sl_skuid,
jt.tsl_update_time as ts_update_time,
jt.tsl_update_man as ts_audit_time,
jt.tsl_status as ts_status,
js.sl_shid,
js.sl_seiid,
jt.tsl_add_man as ts_add_man,
jt.tsl_update_man as ts_update_man,
jt.tsl_update_man as ts_audit_man,
sl_counttype,
bg.gi_retailprice,
bg.gi_importprices,
jt.tsl_add_time as ts_add_time,
(CASE WHEN sl_skuid=0 THEN gi_purchase ELSE gs_purchase END ) AS  gs_purchase,--进货价
(CASE WHEN sl_skuid=0 THEN(gi_purchase* (Case when sl_counttype=1 Then sl_number Else -sl_number End)) ELSE 
(gs_purchase* (Case when sl_counttype=1 Then sl_number Else -sl_number End))END ) as menoy ,--金额
(CASE WHEN  gi_skus='' THEN 0 ELSE 1 END ) AS   gi_skus,
gi_attribute_ids,
gi_attribute_parentids,
gi_types,
gi_typesid,
gi_type1,
gi_type2,
gi_type3,
gi_type4,
(select top 1 gc_name from s_goodsclass where gc_id=gi_type1) AS gi_typename1,
(select top 1 gc_name from s_goodsclass where gc_id=gi_type2) AS gi_typename2,
(select top 1 gc_name from s_goodsclass where gc_id=gi_type3) AS gi_typename3,
(select top 1 gc_name from s_goodsclass where gc_id=gi_type4) AS gi_typename4
FROM  pos_stocklog_pal AS js
LEFT JOIN pos_takeStorageLog jt  ON js.sl_elid=jt.tsl_id AND js.sl_eoid=jt.tsl_id AND jt.tsl_status<>0
LEFT JOIN b_goodsinfo AS bg ON sl_giid=bg.gi_id
LEFT JOIN b_goodsruleset AS bg2 ON bg2.gss_id=sl_skuid
WHERE (sl_type=7 OR sl_type=8 OR sl_type=9 OR sl_type=10) --AND sl_number!=0 


) AS jj WHERE  (ISNULL((sl_takenum-sl_number),0)!=0 OR sl_takenum!=0 OR sl_number!=0)
	 GROUP BY
	 jj.sl_erp_id,
		jj.sl_eoid,
	jj.ts_vo,
	 jj.ts_no,
	 jj.ts_take_date,
	 jj.gi_code,
jj.gi_barcode,
jj.gi_name,

jj.gi_retailprice,
 jj.gi_importprices,
 jj.ts_add_time,
   jj.ts_update_time,
    jj.ts_audit_time,
     jj.ts_status,
jj.sl_shid,
jj.sl_seiid,
jj.ts_add_man,
jj.ts_update_man,
jj.ts_audit_man,
jj.gi_unit_name,jj.sl_giid
go

