create proc wsp 
@name varchar(50),--商品名称 
@cost int         --销售量 
as 
--先得出该货物的库存是否够 
declare @spare float --剩余库存 
select @spare=sum(j)-sum(c) from t where name=@name 
if(@spare>=@cost)                         
   begin 
    --根据入库日期采用先进先出原则对货物的库存进行处理  
     update t set c=                                                                                                                      
     case when (select @cost-isnull(sum(j),0)+isnull(sum(c),0) from t where name=@name and jdate<=a.jdate and j!=c)>=0 
     then a.j 
     else                        
        case when (select @cost-isnull(sum(j),0)+isnull(sum(c),0) from t where name=@name and jdate<a.jdate and j!=c)<0 
        then 0 
        else (select @cost-isnull(sum(j),0)+isnull(sum(c),0)+a.c from t where name=@name and jdate<a.jdate and j!=c) 
        end 
     end 
     from t a where name=@name and j!=c 
   end 
else 
    raiserror('库存不足',16,1)    
    return
go

